# A3 CIM 구현 준비 산출물

참고 PPT는 **10/13 CIM Validation·Handshake 4장 보완본 하나**입니다. 현재 첨부 OSS·CIM V235와 대조해 수정했습니다.

- [수정 PPT 4장](A3LD_AutoJobChange_CIM_OSS_Review_4slides.pptx): 기존 4장 구성·도식·표를 유지한 편집 가능한 수정본.
- [통합 검토서 HTML](A3_CIM_Implementation_Review.html): 검토 15건, 시퀀스 6개, I/F40항목, 모듈Validation6행, 미실행시험50개와10일배치예시. 검색·인쇄·CSV다운로드·브라우저 평가기록/JSON저장을 제공합니다.
- `01`~`07` Markdown: 주제별 편집용 명세.
- [전체 ZIP](A3_CIM_Deliverables.zip): 위 산출물과 manifest 묶음.

HTML은 ZIP을 푼 폴더에서 열면 관련 파일 링크도 함께 사용할 수 있습니다. 평가기록은 현재 브라우저에 저장되며 JSON을 별도로 내려받아 보관해야 합니다. 초기 배포물의 시험결과는 전부 미실행입니다.

RMS 경로, 핀/기판 선후, 최종완료 범위, 허용오차/Timeout은 협의 항목입니다. 주소·필드 확인은 구현·실통신·실기 합격을 뜻하지 않습니다. 기존3분/1~2분은 설계목표이며 실측값이 아닙니다.

공유에는 파생 검토물만 포함했습니다. 원문 고객사양·원본PPT·개인MD·코드·제작/QA 자료는 포함하지 않습니다.
