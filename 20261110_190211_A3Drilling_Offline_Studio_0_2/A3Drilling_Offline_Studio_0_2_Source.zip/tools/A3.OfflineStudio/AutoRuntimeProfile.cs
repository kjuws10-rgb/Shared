using System.Runtime.InteropServices;

namespace A3.OfflineStudio;

/// <summary>Conservative CPU defaults, not a throughput or model-compatibility guarantee.</summary>
public sealed record AutoRuntimeProfile(
    string Mode,
    int ContextSize,
    int Threads,
    int GpuLayers,
    long TotalMemoryBytes,
    long AvailableMemoryBytes,
    long ModelBytes,
    string Reason)
{
    private const long GiB = 1024L * 1024 * 1024;

    public static AutoRuntimeProfile Create(int requestedContext, long modelBytes,
        long? totalMemoryBytes = null, long? availableMemoryBytes = null, int? logicalProcessors = null)
    {
        if (modelBytes < 0) throw new ArgumentOutOfRangeException(nameof(modelBytes));
        var memory = Memory();
        long total = Math.Max(0, totalMemoryBytes ?? memory.Total);
        long available = Math.Max(0, availableMemoryBytes ?? memory.Available);
        int threads = Math.Clamp((logicalProcessors ?? Environment.ProcessorCount) / 2, 1, 8);
        // Free RAM varies with the desktop load. Keep a modest context rather than guessing GPU support.
        int memoryCeiling = total >= 24 * GiB && available >= modelBytes + 8 * GiB ? 8192
            : total >= 12 * GiB && available >= modelBytes + 2 * GiB ? 4096 : 2048;
        int context = Math.Min(Math.Clamp(requestedContext, 2048, 8192), memoryCeiling);
        string reason = "CPU 자동 설정 · GPU 드라이버 호환성을 추정하지 않습니다. " +
            (context < requestedContext ? "사용 가능한 RAM을 고려해 문맥 길이를 줄였습니다." : "요청 문맥 길이를 메모리 기준 안에서 사용합니다.");
        if (total == 0 || available == 0) reason += " RAM 조회가 불가능해 보수적인 기본값을 사용합니다.";
        if (total > 0 && modelBytes > total * .75) reason += " 모델 파일이 RAM에 비해 큽니다. 로딩 실패 또는 매우 느린 응답이 발생할 수 있습니다.";
        return new("CPU Auto", context, threads, 0, total, available, modelBytes, reason);
    }

    private static (long Total, long Available) Memory()
    {
        if (!OperatingSystem.IsWindows())
        {
            var limit = GC.GetGCMemoryInfo().TotalAvailableMemoryBytes;
            return (Math.Max(0, limit), 0);
        }
        try
        {
            var memory = new MemoryStatus { Length = (uint)Marshal.SizeOf<MemoryStatus>() };
            return GlobalMemoryStatusEx(ref memory)
                ? ((long)Math.Min(memory.TotalPhysical, (ulong)long.MaxValue), (long)Math.Min(memory.AvailablePhysical, (ulong)long.MaxValue))
                : (0, 0);
        }
        catch (DllNotFoundException) { return (0, 0); }
        catch (EntryPointNotFoundException) { return (0, 0); }
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct MemoryStatus
    {
        internal uint Length;
        internal uint MemoryLoad;
        internal ulong TotalPhysical;
        internal ulong AvailablePhysical;
        internal ulong TotalPageFile;
        internal ulong AvailablePageFile;
        internal ulong TotalVirtual;
        internal ulong AvailableVirtual;
        internal ulong AvailableExtendedVirtual;
    }

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GlobalMemoryStatusEx(ref MemoryStatus buffer);
}
