using System.IO.Compression;
using System.Buffers.Binary;
using System.Security.Cryptography;
using System.Text.Json;

namespace A3.OfflineStudio;

public sealed record BundleFile(string Path, long Size, string Sha256);
public sealed record BundleModel(string Name, string File, string Sha256, int ContextSize = 4096);
public sealed record BundleRuntime(string File);
public sealed record BundleManifest(int SchemaVersion, string BundleId, string CreatedUtc, BundleModel Model, BundleRuntime Runtime, List<BundleFile> Files, JsonElement? Sources = null);
public sealed record RuntimePackageManifest(int SchemaVersion, List<BundleFile> Files, string? Source = null);

public sealed class BundleManager
{
    public string BundlesRoot { get; } = Path.Combine(StudioSettings.StateRoot, "bundles");
    public string Progress { get; private set; } = "모델 업데이트 묶음을 가져오세요.";
    private static string SafePath(string root, string relative)
    {
        if (string.IsNullOrWhiteSpace(relative) || relative.Contains(':') || relative.Contains('\\') || relative.StartsWith('/') || relative.Split('/').Any(x => x is "" or "." or ".." || x.EndsWith('.') || x.EndsWith(' ')))
            throw new InvalidDataException("업데이트에 허용되지 않는 경로가 있습니다.");
        var result = Path.GetFullPath(Path.Combine(root, relative));
        if (!result.StartsWith(Path.GetFullPath(root) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("업데이트 경로가 범위를 벗어났습니다.");
        return result;
    }
    public (string Directory, BundleManifest Manifest) Read(string bundle)
    {
        var dir = SafePath(BundlesRoot, bundle);
        return (dir, JsonSerializer.Deserialize<BundleManifest>(File.ReadAllText(Path.Combine(dir, "manifest.json")), StudioSettings.Json) ?? throw new InvalidDataException("업데이트 정보가 비어 있습니다."));
    }

    /// <summary>Registers a single local model using only an already trusted, hash-checked runtime.</summary>
    public async Task<string> ImportGgufAsync(string sourcePath, string? trustedBundleId = null, CancellationToken ct = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(sourcePath);
        sourcePath = Path.GetFullPath(sourcePath);
        NoLinks(sourcePath);
        if (!sourcePath.EndsWith(".gguf", StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("단일 .gguf 모델 파일을 선택하세요. LoRA와 분할 조각은 지원하지 않습니다.");
        await using var modelSource = new FileStream(sourcePath, FileMode.Open, FileAccess.Read, FileShare.Read, 1024 * 1024, FileOptions.Asynchronous | FileOptions.SequentialScan);
        long modelLength = modelSource.Length;
        if (modelLength < 24 || modelLength > 18L * 1024 * 1024 * 1024)
            throw new InvalidDataException("GGUF 모델은 24바이트 이상, 18GiB 이하만 지원합니다.");
        var header = new byte[24];
        await modelSource.ReadExactlyAsync(header, ct);
        if (!header.AsSpan(0, 4).SequenceEqual("GGUF"u8) || BinaryPrimitives.ReadUInt32LittleEndian(header.AsSpan(4)) is not (2 or 3)
            || BinaryPrimitives.ReadUInt64LittleEndian(header.AsSpan(8)) is 0 or > 64_000_000
            || BinaryPrimitives.ReadUInt64LittleEndian(header.AsSpan(16)) > 1_000_000)
            throw new InvalidDataException("지원하는 GGUF v2/v3 헤더가 아닙니다. 완성된 단일 GGUF를 선택하세요.");
        modelSource.Position = 0;

        var runtime = await ResolveRuntime(trustedBundleId, ct);
        Directory.CreateDirectory(BundlesRoot);
        NoLinks(BundlesRoot);
        long total = checked(modelLength + runtime.Files.Sum(f => f.Size));
        if (new DriveInfo(Path.GetPathRoot(BundlesRoot)!).AvailableFreeSpace < total + 256L * 1024 * 1024)
            throw new IOException("새 모델과 이전 모델을 함께 보관할 디스크 공간이 부족합니다.");
        var stage = Path.Combine(BundlesRoot, "stage-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(stage);
        try
        {
            var files = new List<BundleFile>();
            foreach (var file in runtime.Files)
            {
                ct.ThrowIfCancellationRequested();
                var source = SafePath(runtime.Directory, file.Path);
                NoLinks(source);
                string destination = runtime.PrefixRuntime && !file.Path.StartsWith("licenses/", StringComparison.OrdinalIgnoreCase)
                    ? "runtime/" + file.Path : file.Path;
                var target = SafePath(stage, destination);
                Progress = "검증된 실행기 복사: " + Path.GetFileName(file.Path);
                await using var input = new FileStream(source, FileMode.Open, FileAccess.Read, FileShare.Read, 1024 * 1024, FileOptions.Asynchronous | FileOptions.SequentialScan);
                string hash = await CopyChecked(input, target, file.Size, ct);
                if (!hash.Equals(file.Sha256, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidDataException("기존 실행기의 해시가 바뀌었습니다. 검증된 실행기 ZIP을 다시 가져오세요.");
                files.Add(new(destination, file.Size, hash));
            }
            var modelHash = await CopyChecked(modelSource, SafePath(stage, "models/model.gguf"), modelLength, ct);
            files.Add(new("models/model.gguf", modelLength, modelHash));
            string id = "bundle-" + DateTime.UtcNow.ToString("yyyyMMddHHmmss") + "-" + Guid.NewGuid().ToString("N")[..8];
            var manifest = new BundleManifest(1, "a3-local-" + modelHash[..12], DateTime.UtcNow.ToString("O"),
                new("로컬 GGUF · " + modelHash[..8], "models/model.gguf", modelHash, 4096),
                new("runtime/llama-server.exe"), files,
                JsonSerializer.SerializeToElement(new { kind = "local-gguf", modelSha256 = modelHash, runtimeSource = runtime.Source, note = "모델 가중치 재학습·변환을 수행하지 않음. 구조·템플릿 호환성은 실제 로딩에서 확인." }, StudioSettings.Json));
            await File.WriteAllTextAsync(Path.Combine(stage, "manifest.json"), JsonSerializer.Serialize(manifest, StudioSettings.Json), ct);
            ct.ThrowIfCancellationRequested();
            Directory.Move(stage, Path.Combine(BundlesRoot, id));
            Progress = "GGUF 검증 완료. 모델을 준비합니다.";
            return id;
        }
        finally
        {
            var full = Path.GetFullPath(stage);
            if (Directory.Exists(full) && full.StartsWith(Path.GetFullPath(BundlesRoot) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
            { NoLinks(full); Directory.Delete(full, true); }
        }
    }

    private async Task<(string Directory, List<BundleFile> Files, bool PrefixRuntime, string Source)> ResolveRuntime(string? trustedBundleId, CancellationToken ct)
    {
        string directory;
        List<BundleFile> files;
        bool prefix;
        string source;
        if (!string.IsNullOrWhiteSpace(trustedBundleId))
        {
            var existing = Read(trustedBundleId);
            directory = existing.Directory;
            if (existing.Manifest.SchemaVersion != 1 || existing.Manifest.Runtime?.File != "runtime/llama-server.exe" || existing.Manifest.Files is null)
                throw new InvalidDataException("기존 실행기 목록을 확인할 수 없습니다. 실행기 ZIP을 다시 가져오세요.");
            if (existing.Manifest.Files.Any(f => f is null || string.IsNullOrWhiteSpace(f.Path)))
                throw new InvalidDataException("기존 실행기 목록에 빈 경로가 있습니다.");
            // Older verified bundles also carry CLI binaries. Reuse only the server, its DLLs and notices;
            // never execute or silently adopt other executables merely because they sit beside a GGUF.
            files = existing.Manifest.Files.Where(f =>
                f.Path.Equals("runtime/llama-server.exe", StringComparison.OrdinalIgnoreCase)
                || f.Path.Equals("runtime/LICENSE-LLVM-OpenMP", StringComparison.OrdinalIgnoreCase)
                || (f.Path.StartsWith("runtime/", StringComparison.OrdinalIgnoreCase) && !f.Path[8..].Contains('/') && f.Path.EndsWith(".dll", StringComparison.OrdinalIgnoreCase))
                || (f.Path.StartsWith("licenses/", StringComparison.OrdinalIgnoreCase) && f.Path.EndsWith(".txt", StringComparison.OrdinalIgnoreCase))).ToList();
            prefix = false; source = "verified-local-bundle:" + trustedBundleId;
        }
        else
        {
            directory = Path.Combine(AppContext.BaseDirectory, "Runtime");
            var path = Path.Combine(directory, "runtime-manifest.json");
            NoLinks(path);
            if (!File.Exists(path) || new FileInfo(path).Length > 1_000_000)
                throw new InvalidOperationException("모델 실행기가 없습니다. 최초 한 번 검증된 모델/실행기 ZIP을 가져오거나, Runtime 폴더가 포함된 배포본을 사용하세요. 인터넷에서 자동 다운로드하지 않습니다.");
            RuntimePackageManifest package;
            await using (var stream = File.OpenRead(path)) package = await JsonSerializer.DeserializeAsync<RuntimePackageManifest>(stream, StudioSettings.Json, ct)
                ?? throw new InvalidDataException("실행기 정보가 비어 있습니다.");
            if (package.SchemaVersion != 1 || package.Files is null) throw new InvalidDataException("실행기 목록 형식이 올바르지 않습니다.");
            files = package.Files; prefix = true; source = package.Source ?? "local-runtime-package";
        }
        NoLinks(directory);
        if (files.Count is < 1 or > 256 || files.Sum(f => f.Size) > 1024L * 1024 * 1024) throw new InvalidDataException("실행기 목록 크기가 올바르지 않습니다.");
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var file in files)
        {
            ct.ThrowIfCancellationRequested();
            _ = SafePath(directory, file.Path);
            string runtimePath = prefix ? file.Path : file.Path.StartsWith("runtime/", StringComparison.OrdinalIgnoreCase) ? file.Path[8..] : file.Path;
            bool license = (file.Path.StartsWith("licenses/", StringComparison.OrdinalIgnoreCase) && file.Path.EndsWith(".txt", StringComparison.OrdinalIgnoreCase))
                || runtimePath.Equals("LICENSE-LLVM-OpenMP", StringComparison.OrdinalIgnoreCase);
            bool executable = runtimePath.Equals("llama-server.exe", StringComparison.OrdinalIgnoreCase);
            bool library = !runtimePath.Contains('/') && runtimePath.EndsWith(".dll", StringComparison.OrdinalIgnoreCase);
            if (!seen.Add(file.Path) || !(license || executable || library) || file.Size is < 0 or > 512L * 1024 * 1024 || file.Sha256 is null || file.Sha256.Length != 64 || !file.Sha256.All(Uri.IsHexDigit))
                throw new InvalidDataException("실행기 파일 목록 또는 해시가 올바르지 않습니다.");
        }
        if (!files.Any(f => f.Path.Equals(prefix ? "llama-server.exe" : "runtime/llama-server.exe", StringComparison.OrdinalIgnoreCase)))
            throw new InvalidDataException("검증된 llama-server.exe가 없습니다.");
        return (directory, files, prefix, source);
    }

    private async Task<string> CopyChecked(Stream input, string target, long expected, CancellationToken ct)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(target)!);
        using var hash = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
        await using (var output = new FileStream(target, FileMode.CreateNew, FileAccess.Write, FileShare.None, 1024 * 1024, FileOptions.Asynchronous | FileOptions.SequentialScan))
        {
            var buffer = new byte[1024 * 1024]; long count = 0; int read;
            while ((read = await input.ReadAsync(buffer, ct)) != 0)
            {
                count = checked(count + read);
                if (count > expected) throw new InvalidDataException("반입 중 파일 크기가 변경되었습니다.");
                hash.AppendData(buffer, 0, read);
                await output.WriteAsync(buffer.AsMemory(0, read), ct);
                Progress = "GGUF·실행기 복사 검증 " + (count / (1024 * 1024)).ToString("N0") + "/" + (expected / (1024 * 1024)).ToString("N0") + " MB";
            }
            if (count != expected) throw new InvalidDataException("모델/실행기 파일이 중간에 잘렸습니다.");
        }
        var value = Convert.ToHexString(hash.GetHashAndReset()).ToLowerInvariant();
        await using var saved = new FileStream(target, FileMode.Open, FileAccess.Read, FileShare.Read, 1024 * 1024, FileOptions.Asynchronous | FileOptions.SequentialScan);
        string copied = Convert.ToHexString(await SHA256.HashDataAsync(saved, ct)).ToLowerInvariant();
        if (value != copied) throw new IOException("복사된 파일의 해시 검증에 실패했습니다.");
        return value;
    }

    private static void NoLinks(string path)
    {
        for (string? current = Path.GetFullPath(path); current is not null; current = Path.GetDirectoryName(current))
        {
            try { if ((File.GetAttributes(current) & FileAttributes.ReparsePoint) != 0) throw new InvalidDataException("링크/junction 모델 또는 실행기는 사용할 수 없습니다."); }
            catch (FileNotFoundException) { }
            catch (DirectoryNotFoundException) { }
        }
    }
    public async Task<string> ImportAsync(string zipPath, CancellationToken ct = default)
    {
        Directory.CreateDirectory(BundlesRoot);
        var stage = Path.Combine(BundlesRoot, "stage-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(stage);
        try
        {
            using var zip = ZipFile.OpenRead(zipPath);
            if (zip.Entries.Count is < 3 or > 1500) throw new InvalidDataException("업데이트 파일 수가 올바르지 않습니다.");
            var entries = new Dictionary<string, ZipArchiveEntry>(StringComparer.OrdinalIgnoreCase);
            long total = 0;
            foreach (var e in zip.Entries)
            {
                if (e.FullName.EndsWith('/')) continue;
                _ = SafePath(stage, e.FullName);
                if (((e.ExternalAttributes >> 16) & 0xF000) == 0xA000 || (e.ExternalAttributes & 0x400) != 0) throw new InvalidDataException("링크 파일은 반입할 수 없습니다.");
                if (!entries.TryAdd(e.FullName, e)) throw new InvalidDataException("중복 업데이트 경로입니다.");
                total = checked(total + e.Length);
                if (total > 24L * 1024 * 1024 * 1024 || e.Length > 18L * 1024 * 1024 * 1024) throw new InvalidDataException("업데이트 크기 제한을 초과했습니다.");
            }
            if (!entries.TryGetValue("manifest.json", out var me) || me.Length > 2_000_000) throw new InvalidDataException("manifest.json이 없거나 너무 큽니다.");
            BundleManifest m;
            using (var stream = me.Open()) m = await JsonSerializer.DeserializeAsync<BundleManifest>(stream, StudioSettings.Json, ct) ?? throw new InvalidDataException("업데이트 정보가 비어 있습니다.");
            if (m.SchemaVersion != 1 || m.Model is null || m.Runtime is null || m.Files is null || m.Files.Count == 0 || m.Model.ContextSize is < 2048 or > 16384) throw new InvalidDataException("지원하지 않는 업데이트 형식입니다.");
            if (m.Runtime.File != "runtime/llama-server.exe" || !m.Model.File.StartsWith("models/", StringComparison.Ordinal) || !m.Model.File.EndsWith(".gguf", StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("모델 또는 실행기 위치가 잘못되었습니다.");
            var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var f in m.Files)
            {
                _ = SafePath(stage, f.Path);
                if (f.Path.Equals("manifest.json", StringComparison.OrdinalIgnoreCase) || !names.Add(f.Path) || !entries.TryGetValue(f.Path, out var entry) || entry.Length != f.Size || f.Sha256.Length != 64 || !f.Sha256.All(Uri.IsHexDigit)) throw new InvalidDataException("목록과 실제 업데이트 파일이 일치하지 않습니다.");
            }
            if (!names.Contains(m.Model.File) || !names.Contains(m.Runtime.File) || entries.Count != names.Count + 1 || !m.Files.Single(f => f.Path.Equals(m.Model.File, StringComparison.OrdinalIgnoreCase)).Sha256.Equals(m.Model.Sha256, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("모델 해시 또는 파일 목록이 불완전합니다.");
            var free = new DriveInfo(Path.GetPathRoot(stage)!).AvailableFreeSpace;
            if (free < total + 256L * 1024 * 1024) throw new IOException("업데이트를 풀 디스크 공간이 부족합니다.");
            var count = 0;
            foreach (var f in m.Files)
            {
                ct.ThrowIfCancellationRequested();
                Progress = $"업데이트 검증 {++count}/{m.Files.Count}: {f.Path}";
                var dest = SafePath(stage, f.Path);
                Directory.CreateDirectory(Path.GetDirectoryName(dest)!);
                using var hasher = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
                await using (var source = entries[f.Path].Open())
                await using (var target = new FileStream(dest, FileMode.CreateNew, FileAccess.Write, FileShare.None, 1024 * 1024, FileOptions.Asynchronous | FileOptions.SequentialScan))
                {
                    var buffer = new byte[1024 * 1024]; long copied = 0; int bytes;
                    while ((bytes = await source.ReadAsync(buffer, ct)) != 0)
                    {
                        copied += bytes;
                        if (copied > f.Size) throw new InvalidDataException("업데이트의 실제 크기가 목록을 초과했습니다.");
                        hasher.AppendData(buffer, 0, bytes);
                        await target.WriteAsync(buffer.AsMemory(0, bytes), ct);
                        if (f.Size > 100 * 1024 * 1024) Progress = $"모델 반입·검증 {copied / (1024 * 1024):N0}/{f.Size / (1024 * 1024):N0} MB";
                    }
                    if (copied != f.Size) throw new InvalidDataException("업데이트 파일이 중간에 잘렸습니다.");
                }
                var hash = Convert.ToHexString(hasher.GetHashAndReset());
                if (!hash.Equals(f.Sha256, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException($"파일 검증 실패: {f.Path}");
            }
            await File.WriteAllTextAsync(Path.Combine(stage, "manifest.json"), JsonSerializer.Serialize(m, StudioSettings.Json), ct);
            var id = "bundle-" + DateTime.UtcNow.ToString("yyyyMMddHHmmss") + "-" + Guid.NewGuid().ToString("N")[..8];
            Directory.Move(stage, Path.Combine(BundlesRoot, id));
            Progress = "업데이트 검증 완료. 모델을 준비합니다.";
            return id;
        }
        finally
        {
            if (Directory.Exists(stage) && Path.GetFullPath(stage).StartsWith(Path.GetFullPath(BundlesRoot) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)) Directory.Delete(stage, true);
        }
    }
}
