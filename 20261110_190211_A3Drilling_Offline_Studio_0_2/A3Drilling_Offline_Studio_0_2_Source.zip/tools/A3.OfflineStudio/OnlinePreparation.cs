using System.Diagnostics;
using System.Text;
using System.Text.RegularExpressions;
using A3.OfflineStudio.Core;

namespace A3.OfflineStudio;

public sealed record PreparedProject(string Path, string Commit, int Files, string Note);

/// <summary>
/// Explicit online preparation only. A fresh, push-disabled A3Drilling snapshot is
/// prepared beside existing snapshots; the active working copy is never pulled or replaced.
/// </summary>
public sealed class OnlinePreparation
{
    private const string Source = "https://github.com/kjuws10-rgb/A3Drilling.git";
    private const int MaximumCapturedCharacters = 16_384;
    public event Action<string>? Progress;

    public async Task<PreparedProject> PrepareAsync(string destinationRoot, CancellationToken ct = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(destinationRoot);
        ct.ThrowIfCancellationRequested();
        string root = Path.TrimEndingDirectorySeparator(System.IO.Path.GetFullPath(destinationRoot));
        RepositoryGuard.CheckNoReparsePoints(root);
        for (var ancestor = new DirectoryInfo(root); ancestor is not null; ancestor = ancestor.Parent)
            if (Directory.Exists(System.IO.Path.Combine(ancestor.FullName, ".git")) || File.Exists(System.IO.Path.Combine(ancestor.FullName, ".git")))
                throw new InvalidOperationException("온라인 준비 폴더는 기존 Git 작업 폴더 밖에 두어야 합니다. 기존 코드 폴더는 변경하지 않습니다.");
        Directory.CreateDirectory(root);
        RepositoryGuard.CheckNoReparsePoints(root);
        string git = FindGit();
        string id = Guid.NewGuid().ToString("N");
        string stage = Child(root, ".staging-a3-" + id);
        string hooks = Child(root, ".staging-a3-hooks-" + id);
        if (Directory.Exists(stage) || File.Exists(stage) || Directory.Exists(hooks) || File.Exists(hooks))
            throw new IOException("온라인 준비용 임시 경로가 이미 있습니다. 다시 실행해 주세요.");
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
        timeout.CancelAfter(TimeSpan.FromMinutes(10));
        bool moved = false;
        try
        {
            Directory.CreateDirectory(hooks);
            RepositoryGuard.CheckNoReparsePoints(hooks);
            Report("온라인 준비: A3Drilling master를 새 폴더로 받고 있습니다. 기존 작업 폴더는 유지합니다.");
            await Git(git, root, hooks,
                ["clone", "--depth", "1", "--single-branch", "--branch", "master", "--", Source, stage], timeout.Token);
            RepositoryGuard.CheckNoReparsePoints(stage);
            await Git(git, stage, hooks, ["remote", "set-url", "--push", "origin", "DISABLED"], timeout.Token);
            var guard = new RepositoryGuard(stage);
            guard.VerifyRepository();
            string branch = (await Git(git, stage, hooks, ["symbolic-ref", "--short", "HEAD"], timeout.Token)).Trim();
            if (!branch.Equals("master", StringComparison.Ordinal))
                throw new InvalidDataException("새 사본의 master 브랜치를 확인할 수 없습니다.");
            string commit = (await Git(git, stage, hooks, ["rev-parse", "--verify", "HEAD"], timeout.Token)).Trim();
            if (!Regex.IsMatch(commit, "^[0-9a-fA-F]{40}$", RegexOptions.CultureInvariant))
                throw new InvalidDataException("원본 Commit을 확인할 수 없습니다.");
            string remoteCommit = (await Git(git, stage, hooks,
                ["rev-parse", "--verify", "refs/remotes/origin/master"], timeout.Token)).Trim();
            if (!commit.Equals(remoteCommit, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("새 사본과 origin/master Commit이 일치하지 않습니다.");
            string dirty = await Git(git, stage, hooks, ["status", "--porcelain=v1", "--untracked-files=all"], timeout.Token);
            if (!string.IsNullOrWhiteSpace(dirty))
                throw new InvalidDataException("새 코드 사본에 예상하지 못한 변경이 있습니다. 기존 작업은 유지됩니다.");
            int files = 0;
            foreach (string relative in guard.GetTrackedPaths())
            {
                timeout.Token.ThrowIfCancellationRequested();
                if (!ProjectIndex.IsSupportedPath(relative)) continue;
                try { if (File.Exists(guard.ResolvePath(relative))) files++; }
                catch (UnauthorizedAccessException) { /* Keep the same exclusion boundary as local retrieval. */ }
            }
            if (files == 0) throw new InvalidDataException("분석 가능한 A3 코드 파일이 없습니다.");
            string final = Child(root, "A3Drilling-" + DateTime.UtcNow.ToString("yyyyMMdd_HHmmss_fff") + "-" + commit[..12]);
            if (Directory.Exists(final) || File.Exists(final))
                throw new IOException("같은 준비 폴더가 이미 있어 덮어쓰지 않았습니다. 다시 실행해 주세요.");
            timeout.Token.ThrowIfCancellationRequested();
            RepositoryGuard.CheckNoReparsePoints(root);
            RepositoryGuard.CheckNoReparsePoints(stage);
            // Same-parent rename publishes only a complete, verified snapshot.
            Directory.Move(stage, final);
            moved = true;
            Report("온라인 준비 완료: 새 코드 사본을 만들었습니다. 열기 전에는 현재 작업이 바뀌지 않습니다.");
            return new(final, commit.ToLowerInvariant(), files,
                "A3Drilling master의 새 코드 사본입니다. 기존 작업과 수정 파일은 보존했습니다. " +
                "새 사본 열기는 별도 선택이며, 자료·코드 검색 문맥 갱신이지 모델 가중치 재학습은 아닙니다.");
        }
        catch (OperationCanceledException) when (!ct.IsCancellationRequested)
        {
            throw new TimeoutException("온라인 코드 준비 시간이 10분을 초과했습니다. 인터넷 연결을 확인한 뒤 다시 시도해 주세요. 기존 작업은 유지됩니다.");
        }
        finally
        {
            if (!moved) DeleteOwnedStage(root, stage, ".staging-a3-" + id);
            DeleteOwnedStage(root, hooks, ".staging-a3-hooks-" + id);
        }
    }

    private void Report(string text) => Progress?.Invoke(text);

    private static string FindGit()
    {
        var bundled = System.IO.Path.Combine(AppContext.BaseDirectory, "toolchain", "git", "cmd", "git.exe");
        if (File.Exists(bundled)) { RepositoryGuard.CheckNoReparsePoints(bundled); return bundled; }
        foreach (string entry in (Environment.GetEnvironmentVariable("PATH") ?? "").Split(System.IO.Path.PathSeparator))
        {
            if (string.IsNullOrWhiteSpace(entry)) continue;
            try
            {
                string path = System.IO.Path.GetFullPath(System.IO.Path.Combine(entry.Trim().Trim('"'), "git.exe"));
                if (!File.Exists(path)) continue;
                RepositoryGuard.CheckNoReparsePoints(path);
                return path;
            }
            catch (Exception ex) when (ex is ArgumentException or NotSupportedException or IOException or UnauthorizedAccessException) { }
        }
        throw new FileNotFoundException("온라인 준비에 Git이 필요합니다. Git for Windows를 설치하거나 반입 패키지의 toolchain/git 폴더를 준비해 주세요. 오프라인 채팅에는 Git 실행 파일이 필요하지 않습니다.");
    }

    private static async Task<string> Git(string executable, string working, string hooks, IReadOnlyList<string> arguments, CancellationToken ct)
    {
        var info = new ProcessStartInfo(executable)
        {
            WorkingDirectory = working, UseShellExecute = false, CreateNoWindow = true,
            RedirectStandardOutput = true, RedirectStandardError = true,
            StandardOutputEncoding = Encoding.UTF8, StandardErrorEncoding = Encoding.UTF8
        };
        foreach (string arg in new[] { "-c", "core.hooksPath=" + hooks, "-c", "credential.helper=", "-c", "credential.interactive=never", "-c", "protocol.file.allow=never", "-c", "http.followRedirects=false" })
            info.ArgumentList.Add(arg);
        foreach (string arg in arguments) info.ArgumentList.Add(arg);
        foreach (string key in info.Environment.Keys.Where(key => key.StartsWith("GIT_", StringComparison.OrdinalIgnoreCase)).ToArray())
            info.Environment.Remove(key);
        info.Environment["GIT_TERMINAL_PROMPT"] = "0";
        info.Environment["GCM_INTERACTIVE"] = "never";
        info.Environment["GIT_CONFIG_NOSYSTEM"] = "1";
        info.Environment["GIT_CONFIG_GLOBAL"] = "NUL";
        info.Environment["GIT_CONFIG_COUNT"] = "0";
        info.Environment["GIT_OPTIONAL_LOCKS"] = "0";
        info.Environment["GIT_LFS_SKIP_SMUDGE"] = "1";
        foreach (string variable in new[] { "GIT_DIR", "GIT_WORK_TREE", "GIT_COMMON_DIR", "GIT_INDEX_FILE", "GIT_OBJECT_DIRECTORY", "GIT_ALTERNATE_OBJECT_DIRECTORIES" })
            info.Environment.Remove(variable);
        using var process = Process.Start(info) ?? throw new IOException("Git을 시작할 수 없습니다.");
        ProcessJob job;
        try { job = ProcessJob.Attach(process); }
        catch
        {
            try { if (!process.HasExited) process.Kill(entireProcessTree: true); } catch (InvalidOperationException) { }
            throw;
        }
        using var processJob = job;
        var stdout = new StringBuilder(); var stderr = new StringBuilder();
        Task output = Drain(process.StandardOutput, stdout);
        Task error = Drain(process.StandardError, stderr);
        try
        {
            await process.WaitForExitAsync(ct).ConfigureAwait(false);
            await Task.WhenAll(output, error).ConfigureAwait(false);
        }
        catch
        {
            try { if (!process.HasExited) process.Kill(entireProcessTree: true); } catch (InvalidOperationException) { }
            try { await process.WaitForExitAsync(CancellationToken.None).WaitAsync(TimeSpan.FromSeconds(5)).ConfigureAwait(false); } catch (TimeoutException) { }
            throw;
        }
        if (process.ExitCode != 0)
            throw new IOException("온라인 코드 준비에 실패했습니다. 인터넷/권한을 확인해 주세요. 기존 작업은 유지됩니다.\n" + stderr.ToString().Trim());
        return stdout.ToString();
    }

    private static async Task Drain(StreamReader reader, StringBuilder captured)
    {
        char[] buffer = new char[4096];
        while (true)
        {
            int count = await reader.ReadAsync(buffer).ConfigureAwait(false);
            if (count == 0) return;
            int retain = Math.Min(count, Math.Max(0, MaximumCapturedCharacters - captured.Length));
            if (retain > 0) captured.Append(buffer, 0, retain);
        }
    }

    private static string Child(string root, string name)
    {
        string full = System.IO.Path.GetFullPath(System.IO.Path.Combine(root, name));
        if (!string.Equals(System.IO.Path.GetDirectoryName(full), root, StringComparison.OrdinalIgnoreCase))
            throw new UnauthorizedAccessException("준비 폴더 범위를 벗어났습니다.");
        return full;
    }

    private static void DeleteOwnedStage(string root, string path, string exactName)
    {
        // Never delete a computed path until its absolute parent/name and link status are checked.
        try
        {
            string full = System.IO.Path.GetFullPath(path);
            if (!string.Equals(full, Child(root, exactName), StringComparison.OrdinalIgnoreCase) ||
                !string.Equals(System.IO.Path.GetDirectoryName(full), root, StringComparison.OrdinalIgnoreCase)) return;
            RepositoryGuard.CheckNoReparsePoints(root);
            RepositoryGuard.CheckNoReparsePoints(full);
            if (!Directory.Exists(full)) return;
            // Git pack files can be read-only. Clear only regular files in this owned staging directory.
            foreach (string file in Directory.EnumerateFiles(full, "*", new EnumerationOptions { RecurseSubdirectories = true, AttributesToSkip = FileAttributes.ReparsePoint }))
            {
                RepositoryGuard.CheckNoReparsePoints(file);
                File.SetAttributes(file, File.GetAttributes(file) & ~FileAttributes.ReadOnly);
            }
            Directory.Delete(full, recursive: true);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        { /* A failed cleanup leaves a uniquely named staging directory; never touch another snapshot. */ }
    }
}
