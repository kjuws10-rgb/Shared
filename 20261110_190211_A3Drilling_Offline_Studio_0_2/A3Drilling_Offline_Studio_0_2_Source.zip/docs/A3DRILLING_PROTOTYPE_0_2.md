# A3Drilling offline chat prototype 0.2

This release adapts the existing Windows local coding app to the A3Drilling repository. It provides a simple HTML chat screen backed by a self-contained .NET application and a local llama.cpp model server. The initial workflow is: run the app, select a supported GGUF if needed, then ask for a small explanation or code change.

## Behavior

- The repository guard accepts `kjuws10-rgb/A3Drilling` and shows the active source commit.
- Current source and selected documents are searched for each request. Korean query aliases help locate English source identifiers. This is lexical retrieval, not whole-repository training or a complete call graph.
- GGUF import reuses the verified CPU runtime from an existing trusted bundle or the prepared runtime directory. CPU threads and context are chosen conservatively from available memory. GPU layers remain zero in this prototype.
- Code proposals require a preview and explicit apply. Source hashes, backups and undo remain in force. A missing explicitly named source file is reported rather than silently substituted with an unrelated document.
- Explicit online preparation clones the fixed A3Drilling `master` into a new, push-disabled directory. Activation is separate and the previous working directory can be reopened. Imported documents survive a source-directory switch.
- Model replacement, source/document updates and weight training are separate operations. LoRA/weight training, PDF OCR and automatic import of all Codex conversations are not implemented.

## Verification on 2026-11-10

| Check | Result |
| --- | --- |
| Core regression checks | 27 passed |
| Integration checks | 31 passed |
| Independent runtime/import/profile checks | 21 passed |
| Mocked frontend checks | 21 passed |
| Independent state/recovery checks | 14 passed with actual state/core and model/bundle test doubles |
| UI context-switch/race checks | 24 passed |
| Actual 7B model and workflow checks | 20 passed |
| Actual generated C# helper behavior checks | 5 passed after isolated compilation |
| Final actual existing-file edit/apply/undo | 8 passed, including requested insertion position and byte-exact restoration |
| Self-contained Win-x64 publication | 0 warnings, 0 errors |
| Actual local-backend browser check | No JavaScript errors, no non-loopback browser requests, no mobile overflow |

The actual model was Qwen2.5-Coder-7B-Instruct Q4_K_M, 4,683,073,536 bytes. A small C# helper proposal took 138.4 seconds on the test PC with CPU Auto, four threads and a 2,048-token context. The final existing-file comment change, explicit apply and undo took 86.3 seconds in total with a 4,096-token context. These examples are not performance or correctness guarantees. An earlier proposal preserved the code but put the comment after the first using directive; after improving insertion guidance, the stricter position check passed. Apply and undo were exercised on an app-owned source copy. The successful Korean explanation check reused a reply from the earlier actual-model run; it is not reported as a second timed run.

The target A3Drilling baseline still fails its offline build with 19 existing missing `Common.Log`/`CLogManager` errors. This is distinct from the successful tool build. No equipment application or physical equipment was run. A physical network-disconnection test and broad complex-change evaluation remain future field checks.

## Distribution boundary

Keep source code for this app separate from equipment source. Prepared equipment clones, selected context, models, runtimes, SDKs and private test sessions belong in the local deployment directory, not this public app repository. This work is a local prototype and is not automatically published. The prepared deployment should be copied as a complete folder; first model import can take several minutes for file copying and hashing. Online source preparation needs Git for Windows if portable Git is not included. Offline chat does not need Git to be executable.

Native dependency inspection found three external VC++ v14 x64 DLL requirements. The prepared local folder therefore includes the official Microsoft offline redistributable, its verified Microsoft Authenticode identity and SHA256 metadata, plus a launcher that checks prerequisites. `Start-OfflineStudio.ps1 -CheckOnly` never installs or starts the app. Normal launch opens an interactive installer only when required, preserving license/UAC/cancel decisions. No installer was executed during development; fresh-machine installation remains a field check. The tool EXE is unsigned and site execution policy can still require administrator approval. A self-contained .NET build does not remove native runtime prerequisites.
