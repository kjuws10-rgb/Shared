using System.Globalization;
using Drilling.Common.Review;
using Drilling.File.Parser;

namespace Drilling.File.ReviewResult;

public sealed partial class CReviewResultFile
{
    public override Task<string> SaveRoughCorrection(ST_ROUGH_REVIEW_RESULT_DATA result,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (result.Snapshot.Points.Count == 0 || result.Snapshot.RecipeId != result.Plan.RecipeId)
            throw new InvalidDataException("ROUGH 검사 결과의 대상 또는 레시피가 올바르지 않습니다.");
        string[] headers = ["SAVED_AT", "RECIPE_ID", "RUN_TYPE", "RULE_SCOPE", "RESULT_STATUS", "RESULT_MESSAGE",
            "STAGE_SIMULATION", "VISION_SIMULATION", "TOTAL_COUNT", "POINT_NO", "HEAD_NO", "CELL_NO", "SHOT_NAME",
            "SHOT_KEY", "BEAM_NO", "LINE_NO", "INDEX_X", "INDEX_Y", "DESIGN_X", "DESIGN_Y",
            "REVIEW_X_TARGET", "STAGE_Y_TARGET", "VISION_X_FLIP", "VISION_Y_FLIP", "VISION_XY_FLIP",
            "RECV_TARGET_MINUS_HOLE_X", "RECV_TARGET_MINUS_HOLE_Y", "VISION_FLIP_CONVERT_X", "VISION_FLIP_CONVERT_Y",
            "RESULT_SOURCE", "JUDGE"];
        var flip = result.Plan.VisionFlipType;
        var status = result.Snapshot.State switch
        {
            EN_REVIEW_SEQUENCE_STATE.Completed => "COMPLETED",
            EN_REVIEW_SEQUENCE_STATE.Stopped => "STOPPED",
            EN_REVIEW_SEQUENCE_STATE.Failed => "FAILED",
            _ => throw new InvalidDataException("ROUGH 검사 종료 상태가 아닙니다.")
        };
        var rows = result.Snapshot.Points.Select(point =>
        {
            var measured = point.State is EN_REVIEW_POINT_STATE.Ok or EN_REVIEW_POINT_STATE.Ng;
            var error = point.Judge == "ERROR";
            var design = CReviewCoordinateTransformer.VisionErrorToStageOffset(point.ErrorX, point.ErrorY, flip);
            var x = (Math.Max(1, point.ShotNo) - 1) % Math.Max(1, point.PixelCountX) + 1;
            var y = (Math.Max(1, point.ShotNo) - 1) / Math.Max(1, point.PixelCountX) + 1;
            return (IReadOnlyDictionary<string, string>)new Dictionary<string, string>
            {
                ["SAVED_AT"] = FormatDate(result.SavedAt), ["RECIPE_ID"] = result.Plan.RecipeId,
                ["RUN_TYPE"] = result.IsNgRetry ? "NG_RETRY" : "INITIAL",
                ["RULE_SCOPE"] = result.Plan.CorrectionPlan?.Scope == EN_REVIEW_CORRECTION_SCOPE.HeadCell ? "HEAD_CELL" : "HEAD",
                ["RESULT_STATUS"] = status, ["RESULT_MESSAGE"] = result.Snapshot.Message,
                ["STAGE_SIMULATION"] = result.IsStageSimulation ? "ON" : "OFF", ["VISION_SIMULATION"] = result.IsVisionSimulation ? "ON" : "OFF",
                ["TOTAL_COUNT"] = Int(result.Snapshot.Points.Count), ["POINT_NO"] = Int(point.PointNo),
                ["HEAD_NO"] = Int(point.HeadNo), ["CELL_NO"] = Int(point.CellNo),
                ["SHOT_NAME"] = CReviewShotNameFormatter.ToMatrixName(point.ShotNo, point.PixelCountX),
                ["SHOT_KEY"] = point.ShotKey, ["BEAM_NO"] = Int(point.BeamNo), ["LINE_NO"] = Int(y), ["INDEX_X"] = Int(x), ["INDEX_Y"] = Int(y),
                ["DESIGN_X"] = Number(point.DesignX), ["DESIGN_Y"] = Number(point.DesignY),
                ["REVIEW_X_TARGET"] = Number(point.ReviewTargetX), ["STAGE_Y_TARGET"] = Number(point.ReviewTargetY),
                ["VISION_X_FLIP"] = flip.HasFlag(EN_VISION_FLIP_TYPE.XFlip) ? "ON" : "OFF",
                ["VISION_Y_FLIP"] = flip.HasFlag(EN_VISION_FLIP_TYPE.YFlip) ? "ON" : "OFF",
                ["VISION_XY_FLIP"] = flip.HasFlag(EN_VISION_FLIP_TYPE.XyFlip) ? "ON" : "OFF",
                ["RECV_TARGET_MINUS_HOLE_X"] = measured ? Number(point.ErrorX) : "미검사",
                ["RECV_TARGET_MINUS_HOLE_Y"] = measured ? Number(point.ErrorY) : "미검사",
                ["VISION_FLIP_CONVERT_X"] = measured ? Number(design.X) : "미검사",
                ["VISION_FLIP_CONVERT_Y"] = measured ? Number(design.Y) : "미검사",
                ["RESULT_SOURCE"] = measured ? result.AttemptedShotKeys.Contains(point.ShotKey) ? "MEASURED" : "RETAINED"
                    : error ? "ERROR" : "UNMEASURED",
                ["JUDGE"] = measured ? point.State == EN_REVIEW_POINT_STATE.Ok ? "OK" : "NG" : error ? "ERROR" : "미검사"
            };
        }).ToArray();
        var directory = Path.Combine(_reviewResultRoot, "ROUGH", SanitizeFileName(result.Plan.RecipeId),
            result.SavedAt.ToString("yyyyMMdd", CultureInfo.InvariantCulture));
        var name = result.SavedAt.ToString("yyyyMMdd_HHmmss_fff", CultureInfo.InvariantCulture);
        var path = Path.Combine(directory, name + ".csv");
        var temporary = Path.Combine(directory, $".{Guid.NewGuid():N}.tmp");
        try
        {
            CCsvParser.Write(temporary, headers, rows);
            for (var duplicate = 1; ; duplicate++)
            {
                cancellationToken.ThrowIfCancellationRequested();
                try { System.IO.File.Move(temporary, path, overwrite: false); break; }
                catch (IOException) when (System.IO.File.Exists(path)) { path = Path.Combine(directory, $"{name}_{duplicate}.csv"); }
            }
        }
        finally { if (System.IO.File.Exists(temporary)) System.IO.File.Delete(temporary); }
        var fullPath = Path.GetFullPath(path);
        _lastSavedPath = fullPath;
        return Task.FromResult(fullPath);
    }

    private static string Int(int value) => value.ToString(CultureInfo.InvariantCulture);
    private static string Number(double value) => Math.Round(value, 3, MidpointRounding.AwayFromZero).ToString("0.000", CultureInfo.InvariantCulture);
}
