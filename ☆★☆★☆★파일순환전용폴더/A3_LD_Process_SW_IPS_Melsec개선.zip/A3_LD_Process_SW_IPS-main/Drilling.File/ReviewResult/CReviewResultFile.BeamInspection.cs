using System.Globalization;
using Drilling.Common.Review;
using Drilling.File.Parser;

namespace Drilling.File.ReviewResult;

public sealed partial class CReviewResultFile
{
    public override Task<string> SaveBeamInspection(
        ST_BEAM_INSPECTION_SNAPSHOT result, string glassId, DateTimeOffset savedAt,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (result.Points.Count == 0 || result.Points.Any(p => p.BeamNo is < 1 or > 16))
            throw new InvalidDataException("Beam Inspection 결과에는 1~16번 Beam이 필요합니다.");

        string[] headers = ["GLASS_NAME", "HEAD_NAME", "CELL_NAME", "SHOT_NAME",
            .. Enumerable.Range(1, 16).SelectMany(beam => new[]
            {
                $"BEAM{beam}_X_MM", $"BEAM{beam}_Y_MM", $"BEAM{beam}_JUDGE"
            })];
        var rows = result.Points.GroupBy(p => (p.HeadNo, p.CellNo, p.ShotNo))
            .OrderBy(g => g.Key.HeadNo).ThenBy(g => g.Key.CellNo).ThenBy(g => g.Key.ShotNo)
            .Select(group =>
            {
                var point = group.First();
                var beams = group.ToDictionary(p => p.BeamNo);
                var row = new Dictionary<string, string>
                {
                    ["GLASS_NAME"] = string.IsNullOrWhiteSpace(glassId) ? "UNLINKED" : glassId,
                    ["HEAD_NAME"] = $"HEAD {point.HeadNo:00}",
                    ["CELL_NAME"] = $"CELL {point.CellNo:00}",
                    ["SHOT_NAME"] = CReviewShotNameFormatter.ToMatrixName(point.ShotNo, point.PixelCountX)
                };
                for (var beam = 1; beam <= 16; beam++)
                {
                    beams.TryGetValue(beam, out var measurement);
                    var measured = measurement?.State is EN_REVIEW_POINT_STATE.Ok or EN_REVIEW_POINT_STATE.Ng;
                    // Store the same measured X/Y deviations (mm) shown in the inspection view.
                    row[$"BEAM{beam}_X_MM"] = measured ? FormatDouble(measurement!.ErrorX) : "미검사";
                    row[$"BEAM{beam}_Y_MM"] = measured ? FormatDouble(measurement!.ErrorY) : "미검사";
                    row[$"BEAM{beam}_JUDGE"] = !measured ? "미검사"
                        : measurement!.State == EN_REVIEW_POINT_STATE.Ok ? "OK" : "NG";
                }
                return row;
            }).ToArray();

        var root = Path.Combine(Path.GetDirectoryName(_reviewResultRoot)!, "BeamInspection");
        if (result.IsSimulation) root = Path.Combine(root, "SIM");
        var directory = Path.Combine(root, savedAt.ToString("yyyyMMdd", CultureInfo.InvariantCulture));
        var fileName = $"BeamInspection_{savedAt:HHmmss_fff}";
        var path = Path.Combine(directory, fileName + ".csv");
        var temporaryPath = Path.Combine(directory, $"{Guid.NewGuid():N}.tmp");
        try
        {
            CCsvParser.Write(temporaryPath, headers, rows);
            for (var duplicate = 1; ; duplicate++)
            {
                try
                {
                    System.IO.File.Move(temporaryPath, path);
                    break;
                }
                catch (IOException) when (System.IO.File.Exists(path))
                {
                    path = Path.Combine(directory, $"{fileName}_{duplicate}.csv");
                }
            }
        }
        finally
        {
            if (System.IO.File.Exists(temporaryPath)) System.IO.File.Delete(temporaryPath);
        }
        return Task.FromResult(Path.GetFullPath(path));
    }
}
