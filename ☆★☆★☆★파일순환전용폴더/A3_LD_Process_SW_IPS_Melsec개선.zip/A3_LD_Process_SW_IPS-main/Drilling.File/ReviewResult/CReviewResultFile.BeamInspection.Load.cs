using System.Globalization;
using System.Text;
using Drilling.Common.Review;
using Microsoft.VisualBasic.FileIO;

namespace Drilling.File.ReviewResult;

public sealed partial class CReviewResultFile
{
    private static readonly string[] BeamInspectionHeaders = ["GLASS_NAME", "HEAD_NAME", "CELL_NAME", "SHOT_NAME",
        .. Enumerable.Range(1, 16).SelectMany(beam => new[] { $"BEAM{beam}_X_MM", $"BEAM{beam}_Y_MM", $"BEAM{beam}_JUDGE" })];

    public override Task<ST_BEAM_INSPECTION_RESULT_FILE_DATA?> LoadLastBeamInspection(CancellationToken cancellationToken = default)
        => Task.Run(() => LoadLastBeamInspectionCore(cancellationToken), cancellationToken);

    private ST_BEAM_INSPECTION_RESULT_FILE_DATA? LoadLastBeamInspectionCore(CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var root = Path.Combine(Path.GetDirectoryName(_reviewResultRoot)!, "BeamInspection");
        if (!Directory.Exists(root)) return null;
        FileInfo? latest;
        try
        {
            // Filename suffixes are intentionally unrestricted: old files include completion/GUID suffixes.
            latest = Directory.EnumerateFiles(root, "*.csv", System.IO.SearchOption.AllDirectories)
                .Where(path => Path.GetFileName(path).StartsWith("BeamInspection_", StringComparison.OrdinalIgnoreCase))
                .Select(path => { cancellationToken.ThrowIfCancellationRequested(); return new FileInfo(path); })
                .OrderByDescending(file => file.LastWriteTimeUtc)
                .ThenBy(file => file.FullName, StringComparer.OrdinalIgnoreCase)
                .ThenBy(file => file.FullName, StringComparer.Ordinal)
                .FirstOrDefault();
        }
        catch (Exception exception) when (exception is IOException or UnauthorizedAccessException)
        {
            throw new InvalidDataException($"최근 Beam Inspection 결과를 검색하지 못했습니다.\n경로: {root}\n{exception.Message}", exception);
        }
        if (latest is null) return null;
        cancellationToken.ThrowIfCancellationRequested();
        try
        {
            // TextFieldParser checks row widths and preserves quoted names, including embedded commas/newlines.
            using var parser = new TextFieldParser(latest.FullName, new UTF8Encoding(false, true), detectEncoding: true)
            {
                HasFieldsEnclosedInQuotes = true,
                TrimWhiteSpace = false
            };
            parser.SetDelimiters(",");
            var headers = parser.ReadFields()?.Select(header => header.Trim()).ToArray();
            if (headers is null || headers.Length != BeamInspectionHeaders.Length ||
                headers.Distinct(StringComparer.OrdinalIgnoreCase).Count() != BeamInspectionHeaders.Length ||
                !headers.ToHashSet(StringComparer.OrdinalIgnoreCase).SetEquals(BeamInspectionHeaders))
                throw new InvalidDataException("CSV 헤더에는 GLASS_NAME/HEAD_NAME/CELL_NAME/SHOT_NAME과 1~16번 Beam의 X_MM/Y_MM/JUDGE, 총 52개 열이 필요합니다.");
            var indexes = headers.Select((name, index) => (name, index)).ToDictionary(pair => pair.name, pair => pair.index, StringComparer.OrdinalIgnoreCase);
            var shots = new List<ST_BEAM_INSPECTION_RESULT_SHOT>();
            var identities = new HashSet<(int Head, int Cell, string Shot)>();
            string? glassName = null;
            while (!parser.EndOfData)
            {
                cancellationToken.ThrowIfCancellationRequested();
                var rowNo = parser.LineNumber;
                var fields = parser.ReadFields();
                if (fields is null) break;
                if (fields.Length != BeamInspectionHeaders.Length)
                    throw Error(rowNo, $"열 개수가 {fields.Length}개입니다. 각 Shot 행에는 52개 열이 필요합니다.");
                string Get(string name) => fields[indexes[name]];
                string RequireName(string name)
                {
                    var value = Get(name);
                    if (string.IsNullOrWhiteSpace(value)) throw Error(rowNo, $"{name} 값이 없습니다.");
                    return value;
                }
                var glass = RequireName("GLASS_NAME");
                if (glassName is not null && !glass.Equals(glassName, StringComparison.Ordinal))
                    throw Error(rowNo, "한 결과 파일의 GLASS_NAME은 모두 같아야 합니다.");
                glassName ??= glass;
                var headName = RequireName("HEAD_NAME");
                var cellName = RequireName("CELL_NAME");
                var shotName = RequireName("SHOT_NAME");
                var headNo = ReadNameNumber(headName, "HEAD", rowNo);
                var cellNo = ReadNameNumber(cellName, "CELL", rowNo);
                if (headNo > 8) throw Error(rowNo, "HEAD_NAME의 Head 번호는 1~8이어야 합니다.");
                if (!identities.Add((headNo, cellNo, shotName)))
                    throw Error(rowNo, $"동일한 Head/Cell/Shot이 중복되었습니다. {headName} / {cellName} / {shotName}");
                var beams = new List<ST_BEAM_INSPECTION_RESULT_BEAM>(16);
                for (var beam = 1; beam <= 16; beam++)
                {
                    var x = Get($"BEAM{beam}_X_MM").Trim();
                    var y = Get($"BEAM{beam}_Y_MM").Trim();
                    var judge = Get($"BEAM{beam}_JUDGE").Trim().ToUpperInvariant();
                    if (judge == "미검사")
                    {
                        if (x != "미검사" || y != "미검사")
                            throw Error(rowNo, $"Beam {beam}: 미검사 결과의 X/Y/JUDGE는 모두 '미검사'여야 합니다.");
                        beams.Add(new(beam, null, null, "미검사"));
                    }
                    else if (judge is "OK" or "NG")
                    {
                        beams.Add(new(beam, ReadFinite(x, rowNo, beam, "X_MM"), ReadFinite(y, rowNo, beam, "Y_MM"), judge));
                    }
                    else throw Error(rowNo, $"Beam {beam}: JUDGE는 OK, NG 또는 미검사여야 합니다. 입력: {judge}");
                }
                shots.Add(new(glass, headName, headNo, cellName, cellNo, shotName, beams.AsReadOnly()));
            }
            if (shots.Count == 0) throw new InvalidDataException("CSV에 Shot 결과 행이 없습니다.");
            var relative = Path.GetRelativePath(root, latest.FullName);
            var simulation = relative.Split(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar)
                .Any(part => part.Equals("SIM", StringComparison.OrdinalIgnoreCase));
            return new(latest.FullName, latest.Name, new DateTimeOffset(latest.LastWriteTimeUtc).ToLocalTime(),
                simulation, glassName!, shots.AsReadOnly());
        }
        catch (Exception exception) when (exception is InvalidDataException or IOException or UnauthorizedAccessException or MalformedLineException or DecoderFallbackException)
        {
            // Never skip a damaged newest file and silently present an older run as the latest result.
            throw new InvalidDataException($"최근 Beam Inspection 결과를 불러오지 못했습니다.\n파일: {latest.FullName}\n{exception.Message}", exception);
        }
    }

    private static int ReadNameNumber(string name, string prefix, long rowNo)
    {
        var parts = name.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries);
        if (parts.Length != 2 || !parts[0].Equals(prefix, StringComparison.OrdinalIgnoreCase) ||
            !int.TryParse(parts[1], NumberStyles.None, CultureInfo.InvariantCulture, out var number) || number < 1)
            throw Error(rowNo, $"{prefix}_NAME 형식이 잘못되었습니다. 예: {prefix} 01. 입력: {name}");
        return number;
    }

    private static double ReadFinite(string text, long rowNo, int beam, string name)
    {
        if (!double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out var value) || !double.IsFinite(value))
            throw Error(rowNo, $"Beam {beam}: {name}은 유한한 숫자여야 합니다. 소수점은 '.'을 사용하세요. 입력: {text}");
        return value;
    }

    private static InvalidDataException Error(long rowNo, string detail) => new($"CSV {rowNo}행: {detail}");
}
