using System.Globalization;
using Drilling.Common.Review;
using Drilling.File.Parser;

namespace Drilling.File.ReviewResult;

public sealed partial class CReviewResultFile
{
    public override Task<string> SaveFineCorrection(ST_FINE_REVIEW_RESULT_DATA result, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var snapshot = result.Snapshot;
        if (snapshot.RecipeId != result.Request.Plan.RecipeId || snapshot.Lines.Count == 0)
            throw new InvalidDataException("FINE 검사 결과 대상 또는 레시피가 올바르지 않습니다.");
        var status = snapshot.State switch
        {
            EN_REVIEW_SEQUENCE_STATE.Completed => "COMPLETED",
            EN_REVIEW_SEQUENCE_STATE.Stopped => snapshot.IsNgPause ? "NG_PAUSED" : "STOPPED",
            EN_REVIEW_SEQUENCE_STATE.Failed => "FAILED",
            _ => throw new InvalidDataException("FINE 검사 종료 상태가 아닙니다.")
        };
        string[] headers = ["SAVED_AT", "RECIPE_ID", "GLASS_ID", "ORIGIN", "METHOD", "IMMEDIATE_RETRY", "RETRY_LIMIT", "CAPTURE_ATTEMPT", "RUN_TYPE", "START_LINE", "RESULT_STATUS", "RESULT_MESSAGE",
            "STAGE_SIMULATION", "VISION_SIMULATION", "INSPECTION_LINE", "MODEL_NO", "DIRECTION", "LINE_STATE",
            "HEAD_NO", "CELL_NO", "SHOT_NAME", "SHOT_KEY", "BEAM_NO", "LINE_NO", "INDEX_X", "INDEX_Y",
            "DESIGN_X", "DESIGN_Y", "REVIEW_X_TARGET", "STAGE_Y_TARGET", "VISION_X_FLIP", "VISION_Y_FLIP", "VISION_XY_FLIP",
            "RECV_TARGET_MINUS_HOLE_X", "RECV_TARGET_MINUS_HOLE_Y", "VISION_FLIP_CONVERT_X", "VISION_FLIP_CONVERT_Y", "RESULT_SOURCE", "JUDGE"];
        var plan = result.Request.Plan;
        var rows = snapshot.Lines.SelectMany(line => line.Points.Select(point =>
        {
            var measured = point.State is EN_REVIEW_POINT_STATE.Ok or EN_REVIEW_POINT_STATE.Ng;
            var converted = CReviewCoordinateTransformer.VisionErrorToStageOffset(point.ErrorX, point.ErrorY, plan.VisionFlipType);
            var indexX = (point.ShotNo - 1) % Math.Max(1, point.PixelCountX) + 1;
            var indexY = (point.ShotNo - 1) / Math.Max(1, point.PixelCountX) + 1;
            return (IReadOnlyDictionary<string, string>)new Dictionary<string, string>
            {
                ["SAVED_AT"] = FormatDate(result.SavedAt), ["RECIPE_ID"] = snapshot.RecipeId,
                ["GLASS_ID"] = result.Request.Context?.GlassId ?? "-", ["ORIGIN"] = result.Request.Context?.Origin ?? "MANUAL FINE",
                ["METHOD"] = result.Request.Method == EN_FINE_INSPECTION_METHOD.Flying ? "FLYING" : "P2P",
                ["IMMEDIATE_RETRY"] = result.Request.ImmediateRetry ? "ON" : "OFF", ["RETRY_LIMIT"] = Int(result.Request.CountMismatchRetries),
                ["CAPTURE_ATTEMPT"] = Int(result.CaptureAttempts.GetValueOrDefault(point.ShotKey)),
                ["RUN_TYPE"] = result.Request.IsResume ? "RESUME_NG" : "INITIAL", ["START_LINE"] = Int(result.Request.StartLineNo),
                ["RESULT_STATUS"] = status, ["RESULT_MESSAGE"] = snapshot.Message, ["STAGE_SIMULATION"] = "ON",
                ["VISION_SIMULATION"] = result.IsVisionSimulation ? "ON" : "OFF", ["INSPECTION_LINE"] = Int(line.Number),
                ["MODEL_NO"] = Int(line.ModelNo), ["DIRECTION"] = line.Points[0].ReviewTargetX <= line.Points[^1].ReviewTargetX ? "X+" : "X-",
                ["LINE_STATE"] = line.State.ToString().ToUpperInvariant(), ["HEAD_NO"] = Int(point.HeadNo), ["CELL_NO"] = Int(point.CellNo),
                ["SHOT_NAME"] = CReviewShotNameFormatter.ToMatrixName(point.ShotNo, point.PixelCountX), ["SHOT_KEY"] = point.ShotKey,
                ["BEAM_NO"] = Int(point.BeamNo), ["LINE_NO"] = Int(indexY), ["INDEX_X"] = Int(indexX), ["INDEX_Y"] = Int(indexY),
                ["DESIGN_X"] = Number(point.DesignX), ["DESIGN_Y"] = Number(point.DesignY),
                ["REVIEW_X_TARGET"] = Number(point.ReviewTargetX), ["STAGE_Y_TARGET"] = Number(point.ReviewTargetY),
                ["VISION_X_FLIP"] = plan.VisionFlipType.HasFlag(EN_VISION_FLIP_TYPE.XFlip) ? "ON" : "OFF",
                ["VISION_Y_FLIP"] = plan.VisionFlipType.HasFlag(EN_VISION_FLIP_TYPE.YFlip) ? "ON" : "OFF",
                ["VISION_XY_FLIP"] = plan.VisionFlipType.HasFlag(EN_VISION_FLIP_TYPE.XyFlip) ? "ON" : "OFF",
                ["RECV_TARGET_MINUS_HOLE_X"] = measured ? Number(point.ErrorX) : "미검사",
                ["RECV_TARGET_MINUS_HOLE_Y"] = measured ? Number(point.ErrorY) : "미검사",
                ["VISION_FLIP_CONVERT_X"] = measured ? Number(converted.X) : "미검사",
                ["VISION_FLIP_CONVERT_Y"] = measured ? Number(converted.Y) : "미검사",
                ["RESULT_SOURCE"] = measured ? result.AttemptedShotKeys.Contains(point.ShotKey) ? "MEASURED" : "RETAINED" : point.Judge == "ERROR" ? "ERROR" : "UNMEASURED",
                ["JUDGE"] = measured ? point.State == EN_REVIEW_POINT_STATE.Ok ? "OK" : "NG" : point.Judge == "ERROR" ? "ERROR" : "미검사"
            };
        })).ToArray();
        var directory = Path.Combine(_reviewResultRoot, "FINE", SanitizeFileName(plan.RecipeId), result.SavedAt.ToString("yyyyMMdd", CultureInfo.InvariantCulture));
        var name = result.SavedAt.ToString("yyyyMMdd_HHmmss_fff", CultureInfo.InvariantCulture);
        var path = Path.Combine(directory, name + ".csv");
        var temporary = Path.Combine(directory, $".{Guid.NewGuid():N}.tmp");
        try
        {
            CCsvParser.Write(temporary, headers, rows);
            for (var duplicate = 1; ; duplicate++)
            {
                cancellationToken.ThrowIfCancellationRequested();
                try { System.IO.File.Move(temporary, path, overwrite: false); break; }
                catch (IOException) when (System.IO.File.Exists(path)) { path = Path.Combine(directory, $"{name}_{duplicate}.csv"); }
            }
        }
        finally { if (System.IO.File.Exists(temporary)) System.IO.File.Delete(temporary); }
        _lastSavedPath = Path.GetFullPath(path);
        return Task.FromResult(_lastSavedPath);
    }
}
