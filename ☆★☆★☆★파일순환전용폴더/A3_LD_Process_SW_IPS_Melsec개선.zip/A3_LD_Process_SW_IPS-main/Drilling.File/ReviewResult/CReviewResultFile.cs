using System.Globalization;
using Drilling.Common.Review;
using Drilling.File.Parser;

namespace Drilling.File.ReviewResult;

public sealed partial class CReviewResultFile(string configRoot) : CReviewResultFileBase
{
    private static readonly IReadOnlyList<IReadOnlyList<string>> RequiredHeaderGroups =
    [
        ["SAVED_AT"],
        ["RECIPE_ID"],
        ["SHOT_KEY", "HOLE_KEY"],
        ["HEAD_NO"],
        ["CELL_NO"],
        ["ERROR_X"],
        ["ERROR_Y"],
        ["JUDGE"]
    ];

    private static readonly IReadOnlyList<string> Headers =
    [
        "SAVED_AT",
        "GLASS_ID",
        "RECIPE_ID",
        "INSPECTION_METHOD",
        "RESULT_STATUS",
        "TOTAL_COUNT",
        "RULE",
        "RULE_SCOPE",
        "BEAM_NO",
        "REFERENCE_CELL_NO",
        "REFERENCE_SHOT",
        "ROUGH_REFERENCE",
        "FINE_LINE_COUNT",
        "RESULT_SOURCE",
        "SHOT_NAME",
        "ROW",
        "COLUMN",
        "DESIGN_X",
        "DESIGN_Y",
        "SHOT_KEY",
        "HEAD_NO",
        "CELL_NO",
        "ERROR_X",
        "ERROR_Y",
        "JUDGE"
    ];

    private readonly string _reviewResultRoot = Path.Combine(
        Directory.GetParent(configRoot)?.FullName ?? configRoot,
        "Data",
        "ReviewResult");
    private readonly string _legacyReviewResultRoot = Path.Combine(
        Directory.GetParent(configRoot)?.FullName ?? configRoot,
        "Data",
        "Result");
    private string? _lastSavedPath;

    public override string RootPath => _reviewResultRoot;

    public override IReadOnlyList<string> SearchRootPaths =>
        [_reviewResultRoot, _legacyReviewResultRoot];

    public override string? LastSavedPath => _lastSavedPath;

    public override Task<ST_REVIEW_RESULT_FILE_DATA> Load(
        string path,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();

        CCsvParser.ValidateRequiredHeaders(
            path,
            "Review Result",
            RequiredHeaderGroups);

        var sourceRows = CCsvParser.Read(path);
        if (sourceRows.Count == 0)
        {
            throw new InvalidDataException("Review Result validation failed. Result row is empty.");
        }

        var rows = sourceRows
            .Select((row, index) => ToResultRow(row, index + 2))
            .ToArray();
        var recipeIds = rows
            .Select(row => row.RecipeId)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToArray();

        if (recipeIds.Length != 1)
        {
            throw new InvalidDataException(
                "Review Result validation failed. All rows must have the same RECIPE_ID.");
        }

        var fullPath = Path.GetFullPath(path);
        var metadataRow = sourceRows[0];
        return Task.FromResult(new ST_REVIEW_RESULT_FILE_DATA(
            fullPath,
            Path.GetFileName(fullPath),
            recipeIds[0],
            rows.Max(row => row.SavedAt),
            rows)
        {
            GlassId = CCsvParser.Get(metadataRow, "GLASS_ID"),
            InspectionMethod = CCsvParser.Get(metadataRow, "INSPECTION_METHOD"),
            ResultStatus = NormalizeResultStatus(CCsvParser.Get(metadataRow, "RESULT_STATUS")),
            TotalCount = ReadOptionalInt(metadataRow, "TOTAL_COUNT", rows.Length),
            Rule = CCsvParser.Get(metadataRow, "RULE"),
            RuleScope = CCsvParser.Get(metadataRow, "RULE_SCOPE"),
            BeamNo = ReadOptionalInt(metadataRow, "BEAM_NO", 1),
            ReferenceCellNo = ReadOptionalNullableInt(metadataRow, "REFERENCE_CELL_NO"),
            ReferenceShot = CCsvParser.Get(metadataRow, "REFERENCE_SHOT"),
            RoughReference = CCsvParser.Get(metadataRow, "ROUGH_REFERENCE"),
            FineLineCount = ReadOptionalInt(metadataRow, "FINE_LINE_COUNT", 0)
        });
    }

    public override Task Save(
        ST_REVIEW_RESULT_DATA result,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();

        var sourceRows = result.Results.Count > 0
            ? result.Results
            : result.Plan.ReviewPoints;
        var rows = new List<ST_REVIEW_PLAN_POINT>();
        foreach (var point in sourceRows)
        {
            if (point.Use &&
                point.State is EN_REVIEW_POINT_STATE.Ok or EN_REVIEW_POINT_STATE.Ng)
            {
                rows.Add(point);
            }
        }

        if (rows.Count == 0)
        {
            throw new InvalidDataException("Review Result save failed. There are no measured Shots.");
        }

        var metadata = CreateMetadata(result);

        _lastSavedPath = null;
        var resultPath = string.IsNullOrWhiteSpace(result.TargetFilePath)
            ? GetResultPath(result, metadata)
            : Path.GetFullPath(result.TargetFilePath);
        CCsvParser.Write(
            resultPath,
            Headers,
            rows.Select(point => ToRow(result, point, metadata)));
        _lastSavedPath = Path.GetFullPath(resultPath);

        return Task.CompletedTask;
    }

    private static ST_REVIEW_RESULT_FILE_ROW ToResultRow(
        IReadOnlyDictionary<string, string> row,
        int rowNo)
    {
        var savedAtText = CCsvParser.RequireText(
            row,
            "Review Result",
            rowNo,
            "SAVED_AT");
        if (!DateTimeOffset.TryParse(
                savedAtText,
                CultureInfo.InvariantCulture,
                DateTimeStyles.AssumeLocal,
                out var savedAt))
        {
            throw new InvalidDataException(
                $"Review Result validation failed. Row {rowNo} / SAVED_AT must be a date and time.");
        }

        var recipeId = CCsvParser.RequireText(
            row,
            "Review Result",
            rowNo,
            "RECIPE_ID");
        var sourceShotKey = CCsvParser.RequireText(
            row,
            "Review Result",
            rowNo,
            "SHOT_KEY",
            "HOLE_KEY");
        var shotName = CCsvParser.Get(row, "SHOT_NAME");
        var normalizedShotKey = CReviewManager.NormalizeShotKey(sourceShotKey);
        var shotKey = string.IsNullOrWhiteSpace(normalizedShotKey)
            ? sourceShotKey
            : normalizedShotKey;
        var headNo = CCsvParser.ReadRequiredInt(
            CCsvParser.Get(row, "HEAD_NO"),
            "Review Result",
            rowNo,
            "HEAD_NO");
        var cellNo = CCsvParser.ReadRequiredInt(
            CCsvParser.Get(row, "CELL_NO"),
            "Review Result",
            rowNo,
            "CELL_NO");
        var errorX = CCsvParser.ReadDouble(
            CCsvParser.Get(row, "ERROR_X"),
            "Review Result",
            rowNo,
            "ERROR_X",
            0.0);
        var errorY = CCsvParser.ReadDouble(
            CCsvParser.Get(row, "ERROR_Y"),
            "Review Result",
            rowNo,
            "ERROR_Y",
            0.0);
        var judge = CCsvParser.RequireText(
            row,
            "Review Result",
            rowNo,
            "JUDGE").ToUpperInvariant();

        return new ST_REVIEW_RESULT_FILE_ROW(
            savedAt,
            recipeId,
            shotKey,
            shotName,
            headNo,
            cellNo,
            errorX,
            errorY,
            judge);
    }

    private string GetResultPath(
        ST_REVIEW_RESULT_DATA result,
        ST_REVIEW_RESULT_METADATA metadata)
    {
        var savedAt = result.SavedAt;
        var glassId = SanitizeFileName(result.GlassId);
        var fileName = CreateResultFileName(metadata, savedAt);

        return Path.Combine(
            _reviewResultRoot,
            savedAt.ToString("yyyyMMdd", CultureInfo.InvariantCulture),
            glassId,
            NormalizeInspectionMethod(result.InspectionMethod),
            fileName);
    }

    private static IReadOnlyDictionary<string, string> ToRow(
        ST_REVIEW_RESULT_DATA result,
        ST_REVIEW_PLAN_POINT point,
        ST_REVIEW_RESULT_METADATA metadata)
    {
        var plan = result.Plan;
        var columnCount = Math.Max(1, point.PixelCountX);
        var zeroBasedShotNo = Math.Max(0, point.ShotNo - 1);
        var rowNo = (zeroBasedShotNo / columnCount) + 1;
        var columnNo = (zeroBasedShotNo % columnCount) + 1;
        var shotName = FormatShotName(point);
        return new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            ["SAVED_AT"] = FormatDate(result.SavedAt),
            ["GLASS_ID"] = result.GlassId,
            ["RECIPE_ID"] = plan.RecipeId,
            ["INSPECTION_METHOD"] = result.InspectionMethod,
            ["RESULT_STATUS"] = NormalizeResultStatus(result.ResultStatus),
            ["TOTAL_COUNT"] = Math.Max(result.TotalCount, plan.ReviewPoints.Count).ToString(CultureInfo.InvariantCulture),
            ["RULE"] = metadata.Rule,
            ["RULE_SCOPE"] = metadata.RuleScope,
            ["BEAM_NO"] = metadata.BeamNo.ToString(CultureInfo.InvariantCulture),
            ["REFERENCE_CELL_NO"] = metadata.ReferenceCellNo?.ToString(CultureInfo.InvariantCulture) ?? "",
            ["REFERENCE_SHOT"] = metadata.ReferenceShot,
            ["ROUGH_REFERENCE"] = metadata.RoughReference,
            ["FINE_LINE_COUNT"] = metadata.FineLineCount > 0
                ? metadata.FineLineCount.ToString(CultureInfo.InvariantCulture)
                : "",
            ["RESULT_SOURCE"] = "MEASURED",
            ["SHOT_NAME"] = shotName,
            ["ROW"] = rowNo.ToString(CultureInfo.InvariantCulture),
            ["COLUMN"] = columnNo.ToString(CultureInfo.InvariantCulture),
            ["DESIGN_X"] = FormatDouble(point.DesignX),
            ["DESIGN_Y"] = FormatDouble(point.DesignY),
            ["SHOT_KEY"] = $"CELL{point.CellNo}_{shotName}",
            ["HEAD_NO"] = point.HeadNo.ToString(CultureInfo.InvariantCulture),
            ["CELL_NO"] = point.CellNo.ToString(CultureInfo.InvariantCulture),
            ["ERROR_X"] = FormatDouble(point.ErrorX),
            ["ERROR_Y"] = FormatDouble(point.ErrorY),
            ["JUDGE"] = point.Judge
        };
    }

    private static ST_REVIEW_RESULT_METADATA CreateMetadata(ST_REVIEW_RESULT_DATA result)
    {
        var projection = result.Plan.CorrectionPlan;
        var rule = projection?.Rule.ToString().ToUpperInvariant() ?? "ALL";
        var ruleScope = projection is null
            ? ""
            : projection.Scope == EN_REVIEW_CORRECTION_SCOPE.HeadCell
                ? "HEAD_CELL"
                : "HEAD";

        ST_REVIEW_PLAN_POINT? referencePoint = null;
        foreach (var point in result.Plan.ReviewPoints)
        {
            referencePoint ??= point;
            if (point.State is EN_REVIEW_POINT_STATE.Ok or EN_REVIEW_POINT_STATE.Ng)
            {
                referencePoint = point;
                break;
            }
        }

        ST_REVIEW_PLAN_POINT? beamPoint = referencePoint;
        if (beamPoint is null && result.Results.Count > 0)
        {
            beamPoint = result.Results[0];
        }

        var isSimple = projection?.Rule == EN_REVIEW_CORRECTION_RULE.Simple;
        var isRough = projection?.Rule == EN_REVIEW_CORRECTION_RULE.Rough;
        var isFine = projection?.Rule == EN_REVIEW_CORRECTION_RULE.Fine;
        return new ST_REVIEW_RESULT_METADATA(
            rule,
            ruleScope,
            beamPoint?.BeamNo ?? 1,
            isSimple ? referencePoint?.CellNo : null,
            isSimple ? FormatShotName(referencePoint) : "",
            isRough ? projection!.RoughReference.ToString().ToUpperInvariant() : "",
            isFine ? projection!.FineLineCount : 0);
    }

    private static string FormatShotName(ST_REVIEW_PLAN_POINT? point)
    {
        return point is null
            ? ""
            : CReviewShotNameFormatter.ToMatrixName(point.ShotNo, point.PixelCountX);
    }

    private static string CreateResultFileName(
        ST_REVIEW_RESULT_METADATA metadata,
        DateTimeOffset savedAt)
    {
        var detail = metadata.Rule switch
        {
            "SIMPLE" => $"SIMPLE_Cell{metadata.ReferenceCellNo?.ToString(CultureInfo.InvariantCulture) ?? ""}_{metadata.ReferenceShot}",
            "ROUGH" => $"ROUGH_{metadata.RuleScope}_{metadata.RoughReference}",
            "FINE" => $"FINE_{metadata.FineLineCount.ToString(CultureInfo.InvariantCulture)}LINE",
            "EDGE" => "EDGE",
            _ => "ALL"
        };

        return $"ReviewResult_{SanitizeFileName(detail)}_{savedAt:HHmmss}.csv";
    }

    private static int ReadOptionalInt(
        IReadOnlyDictionary<string, string> row,
        string name,
        int defaultValue)
    {
        return int.TryParse(
            CCsvParser.Get(row, name),
            NumberStyles.Integer,
            CultureInfo.InvariantCulture,
            out var value)
            ? value
            : defaultValue;
    }

    private static string NormalizeResultStatus(string? resultStatus)
    {
        return resultStatus?.Trim().Equals("IN_PROGRESS", StringComparison.OrdinalIgnoreCase) == true
            ? "IN_PROGRESS"
            : "COMPLETED";
    }

    private static string NormalizeInspectionMethod(string? inspectionMethod)
    {
        return inspectionMethod?.Trim().Equals("IOF", StringComparison.OrdinalIgnoreCase) == true
            ? "IOF"
            : "P2P";
    }

    private static int? ReadOptionalNullableInt(
        IReadOnlyDictionary<string, string> row,
        string name)
    {
        return int.TryParse(
            CCsvParser.Get(row, name),
            NumberStyles.Integer,
            CultureInfo.InvariantCulture,
            out var value)
            ? value
            : null;
    }

    private static string FormatDate(DateTimeOffset? value)
    {
        return value?.ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture) ?? "";
    }

    private static string FormatDouble(double value)
    {
        return value.ToString("0.000000", CultureInfo.InvariantCulture);
    }

    private static string SanitizeFileName(string value)
    {
        var invalidChars = Path.GetInvalidFileNameChars();
        var sanitized = new string(value
            .Select(character => invalidChars.Contains(character) ? '_' : character)
            .ToArray());

        return string.IsNullOrWhiteSpace(sanitized) ? "UNLINKED" : sanitized;
    }

    private sealed record ST_REVIEW_RESULT_METADATA(
        string Rule,
        string RuleScope,
        int BeamNo,
        int? ReferenceCellNo,
        string ReferenceShot,
        string RoughReference,
        int FineLineCount);
}
