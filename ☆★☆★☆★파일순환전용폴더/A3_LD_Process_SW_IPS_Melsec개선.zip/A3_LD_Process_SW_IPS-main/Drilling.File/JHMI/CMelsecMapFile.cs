using System.Globalization;
using Drilling.Common.Interface;
using Drilling.File.Parser;

namespace Drilling.File.JHMI;
public sealed partial class CMelsecMapFile(string configRoot) : CMelsecMapFileBase
{
    private const string TableName = "JHMI_MELSEC_MAP";
    private static readonly IReadOnlyList<string> Headers = ["ID", "USE", "GROUP", "NAME", "DEVICE NO", "ADDRESS", "DATA TYPE", "DIRECTION", "ACCESS", "READ_SCALE", "WRITE_SCALE", "LENGTH", "POLL_MS", "DESCRIPTION"];
    // Startup structure checks and runtime loading must use the same map schema.
    internal static readonly IReadOnlyList<IReadOnlyList<string>> RequiredHeaderGroups = [["ID"], ["USE"], ["GROUP"], ["NAME"], ["DEVICE NO", "DEV NO", "NUMBER"], ["ADDRESS"], ["DATA TYPE", "DATATYPE", "TYPE"], ["DIRECTION", "DIR"], ["ACCESS"], ["READ_SCALE", "SCALE"], ["WRITE_SCALE", "SCALE"], ["LENGTH", "SIZE"], ["POLL_MS", "POLL MS", "POLL"]];
    public override IReadOnlyList<ST_MELSEC_MAP_DATA> LoadAll(CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        EnsureFile();
        CCsvParser.ValidateRequiredHeaders(GetMapPath(), TableName, RequiredHeaderGroups);
        global::Drilling.Common.Interface.ST_MELSEC_MAP_DATA SelectValue(global::System.Collections.Generic.IReadOnlyDictionary<string, string> row, int index)
        {
            return Parse(row, index + 2);
        }

        bool HasId(global::Drilling.Common.Interface.ST_MELSEC_MAP_DATA data)
        {
            return !string.IsNullOrWhiteSpace(data.Id);
        }

        string SelectGroup(global::Drilling.Common.Interface.ST_MELSEC_MAP_DATA data)
        {
            return data.Group;
        }

        int SelectDeviceNo(global::Drilling.Common.Interface.ST_MELSEC_MAP_DATA data)
        {
            return data.DeviceNo;
        }

        string SelectId(global::Drilling.Common.Interface.ST_MELSEC_MAP_DATA data)
        {
            return data.Id;
        }

        var rows = CCsvParser.Read(GetMapPath()).Select(SelectValue).Where(HasId).OrderBy(SelectGroup, StringComparer.OrdinalIgnoreCase).ThenBy(SelectDeviceNo).ThenBy(SelectId, StringComparer.OrdinalIgnoreCase).ToArray();
        Validate(rows);
        return rows;
    }

    private ST_MELSEC_MAP_DATA Parse(IReadOnlyDictionary<string, string> row, int rowNo)
    {
        double readScale, writeScale;
        if (row.ContainsKey("READ_SCALE") || row.ContainsKey("WRITE_SCALE"))
        {
            readScale = ReadDouble(RequireText(row, rowNo, "READ_SCALE"), rowNo, "READ_SCALE", 1);
            writeScale = ReadDouble(RequireText(row, rowNo, "WRITE_SCALE"), rowNo, "WRITE_SCALE", 1);
        }
        else
        {
            // Legacy maps divided by SCALE when writing. Keep their behavior without rewriting the file.
            readScale = ReadDouble(ReadFirst(row, "SCALE"), rowNo, "SCALE", 1);
            if (Math.Abs(readScale) < double.Epsilon) readScale = 1;
            writeScale = 1 / readScale;
        }
        if (!double.IsFinite(readScale) || readScale == 0 || !double.IsFinite(writeScale) || writeScale == 0)
            throw new InvalidDataException($"{TableName} validation failed. Row {rowNo} / READ_SCALE and WRITE_SCALE must be finite and nonzero.");
        return new ST_MELSEC_MAP_DATA(NormalizeId(RequireText(row, rowNo, "ID")), ReadBool(ReadFirst(row, "USE"), true), NormalizeGroup(RequireText(row, rowNo, "GROUP")), ReadFirst(row, "NAME"), ReadInt(ReadFirst(row, "DEVICE NO"), rowNo, "DEVICE NO", 0), NormalizeAddress(RequireText(row, rowNo, "ADDRESS")), ReadDataType(RequireText(row, rowNo, "DATA TYPE", "DATATYPE", "TYPE"), rowNo), ReadDirection(RequireText(row, rowNo, "DIRECTION", "DIR"), rowNo), ReadAccess(RequireText(row, rowNo, "ACCESS"), rowNo), readScale, writeScale, ReadInt(ReadFirst(row, "LENGTH"), rowNo, "LENGTH", 1), ReadInt(ReadFirst(row, "POLL_MS"), rowNo, "POLL_MS", 0), ReadFirst(row, "DESCRIPTION"));
    }

    private void EnsureFile()
    {
        var path = GetMapPath();
        if (System.IO.File.Exists(path))
        {
            return;
        }

        CCsvParser.Write(path, Headers, CreateHandshakeRows()
            .Concat(CreateMotorStatusRows())
            .Concat(CreateUnassignedLegacyRows()).ToArray());
    }

    private string GetMapPath()
    {
        return Path.Combine(configRoot, "JHMI_MELSEC_MAP.csv");
    }

    private static void Validate(IReadOnlyList<ST_MELSEC_MAP_DATA> rows)
    {
        var usedIds = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        bool IsUse(global::Drilling.Common.Interface.ST_MELSEC_MAP_DATA row)
        {
            return row.Use;
        }

        foreach (var row in rows.Where(IsUse))
        {
            if (string.IsNullOrWhiteSpace(row.Id))
            {
                throw new InvalidDataException($"{TableName} validation failed. ID cannot be empty.");
            }

            if (!usedIds.Add(row.Id))
            {
                throw new InvalidDataException($"{TableName} validation failed. Duplicated ID: {row.Id}");
            }

            if (row.DeviceNo < 0)
            {
                throw new InvalidDataException($"{TableName} validation failed. DEVICE NO cannot be negative: {row.Id}");
            }

            if (string.IsNullOrWhiteSpace(row.Address))
            {
                throw new InvalidDataException($"{TableName} validation failed. ADDRESS cannot be empty: {row.Id}");
            }

            if (row.Length <= 0)
            {
                throw new InvalidDataException($"{TableName} validation failed. LENGTH must be positive: {row.Id}");
            }

            if (row.PollMs < 0)
            {
                throw new InvalidDataException($"{TableName} validation failed. POLL_MS cannot be negative: {row.Id}");
            }

            if (row.DataType == EN_MELSEC_DATA_TYPE.Bit && row.Length != 1)
            {
                throw new InvalidDataException($"{TableName} validation failed. BIT LENGTH must be 1: {row.Id}");
            }
        }
    }

    private static IReadOnlyDictionary<string, string> Row(string id, string group, string name, int deviceNo, string address, string dataType, string direction, string access, string readScale, string writeScale, string length, string pollMs, string description, bool use = true)
    {
        return new Dictionary<string, string>
        {
            ["ID"] = id,
            ["USE"] = use ? "1" : "0",
            ["GROUP"] = group,
            ["NAME"] = name,
            ["DEVICE NO"] = deviceNo.ToString(CultureInfo.InvariantCulture),
            ["ADDRESS"] = address,
            ["DATA TYPE"] = dataType,
            ["DIRECTION"] = direction,
            ["ACCESS"] = access,
            ["READ_SCALE"] = readScale,
            ["WRITE_SCALE"] = writeScale,
            ["LENGTH"] = length,
            ["POLL_MS"] = pollMs,
            ["DESCRIPTION"] = description
        };
    }

    private static EN_MELSEC_DATA_TYPE ReadDataType(string value, int rowNo)
    {
        return NormalizeText(value) switch
        {
            "BIT" => EN_MELSEC_DATA_TYPE.Bit,
            "WORD" => EN_MELSEC_DATA_TYPE.Word,
            "DWORD" or "D_WORD" or "DOUBLEWORD" => EN_MELSEC_DATA_TYPE.DWord,
            "DOUBLE" or "REAL64" => EN_MELSEC_DATA_TYPE.Double,
            "FLOAT" or "REAL32" => EN_MELSEC_DATA_TYPE.Float,
            "STRING" or "TEXT" => EN_MELSEC_DATA_TYPE.String,
            _ => throw new InvalidDataException($"{TableName} validation failed. Row {rowNo} / DATA TYPE is invalid: {value}")};
    }

    private static EN_MELSEC_DIRECTION ReadDirection(string value, int rowNo)
    {
        return NormalizeText(value) switch
        {
            "IN" or "INPUT" => EN_MELSEC_DIRECTION.In,
            "OUT" or "OUTPUT" => EN_MELSEC_DIRECTION.Out,
            "INOUT" or "IN_OUT" or "BOTH" => EN_MELSEC_DIRECTION.InOut,
            _ => throw new InvalidDataException($"{TableName} validation failed. Row {rowNo} / DIRECTION is invalid: {value}")};
    }

    private static EN_MELSEC_ACCESS ReadAccess(string value, int rowNo)
    {
        return NormalizeText(value) switch
        {
            "R" or "READ" => EN_MELSEC_ACCESS.Read,
            "W" or "WRITE" => EN_MELSEC_ACCESS.Write,
            "RW" or "R/W" or "READWRITE" or "READ_WRITE" => EN_MELSEC_ACCESS.ReadWrite,
            _ => throw new InvalidDataException($"{TableName} validation failed. Row {rowNo} / ACCESS is invalid: {value}")};
    }

    private static string RequireText(IReadOnlyDictionary<string, string> row, int rowNo, params string[] names)
    {
        return CCsvParser.RequireText(row, TableName, rowNo, names);
    }

    private static string ReadFirst(IReadOnlyDictionary<string, string> row, params string[] names)
    {
        return CCsvParser.GetFirst(row, names);
    }

    private static bool ReadBool(string value, bool defaultValue)
    {
        return CCsvParser.ReadBool(value, defaultValue);
    }

    private static int ReadInt(string value, int rowNo, string fieldName, int defaultValue)
    {
        return CCsvParser.ReadInt(value, TableName, rowNo, fieldName, defaultValue);
    }

    private static double ReadDouble(string value, int rowNo, string fieldName, double defaultValue)
    {
        return CCsvParser.ReadDouble(value, TableName, rowNo, fieldName, defaultValue);
    }

    private static string NormalizeId(string value)
    {
        return value.Trim().ToUpperInvariant();
    }

    private static string NormalizeGroup(string value)
    {
        return value.Trim().ToUpperInvariant();
    }

    private static string NormalizeAddress(string value)
    {
        return value.Trim().ToUpperInvariant();
    }

    private static string NormalizeText(string value)
    {
        return value.Trim().ToUpperInvariant().Replace(" ", "", StringComparison.OrdinalIgnoreCase).Replace("-", "_", StringComparison.OrdinalIgnoreCase);
    }
}
