﻿using System.Globalization;
using Drilling.Common.Review;
using Drilling.File.Parser;

namespace Drilling.File.Review;

public sealed class CReviewSettingFile(string configRoot) : CReviewSettingFileBase
{
    private const string Extension = ".review";
    private static readonly IReadOnlyList<string> Headers = ["NAME", "VALUE"];
    private readonly string _rootDirectory = Path.Combine(configRoot, "ReviewSetting");

    public override Task<IReadOnlyList<string>> List(
        string recipeId,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var directory = GetRecipeDirectory(recipeId);
        if (!Directory.Exists(directory))
        {
            return Task.FromResult<IReadOnlyList<string>>([]);
        }

        var names = new List<string>();
        foreach (var path in Directory.EnumerateFiles(directory, $"*{Extension}"))
        {
            var name = Path.GetFileName(path);
            if (!string.IsNullOrWhiteSpace(name))
            {
                names.Add(name);
            }
        }

        names.Sort(StringComparer.OrdinalIgnoreCase);
        return Task.FromResult<IReadOnlyList<string>>(names.ToArray());
    }

    public override Task<ST_REVIEW_SETTING_PROFILE> Load(
        string recipeId,
        string settingName,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var path = GetSettingPath(recipeId, settingName);
        if (!System.IO.File.Exists(path))
        {
            throw new FileNotFoundException($"Review setting file was not found: {NormalizeSettingName(settingName)}", path);
        }

        var values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var row in CCsvParser.Read(path))
        {
            var name = CCsvParser.Get(row, "NAME").Trim();
            if (!string.IsNullOrWhiteSpace(name))
            {
                values[name] = CCsvParser.Get(row, "VALUE").Trim();
            }
        }

        var profile = new ST_REVIEW_SETTING_PROFILE(
            Read(values, "RECIPE_ID", recipeId),
            NormalizeRule(Read(values, "RULE", "ROUGH")),
            NormalizeScope(Read(values, "SCOPE", "HEAD")),
            NormalizeRoughReference(Read(values, "ROUGH_REFERENCE", "FIRST")),
            ReadFineLineCount(values),
            Math.Max(1, ReadInt(values, "BEAM_NO", 1)),
            NormalizeInspectionMethod(Read(values, "INSPECTION_METHOD", "P2P")),
            Read(values, "SIMPLE_SHOT", Read(values, "SIMPLE_SHOT_KEY", "")));
        return Task.FromResult(profile);
    }

    public override Task Save(
        string recipeId,
        string settingName,
        ST_REVIEW_SETTING_PROFILE profile,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var normalizedRecipeId = NormalizeRecipeId(recipeId);
        var normalizedProfile = profile with
        {
            RecipeId = normalizedRecipeId,
            Rule = NormalizeRule(profile.Rule),
            Scope = NormalizeScope(profile.Scope),
            RoughReference = NormalizeRoughReference(profile.RoughReference),
            FineLineCount = NormalizeFineLineCount(profile.FineLineCount),
            BeamNo = Math.Max(1, profile.BeamNo),
            InspectionMethod = NormalizeInspectionMethod(profile.InspectionMethod),
            SimpleShot = profile.SimpleShot?.Trim() ?? ""
        };

        var rows = new List<IReadOnlyDictionary<string, string>>
        {
            Row("RECIPE_ID", normalizedProfile.RecipeId),
            Row("RULE", normalizedProfile.Rule),
            Row("SCOPE", normalizedProfile.Scope),
            Row("ROUGH_REFERENCE", normalizedProfile.RoughReference),
            Row("FINE_LINE_COUNT", normalizedProfile.FineLineCount.ToString(CultureInfo.InvariantCulture)),
            Row("BEAM_NO", normalizedProfile.BeamNo.ToString(CultureInfo.InvariantCulture)),
            Row("INSPECTION_METHOD", normalizedProfile.InspectionMethod),
            Row("SIMPLE_SHOT", normalizedProfile.SimpleShot)
        };

        CCsvParser.Write(GetSettingPath(normalizedRecipeId, settingName), Headers, rows);
        return Task.CompletedTask;
    }

    public override Task Rename(
        string recipeId,
        string oldSettingName,
        string newSettingName,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var oldPath = GetSettingPath(recipeId, oldSettingName);
        var newPath = GetSettingPath(recipeId, newSettingName);
        if (!System.IO.File.Exists(oldPath))
        {
            throw new FileNotFoundException($"Review setting file was not found: {NormalizeSettingName(oldSettingName)}", oldPath);
        }

        if (System.IO.File.Exists(newPath))
        {
            throw new IOException($"Review setting file already exists: {NormalizeSettingName(newSettingName)}");
        }

        Directory.CreateDirectory(GetRecipeDirectory(recipeId));
        System.IO.File.Move(oldPath, newPath);
        return Task.CompletedTask;
    }

    public override Task Delete(
        string recipeId,
        string settingName,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var path = GetSettingPath(recipeId, settingName);
        if (System.IO.File.Exists(path))
        {
            System.IO.File.Delete(path);
        }

        return Task.CompletedTask;
    }

    public override Task RenameRecipe(
        string oldRecipeId,
        string newRecipeId,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var oldDirectory = GetRecipeDirectory(oldRecipeId);
        if (!Directory.Exists(oldDirectory))
        {
            return Task.CompletedTask;
        }

        var newDirectory = GetRecipeDirectory(newRecipeId);
        if (Directory.Exists(newDirectory))
        {
            throw new IOException($"Review Setting directory already exists: {NormalizeRecipeId(newRecipeId)}");
        }

        Directory.Move(oldDirectory, newDirectory);
        return Task.CompletedTask;
    }

    public override string GetDisplayPath(string recipeId, string settingName)
    {
        if (string.IsNullOrWhiteSpace(settingName))
        {
            return "-";
        }

        return Path.Combine("Config", "ReviewSetting", NormalizeRecipeId(recipeId), NormalizeSettingName(settingName));
    }

    private string GetRecipeDirectory(string recipeId)
    {
        return Path.Combine(_rootDirectory, NormalizeRecipeId(recipeId));
    }

    private string GetSettingPath(string recipeId, string settingName)
    {
        return Path.Combine(GetRecipeDirectory(recipeId), NormalizeSettingName(settingName));
    }

    private static string NormalizeRecipeId(string recipeId)
    {
        return NormalizePathPart(recipeId, "DEFAULT_RECIPE");
    }

    private static string NormalizeSettingName(string settingName)
    {
        var name = Path.GetFileName((settingName ?? "").Trim());
        if (string.IsNullOrWhiteSpace(name))
        {
            return "";
        }

        if (!name.EndsWith(Extension, StringComparison.OrdinalIgnoreCase))
        {
            name += Extension;
        }

        return NormalizePathPart(name, $"DEFAULT{Extension}");
    }

    private static string NormalizePathPart(string value, string fallback)
    {
        var normalized = (value ?? "").Trim();
        foreach (var invalidCharacter in Path.GetInvalidFileNameChars())
        {
            normalized = normalized.Replace(invalidCharacter, '_');
        }

        return string.IsNullOrWhiteSpace(normalized) ? fallback : normalized;
    }

    private static IReadOnlyDictionary<string, string> Row(string name, string value)
    {
        return new Dictionary<string, string>
        {
            ["NAME"] = name,
            ["VALUE"] = value
        };
    }

    private static string Read(IReadOnlyDictionary<string, string> values, string key, string fallback)
    {
        return values.TryGetValue(key, out var value) && !string.IsNullOrWhiteSpace(value)
            ? value.Trim()
            : fallback;
    }

    private static int ReadInt(IReadOnlyDictionary<string, string> values, string key, int fallback)
    {
        return int.TryParse(Read(values, key, ""), NumberStyles.Integer, CultureInfo.InvariantCulture, out var value)
            ? value
            : fallback;
    }

    private static int ReadFineLineCount(IReadOnlyDictionary<string, string> values)
    {
        return NormalizeFineLineCount(ReadInt(values, "FINE_LINE_COUNT", 3));
    }

    private static int NormalizeFineLineCount(int value)
    {
        return value is 1 or 3 or 5 or 7 ? value : 3;
    }

    private static string NormalizeRule(string value)
    {
        var normalized = value.Trim().ToUpperInvariant();
        return normalized is "ROUGH" or "FINE" ? normalized : "ROUGH";
    }

    private static string NormalizeScope(string value)
    {
        return value.Trim().Equals("HEAD_CELL", StringComparison.OrdinalIgnoreCase)
            ? "HEAD_CELL"
            : "HEAD";
    }

    private static string NormalizeRoughReference(string value)
    {
        var normalized = value.Trim().ToUpperInvariant();
        return normalized is "FIRST" or "CENTER" or "LAST" ? normalized : "FIRST";
    }

    private static string NormalizeInspectionMethod(string value)
    {
        return value.Trim().Equals("IOF", StringComparison.OrdinalIgnoreCase) ? "IOF" : "P2P";
    }
}
