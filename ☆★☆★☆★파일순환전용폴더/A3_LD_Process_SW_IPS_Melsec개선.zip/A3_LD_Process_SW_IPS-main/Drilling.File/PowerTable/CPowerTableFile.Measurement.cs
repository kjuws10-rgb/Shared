using System.Collections.Concurrent;
using System.Globalization;
using System.Text;
using Drilling.Common.Interface;
using Drilling.File.Parser;

namespace Drilling.File.PowerTable;

public sealed partial class CPowerTableFile
{
    private static readonly ConcurrentDictionary<string, object> MeasurementLocks = new(StringComparer.OrdinalIgnoreCase);

    public ST_POWER_MEASURE_START FindStart(int headNo, double targetPower, CancellationToken token)
    {
        token.ThrowIfCancellationRequested();
        var path = GetPath(headNo);
        if (!double.IsFinite(targetPower) || targetPower < 0) throw new ArgumentOutOfRangeException(nameof(targetPower));
        // The first simulation can consult the real table, but all simulated results go into Simulation/.
        if (!System.IO.File.Exists(path) && _initialDirectory is not null)
            path = Path.Combine(_initialDirectory, $"HEAD{headNo:00}.csv");
        try
        {
            if (!System.IO.File.Exists(path)) return new(null, "PowerTable 파일 없음");
            var points = LoadMeasurementPoints(path, token);
            var exact = points.Where(p => p.Power == targetPower).ToArray();
            if (exact.Length == 1) return new(exact[0].Angle, "PowerTable 실측값");
            if (exact.Length > 1) return new(null, "목표 W에 해당하는 ATT 각도가 여러 개임");
            var candidates = new List<double>();
            for (var i = 1; i < points.Count; i++)
            {
                var a = points[i - 1]; var b = points[i];
                if (targetPower > Math.Min(a.Power, b.Power) && targetPower < Math.Max(a.Power, b.Power))
                    candidates.Add(a.Angle + (targetPower - a.Power) * (b.Angle - a.Angle) / (b.Power - a.Power));
            }
            return candidates.Count == 1 ? new(candidates[0], "PowerTable 선형 보간") :
                new(null, candidates.Count == 0 ? "목표 W를 포함하는 PowerTable 구간 없음" : "목표 W에 해당하는 PowerTable 구간이 여러 개임");
        }
        catch (Exception error) when (error is InvalidDataException or IOException or UnauthorizedAccessException)
        {
            return new(null, $"PowerTable 조회 불가: {error.Message}");
        }
    }

    /// <summary>Keep the final measured W (not the requested W). Replace the same angle, otherwise insert.</summary>
    public void SaveMeasurement(int headNo, double angle, double measuredPower, CancellationToken token)
    {
        var path = GetPath(headNo);
        if (!double.IsFinite(angle) || angle is < 0 or > 360 || !double.IsFinite(measuredPower) || measuredPower < 0)
            throw new ArgumentException("PowerTable에는 유효한 ATT 각도(0~360°)와 측정 W(0 이상)만 저장할 수 있습니다.");
        lock (MeasurementLocks.GetOrAdd(path, _ => new object()))
        {
            token.ThrowIfCancellationRequested();
            // Never copy the unmeasured seed curve into the simulation results.
            var points = System.IO.File.Exists(path) ? LoadMeasurementPoints(path, token) : [];
            var index = points.FindIndex(p => Math.Abs(p.Angle - angle) <= 0.000001);
            if (index >= 0) points[index] = (angle, measuredPower);
            else points.Add((angle, measuredPower));
            points.Sort((a, b) => a.Angle.CompareTo(b.Angle));
            var text = "Attenuator_deg,Power_W\r\n" + string.Join("\r\n", points.Select(p =>
                $"{p.Angle.ToString("R", CultureInfo.InvariantCulture)},{p.Power.ToString("R", CultureInfo.InvariantCulture)}")) + "\r\n";
            Directory.CreateDirectory(_directory);
            var temporary = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                System.IO.File.WriteAllText(temporary, text, new UTF8Encoding(false));
                token.ThrowIfCancellationRequested();
                // Atomic replacement also keeps the preceding calibration recoverable.
                if (System.IO.File.Exists(path)) System.IO.File.Replace(temporary, path, path + ".bak");
                else System.IO.File.Move(temporary, path);
            }
            finally { if (System.IO.File.Exists(temporary)) System.IO.File.Delete(temporary); }
        }
    }

    private static List<(double Angle, double Power)> LoadMeasurementPoints(string path, CancellationToken token)
    {
        CCsvParser.ValidateRequiredHeaders(path, "PowerTable", [["Attenuator_deg"], ["Power_W"]]);
        var rows = CCsvParser.Read(path);
        var points = new List<(double Angle, double Power)>();
        foreach (var row in rows)
        {
            token.ThrowIfCancellationRequested();
            var angle = ReadNumber(row, "Attenuator_deg", points.Count + 1);
            var power = ReadNumber(row, "Power_W", points.Count + 1);
            if (angle is < 0 or > 360 || power < 0) throw new InvalidDataException("PowerTable의 각도 또는 출력 범위가 올바르지 않습니다.");
            points.Add((angle, power));
        }
        points.Sort((a, b) => a.Angle.CompareTo(b.Angle));
        if (points.Select(p => p.Angle).Distinct().Count() != points.Count)
            throw new InvalidDataException("PowerTable에 중복 ATT 각도가 있습니다.");
        return points;
    }
}
