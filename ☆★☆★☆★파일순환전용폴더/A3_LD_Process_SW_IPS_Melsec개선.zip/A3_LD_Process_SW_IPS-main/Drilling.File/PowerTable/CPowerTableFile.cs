using System.Globalization;
using Drilling.File.Parser;
using Drilling.Common.Interface;

namespace Drilling.File.PowerTable;

/// <summary>Resolves a target optical power from a single Head's measured ATT table.</summary>
public sealed partial class CPowerTableFile : IPowerMeasureTable
{
    private readonly string _directory;
    private readonly string? _initialDirectory;

    /// <param name="configRoot">The application's Config directory.</param>
    public CPowerTableFile(string configRoot, bool simulation = false)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(configRoot);
        _directory = Path.GetFullPath(Path.Combine(configRoot, "PowerTable"));
        if (simulation)
        {
            _initialDirectory = _directory;
            _directory = Path.Combine(_directory, "Simulation");
        }
    }

    public string GetPath(int headNo)
    {
        if (headNo is < 1 or > 8)
            throw new ArgumentOutOfRangeException(nameof(headNo), "PowerTable의 Head 번호는 1~8이어야 합니다.");
        return Path.Combine(_directory, $"HEAD{headNo:00}.csv");
    }

    /// <summary>
    /// Reads fresh table data, then returns an exact point or a linear interpolation.
    /// Ambiguous tables and powers outside the measured range are rejected; no extrapolation is performed.
    /// </summary>
    public double ResolveAttenuatorAngle(int headNo, double powerWatts, CancellationToken cancellationToken = default)
    {
        // Config/PowerTable ships with illustrative values; replace them with measured calibration
        // before real operation. ATT Min/Max SW Limits are independently editable in Setting.
        cancellationToken.ThrowIfCancellationRequested();
        var path = GetPath(headNo);
        var context = $"HEAD {headNo:00} PowerTable 변환 실패 (요청 {powerWatts.ToString("R", CultureInfo.InvariantCulture)} W).\n파일: {path}";
        try
        {
            if (!double.IsFinite(powerWatts) || powerWatts < 0)
                throw new InvalidDataException("요청 출력은 0 이상의 유한한 W 값이어야 합니다.");
            if (!System.IO.File.Exists(path))
                throw new FileNotFoundException("PowerTable 파일이 없습니다.", path);

            CCsvParser.ValidateRequiredHeaders(path, "PowerTable", [["Attenuator_deg"], ["Power_W"]]);
            var rows = CCsvParser.Read(path);
            cancellationToken.ThrowIfCancellationRequested();
            if (rows.Count < 2)
                throw new InvalidDataException("PowerTable에는 서로 다른 각도의 측정값이 최소 2개 필요합니다.");

            var points = new List<(double Angle, double Power)>(rows.Count);
            for (var index = 0; index < rows.Count; index++)
            {
                cancellationToken.ThrowIfCancellationRequested();
                var row = rows[index];
                var angle = ReadNumber(row, "Attenuator_deg", index + 1);
                var power = ReadNumber(row, "Power_W", index + 1);
                if (angle is < 0 or > 360)
                    throw new InvalidDataException($"측정값 {index + 1}: ATT 각도는 0~360 deg 범위여야 합니다.");
                if (power < 0)
                    throw new InvalidDataException($"측정값 {index + 1}: Power_W는 0 이상이어야 합니다.");
                points.Add((angle, power));
            }

            points.Sort((left, right) => left.Angle.CompareTo(right.Angle));
            var direction = Math.Sign(points[1].Power - points[0].Power);
            for (var index = 1; index < points.Count; index++)
            {
                if (points[index].Angle == points[index - 1].Angle)
                    throw new InvalidDataException($"ATT 각도 {Format(points[index].Angle)} deg가 중복되었습니다.");
                if (direction == 0 || Math.Sign(points[index].Power - points[index - 1].Power) != direction)
                    throw new InvalidDataException("ATT 각도 순서에 따른 W 값은 계속 증가하거나 계속 감소해야 합니다. 같은 W 값 또는 방향이 바뀌는 구간이 있어 목표 각도를 결정할 수 없습니다.");
            }

            var minPower = Math.Min(points[0].Power, points[^1].Power);
            var maxPower = Math.Max(points[0].Power, points[^1].Power);
            if (powerWatts < minPower || powerWatts > maxPower)
                throw new InvalidDataException($"요청 출력이 PowerTable 범위 {Format(minPower)}~{Format(maxPower)} W를 벗어났습니다.");

            for (var index = 0; index < points.Count; index++)
            {
                cancellationToken.ThrowIfCancellationRequested();
                var point = points[index];
                if (powerWatts == point.Power) return point.Angle;
                if (index == 0) continue;
                var previous = points[index - 1];
                if (powerWatts > Math.Min(previous.Power, point.Power) && powerWatts < Math.Max(previous.Power, point.Power))
                {
                    var fraction = (powerWatts - previous.Power) / (point.Power - previous.Power);
                    return previous.Angle + (point.Angle - previous.Angle) * fraction;
                }
            }

            throw new InvalidDataException("요청 출력에 해당하는 ATT 각도를 찾을 수 없습니다.");
        }
        catch (Exception exception) when (exception is InvalidDataException or IOException or UnauthorizedAccessException)
        {
            throw new InvalidDataException($"{context}\n{exception.Message}", exception);
        }
    }

    private static double ReadNumber(IReadOnlyDictionary<string, string> row, string name, int measurementNo)
    {
        var text = CCsvParser.Get(row, name);
        if (!double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out var value) || !double.IsFinite(value))
            throw new InvalidDataException($"측정값 {measurementNo}: {name}은 유한한 숫자여야 합니다. 소수점은 '.'을 사용하세요. 입력: {text}");
        return value;
    }

    private static string Format(double value) => value.ToString("R", CultureInfo.InvariantCulture);
}
