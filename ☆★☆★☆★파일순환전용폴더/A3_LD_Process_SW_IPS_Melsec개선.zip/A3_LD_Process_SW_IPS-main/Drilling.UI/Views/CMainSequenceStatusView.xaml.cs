using System.Windows.Controls;
using System.Windows;
using System.Windows.Input;
using Drilling.UI.Menu.Menus;

namespace Drilling.UI.Views;

public partial class CMainSequenceStatusView : UserControl
{
    public CMainSequenceStatusView() => InitializeComponent();
    private void CardClicked(object sender, MouseButtonEventArgs e) => OpenMonitor(sender);
    private void CardKeyUp(object sender, KeyEventArgs e)
    {
        if (e.Key is Key.Enter or Key.Space) OpenMonitor(sender);
    }
    private void OpenMonitor(object sender)
    {
        if (sender is FrameworkElement { DataContext: CMainSequenceCard { Id: "REVIEW_MEASURE" } } &&
            DataContext is CMainSequenceStatus status) status.OpenReviewMonitor?.Invoke();
    }
}
