using System.Windows.Controls;

namespace Drilling.UI.Views;

public partial class CMonitorLogViewerView : UserControl
{
    public CMonitorLogViewerView() => InitializeComponent();

    private void LogTextChanged(object sender, TextChangedEventArgs e)
    {
        if (sender is not TextBox text) return;
        text.ScrollToHome();
        text.ScrollToHorizontalOffset(0);
    }
}
