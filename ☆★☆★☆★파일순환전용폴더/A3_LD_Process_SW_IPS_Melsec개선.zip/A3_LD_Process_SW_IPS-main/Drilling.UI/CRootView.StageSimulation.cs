using System.Windows;
using Drilling.UI.Menu;
using Drilling.UI.Popup;

namespace Drilling.UI;

public sealed partial class CRootView
{
    private CMelsecStageSimulationDialog? _stageSimulationDialog;
    public CButtonCommand OpenMelsecStageSimulationCommand { get; }

    private void OpenMelsecStageSimulation()
    {
        if (_stageSimulationDialog is not null)
        {
            if (_stageSimulationDialog.WindowState == WindowState.Minimized)
                _stageSimulationDialog.WindowState = WindowState.Normal;
            _stageSimulationDialog.Activate();
            return;
        }
        var dialog = new CMelsecStageSimulationDialog(_interfaceManager) { Owner = Application.Current?.MainWindow };
        _stageSimulationDialog = dialog;
        dialog.Closed += (_, _) => _stageSimulationDialog = null;
        dialog.Show(); // Keep MAIN and AUTO controls usable while injecting Stage inputs.
    }
}
