using System.Windows;
using System.Windows.Threading;
using Drilling.Common.Interface;

namespace Drilling.UI.Popup;

public partial class CMelsecStageSimulationDialog : Window
{
    private readonly DispatcherTimer _timer;
    public CMelsecStageSimulationPanel Panel { get; }

    public CMelsecStageSimulationDialog(CInterfaceManager interfaces)
    {
        InitializeComponent();
        Panel = new(interfaces);
        DataContext = Panel;
        Height = Math.Min(Height, SystemParameters.WorkArea.Height * 0.9);
        _timer = new(DispatcherPriority.Background, Dispatcher) { Interval = TimeSpan.FromMilliseconds(500) };
        _timer.Tick += RefreshSnapshot;
        Loaded += (_, _) => { Panel.Refresh(); _timer.Start(); };
        Closed += (_, _) => { _timer.Stop(); _timer.Tick -= RefreshSnapshot; };
        Panel.Refresh();
    }

    // UI refresh only copies the existing cache. It never reads a PLC/device directly.
    private void RefreshSnapshot(object? sender, EventArgs e) => Panel.Refresh();
    private void CloseClicked(object sender, RoutedEventArgs e) => Close();
}
