using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Windows.Media;
using Drilling.Common.Interface;
using Drilling.UI.Menu;

namespace Drilling.UI.Popup;

public sealed class CMelsecStageSimulationPanel(CInterfaceManager interfaces) : INotifyPropertyChanged
{
    private IReadOnlyList<ST_MELSEC_MAP_DATA> _map = [];
    private string _connectionText = "";
    public event PropertyChangedEventHandler? PropertyChanged;
    public ObservableCollection<CMelsecStageSimulationRow> Rows { get; } = [];
    public string ConnectionText => _connectionText;

    public void Refresh()
    {
        var values = interfaces.Melsec.GetCachedSnapshot(out var map);
        var signals = map.Where(row => CMelsec.IsStageSimulationSignal(row) || CMelsec.IsStageAlignSimulationSignal(row))
            .OrderBy(row => ScenarioOrder(row.Group)).ThenBy(row => row.DeviceNo)
            .ThenBy(row => SignalOrder(row.Id)).ThenBy(row => row.Id).ToArray();
        if (!_map.SequenceEqual(signals))
        {
            _map = signals;
            Rows.Clear();
            foreach (var signal in signals)
                Rows.Add(new(signal, value =>
                {
                    if (CMelsec.IsStageAlignSimulationSignal(signal)) interfaces.Melsec.SetStageAlignSimulationValue(signal.Id, value);
                    else interfaces.Melsec.SetStageSimulationSignal(signal.Id, value == 1);
                }));
        }

        var connections = interfaces.GetInterfaceCommunicationList(EN_EQP_MODULE.Melsec)
            .ToDictionary(row => row.Number);
        var text = string.Join("   |   ", signals.Select(row => row.DeviceNo).Distinct().Select(number =>
        {
            var state = connections.TryGetValue(number, out var status)
                ? status.IsSimulation ? "SIMULATION" : status.ConnectionState.ToString().ToUpperInvariant()
                : "OFFLINE";
            return $"MELSEC_{number} : {state}";
        }));
        if (text.Length == 0) text = "등록된 Stage 수신 신호가 없습니다.";
        if (_connectionText != text)
        {
            _connectionText = text;
            PropertyChanged?.Invoke(this, new(nameof(ConnectionText)));
        }
        foreach (var row in Rows)
        {
            values.TryGetValue(row.Id, out var sample);
            row.Refresh(sample, interfaces.IsSimul(EN_EQP_MODULE.Melsec, row.DeviceNo));
        }
    }

    private static int ScenarioOrder(string group) => group.ToUpperInvariant() switch
    {
        "IF_DOREADY" => 0, "IF_PROCESS" => 1, "IF_REVIEW" => 2,
        "IF_TOP_POWERMETER" => 3, "IF_PROCESS_MOVE" => 4, "IF_IOF" => 5, "IF_ALIGN" => 6, _ => 7
    };

    private static int SignalOrder(string id) => id.Equals("SDC_DO_ALIGN_STATUS", StringComparison.OrdinalIgnoreCase) ? 0
        : id.Equals("SDC_DO_ALIGN_COMPLETE", StringComparison.OrdinalIgnoreCase) ? 1
        : id.Contains("_ABLE", StringComparison.OrdinalIgnoreCase) ? 0
        : id.Contains("_START", StringComparison.OrdinalIgnoreCase) ? 1 : 2;
}

public sealed class CMelsecStageSimulationRow : INotifyPropertyChanged
{
    private bool _canSet;
    private string _currentValue = "—";
    private string _inputValue;
    private readonly double _readScale;
    private Brush _stateBrush = Brushes.Gray;
    public event PropertyChangedEventHandler? PropertyChanged;
    public string Id { get; }
    public int DeviceNo { get; }
    public string Scenario { get; }
    public string Name { get; }
    public string Address { get; }
    public string Description { get; }
    public string CurrentValue => _currentValue;
    public Brush StateBrush => _stateBrush;
    public bool CanSet => _canSet;
    public bool IsNumeric { get; }
    public string InputValue
    {
        get => _inputValue;
        set
        {
            if (_inputValue == value) return;
            _inputValue = value;
            Changed();
        }
    }
    public CButtonCommand SetOnCommand { get; }
    public CButtonCommand SetOffCommand { get; }
    public CButtonCommand SetValueCommand { get; }

    public CMelsecStageSimulationRow(ST_MELSEC_MAP_DATA data, Action<int> set, Action<string>? showWarning = null)
    {
        Id = data.Id;
        DeviceNo = data.DeviceNo;
        Scenario = data.Group.ToUpperInvariant() switch
        {
            "IF_DOREADY" => "DoReady", "IF_PROCESS" => "Process", "IF_REVIEW" => "Review",
            "IF_TOP_POWERMETER" => "TPM", "IF_PROCESS_MOVE" => "Process / Move", "IF_IOF" => "IOF", "IF_ALIGN" => "Align", _ => data.Group
        };
        Name = data.Name;
        Address = $"MELSEC_{data.DeviceNo} / {data.Address}";
        Description = data.Description;
        IsNumeric = CMelsec.IsStageAlignSimulationSignal(data);
        _inputValue = IsNumeric ? "10000" : "0";
        _readScale = data.ReadScale;
        var warn = showWarning ?? (message => CRecipeConfirmDialog.ShowWarning("Stage 신호 변경 실패", message));
        void Set(int value)
        {
            if (!_canSet) return;
            try { set(value); }
            catch (Exception exception) { warn(exception.Message); }
        }
        SetOnCommand = new(_ => Set(1), _ => _canSet && !IsNumeric);
        SetOffCommand = new(_ => Set(0), _ => _canSet && !IsNumeric);
        SetValueCommand = new(_ =>
        {
            if (!_canSet || !IsNumeric) return;
            if (!int.TryParse(InputValue, NumberStyles.Integer, CultureInfo.InvariantCulture, out var value) || value is < 0 or > ushort.MaxValue)
            {
                warn("0~65535의 원시 정수를 입력하세요.");
                return;
            }
            Set(value);
        }, _ => _canSet && IsNumeric);
    }

    public void Refresh(ST_MELSEC_CACHED_VALUE? sample, bool simulation)
    {
        if (_canSet != simulation)
        {
            _canSet = simulation;
            Changed(nameof(CanSet));
            SetOnCommand.NotifyCanExecuteChanged();
            SetOffCommand.NotifyCanExecuteChanged();
            SetValueCommand.NotifyCanExecuteChanged();
        }
        var raw = sample is { IsValid: true } ? Convert.ToString(sample.Value, System.Globalization.CultureInfo.InvariantCulture) : null;
        var text = raw switch { "1" => "ON (1)", "0" => "OFF (0)", null => "—", _ => raw };
        var brush = raw switch { "1" => Brushes.ForestGreen, "0" => Brushes.DarkGoldenrod, null => Brushes.Gray, _ => Brushes.Firebrick };
        if (IsNumeric && raw is not null)
        {
            var scaled = Convert.ToDouble(sample!.Value, CultureInfo.InvariantCulture);
            var rawValue = scaled / _readScale;
            text = $"{rawValue.ToString("0", CultureInfo.InvariantCulture)} → {scaled.ToString("0.########", CultureInfo.InvariantCulture)}";
            brush = scaled == 1 ? Brushes.ForestGreen : Brushes.Firebrick;
        }
        if (_currentValue != text) { _currentValue = text; Changed(nameof(CurrentValue)); }
        if (_stateBrush != brush) { _stateBrush = brush; Changed(nameof(StateBrush)); }
    }

    private void Changed([CallerMemberName] string? name = null) => PropertyChanged?.Invoke(this, new(name));
}
