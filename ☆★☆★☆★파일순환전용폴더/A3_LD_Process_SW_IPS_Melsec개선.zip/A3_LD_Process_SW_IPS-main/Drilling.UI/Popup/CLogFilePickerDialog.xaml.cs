using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Drilling.UI.Popup;

public partial class CLogFilePickerDialog : Window
{
    private readonly CLogFilePickerModel _model;
    private bool _initialized;
    public string? SelectedFilePath { get; private set; }

    public CLogFilePickerDialog(string rootDirectory, string initialDirectory)
    {
        InitializeComponent();
        _model = new(rootDirectory, initialDirectory);
        DataContext = _model;
        MaxHeight = SystemParameters.WorkArea.Height - 40;
        MaxWidth = SystemParameters.WorkArea.Width - 40;
    }

    private async void DialogLoaded(object sender, RoutedEventArgs e)
    {
        if (_initialized) return;
        _initialized = true;
        await _model.InitializeAsync();
    }

    private async void OpenClicked(object sender, RoutedEventArgs e) => await OpenSelectedAsync();

    private async void FileDoubleClicked(object sender, MouseButtonEventArgs e)
    {
        if (e.ChangedButton == MouseButton.Left && e.OriginalSource is DependencyObject source
            && ItemsControl.ContainerFromElement(FileGrid, source) is DataGridRow)
            await OpenSelectedAsync();
    }

    private async void FileKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter) { e.Handled = true; await OpenSelectedAsync(); }
        else if (e.Key == Key.Back) { e.Handled = true; await _model.UpAsync(); }
    }

    private async Task OpenSelectedAsync()
    {
        var path = await _model.OpenSelectedAsync();
        if (path is null || !IsVisible) return;
        SelectedFilePath = path;
        DialogResult = true;
    }
}
