using System.ComponentModel;
using System.IO;
using System.Runtime.CompilerServices;
using Drilling.Common.Log;
using Drilling.UI.Menu;

namespace Drilling.UI.Popup;

public sealed record ST_LOG_FILE_PICKER_ENTRY(string Path, string Name, bool IsDirectory, DateTime ModifiedAt, long Length)
{
    public string Kind => IsDirectory ? "폴더" : System.IO.Path.GetExtension(Name).TrimStart('.').ToUpperInvariant();
    public string Modified => ModifiedAt.ToString("yyyy-MM-dd HH:mm:ss");
    public string Size => IsDirectory ? "" : $"{Length / 1024.0:N1} KB";
}

public sealed class CLogFilePickerModel : INotifyPropertyChanged
{
    private readonly CLogFileScope _scope;
    private readonly string _initialDirectory;
    private ST_LOG_FILE_PICKER_ENTRY? _selectedEntry;

    public CLogFilePickerModel(string rootDirectory, string initialDirectory)
    {
        _scope = new(rootDirectory);
        _initialDirectory = initialDirectory;
        CurrentDirectory = _scope.RootDirectory;
        UpCommand = new(async _ => await UpAsync(), _ => CanGoUp);
        RootCommand = new(async _ => await NavigateAsync(_scope.RootDirectory), _ => CanGoUp);
    }

    public event PropertyChangedEventHandler? PropertyChanged;
    public string CurrentDirectory { get; private set; }
    public string DisplayPath => "Log" + (CurrentDirectory.Equals(_scope.RootDirectory, StringComparison.OrdinalIgnoreCase)
        ? "" : " / " + Path.GetRelativePath(_scope.RootDirectory, CurrentDirectory).Replace(Path.DirectorySeparatorChar.ToString(), " / "));
    public string Status { get; private set; } = "";
    public bool IsBusy { get; private set; }
    public bool CanBrowse => !IsBusy;
    public bool CanGoUp => !IsBusy && !CurrentDirectory.Equals(_scope.RootDirectory, StringComparison.OrdinalIgnoreCase);
    public bool CanOpen => !IsBusy && SelectedEntry is not null;
    public IReadOnlyList<ST_LOG_FILE_PICKER_ENTRY> Entries { get; private set; } = [];
    public ST_LOG_FILE_PICKER_ENTRY? SelectedEntry
    {
        get => _selectedEntry;
        set { _selectedEntry = value; Notify(); Notify(nameof(CanOpen)); }
    }
    public CButtonCommand UpCommand { get; }
    public CButtonCommand RootCommand { get; }

    public async Task InitializeAsync()
    {
        if (!await NavigateAsync(_initialDirectory)) await NavigateAsync(_scope.RootDirectory);
    }

    public Task UpAsync() => CanGoUp
        ? NavigateAsync(Path.GetDirectoryName(CurrentDirectory)!) : Task.CompletedTask;

    public async Task<bool> NavigateAsync(string directory)
    {
        if (IsBusy) return false;
        var succeeded = false;
        SetBusy(true);
        try
        {
            var result = await Task.Run(() =>
            {
                var resolved = _scope.ResolveDirectory(directory);
                var rows = new DirectoryInfo(resolved).EnumerateFileSystemInfos()
                    .Where(info => (info.Attributes & FileAttributes.ReparsePoint) == 0 && !CLogFileScope.IsAlarm(info.Name))
                    .Where(info => info is DirectoryInfo || CLogFileScope.IsLogFile(info.Name))
                    .Select(info => new ST_LOG_FILE_PICKER_ENTRY(info.FullName, info.Name, info is DirectoryInfo,
                        info.LastWriteTime, info is FileInfo file ? file.Length : 0))
                    .OrderByDescending(row => row.IsDirectory).ThenBy(row => row.Name, StringComparer.OrdinalIgnoreCase).ToArray();
                return (resolved, rows);
            });
            succeeded = true;
            CurrentDirectory = result.resolved;
            Entries = result.rows;
            SelectedEntry = null;
            Status = Entries.Count == 0 ? "이 폴더에는 표시할 로그 파일이나 하위 폴더가 없습니다." : $"{Entries.Count:N0}개 항목 · 폴더나 파일을 선택한 뒤 OPEN을 누르거나 두 번 클릭하세요.";
        }
        catch (Exception exception) when (exception is IOException or UnauthorizedAccessException or ArgumentException)
        {
            Status = $"조회 실패: {exception.Message}";
        }
        finally { SetBusy(false); }
        return succeeded;
    }

    public async Task<string?> OpenSelectedAsync()
    {
        if (!CanOpen || SelectedEntry is not { } entry) return null;
        if (entry.IsDirectory)
        {
            await NavigateAsync(entry.Path);
            return null;
        }
        SetBusy(true);
        try { return await Task.Run(() => _scope.ResolveFile(entry.Path)); }
        catch (Exception exception) when (exception is IOException or UnauthorizedAccessException or ArgumentException)
        {
            Status = $"열기 실패: {exception.Message}";
            return null;
        }
        finally { SetBusy(false); }
    }

    private void SetBusy(bool busy)
    {
        IsBusy = busy;
        foreach (var name in new[] { nameof(CurrentDirectory), nameof(DisplayPath), nameof(Status), nameof(Entries), nameof(IsBusy), nameof(CanBrowse), nameof(CanGoUp), nameof(CanOpen) }) Notify(name);
        UpCommand.NotifyCanExecuteChanged();
        RootCommand.NotifyCanExecuteChanged();
    }

    private void Notify([CallerMemberName] string? name = null) => PropertyChanged?.Invoke(this, new(name));
}
