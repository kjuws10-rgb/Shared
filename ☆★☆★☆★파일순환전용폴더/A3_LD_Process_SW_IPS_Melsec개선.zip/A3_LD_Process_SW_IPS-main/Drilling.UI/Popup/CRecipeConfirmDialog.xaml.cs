using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Drilling.UI.Popup;

public enum EN_REVIEW_RESUME_CHOICE
{
    Cancel,
    Resume,
    Restart
}

public partial class CRecipeConfirmDialog : Window
{
    private bool _alternateSelected;

    public static bool ShowConfirmation(string title, string message, string confirmText = "확인", bool useDangerStyle = false)
    {
        var dialog = new CRecipeConfirmDialog(title, message, confirmText, useDangerStyle)
        {
            Owner = Application.Current?.MainWindow
        };
        return dialog.ShowDialog() == true;
    }

    public static void ShowCompletion(string title, string message, Window? owner = null)
    {
        ShowMessage(title, message, useDangerStyle: false, owner);
    }

    public static void ShowWarning(string title, string message, Window? owner = null)
    {
        ShowMessage(title, message, useDangerStyle: true, owner);
    }

    public static EN_REVIEW_RESUME_CHOICE ShowReviewResumeChoice(
        string message)
    {
        var dialog = new CRecipeConfirmDialog(
            "미완료 Review 확인",
            message,
            "이어서 검사",
            useDangerStyle: false)
        {
            Owner = Application.Current?.MainWindow
        };
        dialog.CancelButton.Content = "처음부터";
        var result = dialog.ShowDialog();
        if (result == true)
        {
            return EN_REVIEW_RESUME_CHOICE.Resume;
        }

        return dialog._alternateSelected
            ? EN_REVIEW_RESUME_CHOICE.Restart
            : EN_REVIEW_RESUME_CHOICE.Cancel;
    }

    public static EN_REVIEW_RESUME_CHOICE ShowFineRetryChoice(string message)
    {
        var dialog = CreateFineRetryChoice(message);
        var result = dialog.ShowDialog();
        return result == true ? EN_REVIEW_RESUME_CHOICE.Resume
            : dialog._alternateSelected ? EN_REVIEW_RESUME_CHOICE.Restart : EN_REVIEW_RESUME_CHOICE.Cancel;
    }

    internal static CRecipeConfirmDialog CreateFineRetryChoice(string message)
    {
        var owner = Application.Current?.MainWindow;
        var dialog = new CRecipeConfirmDialog("FINE NG 재검사", message, "NG 라인부터", useDangerStyle: false);
        if (owner is not null) dialog.Owner = owner;
        dialog.CancelButton.Content = "처음부터";
        return dialog;
    }

    private static void ShowMessage(string title, string message, bool useDangerStyle, Window? owner)
    {
        var dialog = new CRecipeConfirmDialog(title, message, "확인", useDangerStyle)
        {
            Owner = owner ?? Application.Current?.MainWindow
        };
        dialog.CancelButton.Visibility = Visibility.Collapsed;
        Grid.SetColumnSpan(dialog.ConfirmButton, 3);
        dialog.ShowDialog();
    }

    public CRecipeConfirmDialog(string title, string message, string confirmText = "확인", bool useDangerStyle = true)
    {
        InitializeComponent();
        MaxHeight = Math.Max(MinHeight, SystemParameters.WorkArea.Height - 40);
        Title = title;
        TitleText.Text = title;
        MessageText.Text = message;
        ConfirmButton.Content = confirmText;
        if (!useDangerStyle)
        {
            ConfirmButton.SetResourceReference(Control.BackgroundProperty, "ButtonSuccessBrush");
            ConfirmButton.SetResourceReference(Control.BorderBrushProperty, "ButtonSuccessBorderBrush");
        }

        ConfirmButton.Focus();
    }

    protected override void OnKeyDown(KeyEventArgs e)
    {
        base.OnKeyDown(e);
        if (e.Key == Key.Escape)
        {
            _alternateSelected = false;
            DialogResult = false;
        }
    }

    private void OnConfirmClicked(object sender, RoutedEventArgs e)
    {
        DialogResult = true;
    }

    private void OnCancelClicked(object sender, RoutedEventArgs e)
    {
        _alternateSelected = true;
        DialogResult = false;
    }
}
