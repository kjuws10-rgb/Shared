using System.Windows;
using System.Windows.Threading;
using Drilling.Common.Alarm;
using Drilling.UI.Menu;
using Drilling.UI.Menu.Menus;
using Drilling.UI.Popup;

namespace Drilling.UI;

public sealed partial class CRootView
{
    private readonly Dispatcher _alarmDispatcher = Dispatcher.CurrentDispatcher;
    private readonly CAlarmNavigationTracker _alarmNavigation = new();
    private int _alarmRefreshQueued;
    private bool _isAlarmNavigation;
    private bool _isHeaderAlarmResetRunning;
    private CButtonCommand? _headerAlarmResetCommand;
    private CButtonCommand HeaderAlarmResetCommand => _headerAlarmResetCommand ??= new(async _ => await ConfirmHeaderAlarmReset());

    private async Task ConfirmHeaderAlarmReset()
    {
        if (_isHeaderAlarmResetRunning) return;
        _isHeaderAlarmResetRunning = true;
        try
        {
            if (!CRecipeConfirmDialog.ShowConfirmation("ALARM RESET", "현재 발생한 알람을 RESET하시겠습니까?", "RESET", useDangerStyle: true)) return;
            await ((CMenuAlarm)_menus[EN_MENU.Alarm]).ResetAlarmAsync();
        }
        finally
        {
            _isHeaderAlarmResetRunning = false;
        }
    }

    private void OnCurrentAlarmsChanged()
    {
        if (_alarmDispatcher.HasShutdownStarted || Interlocked.Exchange(ref _alarmRefreshQueued, 1) != 0) return;
        _alarmDispatcher.BeginInvoke(DispatcherPriority.Normal, new Action(() =>
        {
            Interlocked.Exchange(ref _alarmRefreshQueued, 0);
            var snapshot = _alarmManager.GetCurrentSnapshot();
            _systemStatus = _systemStatus with { AlarmState = snapshot.Rows.Count > 0 ? EN_ALARM_STATE.Occur : EN_ALARM_STATE.Clear };
            RefreshShellStatusItems();
            if (_alarmNavigation.ShouldNavigate(snapshot))
            {
                ((CMenuAlarm)_menus[EN_MENU.Alarm]).SelectedTabIndex = 0;
                StatusMessage = "새 알람이 발생했습니다. CURRENT에서 원인과 조치 내용을 확인해 주세요.";
                if (SelectedMenu.Menu != EN_MENU.Alarm)
                {
                    _isAlarmNavigation = true;
                    try { SelectedMenu = Menus.First(menu => menu.Menu == EN_MENU.Alarm); }
                    finally { _isAlarmNavigation = false; }
                    return;
                }
            }
            if (SelectedMenu.Menu == EN_MENU.Alarm) _ = RefreshCurrentScreen();
        }));
    }
}

// OccurrenceVersion changes only on a new insertion, including recurrence after RESET.
public sealed class CAlarmNavigationTracker
{
    private long _handledOccurrence;
    public bool ShouldNavigate(ST_CURRENT_ALARM_SNAPSHOT snapshot)
    {
        if (snapshot.OccurrenceVersion <= _handledOccurrence) return false;
        _handledOccurrence = snapshot.OccurrenceVersion;
        return snapshot.Rows.Count > 0;
    }
}
