using Drilling.Common.Interface;
using Drilling.UI.Popup;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuManual
{
    private CManualMofStagePanel? _mofStage;
    public CManualMofStagePanel MofStage => _mofStage ??= new(
        ReadMofStageConnectionState,
        () => _manager.Interface().GetStageMotionSimulation(),
        RefreshMofStageSnapshot,
        message => CRecipeConfirmDialog.ShowConfirmation("READY POSITION MOVE", message),
        message => CRecipeConfirmDialog.ShowWarning("STAGE Y", message),
        _setStatusMessage,
        () => TryBlockManualAutomationCommand("STAGE_READY_POSITION_MOVE"));

    private EN_COMM_STATE ReadMofStageConnectionState()
    {
        var interfaces = _manager.Interface();
        var deviceNo = interfaces.Melsec.Map.FirstOrDefault(row =>
            row.Id.Equals("MOTOR_STAGE_Y_CUR_POS", StringComparison.OrdinalIgnoreCase))?.DeviceNo
            ?? interfaces.GetInterfaceList(EN_EQP_MODULE.Melsec).FirstOrDefault()?.Number;
        var device = interfaces.GetInterfaceCommunicationList(EN_EQP_MODULE.Melsec)
            .FirstOrDefault(item => item.Number == deviceNo);
        return device?.IsSimulation == true ? EN_COMM_STATE.Simulation : device?.ConnectionState ?? EN_COMM_STATE.Offline;
    }

    private void RefreshMofStageSnapshot()
    {
        var snapshot = _manager.Interface().Melsec.GetCachedSnapshot(out var map);
        MofStage.UpdateSnapshot(map, snapshot);
        MofAlign.UpdateSnapshot(map, snapshot);
        MofRun.SetSelectedHeads(SelectedManualHeadNos);
        MofRun.Refresh();
    }
}
