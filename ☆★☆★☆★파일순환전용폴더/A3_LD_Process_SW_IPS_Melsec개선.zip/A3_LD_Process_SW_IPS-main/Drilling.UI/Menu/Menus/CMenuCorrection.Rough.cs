using Drilling.Common.Interface;
using Drilling.Common.Recipe;
using Drilling.Common.Review;
using Drilling.UI.Popup;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuCorrection
{
    private CancellationTokenSource? _roughCancellation;

    private void InitializeRough(CInterfaceManager? interfaces)
    {
        var inspection = Rough.Inspection!;
        inspection.SourceInvalidated += () => _roughCancellation?.Cancel();
        inspection.ReadFeedback = () =>
        {
            if (interfaces is null) return ("-", "-", "OFFLINE");
            var values = CMotorStatusPollingService.ReadCachedSnapshot(interfaces);
            var mode = CMotorStatusPollingService.ReadStageConnectionState(interfaces);
            return (values.FirstOrDefault(row => row.Name == "Stage Y")?.Position ?? "-",
                values.FirstOrDefault(row => row.Name == "Review X")?.Position ?? "-",
                mode == EN_COMM_STATE.Simulation ? "SIMULATION" : mode == EN_COMM_STATE.Online ? "ONLINE" : "OFFLINE");
        };
        Fine.ReadFeedback = inspection.ReadFeedback;
    }

    private async Task ExecuteRoughAction(string action, Func<string, string, bool>? confirm = null,
        Action<string, string>? completed = null, Action<string, string>? warn = null,
        Action<CAlignOffsetViewerPanel>? showViewer = null,
        Func<ST_REVIEW_PLAN_POINT, CancellationToken, Task<ST_ROUGH_REVIEW_MEASUREMENT>>? simulationMeasurement = null)
    {
        var inspection = Rough.Inspection!;
        if (action == "REVIEW_STOP") { _roughCancellation?.Cancel(); return; }
        if (_isReviewOperationRunning || !inspection.CanExecute(action)) return;
        if (action == "OFFSET_VIEW") { await ExecuteSimpleOffsetAction(action, confirm, completed, warn, showViewer); return; }
        confirm ??= (title, message) => CRecipeConfirmDialog.ShowConfirmation(title, message,
            action == "OFFSET_INIT" ? "초기화" : "확인", useDangerStyle: action == "OFFSET_INIT");
        completed ??= (title, message) => CRecipeConfirmDialog.ShowCompletion(title, message);
        warn ??= (title, message) => CRecipeConfirmDialog.ShowWarning(title, message);
        _isReviewOperationRunning = true;
        Simple.SetOffsetOperationRunning(true); Rough.SetOffsetOperationRunning(true); Fine.SetOperationRunning(true);
        ExecuteCommand.NotifyCanExecuteChanged(); inspection.RefreshCommands();
        try
        {
            var initialize = action == "OFFSET_INIT";
            var request = inspection.CreateOffsetRequest(initialize);
            var recipe = await LoadSelectedOutputViewerRecipe(CancellationToken.None, fallbackToFirst: false)
                ?? throw new InvalidOperationException("현재 선택된 레시피가 없습니다.");
            var settings = LoadSimpleOffsetSettings();
            EnsureSimpleOffsetSource(request, recipe, settings);
            if (action is "REVIEW_START" or "NG_RETRY")
            {
                var retry = action == "NG_RETRY";
                var plan = inspection.CreatePlan();
                var count = plan.Points.Count(point => !retry || point.State == EN_REVIEW_POINT_STATE.Ng);
                if (!confirm(retry ? "NG Retry" : "Review Start", $"{recipe.Name} / HEAD {request.HeadNo:00} / Beam {inspection.SelectedBeam}\n{count}개 Shot을 {(retry ? "재검사" : "PtoP 검사")}하시겠습니까?")) return;
                EnsureSimpleOffsetSource(request, await LoadSelectedOutputViewerRecipe(CancellationToken.None, false)
                    ?? throw new InvalidOperationException("현재 레시피가 없습니다."), LoadSimpleOffsetSettings());
                _roughCancellation = new CancellationTokenSource();
                var version = inspection.SourceVersion;
                inspection.Begin(retry);
                var dispatcher = System.Windows.Application.Current?.Dispatcher;
                void Publish(ST_ROUGH_REVIEW_SNAPSHOT snapshot)
                {
                    if (dispatcher is null || dispatcher.CheckAccess()) inspection.ApplyProgress(snapshot, version);
                    else dispatcher.Invoke(() => inspection.ApplyProgress(snapshot, version));
                }
                var result = await _reviewManager.StartRoughCorrection(plan, retry,
                    Publish, _roughCancellation.Token, simulationMeasurement);
                _statusReporter(result.Message);
                if (result.State == EN_REVIEW_SEQUENCE_STATE.Failed) warn("ROUGH 검사 확인", result.Message);
                if (result.ResultSaveError.Length > 0) warn("ROUGH 검사 결과 저장 실패", result.ResultSaveError);
                return;
            }
            if (action is not ("OFFSET_APPLY" or "OFFSET_INIT")) return;
            var deltas = request.Rows.Select(row => row.CellId).Distinct().ToDictionary(cell => cell,
                cell => initialize ? (X: 0.0, Y: 0.0) : inspection.IncrementForCell(cell));
            if (!confirm(initialize ? "Offset Init" : "Offset Apply", $"현재 레시피: {recipe.Name}\nHEAD {request.HeadNo:00} / {inspection.Rows.Count}개 기준 Shot / {request.Rows.Count:N0}개 적용 Shot\n\n" +
                (initialize ? "이 범위의 Review Offset X/Y를 0.000으로 초기화하시겠습니까?"
                    : "OK 결과의 보정량만 기존 설계 Review Offset에 누적하시겠습니까?\nNG·미검사·이미 적용한 결과는 0.000을 누적하여 기존값을 유지합니다.") +
                "\n새 REVIEW OFFSET 파일을 생성합니다.")) return;
            EnsureSimpleOffsetSource(request, await LoadSelectedOutputViewerRecipe(CancellationToken.None, false)
                ?? throw new InvalidOperationException("현재 레시피가 없습니다."), LoadSimpleOffsetSettings());
            var parameters = BuildOutputViewerParameterMap(recipe, settings);
            var saved = await Task.Run(async () =>
            {
                var latest = await _reviewOffsetFile.LoadLatest(recipe.Id);
                if (!latest.RecipeId.Equals(recipe.Id, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("Review Offset 파일의 레시피가 일치하지 않습니다.");
                var merged = latest.Rows.ToDictionary(row => (row.CellId, NormalizeReviewOffsetShotId(row.ShotId)));
                foreach (var target in request.Rows)
                {
                    var key = (target.CellId, target.ShotId);
                    var previous = merged.GetValueOrDefault(key);
                    var current = previous is null ? (X: 0.0, Y: 0.0) : CReviewOffsetData.ToDesign(parameters, request.HeadNo,
                        previous.ReviewOffsetX, previous.ReviewOffsetY, previous.IsDesignCoordinate);
                    var delta = deltas[target.CellId];
                    merged[key] = previous is { IsDesignCoordinate: true } && !initialize && delta == (0, 0) ? previous
                        : target with { ReviewOffsetX = initialize ? 0 : CRoughCorrectionPanel.Round(current.X + delta.X),
                            ReviewOffsetY = initialize ? 0 : CRoughCorrectionPanel.Round(current.Y + delta.Y) };
                }
                return await _reviewOffsetFile.SaveNew(recipe.Id, merged.Values.OrderBy(row => row.CellId).ThenBy(row => row.ShotId).ToArray());
            });
            _simpleOffsetRecipeId = saved.RecipeId; _simpleOffsetLoad = Task.FromResult(saved);
            inspection.MarkApplied(initialize);
            Rough.AcceptSavedOffsets(saved, request.Rows, recipe, settings);
            Simple.Update(recipe, settings, saved);
            _statusReporter($"ROUGH Review Offset 저장: {saved.FileName}");
            completed(initialize ? "Offset Init 완료" : "Offset Apply 완료", $"{saved.FileName}\n{request.Rows.Count:N0}개 Shot의 Review Offset을 저장했습니다.");
        }
        catch (OperationCanceledException) { _statusReporter("ROUGH 검사 중지"); }
        catch (Exception exception) { _statusReporter(exception.Message); warn("ROUGH 확인", exception.Message); }
        finally
        {
            _roughCancellation?.Dispose(); _roughCancellation = null;
            inspection.End();
            _isReviewOperationRunning = false;
            Simple.SetOffsetOperationRunning(false); Rough.SetOffsetOperationRunning(false); Fine.SetOperationRunning(false);
            ExecuteCommand.NotifyCanExecuteChanged(); inspection.RefreshCommands();
        }
    }
}
