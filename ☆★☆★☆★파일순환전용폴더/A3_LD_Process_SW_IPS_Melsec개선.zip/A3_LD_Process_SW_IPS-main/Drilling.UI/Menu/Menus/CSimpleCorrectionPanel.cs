﻿using System.ComponentModel;
using System.Globalization;
using System.Windows;
using System.Windows.Media;
using Drilling.Common.Managers;
using Drilling.Common.Recipe;
using Drilling.Common.Review;

namespace Drilling.UI.Menu.Menus;

/// <summary>SIMPLE correction selection, design-coordinate drafts, and recipe preview. Does not control motion.</summary>
public sealed class CSimpleCorrectionPanel : INotifyPropertyChanged
{
    private IReadOnlyDictionary<string, string> _parameters = new Dictionary<string, string>();
    private IReadOnlyDictionary<int, ST_SIMPLE_CORRECTION_SHOT[]> _cells = new Dictionary<int, ST_SIMPLE_CORRECTION_SHOT[]>();
    private IReadOnlySet<int> _enabledHeads = new HashSet<int>();
    private IReadOnlyDictionary<string, string> _assignment = new Dictionary<string, string>();
    private ST_PREVIEW_HEAD_LAYOUT _headLayout = CHeadAssignmentPreviewBuilder.BuildHeadLayout([]);
    private int _selectedHead;
    private int _selectedCell;
    private string _selectedScope = "HEAD";
    private string _selectedCorrectionShotKey = "";
    private IReadOnlySet<string> _referenceShotKeys = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, CSimpleCorrectionInput> _inputDrafts = new(StringComparer.OrdinalIgnoreCase);
    private double _viewportWidth = 780;
    private double _viewportHeight = 565;
    private readonly Func<string, Task>? _executeOffsetAction;
    public bool IsOffsetOperationRunning { get; private set; }
    public event PropertyChangedEventHandler? PropertyChanged;

    public CSimpleCorrectionPanel(Func<string, Task>? executeOffsetAction = null, bool isRough = false)
    {
        if (isRough) Inspection = new CRoughCorrectionPanel(this);
        _executeOffsetAction = executeOffsetAction;
        SelectCellCommand = new(SelectCell, _ => !IsOffsetOperationRunning);
        SelectHeadCommand = new(SelectHead, _ => !IsOffsetOperationRunning);
        SelectScopeCommand = new(SelectScope, _ => !IsOffsetOperationRunning);
        SelectCorrectionShotCommand = new(SelectCorrectionShot, _ => !IsOffsetOperationRunning);
        OffsetActionCommand = new(RunOffsetAction, action => _executeOffsetAction is not null && (Inspection is not null
            ? Inspection.CanExecute(action?.ToString() ?? "") : !IsOffsetOperationRunning &&
            (action?.ToString() == "OFFSET_VIEW" ? RecipeId.Length > 0 :
                action?.ToString() is "OFFSET_APPLY" or "OFFSET_INIT" && CorrectionRows.Count == 1)));
        BackToGlassCommand = new(_ => ShowGlass());
        UpdateHeads();
    }

    public CButtonCommand SelectCellCommand { get; }
    public CButtonCommand SelectHeadCommand { get; }
    public int SelectedHeadNo => _selectedHead;
    public CButtonCommand SelectScopeCommand { get; }
    public CButtonCommand SelectCorrectionShotCommand { get; }
    public CButtonCommand OffsetActionCommand { get; }
    public CRoughCorrectionPanel? Inspection { get; }
    public CReviewCameraPreview Camera { get; } = new();
    public void RefreshFeedback() => Inspection?.RefreshFeedback();
    public bool IsRough => Inspection is not null;
    public bool IsSimple => !IsRough;
    public bool IsHeadScope => _selectedScope == "HEAD";
    public bool IsHeadCellScope => _selectedScope == "HEAD_CELL";
    public IReadOnlyList<ST_SIMPLE_CORRECTION_FIRST_SHOT> FirstShotRows { get; private set; } = [];
    public IReadOnlyList<ST_SIMPLE_CORRECTION_CALLOUT> FirstShotCallouts { get; private set; } = [];
    public IReadOnlyList<CSimpleCorrectionInput> CorrectionRows { get; private set; } = [];
    public Visibility CorrectionEmptyVisibility => CorrectionRows.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
    public string CorrectionEmptyText => _selectedHead == 0 ? "Head를 선택해 주세요."
        : _referenceShotKeys.Count == 0 ? "실제로 가공하는 기준 Shot이 없습니다." : "프리뷰의 Shot 박스를 선택해 주세요.";
    public CButtonCommand BackToGlassCommand { get; }
    public string RecipeName { get; private set; } = "-";
    public string RecipeId { get; private set; } = "";
    public string ErrorText { get; private set; } = "";
    public ImageSource? PreviewImage { get; private set; }
    public ST_GLASS_PREVIEW_FRAME GlassFrame { get; private set; } = new(44, 62, 772, 420);
    public double PreviewContentWidth { get; private set; } = 780;
    public double PreviewContentHeight { get; private set; } = 565;
    public Transform PreviewTransform { get; private set; } = Transform.Identity;

    public void ResizePreview(double width, double height)
    {
        if (!double.IsFinite(width) || !double.IsFinite(height) || width <= 0 || height <= 0 ||
            Math.Abs(width - _viewportWidth) < 0.5 && Math.Abs(height - _viewportHeight) < 0.5) return;
        _viewportWidth = width;
        _viewportHeight = height;
        RefreshCallouts();
        Notify();
    }
    public IReadOnlyList<ST_CELL_PREVIEW_LABEL> CellLabels { get; private set; } = [];
    public IReadOnlyList<ST_SIMPLE_CORRECTION_HEAD> HeadSelections { get; private set; } = [];
    public IReadOnlyList<ST_SIMPLE_CORRECTION_SHOT_ROW> ShotRows { get; private set; } = [];
    public Visibility GlassVisibility => _selectedCell == 0 ? Visibility.Visible : Visibility.Collapsed;
    public Visibility CellVisibility => _selectedCell > 0 ? Visibility.Visible : Visibility.Collapsed;
    public string PreviewTitle => _selectedCell > 0 ? $"HEAD {_selectedHead:00} / CELL {_selectedCell:00} / SHOT" : "GLASS PREVIEW";
    public Visibility SelectHeadHintVisibility => _selectedHead == 0 ? Visibility.Visible : Visibility.Collapsed;
    public string Summary { get; private set; } = "현재 레시피를 선택해 주세요.";
    public string CellSummary { get; private set; } = "";

    public void Update(ST_RECIPE_DEFINITION? recipe, IReadOnlyList<ST_SYSTEM_PARAMETER> settings, ST_REVIEW_OFFSET_FILE_DATA? currentOffsets = null)
    {
        if (recipe is null) { Clear("현재 레시피를 찾을 수 없습니다."); return; }
        var parameters = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var item in recipe.Parameters.Where(item => !string.IsNullOrWhiteSpace(item.Key))) parameters[item.Key] = item.Value;
        foreach (var item in settings.Where(item => !string.IsNullOrWhiteSpace(item.Key))) parameters[item.Key] = item.Value;
        if (currentOffsets is not null)
        {
            if (!string.Equals(currentOffsets.RecipeId, recipe.Id, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Current Review Offset recipe does not match the preview recipe.");
            CMenuCorrection.ApplyReviewOffsetsToOutputViewerParameters(parameters, currentOffsets);
        }
        if (RecipeId == recipe.Id && RecipeName == recipe.Name && ErrorText.Length == 0 &&
            _parameters.Count == parameters.Count && parameters.All(item => _parameters.GetValueOrDefault(item.Key) == item.Value)) return;

        var assignment = new Dictionary<string, string>(parameters, StringComparer.OrdinalIgnoreCase) { ["HEAD_COUNT"] = "8" };
        _enabledHeads = CHeadAssignmentPreviewBuilder.BuildEnabledHeadNumbers(parameters).ToHashSet();
        // Keep physical assignment visible for all eight Heads, including NOT USE Heads.
        for (var head = 1; head <= 8; head++) assignment[$"H{head:00}_USE"] = "ON";
        var plan = CShotCoordinatePlanBuilder.Build(assignment);
        var masking = CRecipeShotMaskingPlan.Build(assignment);
        var assigned = plan.Shots.ToDictionary(shot => shot.ShotKey, StringComparer.OrdinalIgnoreCase);
        var cells = CShotCoordinatePlanBuilder.BuildDesignShots(assignment).GroupBy(shot => shot.CellNo).ToDictionary(group => group.Key, group => group.Select(shot =>
        {
            var point = assigned.GetValueOrDefault(shot.ShotKey) ?? CreateUnassignedPoint(shot);
            var mask = masking.EvaluateShot(point);
            var reasons = new List<string>();
            if (mask.IsChessSkipped) reasons.Add("CHESS");
            if (mask.IsMasked) reasons.Add("MASKING");
            if (point.HeadNo == 0) reasons.Add("UNASSIGNED");
            else if (!_enabledHeads.Contains(point.HeadNo)) reasons.Add("HEAD OFF");
            return new ST_SIMPLE_CORRECTION_SHOT(shot.ShotKey,
                CReviewShotNameFormatter.ToMatrixName(shot.CellShotNo, shot.GroupCountX), point.HeadNo,
                shot.GroupColumn, shot.GroupRow, reasons.Count == 0, reasons.Count == 0 ? "PROCESS" : string.Join(" / ", reasons),
                mask.IsChessSkipped, mask.IsMasked) { CellNo = shot.CellNo, SequenceNo = point.SequenceNo,
                    DesignX = shot.DesignX, DesignY = shot.DesignY, CellShotNo = shot.CellShotNo, GroupCountX = shot.GroupCountX, GroupCountY = shot.GroupCountY };
        }).OrderBy(shot => shot.Row).ThenBy(shot => shot.Column).ToArray());
        if (RecipeId != recipe.Id) { _selectedHead = 0; _selectedCell = 0; _selectedCorrectionShotKey = ""; _inputDrafts.Clear(); }
        if (!cells.ContainsKey(_selectedCell)) _selectedCell = 0;
        RecipeId = recipe.Id;
        RecipeName = recipe.Name;
        _parameters = parameters;
        _cells = cells;
        Inspection?.UpdateSource(recipe, parameters);
        _assignment = assignment;
        _headLayout = CHeadAssignmentPreviewBuilder.BuildHeadLayout(settings);
        ErrorText = "";
        RefreshHeadPreview();
        UpdateCell();
        Notify();
    }

    public void Clear(string message)
    {
        _parameters = new Dictionary<string, string>();
        _inputDrafts.Clear();
        _selectedCorrectionShotKey = "";
        _cells = new Dictionary<int, ST_SIMPLE_CORRECTION_SHOT[]>();
        _enabledHeads = new HashSet<int>();
        _selectedCell = 0;
        _selectedHead = 0;
        _assignment = new Dictionary<string, string>();
        RecipeId = "";
        RecipeName = "-";
        PreviewImage = null;
        CellLabels = [];
        ShotRows = [];
        ErrorText = message;
        Summary = message;
        CellSummary = "";
        Inspection?.Clear();
        Camera.Clear();
        RefreshReferenceShots();
        UpdateHeads();
        Notify();
    }

    private void SelectHead(object? value)
    {
        if (!int.TryParse(value?.ToString(), NumberStyles.Integer, CultureInfo.InvariantCulture, out var head) || head is < 1 or > 8 || head == _selectedHead) return;
        _selectedHead = head;
        _selectedCell = 0;
        _selectedCorrectionShotKey = "";
        if (_assignment.Count > 0) RefreshHeadPreview();
        UpdateCell();
        Notify();
    }

    private void SelectScope(object? value)
    {
        var scope = value?.ToString()?.Trim().ToUpperInvariant();
        if (scope is not ("HEAD" or "HEAD_CELL") || scope == _selectedScope) return;
        _selectedScope = scope;
        _selectedCorrectionShotKey = "";
        UpdateCell();
        Notify();
    }

    private void SelectCorrectionShot(object? value)
    {
        if (IsRough) return;
        var key = value?.ToString() ?? "";
        if (!_referenceShotKeys.Contains(key)) return;
        _selectedCorrectionShotKey = key;
        RefreshCorrectionRows();
        RefreshCallouts();
        Notify();
    }

    private async void RunOffsetAction(object? value)
    {
        if (!OffsetActionCommand.CanExecute(value)) return;
        await _executeOffsetAction!(value?.ToString() ?? "");
    }

    public void SetOffsetOperationRunning(bool running)
    {
        IsOffsetOperationRunning = running;
        SelectCellCommand.NotifyCanExecuteChanged();
        SelectHeadCommand.NotifyCanExecuteChanged();
        SelectScopeCommand.NotifyCanExecuteChanged();
        SelectCorrectionShotCommand.NotifyCanExecuteChanged();
        Notify();
    }

    public ST_SIMPLE_OFFSET_CHANGE CreateOffsetChange(bool initialize)
    {
        var input = CorrectionRows.SingleOrDefault() ?? throw new InvalidOperationException("프리뷰의 Shot 박스를 선택해 주세요.");
        var x = initialize ? 0 : double.Parse(input.InputX, CultureInfo.InvariantCulture);
        var y = initialize ? 0 : double.Parse(input.InputY, CultureInfo.InvariantCulture);
        var rows = _cells.Values.SelectMany(shots => shots)
            .Where(shot => shot.HeadNo == _selectedHead && (IsHeadScope || shot.CellNo == input.CellNo))
            .Select(shot => new ST_REVIEW_OFFSET_ROW(shot.CellNo, shot.Name, x, y) { IsDesignCoordinate = true }).ToArray();
        if (rows.Length == 0) throw new InvalidOperationException("적용할 Shot이 없습니다.");
        return new(RecipeId, _selectedHead, IsHeadScope ? 0 : input.CellNo, x, y, rows,
            _parameters.Where(item => !item.Key.Contains("REVIEW_OFFSET", StringComparison.OrdinalIgnoreCase))
                .ToDictionary(item => item.Key, item => item.Value, StringComparer.OrdinalIgnoreCase));
    }

    public void AcceptSavedOffsets(ST_REVIEW_OFFSET_FILE_DATA saved, IReadOnlyList<ST_REVIEW_OFFSET_ROW> changed,
        ST_RECIPE_DEFINITION recipe, IReadOnlyList<ST_SYSTEM_PARAMETER> settings)
    {
        if (!RecipeId.Equals(saved.RecipeId, StringComparison.OrdinalIgnoreCase)) return;
        var affected = changed.Select(row => (row.CellId, row.ShotId.ToUpperInvariant())).ToHashSet();
        foreach (var key in _inputDrafts.Where(item => affected.Contains((item.Value.CellNo, item.Value.ShotName.ToUpperInvariant())))
            .Select(item => item.Key).ToArray()) _inputDrafts.Remove(key);
        // Offset changes may affect scanner ordering, so rebuild the actual first-Shot references as well.
        Update(recipe, settings, saved);
        RefreshCorrectionRows();
        Notify();
    }

    private void RefreshReferenceShots()
    {
        if (_selectedHead == 0)
        {
            FirstShotRows = []; _referenceShotKeys = new HashSet<string>();
            _selectedCorrectionShotKey = "";
            CorrectionRows = [];
            Inspection?.SyncTargets([], [], _parameters);
            RefreshCallouts();
            return;
        }
        // SequenceNo is assigned by the common machining plan, including Stage direction and scanner-axis ordering.
        // Do not infer the first processing Shot from Cell number or the displayed row/column order.
        var headShots = _cells.Values.SelectMany(shots => shots).Where(shot => shot.HeadNo == _selectedHead).ToArray();
        static ST_SIMPLE_CORRECTION_FIRST_SHOT First(int cellNo, IEnumerable<ST_SIMPLE_CORRECTION_SHOT> shots)
        {
            var first = shots.Where(shot => shot.CanProcess).MinBy(shot => shot.SequenceNo);
            return new(first?.CellNo ?? cellNo, first?.Key ?? "", first?.Name ?? "");
        }
        FirstShotRows = IsHeadScope ? [First(0, headShots)] : headShots.GroupBy(shot => shot.CellNo).OrderBy(cell => cell.Key)
            .Select(cell => First(cell.Key, cell)).ToArray();
        _referenceShotKeys = FirstShotRows.Where(row => row.ShotKey.Length > 0).Select(row => row.ShotKey).ToHashSet(StringComparer.OrdinalIgnoreCase);
        Inspection?.SyncTargets(FirstShotRows, _cells.Values.SelectMany(shots => shots).Where(shot => shot.HeadNo == _selectedHead).ToArray(), _parameters);
        RefreshCorrectionRows();
        RefreshCallouts();
    }

    private void RefreshCorrectionRows()
    {
        if (!_referenceShotKeys.Contains(_selectedCorrectionShotKey)) _selectedCorrectionShotKey = "";
        CorrectionRows = FirstShotRows.Where(row => row.ShotKey.Length > 0 &&
            string.Equals(row.ShotKey, _selectedCorrectionShotKey, StringComparison.OrdinalIgnoreCase)).Select(row =>
        {
            var key = $"{_selectedScope}/{_selectedHead}/{row.ShotKey}";
            if (!_inputDrafts.TryGetValue(key, out var input))
            {
                input = new CSimpleCorrectionInput(_selectedHead, row.CellNo, row.ShotKey, row.ShotName);
                _inputDrafts.Add(key, input);
            }
            double Current(string axis)
            {
                var raw = _parameters.GetValueOrDefault($"CELL{row.CellNo}_{row.ShotName}_REVIEW_OFFSET_{axis}",
                    _parameters.GetValueOrDefault($"REVIEW_OFFSET_{axis}", "0"));
                if (!double.TryParse(raw, NumberStyles.Float, CultureInfo.InvariantCulture, out var value) || !double.IsFinite(value))
                    throw new InvalidOperationException($"Cell{row.CellNo:00}-{row.ShotName}의 현재 {axis} 보정값이 올바르지 않습니다.");
                return value;
            }
            var design = CReviewOffsetData.ToDesign(_parameters, _selectedHead, Current("X"), Current("Y"),
                CReviewOffsetData.IsDesignCoordinate(_parameters, $"CELL{row.CellNo}_{row.ShotName}_REVIEW_OFFSET_"));
            input.UpdateCurrent(design.X, design.Y);
            return input;
        }).ToArray();
    }

    private void RefreshCallouts()
    {
        var labels = CellLabels.ToDictionary(label => label.CellNo);
        var references = FirstShotRows.Where(row => row.ShotKey.Length > 0 && labels.ContainsKey(row.CellNo))
            .OrderBy(row => labels[row.CellNo].CanvasCenterX).ThenBy(row => labels[row.CellNo].CanvasCenterY).ToArray();
        // Balance both sides even when all selected Cells lie in the same half of the Glass.
        var leftCount = references.Length == 1
            ? (labels[references[0].CellNo].CanvasCenterX <= GlassFrame.CanvasLeft + GlassFrame.Width / 2 ? 1 : 0)
            : (references.Length + 1) / 2;
        var left = references.Take(leftCount).ToArray();
        var right = references.Skip(leftCount).ToArray();
        const double labelHeight = 28, rowSpacing = 34, columnGap = 10, edgeGap = 22, margin = 12;
        var labelWidth = Math.Clamp(references.Select(row => $"Cell{row.CellNo:00}-{row.ShotName}".Length * 7.5 + 18).DefaultIfEmpty(88).Max(), 88, 132);
        var sideCount = (left.Length > 0 ? 1 : 0) + (right.Length > 0 ? 1 : 0);
        var rowCapacity = Math.Max(1, (int)Math.Floor((_viewportHeight - 2 * margin) / rowSpacing));
        var maxColumns = sideCount == 0 ? 1 : Math.Max(1, (int)Math.Floor(
            ((_viewportWidth - 120) / sideCount - edgeGap - margin + columnGap) / (labelWidth + columnGap)));
        int Columns(int count) => count == 0 ? 0 : Math.Min(maxColumns, (count + rowCapacity - 1) / rowCapacity);
        var leftColumns = Columns(left.Length);
        var rightColumns = Columns(right.Length);
        int Rows(int count, int columns) => columns == 0 ? 0 : (count + columns - 1) / columns;
        double Gutter(int columns) => margin + (columns == 0 ? 0 : columns * labelWidth + (columns - 1) * columnGap + edgeGap);
        var leftGutter = Gutter(leftColumns);
        var rightGutter = Gutter(rightColumns);
        // A very short/narrow viewport scrolls instead of compressing every label and the Glass into unreadable text.
        PreviewContentWidth = Math.Max(_viewportWidth, leftGutter + rightGutter + 120);
        PreviewContentHeight = Math.Max(_viewportHeight, Math.Max(Rows(left.Length, leftColumns), Rows(right.Length, rightColumns)) * rowSpacing + 2 * margin);
        var availableWidth = PreviewContentWidth - leftGutter - rightGutter;
        var scale = Math.Min(availableWidth / GlassFrame.Width, (PreviewContentHeight - 2 * margin) / GlassFrame.Height);
        var glassLeft = leftGutter + (availableWidth - GlassFrame.Width * scale) / 2;
        var glassTop = (PreviewContentHeight - GlassFrame.Height * scale) / 2;
        var transform = new MatrixTransform(scale, 0, 0, scale,
            glassLeft - GlassFrame.CanvasLeft * scale, glassTop - GlassFrame.CanvasTop * scale);
        transform.Freeze();
        PreviewTransform = transform;
        var frame = transform.TransformBounds(new Rect(GlassFrame.CanvasLeft, GlassFrame.CanvasTop, GlassFrame.Width, GlassFrame.Height));
        if (IsRough) Camera.Configure(_parameters, frame);
        var result = new List<ST_SIMPLE_CORRECTION_CALLOUT>();
        AddSide(left, true, leftColumns);
        AddSide(right, false, rightColumns);
        FirstShotCallouts = result;

        void AddSide(ST_SIMPLE_CORRECTION_FIRST_SHOT[] side, bool isLeft, int columns)
        {
            if (columns == 0) return;
            var ordered = side.OrderBy(row => labels[row.CellNo].CanvasCenterY).ThenBy(row => labels[row.CellNo].CanvasCenterX).ThenBy(row => row.CellNo).ToArray();
            var rows = Rows(ordered.Length, columns);
            var centers = Enumerable.Range(0, rows).Select(row => ordered.Skip(row * columns).Take(columns)
                .Average(item => transform.Transform(new Point(labels[item.CellNo].CanvasCenterX, labels[item.CellNo].CanvasCenterY)).Y)).ToArray();
            var top = margin + labelHeight / 2;
            var bottom = PreviewContentHeight - margin - labelHeight / 2;
            for (var row = 0; row < rows; row++) centers[row] = Math.Max(Math.Clamp(centers[row], top, bottom), row == 0 ? top : centers[row - 1] + rowSpacing);
            for (var row = rows - 1; row >= 0; row--) centers[row] = Math.Min(centers[row], row == rows - 1 ? bottom : centers[row + 1] - rowSpacing);
            for (var index = 0; index < ordered.Length; index++)
            {
                var item = ordered[index];
                var cell = labels[item.CellNo];
                var column = index % columns;
                var center = centers[index / columns];
                var point = transform.Transform(new Point(cell.CanvasCenterX, cell.CanvasCenterY));
                var bounds = cell.CellBounds.IsEmpty ? new Rect(point.X - 3, point.Y - 3, 6, 6) : transform.TransformBounds(cell.CellBounds);
                bounds.Inflate(2, 2);
                var labelLeft = isLeft ? frame.Left - edgeGap - labelWidth - column * (labelWidth + columnGap)
                    : frame.Right + edgeGap + column * (labelWidth + columnGap);
                var labelEdge = isLeft ? labelLeft + labelWidth : labelLeft;
                var elbow = isLeft ? frame.Left - 8 - column * 3 : frame.Right + 8 + column * 3;
                var approach = labelEdge + (isLeft ? columnGap / 2 : -columnGap / 2);
                // Outer-column leaders pass through the gap above the row, rather than through the inner label boxes.
                var busY = center - labelHeight / 2 - 3;
                var line = new PointCollection
                {
                    new(isLeft ? bounds.Left : bounds.Right, point.Y), new(elbow, point.Y),
                    new(elbow, busY), new(approach, busY), new(approach, center), new(labelEdge, center)
                };
                line.Freeze();
                result.Add(new(item.CellNo, item.ShotKey, item.ShotName, bounds, line, labelLeft, center - labelHeight / 2, labelWidth, labelHeight)
                    { IsSelected = !IsRough && string.Equals(item.ShotKey, _selectedCorrectionShotKey, StringComparison.OrdinalIgnoreCase),
                        InspectionState = Inspection?.FindRow(item.ShotKey)?.State ?? "",
                        InspectionBrush = Inspection?.FindRow(item.ShotKey)?.StateBrush });
            }
        }
    }

    private void RefreshHeadPreview()
    {
        var visibleCells = _cells.Where(cell => cell.Value.Any(shot => shot.HeadNo == _selectedHead && _selectedHead > 0))
            .Select(cell => cell.Key).ToHashSet();
        if (!visibleCells.Contains(_selectedCell)) _selectedCell = 0;
        var preview = CHeadAssignmentPreviewBuilder.BuildRecipePreview(_assignment, new HashSet<int>(), _headLayout,
            showKeys: false, visibleCellNos: visibleCells);
        if (!string.IsNullOrEmpty(preview.ValidationMessage)) throw new InvalidOperationException(preview.ValidationMessage);
        PreviewImage = preview.Image;
        GlassFrame = preview.Frame;
        CellLabels = preview.CellLabels.Select(label => label with { Width = Math.Min(label.Width, 24) }).ToArray();
        Summary = _selectedHead == 0 ? "Head를 선택해 주세요." : $"HEAD {_selectedHead:00} / {visibleCells.Count:N0} Cells / " +
            $"{_cells.Values.SelectMany(shots => shots).Count(shot => shot.HeadNo == _selectedHead && shot.CanProcess):N0} Process Shots";
    }

    private void SelectCell(object? value)
    {
        if (IsRough) return;
        if (!int.TryParse(value?.ToString(), NumberStyles.Integer, CultureInfo.InvariantCulture, out var cell) ||
            _selectedHead == 0 || !CellLabels.Any(label => label.CellNo == cell)) return;
        _selectedCell = cell;
        UpdateCell();
        Notify();
    }

    private void ShowGlass()
    {
        _selectedCell = 0;
        UpdateCell();
        Notify();
    }

    private void UpdateCell()
    {
        RefreshReferenceShots();
        var shots = (_cells.GetValueOrDefault(_selectedCell) ?? []).Where(shot => shot.HeadNo == _selectedHead)
            .Select(shot => shot with { IsReference = _referenceShotKeys.Contains(shot.Key) }).ToArray();
        ShotRows = shots.GroupBy(shot => shot.Row).OrderBy(group => group.Key)
            .Select(group => new ST_SIMPLE_CORRECTION_SHOT_ROW(group.Key, group.OrderBy(shot => shot.Column).ToArray())).ToArray();
        CellSummary = _selectedCell > 0 ? $"{shots.Count(shot => shot.CanProcess):N0} Process / {shots.Length:N0} Shots · 기준 Shot: 파랑 / CHESS: 보라 / MASKING: 빨강" : "";
        UpdateHeads();
    }

    private void UpdateHeads()
    {
        var all = _cells.Values.SelectMany(shots => shots).Where(shot => shot.CanProcess).ToArray();
        HeadSelections = Enumerable.Range(1, 8).Select(head => new ST_SIMPLE_CORRECTION_HEAD(head,
            all.Count(shot => shot.HeadNo == head), _enabledHeads.Contains(head),
            _selectedHead == head)).ToArray();
    }

    // Retain the design model even when no physical Head covers some coordinates.
    private static ST_HEAD_SHOT_POINT CreateUnassignedPoint(ST_DESIGN_SHOT_POINT shot) => new(
        SequenceNo: 0, ShotKey: shot.ShotKey, HeadNo: 0, CellNo: shot.CellNo, CellShotNo: shot.CellShotNo,
        GroupColumn: shot.GroupColumn, GroupRow: shot.GroupRow, GroupCountX: shot.GroupCountX, GroupCountY: shot.GroupCountY,
        DesignX: shot.DesignX, DesignY: shot.DesignY, ScannerGx: 0, ScannerGy: 0, StageX: 0, StageY: 0,
        RecipeOffsetX: shot.RecipeOffsetX, RecipeOffsetY: shot.RecipeOffsetY,
        HeadDefaultOffsetX: 0, HeadDefaultOffsetY: 0, FirstBeamOffsetX: 0, FirstBeamOffsetY: 0,
        ReviewOffsetX: shot.ReviewOffsetX, ReviewOffsetY: shot.ReviewOffsetY,
        ShiftOffsetX: 0, ShiftOffsetY: 0, ShiftScannerOffsetX: 0, ShiftScannerOffsetY: 0,
        FinalScannerOffsetX: shot.RecipeOffsetX + shot.ReviewOffsetX + shot.AlignOffsetX,
        FinalScannerOffsetY: shot.RecipeOffsetY + shot.ReviewOffsetY + shot.AlignOffsetY, EncoderWaitPosition: 0);

    private void Notify()
    {
        OffsetActionCommand.NotifyCanExecuteChanged();
        PropertyChanged?.Invoke(this, new(null));
    }
    public void RefreshInspectionDisplay() { RefreshCallouts(); Notify(); }
}

public sealed record ST_SIMPLE_CORRECTION_HEAD(int HeadNo, int ShotCount, bool IsEnabled, bool IsSelected)
{
    public string Name => $"HEAD {HeadNo:00}";
    public string Detail => IsEnabled ? $"{ShotCount:N0} Shots" : "NOT USE";
}
public sealed record ST_SIMPLE_CORRECTION_SHOT(string Key, string Name, int HeadNo, int Column, int Row, bool CanProcess, string State, bool IsChessSkipped, bool IsMasked)
{
    public string Head => HeadNo > 0 ? $"H{HeadNo:00}" : "-";
    public int CellNo { get; init; }
    public int SequenceNo { get; init; }
    public bool IsReference { get; init; }
    public double DesignX { get; init; }
    public double DesignY { get; init; }
    public int CellShotNo { get; init; }
    public int GroupCountX { get; init; }
    public int GroupCountY { get; init; }
}
public sealed record ST_SIMPLE_CORRECTION_SHOT_ROW(int Row, IReadOnlyList<ST_SIMPLE_CORRECTION_SHOT> Shots);

public sealed record ST_SIMPLE_CORRECTION_FIRST_SHOT(int CellNo, string ShotKey, string ShotName)
{
    public string Cell => CellNo > 0 ? $"CELL {CellNo:00}" : "-";
    public string Shot => ShotKey.Length > 0 ? ShotName : "가공 Shot 없음";
}

public sealed record ST_SIMPLE_CORRECTION_CALLOUT(int CellNo, string ShotKey, string ShotName, Rect CellBounds,
    PointCollection LeaderPoints, double LabelLeft, double LabelTop, double LabelWidth, double LabelHeight)
{
    public bool IsSelected { get; init; }
    public string InspectionState { get; init; } = "";
    public Brush? InspectionBrush { get; init; }
    public bool HasInspectionState => InspectionState.Length > 0;
    public string Detail => $"CELL {CellNo:00} / SHOT {ShotName}";
    public string Label => $"Cell{CellNo:00}-{ShotName}";
}

/// <summary>Per-scope edit draft. Changing an input never writes a recipe or applies motion.</summary>
public sealed class CSimpleCorrectionInput(int headNo, int cellNo, string shotKey, string shotName) : INotifyPropertyChanged
{
    private string _inputX = "0.000", _inputY = "0.000";
    private bool _editedX, _editedY;
    public event PropertyChangedEventHandler? PropertyChanged;
    public int HeadNo { get; } = headNo;
    public int CellNo { get; } = cellNo;
    public string ShotKey { get; } = shotKey;
    public string ShotName { get; } = shotName;
    public string Title { get; } = $"Cell{cellNo:00}-{shotName}";
    public string CurrentX { get; private set; } = "0.000";
    public string CurrentY { get; private set; } = "0.000";
    public string InputX { get => _inputX; set { _inputX = Normalize(value); _editedX = true; Notify(); } }
    public string InputY { get => _inputY; set { _inputY = Normalize(value); _editedY = true; Notify(); } }

    public void UpdateCurrent(double x, double y)
    {
        var currentX = Format(x);
        var currentY = Format(y);
        if (CurrentX == currentX && CurrentY == currentY) return;
        CurrentX = currentX;
        CurrentY = currentY;
        if (!_editedX) _inputX = currentX;
        if (!_editedY) _inputY = currentY;
        Notify();
    }
    private static string Normalize(string input)
    {
        if (!double.TryParse(input, NumberStyles.Float, CultureInfo.InvariantCulture, out var value) || !double.IsFinite(value))
            throw new ArgumentException("유한한 숫자를 입력해 주세요.", nameof(input));
        return Format(value);
    }
    private static string Format(double value) => Math.Round(value, 3, MidpointRounding.AwayFromZero).ToString("0.000", CultureInfo.InvariantCulture);
    private void Notify() => PropertyChanged?.Invoke(this, new(null));
}

public sealed record ST_SIMPLE_OFFSET_CHANGE(string RecipeId, int HeadNo, int CellNo, double X, double Y,
    IReadOnlyList<ST_REVIEW_OFFSET_ROW> Rows, IReadOnlyDictionary<string, string> SourceParameters)
{
    public string Scope => CellNo == 0 ? $"HEAD {HeadNo:00} 전체" : $"HEAD {HeadNo:00} / Cell{CellNo:00}";
}
