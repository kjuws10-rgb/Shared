using Drilling.UI.Popup;
using Drilling.Common.Interface;
using Drilling.File.PowerTable;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuManual
{
    private CManualPowerMeasurePanel? _powerMeasurePanel;
    public CManualPowerMeasurePanel PowerMeasurePanel
    {
        get
        {
            if (_powerMeasurePanel is not null) return _powerMeasurePanel;
            _powerMeasurePanel = new(_manager.PowerMeasure, () => _manager.Interface().GetInterfaceList(EN_EQP_MODULE.PowerMeter),
                new CPowerTableFile(_manager.ConfigRoot, simulation: true),
                message => CRecipeConfirmDialog.ShowWarning("PowerMeasure", message),
                message => CRecipeConfirmDialog.ShowConfirmation("PowerMeasure", message),
                () => CMotorStatusPollingService.ReadCachedSnapshot(_manager.Interface()),
                () => CMotorStatusPollingService.ReadStageConnectionState(_manager.Interface()),
                stageSimulation: _manager.Interface().GetStageMotionSimulation());
            _powerMeasurePanel.RunningChanged += () =>
            {
                SelectHeadCommand.NotifyCanExecuteChanged();
                SelectManualHeadsCommand.NotifyCanExecuteChanged();
            };
            _powerMeasurePanel.UpdateHeads(SelectedManualHeadNos);
            return _powerMeasurePanel;
        }
    }
    private void RefreshPowerMeasurePanel() => _powerMeasurePanel?.UpdateHeads(SelectedManualHeadNos);
}
