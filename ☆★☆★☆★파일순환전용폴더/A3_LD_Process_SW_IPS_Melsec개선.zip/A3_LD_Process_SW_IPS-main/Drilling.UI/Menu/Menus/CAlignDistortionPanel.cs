using System.ComponentModel;
using System.Globalization;
using System.Windows;
using System.Windows.Media;
using Drilling.Common.Managers;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CAlignDistortionPanel : INotifyPropertyChanged
{
    public const double CanvasWidth = 940;
    public const double CanvasHeight = 700;
    private static readonly SolidColorBrush SelectedDkBrush = MakeBrush(32, 161, 88);
    private static readonly SolidColorBrush UnselectedDkBrush = MakeBrush(128, 138, 148);
    private string _signature = "";
    private Rect _glassFrame;
    private IReadOnlyDictionary<string, (double X, double Y)> _lastLoadedPositions = new Dictionary<string, (double, double)>();
    private bool _baseActionRunning;
    private readonly Func<string, Task>? _executeBaseAction;

    public CAlignDistortionPanel(Func<string, Task>? executeBaseAction = null)
    {
        _executeBaseAction = executeBaseAction;
        BaseActionCommand = new CButtonCommand(RunBaseAction,
            action => executeBaseAction is not null && !_baseActionRunning &&
                (action?.ToString() is "REFRESH" or "LOAD" || (Keys.Count == 10 && !string.IsNullOrEmpty(RecipeId))));
        LoadCommand = new CButtonCommand(_ => RunBaseAction("LOAD"));
    }

    private async void RunBaseAction(object? parameter)
    {
        if (!BaseActionCommand.CanExecute(parameter)) return;
        _baseActionRunning = true;
        BaseActionCommand.NotifyCanExecuteChanged();
        try { await _executeBaseAction!(parameter?.ToString() ?? ""); }
        finally
        {
            _baseActionRunning = false;
            BaseActionCommand.NotifyCanExecuteChanged();
        }
    }

    public CButtonCommand BaseActionCommand { get; }
    public CButtonCommand LoadCommand { get; }
    public IReadOnlyList<CAlignDistortionDkSelection> DkSelections { get; private set; } = [];
    public event PropertyChangedEventHandler? PropertyChanged;
    public ImageSource? PreviewImage { get; private set; }
    public IReadOnlyList<ST_ALIGN_DISTORTION_KEY> Keys { get; private set; } = [];
    public string Summary { get; private set; } = "Recipe not loaded";
    public string RecipeName { get; private set; } = "-";
    public string RecipeId { get; private set; } = "";
    public double PreviewHeight { get; private set; } = CanvasHeight;
    public DateTimeOffset? LastLoadedAt { get; private set; }
    public string LastLoadTime => LastLoadedAt?.ToString("yyMMdd-HH:mm:ss", CultureInfo.InvariantCulture) ?? "-";
    public bool LastLoadIsSimulation { get; private set; }
    public IReadOnlyList<string> LoadKeyNames => CAlignBaseData.KeyNames
        .Where(name => name.StartsWith("AK", StringComparison.Ordinal) || IsDkSelected(name)).ToArray();
    public IReadOnlyList<string> LoadParameterKeys => LoadKeyNames
        .SelectMany(name => new[] { $"ALIGNBASE_{name}_X", $"ALIGNBASE_{name}_Y" }).ToArray();
    public string LoadSelectionSignature => RecipeId + "|" + string.Join("|", Keys.Where(key => LoadKeyNames.Contains(key.Name))
        .Select(key => FormattableString.Invariant($"{key.Name}:{key.GlassX:R},{key.GlassY:R}")));

    // Publish a complete, successful one-shot read together with its completion time.
    public void ApplyLastLoad(string recipeId, IReadOnlyDictionary<string, double> values, DateTimeOffset loadedAt,
        IReadOnlyCollection<string>? expectedParameterKeys = null, bool isSimulation = false)
    {
        if (!RecipeId.Equals(recipeId, StringComparison.OrdinalIgnoreCase) || Keys.Count != 10)
            throw new InvalidOperationException("현재 레시피와 LastLoad 대상이 일치하지 않습니다.");
        var expected = expectedParameterKeys ?? CAlignBaseData.ParameterKeys;
        if (expected.Count == 0 || expected.Any(key => !CAlignBaseData.ParameterKeys.Contains(key)) ||
            expected.Distinct(StringComparer.Ordinal).Count() != expected.Count || values.Count != expected.Count ||
            expected.Any(key => !values.TryGetValue(key, out var value) || !double.IsFinite(value)))
            throw new InvalidOperationException("선택한 키의 LastLoad X/Y 값을 모두 정상적으로 읽어야 합니다.");
        Keys = Keys.Select(key => key with
        {
            LastLoadX = values.TryGetValue($"ALIGNBASE_{key.Name}_X", out var x) ? x.ToString("0.000", CultureInfo.InvariantCulture) : "-",
            LastLoadY = values.TryGetValue($"ALIGNBASE_{key.Name}_Y", out var y) ? y.ToString("0.000", CultureInfo.InvariantCulture) : "-",
            LastLoadRawX = values.TryGetValue($"ALIGNBASE_{key.Name}_X", out var rawX) ? rawX : null,
            LastLoadRawY = values.TryGetValue($"ALIGNBASE_{key.Name}_Y", out var rawY) ? rawY : null
        }).ToArray();
        _lastLoadedPositions = Keys.Where(key => key.LastLoadRawX is not null && key.LastLoadRawY is not null)
            .ToDictionary(key => key.Name, key => (key.GlassX, key.GlassY), StringComparer.Ordinal);
        LastLoadedAt = loadedAt;
        LastLoadIsSimulation = isSimulation;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(null));
    }

    public void Update(ST_RECIPE_DEFINITION? recipe)
    {
        if (recipe is null) { Clear("Recipe not loaded"); return; }
        var parameters = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var parameter in recipe.Parameters)
            if (!string.IsNullOrWhiteSpace(parameter.Key)) parameters[parameter.Key] = parameter.Value;
        var layoutKeys = new[] { "GLASS_SIZE_X", "GLASS_SIZE_Y", "AK_MARGIN_X", "AK_MARGIN_Y" }
            .Concat(Enumerable.Range(1, 6).SelectMany(n => new[] { $"DISTORTION_KEY{n}_X", $"DISTORTION_KEY{n}_Y" }));
        var baseKeys = Enumerable.Range(1, 4).Select(n => $"AK{n}").Concat(Enumerable.Range(1, 6).Select(n => $"DK{n}"))
            .SelectMany(key => new[] { $"ALIGNBASE_{key}_X", $"ALIGNBASE_{key}_Y" });
        var signature = recipe.Id + "|" + recipe.Name + "|" + string.Join("|", layoutKeys.Concat(baseKeys)
            .Select(key => parameters.GetValueOrDefault(key, "")));
        if (_signature == signature) return;
        var previousLoads = RecipeId.Equals(recipe.Id, StringComparison.OrdinalIgnoreCase)
            ? Keys.ToDictionary(key => key.Name, key => (key.LastLoadX, key.LastLoadY, key.LastLoadRawX, key.LastLoadRawY), StringComparer.OrdinalIgnoreCase)
            : new Dictionary<string, (string LastLoadX, string LastLoadY, double? LastLoadRawX, double? LastLoadRawY)>(StringComparer.OrdinalIgnoreCase);
        if (!RecipeId.Equals(recipe.Id, StringComparison.OrdinalIgnoreCase))
        {
            LastLoadedAt = null;
            LastLoadIsSimulation = false;
            _lastLoadedPositions = new Dictionary<string, (double, double)>();
        }
        double? Read(string key) => parameters.TryGetValue(key, out var raw) &&
            double.TryParse(raw, NumberStyles.Float, CultureInfo.InvariantCulture, out var value) && double.IsFinite(value) ? value : null;
        var width = Read("GLASS_SIZE_X") ?? 0;
        var height = Read("GLASS_SIZE_Y") ?? 0;
        if (width <= 0 || height <= 0) { Clear("Glass Size X / Y must be greater than 0.", recipe); return; }
        var marginX = Math.Clamp(Read("AK_MARGIN_X") ?? 0, 0, width / 2);
        var marginY = Math.Clamp(Read("AK_MARGIN_Y") ?? 0, 0, height / 2);
        var gold = MakeBrush(230, 164, 0);
        var keys = new List<ST_ALIGN_DISTORTION_KEY>
        {
            new("AK1", marginX, marginY, gold),
            new("AK2", marginX, height - marginY, gold),
            new("AK3", width - marginX, marginY, gold),
            new("AK4", width - marginX, height - marginY, gold)
        };
        var distortionKeys = CCellPreviewDrawing.CreateDistortionKeyPreviews(width, height, marginX, marginY, Read);
        UpdateDkSelections(distortionKeys.Select(key => (key.DisplayText, key.GlassY)));
        keys.AddRange(distortionKeys
            .Select(key => new ST_ALIGN_DISTORTION_KEY(key.DisplayText, key.GlassX, key.GlassY, GetDkBrush(key.DisplayText))));
        var largestSide = Math.Max(keys.Count(key => key.GlassX <= width / 2), keys.Count(key => key.GlassX > width / 2));
        PreviewHeight = Math.Max(CanvasHeight, 16 + largestSide * ST_ALIGN_DISTORTION_KEY.EditorHeight + (largestSide - 1) * 8);
        var scale = Math.Min(360 / width, 500 / height);
        var frame = new Rect((CanvasWidth - width * scale) / 2, (PreviewHeight - height * scale) / 2,
            width * scale, height * scale);
        foreach (var key in keys)
        {
            key.MarkerX = frame.Left + Math.Clamp(key.GlassX, 0, width) * scale;
            key.MarkerY = frame.Top + Math.Clamp(key.GlassY, 0, height) * scale;
            key.IsInsideGlass = key.GlassX >= 0 && key.GlassX <= width && key.GlassY >= 0 && key.GlassY <= height;
            key.BaseRawX = Read($"ALIGNBASE_{key.Name}_X");
            key.BaseRawY = Read($"ALIGNBASE_{key.Name}_Y");
            key.BaseSourceX = parameters.GetValueOrDefault($"ALIGNBASE_{key.Name}_X", "-");
            key.BaseSourceY = parameters.GetValueOrDefault($"ALIGNBASE_{key.Name}_Y", "-");
            key.BaseX = key.BaseRawX?.ToString("0.000", CultureInfo.InvariantCulture) ?? "-";
            key.BaseY = key.BaseRawY?.ToString("0.000", CultureInfo.InvariantCulture) ?? "-";
            if (previousLoads.TryGetValue(key.Name, out var loaded))
            {
                key.LastLoadX = loaded.LastLoadX;
                key.LastLoadY = loaded.LastLoadY;
                key.LastLoadRawX = loaded.LastLoadRawX;
                key.LastLoadRawY = loaded.LastLoadRawY;
            }
        }
        foreach (var left in new[] { true, false })
        {
            var side = keys.Where(key => (key.GlassX <= width / 2) == left)
                .OrderBy(key => key.GlassY).ThenBy(key => key.GlassX).ThenBy(key => key.Name).ToArray();
            for (var i = 0; i < side.Length; i++)
            {
                side[i].EditorLeft = left ? 6 : CanvasWidth - ST_ALIGN_DISTORTION_KEY.EditorWidth - 6;
                side[i].EditorTop = side.Length == 1 ? (PreviewHeight - ST_ALIGN_DISTORTION_KEY.EditorHeight) / 2 :
                    8 + i * ((PreviewHeight - ST_ALIGN_DISTORTION_KEY.EditorHeight - 16) / (side.Length - 1));
            }
        }
        _glassFrame = frame;
        Keys = keys.ToArray();
        RefreshPreviewImage();
        Summary = $"Glass {width:0.###} × {height:0.###} mm";
        RecipeName = recipe.Name;
        RecipeId = recipe.Id;
        _signature = signature;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(null));
        BaseActionCommand.NotifyCanExecuteChanged();
    }

    private void UpdateDkSelections(IEnumerable<(string Name, double Y)> keys)
    {
        // Use recipe Y coordinates, not fixed DK number pairs, to form horizontal groups.
        var groups = keys.OrderBy(key => key.Y).GroupBy(key => key.Y)
            .Select(group => group.Select(key => key.Name).OrderBy(name => name, StringComparer.Ordinal).ToArray()).ToArray();
        if (DkSelections.Select(group => group.Name).SequenceEqual(groups.Select(names => string.Join(" + ", names))))
            return;
        var selectedKeys = DkSelections.Where(group => group.IsSelected).SelectMany(group => group.KeyNames)
            .ToHashSet(StringComparer.Ordinal);
        DkSelections = groups.Select(names => new CAlignDistortionDkSelection(names, RefreshDkSelection,
            names.All(selectedKeys.Contains))).ToArray();
    }

    private bool IsDkSelected(string name) => DkSelections.Any(group => group.IsSelected && group.KeyNames.Contains(name));

    private Brush GetDkBrush(string name) => IsDkSelected(name) ? SelectedDkBrush : UnselectedDkBrush;

    private void RefreshDkSelection()
    {
        if (Keys.Count == 0) return;
        // Never reuse a previously loaded DK after it has been deselected.
        Keys = Keys.Select(key => key.Name.StartsWith("DK", StringComparison.Ordinal)
            ? key with { KeyBrush = GetDkBrush(key.Name),
                LastLoadX = IsDkSelected(key.Name) ? key.LastLoadX : "-",
                LastLoadY = IsDkSelected(key.Name) ? key.LastLoadY : "-",
                LastLoadRawX = IsDkSelected(key.Name) ? key.LastLoadRawX : null,
                LastLoadRawY = IsDkSelected(key.Name) ? key.LastLoadRawY : null } : key).ToArray();
        RefreshPreviewImage();
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Keys)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PreviewImage)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(AlgorithmPreviewHint)));
    }

    private void RefreshPreviewImage()
    {
        var frame = _glassFrame;
        var group = new DrawingGroup();
        using (var drawing = group.Open())
        {
            drawing.DrawRectangle(Brushes.Transparent, null, new Rect(0, 0, CanvasWidth, PreviewHeight));
            drawing.DrawRectangle(null, new Pen(MakeBrush(102, 136, 164), 2), frame);
            DrawAlgorithmPreview(drawing);
            foreach (var key in Keys)
            {
                var left = key.EditorLeft < frame.Left;
                var start = new Point(left ? key.EditorLeft + ST_ALIGN_DISTORTION_KEY.EditorWidth : key.EditorLeft,
                    key.EditorTop + ST_ALIGN_DISTORTION_KEY.EditorHeight / 2);
                var edge = left ? frame.Left - 14 : frame.Right + 14;
                var geometry = new StreamGeometry();
                using (var line = geometry.Open())
                {
                    line.BeginFigure(start, false, false);
                    line.LineTo(new Point(edge, start.Y), true, false);
                    line.LineTo(new Point(edge, key.MarkerY), true, false);
                    line.LineTo(new Point(key.MarkerX, key.MarkerY), true, false);
                }
                var color = ((SolidColorBrush)key.KeyBrush).Color;
                drawing.DrawGeometry(null, new Pen(MakeBrush(color.R, color.G, color.B, 110), 1), geometry);
            }
            foreach (var key in Keys)
            {
                var excludedDk = key.Name.StartsWith("DK", StringComparison.Ordinal) && !IsDkSelected(key.Name);
                var pen = new Pen(key.IsInsideGlass || excludedDk ? key.KeyBrush : Brushes.IndianRed, 2);
                if (key.Name.StartsWith("AK"))
                    drawing.DrawRectangle(null, pen, new Rect(key.MarkerX - 5, key.MarkerY - 5, 10, 10));
                else
                {
                    drawing.DrawLine(pen, new Point(key.MarkerX - 6, key.MarkerY), new Point(key.MarkerX + 6, key.MarkerY));
                    drawing.DrawLine(pen, new Point(key.MarkerX, key.MarkerY - 6), new Point(key.MarkerX, key.MarkerY + 6));
                }
            }
        }
        group.Freeze();
        var image = new DrawingImage(group);
        image.Freeze();
        PreviewImage = image;
    }

    public void Clear(string message, ST_RECIPE_DEFINITION? recipe = null)
    {
        _signature = "";
        PreviewImage = null;
        _glassFrame = Rect.Empty;
        Keys = [];
        DkSelections = [];
        Summary = message;
        RecipeName = recipe?.Name ?? "-";
        RecipeId = recipe?.Id ?? "";
        PreviewHeight = CanvasHeight;
        LastLoadedAt = null;
        LastLoadIsSimulation = false;
        _lastLoadedPositions = new Dictionary<string, (double, double)>();
        AlgorithmPreviewHint = "현재 레시피의 키 위치를 확인하세요.";
        PreviewRegionCount = 0;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(null));
        BaseActionCommand.NotifyCanExecuteChanged();
    }

    private static SolidColorBrush MakeBrush(byte r, byte g, byte b, byte a = 255)
    {
        var brush = new SolidColorBrush(Color.FromArgb(a, r, g, b));
        brush.Freeze();
        return brush;
    }
}

public sealed class CAlignDistortionDkSelection(IReadOnlyList<string> keyNames, Action selectionChanged, bool isSelected = false) : INotifyPropertyChanged
{
    private bool _isSelected = isSelected;
    public IReadOnlyList<string> KeyNames { get; } = keyNames;
    public string Name => string.Join(" + ", KeyNames);
    public event PropertyChangedEventHandler? PropertyChanged;
    public bool IsSelected
    {
        get => _isSelected;
        set
        {
            if (_isSelected == value) return;
            _isSelected = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsSelected)));
            selectionChanged();
        }
    }
}

public sealed record ST_ALIGN_DISTORTION_KEY(string Name, double GlassX, double GlassY, Brush KeyBrush)
{
    public const double EditorWidth = 222;
    public const double EditorHeight = 144;
    public double EditorLeft { get; internal set; }
    public double EditorTop { get; internal set; }
    public double MarkerX { get; internal set; }
    public double MarkerY { get; internal set; }
    public bool IsInsideGlass { get; internal set; }
    public string BaseX { get; internal set; } = "-";
    public string BaseY { get; internal set; } = "-";
    public string LastLoadX { get; internal set; } = "-";
    public string LastLoadY { get; internal set; } = "-";
    public double? BaseRawX { get; internal set; }
    public double? BaseRawY { get; internal set; }
    public string BaseSourceX { get; internal set; } = "-";
    public string BaseSourceY { get; internal set; } = "-";
    public double? LastLoadRawX { get; internal set; }
    public double? LastLoadRawY { get; internal set; }
    public string BaseMinusLoadX => Subtract(BaseX, LastLoadX);
    public string BaseMinusLoadY => Subtract(BaseY, LastLoadY);
    public string PositionText => $"Recipe X: {GlassX:0.###} mm / Y: {GlassY:0.###} mm" +
        (IsInsideGlass ? "" : " (outside glass)");

    private static string Subtract(string baseValue, string loadValue)
    {
        if (!double.TryParse(baseValue, NumberStyles.Float, CultureInfo.InvariantCulture, out var basis) ||
            !double.TryParse(loadValue, NumberStyles.Float, CultureInfo.InvariantCulture, out var loaded) ||
            !double.IsFinite(basis) || !double.IsFinite(loaded) || !double.IsFinite(basis - loaded))
            return "-";
        return (basis - loaded).ToString("0.000", CultureInfo.InvariantCulture);
    }
}
