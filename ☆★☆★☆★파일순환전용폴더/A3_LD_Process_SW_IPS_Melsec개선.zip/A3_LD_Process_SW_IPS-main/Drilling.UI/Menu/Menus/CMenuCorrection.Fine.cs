using Drilling.Common.Interface.Vision;
using Drilling.Common.Review;
using Drilling.UI.Popup;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuCorrection
{
    private CancellationTokenSource? _fineCancellation;

    private async Task ExecuteFineAction(string action, Func<string, string, bool>? confirm = null,
        Action<string, string>? warn = null,
        Func<IReadOnlyList<ST_REVIEW_PLAN_POINT>, CancellationToken, Task<IReadOnlyList<ST_VISION_MARK_FIND>>>? simulationMeasurement = null)
    {
        if (action is "OFFSET_APPLY" or "OFFSET_INIT" or "OFFSET_VIEW")
        { await ExecuteFineOffsetAction(action, confirm, warn: warn); return; }
        if (action == "STOP") { _fineCancellation?.Cancel(); return; }
        if (_isReviewOperationRunning || action is not ("START" or "RESTART" or "RESUME_NG") || !Fine.CanConfigure || Fine.Lines.Count == 0) return;
        confirm ??= (title, message) => CRecipeConfirmDialog.ShowConfirmation(title, message);
        warn ??= (title, message) => CRecipeConfirmDialog.ShowWarning(title, message);
        _isReviewOperationRunning = true;
        Simple.SetOffsetOperationRunning(true); Rough.SetOffsetOperationRunning(true); Fine.SetOperationRunning(true);
        ExecuteCommand.NotifyCanExecuteChanged();
        var version = Fine.SourceVersion;
        try
        {
            var resume = action == "RESUME_NG";
            var start = resume ? Fine.RetryStartLineNo ?? 1 : 1;
            var count = Fine.Lines.Where(line => line.OrderNo >= start).Sum(line => line.Points.Count);
            if (!confirm("FINE Review Start", $"{Fine.RecipeName} / {Fine.InspectionMethod} / Beam {Fine.SelectedBeam}\nLine #{start}부터 {count:N0}개 Shot을 검사하시겠습니까?\nStage 이동·트리거 버퍼는 MELSEC Simulation에서 실행되며, Vision은 해당 장치 설정을 따릅니다.")) return;
            _fineCancellation = new CancellationTokenSource();
            var token = _fineCancellation.Token;
            Fine.Prepare();
            // Paint preparation/Stop before continuing, even when recipe reads complete synchronously.
            await System.Windows.Threading.Dispatcher.Yield(System.Windows.Threading.DispatcherPriority.Background);
            token.ThrowIfCancellationRequested();
            Fine.Update(await LoadSelectedOutputViewerRecipe(token, fallbackToFirst: false), LoadSimpleOffsetSettings());
            if (version != Fine.SourceVersion) throw new InvalidOperationException("레시피 또는 Setting이 변경되었습니다. 검사 대상을 다시 확인해 주세요.");
            token.ThrowIfCancellationRequested();
            var request = Fine.CreateRequest(start, resume);
            if (version != Fine.SourceVersion) throw new InvalidOperationException("검사 대상이 변경되었습니다. 다시 확인해 주세요.");
            token.ThrowIfCancellationRequested();
            Fine.Begin();
            var dispatcher = System.Windows.Application.Current?.Dispatcher;
            void Publish(ST_FINE_REVIEW_SNAPSHOT snapshot)
            {
                if (dispatcher is null || dispatcher.CheckAccess()) Fine.ApplyProgress(snapshot, version);
                else dispatcher.Invoke(() => Fine.ApplyProgress(snapshot, version));
            }
            var result = await _reviewManager.StartFineCorrection(request, Publish, token, simulationMeasurement);
            _statusReporter(result.Message);
            if (result.State == EN_REVIEW_SEQUENCE_STATE.Failed) warn("FINE 검사 확인", result.Message);
            if (result.ResultSaveError.Length > 0) warn("FINE 검사 결과 저장 실패", result.ResultSaveError);
        }
        catch (OperationCanceledException) { Fine.SetError("FINE 검사 중지"); }
        catch (Exception error) { Fine.SetError(error.Message); _statusReporter(error.Message); warn("FINE 확인", error.Message); }
        finally
        {
            _fineCancellation?.Dispose(); _fineCancellation = null;
            Fine.End(); _isReviewOperationRunning = false;
            Simple.SetOffsetOperationRunning(false); Rough.SetOffsetOperationRunning(false); Fine.SetOperationRunning(false);
            ExecuteCommand.NotifyCanExecuteChanged();
        }
    }
}
