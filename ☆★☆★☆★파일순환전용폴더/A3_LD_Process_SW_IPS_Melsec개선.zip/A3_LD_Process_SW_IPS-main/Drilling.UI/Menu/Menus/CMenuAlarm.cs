﻿using Drilling.Common.Managers;
using Drilling.Common.Interface;
using Drilling.Common.Motion;
using Drilling.Common.Alarm;
using Drilling.Common.InterLock;
using Drilling.Common.Station;
using System.Windows.Media;

namespace Drilling.UI.Menu.Menus;
public sealed class CMenuAlarm(CAlarmManager alarmManager, CStationManager stationManager, Action<string> setStatusMessage, Action refreshShellStatus, Func<Task> refreshCurrentScreen) : CMenuBase
{
    private int _selectedTabIndex;
    public event EventHandler? SelectedTabIndexChanged;
    public int SelectedTabIndex
    {
        get => _selectedTabIndex;
        set
        {
            if (_selectedTabIndex == value) return;
            _selectedTabIndex = value;
            if (value == 1) HistoryPanel.InitializeOnFirstOpen();
            SelectedTabIndexChanged?.Invoke(this, EventArgs.Empty);
        }
    }
    public CAlarmListPanel ListPanel { get; } = new(alarmManager);
    public CAlarmHistoryPanel HistoryPanel { get; } = new(alarmManager.ReadHistory);
    public event EventHandler? LogErrorChanged;
    public string LogError => alarmManager.GetCurrentSnapshot().LogError;
    public override EN_MENU Menu
    {
        get
        {
            return EN_MENU.Alarm;
        }
    }

    public CButtonCommand AlarmResetCommand
    {
        get
        {
            async void ResetAlarmCallback(object? arg0)
            {
                await ResetAlarmAsync();
            }

            return new(ResetAlarmCallback);
        }
    }

    public CButtonCommand BuzzerOffCommand
    {
        get
        {
            void setStatusMessageCallback(object? arg0)
            {
                setStatusMessage("Buzzer off command sent.");
            }

            return new(setStatusMessageCallback);
        }
    }

    public IReadOnlyList<ST_DISPLAY_ITEM> CurrentAlarms { get; private set; } = [];
    public IReadOnlyList<ST_DISPLAY_ITEM> AlarmDetail { get; private set; } = [];
    public IReadOnlyList<ST_DISPLAY_ITEM> RecoveryCommands { get; private set; } = [];
    public IReadOnlyList<ST_DISPLAY_ITEM> History { get; private set; } = [];
    public IReadOnlyList<ST_DISPLAY_ITEM> Trend { get; private set; } = [];
    public IReadOnlyList<ST_ALARM_CURRENT_ROW> CurrentAlarmRows { get; private set; } = [];
    public IReadOnlyList<ST_ALARM_DETAIL_ROW> DetailRows { get; private set; } = [];
    public IReadOnlyList<ST_ALARM_HISTORY_ROW> HistoryRows { get; private set; } = [];
    public IReadOnlyList<ST_ALARM_TREND_BAR> TrendBars { get; private set; } = [];
    public IReadOnlyList<ST_ALARM_SUMMARY_ITEM> SummaryItems { get; private set; } = [];

    public override Task<CScreenViewModel> Build(CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        ListPanel.RefreshSnapshot();
        var alarms = alarmManager.CurAlarm;
        global::Drilling.UI.Menu.Menus.ST_DISPLAY_ITEM BuildDisplay(global::Drilling.Common.Alarm.ST_ALARM_DATA item)
        {
            return new ST_DISPLAY_ITEM(item.Code.ToString(), item.Message, item.Severity.ToString());
        }

        var currentAlarms = alarms.Select(BuildDisplay).DefaultIfEmpty(new ST_DISPLAY_ITEM("No Alarm", "Normal")).ToArray();
        var firstAlarm = alarms.FirstOrDefault();
        Apply(currentAlarms, [new("Code", firstAlarm?.Code.ToString() ?? "-"), new("Severity", firstAlarm?.Severity.ToString() ?? "-"), new("Recovery", firstAlarm?.RecoveryAction ?? "No recovery action required")], [new("Alarm Reset", "Ready"), new("Buzzer Off", "Ready")], [], [], BuildCurrentAlarmRows(alarms), BuildDetailRows(firstAlarm), [], [], []);
        OnPropertyChanged(nameof(CurrentAlarmRows));
        LogErrorChanged?.Invoke(this, EventArgs.Empty);
        return Task.FromResult(new CScreenViewModel(EN_MENU.Alarm, "ALARM", "Current alarms, history/trend and alarm list.", [new("Current", alarms.Count.ToString())], [new("Current Alarm", currentAlarms)], alarm: this));
    }

    public async Task ResetAlarmAsync()
    {
        alarmManager.Reset();
        var station = stationManager.Reset();
        var isResetBlocked = station.ProcessStep == EN_PROCESS_STEP.Error;
        setStatusMessage(isResetBlocked ? $"Alarm reset blocked. {station.Result?.Message ?? "Check InterLock state."}" : "Alarm reset completed. Station is ready.");
        refreshShellStatus();
        await refreshCurrentScreen();
    }

    private void Apply(IReadOnlyList<ST_DISPLAY_ITEM> currentAlarms, IReadOnlyList<ST_DISPLAY_ITEM> alarmDetail, IReadOnlyList<ST_DISPLAY_ITEM> recoveryCommands, IReadOnlyList<ST_DISPLAY_ITEM> history, IReadOnlyList<ST_DISPLAY_ITEM> trend, IReadOnlyList<ST_ALARM_CURRENT_ROW> currentAlarmRows, IReadOnlyList<ST_ALARM_DETAIL_ROW> detailRows, IReadOnlyList<ST_ALARM_HISTORY_ROW> historyRows, IReadOnlyList<ST_ALARM_TREND_BAR> trendBars, IReadOnlyList<ST_ALARM_SUMMARY_ITEM> summaryItems)
    {
        CurrentAlarms = currentAlarms;
        AlarmDetail = alarmDetail;
        RecoveryCommands = recoveryCommands;
        History = history;
        Trend = trend;
        CurrentAlarmRows = currentAlarmRows;
        DetailRows = detailRows;
        HistoryRows = historyRows;
        TrendBars = trendBars;
        SummaryItems = summaryItems;
    }

    private IReadOnlyList<ST_ALARM_CURRENT_ROW> BuildCurrentAlarmRows(IReadOnlyList<ST_ALARM_DATA> alarms)
    {
        var groupsByCode = alarmManager.GetDefinitionsSnapshot().Rows.ToDictionary(row => row.Code, row => row.Group);
        global::Drilling.UI.Menu.Menus.ST_ALARM_CURRENT_ROW BuildAlarm(global::Drilling.Common.Alarm.ST_ALARM_DATA alarm, int index)
        {
            var group = groupsByCode.TryGetValue(alarm.Code, out var definedGroup) ? definedGroup : alarm.Group;
            return new ST_ALARM_CURRENT_ROW(index + 1, alarm.Code.ToString(), FormatSeverity(alarm.Severity), group, alarm.Message, alarm.Message, alarm.RecoveryAction, alarm.OccurredAt.ToString("yyyy-MM-dd HH:mm:ss"));
        }

        return alarms.Select(BuildAlarm).ToArray();
    }

    private static IReadOnlyList<ST_ALARM_DETAIL_ROW> BuildDetailRows(ST_ALARM_DATA? alarm)
    {
        if (alarm is null)
        {
            return[new("Selected Code", "-"), new("Device", "-"), new("Level", "CLEAR", "Ok"), new("Occurred Time", "-"), new("Message", "No active alarm")];
        }

        var severity = FormatSeverity(alarm.Severity);
        return[new("Selected Code", alarm.Code.ToString(), SeverityState(alarm.Severity)), new("Device", alarm.Device), new("Level", severity, SeverityState(alarm.Severity)), new("Occurred Time", alarm.OccurredAt.ToString("yyyy-MM-dd HH:mm:ss")), new("Message", alarm.Message)];
    }

    private static string FormatSeverity(EN_ALARM_LEVEL severity)
    {
        return severity switch
        {
            EN_ALARM_LEVEL.Warning => "LIGHT",
            EN_ALARM_LEVEL.Critical => "HEAVY",
            _ => "INFO"
        };
    }

    private static string SeverityState(EN_ALARM_LEVEL severity)
    {
        return severity switch
        {
            EN_ALARM_LEVEL.Warning => "Warn",
            EN_ALARM_LEVEL.Critical => "Critical",
            _ => "Accent"
        };
    }
}

public sealed record ST_ALARM_CURRENT_ROW(int No, string Code, string Level, string Group, string Message, string Cause, string Action, string Time)
{
    public Brush LevelBrush
    {
        get
        {
            return Level switch
            {
                "LIGHT" or "WARN" => CStatusBrush.Wait,
                "HEAVY" or "CRITICAL" or "ERROR" => CStatusBrush.Offline,
                "INFO" => CStatusBrush.Simul,
                _ => CStatusBrush.PrimaryText
            };
        }
    }
}

public sealed record ST_ALARM_DETAIL_ROW(string Name, string Value, string State = "Normal")
{
    public Brush ValueBrush
    {
        get
        {
            return State switch
            {
                "Warn" => CStatusBrush.Wait,
                "Critical" => CStatusBrush.Offline,
                "Accent" => CStatusBrush.Simul,
                "Ok" => CStatusBrush.Online,
                _ => CStatusBrush.PrimaryText
            };
        }
    }
}

public sealed record ST_ALARM_HISTORY_ROW(int No, string Time, string Code, string Level, string Group, string Cause, string Solution)
{
    public Brush LevelBrush
    {
        get
        {
            return Level switch
            {
                "LIGHT" or "WARN" => CStatusBrush.Wait,
                "HEAVY" or "CRITICAL" or "ERROR" => CStatusBrush.Offline,
                "INFO" => CStatusBrush.Simul,
                _ => CStatusBrush.PrimaryText
            };
        }
    }
}

public sealed record ST_ALARM_TREND_BAR(string Time, double Scanner, double Laser, double Motion, double Total, double TotalY);
public sealed record ST_ALARM_SUMMARY_ITEM(string Name, string Value, string State = "Normal")
{
    public Brush ValueBrush
    {
        get
        {
            return State switch
            {
                "Warn" => CStatusBrush.Wait,
                "Critical" => CStatusBrush.Offline,
                "Accent" => CStatusBrush.Simul,
                "Ok" => CStatusBrush.Online,
                _ => CStatusBrush.PrimaryText
            };
        }
    }
}
