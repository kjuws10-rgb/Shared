using System.Windows;
using System.Data;
using System.Globalization;
using Drilling.Common.Review;
using Drilling.UI.Popup;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuReview
{
    private CancellationTokenSource? _oneShotCancellation;
    private bool _oneShotRunning;
    private string _oneShotMethod = "Mark Find Single";
    private ST_ONE_SHOT_RESULT? _oneShotResult;
    public CButtonCommand OneShotActionCommand { get; private set; } = null!;
    public IReadOnlyList<string> OneShotMethods { get; } = ["Mark Find Single", "Mark Find Setting Single"];
    public string SelectedOneShotMethod
    {
        get => _oneShotMethod;
        set
        {
            if (IsReviewExecutionActive || !OneShotMethods.Contains(value) || value == _oneShotMethod) return;
            _oneShotMethod = value; _oneShotResult = null; OneShotStatus = "검사 대기"; NotifyOneShot();
        }
    }
    public string OneShotStatus { get; private set; } = "Shot을 선택해 주세요.";
    public string OneShotSelection => SelectedOneShotPoint is { } point
        ? $"HEAD {point.HeadNo:00} / Cell{point.CellNo:00}-{ToMatrixShotName(point)} / Beam{_selectedRunBeamNo}"
        : "Shot을 선택해 주세요.";
    public string OneShotResultText
    {
        get
        {
            if (_oneShotResult?.Mark is not { } mark || _lastAllPlan is null) return "";
            var x = mark.TargetMarkX - mark.HoleX; var y = mark.TargetMarkY - mark.HoleY;
            var converted = CReviewCoordinateTransformer.VisionErrorToStageOffset(x, y, _lastAllPlan.VisionFlipType);
            return $"Recv Target-Hole: X {FormatSigned(x)} / Y {FormatSigned(y)}\n" +
                $"Vision Flip: X {FormatSigned(converted.X)} / Y {FormatSigned(converted.Y)}\n" +
                $"RESULT: {_oneShotResult.Point.Judge}" + (_oneShotResult.IsVisionSimulation ? " (SIMULATION)" : "");
        }
    }
    public bool IsShotSelectionMode => IsOneShotReviewMode || IsBeamInspectionMode;
    private ST_REVIEW_PLAN_POINT? SelectedOneShotPoint => FindPointByShotKey(_lastAllPlan, _selectedRunShotKey);

    private void InitializeOneShot()
    {
        OneShotActionCommand = new(value => _ = ExecuteOneShotAction(value?.ToString() ?? ""), value =>
            IsOneShotReviewMode && !IsReviewExecutionActive && SelectedOneShotPoint is { Use: true, HeadNo: > 0 } point &&
            !IsReviewPointExcluded(point) && value?.ToString() is "MOVE" or "INSPECTION" or "MOVE_INSPECTION");
    }
    private void RefreshOneShotSelection(bool clearResult = false)
    {
        if (!IsOneShotReviewMode) return;
        if (clearResult) { _oneShotResult = null; OneShotStatus = SelectedOneShotPoint is null ? "Shot을 선택해 주세요." : "동작 대기"; }
        RunBeamRows = BuildBeamRows(_selectedRunBeamNo);
        OnPropertyChanged(nameof(RunBeamRows)); NotifyOneShot();
    }
    private void NotifyOneShot()
    {
        OnPropertyChanged(nameof(OneShotSelection)); OnPropertyChanged(nameof(OneShotStatus));
        OnPropertyChanged(nameof(OneShotResultText)); OnPropertyChanged(nameof(SelectedOneShotMethod));
        OnPropertyChanged(nameof(IsShotSelectionMode)); OnPropertyChanged(nameof(IsOneShotReviewMode));
        OnPropertyChanged(nameof(InspectionHeadRows));
        if (IsOneShotReviewMode)
        {
            ResultMatrix = BuildOneShotResultMatrix();
            OnPropertyChanged(nameof(ResultMatrix));
        }
        OneShotActionCommand?.NotifyCanExecuteChanged();
    }

    private DataView BuildOneShotResultMatrix()
    {
        var table = new DataTable("OneShotResult") { Locale = CultureInfo.InvariantCulture };
        foreach (var name in new[] { "HEAD", "CELL", "SHOT", "BEAM", "RESULT" }) table.Columns.Add(name, typeof(string));
        foreach (var name in new[] { "Recv X (mm)", "Recv Y (mm)", "Design X (mm)", "Design Y (mm)", "Target X", "Target Y", "Hole X", "Hole Y" })
            table.Columns.Add(name, typeof(double));
        if (_oneShotResult?.Mark is { } mark && _lastAllPlan is { } plan)
        {
            var point = _oneShotResult.Point;
            var x = mark.TargetMarkX - mark.HoleX; var y = mark.TargetMarkY - mark.HoleY;
            var converted = CReviewCoordinateTransformer.VisionErrorToStageOffset(x, y, plan.VisionFlipType);
            table.Rows.Add($"HEAD {point.HeadNo:00}", $"Cell{point.CellNo:00}", ToMatrixShotName(point), $"Beam{point.BeamNo}", point.Judge,
                x, y, converted.X, converted.Y, mark.TargetMarkX, mark.TargetMarkY, mark.HoleX, mark.HoleY);
        }
        return table.DefaultView;
    }
    private IReadOnlyDictionary<int, ST_REVIEW_BEAM_POSITION> OneShotBeamTargets()
        => IsOneShotReviewMode && _lastRecipe is not null && _lastAllPlan is not null && SelectedOneShotPoint is { } point
            ? CReviewManager.GetShotBeamPositions(_lastRecipe, point, _lastAllPlan.StageScanDirectionY).ToDictionary(item => item.BeamNo)
            : new Dictionary<int, ST_REVIEW_BEAM_POSITION>();

    private async Task ExecuteOneShotAction(string action, Func<string, string, bool>? confirm = null, Action<string, string>? warn = null)
    {
        if (!OneShotActionCommand.CanExecute(action)) return;
        var operation = action switch { "MOVE" => EN_ONE_SHOT_ACTION.Move, "INSPECTION" => EN_ONE_SHOT_ACTION.Inspection, _ => EN_ONE_SHOT_ACTION.MoveAndInspection };
        var method = _oneShotMethod == "Mark Find Single" ? EN_ONE_SHOT_METHOD.MarkFindSingle : EN_ONE_SHOT_METHOD.MarkFindSettingSingle;
        confirm ??= (title, message) => CRecipeConfirmDialog.ShowConfirmation(title, message);
        warn ??= (title, message) => CRecipeConfirmDialog.ShowWarning(title, message);
        _oneShotRunning = true; NotifyReviewExecutionCommandStates();
        _oneShotCancellation = new CancellationTokenSource();
        var token = _oneShotCancellation.Token;
        try
        {
            var recipe = await LoadSelectedRecipe(token) ?? throw new InvalidOperationException("현재 레시피가 없습니다.");
            token.ThrowIfCancellationRequested();
            if (recipe.Id != _lastRecipe?.Id) throw new InvalidOperationException("Recipe가 변경되었습니다. Shot을 다시 선택해 주세요.");
            var plan = _reviewManager.CreateAllPlan(recipe, _selectedRunBeamNo);
            var point = FindPointByShotKey(plan, _selectedRunShotKey) ?? throw new InvalidOperationException("선택한 Shot이 없습니다.");
            _lastRecipe = recipe; _lastAllPlan = plan; _lastAllPlanBeamNo = _selectedRunBeamNo;
            RefreshOneShotSelection();
            var title = action switch { "MOVE" => "Move", "INSPECTION" => "Inspection", _ => "Move&Inspection" };
            var message = $"HEAD {point.HeadNo:00} / Cell{point.CellNo:00}-{ToMatrixShotName(point)} / Beam{point.BeamNo}\n" +
                (operation == EN_ONE_SHOT_ACTION.Inspection ? "현재 위치에서 검사합니다.\n" : $"목표: Review X {point.ReviewTargetX:0.000} mm / Stage Y {point.ReviewTargetY:0.000} mm\n") +
                (operation == EN_ONE_SHOT_ACTION.Move ? "이동하시겠습니까?" : $"{_oneShotMethod} 명령으로 {(operation == EN_ONE_SHOT_ACTION.MoveAndInspection ? "이동 후 " : "")}검사하시겠습니까?");
            if (!confirm(title, message)) return;
            token.ThrowIfCancellationRequested();
            _oneShotResult = null; OneShotStatus = "동작 준비 중"; NotifyOneShot();
            var dispatcher = Application.Current?.Dispatcher;
            void Progress(string status)
            {
                void Apply() { OneShotStatus = status; NotifyOneShot(); }
                if (dispatcher is null || dispatcher.CheckAccess()) Apply(); else dispatcher.Invoke(Apply);
            }
            var result = await _reviewManager.ExecuteOneShot(plan, point, operation, method, Progress, _oneShotCancellation.Token);
            _oneShotResult = result;
            OneShotStatus = operation == EN_ONE_SHOT_ACTION.Move ? "이동 완료 (SIMULATION)" : $"검사 완료 · {result.Point.Judge}";
            _statusReporter($"{OneShotSelection} · {OneShotStatus}");
        }
        catch (OperationCanceledException) { OneShotStatus = "동작 중지"; }
        catch (Exception error) { OneShotStatus = error.Message; _statusReporter(error.Message); warn("One Shot 확인", error.Message); }
        finally
        {
            _oneShotCancellation?.Dispose(); _oneShotCancellation = null; _oneShotRunning = false;
            NotifyReviewExecutionCommandStates(); NotifyOneShot();
        }
    }
}
