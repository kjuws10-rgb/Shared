using Drilling.Common.Review;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CFineCorrectionPanel
{
    private bool _offsetApplied;
    private bool _allOffsetResultsOk;
    public bool CanApplyOffset => CanConfigure && !_offsetApplied && _allOffsetResultsOk;
    public string OffsetStatus => _offsetApplied ? "현재 검사 결과 적용 완료" : Lines.Any(line => line.NgCount > 0 || line.State == EN_FINE_LINE_STATE.Ng)
        ? "NG 발생 · Offset 전체 적용 불가" : CanApplyOffset ? "모든 검사 OK · Offset 적용 가능" : "모든 검사 대상 OK 완료 후 적용 가능";

    public IReadOnlyList<ST_REVIEW_PLAN_POINT> GetOffsetTargets() => _source?.Points.Where(point => point.HeadNo > 0).ToArray()
        ?? throw new InvalidOperationException("현재 레시피가 없습니다.");

    public ST_FINE_OFFSET_INPUT CreateOffsetInput()
    {
        if (_offsetApplied) throw new InvalidOperationException("이미 적용한 검사 결과입니다. 다시 검사한 후 적용해 주세요.");
        if (Lines.Any(line => line.State == EN_FINE_LINE_STATE.Ng || line.NgCount > 0))
            throw new InvalidOperationException("NG가 있어 FINE Offset 전체를 적용할 수 없습니다. NG RETRY 후 다시 적용해 주세요.");
        if (Lines.Count == 0 || Lines.Any(line => line.State != EN_FINE_LINE_STATE.Complete))
            throw new InvalidOperationException("검사가 정상 완료되어야 Offset을 적용할 수 있습니다.");
        return new(GetOffsetTargets(), Lines.SelectMany(line => line.Points).ToArray(), _source!.VisionFlipType);
    }

    private void RefreshOffsetEligibility() => _allOffsetResultsOk = Lines.Count > 0 && Lines.All(line =>
        line.State == EN_FINE_LINE_STATE.Complete && line.NgCount == 0 && line.Points.All(point => point.State == EN_REVIEW_POINT_STATE.Ok && point.Judge == "OK"));

    public void AcceptOffsetSave(bool initialize, string fileName)
    {
        _offsetApplied = !initialize;
        Status = $"Review Offset {(initialize ? "초기화" : "누적 적용")} 완료 · {fileName}";
        Notify();
    }
}

public sealed record ST_FINE_OFFSET_INPUT(IReadOnlyList<ST_REVIEW_PLAN_POINT> Targets,
    IReadOnlyList<ST_REVIEW_PLAN_POINT> Measurements, EN_VISION_FLIP_TYPE Flip);
