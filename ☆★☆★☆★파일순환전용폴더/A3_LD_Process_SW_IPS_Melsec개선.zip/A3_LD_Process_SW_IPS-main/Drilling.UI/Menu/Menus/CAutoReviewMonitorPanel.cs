using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using Drilling.Common.Review;

namespace Drilling.UI.Menu.Menus;

/// <summary>UI projection only. Its owner samples the latest shared frame; closing it cannot stop the sequence.</summary>
public sealed class CAutoReviewMonitorPanel : INotifyPropertyChanged
{
    private readonly CFineReviewMonitorStore _store;
    private Guid _runId;
    private long _revision = -1;
    private readonly Dictionary<string, ST_FINE_REVIEW_LINE> _seen = new();
    private readonly Dictionary<string, (int Measured, int Ng)> _counts = new();
    private ST_FINE_MONITOR_RESULT? _selectedNg;
    public CAutoReviewMonitorPanel(CFineReviewMonitorStore store,
        Func<(string StageY, string ReviewX, string Mode)> feedback)
    {
        _store = store;
        Preview.ReadFeedback = feedback;
        Preview.Clear("FINE Review 검사 대기");
    }
    public event PropertyChangedEventHandler? PropertyChanged;
    public CFineCorrectionPanel Preview { get; } = new();
    public ObservableCollection<ST_FINE_MONITOR_RESULT> NgResults { get; } = [];
    public IReadOnlyList<ST_FINE_MONITOR_RESULT> FinalResults { get; private set; } = [];
    public string Header { get; private set; } = "Review Monitor · FINE";
    public string ProgressText { get; private set; } = "검사 대기";
    public string Status { get; private set; } = "AUTO Review 실행은 아직 미연결입니다. 현재는 Manual FINE의 실제 진행 스냅샷도 표시합니다.";
    public string Tolerance { get; private set; } = "Tolerance X / Y : -";
    public string OffsetStatus { get; private set; } = "검사 결과 대기 · AUTO 보정 저장 연결 전";
    public string ResultFile { get; private set; } = "";
    public Visibility FinalVisibility { get; private set; } = Visibility.Collapsed;
    public int ResultRefreshCount { get; private set; }
    public ST_FINE_MONITOR_RESULT? SelectedNg
    {
        get => _selectedNg;
        set { _selectedNg = value; Preview.SetMonitorFocus(value?.Point); Notify(nameof(SelectedNg)); Notify(nameof(FocusText)); }
    }
    public string FocusText => SelectedNg is { } row ? $"LINE #{row.LineNo} · {row.Head} / {row.Cell}-{row.Shot} / Beam {row.Beam}" : "NG 행을 선택하면 프리뷰에 위치를 표시합니다.";
    public void RefreshFeedback() => Preview.RefreshFeedback();
    public void RefreshResults()
    {
        var frame = _store.GetSnapshot();
        if (frame is null || frame.Revision == _revision) return;
        if (frame.RunId != _runId)
        {
            Preview.AttachMonitor(frame.Request);
            _runId = frame.RunId; _seen.Clear(); _counts.Clear(); NgResults.Clear(); SelectedNg = null;
            FinalResults = []; FinalVisibility = Visibility.Collapsed;
        }
        _revision = frame.Revision; ResultRefreshCount++;
        var plan = frame.Request.Plan;
        var progress = frame.Progress;
        var selectedNg = SelectedNg;
        Preview.ApplyProgress(progress, Preview.SourceVersion);
        foreach (var incoming in progress.Lines)
        {
            if (_seen.GetValueOrDefault(incoming.Key) == incoming) continue;
            _seen[incoming.Key] = incoming;
            var line = Preview.Lines.Single(item => item.Key == incoming.Key);
            _counts[incoming.Key] = (line.MeasuredCount, line.NgCount);
            for (var i = NgResults.Count - 1; i >= 0; i--)
                if (NgResults[i].LineKey == incoming.Key) NgResults.RemoveAt(i);
            for (var i = 0; i < line.ShotResults.Count; i++)
                if (line.ShotResults[i].Judge is "NG" or "ERROR")
                    NgResults.Add(new(incoming.Key, line.OrderNo, line.Points[i], line.ShotResults[i], plan.ToleranceX, plan.ToleranceY));
        }
        Preview.SetMonitorNgPoints(NgResults.Select(row => row.Point).ToArray());
        if (selectedNg is { } selected) SelectedNg = NgResults.FirstOrDefault(row => row.LineKey == selected.LineKey && row.Point.ShotKey == selected.Point.ShotKey);
        var context = frame.Request.Context;
        Header = $"{context?.Origin ?? "FINE"} · Recipe {context?.RecipeName ?? plan.RecipeId} · Glass {context?.GlassId ?? "-"} · " +
            $"{(frame.Request.Method == EN_FINE_INSPECTION_METHOD.Flying ? "IOF" : "PtoP")} / {context?.LinesPerCell ?? 1} Line / " +
            $"즉시 재시도 {(frame.Request.ImmediateRetry ? "ON" : "OFF")} / {frame.Request.CountMismatchRetries}회";
        var measured = _counts.Values.Sum(count => count.Measured);
        var ng = _counts.Values.Sum(count => count.Ng);
        var active = progress.Lines.FirstOrDefault(line => line.State == EN_FINE_REVIEW_LINE_STATE.Running);
        var current = frame.Request.Method == EN_FINE_INSPECTION_METHOD.PtoP
            ? active?.Points.FirstOrDefault(point => point.State == EN_REVIEW_POINT_STATE.Current) : null;
        ProgressText = $"Shot {measured:N0} / {plan.Points.Count:N0} · OK {measured - ng:N0} · NG {ng:N0} · " +
            $"LINE {progress.Lines.Count(line => line.State is EN_FINE_REVIEW_LINE_STATE.Complete or EN_FINE_REVIEW_LINE_STATE.Ng)} / {progress.Lines.Count}" +
            (active is null ? "" : $" · 현재 #{active.Number}") +
            (current is null ? "" : $" / Cell{current.CellNo:00}-{CReviewShotNameFormatter.ToMatrixName(current.ShotNo, current.PixelCountX)} / Beam {current.BeamNo}");
        Status = progress.Message;
        Tolerance = $"Tolerance : X ±{plan.ToleranceX:0.000} / Y ±{plan.ToleranceY:0.000} mm · Vision Flip : {plan.VisionFlipType}";
        var finished = progress.State is EN_REVIEW_SEQUENCE_STATE.Completed or EN_REVIEW_SEQUENCE_STATE.Stopped or EN_REVIEW_SEQUENCE_STATE.Failed;
        if (finished && (FinalVisibility != Visibility.Visible || FinalResults.Count != plan.Points.Count ||
            !ReferenceEquals(_finalLines, progress.Lines)))
        {
            FinalResults = Preview.Lines.SelectMany(line => line.ShotResults.Select((row, i) => new ST_FINE_MONITOR_RESULT(
                line.Key, line.OrderNo, line.Points[i], row, plan.ToleranceX, plan.ToleranceY))).ToArray();
            _finalLines = progress.Lines; FinalVisibility = Visibility.Visible;
        }
        ResultFile = progress.ResultSaveError.Length > 0 ? "결과 저장 실패: " + progress.ResultSaveError : progress.ResultFilePath;
        OffsetStatus = frame.OffsetFile.Length > 0 ? $"Review Offset 저장됨 · {frame.OffsetFile}" :
            progress.State == EN_REVIEW_SEQUENCE_STATE.Idle ? "Stage Review START 대기 · 보정 미저장" :
            ng > 0 ? "NG 있음 · FINE 보정 전체 적용 불가" : finished && measured < plan.Points.Count ? "미검사 있음 · FINE 보정 적용 불가" :
            finished ? "전체 OK · 보정 미저장" : "검사 중 · 보정 미저장";
        Notify(null);
    }
    private IReadOnlyList<ST_FINE_REVIEW_LINE>? _finalLines;
    private void Notify(string? name) => PropertyChanged?.Invoke(this, new(name));
}

public sealed record ST_FINE_MONITOR_RESULT(string LineKey, int LineNo, ST_REVIEW_PLAN_POINT Point,
    ST_FINE_SHOT_DETAIL Result, double ToleranceX, double ToleranceY)
{
    public string Head => Result.Head;
    public string Cell => Result.Cell;
    public string Shot => Result.Shot;
    public int Beam => Result.BeamNo;
    public string Received => $"{Result.ReceivedXText} / {Result.ReceivedYText}";
    public string Converted => $"{Result.ConvertedXText} / {Result.ConvertedYText}";
    public string Judge => Result.Judge;
    public string Excess => string.Join(" / ", new[] { Exceeded("X", Result.ConvertedX, ToleranceX), Exceeded("Y", Result.ConvertedY, ToleranceY) }
        .Where(value => value.Length > 0)) is { Length: > 0 } text ? text : Judge is "NG" or "ERROR" ? "Vision NG / 수치 초과 없음" : "-";
    private static string Exceeded(string axis, double? value, double limit) => value is { } number && Math.Abs(number) > limit
        ? $"{axis} +{Math.Abs(number) - limit:0.000} mm" : "";
}
