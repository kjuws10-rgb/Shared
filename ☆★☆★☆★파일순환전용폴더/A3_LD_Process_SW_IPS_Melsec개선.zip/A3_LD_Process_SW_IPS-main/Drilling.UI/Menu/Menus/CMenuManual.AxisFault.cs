using Drilling.Common.Automation;
using Drilling.Common.Managers;
using Drilling.UI.Popup;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuManual
{
    private CButtonCommand? _scannerAxisClearFaultCommand;
    private HashSet<(int Controller, string Axis)>? _clearingAxisFaults;
    private HashSet<(int Controller, string Axis)> ClearingAxisFaults => _clearingAxisFaults ??= [];
    public CButtonCommand ScannerAxisClearFaultCommand => _scannerAxisClearFaultCommand ??= new(
        async value => { if (value is ST_MANUAL_SCANNER_AXIS axis) await ClearScannerAxisFault(axis); },
        value => value is ST_MANUAL_SCANNER_AXIS { CanClearFault: true } axis && !ClearingAxisFaults.Contains((axis.AutomationNo, axis.AxisReference)));

    private async Task ClearScannerAxisFault(ST_MANUAL_SCANNER_AXIS axis)
    {
        if (!axis.CanClearFault || TryBlockManualAutomationCommand("SCANNER_FAULT_CLEAR")) return;
        var key = (axis.AutomationNo, axis.AxisReference);
        if (!ClearingAxisFaults.Add(key)) return;
        ScannerAxisClearFaultCommand.NotifyCanExecuteChanged();
        try
        {
            var limitNote = CAutomationAxisFault.HasLimitFault(axis.FaultMask!.Value)
                ? "\n리미트 오류는 컨트롤러 설정에 따라 CLEAR 시 축이 리미트 밖으로 이동할 수 있습니다." : "";
            if (!CRecipeConfirmDialog.ShowConfirmation("축 FAULT CLEAR",
                $"{axis.Head} / {axis.AxisReference}\n{axis.FaultDetail}{limitNote}\n\n해당 축의 Fault를 해제하시겠습니까?", "CLEAR")) return;
            if (TryBlockManualAutomationCommand("SCANNER_FAULT_CLEAR")) return;
            var settings = _manager.Setting().LoadSection(EN_SETTING_TAB.Option);
            var current = CScannerStatusSnapshotReader.BuildAxisDefinitions(settings, axis.HeadNo)
                .SingleOrDefault(item => item.AxisName == axis.AxisRole);
            if (!IsManualControllerTab || !SelectedManualHeadNos.Contains(axis.HeadNo) || !current.IsUsed ||
                current.AutomationNo != axis.AutomationNo || current.AxisReference != axis.AxisReference ||
                !string.IsNullOrEmpty(current.ConfigurationError))
                throw new InvalidOperationException("Head 또는 축 설정이 변경되었습니다. 다시 선택해 주세요.");
            if (!_manager.automation.IsSimul(axis.AutomationNo) && !_manager.automation.IsConnect(axis.AutomationNo))
                throw new InvalidOperationException("Automation 장비가 연결되어 있지 않습니다.");
            var snapshot = _manager.automation.StatusSnapshots.GetAxis(axis.AxisReference, axis.AutomationNo, current.AioNo, current.ReadExtendedStatus);
            var mask = snapshot.Value is { } status ? CAutomationAxisFault.ParseMask(status.Fault) : null;
            if (!mask.HasValue) throw new InvalidOperationException("현재 축 Fault 상태를 확인할 수 없습니다. 상태 갱신 후 다시 시도해 주세요.");
            if (CAutomationAxisFault.RequiresReset(mask.Value))
                throw new InvalidOperationException("InternalFault는 축 CLEAR로 해제할 수 없습니다. 컨트롤러 RESET이 필요합니다.");
            if (mask.Value == 0) { _setStatusMessage($"{axis.Head} / {axis.AxisReference}: 활성 Fault가 없습니다."); return; }
            EnsureAutomationResponse(await _manager.automation.ResetAlarm(axis.AxisReference, axis.AutomationNo), "FAULT CLEAR");
            // Do not optimistically change FAULT to OK: the common collector verifies the actual state.
            _setStatusMessage($"{axis.Head} / {axis.AxisReference}: FAULT CLEAR 명령 전송. 해제 결과는 상태 갱신 시 표시됩니다.");
        }
        catch (Exception exception)
        {
            _setStatusMessage($"{axis.Head} / {axis.AxisReference}: FAULT CLEAR 실패. {exception.Message}");
            CRecipeConfirmDialog.ShowWarning("축 FAULT CLEAR 실패", exception.Message);
        }
        finally
        {
            ClearingAxisFaults.Remove(key);
            ScannerAxisClearFaultCommand.NotifyCanExecuteChanged();
            _refreshShellStatus();
        }
    }
}
