using System.Globalization;
using System.ComponentModel;
using System.Windows;
using System.Windows.Media;
using Drilling.Common.Managers;
using Drilling.Common.Recipe;
using Drilling.Common.Review;

namespace Drilling.UI.Menu.Menus;

/// <summary>Recipe edit draft only. All geometry/timing checks are shared with SAVE; no device/file polling.</summary>
public sealed class CRecipeZeroDefencePanel : INotifyPropertyChanged
{
    public event PropertyChangedEventHandler? PropertyChanged;
    private readonly Action<IReadOnlyDictionary<string, string>> _write;
    private CZeroDefenceRecipePlan? _plan;
    private string _signature = "";
    private readonly Dictionary<int, ST_ZERO_DEFENCE_POINT> _points = new();
    private readonly Dictionary<int, string> _invalid = new();
    private readonly Dictionary<int, IReadOnlyDictionary<string, ShotAvailability>> _availability = new();
    private IReadOnlyList<ST_SYSTEM_PARAMETER> _settings = [];
    private ST_HEAD_SHOT_POINT? _candidate;
    private int _head = 1, _cell, _count = 2, _group = 1;
    private IReadOnlyDictionary<string, ShotAvailability> _visibleAvailability = new Dictionary<string, ShotAvailability>();
    public CRecipeZeroDefencePanel(Action<IReadOnlyDictionary<string, string>> write)
    {
        _write = write;
        SelectGroupCommand = new(p => SelectGroup(Convert.ToInt32(p, CultureInfo.InvariantCulture)));
        SelectCellCommand = new(p => SelectCell(Convert.ToInt32(p, CultureInfo.InvariantCulture)), _ => !IsAll);
        SelectShotCommand = new(p => SelectShot(p?.ToString() ?? ""), p => CanEdit && !IsAll && p is string key &&
            _visibleAvailability.TryGetValue(key, out var shot) && shot.CanSelect);
        SelectBeamCommand = new(p => SelectBeam(Convert.ToInt32(p, CultureInfo.InvariantCulture)),
            p => CanEdit && !IsAll && int.TryParse(p?.ToString(), out var beam) && Beams.Any(b => b.Number == beam && b.CanSelect));
        SelectCountCommand = new(p => ChangeCount(Convert.ToInt32(p, CultureInfo.InvariantCulture)), _ => CanEdit && !IsAll);
        ClearGroupCommand = new(_ => ClearGroup(), _ => CanEdit && !IsAll);
        BackToGlassCommand = new(_ => { _cell = 0; RefreshView(); });
    }
    public CButtonCommand SelectCellCommand { get; }
    public CButtonCommand SelectGroupCommand { get; }
    public CButtonCommand SelectShotCommand { get; }
    public CButtonCommand SelectBeamCommand { get; }
    public CButtonCommand SelectCountCommand { get; }
    public CButtonCommand ClearGroupCommand { get; }
    public CButtonCommand BackToGlassCommand { get; }
    public bool CanEdit { get; private set; }
    public int PointCount => _count;
    public bool IsTwo => _count == 2;
    public bool IsFour => _count == 4;
    public string Status { get; private set; } = "그룹 카드를 선택한 뒤 Cell·Shot·Beam을 지정해 주세요.";
    public Brush StatusBrush { get; private set; } = Brushes.DarkGoldenrod;
    public string TimingSummary { get; private set; } = "";
    public string Summary => $"{_points.Count} / 8 Heads 지정 · {_count}개씩 {8 / Math.Max(1, _count)}장 순환 · 저장: Recipe SAVE";
    private int GroupSize => _count == 4 ? 4 : 2;
    public bool IsAll => _group == 0;
    public int SelectedGroupNo => _group;
    private IReadOnlyList<int> ScopeHeads => IsAll ? Enumerable.Range(1, 8).ToArray() : Enumerable.Range((_group - 1) * GroupSize + 1, GroupSize).ToArray();
    private string ScopeTitle => IsAll ? "ALL HEADS · 조회 전용" : $"HEAD {string.Join("/", ScopeHeads)} · GROUP{_group}";
    public string PreviewTitle => _cell == 0 ? ScopeTitle + " · GLASS PREVIEW" : $"{ScopeTitle} · Cell{_cell:00} · SHOT";
    public string CandidateText => IsAll ? "ALL · Cell 선택 없이 전체 지정 현황을 확인합니다." : _candidate is null ? "Shot을 고르면 담당 Head와 Beam별 선택 가능 여부가 표시됩니다."
        : $"HEAD {_candidate.HeadNo:00} · Cell{_candidate.CellNo:00}-{CReviewShotNameFormatter.ToMatrixName(_candidate.CellShotNo, _candidate.GroupCountX)} · Beam 선택 시 반영";
    public Visibility GlassVisibility => _cell == 0 ? Visibility.Visible : Visibility.Collapsed;
    public Visibility ShotVisibility => _cell > 0 ? Visibility.Visible : Visibility.Collapsed;
    public ImageSource? PreviewImage { get; private set; }
    public ST_GLASS_PREVIEW_FRAME GlassFrame { get; private set; } = new(44, 62, 772, 420);
    public IReadOnlyList<CZeroDefenceCell> Cells { get; private set; } = [];
    public IReadOnlyList<CZeroDefenceShotRow> ShotRows { get; private set; } = [];
    public IReadOnlyList<CZeroDefenceHeadRow> HeadRows { get; private set; } = [];
    public IReadOnlyList<CZeroDefenceBeam> Beams { get; private set; } = [];
    public IReadOnlyList<CZeroDefenceGroupCard> GroupCards { get; private set; } = [];
    public IReadOnlyList<CZeroDefenceSelectionLabel> SelectionLabels { get; private set; } = [];
    private bool SideLabelsFit => Math.Min(GlassFrame.CanvasLeft, 860 - GlassFrame.CanvasLeft - GlassFrame.Width) >= 150;
    public double PreviewCanvasHeight => IsAll && !SideLabelsFit ? 636 : 520;
    private void SelectGroup(int group)
    {
        if (group < 0 || group > 8 / GroupSize) return;
        _group = group; _head = IsAll ? 0 : ScopeHeads[0]; _cell = 0; _candidate = null;
        UpdateStatus(); RefreshView();
    }
    public void Update(ST_RECIPE_DEFINITION? recipe, IReadOnlyList<ST_SYSTEM_PARAMETER> settings, bool canEdit)
    {
        CanEdit = canEdit;
        var signature = recipe is null ? "" : recipe.Id + "|" + string.Join(";", recipe.Parameters.Select(p => p.Key + "=" + p.Value)) +
            "|" + string.Join(";", settings.Select(p => p.Key + "=" + p.Value));
        if (_signature == signature && _plan is not null) { RefreshView(); return; }
        _signature = signature; _settings = settings; _points.Clear(); _invalid.Clear(); _availability.Clear(); _candidate = null;
        try
        {
            _plan = recipe is null ? null : new(recipe, settings);
            if (_plan is null) { Status = "레시피를 선택해 주세요."; RefreshView(); return; }
            _count = _plan.Count;
            _group = Math.Clamp(_group, 0, 8 / GroupSize);
            if (!ScopeHeads.Contains(_head)) _head = IsAll ? 0 : ScopeHeads[0];
            for (var head = 1; head <= 8; head++)
            {
                var cell = _plan.Int(CZeroDefenceRecipePlan.Key(head, "CELL"));
                var shot = _plan.Int(CZeroDefenceRecipePlan.Key(head, "SHOT"));
                var beam = _plan.Int(CZeroDefenceRecipePlan.Key(head, "BEAM"));
                if (cell == 0 && shot == 0 && beam == 0) continue;
                try { _points[head] = _plan.GetPoint(head, cell, shot, beam); }
                catch (Exception error) when (error is InvalidOperationException or ArgumentException) { _invalid[head] = error.Message; }
            }
            RestoreCandidate();
            var p = _plan.Profile;
            TimingSummary = $"Stage Y {p.StageSpeed:0.###} mm/sec · Acc {p.StageAcceleration:0.###} mm/sec² · MCC Stroke {p.StageStroke:0} mm\n" +
                $"Review X {p.ReviewSpeed:0.###} mm/sec · Acc {p.ReviewAcceleration:0.###} mm/sec²\n" +
                "안정화 50 ms · 선도착 20 ms · 20 FPS · 노출 10 µs";
            UpdateStatus();
        }
        catch (Exception error) when (error is InvalidOperationException or ArgumentException)
        { _plan = null; Status = error.Message; StatusBrush = Brushes.Firebrick; }
        RefreshView();
    }
    private void ChangeCount(int count)
    {
        if (!CanEdit || IsAll || _plan is null || count is not (2 or 4)) return;
        var result = CZeroDefenceTiming.Validate(count, _points.Values, _plan.Profile);
        if (!result.IsValid) { Reject(result.Message); return; }
        try
        {
            _write(new Dictionary<string, string> { [CZeroDefenceRecipePlan.CountKey] = count.ToString(CultureInfo.InvariantCulture) });
            var firstHead = ScopeHeads[0];
            _count = count; _group = (firstHead - 1) / GroupSize + 1; _head = ScopeHeads[0]; _cell = 0; _candidate = null;
            _availability.Clear(); UpdateStatus(); RefreshView();
        }
        catch (InvalidOperationException error) { Reject(error.Message); }
    }
    private void RestoreCandidate()
    {
        var selected = _points.GetValueOrDefault(_head);
        _candidate = selected is null ? null : _plan?.Plan.Shots.FirstOrDefault(p => p.ShotKey == selected.ShotKey);
    }
    private void SelectCell(int cell)
    {
        if (IsAll || !Cells.Any(c => c.Number == cell)) return;
        _cell = cell; _candidate = null; RefreshView();
    }
    private void SelectShot(string key)
    {
        if (IsAll || !CanEdit) return;
        var scope = ScopeHeads.ToHashSet();
        var point = _plan?.Plan.Shots.FirstOrDefault(p => scope.Contains(p.HeadNo) && p.ShotKey == key);
        if (point is null || !_plan!.CanProcess(point)) return;
        var availability = GetShotAvailability(point.HeadNo).GetValueOrDefault(key);
        if (availability is not { CanSelect: true }) { Reject(availability?.Reason ?? "선택할 수 없는 Shot입니다."); return; }
        _head = point.HeadNo; _candidate = point; RefreshView();
        if (Beams.All(b => !b.CanSelect)) Reject(Beams.FirstOrDefault()?.Reason ?? "선택할 수 있는 Beam이 없습니다.");
    }
    private void SelectBeam(int beam)
    {
        if (!CanEdit || IsAll || _plan is null || _candidate is null) return;
        try
        {
            var point = _plan.GetPoint(_head, _candidate.CellNo, _candidate.CellShotNo, beam);
            var validation = ValidateCandidate(point);
            if (!validation.IsValid) { Reject(validation.Message); return; }
            _write(new Dictionary<string, string>
            {
                [CZeroDefenceRecipePlan.Key(_head, "CELL")] = point.CellNo.ToString(CultureInfo.InvariantCulture),
                [CZeroDefenceRecipePlan.Key(_head, "SHOT")] = point.ShotNo.ToString(CultureInfo.InvariantCulture),
                [CZeroDefenceRecipePlan.Key(_head, "BEAM")] = beam.ToString(CultureInfo.InvariantCulture)
            });
            _points[_head] = point; _invalid.Remove(_head);
            InvalidateOtherHeadsInGroup();
            UpdateStatus(); RefreshView();
        }
        catch (Exception error) when (error is InvalidOperationException or ArgumentException) { Reject(error.Message); }
    }
    private ST_ZERO_DEFENCE_TIMING_RESULT ValidateCandidate(ST_ZERO_DEFENCE_POINT point)
    {
        var result = CZeroDefenceTiming.Validate(_count, _points.Values.Where(p => p.HeadNo != point.HeadNo).Append(point), _plan!.Profile);
        var group = (point.HeadNo - 1) / Math.Max(1, _count) + 1;
        // Permit repairing one glass group while another stored group still needs correction.
        // SAVE always validates all groups together.
        return new(result.Issues.Where(i => i.GroupNo == 0 || i.GroupNo == group).ToArray(),
            result.Transitions.Where(t => t.GroupNo == group).ToArray());
    }
    private void InvalidateOtherHeadsInGroup()
    {
        var groupSize = Math.Max(1, _count);
        var group = (_head - 1) / groupSize;
        foreach (var head in _availability.Keys.Where(head => head != _head && (head - 1) / groupSize == group).ToArray())
            _availability.Remove(head);
    }
    private IReadOnlyDictionary<string, ShotAvailability> GetShotAvailability(int head)
    {
        if (_plan is null) return new Dictionary<string, ShotAvailability>();
        if (_availability.TryGetValue(head, out var cached)) return cached;
        // Evaluate a Head once per recipe/settings/group-selection change. Cell navigation
        // and candidate highlighting reuse this snapshot; no timer or device reads are involved.
        var result = new Dictionary<string, ShotAvailability>();
        foreach (var shot in _plan.Plan.Shots.Where(shot => shot.HeadNo == head))
        {
            var mask = _plan.Mask(shot);
            if (mask.ShouldSkipLaser)
            {
                result[shot.ShotKey] = new(false, mask.IsMasked ? "MASKING" : "CHESS");
                continue;
            }
            var reason = "선택 가능한 Beam이 없습니다.";
            var canSelect = false;
            for (var beam = 1; beam <= 16; beam++)
            {
                try
                {
                    var point = _plan.GetPoint(head, shot.CellNo, shot.CellShotNo, beam);
                    var check = ValidateCandidate(point);
                    if (check.IsValid) { canSelect = true; break; }
                    if (beam == 1) reason = check.Message;
                }
                catch (Exception error) when (error is InvalidOperationException or ArgumentException)
                { if (beam == 1) reason = error.Message; }
            }
            result[shot.ShotKey] = new(canSelect, canSelect ? "" : reason);
        }
        _availability[head] = result;
        return result;
    }
    private sealed record ShotAvailability(bool CanSelect, string Reason);
    private void ClearGroup()
    {
        if (!CanEdit || IsAll) return;
        try
        {
            _write(ScopeHeads.SelectMany(head => new[] { "CELL", "SHOT", "BEAM" }.Select(field => CZeroDefenceRecipePlan.Key(head, field))).ToDictionary(key => key, _ => "0"));
            foreach (var head in ScopeHeads) { _points.Remove(head); _invalid.Remove(head); _availability.Remove(head); }
            _candidate = null;
            UpdateStatus(); RefreshView();
        }
        catch (InvalidOperationException error) { Reject(error.Message); }
    }
    private void UpdateStatus()
    {
        if (_plan is null) return;
        var check = CZeroDefenceTiming.Validate(_count, _points.Values, _plan.Profile);
        Status = _invalid.Count > 0 ? string.Join("\n", _invalid.Values) : !check.IsValid ? check.Message :
            _points.Count < 8 ? $"{8 - _points.Count}개 Head가 미지정입니다. 각 Head의 Shot·Beam을 지정해 주세요." : "전체 8개 Head의 MCC 이동·촬영 조건이 유효합니다.";
        StatusBrush = _invalid.Count > 0 || !check.IsValid ? Brushes.Firebrick : _points.Count == 8 ? Brushes.SeaGreen : Brushes.DarkGoldenrod;
    }
    private void Reject(string reason) { Status = reason; StatusBrush = Brushes.Firebrick; OnPropertyChanged(nameof(Status)); OnPropertyChanged(nameof(StatusBrush)); }
    private void OnPropertyChanged(string? property = null) => PropertyChanged?.Invoke(this, new(property));
    private void RefreshView()
    {
        var result = _plan is null ? new ST_ZERO_DEFENCE_TIMING_RESULT([], []) : CZeroDefenceTiming.Validate(_count, _points.Values, _plan.Profile);
        HeadRows = Enumerable.Range(1, 8).Select(head =>
        {
            var point = _points.GetValueOrDefault(head);
            var bad = _invalid.GetValueOrDefault(head) ?? result.Issues.FirstOrDefault(i => i.FromHead == head || i.ToHead == head)?.Reason;
            return new CZeroDefenceHeadRow(head, (head - 1) / Math.Max(1, _count) + 1, point,
                bad is not null ? "확인 필요" : point is null ? "미지정" : "지정 완료", bad ?? "", _candidate?.HeadNo == head);
        }).ToArray();
        GroupCards = Enumerable.Range(1, 8 / GroupSize).Select(group =>
        {
            var heads = Enumerable.Range((group - 1) * GroupSize + 1, GroupSize).ToArray();
            return new CZeroDefenceGroupCard(group, "HEAD " + string.Join("/", heads), $"GROUP{group} · {heads.Count(head => _points.ContainsKey(head))}/{GroupSize}", group == _group);
        }).Append(new CZeroDefenceGroupCard(0, "ALL", $"조회 전용 · {_points.Count}/8", IsAll)).ToArray();
        if (_plan is not null)
        {
            var scope = ScopeHeads.ToHashSet();
            var headShots = _plan.Plan.Shots.Where(p => scope.Contains(p.HeadNo)).ToArray();
            _visibleAvailability = IsAll ? new Dictionary<string, ShotAvailability>() : ScopeHeads.SelectMany(head => GetShotAvailability(head)).ToDictionary(pair => pair.Key, pair => pair.Value);
            var cellCounts = headShots.GroupBy(shot => shot.CellNo).ToDictionary(group => group.Key,
                group => (Total: group.Count(), Available: IsAll ? group.Count() : group.Count(shot => _visibleAvailability[shot.ShotKey].CanSelect), Heads: group.Select(shot => shot.HeadNo).Distinct().Order().ToArray()));
            var visible = cellCounts.Keys.ToHashSet();
            var preview = CHeadAssignmentPreviewBuilder.BuildRecipePreview(_plan.Parameters, scope,
                CHeadAssignmentPreviewBuilder.BuildHeadLayout(_settings), showKeys: false, visibleCellNos: visible);
            PreviewImage = preview.Image;
            GlassFrame = preview.Frame;
            Cells = preview.CellLabels.Select(c => new CZeroDefenceCell(c.CellNo, c.CellBounds.IsEmpty ? new Rect(c.CanvasCenterX - 4, c.CanvasCenterY - 4, 8, 8) : c.CellBounds,
                _points.Values.Any(p => scope.Contains(p.HeadNo) && p.CellNo == c.CellNo), cellCounts[c.CellNo].Available, cellCounts[c.CellNo].Total,
                cellCounts[c.CellNo].Heads, string.Join("/", _points.Values.Where(p => scope.Contains(p.HeadNo) && p.CellNo == c.CellNo).OrderBy(p => p.HeadNo).Select(p => $"H{p.HeadNo}")), !IsAll)).ToArray();
            SelectionLabels = !IsAll ? [] : _points.Values.OrderBy(point => point.HeadNo).Select(point =>
            {
                var cell = Cells.FirstOrDefault(cell => cell.Number == point.CellNo);
                var anchor = cell is null ? new Point(GlassFrame.CanvasLeft + GlassFrame.Width / 2, GlassFrame.CanvasTop) :
                    new Point(cell.Bounds.X + cell.Bounds.Width / 2, cell.Bounds.Y + cell.Bounds.Height / 2);
                var onLeft = point.HeadNo <= 4;
                var width = SideLabelsFit ? Math.Min(210, Math.Min(GlassFrame.CanvasLeft, 860 - GlassFrame.CanvasLeft - GlassFrame.Width) - 40) : 202;
                var left = SideLabelsFit ? onLeft ? GlassFrame.CanvasLeft - width - 24 : GlassFrame.CanvasLeft + GlassFrame.Width + 24 : 14 + ((point.HeadNo - 1) % 4) * 212;
                var top = SideLabelsFit ? GlassFrame.CanvasTop + ((point.HeadNo - 1) % 4) * Math.Max(0, (GlassFrame.Height - 44) / 3) : 526 + ((point.HeadNo - 1) / 4) * 52;
                var endpoint = SideLabelsFit ? new Point(onLeft ? left + width : left, top + 22) : new Point(left + width / 2, top);
                return new CZeroDefenceSelectionLabel($"HEAD {point.HeadNo:00} · Cell{point.CellNo:00}\n{point.ShotName} · Beam{point.BeamNo}", left, top, width,
                    new PointCollection { anchor, new(endpoint.X, anchor.Y), endpoint });
            }).ToArray();
            ShotRows = headShots.Where(p => !IsAll && p.CellNo == _cell).GroupBy(p => p.GroupRow).OrderBy(g => g.Key)
                .Select(g => new CZeroDefenceShotRow(g.OrderBy(p => p.GroupColumn).Select(p =>
                {
                    var mask = _plan.Mask(p);
                    var eligibility = _visibleAvailability[p.ShotKey];
                    return new CZeroDefenceShot(p.ShotKey, CReviewShotNameFormatter.ToMatrixName(p.CellShotNo, p.GroupCountX),
                        eligibility.CanSelect, mask.IsMasked, mask.IsChessSkipped, eligibility.Reason,
                        _candidate?.ShotKey == p.ShotKey, _points.GetValueOrDefault(p.HeadNo)?.ShotKey == p.ShotKey, p.HeadNo);
                }).ToArray())).ToArray();
        }
        else { PreviewImage = null; Cells = []; ShotRows = []; SelectionLabels = []; _visibleAvailability = new Dictionary<string, ShotAvailability>(); }
        Beams = Enumerable.Range(1, 16).Select(beam =>
        {
            if (_plan is null || _candidate is null) return new CZeroDefenceBeam(beam, null, false, "Shot을 선택해 주세요.", false);
            try
            {
                var point = _plan.GetPoint(_head, _candidate.CellNo, _candidate.CellShotNo, beam);
                var check = ValidateCandidate(point);
                return new CZeroDefenceBeam(beam, point, CanEdit && check.IsValid, check.Message,
                    _points.GetValueOrDefault(_head) is { } selected && selected.ShotKey == point.ShotKey && selected.BeamNo == beam);
            }
            catch (Exception error) when (error is InvalidOperationException or ArgumentException)
            { return new CZeroDefenceBeam(beam, null, false, error.Message, false); }
        }).ToArray();
        foreach (var command in new[] { SelectCellCommand, SelectBeamCommand, SelectShotCommand, SelectCountCommand, ClearGroupCommand }) command.NotifyCanExecuteChanged();
        OnPropertyChanged(null);
    }
}
public sealed record CZeroDefenceHeadRow(int HeadNo, int GroupNo, ST_ZERO_DEFENCE_POINT? Point, string State, string Detail, bool IsSelected)
{
    public string Head => $"H{HeadNo:00}";
    public string Cell => Point is null ? "-" : $"Cell{Point.CellNo:00}";
    public string Shot => Point?.ShotName ?? "-";
    public string Beam => Point?.BeamNo.ToString(CultureInfo.InvariantCulture) ?? "-";
    public string Coordinates => Point is null ? "" : $"Review X {Point.ReviewX:0.000} / Stage Y {Point.StageY:0.000} mm";
    public string Tooltip => Coordinates + (Detail.Length == 0 ? "" : "\n" + Detail);
}
public sealed record CZeroDefenceGroupCard(int Number, string Name, string Detail, bool IsSelected)
{
    public Brush Background => IsSelected ? Brushes.SteelBlue : Brushes.AliceBlue;
    public Brush Foreground => IsSelected ? Brushes.White : Brushes.Black;
}
public sealed record CZeroDefenceSelectionLabel(string Text, double Left, double Top, double Width, PointCollection Leader)
{
    public double FontSize => Math.Min(16, Width / 12);
}
public sealed record CZeroDefenceCell(int Number, Rect Bounds, bool HasSelection, int SelectableShotCount, int TotalShotCount,
    IReadOnlyList<int> HeadNos, string SelectedHeads, bool CanOpen)
{
    public bool IsUnavailable => CanOpen && SelectableShotCount == 0;
    public string Detail => $"Cell{Number:00} · HEAD {string.Join("/", HeadNos)}" +
        (CanOpen ? $" · 선택 가능 {SelectableShotCount:N0} / {TotalShotCount:N0} Shot" : " · 조회 전용") +
        (HasSelection ? "\n지정: " + SelectedHeads : "") +
        (IsUnavailable ? "\n선택 가능한 Beam이 있는 Shot이 없습니다. Cell을 눌러 Shot별 사유를 확인해 주세요." : "");
}
public sealed record CZeroDefenceShotRow(IReadOnlyList<CZeroDefenceShot> Shots);
public sealed record CZeroDefenceShot(string Key, string Name, bool CanSelect, bool IsMasked, bool IsChess, string UnavailableReason, bool IsCandidate, bool IsSelected, int HeadNo)
{
    public string Label => $"{Name}\nH{HeadNo:00}";
    public Brush Background => IsMasked ? Brushes.LightCoral : IsChess ? Brushes.Plum : !CanSelect ? Brushes.LightGray : IsSelected ? Brushes.MediumSeaGreen : IsCandidate ? Brushes.LightSkyBlue : Brushes.White;
    public string Detail => IsMasked ? "MASKING" : IsChess ? "CHESS" : !CanSelect ? "선택 불가: 선택 가능한 Beam이 없습니다.\n" + UnavailableReason : IsSelected ? "등록된 Shot" : "Shot 선택 후 Beam을 선택해 주세요.";
}
public sealed record CZeroDefenceBeam(int Number, ST_ZERO_DEFENCE_POINT? Point, bool CanSelect, string Reason, bool IsSelected)
{
    public string Name => $"Beam{Number}";
    public string Coordinates => Point is null ? "X -\nY -" : $"X {Point.ReviewX:0.000}\nY {Point.StageY:0.000}";
    public Brush Background => IsSelected ? Brushes.SeaGreen : CanSelect ? Brushes.White : Brushes.MistyRose;
    public Brush Foreground => IsSelected ? Brushes.White : Brushes.Black;
    public string Detail => CanSelect ? "Review X / Stage Y · 선택 가능" : Reason;
}
