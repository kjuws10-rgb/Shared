﻿using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Media;
using Drilling.UI.Menu;
using Drilling.Common.Automation;
using Drilling.Common.Managers;
using Drilling.Common.Interface;
using Drilling.Common.Motion;
using Drilling.Common.Alarm;
using Drilling.Common.InterLock;
using Drilling.Common.Station;
using Drilling.Common.Recipe;
using Drilling.Common.Review;

namespace Drilling.UI.Menu.Menus;
public sealed partial class CMenuMain(CStationManager stationManager, CInterfaceManager interfaceManager, CAutomationManager automationManager, CRecipeManager recipeManager, CSettingManager settingManager, CReviewManager reviewManager, Func<string> selectedRecipeIdProvider, Action<string> statusReporter, Func<Task> refreshCurrentScreen) : CMenuBase
{
    private const string ParameterTabHead = "HEAD";
    private const string ParameterTabRunOption = "RUN_OPTION";
    private const string ParameterTabOptic = "OPTIC";
    private const string ParameterTabScanner = "SCANNER";
    private const string ParameterTabMotor = "MOTOR";
    private const string OpticStatusLaser = "LASER";
    private const string OpticStatusAttenuator = "ATT";
    private const string OpticStatusBet = "BET";
    private const double ReviewSequenceRowTolerance = 0.001;
    public CMainSequenceStatus SequenceStatus { get; } = new();
    public CMainRunOptionPanel RunOptions { get; } = new(() => ReadReviewAble(
        interfaceManager?.Melsec.GetCachedSnapshot().GetValueOrDefault("HANDSHAKE_PRC_REVIEW_ABLE")), settingManager, statusReporter);

    private static bool? ReadReviewAble(ST_MELSEC_CACHED_VALUE? sample)
    {
        if (sample?.IsValid != true || sample.Value is null) return null;
        try { return Convert.ToDouble(sample.Value, CultureInfo.InvariantCulture) switch { 0 => false, 1 => true, _ => null }; }
        catch (Exception error) when (error is FormatException or InvalidCastException or OverflowException) { return null; }
    }

    private void RefreshSequenceStatus(ST_STATION_PROCESS_STATUS snapshot)
    {
        var values = interfaceManager.Melsec.GetCachedSnapshot(out var map);
        var connections = interfaceManager.GetInterfaceCommunicationList(EN_EQP_MODULE.Melsec)
            .ToDictionary(device => device.Number, device => device.IsSimulation ? EN_COMM_STATE.Simulation : device.ConnectionState);
        SequenceStatus.Refresh(values, map, connections, snapshot.SequenceActions);
        RunOptions.UpdateReviewAble(ReadReviewAble(values.GetValueOrDefault("HANDSHAKE_PRC_REVIEW_ABLE")));
        SequenceStatus.OpenReviewMonitor = OpenReviewMonitor;
        SequenceStatus.RefreshReviewMonitor(reviewManager?.FineMonitor.GetSnapshot());
    }
    private CButtonCommand? _selectParameterTabCommand;
    private CButtonCommand? _selectOpticStatusCommand;
    private CButtonCommand? _selectScannerStatusHeadCommand;
    private string _selectedParameterTabKey = ParameterTabHead;
    private string _selectedOpticStatusKey = OpticStatusLaser;
    private int _selectedScannerStatusHeadNo = 1;
    private IReadOnlyList<ST_DISPLAY_ITEM> _cycleItems = [];
    private IReadOnlyList<ST_DISPLAY_ITEM> _resultItems = [];
    private IReadOnlyList<ST_MAIN_PROCESS_SEQUENCE_ITEM> _processSequenceItems = [];
    private IReadOnlyList<ST_DISPLAY_ITEM> _currentStepDetails = [];
    private IReadOnlyList<ST_DISPLAY_ITEM> _processSummaryItems = [];
    private IReadOnlyList<ST_DISPLAY_ITEM> _lifecycleItems = [];
    private IReadOnlyList<ST_SCRIPT_TASK_STATUS_ITEM> _scriptTaskStatusItems = [];
    private IReadOnlyList<ST_AUTOMATION_CONTROLLER_STATUS_ITEM> _automationControllerStatusItems = [];
    private IReadOnlyDictionary<(int AutomationNo, int TaskNo), ST_SCRIPT_TASK_STATUS_VALUE> _lastScriptTaskStatusValues = new Dictionary<(int AutomationNo, int TaskNo), ST_SCRIPT_TASK_STATUS_VALUE>();
    private IReadOnlyList<ST_INSPECTION_STATUS_ITEM> _inspectionStatusItems = [];
    private string _inspectionSummary = "0 / 0 shots";
    private string _inspectionModeText = "MODE : -";
    private string _inspectionRuleText = "RULE : -";
    private Visibility _inspectionRuleVisibility = Visibility.Collapsed;
    private IReadOnlyList<ST_INTERLOCK_GROUP> _interlockItems = [];
    private readonly CMainInterlockSnapshot _interlockSnapshot = new();
    private IReadOnlyList<ST_OPTIC_PARAMETER_GROUP> _opticParameterGroups = [];
    private IReadOnlyList<ST_OPTIC_HEAD_PARAMETER> _opticHeadParameters = [];
    private IReadOnlyList<ST_MAIN_PARAMETER_TAB_ITEM> _opticStatusTabs = [];
    private IReadOnlyList<ST_MAIN_PARAMETER_TAB_ITEM> _scannerStatusHeadTabs = [];
    private IReadOnlyList<ST_SCANNER_AXIS_STATUS_ITEM> _scannerStatusItems = [];
    private string _processStep = "";
    private string _scriptStatus = "";
    private string _scriptStatusText = "Script Status       -";
    private string _resultMessage = "";
    private string _totalShotsText = "Total Shots         0";
    private string _moveCountText = "Move Count (G0)     0";
    private string _laserOnSegmentsText = "Laser On Segments   0";
    private string _estimatedTimeText = "Estimated Time       00:00:00";
    private string _elapsedTimeText = "Elapsed Time         00:00:00";
    private string _progressText = "Progress             0.0%";
    private string _progressPercentText = "0.0%";
    private double _progressPercent;
    private string _processResultValue = "PENDING";
    private Brush _processResultBrush = CStatusBrush.Wait;
    private readonly CScannerStatusSnapshotReader _scannerStatusSnapshotReader = new(automationManager);
    private readonly CMotorStatusPollingService _motorStatusPollingService = new(interfaceManager);
    private IReadOnlyList<ST_MOTOR_STATUS_ITEM> _motorStatusItems = [];
    public IReadOnlyList<ST_MOTOR_STATUS_ITEM> MotorStatusItems
    {
        get => _motorStatusItems;
        private set => SetSequenceProperty(ref _motorStatusItems, value);
    }
    public bool IsMotorStatusSelected => _selectedParameterTabKey == ParameterTabMotor;
    public Visibility MotorStatusVisibility { get; private set; } = Visibility.Collapsed;
    private void RefreshMotorStatus()
    {
        if (!IsMotorStatusSelected) return;
        _motorStatusPollingService.Start();
        MotorStatusItems = _motorStatusPollingService.GetSnapshot();
    }
    public override EN_MENU Menu
    {
        get
        {
            return EN_MENU.Main;
        }
    }

    private IReadOnlyDictionary<int, long> _previewHeadShotCounts = new Dictionary<int, long>();
    private IReadOnlyList<ST_HEAD_PREVIEW> _headPreviews = [];
    private IReadOnlyList<ST_HEAD_PREVIEW> _oddHeadPreviews = [];
    private IReadOnlyList<ST_HEAD_PREVIEW> _evenHeadPreviews = [];
    public IReadOnlyList<ST_HEAD_PREVIEW> HeadPreviews
    {
        get => _headPreviews;
        private set => SetSequenceProperty(ref _headPreviews, value);
    }
    public IReadOnlyList<ST_HEAD_PREVIEW> OddHeadPreviews
    {
        get => _oddHeadPreviews;
        private set => SetSequenceProperty(ref _oddHeadPreviews, value);
    }
    public IReadOnlyList<ST_HEAD_PREVIEW> EvenHeadPreviews
    {
        get => _evenHeadPreviews;
        private set => SetSequenceProperty(ref _evenHeadPreviews, value);
    }

    public IReadOnlyList<ST_DISPLAY_ITEM> CycleItems
    {
        get
        {
            return _cycleItems;
        }

        private set
        {
            SetSequenceProperty(ref _cycleItems, value);
        }
    }

    public IReadOnlyList<ST_DISPLAY_ITEM> ResultItems
    {
        get
        {
            return _resultItems;
        }

        private set
        {
            SetSequenceProperty(ref _resultItems, value);
        }
    }

    public IReadOnlyList<ST_MAIN_PROCESS_SEQUENCE_ITEM> ProcessSequenceItems
    {
        get
        {
            return _processSequenceItems;
        }

        private set
        {
            SetSequenceProperty(ref _processSequenceItems, value);
        }
    }

    public IReadOnlyList<ST_DISPLAY_ITEM> CurrentStepDetails
    {
        get
        {
            return _currentStepDetails;
        }

        private set
        {
            SetSequenceProperty(ref _currentStepDetails, value);
        }
    }

    public IReadOnlyList<ST_DISPLAY_ITEM> ProcessSummaryItems
    {
        get
        {
            return _processSummaryItems;
        }

        private set
        {
            SetSequenceProperty(ref _processSummaryItems, value);
        }
    }

    public IReadOnlyList<ST_DISPLAY_ITEM> LifecycleItems
    {
        get
        {
            return _lifecycleItems;
        }

        private set
        {
            SetSequenceProperty(ref _lifecycleItems, value);
        }
    }

    public IReadOnlyList<ST_SCRIPT_TASK_STATUS_ITEM> ScriptTaskStatusItems
    {
        get
        {
            return _scriptTaskStatusItems;
        }

        private set
        {
            SetSequenceProperty(ref _scriptTaskStatusItems, value);
        }
    }

    public IReadOnlyList<ST_AUTOMATION_CONTROLLER_STATUS_ITEM> AutomationControllerStatusItems
    {
        get
        {
            return _automationControllerStatusItems;
        }

        private set
        {
            SetSequenceProperty(ref _automationControllerStatusItems, value);
        }
    }

    public IReadOnlyList<ST_INSPECTION_STATUS_ITEM> InspectionStatusItems
    {
        get
        {
            return _inspectionStatusItems;
        }

        private set
        {
            SetSequenceProperty(ref _inspectionStatusItems, value);
        }
    }

    public string InspectionSummary
    {
        get
        {
            return _inspectionSummary;
        }

        private set
        {
            SetProperty(ref _inspectionSummary, value);
        }
    }

    public string InspectionModeText
    {
        get
        {
            return _inspectionModeText;
        }

        private set
        {
            SetProperty(ref _inspectionModeText, value);
        }
    }

    public string InspectionRuleText
    {
        get
        {
            return _inspectionRuleText;
        }

        private set
        {
            SetProperty(ref _inspectionRuleText, value);
        }
    }

    public Visibility InspectionRuleVisibility
    {
        get
        {
            return _inspectionRuleVisibility;
        }

        private set
        {
            SetProperty(ref _inspectionRuleVisibility, value);
        }
    }

    public IReadOnlyList<ST_INTERLOCK_GROUP> InterlockItems
    {
        get
        {
            return _interlockItems;
        }

        private set
        {
            if (_interlockItems.Count == value.Count && _interlockItems.Zip(value).All(pair =>
                pair.First.Item == pair.Second.Item && pair.First.Details.SequenceEqual(pair.Second.Details))) return;
            SetSequenceProperty(ref _interlockItems, value);
        }
    }

    public IReadOnlyList<ST_HEAD_PARAMETER> HeadParameters { get; private set; } = [];
    public IReadOnlyList<ST_MAIN_PARAMETER_TAB_ITEM> ParameterTabs { get; private set; } = [];

    public IReadOnlyList<ST_MAIN_PARAMETER_TAB_ITEM> OpticStatusTabs
    {
        get
        {
            return _opticStatusTabs;
        }

        private set
        {
            SetSequenceProperty(ref _opticStatusTabs, value);
        }
    }

    public IReadOnlyList<ST_MAIN_PARAMETER_TAB_ITEM> ScannerStatusHeadTabs
    {
        get
        {
            return _scannerStatusHeadTabs;
        }

        private set
        {
            SetSequenceProperty(ref _scannerStatusHeadTabs, value);
        }
    }

    public IReadOnlyList<ST_OPTIC_PARAMETER_GROUP> OpticParameterGroups
    {
        get
        {
            return _opticParameterGroups;
        }

        private set
        {
            SetSequenceProperty(ref _opticParameterGroups, value);
        }
    }

    public IReadOnlyList<ST_OPTIC_HEAD_PARAMETER> OpticHeadParameters
    {
        get
        {
            return _opticHeadParameters;
        }

        private set
        {
            SetSequenceProperty(ref _opticHeadParameters, OrderOpticHeadParameters(value));
        }
    }

    public IReadOnlyList<ST_SCANNER_AXIS_STATUS_ITEM> ScannerStatusItems
    {
        get
        {
            return _scannerStatusItems;
        }

        private set
        {
            SetSequenceProperty(ref _scannerStatusItems, value);
        }
    }

    public Visibility HeadParameterVisibility { get; private set; } = Visibility.Visible;
    public Visibility OpticParameterVisibility { get; private set; } = Visibility.Collapsed;
    public Visibility ScannerStatusVisibility { get; private set; } = Visibility.Collapsed;

    public Visibility OpticLaserVisibility
    {
        get
        {
            return IsOpticStatusSelected(OpticStatusLaser) ? Visibility.Visible : Visibility.Collapsed;
        }
    }

    public Visibility OpticAttenuatorVisibility
    {
        get
        {
            return IsOpticStatusSelected(OpticStatusAttenuator) ? Visibility.Visible : Visibility.Collapsed;
        }
    }

    public Visibility OpticBetVisibility
    {
        get
        {
            return IsOpticStatusSelected(OpticStatusBet) ? Visibility.Visible : Visibility.Collapsed;
        }
    }

    public bool IsScannerStatusSelected
    {
        get
        {
            return _selectedParameterTabKey.Equals(ParameterTabScanner, StringComparison.OrdinalIgnoreCase);
        }
    }

    public bool IsOpticParameterSelected
    {
        get
        {
            return _selectedParameterTabKey.Equals(ParameterTabOptic, StringComparison.OrdinalIgnoreCase);
        }
    }

    public string ProcessStep
    {
        get
        {
            return _processStep;
        }

        private set
        {
            SetProperty(ref _processStep, value);
        }
    }

    public string ScriptStatus
    {
        get
        {
            return _scriptStatus;
        }

        private set
        {
            SetProperty(ref _scriptStatus, value);
        }
    }

    public string ScriptStatusText
    {
        get
        {
            return _scriptStatusText;
        }

        private set
        {
            SetProperty(ref _scriptStatusText, value);
        }
    }

    public string ResultMessage
    {
        get
        {
            return _resultMessage;
        }

        private set
        {
            SetProperty(ref _resultMessage, value);
        }
    }

    public string TotalShotsText
    {
        get
        {
            return _totalShotsText;
        }

        private set
        {
            SetProperty(ref _totalShotsText, value);
        }
    }

    public string MoveCountText
    {
        get
        {
            return _moveCountText;
        }

        private set
        {
            SetProperty(ref _moveCountText, value);
        }
    }

    public string LaserOnSegmentsText
    {
        get
        {
            return _laserOnSegmentsText;
        }

        private set
        {
            SetProperty(ref _laserOnSegmentsText, value);
        }
    }

    public string EstimatedTimeText
    {
        get
        {
            return _estimatedTimeText;
        }

        private set
        {
            SetProperty(ref _estimatedTimeText, value);
        }
    }

    public string ElapsedTimeText
    {
        get
        {
            return _elapsedTimeText;
        }

        private set
        {
            SetProperty(ref _elapsedTimeText, value);
        }
    }

    public string ProgressText
    {
        get
        {
            return _progressText;
        }

        private set
        {
            SetProperty(ref _progressText, value);
        }
    }

    public string ProgressPercentText
    {
        get
        {
            return _progressPercentText;
        }

        private set
        {
            SetProperty(ref _progressPercentText, value);
        }
    }

    public double ProgressPercent
    {
        get
        {
            return _progressPercent;
        }

        private set
        {
            SetProperty(ref _progressPercent, value);
        }
    }

    public string ProcessResultValue
    {
        get
        {
            return _processResultValue;
        }

        private set
        {
            SetProperty(ref _processResultValue, value);
        }
    }

    public Brush ProcessResultBrush
    {
        get
        {
            return _processResultBrush;
        }

        private set
        {
            SetProperty(ref _processResultBrush, value);
        }
    }

    public CButtonCommand SelectParameterTabCommand
    {
        get
        {
            async void SelectParameterTabCallback(object? parameter)
            {
                await SelectParameterTab(parameter);
            }

            return _selectParameterTabCommand ??= new CButtonCommand(SelectParameterTabCallback);
        }
    }

    public CButtonCommand SelectOpticStatusCommand
    {
        get
        {
            async void SelectOpticStatusCallback(object? parameter)
            {
                await SelectOpticStatus(parameter);
            }

            return _selectOpticStatusCommand ??= new CButtonCommand(SelectOpticStatusCallback);
        }
    }

    public CButtonCommand SelectScannerStatusHeadCommand
    {
        get
        {
                async void SelectScannerStatusHeadCallback(object? parameter)
                {
                    await SelectScannerStatusHead(parameter);
                }

                bool CanSelectScannerStatusHeadCallback(object? parameter)
                {
                    return CanSelectScannerStatusHead(parameter);
                }

                return _selectScannerStatusHeadCommand ??= new CButtonCommand(SelectScannerStatusHeadCallback, CanSelectScannerStatusHeadCallback);
            }
        }

    public override async Task<CScreenViewModel> Build(CancellationToken cancellationToken = default)
    {
        var snapshot = stationManager.GetStatus(cancellationToken);
        RefreshSequenceStatus(snapshot);
        var previewParameters = await LoadPreviewParameters(snapshot, cancellationToken);
        RunOptions.SetVisible(_selectedParameterTabKey == ParameterTabRunOption);
        RunOptions.UpdatePointCount(previewParameters.TryGetValue(CZeroDefenceRecipePlan.CountKey, out var pointCountText) &&
            int.TryParse(pointCountText, NumberStyles.Integer, CultureInfo.InvariantCulture, out var pointCount) ? pointCount : 2);
        var activeHeadNos = BuildEnabledHeadNumbers(previewParameters);
        NormalizeScannerStatusHeadSelection(activeHeadNos);
        var selectedHeadNos = new HashSet<int>();
        var previewHeadLayout = await LoadPreviewHeadLayout(cancellationToken);
        var inspectionStatus = BuildInspectionStatus(snapshot);
        var scriptTaskStatusItems = BuildScriptTaskStatusPlaceholders(snapshot, previewParameters);
        var automationControllerStatusItems = BuildAutomationControllerStatusPlaceholders(scriptTaskStatusItems);
        var liveInterlockItems = LoadLiveInterlockItems(snapshot, previewParameters, cancellationToken);
        var opticParameterGroups = IsOpticParameterSelected ? await BuildOpticParameterGroups(previewParameters, cancellationToken) : [];
        var opticHeadParameters = IsOpticParameterSelected ? await BuildOpticHeadParameters(previewParameters, cancellationToken) : [];
        RefreshMotorStatus();
        if (IsScannerStatusSelected)
        {
            _scannerStatusSnapshotReader.SelectHead(_selectedScannerStatusHeadNo, previewParameters);
        }

        var scannerStatusItems = IsScannerStatusSelected ? _scannerStatusSnapshotReader.GetSnapshot() : [];
        var metrics = new List<ST_DISPLAY_ITEM>
        {
            new("Cycle State", snapshot.ProcessStep.ToString()),
            new("Script", FormatScriptStatus(snapshot.ScriptStatus)),
            new("Heads", snapshot.HeadPreviews.Count.ToString()),
            new("Result", snapshot.Result?.Message ?? "Waiting")
        };
        var recipePreview = CHeadAssignmentPreviewBuilder.BuildRecipePreview(previewParameters, selectedHeadNos, previewHeadLayout);
        _previewHeadShotCounts = recipePreview.HeadPointCounts;
        global::Drilling.UI.Menu.Menus.ST_HEAD_PREVIEW SelectHeadPreviewItem(int headNo)
        {
            var isEnabled = activeHeadNos.Contains(headNo);
            var shotCount = _previewHeadShotCounts.TryGetValue(headNo, out var count) ? count : 0;
            return BuildHeadPreviewItem(headNo, shotCount, snapshot, selectedHeadNos, liveInterlockItems, scriptTaskStatusItems, isEnabled);
        }

        var headPreviewItems = Enumerable.Range(1, 8).Select(SelectHeadPreviewItem).ToArray();
        Apply(headPreviewItems, [new("Cycle State", snapshot.ProcessStep.ToString()), new("Script Status", FormatScriptStatus(snapshot.ScriptStatus)), new("Automation", "Simulation"), new("Preview Source", "Recipe Cell drilling points")], [new("Complete Time", snapshot.Result?.CompletedAt.ToString("HH:mm:ss") ?? "-"), new("Result", FormatProcessResult(snapshot)), new("Message", snapshot.Result?.Message ?? "Ready")], [..BuildProcessSequenceItems(snapshot.ProcessSequence)], [..snapshot.CurrentStepDetails.Select(ToDisplayItem)], [..snapshot.ProcessSummary.Select(ToDisplayItem)], [..snapshot.ScriptLifecycleItems.Select(ToDisplayItem)], scriptTaskStatusItems, automationControllerStatusItems, inspectionStatus.Items, inspectionStatus.Summary, inspectionStatus.ModeText, inspectionStatus.RuleText, inspectionStatus.RuleVisibility, CMainInterlockGroups.Build(liveInterlockItems), BuildHeadParameters(previewParameters, activeHeadNos), BuildParameterTabs(), BuildOpticStatusTabs(), BuildScannerStatusHeadTabs(previewParameters), opticParameterGroups, opticHeadParameters, scannerStatusItems, snapshot.ProcessStep.ToString(), FormatScriptStatus(snapshot.ScriptStatus), snapshot.Result?.Message ?? "Waiting for operator command.", snapshot.Statistics, FormatProcessResult(snapshot));
        return new CScreenViewModel(EN_MENU.Main, "MAIN", "Automatic operation, head status, script status, and cycle result.", metrics, [], showCycleControls: true, this);
    }

    public async Task<IReadOnlyList<Drilling.Common.InterLock.ST_INTERLOCK_ITEM>> GetAutoModeBlockers(CancellationToken cancellationToken = default)
    {
        // Evaluate the same current snapshot as Interlock/Safety, even before Main is opened.
        var snapshot = stationManager.GetStatus(cancellationToken);
        var parameters = await LoadPreviewParameters(snapshot, cancellationToken);
        var items = LoadLiveInterlockItems(snapshot, parameters, cancellationToken);
        InterlockItems = CMainInterlockGroups.Build(items);
        return items.Where(item => !CMainInterlockGroups.IsOk(item)).ToArray();
    }

    public async Task RefreshLiveStatus(CancellationToken cancellationToken = default)
    {
        var snapshot = stationManager.GetStatus(cancellationToken);
        RefreshSequenceStatus(snapshot);
        var previewParameters = await LoadPreviewParameters(snapshot, cancellationToken);
        var activeHeadNos = BuildEnabledHeadNumbers(previewParameters);
        NormalizeScannerStatusHeadSelection(activeHeadNos);
        var inspectionStatus = BuildInspectionStatus(snapshot);
        var statistics = snapshot.Statistics;
        CycleItems = [new("Cycle State", snapshot.ProcessStep.ToString()), new("Script Status", FormatScriptStatus(snapshot.ScriptStatus)), new("Automation", "Simulation"), new("Preview Source", "Recipe Cell drilling points")];
        ResultItems = [new("Complete Time", snapshot.Result?.CompletedAt.ToString("HH:mm:ss") ?? "-"), new("Result", FormatProcessResult(snapshot)), new("Message", snapshot.Result?.Message ?? "Ready")];
        ProcessSequenceItems = BuildProcessSequenceItems(snapshot.ProcessSequence);
        CurrentStepDetails = [..snapshot.CurrentStepDetails.Select(ToDisplayItem)];
        ProcessSummaryItems = [..snapshot.ProcessSummary.Select(ToDisplayItem)];
        LifecycleItems = [..snapshot.ScriptLifecycleItems.Select(ToDisplayItem)];
        InspectionStatusItems = inspectionStatus.Items;
        InspectionSummary = inspectionStatus.Summary;
        InspectionModeText = inspectionStatus.ModeText;
        InspectionRuleText = inspectionStatus.RuleText;
        InspectionRuleVisibility = inspectionStatus.RuleVisibility;
        var liveInterlockItems = LoadLiveInterlockItems(snapshot, previewParameters, cancellationToken);
        InterlockItems = CMainInterlockGroups.Build(liveInterlockItems);
        HeadParameters = BuildHeadParameters(previewParameters, activeHeadNos);
        ScannerStatusHeadTabs = BuildScannerStatusHeadTabs(previewParameters);
        ProcessStep = snapshot.ProcessStep.ToString();
        ScriptStatus = FormatScriptStatus(snapshot.ScriptStatus);
        ScriptStatusText = $"Script Status       {ScriptStatus}";
        ResultMessage = snapshot.Result?.Message ?? "Waiting for operator command.";
        TotalShotsText = $"Total Shots         {statistics.TotalShots:N0}";
        MoveCountText = $"Move Count (G0)     {statistics.MoveCount:N0}";
        LaserOnSegmentsText = $"Laser On Segments   {statistics.LaserOnSegments:N0}";
        EstimatedTimeText = $"Estimated Time       {FormatDuration(statistics.EstimatedTime)}";
        ElapsedTimeText = $"Elapsed Time         {FormatDuration(statistics.ElapsedTime)}";
        ProgressText = $"Progress             {statistics.ProgressPercent:F1}%";
        ProgressPercentText = $"{statistics.ProgressPercent:F1}%";
        ProgressPercent = statistics.ProgressPercent;
        ProcessResultValue = FormatProcessResult(snapshot);
        ProcessResultBrush = CStatusBrush.ForDisplayState(ProcessResultValue);
        if (IsOpticParameterSelected)
        {
            OpticParameterGroups = await BuildOpticParameterGroups(previewParameters, cancellationToken);
            OpticHeadParameters = await BuildOpticHeadParameters(previewParameters, cancellationToken);
        }

        RefreshMotorStatus();
        if (IsScannerStatusSelected)
        {
            _scannerStatusSnapshotReader.SelectHead(_selectedScannerStatusHeadNo, previewParameters);
            ScannerStatusItems = _scannerStatusSnapshotReader.GetSnapshot();
        }

        var scriptTaskStatusItems = await BuildScriptTaskStatusItems(snapshot, previewParameters, cancellationToken);
        ScriptTaskStatusItems = scriptTaskStatusItems;
        var selectedHeadNos = new HashSet<int>();
        SetHeadPreviews(Enumerable.Range(1, 8).Select(headNo => BuildHeadPreviewItem(
            headNo, _previewHeadShotCounts.TryGetValue(headNo, out var count) ? count : 0,
            snapshot, selectedHeadNos, liveInterlockItems, scriptTaskStatusItems, activeHeadNos.Contains(headNo))).ToArray());
        AutomationControllerStatusItems = await BuildAutomationControllerStatusItems(scriptTaskStatusItems, cancellationToken);
    }

    private void SetHeadPreviews(IReadOnlyList<ST_HEAD_PREVIEW> headPreviews)
    {
        HeadPreviews = headPreviews;
        OddHeadPreviews = headPreviews.Where(head => head.HeadNo % 2 != 0).OrderBy(head => head.HeadNo).ToArray();
        EvenHeadPreviews = headPreviews.Where(head => head.HeadNo % 2 == 0).OrderBy(head => head.HeadNo).ToArray();
    }

    private void Apply(IReadOnlyList<ST_HEAD_PREVIEW> headPreviews, IReadOnlyList<ST_DISPLAY_ITEM> cycleItems, IReadOnlyList<ST_DISPLAY_ITEM> resultItems, IReadOnlyList<ST_MAIN_PROCESS_SEQUENCE_ITEM> processSequenceItems, IReadOnlyList<ST_DISPLAY_ITEM> currentStepDetails, IReadOnlyList<ST_DISPLAY_ITEM> processSummaryItems, IReadOnlyList<ST_DISPLAY_ITEM> lifecycleItems, IReadOnlyList<ST_SCRIPT_TASK_STATUS_ITEM> scriptTaskStatusItems, IReadOnlyList<ST_AUTOMATION_CONTROLLER_STATUS_ITEM> automationControllerStatusItems, IReadOnlyList<ST_INSPECTION_STATUS_ITEM> inspectionStatusItems, string inspectionSummary, string inspectionModeText, string inspectionRuleText, Visibility inspectionRuleVisibility, IReadOnlyList<ST_INTERLOCK_GROUP> interlockItems, IReadOnlyList<ST_HEAD_PARAMETER> headParameters, IReadOnlyList<ST_MAIN_PARAMETER_TAB_ITEM> parameterTabs, IReadOnlyList<ST_MAIN_PARAMETER_TAB_ITEM> opticStatusTabs, IReadOnlyList<ST_MAIN_PARAMETER_TAB_ITEM> scannerStatusHeadTabs, IReadOnlyList<ST_OPTIC_PARAMETER_GROUP> opticParameterGroups, IReadOnlyList<ST_OPTIC_HEAD_PARAMETER> opticHeadParameters, IReadOnlyList<ST_SCANNER_AXIS_STATUS_ITEM> scannerStatusItems, string processStep, string scriptStatus, string resultMessage, ST_PROCESS_STATISTICS statistics, string processResultValue)
    {
        SetHeadPreviews(headPreviews);
        CycleItems = cycleItems;
        ResultItems = resultItems;
        ProcessSequenceItems = processSequenceItems;
        CurrentStepDetails = currentStepDetails;
        ProcessSummaryItems = processSummaryItems;
        LifecycleItems = lifecycleItems;
        ScriptTaskStatusItems = scriptTaskStatusItems;
        AutomationControllerStatusItems = automationControllerStatusItems;
        InspectionStatusItems = inspectionStatusItems;
        InspectionSummary = inspectionSummary;
        InspectionModeText = inspectionModeText;
        InspectionRuleText = inspectionRuleText;
        InspectionRuleVisibility = inspectionRuleVisibility;
        InterlockItems = interlockItems;
        HeadParameters = headParameters;
        ParameterTabs = parameterTabs;
        OpticStatusTabs = opticStatusTabs;
        ScannerStatusHeadTabs = scannerStatusHeadTabs;
        OpticParameterGroups = opticParameterGroups;
        OpticHeadParameters = opticHeadParameters;
        ScannerStatusItems = scannerStatusItems;
        MotorStatusVisibility = IsMotorStatusSelected ? Visibility.Visible : Visibility.Collapsed;
        HeadParameterVisibility = _selectedParameterTabKey.Equals(ParameterTabHead, StringComparison.OrdinalIgnoreCase) ? Visibility.Visible : Visibility.Collapsed;
        OpticParameterVisibility = _selectedParameterTabKey.Equals(ParameterTabOptic, StringComparison.OrdinalIgnoreCase) ? Visibility.Visible : Visibility.Collapsed;
        ScannerStatusVisibility = _selectedParameterTabKey.Equals(ParameterTabScanner, StringComparison.OrdinalIgnoreCase) ? Visibility.Visible : Visibility.Collapsed;
        ProcessStep = processStep;
        ScriptStatus = scriptStatus;
        ScriptStatusText = $"Script Status       {scriptStatus}";
        ResultMessage = resultMessage;
        TotalShotsText = $"Total Shots         {statistics.TotalShots:N0}";
        MoveCountText = $"Move Count (G0)     {statistics.MoveCount:N0}";
        LaserOnSegmentsText = $"Laser On Segments   {statistics.LaserOnSegments:N0}";
        EstimatedTimeText = $"Estimated Time       {FormatDuration(statistics.EstimatedTime)}";
        ElapsedTimeText = $"Elapsed Time         {FormatDuration(statistics.ElapsedTime)}";
        ProgressText = $"Progress             {statistics.ProgressPercent:F1}%";
        ProgressPercentText = $"{statistics.ProgressPercent:F1}%";
        ProgressPercent = statistics.ProgressPercent;
        ProcessResultValue = processResultValue;
        ProcessResultBrush = CStatusBrush.ForDisplayState(processResultValue);
    }

    public static string FormatScriptStatus(EN_SCRIPT_STATUS status)
    {
        return status switch
        {
            EN_SCRIPT_STATUS.NotCreated => "Not Created",
            _ => status.ToString()};
    }

    private static ST_DISPLAY_ITEM ToDisplayItem(ST_PROCESS_DISPLAY_ITEM item)
    {
        return new ST_DISPLAY_ITEM(item.Name, item.Value, item.Detail);
    }

    private static IReadOnlyList<ST_MAIN_PROCESS_SEQUENCE_ITEM> BuildProcessSequenceItems(IReadOnlyList<ST_PROCESS_DISPLAY_ITEM> processSequence)
        => processSequence.Select(item => new ST_MAIN_PROCESS_SEQUENCE_ITEM(item.Name, item.Value, item.Detail)).ToArray();

    private async Task SelectParameterTab(object? parameter)
    {
        var tabKey = parameter is ST_MAIN_PARAMETER_TAB_ITEM tabItem ? tabItem.Key : parameter?.ToString();
        tabKey = tabKey?.Trim().ToUpperInvariant();
        if (tabKey is not ParameterTabRunOption and not ParameterTabHead and not ParameterTabOptic and not ParameterTabScanner and not ParameterTabMotor)
        {
            return;
        }

        if (_selectedParameterTabKey.Equals(tabKey, StringComparison.OrdinalIgnoreCase))
        {
            return;
        }

        StopScannerStatusPolling();
        _selectedParameterTabKey = tabKey;
        RunOptions.SetVisible(tabKey == ParameterTabRunOption);
        if (IsScannerStatusSelected)
        {
            _scannerStatusSnapshotReader.SelectHead(_selectedScannerStatusHeadNo);
        }

        await refreshCurrentScreen();
    }

    private async Task SelectOpticStatus(object? parameter)
    {
        var statusKey = parameter is ST_MAIN_PARAMETER_TAB_ITEM tabItem ? tabItem.Key : parameter?.ToString();
        statusKey = statusKey?.Trim().ToUpperInvariant();
        if (statusKey is not OpticStatusLaser and not OpticStatusAttenuator and not OpticStatusBet)
        {
            return;
        }

        if (_selectedOpticStatusKey.Equals(statusKey, StringComparison.OrdinalIgnoreCase))
        {
            return;
        }

        _selectedOpticStatusKey = statusKey;
        NotifyOpticStatusSelectionChanged();
        await refreshCurrentScreen();
    }

    private async Task SelectScannerStatusHead(object? parameter)
    {
        if (!CanSelectScannerStatusHead(parameter))
        {
            return;
        }

        var key = parameter is ST_MAIN_PARAMETER_TAB_ITEM tabItem ? tabItem.Key : parameter?.ToString();
        if (!int.TryParse(key, NumberStyles.Integer, CultureInfo.InvariantCulture, out var headNo))
        {
            return;
        }

        var normalizedHeadNo = Math.Clamp(headNo, 1, 8);
        if (_selectedScannerStatusHeadNo == normalizedHeadNo)
        {
            return;
        }

        _selectedScannerStatusHeadNo = normalizedHeadNo;
        _scannerStatusSnapshotReader.SelectHead(_selectedScannerStatusHeadNo);
        await refreshCurrentScreen();
    }

    private void NormalizeScannerStatusHeadSelection(IReadOnlyList<int> enabledHeadNos)
    {
        if (enabledHeadNos.Count == 0 || enabledHeadNos.Contains(_selectedScannerStatusHeadNo))
        {
            return;
        }

        _selectedScannerStatusHeadNo = enabledHeadNos[0];
        _scannerStatusSnapshotReader.SelectHead(_selectedScannerStatusHeadNo);
    }

    private IReadOnlyList<ST_MAIN_PARAMETER_TAB_ITEM> BuildParameterTabs()
    {
        return[new(ParameterTabRunOption, "Run Option", _selectedParameterTabKey.Equals(ParameterTabRunOption, StringComparison.OrdinalIgnoreCase)), new(ParameterTabHead, "Head Parameter", _selectedParameterTabKey.Equals(ParameterTabHead, StringComparison.OrdinalIgnoreCase)), new(ParameterTabOptic, "Optic Parameter", _selectedParameterTabKey.Equals(ParameterTabOptic, StringComparison.OrdinalIgnoreCase)), new(ParameterTabScanner, "Scanner Status", _selectedParameterTabKey.Equals(ParameterTabScanner, StringComparison.OrdinalIgnoreCase)), new(ParameterTabMotor, "Motor Status", IsMotorStatusSelected)];
    }

    private IReadOnlyList<ST_MAIN_PARAMETER_TAB_ITEM> BuildOpticStatusTabs()
    {
        return[new(OpticStatusLaser, "LASER", IsOpticStatusSelected(OpticStatusLaser)), new(OpticStatusAttenuator, "ATT", IsOpticStatusSelected(OpticStatusAttenuator)), new(OpticStatusBet, "BET", IsOpticStatusSelected(OpticStatusBet))];
    }

    private IReadOnlyList<ST_MAIN_PARAMETER_TAB_ITEM> BuildScannerStatusHeadTabs(IReadOnlyDictionary<string, string> parameters)
    {
        const int headCount = 8;
        var tabs = new List<ST_MAIN_PARAMETER_TAB_ITEM>(headCount);
        for (var headNo = 1; headNo <= headCount; headNo++)
        {
            var isEnabled = IsHeadEnabled(parameters, headNo);
            var name = isEnabled ? $"H{headNo:00}" : $"H{headNo:00} NOT USE";
            tabs.Add(new ST_MAIN_PARAMETER_TAB_ITEM(headNo.ToString(CultureInfo.InvariantCulture), name, isEnabled && _selectedScannerStatusHeadNo == headNo, isEnabled));
        }

        return tabs;
    }

    private static bool CanSelectScannerStatusHead(object? parameter)
    {
        return parameter switch
        {
            ST_MAIN_PARAMETER_TAB_ITEM tabItem => tabItem.IsEnabled,
            _ => true
        };
    }

    private bool IsOpticStatusSelected(string statusKey)
    {
        return _selectedOpticStatusKey.Equals(statusKey, StringComparison.OrdinalIgnoreCase);
    }

    private void NotifyOpticStatusSelectionChanged()
    {
        OnPropertyChanged(nameof(OpticLaserVisibility));
        OnPropertyChanged(nameof(OpticAttenuatorVisibility));
        OnPropertyChanged(nameof(OpticBetVisibility));
    }

    public void StopScannerStatusPolling()
    {
        try
        {
            _motorStatusPollingService.Stop();
            _motorStatusPollingService.ClearSnapshot();
        }
        catch (TimeoutException exception)
        {
            statusReporter($"Motor status polling stop timeout. {exception.Message}");
        }
    }

    // Shared presentation path for Main and Manual MOF. Reads memory snapshots only.
    public IReadOnlyList<ST_AUTOMATION_CONTROLLER_STATUS_ITEM> ReadAutomationControllerStatusSnapshot(
        ST_STATION_PROCESS_STATUS snapshot, IReadOnlyDictionary<string, string> parameters,
        CancellationToken cancellationToken = default)
        => BuildAutomationControllerStatusSnapshot(BuildScriptTaskStatusSnapshot(snapshot, parameters, cancellationToken), cancellationToken);

    private Task<IReadOnlyList<ST_SCRIPT_TASK_STATUS_ITEM>> BuildScriptTaskStatusItems(ST_STATION_PROCESS_STATUS snapshot, IReadOnlyDictionary<string, string> previewParameters, CancellationToken cancellationToken)
        => Task.FromResult(BuildScriptTaskStatusSnapshot(snapshot, previewParameters, cancellationToken));

    private IReadOnlyList<ST_SCRIPT_TASK_STATUS_ITEM> BuildScriptTaskStatusSnapshot(ST_STATION_PROCESS_STATUS snapshot, IReadOnlyDictionary<string, string> previewParameters, CancellationToken cancellationToken)
    {
        var definitions = BuildScriptTaskDefinitions(snapshot, previewParameters);
        var statusCache = new Dictionary<(int AutomationNo, int TaskNo), ST_SCRIPT_TASK_STATUS_VALUE>();
        var nextStatusValues = new Dictionary<(int AutomationNo, int TaskNo), ST_SCRIPT_TASK_STATUS_VALUE>(_lastScriptTaskStatusValues);
        var items = new List<ST_SCRIPT_TASK_STATUS_ITEM>(definitions.Count);
        foreach (var definition in definitions)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var key = (definition.AutomationNo, definition.TaskNo);
            if (!statusCache.TryGetValue(key, out var status))
            {
                status = ReadScriptTaskStatusSnapshot(definition.AutomationNo, definition.TaskNo, definition.ScriptFileName, cancellationToken);
                if (_lastScriptTaskStatusValues.TryGetValue(key, out var previousStatus) && ShouldKeepPreviousScriptTaskStatus(snapshot, status, previousStatus))
                {
                    status = previousStatus;
                }
                else
                {
                    nextStatusValues[key] = status;
                }

                statusCache[key] = status;
            }

            var displayStatus = NormalizeScriptTaskStatusForDisplay(status);
            items.Add(new ST_SCRIPT_TASK_STATUS_ITEM($"TASK {definition.TaskNo}", $"H{definition.HeadNo:00}", $"A{definition.AutomationNo}", $"T{definition.TaskNo}", displayStatus.State, string.IsNullOrWhiteSpace(displayStatus.FileName) ? definition.ScriptFileName : displayStatus.FileName, displayStatus.Detail, definition.TotalShots)
                { IsSimulation = automationManager.IsSimul(definition.AutomationNo) });
        }

        _lastScriptTaskStatusValues = nextStatusValues;
        return items;
    }

    private Task<IReadOnlyList<ST_AUTOMATION_CONTROLLER_STATUS_ITEM>> BuildAutomationControllerStatusItems(IReadOnlyList<ST_SCRIPT_TASK_STATUS_ITEM> taskStatusItems, CancellationToken cancellationToken)
        => Task.FromResult(BuildAutomationControllerStatusSnapshot(taskStatusItems, cancellationToken));

    private IReadOnlyList<ST_AUTOMATION_CONTROLLER_STATUS_ITEM> BuildAutomationControllerStatusSnapshot(IReadOnlyList<ST_SCRIPT_TASK_STATUS_ITEM> taskStatusItems, CancellationToken cancellationToken)
    {
        var controllerNos = BuildAutomationControllerNumbers(taskStatusItems);
        var items = new List<ST_AUTOMATION_CONTROLLER_STATUS_ITEM>(controllerNos.Count);
        foreach (var automationNo in controllerNos)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var usage = ReadAutomationControllerUsageSnapshot(automationNo, cancellationToken);
            items.Add(new ST_AUTOMATION_CONTROLLER_STATUS_ITEM(automationNo, usage.State, usage.Percent, usage.Detail, BuildControllerTaskStatusItems(taskStatusItems, automationNo)));
        }

        return items;
    }

    private Task<ST_AUTOMATION_CONTROLLER_USAGE_VALUE> ReadAutomationControllerUsage(int automationNo, CancellationToken cancellationToken) => Task.FromResult(ReadAutomationControllerUsageSnapshot(automationNo, cancellationToken));

    private ST_AUTOMATION_CONTROLLER_USAGE_VALUE ReadAutomationControllerUsageSnapshot(int automationNo, CancellationToken cancellationToken)
    {
        try
        {
            if (automationManager.IsSimul(automationNo))
            {
                return new ST_AUTOMATION_CONTROLLER_USAGE_VALUE("SIM", 0.0, "Simulation mode");
            }

            if (!automationManager.IsConnect(automationNo))
            {
                return new ST_AUTOMATION_CONTROLLER_USAGE_VALUE("OFFLINE", 0.0, "Automation1 is not connected");
            }

            var cached = automationManager.StatusSnapshots.GetProcessorUsage(automationNo);
            if (cached.Value is not { } response)
                return new ST_AUTOMATION_CONTROLLER_USAGE_VALUE(cached.State == "LOADING" ? "WAIT" : cached.State, 0, cached.Detail);
            return ParseAutomationControllerUsage(response);
        }
        catch (Exception exception)when (exception is not OperationCanceledException)
        {
            return new ST_AUTOMATION_CONTROLLER_USAGE_VALUE("ERROR", 0.0, exception.Message);
        }
    }

    private static ST_AUTOMATION_CONTROLLER_USAGE_VALUE ParseLiveAutomationControllerUsage(string processorUsage)
    {
        var value = string.IsNullOrWhiteSpace(processorUsage) ? "WAIT" : processorUsage.Trim();
        if (double.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out var usage))
        {
            var clampedUsage = Math.Clamp(usage, 0.0, 100.0);
            var state = clampedUsage >= 90.0 ? "WARN" : "OK";
            return new ST_AUTOMATION_CONTROLLER_USAGE_VALUE(state, clampedUsage, "Live scanner status snapshot");
        }

        var normalized = value.ToUpperInvariant();
        if (normalized.Equals("SIM", StringComparison.Ordinal))
        {
            return new ST_AUTOMATION_CONTROLLER_USAGE_VALUE("SIM", 0.0, "Simulation mode");
        }

        if (normalized.Equals("OFFLINE", StringComparison.Ordinal))
        {
            return new ST_AUTOMATION_CONTROLLER_USAGE_VALUE("OFFLINE", 0.0, "Automation1 is not connected");
        }

        if (normalized.Equals("ERROR", StringComparison.Ordinal))
        {
            return new ST_AUTOMATION_CONTROLLER_USAGE_VALUE("ERROR", 0.0, "Live scanner status snapshot error");
        }

        return new ST_AUTOMATION_CONTROLLER_USAGE_VALUE("WAIT", 0.0, "Waiting for live scanner status snapshot");
    }

    private static ST_AUTOMATION_CONTROLLER_USAGE_VALUE ParseAutomationControllerUsage(string response)
    {
        var fields = response.Split(':');
        if (fields.Length >= 4 && fields[0].Equals("OK", StringComparison.OrdinalIgnoreCase) && fields[1].Equals("SYSTEM", StringComparison.OrdinalIgnoreCase) && fields[2].Equals("PROCESSOR_USAGE", StringComparison.OrdinalIgnoreCase) && double.TryParse(fields[3], NumberStyles.Float, CultureInfo.InvariantCulture, out var usage))
        {
            var clampedUsage = Math.Clamp(usage, 0.0, 100.0);
            var state = clampedUsage >= 90.0 ? "WARN" : "OK";
            return new ST_AUTOMATION_CONTROLLER_USAGE_VALUE(state, clampedUsage, "Estimated SMC processor usage");
        }

        return response.StartsWith("OK", StringComparison.OrdinalIgnoreCase) ? new ST_AUTOMATION_CONTROLLER_USAGE_VALUE("OK", 0.0, response) : new ST_AUTOMATION_CONTROLLER_USAGE_VALUE("ERROR", 0.0, response);
    }

    private static IReadOnlyList<ST_AUTOMATION_CONTROLLER_STATUS_ITEM> BuildAutomationControllerStatusPlaceholders(IReadOnlyList<ST_SCRIPT_TASK_STATUS_ITEM> taskStatusItems)
    {
        var controllerNos = BuildAutomationControllerNumbers(taskStatusItems);
        var items = new List<ST_AUTOMATION_CONTROLLER_STATUS_ITEM>(controllerNos.Count);
        foreach (var automationNo in controllerNos)
        {
            items.Add(new ST_AUTOMATION_CONTROLLER_STATUS_ITEM(automationNo, "WAIT", 0.0, "Waiting for controller status", BuildControllerTaskStatusItems(taskStatusItems, automationNo)));
        }

        return items;
    }

    private static IReadOnlyList<int> BuildAutomationControllerNumbers(IReadOnlyList<ST_SCRIPT_TASK_STATUS_ITEM> taskStatusItems)
    {
        var controllerNos = new SortedSet<int>
        {
            0,
            1
        };
        foreach (var item in taskStatusItems)
        {
            controllerNos.Add(item.AutomationNoValue);
        }

        return controllerNos.ToArray();
    }

    private static IReadOnlyList<ST_SCRIPT_TASK_STATUS_ITEM> BuildControllerTaskStatusItems(IReadOnlyList<ST_SCRIPT_TASK_STATUS_ITEM> taskStatusItems, int automationNo)
    {
        int SelectHeadNoValue(global::Drilling.UI.Menu.Menus.ST_SCRIPT_TASK_STATUS_ITEM item)
        {
            return item.HeadNoValue;
        }

        string SelectHead(global::Drilling.UI.Menu.Menus.ST_SCRIPT_TASK_STATUS_ITEM item)
        {
            return item.Head;
        }

        bool ShouldIncludeItem(global::Drilling.UI.Menu.Menus.ST_SCRIPT_TASK_STATUS_ITEM item)
        {
            return item.AutomationNoValue == automationNo;
        }

        return taskStatusItems.Where(ShouldIncludeItem).OrderBy(SelectHeadNoValue).ThenBy(SelectHead).ToArray();
    }

    private static IReadOnlyList<ST_SCRIPT_TASK_STATUS_ITEM> BuildScriptTaskStatusPlaceholders(ST_STATION_PROCESS_STATUS snapshot, IReadOnlyDictionary<string, string> previewParameters)
    {
        global::Drilling.UI.Menu.Menus.ST_SCRIPT_TASK_STATUS_ITEM BuildScript(global::Drilling.UI.Menu.Menus.ST_SCRIPT_TASK_DEFINITION definition)
        {
            return new ST_SCRIPT_TASK_STATUS_ITEM($"TASK {definition.TaskNo}", $"H{definition.HeadNo:00}", $"A{definition.AutomationNo}", $"T{definition.TaskNo}", "WAIT", definition.ScriptFileName, "Waiting for status", definition.TotalShots);
        }

        return BuildScriptTaskDefinitions(snapshot, previewParameters).Select(BuildScript).ToArray();
    }

    private static IReadOnlyList<ST_SCRIPT_TASK_DEFINITION> BuildScriptTaskDefinitions(ST_STATION_PROCESS_STATUS snapshot, IReadOnlyDictionary<string, string> previewParameters)
    {
        int SelectHeadNo(global::Drilling.Common.Station.ST_HEAD_PROCESS_PLAN head)
        {
            return head.HeadNo;
        }

        int SelectKey(global::System.Linq.IGrouping<int, global::Drilling.Common.Station.ST_HEAD_PROCESS_PLAN> group)
        {
            return group.Key;
        }

        global::Drilling.Common.Station.ST_HEAD_PROCESS_PLAN SelectValue(global::System.Linq.IGrouping<int, global::Drilling.Common.Station.ST_HEAD_PROCESS_PLAN> group)
        {
            return group.Last();
        }

        var headMap = ShouldUseProcessModelTaskDefinitions(snapshot) ? snapshot.ProcessModel?.HeadPlans.GroupBy(SelectHeadNo).ToDictionary(SelectKey, SelectValue) ?? [] : [];
        global::Drilling.UI.Menu.Menus.ST_SCRIPT_TASK_DEFINITION ifCallback(int headNo)
        {
            if (headMap.TryGetValue(headNo, out var head))
            {
                return new ST_SCRIPT_TASK_DEFINITION(headNo, head.AutomationNo, head.TaskNo, head.ScriptFileName, head.Shots.Count);
            }

            return new ST_SCRIPT_TASK_DEFINITION(headNo, ReadMainHeadAutomationNo(previewParameters, headNo), ReadMainHeadAutomationTaskNo(previewParameters, headNo), $"PROCESS_H{headNo:00}.ascript", 0);
        }

        var enabledHeadNos = BuildEnabledHeadNumbers(previewParameters);
        var definitions = new List<ST_SCRIPT_TASK_DEFINITION>(enabledHeadNos.Count);
        foreach (var headNo in enabledHeadNos)
        {
            definitions.Add(ifCallback(headNo));
        }

        return definitions;
    }

    private static bool ShouldUseProcessModelTaskDefinitions(ST_STATION_PROCESS_STATUS snapshot)
    {
        if (snapshot.ProcessModel is null)
        {
            return false;
        }

        if (snapshot.ScriptStatus is EN_SCRIPT_STATUS.Created or EN_SCRIPT_STATUS.Running)
        {
            return true;
        }

        return snapshot.ProcessStep is EN_PROCESS_STEP.PowerCheck or EN_PROCESS_STEP.Align or EN_PROCESS_STEP.Process or EN_PROCESS_STEP.Inspection;
    }

    private Task<ST_SCRIPT_TASK_STATUS_VALUE> ReadScriptTaskStatus(int automationNo, int taskNo, string defaultFileName, CancellationToken cancellationToken) => Task.FromResult(ReadScriptTaskStatusSnapshot(automationNo, taskNo, defaultFileName, cancellationToken));

    private ST_SCRIPT_TASK_STATUS_VALUE ReadScriptTaskStatusSnapshot(int automationNo, int taskNo, string defaultFileName, CancellationToken cancellationToken)
    {
        try
        {
            if (!automationManager.IsSimul(automationNo) && !automationManager.IsConnect(automationNo))
            {
                return new ST_SCRIPT_TASK_STATUS_VALUE("OFFLINE", defaultFileName, "Automation1 is not connected");
            }

            var cached = automationManager.StatusSnapshots.GetTask(taskNo, automationNo);
            if (cached.Value is not { } response)
                return new ST_SCRIPT_TASK_STATUS_VALUE(cached.State == "LOADING" ? "WAIT" : cached.State, defaultFileName, cached.Detail);
            var status = ParseScriptTaskStatus(response, defaultFileName);
            return automationManager.IsSimul(automationNo)
                ? status with { Detail = $"SIMULATION · {status.Detail}" }
                : status;
        }
        catch (Exception exception)when (exception is not OperationCanceledException)
        {
            return new ST_SCRIPT_TASK_STATUS_VALUE("ERROR", defaultFileName, exception.Message);
        }
    }

    private static bool ShouldKeepPreviousScriptTaskStatus(ST_STATION_PROCESS_STATUS snapshot, ST_SCRIPT_TASK_STATUS_VALUE status, ST_SCRIPT_TASK_STATUS_VALUE previousStatus)
    {
        if (snapshot.ScriptStatus != EN_SCRIPT_STATUS.Running)
        {
            return false;
        }

        var state = status.State.Trim();
        if (IsBufferedRunPendingTaskState(state))
        {
            return previousStatus.State.Equals("RUNNING", StringComparison.OrdinalIgnoreCase);
        }

        return state.Equals("WAIT", StringComparison.OrdinalIgnoreCase);
    }

    private static ST_SCRIPT_TASK_STATUS_VALUE NormalizeScriptTaskStatusForDisplay(ST_SCRIPT_TASK_STATUS_VALUE status)
    {
        if (IsBufferedRunPendingTaskState(status.State))
        {
            return status with
            {
                State = "WAIT"
            };
        }

        return status;
    }

    private static ST_SCRIPT_TASK_STATUS_VALUE ParseScriptTaskStatus(string response, string defaultFileName)
    {
        var automationError = FormatAutomationErrorResponse(response);
        if (!string.IsNullOrWhiteSpace(automationError))
        {
            return new ST_SCRIPT_TASK_STATUS_VALUE("ERROR", defaultFileName, automationError);
        }

        var fields = response.Split(':');
        if (fields.Length >= 4 && fields[0].Equals("OK", StringComparison.OrdinalIgnoreCase) && fields[1].Equals("TASK", StringComparison.OrdinalIgnoreCase))
        {
            var state = FormatScriptTaskState(fields[3]);
            var fileName = fields.Length >= 5 && !string.IsNullOrWhiteSpace(fields[4]) ? fields[4].Trim() : defaultFileName;
            var error = fields.Length >= 6 ? fields[5].Trim() : "";
            var detail = string.IsNullOrWhiteSpace(error) ? "OK" : error;
            return new ST_SCRIPT_TASK_STATUS_VALUE(state, fileName, detail);
        }

        return response.StartsWith("OK", StringComparison.OrdinalIgnoreCase) ? new ST_SCRIPT_TASK_STATUS_VALUE("OK", defaultFileName, response) : new ST_SCRIPT_TASK_STATUS_VALUE("ERROR", defaultFileName, response);
    }

    private static string FormatAutomationErrorResponse(string response)
    {
        if (string.IsNullOrWhiteSpace(response))
        {
            return "";
        }

        var fields = response.Trim().Split(':', 4, StringSplitOptions.TrimEntries);
        if (fields.Length >= 4 && fields[0].Equals("ERROR", StringComparison.OrdinalIgnoreCase) && fields[1].Equals("AUTOMATION1", StringComparison.OrdinalIgnoreCase))
        {
            return $"{fields[2]}: {fields[3]}";
        }

        return "";
    }

    private static string FormatScriptTaskState(string state)
    {
        var normalized = state.Trim().Replace("_", " ", StringComparison.Ordinal).ToUpperInvariant();
        if (string.IsNullOrWhiteSpace(normalized))
        {
            return "UNKNOWN";
        }

        if (normalized.Equals("QUEUERUNNING", StringComparison.OrdinalIgnoreCase))
        {
            return "RUNNING";
        }

        if (normalized.Equals("QUEUECOMPLETE", StringComparison.OrdinalIgnoreCase))
        {
            return "DONE";
        }

        if (IsBufferedRunPendingTaskState(normalized))
        {
            return "QUEUEPENDING";
        }

        if (normalized.Contains("ERROR", StringComparison.OrdinalIgnoreCase) || normalized.Contains("FAULT", StringComparison.OrdinalIgnoreCase))
        {
            return "ERROR";
        }

        if (normalized.Contains("RUN", StringComparison.OrdinalIgnoreCase) || normalized.Contains("EXEC", StringComparison.OrdinalIgnoreCase))
        {
            return "RUNNING";
        }

        if (normalized.Contains("STOP", StringComparison.OrdinalIgnoreCase))
        {
            return "STOPPED";
        }

        if (normalized.Contains("IDLE", StringComparison.OrdinalIgnoreCase) || normalized.Contains("INACTIVE", StringComparison.OrdinalIgnoreCase))
        {
            return "IDLE";
        }

        if (normalized.Contains("DONE", StringComparison.OrdinalIgnoreCase) || normalized.Contains("COMPLETE", StringComparison.OrdinalIgnoreCase))
        {
            return "DONE";
        }

        return normalized;
    }

    private static bool IsBufferedRunPendingTaskState(string state)
    {
        return state.Equals("QUEUEPENDING", StringComparison.OrdinalIgnoreCase) || state.Equals("QUEUESTARTING", StringComparison.OrdinalIgnoreCase) || state.Equals("QUEUERUNNING", StringComparison.OrdinalIgnoreCase) || state.Equals("QUEUECOMPLETE", StringComparison.OrdinalIgnoreCase);
    }

    private static int ReadMainHeadAutomationNo(IReadOnlyDictionary<string, string> parameters, int headNo)
    {
        return Math.Max(0, ReadIntAny(parameters, headNo <= 4 ? 0 : 1, $"H{headNo:00}_AUTOMATION_NO"));
    }

    private static int ReadMainHeadAutomationTaskNo(IReadOnlyDictionary<string, string> parameters, int headNo)
    {
        return Math.Max(1, ReadIntAny(parameters, ((headNo - 1) % 4) + 1, $"H{headNo:00}_AUTOMATION_TASK_NO"));
    }

    private Task<IReadOnlyList<ST_OPTIC_PARAMETER_GROUP>> BuildOpticParameterGroups(IReadOnlyDictionary<string, string> previewParameters, CancellationToken cancellationToken)
    {
        var groups = new List<ST_OPTIC_PARAMETER_GROUP>();
        return Task.FromResult<IReadOnlyList<ST_OPTIC_PARAMETER_GROUP>>(groups);
    }

    private async Task<IReadOnlyList<ST_OPTIC_HEAD_PARAMETER>> BuildOpticHeadParameters(IReadOnlyDictionary<string, string> previewParameters, CancellationToken cancellationToken)
    {
        var laserDevices = IsOpticStatusSelected(OpticStatusLaser) ? BuildOpticDeviceMap(EN_EQP_MODULE.TalonLaser) : new Dictionary<int, int>();
        var attenuatorDevices = IsOpticStatusSelected(OpticStatusAttenuator) ? BuildOpticDeviceMap(EN_EQP_MODULE.Attenuator) : new Dictionary<int, int>();
        var betDevices = IsOpticStatusSelected(OpticStatusBet) ? BuildOpticDeviceMap(EN_EQP_MODULE.Bet) : new Dictionary<int, int>();
        const int headCount = 8;
        var items = new List<ST_OPTIC_HEAD_PARAMETER>(headCount);
        for (var headNo = 1; headNo <= headCount; headNo++)
        {
            if (!IsHeadEnabled(previewParameters, headNo))
            {
                items.Add(CreateNotUseOpticHeadParameter(headNo));
                continue;
            }

            var laser = CreateEmptyLaserHeadParameter();
            var attenuator = CreateEmptyAxisHeadParameter(previewParameters, headNo);
            var bet = CreateEmptyBetHeadParameter(previewParameters, headNo);
            var state = "N/C";
            if (IsOpticStatusSelected(OpticStatusLaser))
            {
                laser = await BuildLaserHeadParameter(headNo, laserDevices, cancellationToken);
                state = FormatOpticGroupState([new ST_OPTIC_PARAMETER_ITEM("POWER", laser.Power, "", laser.State), new ST_OPTIC_PARAMETER_ITEM("GATE", laser.Gate, "", laser.Gate), new ST_OPTIC_PARAMETER_ITEM("SHUTTER", laser.Shutter, "", laser.Shutter)]);
            }
            else if (IsOpticStatusSelected(OpticStatusAttenuator))
            {
                attenuator = await BuildAttenuatorHeadParameter(headNo, attenuatorDevices, previewParameters, cancellationToken);
                state = attenuator.State;
            }
            else if (IsOpticStatusSelected(OpticStatusBet))
            {
                bet = await BuildBetHeadParameter(headNo, betDevices, previewParameters, cancellationToken);
                state = bet.State;
            }

            items.Add(new ST_OPTIC_HEAD_PARAMETER($"H{headNo:00}", state, laser.Power, laser.Gate, laser.Shutter, laser.State, attenuator.Current, attenuator.Target, attenuator.State, bet.MagnificationCurrentStep, bet.MagnificationTargetStep, bet.DivergenceCurrentStep, bet.DivergenceTargetStep, bet.State));
        }

        return items;
    }

    private static ST_OPTIC_HEAD_PARAMETER CreateNotUseOpticHeadParameter(int headNo)
    {
        return new ST_OPTIC_HEAD_PARAMETER($"H{headNo:00}", "NOT USE", "-", "-", "-", "NOT USE", "-", "-", "NOT USE", "-", "-", "-", "-", "NOT USE");
    }

    private static ST_OPTIC_LASER_HEAD_PARAMETER CreateEmptyLaserHeadParameter()
    {
        return new ST_OPTIC_LASER_HEAD_PARAMETER("-", "-", "-", "N/C");
    }

    private static ST_OPTIC_AXIS_HEAD_PARAMETER CreateEmptyAxisHeadParameter(IReadOnlyDictionary<string, string> previewParameters, int headNo)
    {
        var target = ReadDoubleAny(previewParameters, 23.50, $"H{headNo:00}_ATTENUATOR_POSITION");
        return new ST_OPTIC_AXIS_HEAD_PARAMETER("-", FormatOpticValue(target, "deg"), "N/C");
    }

    private static ST_OPTIC_BET_HEAD_PARAMETER CreateEmptyBetHeadParameter(IReadOnlyDictionary<string, string> previewParameters, int headNo)
    {
        var targetMag = ReadDoubleAny(previewParameters, 1.0, $"H{headNo:00}_BET_MAGNIFICATION", $"H{headNo:00}_BET_TARGET_MAGNIFICATION", "BET_MAGNIFICATION", "BET_TARGET_MAGNIFICATION", "BET_MAG_TARGET", "BET_MAG", "BEAM_EXPANDER_MAGNIFICATION");
        var targetDiv = ReadDoubleAny(previewParameters, 1.0, $"H{headNo:00}_BET_DIVERGENCE", $"H{headNo:00}_BET_TARGET_DIVERGENCE", "BET_DIVERGENCE", "BET_TARGET_DIVERGENCE", "BET_DIV_TARGET", "BET_DIV", "BEAM_EXPANDER_DIVERGENCE");
        return new ST_OPTIC_BET_HEAD_PARAMETER("-", FormatBetStep(targetMag), "-", FormatBetStep(targetDiv), "N/C");
    }

    private IReadOnlyDictionary<int, int> BuildOpticDeviceMap(EN_EQP_MODULE module)
    {
        int SelectValue(global::Drilling.Common.Interface.ST_INTERFACE_DATA device)
        {
            return Math.Clamp(device.Number + 1, 1, 8);
        }

        int SelectKey(global::System.Linq.IGrouping<int, global::Drilling.Common.Interface.ST_INTERFACE_DATA> group)
        {
            return group.Key;
        }

        int SelectNumber(global::Drilling.Common.Interface.ST_INTERFACE_DATA device)
        {
            return device.Number;
        }

        string SelectNickName(global::Drilling.Common.Interface.ST_INTERFACE_DATA device)
        {
            return device.NickName;
        }

        int SelectInt(global::System.Linq.IGrouping<int, global::Drilling.Common.Interface.ST_INTERFACE_DATA> group)
        {
            return group.OrderBy(SelectNumber).ThenBy(SelectNickName, StringComparer.OrdinalIgnoreCase).First().Number;
        }

        return interfaceManager.GetInterfaceList(module).GroupBy(SelectValue).ToDictionary(SelectKey, SelectInt);
    }

    private Task<ST_OPTIC_LASER_HEAD_PARAMETER> BuildLaserHeadParameter(int headNo, IReadOnlyDictionary<int, int> devices, CancellationToken cancellationToken)
    {
        if (!devices.TryGetValue(headNo, out var deviceNo))
        {
            return Task.FromResult(new ST_OPTIC_LASER_HEAD_PARAMETER("-", "-", "-", "N/C"));
        }

        try
        {
            var snapshot = interfaceManager.OpticSnapshots.GetLaser(deviceNo);
            var status = snapshot.Value ?? throw new InvalidOperationException(snapshot.Detail);
            var power = status.PowerOn ? "ON" : "OFF";
            return Task.FromResult(new ST_OPTIC_LASER_HEAD_PARAMETER(power, status.GateOn ? "OPEN" : "CLOSE", status.ShutterOpen ? "OPEN" : "CLOSE", "OK"));
        }
        catch (Exception exception)when (exception is not OperationCanceledException)
        {
            return Task.FromResult(new ST_OPTIC_LASER_HEAD_PARAMETER("-", "-", "-", "ERROR"));
        }
    }

    private Task<ST_OPTIC_AXIS_HEAD_PARAMETER> BuildAttenuatorHeadParameter(int headNo, IReadOnlyDictionary<int, int> devices, IReadOnlyDictionary<string, string> previewParameters, CancellationToken cancellationToken)
    {
        var target = ReadDoubleAny(previewParameters, 23.50, $"H{headNo:00}_ATTENUATOR_POSITION");
        if (!devices.TryGetValue(headNo, out var deviceNo))
        {
            return Task.FromResult(new ST_OPTIC_AXIS_HEAD_PARAMETER("-", FormatOpticValue(target, "deg"), "N/C"));
        }

        try
        {
            var status = interfaceManager.GetAttenuatorStatus(deviceNo, cancellationToken);
            var state = FormatOpticValueState(FormatAttenuatorState(status), status.CurrentPosition, target);
            return Task.FromResult(new ST_OPTIC_AXIS_HEAD_PARAMETER(FormatOpticValue(status.CurrentPosition, "deg"), FormatOpticValue(target, "deg"), state));
        }
        catch (Exception exception)when (exception is not OperationCanceledException)
        {
            return Task.FromResult(new ST_OPTIC_AXIS_HEAD_PARAMETER("-", FormatOpticValue(target, "deg"), "ERROR"));
        }
    }

    private Task<ST_OPTIC_BET_HEAD_PARAMETER> BuildBetHeadParameter(int headNo, IReadOnlyDictionary<int, int> devices, IReadOnlyDictionary<string, string> previewParameters, CancellationToken cancellationToken)
    {
        var targetMag = ReadDoubleAny(previewParameters, 1.0, $"H{headNo:00}_BET_MAGNIFICATION", $"H{headNo:00}_BET_TARGET_MAGNIFICATION", "BET_MAGNIFICATION", "BET_TARGET_MAGNIFICATION", "BET_MAG_TARGET", "BET_MAG", "BEAM_EXPANDER_MAGNIFICATION");
        var targetDiv = ReadDoubleAny(previewParameters, 1.0, $"H{headNo:00}_BET_DIVERGENCE", $"H{headNo:00}_BET_TARGET_DIVERGENCE", "BET_DIVERGENCE", "BET_TARGET_DIVERGENCE", "BET_DIV_TARGET", "BET_DIV", "BEAM_EXPANDER_DIVERGENCE");
        if (!devices.TryGetValue(headNo, out var deviceNo))
        {
            return Task.FromResult(new ST_OPTIC_BET_HEAD_PARAMETER("-", FormatBetStep(targetMag), "-", FormatBetStep(targetDiv), "N/C"));
        }

        try
        {
            var snapshot = interfaceManager.OpticSnapshots.GetBet(deviceNo);
            var status = snapshot.Value ?? throw new InvalidOperationException(snapshot.Detail);
            targetMag = ReadDoubleAny(previewParameters, status.TargetMagnification, $"H{headNo:00}_BET_MAGNIFICATION", $"H{headNo:00}_BET_TARGET_MAGNIFICATION", "BET_MAGNIFICATION", "BET_TARGET_MAGNIFICATION", "BET_MAG_TARGET", "BET_MAG", "BEAM_EXPANDER_MAGNIFICATION");
            targetDiv = ReadDoubleAny(previewParameters, status.TargetDivergence, $"H{headNo:00}_BET_DIVERGENCE", $"H{headNo:00}_BET_TARGET_DIVERGENCE", "BET_DIVERGENCE", "BET_TARGET_DIVERGENCE", "BET_DIV_TARGET", "BET_DIV", "BEAM_EXPANDER_DIVERGENCE");
            var state = FormatOpticGroupState([new ST_OPTIC_PARAMETER_ITEM("MAG", "", "", FormatBetState(status, status.CurrentMagnification, targetMag)), new ST_OPTIC_PARAMETER_ITEM("DIV", "", "", FormatBetState(status, status.CurrentDivergence, targetDiv))]);
            return Task.FromResult(new ST_OPTIC_BET_HEAD_PARAMETER(FormatBetStep(status.MagnificationAxisPosition), FormatBetStep(targetMag), FormatBetStep(status.DivergenceAxisPosition), FormatBetStep(targetDiv), state));
        }
        catch (Exception exception)when (exception is not OperationCanceledException)
        {
            return Task.FromResult(new ST_OPTIC_BET_HEAD_PARAMETER("-", FormatBetStep(targetMag), "-", FormatBetStep(targetDiv), "ERROR"));
        }
    }

    private static ST_OPTIC_PARAMETER_GROUP BuildOpticGroup(string device, IReadOnlyList<ST_OPTIC_PARAMETER_ITEM> items)
    {
        return new ST_OPTIC_PARAMETER_GROUP(device, FormatOpticGroupState(items), items);
    }

    private static IReadOnlyList<int> CreateOpticHeadOrder()
    {
        return[1, 3, 5, 7, 2, 4, 6, 8];
    }

    private static IReadOnlyList<ST_OPTIC_HEAD_PARAMETER> OrderOpticHeadParameters(IReadOnlyList<ST_OPTIC_HEAD_PARAMETER> headParameters)
    {
        if (headParameters.Count == 0)
        {
            return[];
        }

        string SelectHead(global::Drilling.UI.Menu.Menus.ST_OPTIC_HEAD_PARAMETER head)
        {
            return head.Head;
        }

        global::Drilling.UI.Menu.Menus.ST_OPTIC_HEAD_PARAMETER SelectHead2(global::Drilling.UI.Menu.Menus.ST_OPTIC_HEAD_PARAMETER head)
        {
            return head;
        }

        var headMap = headParameters.ToDictionary(SelectHead, SelectHead2, StringComparer.OrdinalIgnoreCase);
        string SelectItem(int headNo)
        {
            return $"H{headNo:00}";
        }

        global::Drilling.UI.Menu.Menus.ST_OPTIC_HEAD_PARAMETER SelectOPTIC_HEAD_PARAMETER(string head)
        {
            return headMap[head];
        }

        var heads = CreateOpticHeadOrder().Select(SelectItem).Where(headMap.ContainsKey).Select(SelectOPTIC_HEAD_PARAMETER).ToArray();
        return heads;
    }

    private static string FormatOpticValueState(string deviceState, double current, double target, double tolerance = 0.001)
    {
        if (IsOpticState(deviceState, "ERROR", "ALARM", "NG", "OFFLINE", "N/C"))
        {
            return deviceState;
        }

        return IsNear(current, target, tolerance) ? "OK" : "WARN";
    }

    private static string FormatBetStep(double value)
    {
        var step = Math.Clamp((int)Math.Round(value), 0, 4500);
        return step.ToString(CultureInfo.InvariantCulture);
    }

    private static string FormatOpticGroupState(IReadOnlyList<ST_OPTIC_PARAMETER_ITEM> items)
    {
        bool MatchesItem(global::Drilling.UI.Menu.Menus.ST_OPTIC_PARAMETER_ITEM item)
        {
            return IsOpticState(item.State, "N/C");
        }

        if (items.Count > 0 && items.All(MatchesItem))
        {
            return "N/C";
        }

        bool MatchesItem2(global::Drilling.UI.Menu.Menus.ST_OPTIC_PARAMETER_ITEM item)
        {
            return IsOpticState(item.State, "ERROR", "ALARM", "NG", "OFFLINE");
        }

        if (items.Any(MatchesItem2))
        {
            return "ALARM";
        }

        bool MatchesItem3(global::Drilling.UI.Menu.Menus.ST_OPTIC_PARAMETER_ITEM item)
        {
            return IsOpticState(item.State, "N/C");
        }

        if (items.Any(MatchesItem3))
        {
            return "N/C";
        }

        bool MatchesItem4(global::Drilling.UI.Menu.Menus.ST_OPTIC_PARAMETER_ITEM item)
        {
            return IsOpticState(item.State, "MOVING", "RUNNING");
        }

        if (items.Any(MatchesItem4))
        {
            return "MOVING";
        }

        bool MatchesItem5(global::Drilling.UI.Menu.Menus.ST_OPTIC_PARAMETER_ITEM item)
        {
            return IsOpticState(item.State, "WARN", "WAIT", "STOP");
        }

        if (items.Any(MatchesItem5))
        {
            return "WARN";
        }

        bool MatchesItem6(global::Drilling.UI.Menu.Menus.ST_OPTIC_PARAMETER_ITEM item)
        {
            return IsOpticState(item.State, "SAFE");
        }

        if (items.Any(MatchesItem6))
        {
            return "SAFE";
        }

        return "OK";
    }

    private static bool IsOpticState(string state, params string[] expectedStates)
    {
        var normalized = state.Trim().ToUpperInvariant();
        bool MatchesItem(string expected)
        {
            return normalized.Equals(expected, StringComparison.OrdinalIgnoreCase);
        }

        return expectedStates.Any(MatchesItem);
    }

    private static string FormatBetState(ST_BET_STATUS status, double current, double target)
    {
        if (status.AlarmOn || !status.CommOk)
        {
            return "ALARM";
        }

        if (status.IsMoving)
        {
            return "MOVING";
        }

        return IsNear(current, target) ? "OK" : "WARN";
    }

    private static string FormatAttenuatorState(ST_ATTENUATOR_STATUS status)
    {
        if (!status.CommOk || status.LastError != EN_CONEX_AGP_ERROR.Ok)
        {
            return "ALARM";
        }

        return string.IsNullOrWhiteSpace(status.CommandState) ? "OK" : status.CommandState.Trim().ToUpperInvariant();
    }

    private static bool IsNear(double current, double target, double tolerance = 0.001)
    {
        return Math.Abs(current - target) <= tolerance;
    }

    private static string FormatOpticValue(double value, string unit)
    {
        return $"{value.ToString("F3", CultureInfo.InvariantCulture)} {unit}";
    }

    private static IReadOnlyList<int> BuildEnabledHeadNumbers(IReadOnlyDictionary<string, string> parameters, int headCount = 8)
    {
        var normalizedHeadCount = Math.Clamp(headCount, 1, 8);
        var heads = new List<int>(normalizedHeadCount);
        for (var headNo = 1; headNo <= normalizedHeadCount; headNo++)
        {
            if (IsHeadEnabled(parameters, headNo))
            {
                heads.Add(headNo);
            }
        }

        return heads;
    }

    private static bool IsHeadEnabled(IReadOnlyDictionary<string, string> parameters, int headNo)
    {
        return parameters.TryGetValue($"H{headNo:00}_USE", out var value) ? ReadBoolOption(value, true) : true;
    }

    private static bool ReadBoolOption(string value, bool defaultValue)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return defaultValue;
        }

        return value.Trim().ToUpperInvariant() switch
        {
            "1" or "Y" or "YES" or "TRUE" or "ON" or "USE" => true,
            "0" or "N" or "NO" or "FALSE" or "OFF" or "SKIP" or "UNUSE" => false,
            _ => defaultValue
        };
    }

    private (IReadOnlyList<ST_INSPECTION_STATUS_ITEM> Items, string Summary, string ModeText, string RuleText, Visibility RuleVisibility) BuildInspectionStatus(ST_STATION_PROCESS_STATUS snapshot)
    {
        var sequenceState = FormatReviewSequenceState(reviewManager.SequenceState);
        var plan = reviewManager.CurrentPlan;
        if (plan is null)
        {
            return ([], "No live inspection data", $"STATE : {sequenceState}", "PLAN : -", Visibility.Visible);
        }

        var items = BuildInspectionStatusItems(plan);
        bool MatchesINSPECTION_STATUS_ITEM(global::Drilling.UI.Menu.Menus.ST_INSPECTION_STATUS_ITEM item)
        {
            return item.State is "OK" or "NG";
        }

        var completedCount = items.Count(MatchesINSPECTION_STATUS_ITEM);
        bool MatchesState(global::Drilling.UI.Menu.Menus.ST_INSPECTION_STATUS_ITEM item)
        {
            return item.State == "NG";
        }

        var ngCount = items.Count(MatchesState);
        bool MatchesItem(global::Drilling.UI.Menu.Menus.ST_INSPECTION_STATUS_ITEM item)
        {
            return item.State == "Current";
        }

        var currentShot = items.FirstOrDefault(MatchesItem)?.Shot ?? "-";
        var summary = $"State {sequenceState} / Total {items.Count:N0} / Done {completedCount:N0} / NG {ngCount:N0} / Current {currentShot}";
        return (items, summary, $"STATE : {sequenceState}", $"RECIPE : {plan.RecipeId}", Visibility.Visible);
    }

    private static string FormatReviewSequenceState(EN_REVIEW_SEQUENCE_STATE state)
    {
        return state.ToString().ToUpperInvariant();
    }

    private static IReadOnlyList<ST_INSPECTION_STATUS_ITEM> BuildInspectionStatusItems(ST_REVIEW_PLAN plan)
    {
        var points = OrderByInspectionSequence(plan.ReviewPoints);
        if (points.Count == 0)
        {
            return[];
        }

        global::Drilling.UI.Menu.Menus.ST_INSPECTION_STATUS_ITEM BuildINSPECTION_STATUS_ITEM(global::Drilling.Common.Review.ST_REVIEW_PLAN_POINT point, int index)
        {
            var state = ToInspectionStateText(point.State);
            var judge = state switch
            {
                "OK" => "OK",
                "NG" => "NG",
                "Current" => "RUN",
                _ => point.Judge is "OK" or "NG" ? point.Judge : "WAIT"
            };
            return new ST_INSPECTION_STATUS_ITEM((index + 1).ToString("00", CultureInfo.InvariantCulture), $"H{point.HeadNo:00}", $"CELL{point.CellNo:00}", CReviewShotNameFormatter.ToMatrixName(point.ShotNo, point.PixelCountX), FormatInspectionErrorValue(point.ErrorX, state), FormatInspectionErrorValue(point.ErrorY, state), state, judge);
        }

        return points.Select(BuildINSPECTION_STATUS_ITEM).ToArray();
    }

    private static string FormatInspectionErrorValue(double value, string state)
    {
        return state is "OK" or "NG" ? FormatSigned(value) : "-";
    }

    private static string FormatSigned(double value)
    {
        return value.ToString("+0.000;-0.000;0.000", CultureInfo.InvariantCulture);
    }

    private static IReadOnlyList<ST_REVIEW_PLAN_POINT> OrderByInspectionSequence(IEnumerable<ST_REVIEW_PLAN_POINT> points)
    {
        double SelectDesignY(global::Drilling.Common.Review.ST_REVIEW_PLAN_POINT point)
        {
            return point.DesignY;
        }

        double SelectDesignX(global::Drilling.Common.Review.ST_REVIEW_PLAN_POINT point)
        {
            return point.DesignX;
        }

        int SelectCellNo(global::Drilling.Common.Review.ST_REVIEW_PLAN_POINT point)
        {
            return point.CellNo;
        }

        int SelectShotNo(global::Drilling.Common.Review.ST_REVIEW_PLAN_POINT point)
        {
            return point.ShotNo;
        }

        var source = points.OrderBy(SelectDesignY).ThenBy(SelectDesignX).ThenBy(SelectCellNo).ThenBy(SelectShotNo).ToArray();
        var rows = new List<List<ST_REVIEW_PLAN_POINT>>();
        foreach (var point in source)
        {
            if (rows.Count == 0 || Math.Abs(point.DesignY - rows[^1][0].DesignY) > ReviewSequenceRowTolerance)
            {
                rows.Add([]);
            }

            rows[^1].Add(point);
        }

        var orderedPoints = new List<ST_REVIEW_PLAN_POINT>(source.Length);
        double SelectDesignX2(global::Drilling.Common.Review.ST_REVIEW_PLAN_POINT point)
        {
            return point.DesignX;
        }

        int SelectCellNo2(global::Drilling.Common.Review.ST_REVIEW_PLAN_POINT point)
        {
            return point.CellNo;
        }

        int SelectShotNo2(global::Drilling.Common.Review.ST_REVIEW_PLAN_POINT point)
        {
            return point.ShotNo;
        }

        double SelectDesignX3(global::Drilling.Common.Review.ST_REVIEW_PLAN_POINT point)
        {
            return point.DesignX;
        }

        int SelectCellNo3(global::Drilling.Common.Review.ST_REVIEW_PLAN_POINT point)
        {
            return point.CellNo;
        }

        int SelectShotNo3(global::Drilling.Common.Review.ST_REVIEW_PLAN_POINT point)
        {
            return point.ShotNo;
        }

        for (var rowIndex = 0; rowIndex < rows.Count; rowIndex++)
        {
            var row = rows[rowIndex];
            var orderedRow = rowIndex % 2 == 0 ? row.OrderBy(SelectDesignX2).ThenBy(SelectCellNo2).ThenBy(SelectShotNo2) : row.OrderByDescending(SelectDesignX3).ThenBy(SelectCellNo3).ThenBy(SelectShotNo3);
            orderedPoints.AddRange(orderedRow);
        }

        return orderedPoints;
    }

    private static string ToInspectionStateText(EN_REVIEW_POINT_STATE state)
    {
        return state switch
        {
            EN_REVIEW_POINT_STATE.Current => "Current",
            EN_REVIEW_POINT_STATE.Ok => "OK",
            EN_REVIEW_POINT_STATE.Ng => "NG",
            EN_REVIEW_POINT_STATE.Skip => "Skip",
            _ => "Ready"
        };
    }

    private IReadOnlyList<Drilling.Common.InterLock.ST_INTERLOCK_ITEM> LoadLiveInterlockItems(ST_STATION_PROCESS_STATUS snapshot, IReadOnlyDictionary<string, string> previewParameters, CancellationToken cancellationToken)
    {
        return _interlockSnapshot.Read(
            () => stationManager.GetLiveInterlockItems(previewParameters, cancellationToken), snapshot.InterlockItems);
    }

    private static string FormatProcessResult(ST_STATION_PROCESS_STATUS snapshot)
    {
        if (snapshot.Result is null)
        {
            return "PENDING";
        }

        return string.IsNullOrWhiteSpace(snapshot.Result.ResultCode) ? snapshot.Result.IsSuccess ? "OK" : "NG" : snapshot.Result.ResultCode.Trim().ToUpperInvariant();
    }

    private static string FormatDuration(TimeSpan value)
    {
        return value == TimeSpan.Zero ? "00:00:00" : value.ToString(@"hh\:mm\:ss");
    }

    private static ST_HEAD_PREVIEW BuildHeadPreviewItem(int headNo, long assignedShotCount, ST_STATION_PROCESS_STATUS snapshot,
        IReadOnlySet<int> selectedHeadNos, IReadOnlyList<Drilling.Common.InterLock.ST_INTERLOCK_ITEM> interlockItems,
        IReadOnlyList<ST_SCRIPT_TASK_STATUS_ITEM> taskStatusItems, bool isEnabled = true)
    {
        var headPlan = snapshot.ProcessModel?.HeadPlans.FirstOrDefault(head => head.HeadNo == headNo);
        var isCycleActive = snapshot.ProcessStep is EN_PROCESS_STEP.PowerCheck or EN_PROCESS_STEP.Align or EN_PROCESS_STEP.Process or EN_PROCESS_STEP.Inspection;
        // Count allocated drilling coordinates, not the pulse count configured for each coordinate.
        var shotCount = !isEnabled ? 0 : isCycleActive ? headPlan?.Shots.Count ?? 0 : Math.Max(0, assignedShotCount);
        // Equipment-wide interlocks remain in INTERLOCK / SAFETY; only this head's conditions color its card.
        var blockers = interlockItems.Where(item => item.BlocksAutoRun && item.HeadNo == headNo).ToArray();
        var state = "IDLE";
        var detail = "Ready";
        if (!isEnabled)
        {
            state = "NOT USE";
            detail = "Head is disabled in settings.";
        }
        else if (blockers.Length > 0)
        {
            state = "INTERLOCK";
            detail = string.Join(Environment.NewLine, blockers.Select(item => $"{item.Signal}: {item.State} — {item.Detail}"));
        }
        else if (headPlan?.Shots.Count > 0 && snapshot.ProcessStep == EN_PROCESS_STEP.PowerCheck)
        {
            state = "POWER MEASURE";
            detail = "POWER CHECK sequence is active.";
        }
        else if (headPlan?.Shots.Count > 0 && snapshot.ProcessStep == EN_PROCESS_STEP.Process && snapshot.ScriptStatus == EN_SCRIPT_STATUS.Running)
        {
            var task = taskStatusItems.FirstOrDefault(item => item.HeadNoValue == headNo);
            if (task?.State is "RUNNING" or "SIM")
            {
                state = "RUNNING";
                detail = task.State == "SIM" ? "Process is running in simulation." : $"{task.ControllerTaskText}: {task.FileText}";
            }
        }

        return new ST_HEAD_PREVIEW(headNo, $"HEAD {headNo:00}", state, isEnabled && selectedHeadNos.Contains(headNo), isEnabled)
        {
            AssignedShotCount = shotCount,
            StatusDetail = detail
        };
    }

    private async Task<IReadOnlyDictionary<string, string>> LoadPreviewParameters(ST_STATION_PROCESS_STATUS snapshot, CancellationToken cancellationToken)
    {
        var parameters = new Dictionary<string, string>(snapshot.ProcessModel?.Parameters ?? new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase), StringComparer.OrdinalIgnoreCase);
        var recipes = await recipeManager.LoadRecipes(cancellationToken);
        if (recipes.Count > 0)
        {
            var recipeId = selectedRecipeIdProvider();
            if (string.IsNullOrWhiteSpace(recipeId))
            {
                recipeId = snapshot.ProcessModel?.RecipeId ?? "DRILL_A01";
            }

            bool MatchesItem(global::Drilling.Common.Managers.ST_RECIPE_DEFINITION item)
            {
                return item.Id.Equals(recipeId, StringComparison.OrdinalIgnoreCase);
            }

            bool MatchesItem2(global::Drilling.Common.Managers.ST_RECIPE_DEFINITION item)
            {
                return item.Id.Equals("DRILL_A01", StringComparison.OrdinalIgnoreCase);
            }

            var recipe = recipes.FirstOrDefault(MatchesItem) ?? recipes.FirstOrDefault(MatchesItem2) ?? recipes[0];
            bool ShouldIncludeItem(global::Drilling.Common.Managers.ST_RECIPE_PARAMETER parameter)
            {
                return !string.IsNullOrWhiteSpace(parameter.Key);
            }

            foreach (var parameter in recipe.Parameters.Where(ShouldIncludeItem))
            {
                parameters[parameter.Key] = parameter.Value;
            }
        }

        foreach (var setting in settingManager.LoadSection(EN_SETTING_TAB.Option, cancellationToken))
        {
            if (!string.IsNullOrWhiteSpace(setting.Key))
            {
                parameters[setting.Key] = setting.Value;
            }
        }

        return parameters;
    }

    private Task<ST_PREVIEW_HEAD_LAYOUT> LoadPreviewHeadLayout(CancellationToken cancellationToken)
    {
        return Task.FromResult(CHeadAssignmentPreviewBuilder.BuildHeadLayout(settingManager.LoadSection(EN_SETTING_TAB.Option, cancellationToken)));
    }

    private static int ReadIntAny(IReadOnlyDictionary<string, string> parameters, int defaultValue, params string[] keys)
    {
        foreach (var key in keys)
        {
            if (parameters.TryGetValue(key, out var value) && int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var parsed))
            {
                return parsed;
            }
        }

        return defaultValue;
    }

    private static double ReadDoubleAny(IReadOnlyDictionary<string, string> parameters, double defaultValue, params string[] keys)
    {
        foreach (var key in keys)
        {
            if (parameters.TryGetValue(key, out var value) && double.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out var parsed))
            {
                return parsed;
            }
        }

        return defaultValue;
    }

    private static double ReadFiniteDoubleAny(IReadOnlyDictionary<string, string> parameters, double defaultValue, params string[] keys)
    {
        var value = ReadDoubleAny(parameters, defaultValue, keys);
        return double.IsFinite(value) ? value : defaultValue;
    }

    public static Brush CreateHeadBrush(int headNo, byte alpha = 255) => CHeadAssignmentPreviewBuilder.CreateHeadBrush(headNo, alpha);

    private static IReadOnlyList<ST_HEAD_PARAMETER> BuildHeadParameters(IReadOnlyDictionary<string, string> parameters, IReadOnlyList<int> enabledHeadNos)
    {
        global::Drilling.UI.Menu.Menus.ST_HEAD_PARAMETER BuildHead(int headNo)
        {
            var prefix = $"H{headNo:00}";
            return new ST_HEAD_PARAMETER(prefix, ReadDoubleAny(parameters, 1.2, $"{prefix}_LASER_POWER"), ReadDoubleAny(parameters, 20.0, $"{prefix}_LASER_FREQUENCY"), ReadIntAny(parameters, 10, $"{prefix}_SHOT_COUNT"), ReadDoubleAny(parameters, 0.0, $"{prefix}_SCANNER_JUMP_SPEED"), ReadDoubleAny(parameters, 0.0, $"{prefix}_DOE_Z_POSITION"));
        }

        return enabledHeadNos.Select(BuildHead).ToArray();
    }
}

internal sealed record ST_HEAD_ASSIGNMENT_MAP(IReadOnlyList<ST_HEAD_ASSIGNMENT_AREA> Areas);
internal sealed record ST_MAIN_RECIPE_PREVIEW(ImageSource? Image, ST_GLASS_PREVIEW_FRAME Frame, IReadOnlyDictionary<int, long> HeadPointCounts, long TotalPointCount, long UnassignedPointCount, IReadOnlyList<ST_CELL_PREVIEW_LABEL> CellLabels, string ValidationMessage = "", int MaskingAreaCount = 0);
internal sealed record ST_PREVIEW_HEAD_LAYOUT(IReadOnlyList<ST_PREVIEW_HEAD_FIELD> Fields)
{
    public ST_PREVIEW_HEAD_FIELD GetField(int headNo)
    {
        var normalizedHeadNo = Math.Clamp(headNo, 1, 8);
        bool MatchesItem(global::Drilling.UI.Menu.Menus.ST_PREVIEW_HEAD_FIELD field)
        {
            return field.HeadNo == normalizedHeadNo;
        }

        return Fields.First(MatchesItem);
    }
}

internal sealed record ST_PREVIEW_HEAD_FIELD(int HeadNo, double PositionX, double ScanFieldWidthX);
public sealed record ST_GLASS_PREVIEW_FRAME(double CanvasLeft, double CanvasTop, double Width, double Height);
public sealed record ST_HEAD_PREVIEW(int HeadNo, string HeadName, string Status, bool IsSelected, bool IsEnabled = true)
{
    public long AssignedShotCount { get; init; }
    public string ShotCountText => $"{AssignedShotCount:N0} Shots";
    public string StatusDetail { get; init; } = "";
    public Brush StatusBrush => Status switch
    {
        "RUNNING" => CStatusBrush.CommandGreen,
        "POWER MEASURE" => Brushes.Gold,
        "INTERLOCK" => CStatusBrush.CommandRed,
        _ => Brushes.DimGray
    };
    public Brush StatusTextBrush => Status == "POWER MEASURE" ? Brushes.Black : Brushes.White;

    public Brush TextBrush
    {
        get
        {
            return IsSelected ? Brushes.White : CStatusBrush.PrimaryText;
        }
    }
}

public sealed record ST_MAIN_PROCESS_SEQUENCE_ITEM(string Order, string StepName, string State)
{
    public Brush StateBrush => CStatusBrush.ForDisplayState(State);
}

public sealed record ST_HEAD_ASSIGNMENT_AREA(int HeadNo, string HeadName, double CanvasLeft, double CanvasTop, double Width, double Height, double LabelCanvasLeft, double LabelWidth, bool IsSelected, int PointCount, Brush FillBrush, Brush StrokeBrush, Thickness BorderThicknessValue, double Opacity)
{
    public double LabelCanvasTop
    {
        get
        {
            return CanvasTop - 24.0;
        }
    }

    public Visibility RangeVisibility
    {
        get
        {
            return IsSelected ? Visibility.Visible : Visibility.Collapsed;
        }
    }

    public string DisplayLabel
    {
        get
        {
            return $"H{HeadNo:00}";
        }
    }
}

internal readonly record struct ST_PREVIEW_HEAD_ASSIGNMENT_CANDIDATE(int HeadNo, double Distance);
internal readonly record struct ST_SCRIPT_TASK_DEFINITION(int HeadNo, int AutomationNo, int TaskNo, string ScriptFileName, int TotalShots);
internal readonly record struct ST_SCRIPT_TASK_STATUS_VALUE(string State, string FileName, string Detail);
internal readonly record struct ST_AUTOMATION_CONTROLLER_USAGE_VALUE(string State, double Percent, string Detail);
public sealed record ST_AUTOMATION_CONTROLLER_STATUS_ITEM(int AutomationNo, string State, double CpuUsagePercent, string Detail, IReadOnlyList<ST_SCRIPT_TASK_STATUS_ITEM> Tasks)
{
    public string ControllerName
    {
        get
        {
            return $"A1 #{AutomationNo}";
        }
    }

    public string CpuUsageText
    {
        get
        {
            var normalizedState = State.Trim().ToUpperInvariant();
            return normalizedState is "OK" or "WARN" ? $"{CpuUsagePercent.ToString("F1", CultureInfo.InvariantCulture)}%" : normalizedState;
        }
    }

    public string TaskSummary
    {
        get
        {
            return $"{Tasks.Count.ToString("N0", CultureInfo.InvariantCulture)} TASKS";
        }
    }

    public string DetailText
    {
        get
        {
            return string.IsNullOrWhiteSpace(Detail) ? "-" : Detail;
        }
    }

    public Brush StateBrush
    {
        get
        {
            return ControllerStateBrush(State);
        }
    }

    public Brush CpuUsageBrush
    {
        get
        {
            return ControllerStateBrush(State);
        }
    }

    private static Brush ControllerStateBrush(string state)
    {
        return state.Trim().ToUpperInvariant() switch
        {
            "OK" => CStatusBrush.Online,
            "SIM" or "WAIT" or "WARN" => CStatusBrush.Wait,
            "OFFLINE" or "ERROR" or "FAULT" => CStatusBrush.Offline,
            _ => CStatusBrush.Muted
        };
    }
}

public sealed record ST_SCRIPT_TASK_STATUS_ITEM(string Task, string Head, string Automation, string TaskNo, string State, string File, string Detail, int Shots)
{
    public bool IsSimulation { get; init; }
    public string StateText => IsSimulation ? $"{State}(SIMUL)" : State;
    public int AutomationNoValue
    {
        get
        {
            return ReadPrefixedNumber(Automation, 'A', 0);
        }
    }

    public int TaskNoValue
    {
        get
        {
            return ReadPrefixedNumber(TaskNo, 'T', 1);
        }
    }

    public int HeadNoValue
    {
        get
        {
            return ReadPrefixedNumber(Head, 'H', 0);
        }
    }

    public string AutomationText
    {
        get
        {
            return $"A1 #{AutomationNoValue}";
        }
    }

    public string ControllerTaskText
    {
        get
        {
            return $"{AutomationText} / {TaskNo}";
        }
    }

    public string FileText
    {
        get
        {
            return string.IsNullOrWhiteSpace(File) ? "-" : File;
        }
    }

    public string DetailText
    {
        get
        {
            return string.IsNullOrWhiteSpace(Detail) ? "-" : Detail;
        }
    }

    public string ShotText
    {
        get
        {
            return $"{Shots.ToString("N0", CultureInfo.InvariantCulture)} SHOTS";
        }
    }

    public Brush StateBrush
    {
        get
        {
            return TaskStateBrush(State);
        }
    }

    public bool IsStateHighlighted => State.Trim().ToUpperInvariant() is
        "RUNNING" or "QUEUESTARTING" or "OK" or "DONE" or "READY" or
        "STOP" or "STOPPED" or "ERROR" or "FAULT" or "OFFLINE";

    public Brush CardTextBrush => Brushes.White;

    private static Brush TaskStateBrush(string state)
    {
        return state.Trim().ToUpperInvariant() switch
        {
            "RUNNING" or "QUEUESTARTING" => CStatusBrush.Wait,
            "OK" or "DONE" or "READY" => CStatusBrush.Online,
            "IDLE" or "SIM" or "UNKNOWN" => CStatusBrush.Muted,
            "STOP" or "STOPPED" or "ERROR" or "FAULT" or "OFFLINE" => CStatusBrush.Offline,
            _ => CStatusBrush.Muted
        };
    }

    private static int ReadPrefixedNumber(string value, char prefix, int defaultValue)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return defaultValue;
        }

        var text = value.Trim();
        if (text.Length > 0 && char.ToUpperInvariant(text[0]) == char.ToUpperInvariant(prefix))
        {
            text = text[1..];
        }

        return int.TryParse(text, NumberStyles.Integer, CultureInfo.InvariantCulture, out var parsed) ? parsed : defaultValue;
    }
}

public sealed record ST_INSPECTION_STATUS_ITEM(string No, string Head, string Cell, string Shot, string ErrorX, string ErrorY, string State, string Judge)
{
    public Brush StateBrush
    {
        get
        {
            return CStatusBrush.ForDisplayState(State);
        }
    }

    public Brush JudgeBrush
    {
        get
        {
            return CStatusBrush.ForDisplayState(Judge);
        }
    }
}

public sealed record ST_MAIN_PARAMETER_TAB_ITEM(string Key, string Name, bool IsSelected, bool IsEnabled = true)
{
    public Brush BackgroundBrush
    {
        get
        {
            return IsEnabled && IsSelected ? CStatusBrush.CommandBlue : CStatusBrush.CommandDark;
        }
    }

    public Brush BorderBrush
    {
        get
        {
            return IsEnabled && IsSelected ? CStatusBrush.CommandBlueBorder : CStatusBrush.CommandDarkBorder;
        }
    }

    public Brush TextBrush
    {
        get
        {
            return IsEnabled ? Brushes.White : CStatusBrush.Muted;
        }
    }
}

public sealed record ST_HEAD_PARAMETER(string Head, double Power, double Frequency, int Shot, double JumpSpeed, double DoeZPosition);
public sealed record ST_OPTIC_HEAD_PARAMETER(string Head, string State, string LaserPower, string LaserGate, string LaserShutter, string LaserState, string AttenuatorCurrent, string AttenuatorTarget, string AttenuatorState, string BetMagnificationCurrentStep, string BetMagnificationTargetStep, string BetDivergenceCurrentStep, string BetDivergenceTargetStep, string BetState)
{
    public string LaserPowerText
    {
        get
        {
            return $"P {LaserPower}";
        }
    }

    public string LaserGateText
    {
        get
        {
            return $"G {LaserGate}";
        }
    }

    public string LaserShutterText
    {
        get
        {
            return $"S {LaserShutter}";
        }
    }

    public string AttenuatorText
    {
        get
        {
            return $"{AttenuatorCurrent} / {AttenuatorTarget}";
        }
    }

    public string BetMagnificationText
    {
        get
        {
            return $"MAG {BetMagnificationCurrentStep} / {BetMagnificationTargetStep}";
        }
    }

    public string BetDivergenceText
    {
        get
        {
            return $"DIV {BetDivergenceCurrentStep} / {BetDivergenceTargetStep}";
        }
    }

    public Brush StateBrush
    {
        get
        {
            return ST_OPTIC_PARAMETER_ITEM.OpticStateBrush(State);
        }
    }

    public Brush LaserStateBrush
    {
        get
        {
            return ST_OPTIC_PARAMETER_ITEM.OpticStateBrush(LaserState);
        }
    }

    public Brush LaserPowerBrush
    {
        get
        {
            return ST_OPTIC_PARAMETER_ITEM.OpticStateBrush(LaserPower);
        }
    }

    public Brush LaserGateBrush
    {
        get
        {
            return ST_OPTIC_PARAMETER_ITEM.OpticStateBrush(LaserGate);
        }
    }

    public Brush LaserShutterBrush
    {
        get
        {
            return ST_OPTIC_PARAMETER_ITEM.OpticStateBrush(LaserShutter);
        }
    }

    public Brush AttenuatorStateBrush
    {
        get
        {
            return ST_OPTIC_PARAMETER_ITEM.OpticStateBrush(AttenuatorState);
        }
    }

    public Brush BetStateBrush
    {
        get
        {
            return ST_OPTIC_PARAMETER_ITEM.OpticStateBrush(BetState);
        }
    }
}

public sealed record ST_OPTIC_PARAMETER_GROUP(string Device, string State, IReadOnlyList<ST_OPTIC_PARAMETER_ITEM> Items)
{
    public Brush StateBrush
    {
        get
        {
            return ST_OPTIC_PARAMETER_ITEM.OpticStateBrush(State);
        }
    }
}

public sealed record ST_OPTIC_PARAMETER_ITEM(string Item, string Current, string RecipeTarget, string State)
{
    public Brush StateBrush
    {
        get
        {
            return OpticStateBrush(State);
        }
    }

    public static Brush OpticStateBrush(string state)
    {
        return state.Trim().ToUpperInvariant() switch
        {
            "OK" or "ON" or "OPEN" or "RUN" or "READY" or "SAFE" or "CLOSE" or "DONE" => CStatusBrush.Online,
            "MOVING" or "WARN" or "WAIT" or "STOP" => CStatusBrush.Wait,
            "ALARM" or "ERROR" or "NG" or "OFFLINE" => CStatusBrush.Offline,
            "N/C" => CStatusBrush.Muted,
            _ => CStatusBrush.Muted
        };
    }
}

internal readonly record struct ST_OPTIC_LASER_HEAD_PARAMETER(string Power, string Gate, string Shutter, string State);
internal readonly record struct ST_OPTIC_AXIS_HEAD_PARAMETER(string Current, string Target, string State);
internal readonly record struct ST_OPTIC_BET_HEAD_PARAMETER(string MagnificationCurrentStep, string MagnificationTargetStep, string DivergenceCurrentStep, string DivergenceTargetStep, string State);
public sealed record ST_SCANNER_AXIS_STATUS_ITEM(string Head, string Automation, string Axis, string AxisNo, string Able, string Position, string AuxFeedback, string CurrentFeedback, string GalvoLaserOutputRaw, string GalvoTemperature, string Home, string Fault, string Error, string Detail)
{
    public Brush AbleBrush
    {
        get
        {
            return ScannerStateBrush(Able);
        }
    }

    public Brush HomeBrush
    {
        get
        {
            return ScannerStateBrush(Home);
        }
    }

    public Brush ErrorBrush
    {
        get
        {
            return ScannerStateBrush(Error);
        }
    }

    public Brush FaultBrush
    {
        get
        {
            return IsFaultClear(Fault) ? CStatusBrush.Online : CStatusBrush.Offline;
        }
    }

    private static Brush ScannerStateBrush(string state)
    {
        return state.Trim().ToUpperInvariant() switch
        {
            "ABLE" or "HOME" or "OK" => CStatusBrush.Online,
            "DISABLE" or "WAIT" => CStatusBrush.Wait,
            "NO" or "ERROR" or "OFFLINE" => CStatusBrush.Offline,
            _ => CStatusBrush.Muted
        };
    }

    private static bool IsFaultClear(string fault)
    {
        var normalized = fault.Trim();
        return normalized.Length == 0 || normalized.Equals("-", StringComparison.OrdinalIgnoreCase) || normalized.Equals("0", StringComparison.OrdinalIgnoreCase) || normalized.Equals("0.0", StringComparison.OrdinalIgnoreCase) || normalized.Equals("FALSE", StringComparison.OrdinalIgnoreCase);
    }
}
