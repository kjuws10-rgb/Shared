using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows;
using Drilling.Common.Alarm;

namespace Drilling.UI.Menu.Menus;

public sealed class CAlarmHistoryPanel : INotifyPropertyChanged
{
    private readonly Func<DateTime, DateTime, CancellationToken, ST_ALARM_HISTORY_RESULT> _read;
    private readonly Func<DateTime> _now;
    private DateTime? _from = DateTime.Today;
    private DateTime? _through = DateTime.Today;
    private string _fromTime = "00:00:00";
    private string _throughTime = "00:00:00";
    private bool _hasOpened;
    private bool _isCodeView = true;
    private IReadOnlyList<ST_ALARM_HISTORY_ENTRY> _loadedRows = [];
    private DateTime? _searchedFrom;
    private DateTime? _searchedThrough;
    public CAlarmHistoryPanel(Func<DateTime, DateTime, CancellationToken, ST_ALARM_HISTORY_RESULT> read, Func<DateTime>? now = null)
    {
        _read = read;
        _now = now ?? (() => DateTime.Now);
        SetDefaultRange();
        SearchCommand = new(async _ => await SearchAsync(), _ => !IsBusy);
        Last24HoursCommand = new(async _ => await SearchLast24HoursAsync(), _ => !IsBusy);
        HourViewCommand = new(_ => SelectTrendView(false));
        CodeViewCommand = new(_ => SelectTrendView(true));
    }
    public event PropertyChangedEventHandler? PropertyChanged;
    public DateTime? From { get => _from; set { _from = value; Notify(); } }
    public DateTime? Through { get => _through; set { _through = value; Notify(); } }
    public string FromTime { get => _fromTime; set { _fromTime = value; Notify(); } }
    public string ThroughTime { get => _throughTime; set { _throughTime = value; Notify(); } }
    public bool IsBusy { get; private set; }
    public bool CanEdit => !IsBusy;
    public bool IsCodeView => _isCodeView;
    public bool IsHourView => !_isCodeView;
    public string Status { get; private set; } = "날짜와 시간을 지정하고 SEARCH를 눌러 주세요.";
    public string TrendCaption { get; private set; } = "코드별 발생 횟수 · 많은 순서";
    public string EmptyMessage { get; private set; } = "조회한 알람 이력이 없습니다.";
    public IReadOnlyList<ST_ALARM_HISTORY_ROW> Rows { get; private set; } = [];
    public IReadOnlyList<ST_ALARM_TREND_COLUMN> Bars { get; private set; } = [];
    public CButtonCommand SearchCommand { get; }
    public CButtonCommand Last24HoursCommand { get; }
    public CButtonCommand HourViewCommand { get; }
    public CButtonCommand CodeViewCommand { get; }

    public void InitializeOnFirstOpen()
    {
        if (_hasOpened) return;
        _hasOpened = true;
        SetDefaultRange();
    }

    private void SetDefaultRange()
    {
        var now = _now();
        From = Through = now.Date;
        FromTime = "00:00:00";
        ThroughTime = now.ToString("HH:mm:ss", CultureInfo.InvariantCulture);
    }

    private void SelectTrendView(bool codeView)
    {
        if (_isCodeView == codeView || IsBusy) return;
        _isCodeView = codeView;
        RefreshTrend();
        foreach (var name in new[] { nameof(IsCodeView), nameof(IsHourView), nameof(Bars), nameof(TrendCaption) }) Notify(name);
    }

    private void RefreshTrend()
    {
        if (_searchedFrom is not { } from || _searchedThrough is not { } through)
        {
            Bars = [];
            TrendCaption = IsCodeView ? "코드별 발생 횟수 · 많은 순서" : "시간별 발생 횟수 · 1시간 기준";
            return;
        }
        Bars = IsCodeView ? BuildCodeBars(_loadedRows) : BuildHourBars(_loadedRows, from, through);
        var summary = IsCodeView ? $"{Bars.Count:N0}개 코드 · 발생 횟수 내림차순" : "시간별 · 1시간 기준";
        TrendCaption = $"{from:yyyy-MM-dd HH:mm:ss.fff} ~ {through:yyyy-MM-dd HH:mm:ss.fff}\n{summary} · 총 {_loadedRows.Count:N0}건";
    }

    public async Task SearchLast24HoursAsync()
    {
        if (IsBusy) return;
        var now = _now();
        // Display and query the same millisecond precision, including across midnight.
        var through = new DateTime(now.Ticks - now.Ticks % TimeSpan.TicksPerMillisecond, now.Kind);
        var from = through.AddHours(-24);
        From = from.Date;
        Through = through.Date;
        FromTime = from.ToString("HH:mm:ss.fff", CultureInfo.InvariantCulture);
        ThroughTime = through.ToString("HH:mm:ss.fff", CultureInfo.InvariantCulture);
        await SearchAsync();
    }

    public async Task SearchAsync()
    {
        if (IsBusy) return;
        if (From is not { } from || Through is not { } through ||
            !TryReadTime(FromTime, out var fromTime) || !TryReadTime(ThroughTime, out var throughTime))
        {
            Status = "날짜와 시간을 올바르게 입력해 주세요. 시간 형식: HH:mm 또는 HH:mm:ss (24시간제).";
            Notify(nameof(Status));
            return;
        }
        from = from.Date.Add(fromTime);
        through = through.Date.Add(throughTime);
        if (from > through)
        {
            Status = "시작 일시는 종료 일시보다 늦을 수 없습니다.";
            Notify(nameof(Status));
            return;
        }
        IsBusy = true;
        Status = "알람 이력을 조회하고 있습니다.";
        Notify(nameof(IsBusy)); Notify(nameof(CanEdit)); Notify(nameof(Status));
        SearchCommand.NotifyCanExecuteChanged();
        Last24HoursCommand.NotifyCanExecuteChanged();
        try
        {
            var result = await Task.Run(() =>
            {
                // The store opens only the relevant daily files. Apply exact times before both grid and chart.
                var loaded = _read(from.Date, through.Date, CancellationToken.None);
                return loaded with { Rows = loaded.Rows.Where(row => row.OccurredAt.LocalDateTime >= from && row.OccurredAt.LocalDateTime <= through)
                    .OrderByDescending(row => row.OccurredAt).ThenBy(row => row.Code).ToArray() };
            });
            Rows = result.Rows.Select((row, index) => new ST_ALARM_HISTORY_ROW(index + 1,
                row.OccurredAt.LocalDateTime.ToString("yyyy-MM-dd HH:mm:ss.fff"), row.Code.ToString(),
                row.Level, row.Group, row.Cause, row.Solution)).ToArray();
            _loadedRows = result.Rows;
            _searchedFrom = from;
            _searchedThrough = through;
            RefreshTrend();
            Status = result.Warning.Length == 0 ? $"{Rows.Count:N0}건 조회 완료" : $"{Rows.Count:N0}건 조회 · {result.Warning}";
            EmptyMessage = "해당 기간에 발생한 알람이 없습니다.";
        }
        catch (Exception exception) when (exception is IOException or UnauthorizedAccessException or ArgumentException)
        {
            Rows = []; Bars = [];
            _loadedRows = [];
            _searchedFrom = _searchedThrough = null;
            Status = $"알람 이력 조회 실패: {exception.Message}";
            EmptyMessage = "알람 이력을 읽지 못했습니다.";
            TrendCaption = "조회 실패";
        }
        finally
        {
            IsBusy = false;
            foreach (var name in new[] { nameof(Rows), nameof(Bars), nameof(Status), nameof(EmptyMessage), nameof(TrendCaption), nameof(IsBusy), nameof(CanEdit) }) Notify(name);
            SearchCommand.NotifyCanExecuteChanged();
            Last24HoursCommand.NotifyCanExecuteChanged();
        }
    }

    private static bool TryReadTime(string value, out TimeSpan time)
    {
        string[] formats = ["H:mm", "HH:mm", "H:mm:ss", "HH:mm:ss", "H:mm:ss.FFF", "HH:mm:ss.FFF"];
        var valid = DateTime.TryParseExact(value?.Trim(), formats, CultureInfo.InvariantCulture, DateTimeStyles.None, out var parsed);
        time = parsed.TimeOfDay;
        return valid;
    }

    private static IReadOnlyList<ST_ALARM_TREND_COLUMN> BuildCodeBars(IReadOnlyList<ST_ALARM_HISTORY_ENTRY> rows)
    {
        if (rows.Count == 0) return [];
        var counts = rows.GroupBy(row => row.Code).Select(group => new { Code = group.Key, Cause = group.First().Cause, Count = group.Count() })
            .OrderByDescending(group => group.Count).ThenBy(group => group.Code).ToArray();
        var maximum = counts[0].Count;
        return counts.Select(group => new ST_ALARM_TREND_COLUMN(group.Code.ToString(CultureInfo.InvariantCulture),
            $"{group.Code} · {group.Cause}\n발생 {group.Count:N0}건", group.Cause, group.Count,
            new GridLength(group.Count, GridUnitType.Star), new GridLength(maximum - group.Count, GridUnitType.Star))).ToArray();
    }

    private static IReadOnlyList<ST_ALARM_TREND_COLUMN> BuildHourBars(IReadOnlyList<ST_ALARM_HISTORY_ENTRY> rows, DateTime from, DateTime through)
    {
        static DateTime Hour(DateTime value) => value.Date.AddHours(value.Hour);
        var counts = rows.GroupBy(row => Hour(row.OccurredAt.LocalDateTime)).ToDictionary(group => group.Key, group => group.Count());
        var maximum = Math.Max(1, counts.Values.DefaultIfEmpty(0).Max());
        var bars = new List<ST_ALARM_TREND_COLUMN>();
        var end = Hour(through);
        for (var hour = Hour(from); ; hour = hour.AddHours(1))
        {
            var count = counts.GetValueOrDefault(hour);
            bars.Add(new(hour.ToString("MM-dd HH:mm", CultureInfo.InvariantCulture), $"{hour:yyyy-MM-dd HH:mm} · {count:N0}건", "", count,
                new GridLength(count, GridUnitType.Star), new GridLength(maximum - count, GridUnitType.Star), IsHourly: true));
            if (hour == end) break;
        }
        return bars;
    }

    private void Notify([CallerMemberName] string? name = null) => PropertyChanged?.Invoke(this, new(name));
}

public sealed record ST_ALARM_TREND_COLUMN(string Label, string Detail, string Cause, int Count, GridLength FilledWidth, GridLength EmptyWidth, bool IsHourly = false);
