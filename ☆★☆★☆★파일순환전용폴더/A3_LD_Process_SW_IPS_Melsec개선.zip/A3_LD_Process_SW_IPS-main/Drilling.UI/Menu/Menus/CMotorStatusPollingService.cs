using System.Globalization;
using Drilling.Common.Interface;
using Drilling.Common.Managers;
using Drilling.Common.Threading;

namespace Drilling.UI.Menu.Menus;

internal sealed class CMotorStatusPollingService(CInterfaceManager interfaceManager) : CtrlThread
{
    private static readonly (string Name, string Key)[] Axes =
        [("Stage Y", "STAGE_Y"), ("Review X", "CAMERA_X"), ("Window Y", "WINDOW_Y")];
    private readonly object _snapshotLock = new();
    private IReadOnlyList<ST_MOTOR_STATUS_ITEM> _snapshot = CreateEmptySnapshot();

    public void Start()
    {
        if (!IsRunning) Run(); // Populate the first frame from shared memory before the menu is shown.
        base.Start(1000, "MotorStatusPolling");
    }

    public IReadOnlyList<ST_MOTOR_STATUS_ITEM> GetSnapshot()
    {
        lock (_snapshotLock)
        {
            return _snapshot;
        }
    }

    public void ClearSnapshot()
    {
        lock (_snapshotLock)
        {
            _snapshot = CreateEmptySnapshot();
        }
    }

    public override void Run()
    {
        var items = ReadCachedSnapshot(interfaceManager);
        lock (_snapshotLock)
        {
            _snapshot = items;
        }
    }

    internal static IReadOnlyList<ST_MOTOR_STATUS_ITEM> ReadCachedSnapshot(CInterfaceManager interfaceManager)
    {
        var cachedValues = interfaceManager.Melsec.GetCachedSnapshot(out var mapRows);
        var map = mapRows.ToDictionary(row => row.Id, StringComparer.OrdinalIgnoreCase);
        var simulatedDevices = interfaceManager.GetInterfaceCommunicationList(EN_EQP_MODULE.Melsec)
            .Where(row => row.IsSimulation).Select(row => row.Number).ToHashSet();
        var simulationFrames = new Dictionary<int, IReadOnlyDictionary<string, double>>();
        (string Value, string Message) Read(string id)
        {
            map.TryGetValue(id, out var row);
            var number = row?.DeviceNo ?? mapRows.FirstOrDefault(item => item.Id == "MOTOR_STAGE_Y_CUR_POS")?.DeviceNo
                ?? interfaceManager.GetInterfaceList(EN_EQP_MODULE.Melsec).FirstOrDefault()?.Number;
            (string Value, string Message)? fallback = null;
            if (number is { } deviceNo && simulatedDevices.Contains(deviceNo))
            {
                if (!simulationFrames.TryGetValue(deviceNo, out var frame))
                    simulationFrames[deviceNo] = frame = interfaceManager.GetStageMotionSimulationFeedback(deviceNo);
                if (frame.TryGetValue(id, out var value))
                    fallback = (value.ToString("F3", CultureInfo.InvariantCulture), "Shared MELSEC stage simulation feedback.");
            }
            return ReadValue(map, cachedValues, id, fallback);
        }
        return Axes.Select(axis =>
        {
            var position = Read($"MOTOR_{axis.Key}_CUR_POS");
            var speed = Read($"MOTOR_{axis.Key}_CUR_SPEED");
            var acceleration = Read($"MOTOR_{axis.Key}_CUR_ACC");
            return new ST_MOTOR_STATUS_ITEM(axis.Name, position.Value, speed.Value, acceleration.Value)
            {
                PositionMessage = position.Message,
                SpeedMessage = speed.Message,
                AccelerationMessage = acceleration.Message
            };
        }).ToArray();
    }

    internal static EN_COMM_STATE ReadStageConnectionState(CInterfaceManager interfaceManager)
    {
        // Simulation is an operating setting and remains usable while the interface is offline.
        // Read the current runtime setting and connection state without device I/O.
        var ids = new[] { "MOTOR_STAGE_Y_CUR_POS", "MOTOR_STAGE_Y_CUR_SPEED", "MOTOR_CAMERA_X_CUR_POS", "MOTOR_CAMERA_X_CUR_SPEED" };
        var map = interfaceManager.Melsec.GetMapList();
        var rows = ids.Select(id => map.FirstOrDefault(row => string.Equals(row.Id, id, StringComparison.OrdinalIgnoreCase))).ToArray();
        var connections = interfaceManager.GetInterfaceCommunicationList(EN_EQP_MODULE.Melsec);
        // Unassigned/disabled feedback rows are excluded from the active map. Simulation
        // must still work before addresses are configured; use the registered interfaces.
        IEnumerable<ST_INTERFACE_COMM_STATUS?> axisConnections = rows.Any(row => row is null)
            ? connections
            : rows.Select(row => row!.DeviceNo).Distinct()
                .Select(number => connections.FirstOrDefault(device => device.Number == number));
        var states = axisConnections
            .Select(device => device?.IsSimulation == true ? EN_COMM_STATE.Simulation : device?.ConnectionState ?? EN_COMM_STATE.Offline)
            .Distinct().ToArray();
        return states.Length == 1 ? states[0] : EN_COMM_STATE.Offline;
    }

    private static (string Value, string Message) ReadValue(
        IReadOnlyDictionary<string, ST_MELSEC_MAP_DATA> map,
        IReadOnlyDictionary<string, ST_MELSEC_CACHED_VALUE> cachedValues,
        string id, (string Value, string Message)? simulationFallback = null)
    {
        if (!map.TryGetValue(id, out var row) || !row.Use)
        {
            return simulationFallback ?? ("-", "MELSEC feedback is not configured.");
        }

        if (row.Access == EN_MELSEC_ACCESS.Write)
        {
            return ("ERR", $"{id} is write-only.");
        }

        if (!cachedValues.TryGetValue(id, out var cached) || cached.State == EN_MELSEC_CACHE_STATE.Pending)
        {
            return simulationFallback ?? ("-", "Waiting for MELSEC feedback.");
        }

        if (!cached.IsValid)
        {
            if (row.Access == EN_MELSEC_ACCESS.Read && cached.State is EN_MELSEC_CACHE_STATE.Offline or EN_MELSEC_CACHE_STATE.Stale && simulationFallback is { } simulation)
                return simulation;
            return ("ERR", CMelsecCachePresentation.Describe(cached));
        }

        var value = CMelsecCachePresentation.NumericValue(cached.Value);
        value = row.DataType switch
        {
            EN_MELSEC_DATA_TYPE.Word or EN_MELSEC_DATA_TYPE.DWord or EN_MELSEC_DATA_TYPE.Double or EN_MELSEC_DATA_TYPE.Float => value,
            _ => double.NaN
        };
        return double.IsFinite(value)
            ? (value.ToString("F3", CultureInfo.InvariantCulture), CMelsecCachePresentation.Describe(cached))
            : ("ERR", $"{id} has invalid numeric feedback.");
    }

    private static IReadOnlyList<ST_MOTOR_STATUS_ITEM> CreateEmptySnapshot() =>
        Axes.Select(axis => new ST_MOTOR_STATUS_ITEM(axis.Name, "-", "-", "-")).ToArray();
}

public sealed record ST_MOTOR_STATUS_ITEM(string Name, string Position, string Speed, string Acceleration)
{
    public string PositionMessage { get; init; } = "";
    public string SpeedMessage { get; init; } = "";
    public string AccelerationMessage { get; init; } = "";
}
