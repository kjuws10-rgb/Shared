using System.ComponentModel;
using System.IO;
using System.Runtime.CompilerServices;
using Drilling.Common.Log;
using Drilling.UI.Popup;
using System.Windows;

namespace Drilling.UI.Menu.Menus;

public sealed class CMonitorLogViewerPanel : INotifyPropertyChanged
{
    private readonly string _logDirectory;
    private readonly CLogFileScope _fileScope;
    private string? _lastOpenedDirectory;
    private readonly List<long> _pageOffsets = [0];
    private int _pageIndex;
    private long _nextOffset;
    private long _fileLength;

    public CMonitorLogViewerPanel(string logDirectory)
    {
        _fileScope = new CLogFileScope(logDirectory);
        _logDirectory = _fileScope.RootDirectory;
        OpenCommand = new(async _ => await OpenFileAsync(), _ => !IsBusy);
        PreviousCommand = new(async _ => await PreviousAsync(), _ => CanPrevious);
        NextCommand = new(async _ => await NextAsync(), _ => CanNext);
    }

    public event PropertyChangedEventHandler? PropertyChanged;
    public string OpenDirectory => _lastOpenedDirectory ?? _logDirectory;
    public string FilePath { get; private set; } = "";
    public string Text { get; private set; } = "";
    public string Status { get; private set; } = "FILE OPEN을 눌러 확인할 로그 파일을 선택해 주세요.";
    public bool IsBusy { get; private set; }
    public bool CanPrevious => !IsBusy && _pageIndex > 0;
    public bool CanNext => !IsBusy && _nextOffset < _fileLength;
    public string PageLabel => FilePath.Length == 0 ? "" : $"PAGE {_pageIndex + 1:N0}";
    public CButtonCommand OpenCommand { get; }
    public CButtonCommand PreviousCommand { get; }
    public CButtonCommand NextCommand { get; }

    private async Task OpenFileAsync()
    {
        if (IsBusy) return;
        var dialog = new CLogFilePickerDialog(_logDirectory, OpenDirectory)
        {
            Owner = Application.Current?.MainWindow
        };
        if (dialog.ShowDialog() == true && dialog.SelectedFilePath is { } path) await LoadFileAsync(path);
    }

    public async Task LoadFileAsync(string path)
    {
        if (IsBusy) return;
        FilePath = "";
        Text = "";
        _pageOffsets.Clear();
        _pageOffsets.Add(0);
        _pageIndex = 0;
        _nextOffset = _fileLength = 0;
        await LoadPageAsync(path, 0);
    }

    public Task PreviousAsync() => CanPrevious ? LoadPageAsync(FilePath, _pageIndex - 1) : Task.CompletedTask;
    public Task NextAsync() => CanNext ? LoadPageAsync(FilePath, _pageIndex + 1) : Task.CompletedTask;

    private async Task LoadPageAsync(string path, int index)
    {
        var offset = index < _pageOffsets.Count ? _pageOffsets[index] : _nextOffset;
        IsBusy = true;
        Status = "로그를 읽고 있습니다...";
        NotifyView();
        try
        {
            // No timers or tab-entry reads: only explicit file/page commands reach the reader.
            var page = await Task.Run(() => CLogTextReader.ReadPage(_fileScope.ResolveFile(path), offset));
            if (index == _pageOffsets.Count) _pageOffsets.Add(offset);
            _pageIndex = index;
            _nextOffset = page.NextOffset;
            _fileLength = page.FileLength;
            FilePath = Path.GetFullPath(path);
            _lastOpenedDirectory = Path.GetDirectoryName(FilePath);
            Text = page.Text;
            Status = _fileLength == 0 || (_pageIndex == 0 && Text.Length == 0)
                ? "내용이 없는 파일입니다."
                : $"{_fileLength / 1024.0:N1} KB · 읽기 전용 · 큰 파일은 PREV / NEXT로 확인할 수 있습니다.";
        }
        catch (Exception exception) when (exception is IOException or UnauthorizedAccessException or ArgumentException)
        {
            Status = $"로그를 읽지 못했습니다: {exception.Message}";
        }
        finally
        {
            IsBusy = false;
            NotifyView();
        }
    }

    private void NotifyView()
    {
        foreach (var property in new[] { nameof(FilePath), nameof(Text), nameof(Status), nameof(PageLabel), nameof(IsBusy), nameof(CanPrevious), nameof(CanNext) })
            Notify(property);
        OpenCommand.NotifyCanExecuteChanged();
        PreviousCommand.NotifyCanExecuteChanged();
        NextCommand.NotifyCanExecuteChanged();
    }

    private void Notify([CallerMemberName] string? property = null) => PropertyChanged?.Invoke(this, new(property));
}
