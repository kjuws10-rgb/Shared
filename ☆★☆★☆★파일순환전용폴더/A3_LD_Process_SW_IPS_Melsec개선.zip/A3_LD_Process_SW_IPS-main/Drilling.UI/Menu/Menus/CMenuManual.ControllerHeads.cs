﻿using System.ComponentModel;
using System.IO;
using System.Windows.Media;
using Drilling.Common.Managers;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuManual
{
    private readonly Dictionary<int, ST_MANUAL_CONTROLLER_HEAD> _controllerHeadCache = [];
    public IReadOnlyList<ST_MANUAL_CONTROLLER_HEAD> ManualControllerHeads { get; private set; } = [];

    private void RefreshManualControllerHeads()
    {
        var heads = SelectedManualHeadNos;
        _scannerStatusSnapshotReader?.SelectHeads(heads, _manualScannerOptionSettings);
        var snapshot = _scannerStatusSnapshotReader?.GetSnapshot() ?? [];
        var cards = new List<ST_MANUAL_CONTROLLER_HEAD>();
        foreach (var head in heads)
        {
            if (!_controllerHeadCache.TryGetValue(head, out var card))
            {
                card = new ST_MANUAL_CONTROLLER_HEAD(head, value => RunHeadDioCommand(head, value));
                _controllerHeadCache.Add(head, card);
            }
            var axes = snapshot.Where(axis => axis.HeadNo == head).ToArray();
            card.SetAxes(axes.Length > 0 ? axes : CManualScannerSnapshotReader.BuildFallbackAxes(_manualScannerOptionSettings, head));
            try { card.SetTarget(CreateManualDioTarget(_manualScannerOptionSettings, head), ""); }
            catch (Exception exception) when (exception is InvalidOperationException or InvalidDataException)
            { card.SetTarget(null, exception.Message); }
            cards.Add(card);
        }
        if (!ManualControllerHeads.SequenceEqual(cards))
        {
            ManualControllerHeads = cards;
            OnPropertyChanged(nameof(ManualControllerHeads));
        }
        MotionPanel.RefreshHeads(ManualControllerHeads);
        RefreshManualHomeSpeedTargets();
        RefreshManualScanAssignments();
        RefreshPowerMeasurePanel();
    }

    private async Task RunHeadDioCommand(int headNo, bool? output)
    {
        if (!_selectedManualHeadNos.Contains(headNo) || !_controllerHeadCache.TryGetValue(headNo, out var card) ||
            !card.CanControlDio || card.DioTarget is not { } target) return;
        var command = output.HasValue ? output.Value ? "DIO_ON" : "DIO_OFF" : "DIO_READ";
        if (TryBlockManualAutomationCommand(command)) return;
        card.SetBusy(true);
        try
        {
            var settings = _manager.Setting().LoadSection(EN_SETTING_TAB.Option);
            if (!CScannerStatusSnapshotReader.BuildEnabledHeadNumbers(settings).Contains(headNo) ||
                CreateManualDioTarget(settings, headNo) != target)
                throw new InvalidOperationException("Head 또는 DIO 설정이 변경되었습니다. 다시 선택해 주세요.");
            var response = output.HasValue
                ? await _manager.automation.SetIo(target.Address, output.Value, target.AutomationNo)
                : await _manager.automation.ReadIo(target.Address, target.AutomationNo);
            EnsureAutomationResponse(response, $"H{headNo:00} {command}");
            var value = ReadDioValueFromResponse(response);
            if (card.DioTarget == target) card.SetDioState(value, $"Current {value}");
            _setStatusMessage($"H{headNo:00} {command} · {target.Address}: {value}");
        }
        catch (Exception exception) when (exception is InvalidOperationException or IOException or TimeoutException or KeyNotFoundException)
        {
            if (card.DioTarget == target) card.SetDioState("UNKNOWN", exception.Message);
            _setStatusMessage($"H{headNo:00} {command} failed. {exception.Message}");
        }
        finally
        {
            card.SetBusy(false);
            _refreshShellStatus();
        }
    }
}

public sealed class ST_MANUAL_CONTROLLER_HEAD : INotifyPropertyChanged
{
    public event PropertyChangedEventHandler? PropertyChanged;
    public int HeadNo { get; }
    public string HeadName => $"HEAD {HeadNo:00}";
    public IReadOnlyList<ST_MANUAL_SCANNER_AXIS> Axes { get; private set; } = [];
    public ST_MANUAL_SCANNER_AXIS? XAxis => Axes.FirstOrDefault(axis => axis.AxisRole == "X");
    public ST_MANUAL_SCANNER_AXIS? YAxis => Axes.FirstOrDefault(axis => axis.AxisRole == "Y");
    public ST_MANUAL_SCANNER_AXIS? ZAxis => Axes.FirstOrDefault(axis => axis.AxisRole == "Z");
    public string XCurrentPosition => FormatCurrentPosition(XAxis);
    public string YCurrentPosition => FormatCurrentPosition(YAxis);
    public string ZCurrentPosition => FormatCurrentPosition(ZAxis);
    private static string FormatCurrentPosition(ST_MANUAL_SCANNER_AXIS? axis)
        => axis is null ? "-" : axis.IsControlEnabled ? axis.CurrentPosition : "NOT USE";
    public ST_MANUAL_DIO_TARGET? DioTarget { get; private set; }
    public string DioAxisName => DioTarget?.AxisName ?? "-";
    public string DioNo => DioTarget?.DioNo.ToString() ?? "-";
    public string DioState { get; private set; } = "UNKNOWN";
    public string DioDetail { get; private set; } = "";
    public bool IsDioBusy { get; private set; }
    public bool CanControlDio => DioTarget is not null && !IsDioBusy;
    public Brush DioBackground => DioState == "ON" ? CStatusBrush.Online : DioState == "OFF" ? CStatusBrush.Offline : CStatusBrush.Muted;
    public CButtonCommand ReadDioCommand { get; }
    public CButtonCommand DioOnCommand { get; }
    public CButtonCommand DioOffCommand { get; }

    public ST_MANUAL_CONTROLLER_HEAD(int headNo, Func<bool?, Task> executeDio)
    {
        HeadNo = headNo;
        ReadDioCommand = new CButtonCommand(async _ => await executeDio(null), _ => CanControlDio);
        DioOnCommand = new CButtonCommand(async _ => await executeDio(true), _ => CanControlDio);
        DioOffCommand = new CButtonCommand(async _ => await executeDio(false), _ => CanControlDio);
    }

    public void SetAxes(IReadOnlyList<ST_MANUAL_SCANNER_AXIS> axes)
    {
        if (Axes.SequenceEqual(axes)) return;
        Axes = axes;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Axes)));
        foreach (var property in new[] { nameof(XAxis), nameof(YAxis), nameof(ZAxis), nameof(XCurrentPosition), nameof(YCurrentPosition), nameof(ZCurrentPosition) })
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(property));
    }
    public void SetTarget(ST_MANUAL_DIO_TARGET? target, string error)
    {
        if (DioTarget == target && (target is not null || DioDetail == error)) return;
        DioTarget = target;
        DioState = "UNKNOWN";
        DioDetail = error;
        NotifyDio();
    }
    public void SetDioState(string state, string detail) { DioState = state; DioDetail = detail; NotifyDio(); }
    public void SetBusy(bool busy) { IsDioBusy = busy; NotifyDio(); }
    private void NotifyDio()
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(string.Empty));
        ReadDioCommand.NotifyCanExecuteChanged(); DioOnCommand.NotifyCanExecuteChanged(); DioOffCommand.NotifyCanExecuteChanged();
    }
}
