using System.ComponentModel;
using System.Globalization;
using System.Windows;
using System.Windows.Media;
using Drilling.Common.Managers;
using Drilling.Common.Recipe;
using Drilling.Common.Review;
using Drilling.UI.Popup;

namespace Drilling.UI.Menu.Menus;

public enum EN_FINE_LINE_STATE { Wait, Running, Complete, Ng, Error }

/// <summary>Fine UI receives sequence snapshots. No device/file polling or motion commands in this view model.</summary>
public sealed partial class CFineCorrectionPanel : INotifyPropertyChanged
{
    private readonly Action<string>? _requestAction;
    private readonly Func<string, EN_REVIEW_RESUME_CHOICE>? _chooseRetry;
    private IReadOnlyDictionary<string, string> _parameters = new Dictionary<string, string>();
    private ST_REVIEW_PLAN? _source;
    private ST_GLASS_PREVIEW_FRAME _sourceFrame = new(44, 62, 772, 420);
    private IReadOnlyList<ST_CELL_PREVIEW_LABEL> _sourceCells = [];
    private int _selectedBeam = 1;
    private ST_RECIPE_DEFINITION? _recipe;
    private int _sourceVersion;
    private bool _operationRunning;
    private readonly Dictionary<string, ST_FINE_REVIEW_LINE> _lastSnapshots = new();
    private double _width = 780, _height = 660;
    public event PropertyChangedEventHandler? PropertyChanged;
    public event Action? SourceInvalidated;
    public CFineCorrectionPanel(Action<string>? requestAction = null, Func<string, EN_REVIEW_RESUME_CHOICE>? chooseRetry = null)
    {
        _requestAction = requestAction; _chooseRetry = chooseRetry;
        SelectLineCountCommand = new(SelectLineCount, _ => CanConfigure);
        SelectMethodCommand = new(SelectMethod, _ => CanConfigure);
        OpenLineDetailsCommand = new(value =>
        {
            if (value is CFineInspectionLine line && Lines.Contains(line)) ShowLineDetails?.Invoke(line);
        });
        ActionCommand = new(ExecuteAction, value => value?.ToString() switch
        {
            "START" => CanConfigure && Lines.Count > 0,
            "STOP" => IsRunning,
            "NG_RETRY" => CanConfigure && Lines.Any(line => line.State == EN_FINE_LINE_STATE.Ng),
            "OFFSET_APPLY" => CanApplyOffset,
            "OFFSET_INIT" => CanConfigure && _source?.Points.Count > 0,
            "OFFSET_VIEW" => CanConfigure && _recipe is not null,
            _ => false
        });
    }
    public CButtonCommand SelectLineCountCommand { get; }
    public CButtonCommand SelectMethodCommand { get; }
    public CButtonCommand ActionCommand { get; }
    public CButtonCommand OpenLineDetailsCommand { get; }
    public Action<CFineInspectionLine>? ShowLineDetails { get; set; }
    public Func<(string StageY, string ReviewX, string Mode)>? ReadFeedback { get; set; }
    public CReviewCameraPreview Camera { get; } = new();
    public string RecipeId { get; private set; } = "";
    public string RecipeName { get; private set; } = "-";
    public string StageY { get; private set; } = "-";
    public string ReviewX { get; private set; } = "-";
    public string Mode { get; private set; } = "OFFLINE";
    public int LineCount { get; private set; } = 1;
    public bool IsOneLine => LineCount == 1;
    public bool IsThreeLine => LineCount == 3;
    public bool IsFiveLine => LineCount == 5;
    public bool IsSevenLine => LineCount == 7;
    public string InspectionMethod { get; private set; } = "FLYING";
    public bool IsFlying => InspectionMethod == "FLYING";
    public bool IsPtoP => InspectionMethod == "P2P";
    public IReadOnlyList<int> BeamNumbers { get; private set; } = [];
    public int SelectedBeam
    {
        get => _selectedBeam;
        set
        {
            if (!CanConfigure || !BeamNumbers.Contains(value) || value == _selectedBeam) return;
            _selectedBeam = value;
            BuildLines();
        }
    }
    public bool IsRunning { get; private set; }
    public bool CanConfigure => !IsRunning && !_operationRunning;
    public int SourceVersion => _sourceVersion;
    public string LastResultPath { get; private set; } = "";
    public Guid MonitorRunId { get; private set; }
    public string Status { get; private set; } = "검사 대기";
    public int? RetryStartLineNo { get; private set; }
    public ImageSource? PreviewImage { get; private set; }
    public Transform PreviewTransform { get; private set; } = Transform.Identity;
    public Rect GlassBounds { get; private set; }
    public double PreviewWidth { get; private set; } = 780;
    public double PreviewHeight { get; private set; } = 660;
    public IReadOnlyList<ST_FINE_CELL_VISUAL> Cells { get; private set; } = [];
    public IReadOnlyList<CFineInspectionLine> Lines { get; private set; } = [];
    public IReadOnlyList<ST_FINE_LINE_VISUAL> LineVisuals { get; private set; } = [];
    public IReadOnlyList<PointCollection> Connections { get; private set; } = [];
    public string Summary => $"{Cells.Count:N0} Cells / {LineCount} Line per Cell / {Lines.Count:N0} Inspection Lines / {Lines.Sum(line => line.Points.Count):N0} Shots / Beam {SelectedBeam}";
    public string ModelOrder => string.Join(" → ", Lines.DistinctBy(line => line.ModelNo).Select(line => $"MODEL {line.ModelNo} ({line.ModelCellCount} Cells)"));

    public void Update(ST_RECIPE_DEFINITION? recipe, IReadOnlyList<ST_SYSTEM_PARAMETER> settings)
    {
        if (recipe is null) { Clear("현재 레시피를 선택해 주세요."); return; }
        var parameters = recipe.Parameters.Where(item => item.Key.Length > 0).ToDictionary(item => item.Key, item => item.Value, StringComparer.OrdinalIgnoreCase);
        foreach (var setting in settings.Where(item => item.Key.Length > 0)) parameters[setting.Key] = setting.Value;
        // Saved offsets do not change Fine line selection or the design-coordinate route.
        foreach (var key in parameters.Keys.Where(key => key.Contains("OFFSET", StringComparison.OrdinalIgnoreCase)).ToArray()) parameters.Remove(key);
        if (RecipeId == recipe.Id && RecipeName == recipe.Name && parameters.Count == _parameters.Count && parameters.All(item => _parameters.GetValueOrDefault(item.Key) == item.Value)) return;
        _parameters = parameters; _recipe = recipe; RecipeId = recipe.Id; RecipeName = recipe.Name;
        var assignment = new Dictionary<string, string>(parameters, StringComparer.OrdinalIgnoreCase) { ["HEAD_COUNT"] = "8" };
        for (var head = 1; head <= 8; head++) assignment[$"H{head:00}_USE"] = "ON";
        var shots = CShotCoordinatePlanBuilder.Build(assignment).Shots;
        var split = int.TryParse(parameters.GetValueOrDefault("SPLITED_BEAM_COUNT"), out var count) ? count : 1;
        if (!CCellPatternCalculator.IsSupportedSplitBeamCount(split)) throw new InvalidOperationException("SPLITED_BEAM_COUNT를 확인해 주세요.");
        BeamNumbers = Enumerable.Range(1, split * split).ToArray();
        if (!BeamNumbers.Contains(_selectedBeam)) _selectedBeam = BeamNumbers[0];
        var masking = CRecipeShotMaskingPlan.Build(parameters);
        var enabled = CHeadAssignmentPreviewBuilder.BuildEnabledHeadNumbers(parameters).ToHashSet();
        var points = shots.Select(shot => new ST_REVIEW_PLAN_POINT(shot.SequenceNo, shot.ShotKey, shot.HeadNo, shot.CellNo,
            shot.CellShotNo, shot.GroupCountX, shot.GroupCountY, enabled.Contains(shot.HeadNo) && !masking.EvaluateShot(shot).ShouldSkipLaser,
            shot.DesignX, shot.DesignY, 0, 0, 0, 0, EN_REVIEW_POINT_STATE.Ready, "WAIT")).ToArray();
        _source = new(recipe.Id, points.Select(point => point.CellNo).Distinct().Count(), ReadTolerance(parameters, "REVIEW_TOLERANCE_X"), ReadTolerance(parameters, "REVIEW_TOLERANCE_Y"),
            CReviewCoordinateTransformer.ParseVisionFlipType(parameters.GetValueOrDefault("VisionXFlip"),
                parameters.GetValueOrDefault("VisionYFlip"), parameters.GetValueOrDefault("VisionXyFlip")), DateTimeOffset.Now, points);
        var preview = CHeadAssignmentPreviewBuilder.BuildRecipePreview(parameters, new HashSet<int>(),
            CHeadAssignmentPreviewBuilder.BuildHeadLayout(settings), showKeys: false);
        if (preview.ValidationMessage.Length > 0) throw new InvalidOperationException(preview.ValidationMessage);
        PreviewImage = preview.Image; _sourceFrame = preview.Frame; _sourceCells = preview.CellLabels;
        BuildLines(); RefreshFeedback();
    }
    public void Clear(string message)
    {
        MonitorRunId = Guid.Empty;
        _monitorNgPoints = []; _monitorFocus = null; MonitorNgImage = null;
        _sourceVersion++; SourceInvalidated?.Invoke(); _lastSnapshots.Clear(); _recipe = null; LastResultPath = ""; _offsetApplied = false;
        RecipeId = ""; RecipeName = "-"; _source = null; _sourceCells = []; _parameters = new Dictionary<string, string>();
        PreviewImage = null; Lines = []; Cells = []; LineVisuals = []; Connections = []; IsRunning = false; Camera.Clear();
        BeamNumbers = []; _selectedBeam = 1;
        Status = message; RetryStartLineNo = null; RefreshOffsetEligibility(); Notify();
    }
    private void BuildLines()
    {
        if (_source is null) { Notify(); return; }
        MonitorRunId = Guid.Empty;
        _sourceVersion++; SourceInvalidated?.Invoke(); _lastSnapshots.Clear(); LastResultPath = ""; _offsetApplied = false;
        var selection = CReviewRulePlanBuilder.Build(_source, new(EN_REVIEW_CORRECTION_RULE.Fine,
            EN_REVIEW_CORRECTION_SCOPE.HeadCell, SelectedBeam, "", EN_REVIEW_REFERENCE_LINE.First, LineCount)).ShotKeys.ToHashSet(StringComparer.OrdinalIgnoreCase);
        var cellModels = _source.Points.Select(point => point.CellNo).Distinct().ToDictionary(cell => cell,
            cell => CRecipeModelPixelCountReader.ReadCellModelType(_parameters, cell));
        var counts = cellModels.Values.GroupBy(model => model).ToDictionary(group => group.Key, group => group.Count());
        var result = new List<CFineInspectionLine>();
        var stageDirection = CScannerAxisTransform.ReadStageDirection(_parameters);
        var calculatePosition = CReviewManager.CreateShotBeamPositionCalculator(_recipe!, stageDirection);
        ST_REVIEW_BEAM_POSITION Position(ST_REVIEW_PLAN_POINT point)
            => calculatePosition(point, SelectedBeam);
        foreach (var model in _source.Points.Where(point => point.Use && selection.Contains(point.ShotKey))
            .GroupBy(point => cellModels[point.CellNo]).OrderByDescending(group => counts[group.Key]).ThenBy(group => group.Key))
        {
            var row = 0;
            foreach (var line in model.GroupBy(point => Math.Round(point.DesignY, 6)).OrderBy(group => group.Key))
            {
                var leftToRight = row++ % 2 == 0;
                var ordered = (leftToRight ? line.OrderBy(point => point.DesignX) : line.OrderByDescending(point => point.DesignX))
                    .ThenBy(point => point.CellNo).ThenBy(point => point.ShotNo).Select(point =>
                    {
                        var position = Position(point);
                        return point with { BeamNo = SelectedBeam, ReviewTargetX = position.ReviewX, ReviewTargetY = position.StageY };
                    }).ToArray();
                result.Add(new($"B{SelectedBeam}:{model.Key}:{line.Key.ToString("R", CultureInfo.InvariantCulture)}", result.Count + 1,
                    model.Key, counts[model.Key], line.Key, leftToRight, ordered, Position(ordered[0]), Position(ordered[^1])));
            }
        }
        Lines = result; IsRunning = false; RetryStartLineNo = null; Status = "검사 대기";
        RefreshOffsetEligibility(); Layout(); Notify();
    }
    private void SelectLineCount(object? value)
    {
        if (!CanConfigure || !int.TryParse(value?.ToString(), out var count) || count is not (1 or 3 or 5 or 7) || LineCount == count) return;
        LineCount = count; BuildLines();
    }
    private void SelectMethod(object? value)
    {
        var method = value?.ToString();
        if (!CanConfigure || method is not ("FLYING" or "P2P") || InspectionMethod == method) return;
        InspectionMethod = method; BuildLines();
    }
    private void ExecuteAction(object? value)
    {
        var action = value?.ToString() ?? "";
        if (!ActionCommand.CanExecute(action)) return;
        if (action == "NG_RETRY")
        {
            var first = Lines.First(line => line.State == EN_FINE_LINE_STATE.Ng);
            var choice = _chooseRetry?.Invoke($"NG Line #{first.OrderNo} / MODEL {first.ModelNo}\n처음부터 검사할지, NG가 발생한 라인부터 검사할지 선택해 주세요.") ?? EN_REVIEW_RESUME_CHOICE.Cancel;
            if (choice == EN_REVIEW_RESUME_CHOICE.Cancel) return;
            RetryStartLineNo = choice == EN_REVIEW_RESUME_CHOICE.Restart ? 1 : first.OrderNo;
            Status = choice == EN_REVIEW_RESUME_CHOICE.Restart ? "재검사 선택: 처음부터" : $"재검사 선택: NG Line #{first.OrderNo}부터";
            Notify(); action = choice == EN_REVIEW_RESUME_CHOICE.Restart ? "RESTART" : "RESUME_NG";
        }
        _requestAction?.Invoke(action);
    }
    /// <summary>Status-only adapter used by UI checks.</summary>
    public void ApplyLineStates(IReadOnlyDictionary<string, EN_FINE_LINE_STATE> states, bool isRunning)
    {
        foreach (var line in Lines) if (states.TryGetValue(line.Key, out var state)) line.Update(state);
        IsRunning = isRunning;
        RefreshOffsetEligibility();
        Status = isRunning ? "검사 중" : Lines.Any(line => line.State == EN_FINE_LINE_STATE.Ng) ? "NG 발생 · NG RETRY에서 재검사 시작 위치를 선택해 주세요." : "검사 대기";
        Notify();
    }
    public ST_FINE_REVIEW_REQUEST CreateRequest(int startLineNo = 1, bool resume = false)
    {
        if (_recipe is null) throw new InvalidOperationException("현재 레시피가 없습니다.");
        var source = _source ?? throw new InvalidOperationException("검사 대상이 없습니다.");
        var lines = Lines.Select(line => new ST_FINE_REVIEW_LINE(line.Key, line.OrderNo, line.ModelNo,
            Array.AsReadOnly(line.Points.ToArray()), line.State switch
            {
                EN_FINE_LINE_STATE.Complete => EN_FINE_REVIEW_LINE_STATE.Complete,
                EN_FINE_LINE_STATE.Ng => EN_FINE_REVIEW_LINE_STATE.Ng,
                EN_FINE_LINE_STATE.Error => EN_FINE_REVIEW_LINE_STATE.Error,
                EN_FINE_LINE_STATE.Running => EN_FINE_REVIEW_LINE_STATE.Running,
                _ => EN_FINE_REVIEW_LINE_STATE.Wait
            })).ToArray();
        var plan = source with { Points = Array.AsReadOnly(lines.SelectMany(line => line.Points).ToArray()) };
        return new(plan, Array.AsReadOnly(lines), IsFlying ? EN_FINE_INSPECTION_METHOD.Flying : EN_FINE_INSPECTION_METHOD.PtoP, startLineNo, resume)
        {
            Context = new(RecipeName, "-", "MANUAL FINE", LineCount,
                new System.Collections.ObjectModel.ReadOnlyDictionary<string, string>(new Dictionary<string, string>(_parameters)))
        };
    }
    public void SetOperationRunning(bool value) { _operationRunning = value; Notify(); }
    public void Prepare() { IsRunning = true; Status = "검사 준비 중 · 레시피/목표 위치 확인"; Notify(); }
    public void Begin() { _lastSnapshots.Clear(); LastResultPath = ""; _offsetApplied = false; _allOffsetResultsOk = false; IsRunning = true; Status = "검사 준비 중"; Notify(); }
    public void End() { IsRunning = false; Notify(); }
    public void SetError(string message) { Status = message; Notify(); }
    public void ApplyProgress(ST_FINE_REVIEW_SNAPSHOT snapshot, int version)
    {
        if (version != _sourceVersion || snapshot.RecipeId != RecipeId) return;
        MonitorRunId = snapshot.RunId;
        var byKey = Lines.ToDictionary(line => line.Key);
        var layoutChanged = false;
        foreach (var incoming in snapshot.Lines)
        {
            if (_lastSnapshots.GetValueOrDefault(incoming.Key) == incoming || !byKey.TryGetValue(incoming.Key, out var line)) continue;
            layoutChanged |= line.ApplyProgress(incoming, _source!.VisionFlipType);
            _lastSnapshots[incoming.Key] = incoming;
        }
        IsRunning = snapshot.State == EN_REVIEW_SEQUENCE_STATE.Running;
        Status = snapshot.Message + (snapshot.ResultFilePath.Length > 0 ? " · 결과 저장 완료" : "");
        LastResultPath = snapshot.ResultFilePath;
        RefreshOffsetEligibility();
        if (layoutChanged) Layout();
        Notify();
    }
    private static double ReadTolerance(IReadOnlyDictionary<string, string> parameters, string key)
        => double.TryParse(parameters.GetValueOrDefault(key, "0.03"), NumberStyles.Float, CultureInfo.InvariantCulture, out var value) && double.IsFinite(value) && value >= 0
            ? value : throw new InvalidOperationException($"{key}를 확인해 주세요.");
    /// <summary>Replace one line's received Target-Hole snapshot. Call on the UI dispatcher, like ApplyLineStates.
    /// Missing Shots remain unmeasured. Execution state is supplied separately by the sequence.</summary>
    public void ApplyLineResults(string lineKey, IReadOnlyList<ST_FINE_SHOT_RESULT> results)
    {
        var line = Lines.SingleOrDefault(item => item.Key == lineKey)
            ?? throw new ArgumentException("검사 대상에 없는 라인입니다.", nameof(lineKey));
        line.ApplyResults(results, _source!.VisionFlipType);
        RefreshOffsetEligibility(); Notify();
    }
    public void RefreshFeedback()
    {
        if (ReadFeedback is null) return;
        var values = ReadFeedback();
        Camera.UpdateFeedback(values.StageY, values.ReviewX, values.Mode);
        if ((StageY, ReviewX, Mode) == values) return;
        StageY = values.StageY; ReviewX = values.ReviewX; Mode = values.Mode; Notify();
    }
    public void ResizePreview(double width, double height)
    {
        if (!double.IsFinite(width) || !double.IsFinite(height) || width < 1 || height < 1 || Math.Abs(width - _width) < 0.5 && Math.Abs(height - _height) < 0.5) return;
        _width = width; _height = height; Layout(); Notify();
    }
    private void Layout()
    {
        const double margin = 16, spacing = 19, columnStep = 34;
        PreviewWidth = Math.Max(300, _width);
        var largestSide = Math.Max(Lines.Count(line => line.LeftToRight), Lines.Count(line => !line.LeftToRight));
        var capacity = Math.Max(1, (int)((_height - 2 * margin) / spacing));
        var maxColumns = Math.Max(1, (int)((PreviewWidth - 150 - 2 * margin) / (2 * columnStep)));
        var columns = Math.Clamp((largestSide + capacity - 1) / capacity, 1, maxColumns);
        PreviewHeight = Math.Max(_height, Math.Ceiling(largestSide / (double)columns) * spacing + 2 * margin);
        capacity = Math.Max(1, (int)((PreviewHeight - 2 * margin) / spacing));
        int Columns(bool side) => Math.Min(columns, (Lines.Count(line => line.LeftToRight == side) + capacity - 1) / capacity);
        var leftGutter = 20 + Columns(true) * columnStep;
        var rightGutter = 20 + Columns(false) * columnStep;
        var availableWidth = PreviewWidth - leftGutter - rightGutter;
        var scale = Math.Min(availableWidth / _sourceFrame.Width, (PreviewHeight - 2 * margin) / _sourceFrame.Height);
        var left = leftGutter + (availableWidth - _sourceFrame.Width * scale) / 2;
        var top = (PreviewHeight - _sourceFrame.Height * scale) / 2;
        var transform = new MatrixTransform(scale, 0, 0, scale, left - _sourceFrame.CanvasLeft * scale, top - _sourceFrame.CanvasTop * scale);
        transform.Freeze(); PreviewTransform = transform;
        GlassBounds = transform.TransformBounds(new Rect(_sourceFrame.CanvasLeft, _sourceFrame.CanvasTop, _sourceFrame.Width, _sourceFrame.Height));
        Camera.Configure(_parameters, GlassBounds);
        var physicalScale = GlassBounds.Width / Read("GLASS_SIZE_X", 925);
        Point Project(double x, double y) => new(GlassBounds.Left + x * physicalScale, GlassBounds.Top + y * physicalScale);
        Cells = _sourceCells.Select(cell => new ST_FINE_CELL_VISUAL(cell.CellNo,
            CRecipeModelPixelCountReader.ReadCellModelType(_parameters, cell.CellNo), transform.TransformBounds(cell.CellBounds))).ToArray();
        var visuals = new List<ST_FINE_LINE_VISUAL>();
        foreach (var side in new[] { true, false })
        {
            var lines = Lines.Where(line => line.LeftToRight == side).OrderBy(line => line.DesignY).ThenBy(line => line.OrderNo).ToArray();
            var sideColumns = Columns(side);
            if (sideColumns == 0) continue;
            var rows = (lines.Length + sideColumns - 1) / sideColumns;
            var centers = Enumerable.Range(0, rows).Select(row => lines.Skip(row * sideColumns).Take(sideColumns)
                .Average(line => Project(0, line.DesignY).Y)).ToArray();
            for (var i = 0; i < centers.Length; i++) centers[i] = Math.Max(Math.Clamp(centers[i], margin, PreviewHeight - margin), i == 0 ? margin : centers[i - 1] + spacing);
            for (var i = centers.Length - 1; i >= 0; i--) centers[i] = Math.Min(centers[i], i == centers.Length - 1 ? PreviewHeight - margin : centers[i + 1] - spacing);
            for (var i = 0; i < lines.Length; i++)
            {
                var line = lines[i]; var start = Project(line.Points[0].DesignX, line.DesignY); var end = Project(line.Points[^1].DesignX, line.DesignY);
                if (Math.Abs(start.X - end.X) < 5) { start.X += side ? -3 : 3; end.X += side ? 3 : -3; }
                var column = i % sideColumns;
                var center = centers[i / sideColumns];
                var badgeX = side ? GlassBounds.Left - 42 - column * columnStep : GlassBounds.Right + 14 + column * columnStep;
                var leaderEdge = badgeX + (side ? 28 : 0);
                var elbow = side ? GlassBounds.Left - 6 - column * 2 : GlassBounds.Right + 6 + column * 2;
                var approach = leaderEdge + (side ? 3 : -3);
                var busY = center - 11;
                var arrowX = start.X + (end.X - start.X) * 0.6;
                var direction = side ? 1 : -1;
                visuals.Add(new(line, Points(start, end), Points(new(arrowX - direction * 5, start.Y - 3), new(arrowX, start.Y), new(arrowX - direction * 5, start.Y + 3)),
                    Points(start, new(elbow, start.Y), new(elbow, busY), new(approach, busY), new(approach, center), new(leaderEdge, center)), badgeX, center - 8));
            }
        }
        LineVisuals = visuals.OrderBy(visual => visual.Line.OrderNo).ToArray();
        Connections = LineVisuals.Zip(LineVisuals.Skip(1), (previous, next) =>
        {
            var end = previous.Segment[^1]; var start = next.Segment[0];
            var sideX = previous.Line.LeftToRight ? GlassBounds.Right + 8 : GlassBounds.Left - 8;
            return Points(end, new(sideX, end.Y), new(sideX, start.Y), start);
        }).ToArray();
        RefreshMonitorMarkers();
    }
    private static PointCollection Points(params Point[] points) { var result = new PointCollection(points); result.Freeze(); return result; }
    private double Read(string key, double fallback) => double.TryParse(_parameters.GetValueOrDefault(key), NumberStyles.Float, CultureInfo.InvariantCulture, out var value) && double.IsFinite(value) && value > 0 ? value : fallback;
    private void Notify() { PropertyChanged?.Invoke(this, new(null)); SelectLineCountCommand.NotifyCanExecuteChanged(); SelectMethodCommand.NotifyCanExecuteChanged(); ActionCommand.NotifyCanExecuteChanged(); }
}

public sealed record ST_FINE_LINE_VISUAL(CFineInspectionLine Line, PointCollection Segment, PointCollection Arrow,
    PointCollection Leader, double BadgeX, double BadgeY);
public sealed record ST_FINE_CELL_VISUAL(int CellNo, int ModelNo, Rect Bounds)
{
    public string Tooltip => $"Cell{CellNo:00} / MODEL {ModelNo}";
}
