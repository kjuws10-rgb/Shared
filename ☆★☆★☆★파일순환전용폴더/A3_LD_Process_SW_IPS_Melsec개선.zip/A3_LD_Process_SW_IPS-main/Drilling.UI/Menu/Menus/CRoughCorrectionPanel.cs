using System.ComponentModel;
using System.Globalization;
using System.Windows.Media;
using Drilling.Common.Interface;
using Drilling.Common.Managers;
using Drilling.Common.Recipe;
using Drilling.Common.Review;

namespace Drilling.UI.Menu.Menus;

/// <summary>ROUGH screen state. Receives sequence snapshots; never polls hardware or reads files.</summary>
public sealed class CRoughCorrectionPanel(CSimpleCorrectionPanel owner) : INotifyPropertyChanged
{
    private ST_RECIPE_DEFINITION? _recipe;
    private IReadOnlyDictionary<string, string> _parameters = new Dictionary<string, string>();
    private string _targetSignature = "";
    private int _sourceVersion;
    private int _selectedBeam = 1;
    private ST_SIMPLE_CORRECTION_FIRST_SHOT[] _references = [];
    private ST_SIMPLE_CORRECTION_SHOT[] _assigned = [];
    public event PropertyChangedEventHandler? PropertyChanged;
    public event Action? SourceInvalidated;
    public Func<(string StageY, string ReviewX, string Mode)>? ReadFeedback { get; set; }
    public IReadOnlyList<CRoughCorrectionRow> Rows { get; private set; } = [];
    public IReadOnlyList<int> BeamNumbers { get; private set; } = [];
    public bool IsRunning { get; private set; }
    public int SourceVersion => _sourceVersion;
    public string StageY { get; private set; } = "-";
    public string ReviewX { get; private set; } = "-";
    public string Mode { get; private set; } = "OFFLINE";
    public string Status { get; private set; } = "검사 대기";
    public int SelectedBeam
    {
        get => _selectedBeam;
        set
        {
            if (IsRunning || owner.IsOffsetOperationRunning || !BeamNumbers.Contains(value) || value == _selectedBeam) return;
            _selectedBeam = value;
            SyncTargets(_references, _assigned, _parameters);
            owner.RefreshInspectionDisplay();
        }
    }
    public bool CanConfigure => !IsRunning && !owner.IsOffsetOperationRunning;
    public string Summary => $"{Rows.Count} Shots / OK {Rows.Count(row => row.Point.State == EN_REVIEW_POINT_STATE.Ok)} / NG {Rows.Count(row => row.Point.State == EN_REVIEW_POINT_STATE.Ng)}";
    public bool CanExecute(string action) => action switch
    {
        "REVIEW_STOP" => IsRunning,
        "REVIEW_START" => CanConfigure && Rows.Count > 0,
        "NG_RETRY" => CanConfigure && Rows.Any(row => row.Point.State == EN_REVIEW_POINT_STATE.Ng),
        "OFFSET_APPLY" => CanConfigure && Rows.Any(row => row.Point.State == EN_REVIEW_POINT_STATE.Ok && !row.Applied),
        "OFFSET_INIT" => CanConfigure && _assigned.Length > 0 && Rows.Count > 0,
        "OFFSET_VIEW" => CanConfigure && _recipe is not null,
        _ => false
    };

    public void UpdateSource(ST_RECIPE_DEFINITION recipe, IReadOnlyDictionary<string, string> parameters)
    {
        var source = SourceMap(parameters);
        var previous = SourceMap(_parameters);
        if (_recipe?.Id != recipe.Id || previous.Count != source.Count || previous.Any(item => source.GetValueOrDefault(item.Key) != item.Value))
        {
            _sourceVersion++;
            SourceInvalidated?.Invoke();
            _targetSignature = "";
            Rows = [];
        }
        _recipe = recipe;
        _parameters = parameters;
        var split = int.TryParse(parameters.GetValueOrDefault("SPLITED_BEAM_COUNT"), out var count) ? count : 0;
        BeamNumbers = Enumerable.Range(1, Math.Max(0, split * split)).ToArray();
        if (!BeamNumbers.Contains(_selectedBeam)) _selectedBeam = BeamNumbers.FirstOrDefault();
        RefreshFeedback();
    }

    public void Clear()
    {
        _sourceVersion++; SourceInvalidated?.Invoke(); _recipe = null; _targetSignature = "";
        _references = []; _assigned = []; Rows = []; BeamNumbers = []; Status = "현재 레시피를 선택해 주세요."; Notify();
    }

    public void SyncTargets(IReadOnlyList<ST_SIMPLE_CORRECTION_FIRST_SHOT> references,
        IReadOnlyList<ST_SIMPLE_CORRECTION_SHOT> assigned, IReadOnlyDictionary<string, string> parameters)
    {
        _references = references.ToArray(); _assigned = assigned.ToArray(); _parameters = parameters;
        var signature = $"{_sourceVersion}/{owner.SelectedHeadNo}/{owner.IsHeadScope}/{_selectedBeam}/" + string.Join("|", references.Select(row => row.ShotKey));
        if (_targetSignature == signature)
        {
            foreach (var row in Rows) row.SetCurrent(ReadDesignOffset(row.Point.CellNo, row.ShotName));
            return;
        }
        _targetSignature = signature;
        if (_recipe is null || _selectedBeam < 1) { Rows = []; Notify(); return; }
        var byKey = assigned.ToDictionary(shot => shot.Key, StringComparer.OrdinalIgnoreCase);
        var points = new List<ST_REVIEW_PLAN_POINT>();
        var direction = CScannerAxisTransform.ReadStageDirection(parameters);
        foreach (var reference in references.Where(row => row.ShotKey.Length > 0))
        {
            var shot = byKey[reference.ShotKey];
            var point = new ST_REVIEW_PLAN_POINT(points.Count + 1, shot.Key, shot.HeadNo, shot.CellNo, shot.CellShotNo,
                shot.GroupCountX, shot.GroupCountY, true, shot.DesignX, shot.DesignY, 0, 0, 0, 0, EN_REVIEW_POINT_STATE.Ready, "WAIT") { BeamNo = _selectedBeam };
            var position = CReviewManager.GetShotBeamPositions(_recipe, point, direction).Single(beam => beam.BeamNo == _selectedBeam);
            points.Add(point with { ReviewTargetX = position.ReviewX, ReviewTargetY = position.StageY });
        }
        Rows = CReviewManager.OrderRoughTargets(points).Select((point, index) =>
            new CRoughCorrectionRow(point with { PointNo = index + 1 }, byKey[point.ShotKey].Name, DeltaToDesign)).ToArray();
        foreach (var row in Rows) row.SetCurrent(ReadDesignOffset(row.Point.CellNo, row.ShotName));
        Status = "검사 대기"; Notify();
    }

    public ST_REVIEW_PLAN CreatePlan()
    {
        if (_recipe is null || Rows.Count == 0) throw new InvalidOperationException("검사 대상 Shot이 없습니다.");
        var vision = CReviewCoordinateTransformer.ParseVisionFlipType(_parameters.GetValueOrDefault("VisionXFlip"), _parameters.GetValueOrDefault("VisionYFlip"), _parameters.GetValueOrDefault("VisionXyFlip"));
        return new(_recipe.Id, Rows.Select(row => row.Point.CellNo).Distinct().Count(), ReadTolerance("REVIEW_TOLERANCE_X"),
            ReadTolerance("REVIEW_TOLERANCE_Y"), vision, DateTimeOffset.Now, Rows.Select(row => row.Point).ToArray())
        {
            CorrectionPlan = new(EN_REVIEW_CORRECTION_RULE.Rough,
                owner.IsHeadScope ? EN_REVIEW_CORRECTION_SCOPE.Head : EN_REVIEW_CORRECTION_SCOPE.HeadCell,
                Rows.Select(row => row.Point).ToArray())
        };
    }

    public void Begin(bool retry)
    {
        IsRunning = true;
        if (!retry) foreach (var row in Rows) { row.Applied = false; row.Update(row.Point with { State = EN_REVIEW_POINT_STATE.Ready, Judge = "WAIT", ErrorX = 0, ErrorY = 0 }); }
        Notify();
    }
    public void ApplyProgress(ST_ROUGH_REVIEW_SNAPSHOT snapshot, int version)
    {
        if (version != _sourceVersion || snapshot.RecipeId != _recipe?.Id) return;
        var points = snapshot.Points.ToDictionary(point => point.ShotKey, StringComparer.OrdinalIgnoreCase);
        foreach (var row in Rows) if (points.TryGetValue(row.Point.ShotKey, out var point)) row.Update(point);
        Status = snapshot.Message; RefreshFeedback(); Notify(); owner.RefreshInspectionDisplay();
    }
    public void End() { IsRunning = false; Notify(); owner.RefreshInspectionDisplay(); }
    public void RefreshCommands() { Notify(); owner.OffsetActionCommand.NotifyCanExecuteChanged(); }
    public CRoughCorrectionRow? FindRow(string key) => Rows.FirstOrDefault(row => row.Point.ShotKey.Equals(key, StringComparison.OrdinalIgnoreCase));
    public void RefreshFeedback()
    {
        if (ReadFeedback is null) return;
        var feedback = ReadFeedback();
        owner.Camera.UpdateFeedback(feedback.StageY, feedback.ReviewX, feedback.Mode);
        if ((StageY, ReviewX, Mode) == feedback) return;
        StageY = feedback.StageY; ReviewX = feedback.ReviewX; Mode = feedback.Mode; Notify();
    }

    public ST_SIMPLE_OFFSET_CHANGE CreateOffsetRequest(bool initialize)
    {
        if (_recipe is null || Rows.Count == 0) throw new InvalidOperationException("Offset 대상이 없습니다.");
        var rows = _assigned.Select(shot => new ST_REVIEW_OFFSET_ROW(shot.CellNo, shot.Name, 0, 0) { IsDesignCoordinate = true }).ToArray();
        return new(_recipe.Id, owner.SelectedHeadNo, 0, 0, 0, rows, SourceMap(_parameters));
    }
    public (double X, double Y) IncrementForCell(int cellNo)
    {
        var row = owner.IsHeadScope ? Rows.FirstOrDefault() : Rows.FirstOrDefault(item => item.Point.CellNo == cellNo);
        return row is { Applied: false, Point.State: EN_REVIEW_POINT_STATE.Ok } ? row.DesignDelta : (0, 0);
    }
    public void MarkApplied(bool initialize)
    {
        foreach (var row in Rows)
        {
            if (row.Point.State == EN_REVIEW_POINT_STATE.Ok) row.Applied = true;
            if (initialize) { row.Applied = false; row.Update(row.Point with { State = EN_REVIEW_POINT_STATE.Ready, Judge = "WAIT", ErrorX = 0, ErrorY = 0 }); }
        }
        Notify(); owner.RefreshInspectionDisplay();
    }

    private (double X, double Y) ReadDesignOffset(int cellNo, string shot)
    {
        var prefix = $"CELL{cellNo}_{shot}_REVIEW_OFFSET_";
        double Read(string axis) => double.TryParse(_parameters.GetValueOrDefault(prefix + axis, "0"), NumberStyles.Float, CultureInfo.InvariantCulture, out var value) ? value : 0;
        return CReviewOffsetData.ToDesign(_parameters, owner.SelectedHeadNo, Read("X"), Read("Y"), CReviewOffsetData.IsDesignCoordinate(_parameters, prefix));
    }
    private (double X, double Y) DeltaToDesign(ST_REVIEW_PLAN_POINT point)
    {
        var plan = CreatePlan();
        // Vision Flip defines the received camera error in design coordinates.
        // Stage direction and Head flips belong to the later script conversion.
        var design = CReviewCoordinateTransformer.VisionErrorToStageOffset(point.ErrorX, point.ErrorY, plan.VisionFlipType);
        return (Round(design.X), Round(design.Y));
    }
    private double ReadTolerance(string key) => double.TryParse(_parameters.GetValueOrDefault(key, "0.03"), NumberStyles.Float, CultureInfo.InvariantCulture, out var value) && double.IsFinite(value) && value >= 0 ? value : throw new InvalidOperationException($"{key}를 확인해 주세요.");
    private static Dictionary<string, string> SourceMap(IReadOnlyDictionary<string, string> values) => values.Where(item => !item.Key.Contains("REVIEW_OFFSET", StringComparison.OrdinalIgnoreCase)).ToDictionary(item => item.Key, item => item.Value, StringComparer.OrdinalIgnoreCase);
    internal static double Round(double value) => Math.Round(value, 3, MidpointRounding.AwayFromZero);
    private void Notify() => PropertyChanged?.Invoke(this, new(null));
}

public sealed class CRoughCorrectionRow(ST_REVIEW_PLAN_POINT point, string shotName,
    Func<ST_REVIEW_PLAN_POINT, (double X, double Y)> toDesign) : INotifyPropertyChanged
{
    public event PropertyChangedEventHandler? PropertyChanged;
    public ST_REVIEW_PLAN_POINT Point { get; private set; } = point;
    public string ShotName { get; } = shotName;
    public string Title => $"{Point.PointNo}. Cell{Point.CellNo:00}-{ShotName}";
    public string ReviewX => Point.ReviewTargetX.ToString("0.000", CultureInfo.InvariantCulture);
    public string StageY => Point.ReviewTargetY.ToString("0.000", CultureInfo.InvariantCulture);
    public string CurrentX { get; private set; } = "0.000";
    public string CurrentY { get; private set; } = "0.000";
    public bool Applied { get; set; }
    public (double X, double Y) DesignDelta => Point.State is EN_REVIEW_POINT_STATE.Ok or EN_REVIEW_POINT_STATE.Ng ? toDesign(Point) : (0, 0);
    public string DeltaX => Point.State is EN_REVIEW_POINT_STATE.Ok or EN_REVIEW_POINT_STATE.Ng ? CRoughCorrectionPanel.Round(Point.ErrorX).ToString("0.000", CultureInfo.InvariantCulture) : "-";
    public string DeltaY => Point.State is EN_REVIEW_POINT_STATE.Ok or EN_REVIEW_POINT_STATE.Ng ? CRoughCorrectionPanel.Round(Point.ErrorY).ToString("0.000", CultureInfo.InvariantCulture) : "-";
    public string ConvertedX => Point.State is EN_REVIEW_POINT_STATE.Ok or EN_REVIEW_POINT_STATE.Ng ? DesignDelta.X.ToString("0.000", CultureInfo.InvariantCulture) : "-";
    public string ConvertedY => Point.State is EN_REVIEW_POINT_STATE.Ok or EN_REVIEW_POINT_STATE.Ng ? DesignDelta.Y.ToString("0.000", CultureInfo.InvariantCulture) : "-";
    public string State => Point.State switch { EN_REVIEW_POINT_STATE.Current => "RUNNING", EN_REVIEW_POINT_STATE.Ok => "OK", EN_REVIEW_POINT_STATE.Ng => "NG", _ => Point.Judge == "ERROR" ? "ERROR" : "WAIT" };
    public Brush StateBrush => State switch { "OK" or "RUNNING" => Brushes.SeaGreen, "NG" or "ERROR" => Brushes.Firebrick, _ => Brushes.DarkGoldenrod };
    public void Update(ST_REVIEW_PLAN_POINT point) { Point = point; Notify(); }
    public void SetCurrent((double X, double Y) value)
    {
        var x = value.X.ToString("0.000", CultureInfo.InvariantCulture); var y = value.Y.ToString("0.000", CultureInfo.InvariantCulture);
        if (CurrentX == x && CurrentY == y) return;
        CurrentX = x; CurrentY = y; Notify();
    }
    private void Notify() => PropertyChanged?.Invoke(this, new(null));
}
