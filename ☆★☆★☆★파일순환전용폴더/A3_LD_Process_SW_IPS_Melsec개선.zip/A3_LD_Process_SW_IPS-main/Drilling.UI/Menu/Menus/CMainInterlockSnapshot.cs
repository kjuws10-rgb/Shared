using Drilling.Common.InterLock;
using InterlockItem = Drilling.Common.InterLock.ST_INTERLOCK_ITEM;

namespace Drilling.UI.Menu.Menus;

/// <summary>Keeps the display independent of the process snapshot cleared by RESET/PrepareProcess.</summary>
public sealed class CMainInterlockSnapshot
{
    private IReadOnlyList<InterlockItem> _lastSuccessful = [];

    public IReadOnlyList<InterlockItem> Read(Func<IReadOnlyList<InterlockItem>> read,
        IReadOnlyList<InterlockItem> processFallback)
    {
        try
        {
            var current = read().ToArray();
            _lastSuccessful = current;
            return current;
        }
        catch (Exception exception) when (exception is not OperationCanceledException)
        {
            var previous = _lastSuccessful.Count > 0 ? _lastSuccessful : processFallback;
            if (previous.Count == 0)
                return [new("Interlock Refresh", EN_INTERLOCK_LEVEL.Error, "READ FAIL", exception.Message) { BlocksAutoRun = true }];

            // Retain every known check, but never present a previous OK as a current reading.
            return previous.Select(item => item with
            {
                Level = EN_INTERLOCK_LEVEL.Error,
                State = "READ FAIL",
                Detail = $"현재 상태를 확인할 수 없습니다. {exception.Message}",
                BlocksAutoRun = true
            }).ToArray();
        }
    }
}
