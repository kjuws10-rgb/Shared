using System.Globalization;
using System.IO;
using Drilling.Common.Managers;
using Drilling.Common.Station;
using Drilling.UI.Popup;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuManual
{
    private CManualShapeScanRun? _activeManualLaserAction;
    private bool _manualLaserOffInProgress;
    private bool _manualLaserOffUnconfirmed;
    private IReadOnlyList<ST_MANUAL_LASER_OFF_TARGET> _manualLaserOffPendingTargets = [];
    private bool IsManualLaserActionActive => _activeManualLaserAction is not null || _manualLaserOffInProgress ||
        _manualLaserOffUnconfirmed || _manualLaserOffPendingTargets is { Count: > 0 };

    private async Task RunSelectedManualLaserActions(bool useCurrentPosition)
    {
        if (IsManualShapeScanActive)
        {
            CRecipeConfirmDialog.ShowWarning("레이저 동작", "수동 가공이 진행 중이거나 정지가 확인되지 않은 Head가 있습니다. LASER OFF로 정지한 후 다시 시도해 주세요.");
            return;
        }
        if (TryBlockManualAutomationCommand("LASER_ON")) return;
        var run = new CManualShapeScanRun();
        _activeManualLaserAction = run;
        try
        {
            var programs = await PrepareManualLaserActionPrograms(run.Cancellation.Token, useCurrentPosition);
            run.Programs = programs;
            if (!CRecipeConfirmDialog.ShowConfirmation("레이저 동작",
                    BuildManualScanConfirmation(programs, shapeScan: false))) return;
            run.Cancellation.Token.ThrowIfCancellationRequested();
            EnsureManualShapeScanAutoStopped();
            _lastCommand = "LASER_ON";
            _lastResult = $"Preparing ATT / {programs.Count} Heads";
            _setStatusMessage($"선택한 {programs.Count}개 Head의 .scan 설정으로 레이저 동작을 준비합니다.");
            RefreshCommandStateRows();
            _refreshShellStatus();
            await ExecuteManualShapeScanPrograms(programs, run.Cancellation.Token);
            _laserState = "OFF";
            _lastResult = $"Completed {programs.Count} Heads";
            _setStatusMessage($"선택한 {programs.Count}개 Head의 레이저 동작이 완료되었습니다.");
        }
        catch (OperationCanceledException)
        {
            _lastResult = "Stopped";
            _setStatusMessage("선택한 Head의 레이저 동작을 정지했습니다.");
        }
        catch (Exception exception) when (exception is InvalidDataException or InvalidOperationException or IOException or TimeoutException or KeyNotFoundException)
        {
            _lastResult = $"ERROR: {exception.Message}";
            _setStatusMessage($"레이저 동작을 완료하지 못했습니다. {exception.Message}");
            CRecipeConfirmDialog.ShowWarning("레이저 동작 실패", exception.Message);
        }
        finally
        {
            _activeManualLaserAction = null;
            run.Completed.TrySetResult();
            run.Cancellation.Dispose();
            RefreshCommandStateRows();
            _refreshShellStatus();
        }
    }

    private async Task<IReadOnlyList<ST_MANUAL_SHAPE_SCAN_PROGRAM>> PrepareManualLaserActionPrograms(CancellationToken cancellationToken, bool useCurrentPosition)
    {
        var options = _manager.Setting().LoadSection(EN_SETTING_TAB.Option, cancellationToken);
        var routes = BuildManualShapeScanRoutes(options, SelectedManualHeadNos);
        var origins = CaptureManualScanOrigins(routes, options, useCurrentPosition);
        var programs = new List<ST_MANUAL_SHAPE_SCAN_PROGRAM>(routes.Count);
        foreach (var route in routes)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (!_manager.automation.IsSimul(route.AutomationNo) && !_manager.automation.IsConnect(route.AutomationNo))
                throw new InvalidOperationException($"CONTROLLER {route.AutomationNo + 1}이 연결되어 있지 않습니다.");
            var settings = await ReadAssignedManualScanParamCore(route.HeadNo, cancellationToken, validateShape: false);
            var script = _scriptFile.Create($"MANUAL_H{route.HeadNo:00}_LASER_ON.ascript");
            script.SetDeviceNo(route.HeadNo - 1);
            script.SetAxis(route.XAxis, route.YAxis);
            AppendManualSettingComment(script, settings);
            script.AddLine($"// Laser Action Mode={settings.LaserOnMode}, OnTime={settings.Time.ToString("R", CultureInfo.InvariantCulture)} msec, ShotCount={settings.Count}");
            script.AddLine($"// Laser Action RepeatCount={settings.RepeatCount}, RepeatDelay={settings.RepeatDelayTime.ToString("R", CultureInfo.InvariantCulture)} msec");
            script.Start($"Manual H{route.HeadNo:00} LASER ON");
            script.LaserOff();
            ApplySavedManualLaserActionSetup(script, settings);
            var position = ResolveManualScanPosition(route, options, settings, origins[route.HeadNo], useCurrentPosition);
            script.AddLine(position.ScriptComment);
            script.Jump(position.TargetX, position.TargetY);
            script.WaitMoveDone();
            AppendSavedManualLaserOnScript(script, settings);
            script.End();
            var saved = script.Save(cancellationToken);
            programs.Add(new(route.HeadNo, route.AutomationNo, route.TaskNo, ScanAssignments.GetSettingName(route.HeadNo),
                settings, saved.FileName, saved.FilePath) { LaserAxis = route.XAxis, Position = position });
        }
        await EnsureManualShapeScanTasksReady(programs, cancellationToken);
        return programs;
    }

    private static void ValidateSavedManualLaserActionSettings(ST_MANUAL_SCAN_PARAM settings)
    {
        if (!double.IsFinite(settings.OffsetX) || !double.IsFinite(settings.OffsetY))
            throw new InvalidDataException("Offset X/Y는 유한한 mm 값이어야 합니다.");
        if (!double.IsFinite(settings.JumpSpeed) || settings.JumpSpeed <= 0 || !double.IsFinite(settings.JumpSpeed * 1000.0))
            throw new InvalidDataException("Jump Speed는 0보다 큰 유한한 이동 속도여야 합니다.");
        if (settings.LaserOnMode is not ("TIME" or "COUNT"))
            throw new InvalidDataException("Laser Action Mode는 TIME 또는 COUNT로 설정해 주세요.");
        if (!double.IsFinite(settings.LaserPower) || settings.LaserPower < 0)
            throw new InvalidDataException("Laser Power는 0 이상의 유한한 W 값이어야 합니다.");
        if (!double.IsFinite(settings.LaserFrequency) || settings.LaserFrequency <= 0)
            throw new InvalidDataException("Laser Frequency는 0보다 큰 유한한 값이어야 합니다.");
        if (!double.IsFinite(settings.LaserOnDelay) || settings.LaserOnDelay < 0 ||
            !double.IsFinite(settings.LaserOffDelay) || settings.LaserOffDelay < 0)
            throw new InvalidDataException("Laser On/Off Delay는 0 이상의 유한한 msec 값이어야 합니다.");
        if (!double.IsFinite(settings.Time) || settings.Time <= 0 || settings.Count < 1)
            throw new InvalidDataException("On Time은 0보다 큰 msec 값, Shot Count는 1 이상의 정수로 설정해 주세요.");
        if (settings.RepeatCount < 1 || !double.IsFinite(settings.RepeatDelayTime) || settings.RepeatDelayTime < 0)
            throw new InvalidDataException("Repeat Count는 1 이상의 정수, Repeat Delay Time은 0 이상의 유한한 msec 값으로 설정해 주세요.");
    }

    private static void ApplySavedManualLaserActionSetup(CAutomation1ScriptBase script, ST_MANUAL_SCAN_PARAM settings)
    {
        script.DefaultSetting(resetPso: false);
        script.SetMoveBlending(false);
        script.SetJumpSpeed(settings.JumpSpeed);
        script.SetLaserDelay(0, 0);
        script.SetFrequency(settings.LaserFrequency);
        // The optical W target is applied with the ATT before any of these scripts start.
        script.SetLaserPowerNoDelay(100);
        script.SetLaserMode(0);
    }

    private static void AppendSavedManualLaserOnScript(CAutomation1ScriptBase script, ST_MANUAL_SCAN_PARAM settings)
    {
        ValidateSavedManualLaserActionSettings(settings);
        var onTime = settings.LaserOnMode == "COUNT" ? (settings.Count + 1.0) / settings.LaserFrequency : settings.Time;
        if (!double.IsFinite(onTime) || onTime <= 0) throw new InvalidDataException("레이저 동작 시간을 계산할 수 없습니다.");
        void Cycle()
        {
            script.SetMoveDelay(settings.LaserOnDelay, applyMinimumDelay: false);
            script.LaserOn();
            script.SetMoveDelay(onTime, applyMinimumDelay: false);
            script.LaserOff();
            script.SetMoveDelay(settings.LaserOffDelay, applyMinimumDelay: false);
        }
        if (settings.RepeatCount > 1)
        {
            script.AddLine($"repeat {settings.RepeatCount - 1}");
            Cycle();
            script.SetMoveDelay(settings.RepeatDelayTime, applyMinimumDelay: false);
            script.AddLine("end");
        }
        Cycle();
    }

    private async Task StopAllManualLasers()
    {
        if (_manualLaserOffInProgress) return;
        _manualLaserOffInProgress = true;
        _manualLaserOffUnconfirmed = true;
        var failures = new List<string>();
        var laser = _activeManualLaserAction;
        var shape = _activeManualShapeScan;
        var originalPrograms = (laser?.Programs ?? []).Concat(shape?.Programs ?? [])
            .Concat(_manualShapeScanPendingStops ?? []).ToArray();
        try
        {
            _lastCommand = "LASER_OFF";
            _lastResult = "Stopping all Heads";
            laser?.Cancellation.Cancel();
            shape?.Cancellation.Cancel();
            CancelStatusPolling();
            if (IsAutoProcessRunning())
            {
                try { _manager.Station().Stop(); }
                catch (Exception exception) { failures.Add($"자동 운전 정지 요청 실패: {exception.Message}"); }
            }
            await Task.WhenAll(new[] { laser?.Completed.Task, shape?.Completed.Task }.OfType<Task>());
            var targets = new List<ST_MANUAL_LASER_OFF_TARGET>();
            try { targets.AddRange(BuildManualLaserOffTargets(_manager.Setting().LoadSection(EN_SETTING_TAB.Option))); }
            catch (Exception exception) { failures.Add($"Head 설정 확인 실패: {exception.Message}"); }
            targets.AddRange(originalPrograms.Where(program => !string.IsNullOrWhiteSpace(program.LaserAxis))
                .Select(program => new ST_MANUAL_LASER_OFF_TARGET(program.HeadNo, program.AutomationNo, program.TaskNo, program.LaserAxis)));
            targets.AddRange((_manualLaserOffPendingTargets ?? []).Where(pending =>
                string.IsNullOrWhiteSpace(pending.ConfigurationError) || !targets.Any(target => target.HeadNo == pending.HeadNo && string.IsNullOrWhiteSpace(target.ConfigurationError))));
            failures.AddRange(await ForceManualLasersOff(targets.Distinct().ToArray(), CancellationToken.None));
            if (_manualShapeScanAttenuatorPositioning?.HasPendingStops == true)
            {
                try { await _manualShapeScanAttenuatorPositioning.StopPendingAsync(); }
                catch (Exception exception) { failures.Add(exception.Message); }
            }
            _manualShapeScanPendingStops = (_manualShapeScanPendingStops ?? []).Where(program =>
                (_manualLaserOffPendingTargets ?? []).Any(target => target.AutomationNo == program.AutomationNo && target.TaskNo == program.TaskNo)).ToArray();
            if (failures.Count > 0)
            {
                _lastResult = "ERROR: LASER OFF";
                _setStatusMessage("일부 Head의 정지 또는 LASER OFF를 확인하지 못했습니다.");
                CRecipeConfirmDialog.ShowWarning("LASER OFF 실패", string.Join("\n", failures));
            }
            else
            {
                _manualLaserOffUnconfirmed = false;
                _laserState = "OFF";
                _centerState = "OFF";
                _lastResult = "All Heads OFF";
                _setStatusMessage("전체 Head의 스크립트를 정지하고 LASER OFF 명령을 완료했습니다.");
            }
        }
        finally
        {
            _manualLaserOffInProgress = false;
            RefreshCommandStateRows();
            _refreshShellStatus();
        }
    }

    private static IReadOnlyList<ST_MANUAL_LASER_OFF_TARGET> BuildManualLaserOffTargets(IReadOnlyList<ST_SYSTEM_PARAMETER> options)
    {
        var enabled = CScannerStatusSnapshotReader.BuildEnabledHeadNumbers(options);
        var targets = new List<ST_MANUAL_LASER_OFF_TARGET>();
        foreach (var head in Enumerable.Range(1, 8))
        {
            var axis = ReadHeadSettingText(options, "", head, "X_AXIS", "GX_AXIS");
            if (string.IsNullOrWhiteSpace(axis) && !enabled.Contains(head)) continue;
            var controller = -1;
            var task = 0;
            try
            {
                controller = ReadManualHeadAutomationNo(options, head);
                task = ReadManualHeadAutomationTaskNo(options, head);
                if (!IsConfiguredScannerAxisName(axis)) throw new InvalidDataException($"HEAD {head:00} X축 설정을 확인해 주세요.");
                targets.Add(new(head, controller, task, axis));
            }
            catch (Exception exception) when (exception is InvalidDataException or InvalidOperationException)
            {
                targets.Add(new(head, controller, task, axis) { ConfigurationError = exception.Message });
            }
        }
        return targets;
    }

    private async Task<IReadOnlyList<string>> ForceManualLasersOff(IReadOnlyList<ST_MANUAL_LASER_OFF_TARGET> targets, CancellationToken cancellationToken)
    {
        var failures = new List<string>();
        var pending = new HashSet<ST_MANUAL_LASER_OFF_TARGET>();
        var available = new List<ST_MANUAL_LASER_OFF_TARGET>();
        var stoppable = new List<ST_MANUAL_LASER_OFF_TARGET>();
        foreach (var target in targets)
        {
            var validAxis = string.IsNullOrWhiteSpace(target.ConfigurationError) && IsConfiguredScannerAxisName(target.LaserAxis);
            if (!validAxis || target.AutomationNo < 0 || target.TaskNo < 1)
            {
                pending.Add(target);
                failures.Add($"HEAD {target.HeadNo:00}: {target.ConfigurationError} LASER OFF 축/Task 설정을 확인해 주세요.");
            }
            if (target.AutomationNo < 0 || target.TaskNo < 1) continue;
            if (!_manager.automation.IsSimul(target.AutomationNo) && !_manager.automation.IsConnect(target.AutomationNo))
            {
                pending.Add(target);
                failures.Add($"HEAD {target.HeadNo:00}: CONTROLLER {target.AutomationNo + 1} 미연결로 LASER OFF를 확인할 수 없습니다.");
            }
            else
            {
                stoppable.Add(target);
                if (validAxis) available.Add(target);
            }
        }
        // Stop every producer of laser commands before issuing the final OFF commands.
        foreach (var group in stoppable.GroupBy(target => (target.AutomationNo, target.TaskNo)))
        {
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            timeout.CancelAfter(TimeSpan.FromSeconds(5));
            try
            {
                var response = await _manager.automation.StopTask(group.Key.TaskNo, group.Key.AutomationNo, timeout.Token);
                EnsureAutomationResponse(response, "LASER OFF task stop");
                await WaitManualTaskCompleted(response, false, group.Key.AutomationNo, group.Key.TaskNo, timeout.Token);
            }
            catch (Exception exception)
            {
                foreach (var target in group) pending.Add(target);
                failures.Add($"CONTROLLER {group.Key.AutomationNo + 1} / Task {group.Key.TaskNo} 정지 실패: {exception.Message}");
            }
        }
        foreach (var group in available.GroupBy(target => (target.AutomationNo, Axis: target.LaserAxis.ToUpperInvariant())))
        {
            var target = group.First();
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            timeout.CancelAfter(TimeSpan.FromSeconds(5));
            try
            {
                var response = await _manager.automation.SetGalvoLaserOutput(target.LaserAxis, false, target.TaskNo, target.AutomationNo, timeout.Token);
                EnsureAutomationResponse(response, $"HEAD {target.HeadNo:00} LASER OFF");
            }
            catch (Exception exception)
            {
                foreach (var failed in group) pending.Add(failed);
                failures.Add($"HEAD {target.HeadNo:00} LASER OFF 실패: {exception.Message}");
            }
        }
        _manualLaserOffPendingTargets = pending.ToArray();
        return failures;
    }

    private sealed record ST_MANUAL_LASER_OFF_TARGET(int HeadNo, int AutomationNo, int TaskNo, string LaserAxis)
    {
        public string ConfigurationError { get; init; } = "";
    }
}
