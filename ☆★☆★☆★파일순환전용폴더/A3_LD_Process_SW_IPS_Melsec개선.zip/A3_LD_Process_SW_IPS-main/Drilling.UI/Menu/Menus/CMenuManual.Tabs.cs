﻿namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuManual
{
    private string _manualControlTab = "CONTROLLER";

    public CButtonCommand SelectManualControlTabCommand { get; }
    public bool IsManualControllerTab => _manualControlTab == "CONTROLLER";
    public bool IsManualMotionTab => _manualControlTab == "MOTION";
    public bool IsManualScanTab => _manualControlTab == "SCAN";
    public bool IsManualPowerMeasureTab => _manualControlTab == "POWERMEASURE";
    public bool IsManualMofTab => _manualControlTab == "MOF";
    public bool IsManualStageReviewTab => IsManualScanTab || IsManualPowerMeasureTab || IsManualMofTab;

    private void SelectManualControlTab(object? parameter)
    {
        var tab = parameter?.ToString()?.Trim().ToUpperInvariant();
        if (tab is not ("CONTROLLER" or "MOTION" or "SCAN" or "POWERMEASURE" or "MOF") || tab == _manualControlTab) return;
        _manualControlTab = tab;
        if (tab != "MOTION") _ = StopMotionJog();
        if (!IsManualStageReviewTab) _powerMeasurePanel?.StageMotion.SetActive(false);
        _homeSpeedPanel?.SetActive(_homeSpeedController.HasValue && IsManualControllerTab && IsScannerWorkspace);
        OnPropertyChanged(nameof(IsManualControllerTab));
        OnPropertyChanged(nameof(IsManualMotionTab));
        OnPropertyChanged(nameof(IsManualScanTab));
        OnPropertyChanged(nameof(IsManualPowerMeasureTab));
        OnPropertyChanged(nameof(IsManualStageReviewTab));
        OnPropertyChanged(nameof(IsManualMofTab));
        if (IsManualPowerMeasureTab) PowerMeasurePanel.UpdateHeads(SelectedManualHeadNos);
        if (IsScannerWorkspace && (IsManualScanTab || IsManualMofTab)) RefreshAutomationStatusSnapshot();
    }
}
