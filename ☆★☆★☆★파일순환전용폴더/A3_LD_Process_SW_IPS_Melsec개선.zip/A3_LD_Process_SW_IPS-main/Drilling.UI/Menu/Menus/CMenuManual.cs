﻿using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Media;
using Drilling.Common.Automation;
using Drilling.Common.Interface;
using Drilling.Common.Interface.Vision;
using Drilling.Common.Managers;
using Drilling.Common.Station;
using Drilling.UI.Menu;
using Drilling.UI.Popup;

namespace Drilling.UI.Menu.Menus;
public sealed partial class CMenuManual : CMenuBase
{
    public CManualMofPreviewPanel MofPreview { get; } = new();

    private const int ManualTaskIndex = 1;
    private const int SettingFilesPageSize = 3;
    private const int UnconfiguredScannerDioNo = -1;
    private static readonly TimeSpan ResetSequenceResetTimeout = TimeSpan.FromSeconds(10);
    private static readonly TimeSpan ResetSequenceEnableTimeout = TimeSpan.FromSeconds(10);
    private static readonly TimeSpan ResetSequenceHomeTimeout = TimeSpan.FromSeconds(60);
    private static readonly TimeSpan ResetSequenceDioTimeout = TimeSpan.FromSeconds(5);
    private static readonly TimeSpan ResetSequenceCommandTimeout = TimeSpan.FromSeconds(5);
    private static readonly TimeSpan ResetSequencePollInterval = TimeSpan.FromMilliseconds(500);
    private readonly CManager _manager;
    private readonly CManualScanFileBase _scanFile;
    private readonly CAutomationScriptFileBase _scriptFile;
    private readonly CManualScannerSnapshotReader _scannerStatusSnapshotReader;
    private readonly CManualStageMotionPollingService _stageMotionPollingService;
    private readonly Func<int> _selectedHeadNoProvider;
    private readonly Func<string> _selectedRecipeIdProvider;
    private readonly Func<string> _selectedSettingNameProvider;
    private readonly Action<string> _selectedSettingNameSetter;
    private readonly Action<string> _setStatusMessage;
    private readonly Action _refreshShellStatus;
    private readonly Func<Task> _refreshCurrentScreen;
    private readonly object _menuLifetimeSync = new();
    private CancellationTokenSource _menuLifetimeCancellation = new();
    private CancellationTokenSource? _statusPollingCancellation;
    private string _targetGx = "";
    private string _targetGy = "";
    private string _targetGz = "";
    private int _lastBuiltHeadNo;
    private string _laserState = "OFF";
    private string _centerState = "OFF";
    private string _lastCommand = "-";
    private string _lastResult = "Ready";
    private int? _lastManualScriptAutomationNo;
    private string _lastLoadedSettingName = "";
    private string _lastSettingListSelectedName = "";
    private string _settingFilesPageText = "PAGE 0 / 0";
    private int _settingFilesPageIndex;
    private int _settingFilesPageCount;
    private IReadOnlyList<ST_SYSTEM_PARAMETER> _manualScannerOptionSettings = [];
    private IReadOnlyList<ST_MANUAL_HEAD_GROUP> _headGroups = [];
    private IReadOnlyList<ST_MANUAL_SETTING_FILE> _settingFiles = [];
    private string _shapeSize = "10.000";
    private string _shapeOffsetX = "0.000";
    private string _shapeOffsetY = "0.000";
    private string _shapeDirection = "CW";
    private string _shapeName = "Circle";
    private string _gridRowLines = "5";
    private string _gridColLines = "5";
    private string _laserOnMode = "TIME";
    private string _laserOnTimeMsec = "1000";
    private string _laserShotCount = "1";
    private string _laserRepeatCount = "1";
    private string _laserRepeatDelayTimeMsec = "0";
    private string _laserActionPower = "1.00";
    private string _laserActionFrequency = "20.000";
    private string _dioAddress = "";
    private string _dioAxisName = "-";
    private string _dioNo = "-";
    private string _dioCurrentValue = "UNKNOWN";
    private string _dioLastResult = "Ready";
    private int _dioAutomationNo;
    private long _dioGeneration;
    private IReadOnlyList<ST_MANUAL_SCANNER_AXIS> _scannerAxes = [];
    private bool _hasScannerTargetSnapshot;
    private bool _isDioTargetReady;
    private bool _isDioControlBusy;
    private bool _isScannerWorkspace = true;
    private bool _isReviewWorkspace;
    public CMenuReview? Review { get; private set; }
    public bool IsReviewWorkspace => _isReviewWorkspace;
    public void ConfigureReview(CMenuReview review) => Review = review;
    private ST_MANUAL_STAGE_AXIS _selectedStageAxis = null!;
    private ST_MANUAL_VISION_PROTOCOL_COMMAND _selectedVisionProtocolCommand = null!;
    private string _visionProtocolInspectionType = "0";
    private string _visionProtocolEndpoint = "-";
    private string _visionProtocolStatus = "NOT CONFIGURED";
    private string _visionProtocolKeepAlive = "WAITING";
    private bool _isVisionProtocolBusy;
    public CMenuManual(CManager manager, CManualScanFileBase scanFile, CAutomationScriptFileBase scriptFile, Func<int> selectedHeadNoProvider, Func<string> selectedRecipeIdProvider, Func<string> selectedSettingNameProvider, Action<string> selectedSettingNameSetter, CButtonCommand selectHeadCommand, Action<string> setStatusMessage, Action refreshShellStatus, Func<Task> refreshCurrentScreen, Func<(double X, double Y)>? manualMofShiftOffsetProvider = null)
    {
        _manager = manager;
        _manualMofShiftOffsetProvider = manualMofShiftOffsetProvider ?? (() => (0, 0));
        _scanFile = scanFile;
        _scriptFile = scriptFile;
        _scannerStatusSnapshotReader = new CManualScannerSnapshotReader(_manager.Automation());
        _stageMotionPollingService = new CManualStageMotionPollingService(_manager.Interface().Melsec);
        _selectedHeadNoProvider = selectedHeadNoProvider;
        _selectedRecipeIdProvider = selectedRecipeIdProvider;
        _selectedSettingNameProvider = selectedSettingNameProvider;
        _selectedSettingNameSetter = selectedSettingNameSetter;
        _setStatusMessage = setStatusMessage;
        _refreshShellStatus = refreshShellStatus;
        _refreshCurrentScreen = refreshCurrentScreen;
        _manager.Interface().ProtocolTrace += OnVisionProtocolTrace;
        _selectFocusedHeadCommand = selectHeadCommand;
        SelectHeadCommand = new CButtonCommand(ToggleManualHead, parameter => _powerMeasurePanel?.IsRunning != true && _mofRun?.IsBusy != true && selectHeadCommand.CanExecute(parameter));
        SelectManualHeadsCommand = new CButtonCommand(SelectManualHeads, _ => _powerMeasurePanel?.IsRunning != true && _mofRun?.IsBusy != true && selectHeadCommand.CanExecute(null));
        selectHeadCommand.CanExecuteChanged += (_, _) => SelectManualHeadsCommand.NotifyCanExecuteChanged();
        SelectManualControlTabCommand = new CButtonCommand(SelectManualControlTab);
        async void SelectSettingCallback(object? parameter)
        {
            await SelectSetting(parameter);
        }

        SelectSettingCommand = new CButtonCommand(SelectSettingCallback);
        async void ShowPreviousSettingPageCallback(object? arg0)
        {
            await ShowPreviousSettingPage();
        }

        bool CanShowPreviousSettingPageCallback(object? arg0)
        {
            return CanShowPreviousSettingPage();
        }

        PreviousSettingPageCommand = new CButtonCommand(ShowPreviousSettingPageCallback, CanShowPreviousSettingPageCallback);
        async void ShowNextSettingPageCallback(object? arg0)
        {
            await ShowNextSettingPage();
        }

        bool CanShowNextSettingPageCallback(object? arg0)
        {
            return CanShowNextSettingPage();
        }

        NextSettingPageCommand = new CButtonCommand(ShowNextSettingPageCallback, CanShowNextSettingPageCallback);
        async void CreateSettingCallback(object? arg0)
        {
            await Create();
        }

        CreateCommand = new CButtonCommand(CreateSettingCallback);
        async void DeleteSettingCallback(object? arg0)
        {
            await Delete();
        }

        DeleteCommand = new CButtonCommand(DeleteSettingCallback);
        async void RenameSettingCallback(object? arg0)
        {
            await Rename();
        }

        RenameCommand = new CButtonCommand(RenameSettingCallback);
        async void SaveSettingCallback(object? arg0)
        {
            await Save();
        }

        SaveCommand = new CButtonCommand(SaveSettingCallback);
        async void CenterMoveCallback(object? arg0)
        {
            await CenterMove();
        }

        CenterMoveCommand = new CButtonCommand(CenterMoveCallback);
        async void PositionMoveCallback(object? arg0)
        {
            await PositionMove();
        }

        PositionMoveCommand = new CButtonCommand(PositionMoveCallback);
        async void ZPositionMoveCallback(object? arg0)
        {
            await ZPositionMove();
        }

        ZPositionMoveCommand = new CButtonCommand(ZPositionMoveCallback);
        async void MoveStopCallback(object? arg0)
        {
            await MoveStop();
        }

        MoveStopCommand = new CButtonCommand(MoveStopCallback);
        async void SelectShapeCallback(object? parameter)
        {
            await SelectShape(parameter);
        }

        SelectShapeCommand = new CButtonCommand(SelectShapeCallback);
        async void ShapeStartCallback(object? arg0)
        {
            await ShapeStart(string.Equals(arg0?.ToString(), "CURPOS", StringComparison.OrdinalIgnoreCase));
        }

        ShapeStartCommand = new CButtonCommand(ShapeStartCallback);
        async void ShapeStopCallback(object? arg0)
        {
            await ShapeStop();
        }

        ShapeStopCommand = new CButtonCommand(ShapeStopCallback);
        async void LaserOnCallback(object? arg0)
        {
            await LaserOn(string.Equals(arg0?.ToString(), "CURPOS", StringComparison.OrdinalIgnoreCase));
        }

        LaserOnCommand = new CButtonCommand(LaserOnCallback);
        async void LaserOffCallback(object? arg0)
        {
            await LaserOff();
        }

        LaserOffCommand = new CButtonCommand(LaserOffCallback);
        async void CenterOnCallback(object? arg0)
        {
            await CenterOn();
        }

        CenterOnCommand = new CButtonCommand(CenterOnCallback);
        async void DioReadCallback(object? arg0)
        {
            await RefreshDioState();
        }

        DioReadCommand = new CButtonCommand(DioReadCallback);
        async void DioOnCallback(object? arg0)
        {
            await SetDioOutput(true);
        }

        DioOnCommand = new CButtonCommand(DioOnCallback);
        async void DioOffCallback(object? arg0)
        {
            await SetDioOutput(false);
        }

        DioOffCommand = new CButtonCommand(DioOffCallback);
        async void ScannerAxisHomeCallback(object? parameter)
        {
            await HomeScannerAxis(parameter);
        }

        ScannerAxisHomeCommand = new CButtonCommand(ScannerAxisHomeCallback);
        async void ScannerAxisEnableCallback(object? parameter)
        {
            await EnableScannerAxis(parameter);
        }

        ScannerAxisEnableCommand = new CButtonCommand(ScannerAxisEnableCallback);
        async void ScannerAxisDisableCallback(object? parameter)
        {
            await DisableScannerAxis(parameter);
        }

        ScannerAxisDisableCommand = new CButtonCommand(ScannerAxisDisableCallback);
        async void ResetAutomationControllerCallback(object? parameter)
        {
            await ResetAutomationController(parameter);
        }

        ResetAutomationControllerCommand = new CButtonCommand(ResetAutomationControllerCallback);
        async void HomeAutomationControllerAxesCallback(object? parameter)
        {
            await HomeAutomationControllerAxes(parameter);
        }

        HomeAutomationControllerAxesCommand = new CButtonCommand(HomeAutomationControllerAxesCallback);
        async void DisableControllerMofCallback(object? parameter) => await DisableControllerMof(parameter);
        DisableControllerMofCommand = new CButtonCommand(DisableControllerMofCallback);
        ShowResetSequenceCommand = new CButtonCommand(ShowResetSequenceDialog);
        SelectManualWorkspaceCommand = new CButtonCommand(SelectManualWorkspace);
        SelectStageAxisCommand = new CButtonCommand(SelectStageAxis);
        StageAbsMoveCommand = new CButtonCommand(StageAbsMove);
        StageRelMoveCommand = new CButtonCommand(StageRelMove);
        StageHomeCommand = new CButtonCommand(StageHome);
        StageStopCommand = new CButtonCommand(StageStop);
        VisionProtocolCommands =
        [
            new("1000  |  Mark Find Single", "MARK_FIND_SINGLE", "지정한 Shot 1개의 Mark/Hole 위치를 Vision에 요청합니다."),
            new("1001  |  Flying Ready", "FLYING_READY", "Flying 검사 전에 대상 목록을 전달합니다. 필요한 수만큼 Mark 행을 추가하세요."),
            new("1002  |  Flying Move Done", "FLYING_MOVE_DONE", "Flying 이동 완료를 Vision에 알립니다. 입력값이 없습니다."),
            new("1003  |  Mark Find Line", "MARK_FIND_LINE", "한 Line의 Mark 검사 결과를 요청합니다. 입력값이 없습니다."),
            new("1010  |  Mark Find Setting Single", "MARK_FIND_SETTING_SINGLE", "Setup 시 등록된 Single Mark를 확인합니다. 입력값이 없습니다."),
            new("1900  |  Keep-Alive Request", "KEEP_ALIVE_REQUEST", "Vision 연결 확인용 Keep-Alive 요청을 전송합니다. 입력값이 없으며 UID는 0입니다.")
        ];
        _selectedVisionProtocolCommand = VisionProtocolCommands[0];
        async void SendVisionProtocolCallback(object? _)
        {
            await SendVisionProtocolCommand();
        }

        VisionProtocolSendCommand = new CButtonCommand(
            SendVisionProtocolCallback,
            CanSendVisionProtocol);
        VisionProtocolRefreshCommand = new CButtonCommand(RefreshVisionProtocolCallback);
        VisionProtocolClearLogCommand = new CButtonCommand(ClearVisionProtocolLogCallback);
        VisionProtocolAddMarkCommand = new CButtonCommand(
            AddVisionProtocolMarkCallback,
            CanAddVisionProtocolMark);
        VisionProtocolRemoveMarkCommand = new CButtonCommand(
            RemoveVisionProtocolMarkCallback,
            CanRemoveVisionProtocolMark);
        ResetVisionProtocolInputs();
        StageAxes =
        [
            new("STAGE_Y", "STAGE Y", "mm", "EC_SET_ALIGN_STAGE_Y1_POS_READ", "EC_SET_ALIGN_STAGE_Y1_POS_WRITE"),
            new("CAMERA_X", "REVIEW X", "mm", "EC_SET_ALIGN_STAGE_X1_POS_READ", "EC_SET_ALIGN_STAGE_X1_POS_WRITE")
        ];
        SelectedStageAxis = StageAxes[0];
        _stageMotionPollingService.SelectAxes(StageAxes);

        bool CanSendVisionProtocol(object? _)
        {
            return !IsVisionProtocolBusy;
        }

        void RefreshVisionProtocolCallback(object? _)
        {
            RefreshVisionProtocolStatus(writeLog: true);
        }

        void ClearVisionProtocolLogCallback(object? _)
        {
            VisionProtocolLogs.Clear();
        }

        void AddVisionProtocolMarkCallback(object? _)
        {
            AddVisionProtocolMarkRow();
        }

        bool CanAddVisionProtocolMark(object? _)
        {
            return VisionProtocolMarkRows.Count < CVisionProtocol.MaximumMarkCount;
        }

        void RemoveVisionProtocolMarkCallback(object? _)
        {
            RemoveVisionProtocolMarkRow();
        }

        bool CanRemoveVisionProtocolMark(object? _)
        {
            return VisionProtocolMarkRows.Count > 0;
        }
    }

    public override EN_MENU Menu
    {
        get
        {
            return EN_MENU.Manual;
        }
    }

    public void StopScannerStatusPolling()
    {
        if (_manager.Station().ManualMofStatus.IsRunning != true) _powerMeasurePanel?.StageMotion.Stop();
        _powerMeasurePanel?.StageMotion.SetActive(false);
        StopStageMotionPolling();
    }

    private void StopStageMotionPolling()
    {
        if (!_stageMotionPollingService.IsRunning)
        {
            return;
        }

        try
        {
            _stageMotionPollingService.Stop();
        }
        catch (TimeoutException exception)
        {
            _setStatusMessage($"Manual stage motion polling stop timeout. {exception.Message}");
        }
    }

    public void RefreshScannerStatusSnapshot()
    {
        if (IsReviewWorkspace) return;
        if (IsScannerWorkspace && IsManualMofTab) RefreshMofStageSnapshot();
        if (IsScannerWorkspace && (IsManualScanTab || IsManualMofTab)) RefreshAutomationStatusSnapshot();
        if (_manualScannerOptionSettings.Count == 0)
        {
            return;
        }

        var selectedHeadNo = NormalizeManualScannerHeadNo(_manualScannerOptionSettings, Math.Clamp(_selectedHeadNoProvider(), 1, 8));
        var scannerAxes = ReadManualScannerAxesSnapshot(_manualScannerOptionSettings, selectedHeadNo);
        var headCards = ApplyManualHeadSelection(BuildHeadCards(selectedHeadNo, _manualScannerOptionSettings, scannerAxes), selectedHeadNo);
        bool IsSelectedHeadCard(ST_MANUAL_HEAD_CARD head)
        {
            return head.HeadNo == selectedHeadNo;
        }

        var selectedHead = headCards.FirstOrDefault(IsSelectedHeadCard) ?? new ST_MANUAL_HEAD_CARD(selectedHeadNo, $"H{selectedHeadNo:00}", "X -", "Y -", "Z -", "Disabled", true);
        if (!_hasScannerTargetSnapshot && HasReadableScannerPosition(scannerAxes))
        {
            TargetGx = ReadScannerAxisTarget(scannerAxes, "X");
            TargetGy = ReadScannerAxisTarget(scannerAxes, "Y");
            TargetGz = ReadScannerAxisTarget(scannerAxes, "Z", IsScannerAxisAvailable(scannerAxes, "Z") ? TargetGz : "NOT USE");
            _hasScannerTargetSnapshot = true;
        }

        HeadCards = headCards;
        HeadGroups = BuildHeadGroups(headCards);
        SelectedHeadItems = BuildSelectedHeadItems(selectedHead);
        SelectedHead = selectedHead.HeadName;
        ScannerAxes = scannerAxes;
        if (IsStageVisionWorkspace)
        {
            RefreshStageMotionSnapshot();
        }
        else
        {
            StopStageMotionPolling();
        }

        CommandStateRows = BuildCommandStateRows(selectedHead);
        OnPropertyChanged(nameof(HeadCards));
        OnPropertyChanged(nameof(SelectedHeadItems));
        OnPropertyChanged(nameof(SelectedHead));
        OnPropertyChanged(nameof(CommandStateRows));
        OnPropertyChanged(nameof(IsZPositionMoveEnabled));
        RefreshManualControllerHeads();
    }

    private void RefreshStageMotionSnapshot()
    {
        _stageMotionPollingService.SelectAxes(StageAxes);
        _stageMotionPollingService.Start();
        var snapshot = _stageMotionPollingService.GetSnapshot();
        foreach (var axis in StageAxes)
        {
            if (snapshot.TryGetValue(axis.Key, out var value))
            {
                axis.CurrentPosition = value.Position;
                axis.CurrentSpeed = value.Speed;
                axis.Status = value.State;
                axis.StatusMessage = value.Message;
            }
        }
    }

    public IReadOnlyList<ST_DISPLAY_ITEM> ManualSettings { get; private set; } = [];
    public IReadOnlyList<ST_DISPLAY_ITEM> SelectedHeadItems { get; private set; } = [];
    public IReadOnlyList<ST_DISPLAY_ITEM> PositionMoveItems { get; private set; } = [];
    public IReadOnlyList<ST_DISPLAY_ITEM> ShapeScanItems { get; private set; } = [];
    public IReadOnlyList<ST_DISPLAY_ITEM> CommandStateItems { get; private set; } = [];
    public string SelectedHead { get; private set; } = "";
    public string LoadedSettingName { get; private set; } = "";
    public string LoadedSettingPath { get; private set; } = "";

    public string TargetGx
    {
        get
        {
            return _targetGx;
        }

        set
        {
            SetProperty(ref _targetGx, value);
        }
    }

    public string TargetGy
    {
        get
        {
            return _targetGy;
        }

        set
        {
            SetProperty(ref _targetGy, value);
        }
    }

    public string TargetGz
    {
        get
        {
            return _targetGz;
        }

        set
        {
            SetProperty(ref _targetGz, value);
        }
    }

    public bool IsZPositionMoveEnabled
    {
        get
        {
            return IsScannerAxisAvailable(ScannerAxes, "Z");
        }
    }

    public string ShapeSize
    {
        get
        {
            return _shapeSize;
        }

        set
        {
            SetProperty(ref _shapeSize, value);
        }
    }

    public string ShapeOffsetX
    {
        get
        {
            return _shapeOffsetX;
        }

        set
        {
            SetProperty(ref _shapeOffsetX, value);
        }
    }

    public string ShapeOffsetY
    {
        get
        {
            return _shapeOffsetY;
        }

        set
        {
            SetProperty(ref _shapeOffsetY, value);
        }
    }

    public string ShapeDirection
    {
        get
        {
            return _shapeDirection;
        }

        set
        {
            SetProperty(ref _shapeDirection, value);
        }
    }

    public string ShapeName
    {
        get
        {
            return _shapeName;
        }

        set
        {
            SetProperty(ref _shapeName, NormalizeShapeName(value));
        }
    }

    public string GridRowLines
    {
        get
        {
            return _gridRowLines;
        }

        set
        {
            SetProperty(ref _gridRowLines, value);
        }
    }

    public string GridColLines
    {
        get
        {
            return _gridColLines;
        }

        set
        {
            SetProperty(ref _gridColLines, value);
        }
    }

    public string LaserOnMode
    {
        get
        {
            return _laserOnMode;
        }

        set
        {
            var normalizedValue = NormalizeLaserOnMode(value);
            if (SetProperty(ref _laserOnMode, normalizedValue))
            {
                OnPropertyChanged(nameof(IsLaserTimeMode));
                OnPropertyChanged(nameof(IsLaserCountMode));
                RefreshCommandStateRows();
            }
        }
    }

    public bool IsLaserTimeMode
    {
        get
        {
            return IsLaserTimeModeValue(LaserOnMode);
        }
    }

    public bool IsLaserCountMode
    {
        get
        {
            return !IsLaserTimeMode;
        }
    }

    public string LaserOnTimeMsec
    {
        get
        {
            return _laserOnTimeMsec;
        }

        set
        {
            SetProperty(ref _laserOnTimeMsec, value);
        }
    }

    public string LaserShotCount
    {
        get
        {
            return _laserShotCount;
        }

        set
        {
            SetProperty(ref _laserShotCount, value);
        }
    }

    public string LaserRepeatCount
    {
        get => _laserRepeatCount;
        set => SetProperty(ref _laserRepeatCount, value);
    }

    public string LaserRepeatDelayTimeMsec
    {
        get => _laserRepeatDelayTimeMsec;
        set => SetProperty(ref _laserRepeatDelayTimeMsec, value);
    }

    public IReadOnlyList<ST_MANUAL_HEAD_CARD> HeadCards { get; private set; } = [];
    public IReadOnlyList<ST_MANUAL_HEAD_GROUP> HeadGroups
    {
        get
        {
            return _headGroups;
        }

        private set
        {
            SetSequenceProperty(ref _headGroups, value);
        }
    }

    public IReadOnlyList<ST_MANUAL_SETTING_FILE> SettingFiles
    {
        get
        {
            return _settingFiles;
        }

        private set
        {
            SetSequenceProperty(ref _settingFiles, value);
        }
    }

    public string SettingFilesPageText
    {
        get
        {
            return _settingFilesPageText;
        }

        private set
        {
            SetProperty(ref _settingFilesPageText, value);
        }
    }

    public IReadOnlyList<ST_MANUAL_PARAMETER> SettingParameters { get; private set; } = [];
    public IReadOnlyList<ST_MANUAL_COMMAND_STATE> CommandStateRows { get; private set; } = [];
    public IReadOnlyList<ST_MANUAL_SCANNER_AXIS> ScannerAxes
    {
        get
        {
            return _scannerAxes;
        }

        private set
        {
            if (SetSequenceProperty(ref _scannerAxes, value))
            {
                OnPropertyChanged(nameof(IsZPositionMoveEnabled));
            }
        }
    }

    public IReadOnlyList<ST_MANUAL_STAGE_AXIS> StageAxes { get; }

    public ST_MANUAL_STAGE_AXIS SelectedStageAxis
    {
        get
        {
            return _selectedStageAxis;
        }

        private set
        {
            if (SetProperty(ref _selectedStageAxis, value))
            {
                RefreshStageAxisSelection();
            }
        }
    }

    public string DioAddress
    {
        get
        {
            return _dioAddress;
        }

        private set
        {
            SetProperty(ref _dioAddress, value);
        }
    }

    public string DioAxisName
    {
        get
        {
            return _dioAxisName;
        }

        private set
        {
            SetProperty(ref _dioAxisName, value);
        }
    }

    public string DioNo
    {
        get
        {
            return _dioNo;
        }

        private set
        {
            SetProperty(ref _dioNo, value);
        }
    }

    public string DioCurrentValue
    {
        get
        {
            return _dioCurrentValue;
        }

        private set
        {
            if (SetProperty(ref _dioCurrentValue, value))
            {
                OnPropertyChanged(nameof(IsDioOn));
                OnPropertyChanged(nameof(IsDioOff));
            }
        }
    }

    public bool IsDioOn
    {
        get
        {
            return DioCurrentValue.Equals("ON", StringComparison.OrdinalIgnoreCase);
        }
    }

    public bool IsDioOff
    {
        get
        {
            return DioCurrentValue.Equals("OFF", StringComparison.OrdinalIgnoreCase);
        }
    }

    public bool IsDioTargetReady
    {
        get
        {
            return _isDioTargetReady;
        }

        private set
        {
            if (SetProperty(ref _isDioTargetReady, value))
            {
                OnPropertyChanged(nameof(IsDioControlEnabled));
            }
        }
    }

    public bool IsDioControlEnabled
    {
        get
        {
            return IsDioTargetReady && !IsDioControlBusy;
        }
    }

    public string DioLastResult
    {
        get
        {
            return _dioLastResult;
        }

        private set
        {
            SetProperty(ref _dioLastResult, value);
        }
    }

    public bool IsDioControlBusy
    {
        get
        {
            return _isDioControlBusy;
        }

        private set
        {
            if (SetProperty(ref _isDioControlBusy, value))
            {
                OnPropertyChanged(nameof(IsDioControlEnabled));
            }
        }
    }

    public bool IsScannerWorkspace
    {
        get
        {
            return _isScannerWorkspace;
        }

        private set
        {
            if (SetProperty(ref _isScannerWorkspace, value))
            {
                OnPropertyChanged(nameof(IsStageVisionWorkspace));
            }
        }
    }

    public bool IsStageVisionWorkspace
    {
        get
        {
            return !IsScannerWorkspace && !IsReviewWorkspace;
        }
    }

    public IReadOnlyList<ST_MANUAL_VISION_PROTOCOL_COMMAND> VisionProtocolCommands { get; }

    public ST_MANUAL_VISION_PROTOCOL_COMMAND SelectedVisionProtocolCommand
    {
        get
        {
            return _selectedVisionProtocolCommand;
        }

        set
        {
            if (value is not null && SetProperty(ref _selectedVisionProtocolCommand, value))
            {
                ResetVisionProtocolInputs();
            }
        }
    }

    public string VisionProtocolCommandDescription
    {
        get
        {
            return SelectedVisionProtocolCommand.Description;
        }
    }

    public bool VisionProtocolUsesMarkRows
    {
        get
        {
            return SelectedVisionProtocolCommand.CommandText is "MARK_FIND_SINGLE" or "FLYING_READY";
        }
    }

    public bool VisionProtocolIsFlyingReady
    {
        get
        {
            return SelectedVisionProtocolCommand.CommandText == "FLYING_READY";
        }
    }

    public bool VisionProtocolHasNoArguments
    {
        get
        {
            return !VisionProtocolUsesMarkRows;
        }
    }

    public string VisionProtocolInspectionType
    {
        get
        {
            return _visionProtocolInspectionType;
        }

        set
        {
            if (SetProperty(ref _visionProtocolInspectionType, value ?? ""))
            {
                OnPropertyChanged(nameof(VisionProtocolRequestPreview));
            }
        }
    }

    public string VisionProtocolRequestPreview
    {
        get
        {
            return BuildVisionProtocolFunction(validate: false);
        }
    }

    public string VisionProtocolMarkRowCountText
    {
        get
        {
            return $"MARK {VisionProtocolMarkRows.Count} / {CVisionProtocol.MaximumMarkCount}";
        }
    }

    public string VisionProtocolEndpoint
    {
        get
        {
            return _visionProtocolEndpoint;
        }

        private set
        {
            SetProperty(ref _visionProtocolEndpoint, value);
        }
    }

    public string VisionProtocolStatus
    {
        get
        {
            return _visionProtocolStatus;
        }

        private set
        {
            SetProperty(ref _visionProtocolStatus, value);
        }
    }

    public string VisionProtocolKeepAlive
    {
        get
        {
            return _visionProtocolKeepAlive;
        }

        private set
        {
            SetProperty(ref _visionProtocolKeepAlive, value);
        }
    }

    public bool IsVisionProtocolBusy
    {
        get
        {
            return _isVisionProtocolBusy;
        }

        private set
        {
            if (SetProperty(ref _isVisionProtocolBusy, value))
            {
                VisionProtocolSendCommand.NotifyCanExecuteChanged();
            }
        }
    }

    public ObservableCollection<string> VisionProtocolLogs { get; } = [];
    public ObservableCollection<ST_MANUAL_VISION_MARK_SEARCH> VisionProtocolMarkRows { get; } = [];

    public CButtonCommand SelectHeadCommand { get; }
    public CButtonCommand SelectSettingCommand { get; }
    public CButtonCommand PreviousSettingPageCommand { get; }
    public CButtonCommand NextSettingPageCommand { get; }
    public CButtonCommand CreateCommand { get; }
    public CButtonCommand DeleteCommand { get; }
    public CButtonCommand RenameCommand { get; }
    public CButtonCommand SaveCommand { get; }
    public CButtonCommand CenterMoveCommand { get; }
    public CButtonCommand PositionMoveCommand { get; }
    public CButtonCommand ZPositionMoveCommand { get; }
    public CButtonCommand MoveStopCommand { get; }
    public CButtonCommand SelectShapeCommand { get; }
    public CButtonCommand ShapeStartCommand { get; }
    public CButtonCommand ShapeStopCommand { get; }
    public CButtonCommand LaserOnCommand { get; }
    public CButtonCommand LaserOffCommand { get; }
    public CButtonCommand CenterOnCommand { get; }
    public CButtonCommand DioReadCommand { get; }
    public CButtonCommand DioOnCommand { get; }
    public CButtonCommand DioOffCommand { get; }
    public CButtonCommand ScannerAxisHomeCommand { get; }
    public CButtonCommand ScannerAxisEnableCommand { get; }
    public CButtonCommand ScannerAxisDisableCommand { get; }
    public CButtonCommand ResetAutomationControllerCommand { get; }
    public CButtonCommand HomeAutomationControllerAxesCommand { get; }
    public CButtonCommand DisableControllerMofCommand { get; }
    public CButtonCommand ShowResetSequenceCommand { get; }
    public CButtonCommand SelectManualWorkspaceCommand { get; }
    public CButtonCommand SelectStageAxisCommand { get; }
    public CButtonCommand StageAbsMoveCommand { get; }
    public CButtonCommand StageRelMoveCommand { get; }
    public CButtonCommand StageHomeCommand { get; }
    public CButtonCommand StageStopCommand { get; }
    public CButtonCommand VisionProtocolSendCommand { get; }
    public CButtonCommand VisionProtocolRefreshCommand { get; }
    public CButtonCommand VisionProtocolClearLogCommand { get; }
    public CButtonCommand VisionProtocolAddMarkCommand { get; }
    public CButtonCommand VisionProtocolRemoveMarkCommand { get; }

    public override void OnActivated()
    {
        lock (_menuLifetimeSync)
        {
            if (_menuLifetimeCancellation.IsCancellationRequested)
            {
                _menuLifetimeCancellation.Dispose();
                _menuLifetimeCancellation = new CancellationTokenSource();
            }
        }

    }

    public override void OnDeactivated()
    {
        lock (_menuLifetimeSync)
        {
            _menuLifetimeCancellation.Cancel();
            _statusPollingCancellation?.Cancel();
            _statusPollingCancellation?.Dispose();
            _statusPollingCancellation = null;
        }
    }

    public override async Task<CScreenViewModel> Build(CancellationToken cancellationToken = default)
    {
        if (IsReviewWorkspace && Review is not null)
        {
            await Review.Build(cancellationToken);
            return new CScreenViewModel(EN_MENU.Manual, "MANUAL / CONTROL", "Review inspection operation.", [], [], manual: this);
        }
        var settingNames = await _scanFile.List(cancellationToken);
        var orderedSettingNames = OrderSettingNames(settingNames);
        _manualScanSettingNames = orderedSettingNames;
        var formItems = await _scanFile.LoadForm(cancellationToken);
        var selectedSettingName = ResolveSelectedSettingName(orderedSettingNames, _selectedSettingNameProvider());
        var settings = await _scanFile.Load(selectedSettingName, cancellationToken);
        SyncSettingFilesPage(orderedSettingNames, selectedSettingName);
        var selectedHeadNoRaw = _selectedHeadNoProvider();
        var optionSettings = _manager.Setting().LoadSection(EN_SETTING_TAB.Option, cancellationToken);
        _manualScannerOptionSettings = optionSettings;
        var selectedHeadNo = NormalizeManualScannerHeadNo(optionSettings, Math.Clamp(selectedHeadNoRaw, 1, 8));
        var scannerAxes = ReadManualScannerAxesSnapshot(optionSettings, selectedHeadNo);
        var headCards = ApplyManualHeadSelection(BuildHeadCards(selectedHeadNo, optionSettings, scannerAxes), selectedHeadNo);
        var selectedRecipe = await LoadSelectedRecipe(cancellationToken);
        MofPreview.Update(selectedRecipe, optionSettings);
        MofStage.UpdateTargets(selectedRecipe, _manager.Setting().LoadSection(EN_SETTING_TAB.Motor, cancellationToken));
        MofRun.SetInputs(selectedRecipe, optionSettings, SelectedManualHeadNos);
        SetAutomationStatusInputs(selectedRecipe, optionSettings);
        RefreshMofStageSnapshot();
        RefreshAutomationStatusSnapshot();
        bool IsSelectedHeadCard(global::Drilling.UI.Menu.Menus.ST_MANUAL_HEAD_CARD head)
        {
            return head.HeadNo == selectedHeadNo;
        }

        var selectedHead = headCards.First(IsSelectedHeadCard);
        var xAxisReference = ReadScannerAxisReference(scannerAxes, "X", "X");
        var yAxisReference = ReadScannerAxisReference(scannerAxes, "Y", "Y");
        var zAxisReference = ReadScannerAxisReference(scannerAxes, "Z", "Z");
        var isZAxisAvailable = IsScannerAxisAvailable(scannerAxes, "Z");
        var zTargetDefault = isZAxisAvailable ? FormatDouble(ReadHeadRecipeDouble(selectedRecipe, selectedHeadNo, 0.0, "DOE_Z_POSITION"), 3) : "NOT USE";
        var shouldRefreshPositionTargets = _lastBuiltHeadNo != selectedHeadNo || string.IsNullOrWhiteSpace(TargetGx) || string.IsNullOrWhiteSpace(TargetGy);
        if (shouldRefreshPositionTargets)
        {
            TargetGx = ReadScannerAxisTarget(scannerAxes, "X");
            TargetGy = ReadScannerAxisTarget(scannerAxes, "Y");
            _lastBuiltHeadNo = selectedHeadNo;
            _hasScannerTargetSnapshot = HasReadableScannerPosition(scannerAxes);
        }

        if (!isZAxisAvailable)
        {
            TargetGz = "NOT USE";
        }
        else if (shouldRefreshPositionTargets || string.IsNullOrWhiteSpace(TargetGz) || TargetGz.Equals("NOT USE", StringComparison.OrdinalIgnoreCase))
        {
            TargetGz = ReadScannerAxisTarget(scannerAxes, "Z", zTargetDefault);
        }

        if (!_lastLoadedSettingName.Equals(selectedSettingName, StringComparison.OrdinalIgnoreCase))
        {
            ShapeSize = FormatDouble(settings.ShapeSize, 3);
            ShapeOffsetX = FormatDouble(settings.OffsetX, 3);
            ShapeOffsetY = FormatDouble(settings.OffsetY, 3);
            ShapeDirection = string.IsNullOrWhiteSpace(settings.Direction) ? "CW" : settings.Direction;
            ShapeName = settings.ShapeName;
            GridRowLines = settings.GridRowLines.ToString(CultureInfo.InvariantCulture);
            GridColLines = settings.GridColLines.ToString(CultureInfo.InvariantCulture);
            _lastLoadedSettingName = selectedSettingName;
        }

        var dioGeneration = BeginDioTargetRefresh("Loading");
        try
        {
            var dioTarget = await ResolveDioTarget(selectedHeadNo, cancellationToken);
            if (IsCurrentDioGeneration(dioGeneration))
            {
                ApplyDioTarget(dioTarget);
            }
        }
        catch (Exception exception)when (exception is InvalidOperationException or InvalidDataException or IOException or TimeoutException or KeyNotFoundException)
        {
            if (IsCurrentDioGeneration(dioGeneration))
            {
                InvalidateDioTarget($"ERROR: {exception.Message}");
            }
        }

        Apply(BuildManualSettings(settings), BuildSelectedHeadItems(selectedHead), [new("Center Move", "Ready"), new("Position Move", $"{xAxisReference}/{yAxisReference} Target"), new("Z Move", $"{zAxisReference} Target"), new("Move Stop", "Ready"), new($"{xAxisReference} Target", TargetGx, "mm"), new($"{yAxisReference} Target", TargetGy, "mm"), new($"{zAxisReference} Target", TargetGz, "mm")], [new("Shape Size", ShapeSize, "mm"), new("Offset X", ShapeOffsetX, "mm"), new("Offset Y", ShapeOffsetY, "mm"), new("Direction", ShapeDirection), new("Shape", ShapeName), new("Grid Row Lines", GridRowLines, "ea"), new("Grid Col Lines", GridColLines, "ea"), new("Start", "Ready"), new("Stop", "Ready")], [new("Laser", _laserState), new("CENTER", _centerState), new("Last Command", _lastCommand), new("Result", _lastResult)], selectedHead.HeadName, selectedSettingName, $@"Config\Manual\{selectedSettingName}", headCards, BuildSettingFiles(orderedSettingNames, selectedSettingName, _settingFilesPageIndex), BuildSettingParameters(settings, formItems), BuildCommandStateRows(selectedHead), scannerAxes);
        RefreshManualControllerHeads();
        RefreshVisionProtocolStatus(writeLog: false);
        return new CScreenViewModel(EN_MENU.Manual, "MANUAL / CONTROL", "Scanner, stage and protocol test operation.", [new("Selected Head", selectedHead.HeadName), new("Mode", "Manual"), new("Laser", _laserState)], [new("Manual Setting", BuildManualSettings(settings)), new("Position Move", [new("Center Move", "Ready"), new("Position Move", $"{xAxisReference}/{yAxisReference} target input"), new("Z Move", $"{zAxisReference} target input"), new("Move Stop", "Ready")])], manual: this);
    }

    private async Task ShowPreviousSettingPage()
    {
        if (!CanShowPreviousSettingPage())
        {
            return;
        }

        _settingFilesPageIndex--;
        NotifySettingFilesPageCommands();
        await _refreshCurrentScreen();
    }

    private async Task ShowNextSettingPage()
    {
        if (!CanShowNextSettingPage())
        {
            return;
        }

        _settingFilesPageIndex++;
        NotifySettingFilesPageCommands();
        await _refreshCurrentScreen();
    }

    private bool CanShowPreviousSettingPage()
    {
        return _settingFilesPageIndex > 0;
    }

    private bool CanShowNextSettingPage()
    {
        return _settingFilesPageIndex + 1 < _settingFilesPageCount;
    }

    private void NotifySettingFilesPageCommands()
    {
        PreviousSettingPageCommand.NotifyCanExecuteChanged();
        NextSettingPageCommand.NotifyCanExecuteChanged();
    }

    private void SelectManualWorkspace(object? parameter)
    {
        var workspace = parameter?.ToString()?.ToUpperInvariant();
        if (workspace is not ("SCANNER" or "STAGE_VISION" or "REVIEW")) return;
        if (Review?.IsReviewExecutionActive == true && workspace != "REVIEW")
        {
            CRecipeConfirmDialog.ShowWarning("검사 진행 중", "검사를 중지한 후 이동해 주세요.");
            return;
        }
        var wasReview = IsReviewWorkspace;
        _isReviewWorkspace = workspace == "REVIEW";
        IsScannerWorkspace = workspace == "SCANNER";
        OnPropertyChanged(nameof(IsReviewWorkspace));
        OnPropertyChanged(nameof(IsStageVisionWorkspace));
        if (IsReviewWorkspace && !wasReview) Review?.ResetForMenuOpen();
        if (!IsScannerWorkspace) _powerMeasurePanel?.StageMotion.SetActive(false);
        _homeSpeedPanel?.SetActive(_homeSpeedController.HasValue && IsManualControllerTab && IsScannerWorkspace);
        if (IsScannerWorkspace || IsReviewWorkspace)
        {
            StopStageMotionPolling();
        }
        _ = _refreshCurrentScreen();
    }

    private void SelectStageAxis(object? parameter)
    {
        if (parameter is not ST_MANUAL_STAGE_AXIS axis)
        {
            return;
        }

        SelectedStageAxis = axis;
    }

    private async void StageAbsMove(object? parameter)
    {
        await ExecuteMotionMove("ABS", "절대 이동");
    }

    private async void StageRelMove(object? parameter)
    {
        await ExecuteMotionMove("REL", "상대 이동");
    }

    private async Task ExecuteMotionMove(string moveMode, string confirmationTitle)
    {
        var axis = SelectedStageAxis;
        if (!double.TryParse(axis.TargetPosition, NumberStyles.Float, CultureInfo.InvariantCulture, out var targetPosition))
        {
            var message = $"{axis.DisplayName} position is not a valid number: {axis.TargetPosition}";
            _setStatusMessage(message);
            ShowManualWarning(message);
            return;
        }

        if (!double.TryParse(axis.TargetSpeed, NumberStyles.Float, CultureInfo.InvariantCulture, out var targetSpeed) || targetSpeed < 0.0)
        {
            var message = $"{axis.DisplayName} speed is not a valid positive number: {axis.TargetSpeed}";
            _setStatusMessage(message);
            ShowManualWarning(message);
            return;
        }

        if (!CRecipeConfirmDialog.ShowConfirmation("Motion " + confirmationTitle, $"{axis.DisplayName} 축을 {moveMode} 모드로 이동하시겠습니까?\nPOS={targetPosition:0.###} {axis.Unit}\nSPEED={targetSpeed:0.###} {axis.SpeedUnit} (현재 맵 미적용)"))
        {
            return;
        }

        _setStatusMessage($"{axis.DisplayName} {moveMode} move sending. Pos={targetPosition:0.###} {axis.Unit}.");
        try
        {
            var writePosition = await CalculateStageMotionWritePosition(axis, moveMode, targetPosition);
            await Task.Run(() => _manager.Interface().Melsec.WriteDouble(axis.WritePositionId, writePosition));
            _setStatusMessage($"{axis.DisplayName} {moveMode} move requested. {axis.WritePositionId}={FormatDouble(writePosition, 3)} {axis.Unit}.");
            RefreshStageMotionSnapshot();
        }
        catch (Exception exception) when (exception is InvalidOperationException or InvalidDataException or IOException or TimeoutException)
        {
            var message = $"{axis.DisplayName} {moveMode} move failed. {exception.Message}";
            _setStatusMessage(message);
            ShowManualWarning(message);
        }
        finally
        {
            _refreshShellStatus();
        }
    }

    private async Task<double> CalculateStageMotionWritePosition(ST_MANUAL_STAGE_AXIS axis, string moveMode, double inputPosition)
    {
        if (!double.IsFinite(inputPosition))
        {
            throw new InvalidOperationException($"{axis.DisplayName} target position is not finite.");
        }

        if (moveMode.Equals("ABS", StringComparison.OrdinalIgnoreCase))
        {
            return inputPosition;
        }

        var cached = await _manager.Interface().Melsec.RefreshCachedValueAsync(axis.ReadPositionId);
        var currentPosition = cached.Value is double number ? number : double.NaN;
        var targetPosition = currentPosition + inputPosition;
        if (!cached.IsValid || !double.IsFinite(currentPosition) || !double.IsFinite(targetPosition))
        {
            throw new InvalidOperationException($"{axis.DisplayName} current position is unavailable. {CMelsecCachePresentation.Describe(cached)}");
        }

        return targetPosition;
    }

    private void StageStop(object? parameter)
    {
        var axis = SelectedStageAxis;
        _setStatusMessage($"{axis.DisplayName} stop requested (UI only).");
        _refreshShellStatus();
    }

    private void StageHome(object? parameter)
    {
        var axis = SelectedStageAxis;
        if (!CRecipeConfirmDialog.ShowConfirmation("Motion 원점 복귀", $"{axis.DisplayName} 축을 원점으로 복귀하시겠습니까?"))
        {
            return;
        }

        _setStatusMessage($"{axis.DisplayName} home requested (UI only).");
        _refreshShellStatus();
    }

    private void RefreshStageAxisSelection()
    {
        foreach (var axis in StageAxes)
        {
            axis.IsSelected = ReferenceEquals(axis, SelectedStageAxis);
        }
    }

    private async Task HomeScannerAxis(object? parameter)
    {
        await ExecuteScannerAxisCommand(parameter, "HOME");
    }

    private async Task EnableScannerAxis(object? parameter)
    {
        await ExecuteScannerAxisCommand(parameter, "ENABLE");
    }

    private async Task DisableScannerAxis(object? parameter)
    {
        await ExecuteScannerAxisCommand(parameter, "DISABLE");
    }

    private void ShowResetSequenceDialog(object? parameter)
    {
        if (!IsScannerWorkspace)
        {
            return;
        }

        var dialog = new CControllerResetSequenceDialog(
            BuildResetSequenceTargetOptions(),
            ExecuteResetSequence)
        {
            Owner = GetActiveWindow()
        };
        dialog.ShowDialog();
    }

    private async Task ResetAutomationController(object? parameter, CancellationToken cancellationToken = default)
    {
        if (parameter is not ST_MANUAL_HEAD_GROUP group)
        {
            return;
        }

        var commandName = $"CONTROLLER_{group.AutomationNo + 1}_RESET";
        if (TryBlockManualAutomationCommand(commandName))
        {
            return;
        }

        if (!_manager.automation.IsSimul(group.AutomationNo) &&
            !_manager.automation.IsConnect(group.AutomationNo))
        {
            _lastCommand = commandName;
            _lastResult = "OFFLINE";
            _setStatusMessage($"{group.Title} reset failed. Automation is offline.");
            RefreshCommandStateRows();
            _refreshShellStatus();
            CRecipeConfirmDialog.ShowWarning(
                "컨트롤러 리셋 실패",
                $"{group.Title} Automation 장비가 연결되어 있지 않아 리셋을 실행할 수 없습니다.");
            return;
        }

        if (!CRecipeConfirmDialog.ShowConfirmation("컨트롤러 리셋", $"{group.Title} 컨트롤러를 리셋하시겠습니까?\n축 Enable과 Home 상태가 해제될 수 있습니다."))
        {
            return;
        }

        _lastCommand = commandName;
        _lastResult = "Sending";
        RefreshCommandStateRows();
        _refreshShellStatus();

        try
        {
            var response = await _manager.automation.ResetController(group.AutomationNo, cancellationToken);
            EnsureAutomationResponse(response, $"{group.Title} reset");
            _lastResult = $"OK: {group.Title}";
            _setStatusMessage($"{group.Title} reset command OK.");
            RefreshCommandStateRows();
            _refreshShellStatus();
            await _refreshCurrentScreen();
        }
        catch (Exception exception)when (exception is InvalidOperationException or IOException or TimeoutException or KeyNotFoundException)
        {
            _lastResult = $"ERROR: {exception.Message}";
            _setStatusMessage($"{group.Title} reset failed. {exception.Message}");
            RefreshCommandStateRows();
            _refreshShellStatus();
            await _refreshCurrentScreen();
            CRecipeConfirmDialog.ShowWarning(
                "컨트롤러 리셋 실패",
                $"{group.Title} 리셋 명령을 완료하지 못했습니다.\n{exception.Message}");
        }
    }

    private IReadOnlyList<ST_CONTROLLER_RESET_SEQUENCE_TARGET_OPTION> BuildResetSequenceTargetOptions()
    {
        int SelectInterfaceNumber(ST_INTERFACE_DATA data)
        {
            return data.Number;
        }

        string FormatControllerName(ST_INTERFACE_DATA data)
        {
            var controllerName = $"CONTROLLER {data.Number + 1}";
            return string.IsNullOrWhiteSpace(data.NickName)
                ? controllerName
                : $"{controllerName} ({data.NickName})";
        }

        return _manager.Interface()
            .GetInterfaceList(EN_EQP_MODULE.Automation1)
            .OrderBy(SelectInterfaceNumber)
            .Select(data => new ST_CONTROLLER_RESET_SEQUENCE_TARGET_OPTION(
                FormatControllerName(data),
                data.Number,
                false))
            .ToArray();
    }

    private async Task ExecuteResetSequence(
        CControllerResetSequenceDialog dialog,
        IReadOnlyList<ST_CONTROLLER_RESET_SEQUENCE_TARGET_OPTION> controllers,
        Func<bool> isStopRequested,
        CancellationToken cancellationToken)
    {
        if (TryBlockManualAutomationCommand("RESET_SEQUENCE"))
        {
            throw new InvalidOperationException("Auto process is running. Reset sequence is blocked.");
        }

        var settings = _manager.Setting().LoadSection(EN_SETTING_TAB.Option, cancellationToken);
        // Validate every selected controller's Recipe targets before the first reset.
        var recipeZMoves = await PrepareResetRecipeZMoves(settings, controllers, cancellationToken);
        _lastCommand = "RESET_SEQUENCE";
        _lastResult = "Running";
        RefreshCommandStateRows();
        _refreshShellStatus();

        foreach (var controller in controllers)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (isStopRequested())
            {
                dialog.SkipAllWaitingSteps();
                break;
            }

            await ExecuteResetSequenceStep(dialog, controller, 1, "Controller Reset", () => ResetSequenceController(controller, cancellationToken));
            if (isStopRequested())
            {
                dialog.SkipWaitingSteps(controller.AutomationNo);
                dialog.SkipAllWaitingSteps();
                break;
            }

            var axes = BuildResetSequenceAxisTargets(settings, controller.AutomationNo);
            await ExecuteResetSequenceStep(dialog, controller, 2, "All Axis Enable", () => ResetSequenceEnableAxes(controller, axes, cancellationToken));
            if (isStopRequested())
            {
                dialog.SkipWaitingSteps(controller.AutomationNo);
                dialog.SkipAllWaitingSteps();
                break;
            }

            await ExecuteResetSequenceStep(dialog, controller, 3, "All Axis Home", () => ResetSequenceHomeAxes(controller, axes, cancellationToken));
            if (isStopRequested())
            {
                dialog.SkipWaitingSteps(controller.AutomationNo);
                dialog.SkipAllWaitingSteps();
                break;
            }

            var dioTargets = BuildResetSequenceDioTargets(settings, controller.AutomationNo);
            await ExecuteResetSequenceStep(dialog, controller, 4, "DIO ON", () => ResetSequenceDioOn(controller, dioTargets, cancellationToken));
            if (isStopRequested())
            {
                dialog.SkipAllWaitingSteps();
                break;
            }
            var zMoves = recipeZMoves[controller.AutomationNo];
            if (zMoves.Count == 0)
            {
                dialog.SetStepState(controller.AutomationNo, 5, "SKIP");
                dialog.SetStatusMessage($"{controller.DisplayName}: 사용 중인 DOE Z축이 없어 5번 단계를 건너뜁니다.");
            }
            else
            {
                await ExecuteResetSequenceStep(dialog, controller, 5, "DOE Z Recipe Position Move",
                    () => new CAutomationPositioningService(_manager.automation).MoveAndWait(zMoves, cancellationToken));
            }
        }

        _lastResult = isStopRequested() ? "STOPPED" : "OK";
        RefreshCommandStateRows();
        _refreshShellStatus();
    }

    private async Task ExecuteResetSequenceStep(
        CControllerResetSequenceDialog dialog,
        ST_CONTROLLER_RESET_SEQUENCE_TARGET_OPTION controller,
        int stepNo,
        string stepName,
        Func<Task> action)
    {
        dialog.SetStatusMessage($"{controller.DisplayName} {stepName} running.");
        dialog.SetStepState(controller.AutomationNo, stepNo, "RUNNING");
        try
        {
            await action();
            dialog.SetStepState(controller.AutomationNo, stepNo, "OK");
            dialog.SetStatusMessage($"{controller.DisplayName} {stepName} OK.");
        }
        catch
        {
            dialog.SetStepState(controller.AutomationNo, stepNo, "NG");
            dialog.SkipAllWaitingSteps();
            _lastResult = $"NG: {controller.DisplayName} {stepName}";
            RefreshCommandStateRows();
            _refreshShellStatus();
            throw;
        }
    }

    private async Task ResetSequenceController(
        ST_CONTROLLER_RESET_SEQUENCE_TARGET_OPTION controller,
        CancellationToken cancellationToken)
    {
        if (!_manager.automation.IsSimul(controller.AutomationNo) &&
            !_manager.automation.IsConnect(controller.AutomationNo))
        {
            throw new InvalidOperationException($"{controller.DisplayName} Automation is offline.");
        }

        var response = await WithTimeout(
            token => _manager.automation.ResetController(controller.AutomationNo, token),
            ResetSequenceResetTimeout,
            cancellationToken);
        EnsureAutomationResponse(response, $"{controller.DisplayName} reset");
        await WaitControllerReady(controller, cancellationToken);
    }

    private async Task WaitControllerReady(
        ST_CONTROLLER_RESET_SEQUENCE_TARGET_OPTION controller,
        CancellationToken cancellationToken)
    {
        if (_manager.automation.IsSimul(controller.AutomationNo))
        {
            return;
        }

        var deadline = DateTimeOffset.Now + ResetSequenceResetTimeout;
        while (DateTimeOffset.Now <= deadline)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (_manager.automation.IsConnect(controller.AutomationNo))
            {
                var response = await WithTimeout(
                    token => _manager.automation.ReadStatus(controller.AutomationNo, token),
                    ResetSequenceCommandTimeout,
                    cancellationToken);
                EnsureAutomationResponse(response, $"{controller.DisplayName} status");
                return;
            }

            await Task.Delay(ResetSequencePollInterval, cancellationToken);
        }

        throw new TimeoutException($"{controller.DisplayName} reset ready check timed out.");
    }

    private async Task ResetSequenceEnableAxes(
        ST_CONTROLLER_RESET_SEQUENCE_TARGET_OPTION controller,
        IReadOnlyList<ST_RESET_SEQUENCE_AXIS_TARGET> axes,
        CancellationToken cancellationToken)
    {
        if (axes.Count == 0)
        {
            throw new InvalidOperationException($"{controller.DisplayName} has no configured scanner axis.");
        }

        foreach (var axis in axes)
        {
            var response = await WithTimeout(
                token => _manager.automation.ServoOn(axis.AxisReference, controller.AutomationNo, token),
                ResetSequenceCommandTimeout,
                cancellationToken);
            EnsureAutomationResponse(response, $"{controller.DisplayName} {axis.AxisReference} enable");
        }

        await WaitAxesReady(
            controller,
            axes,
            status => status.Able && !status.HasError,
            "enable",
            ResetSequenceEnableTimeout,
            cancellationToken);
    }

    private async Task ResetSequenceHomeAxes(
        ST_CONTROLLER_RESET_SEQUENCE_TARGET_OPTION controller,
        IReadOnlyList<ST_RESET_SEQUENCE_AXIS_TARGET> axes,
        CancellationToken cancellationToken)
    {
        if (axes.Count == 0)
        {
            throw new InvalidOperationException($"{controller.DisplayName} has no configured scanner axis.");
        }

        foreach (var axis in axes)
        {
            var response = await WithTimeout(
                token => _manager.automation.HomeAsync(axis.AxisReference, controller.AutomationNo, token),
                ResetSequenceCommandTimeout,
                cancellationToken);
            EnsureAutomationResponse(response, $"{controller.DisplayName} {axis.AxisReference} home");
        }

        await WaitAxesReady(
            controller,
            axes,
            status => status.Able && status.HomeDone && !status.HasError,
            "home",
            ResetSequenceHomeTimeout,
            cancellationToken);
    }

    private async Task WaitAxesReady(
        ST_CONTROLLER_RESET_SEQUENCE_TARGET_OPTION controller,
        IReadOnlyList<ST_RESET_SEQUENCE_AXIS_TARGET> axes,
        Func<ST_AUTOMATION_AXIS_STATUS, bool> isReady,
        string actionName,
        TimeSpan timeout,
        CancellationToken cancellationToken)
    {
        var deadline = DateTimeOffset.Now + timeout;
        while (DateTimeOffset.Now <= deadline)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var readyCount = 0;
            foreach (var axis in axes)
            {
                var status = await ReadAxisStatusWithTimeout(axis, cancellationToken);
                if (status.HasError)
                {
                    throw new InvalidOperationException($"{controller.DisplayName} {axis.AxisReference} fault during {actionName}. Fault={status.Fault}");
                }

                if (isReady(status))
                {
                    readyCount++;
                }
            }

            if (readyCount == axes.Count)
            {
                return;
            }

            await Task.Delay(ResetSequencePollInterval, cancellationToken);
        }

        throw new TimeoutException($"{controller.DisplayName} axis {actionName} check timed out.");
    }

    private async Task<ST_AUTOMATION_AXIS_STATUS> ReadAxisStatusWithTimeout(
        ST_RESET_SEQUENCE_AXIS_TARGET axis,
        CancellationToken cancellationToken)
    {
        return await WithTimeout(
            token => Task.Run(
                () => _manager.automation.ReadAxisStatusByNameNoLog(
                    axis.AxisReference,
                    axis.AutomationNo,
                    axis.AioNo,
                    axis.ReadExtendedStatus,
                    token),
                token),
            ResetSequenceCommandTimeout,
            cancellationToken);
    }

    private async Task ResetSequenceDioOn(
        ST_CONTROLLER_RESET_SEQUENCE_TARGET_OPTION controller,
        IReadOnlyList<ST_RESET_SEQUENCE_DIO_TARGET> dioTargets,
        CancellationToken cancellationToken)
    {
        if (dioTargets.Count == 0)
        {
            throw new InvalidOperationException($"{controller.DisplayName} has no configured scanner DIO.");
        }

        foreach (var target in dioTargets)
        {
            var response = await WithTimeout(
                token => _manager.automation.SetIo(target.Address, true, controller.AutomationNo, token),
                ResetSequenceCommandTimeout,
                cancellationToken);
            EnsureAutomationResponse(response, $"{controller.DisplayName} {target.Address} ON");
            var setValue = ReadDioValueFromResponse(response);
            if (!setValue.Equals("ON", StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException($"{controller.DisplayName} {target.Address} ON response mismatch. Response={setValue}");
            }

            var readResponse = await WithTimeout(
                token => _manager.automation.ReadIo(target.Address, controller.AutomationNo, token),
                ResetSequenceDioTimeout,
                cancellationToken);
            EnsureAutomationResponse(readResponse, $"{controller.DisplayName} {target.Address} read");
            var readValue = ReadDioValueFromResponse(readResponse);
            if (!readValue.Equals("ON", StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException($"{controller.DisplayName} {target.Address} readback mismatch. Current={readValue}");
            }
        }
    }

    private static async Task<T> WithTimeout<T>(
        Func<CancellationToken, Task<T>> action,
        TimeSpan timeout,
        CancellationToken cancellationToken)
    {
        using var timeoutCancellation = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        var task = action(timeoutCancellation.Token);
        var completed = await Task.WhenAny(task, Task.Delay(timeout, cancellationToken));
        if (!ReferenceEquals(completed, task))
        {
            timeoutCancellation.Cancel();
            throw new TimeoutException($"Automation command timed out after {timeout.TotalSeconds:0.#} sec.");
        }

        return await task;
    }

    private static IReadOnlyList<ST_RESET_SEQUENCE_AXIS_TARGET> BuildResetSequenceAxisTargets(
        IReadOnlyList<ST_SYSTEM_PARAMETER> settings,
        int automationNo)
    {
        const int headCount = 8;
        var targets = new List<ST_RESET_SEQUENCE_AXIS_TARGET>();
        var axisSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        for (var headNo = 1; headNo <= headCount; headNo++)
        {
            var definitions = CScannerStatusSnapshotReader.BuildAxisDefinitions(settings, headNo);
            foreach (var definition in definitions)
            {
                if (definition.AutomationNo != automationNo || !definition.IsUsed)
                {
                    continue;
                }

                if (!string.IsNullOrWhiteSpace(definition.ConfigurationError))
                {
                    throw new InvalidOperationException(definition.ConfigurationError);
                }

                if (string.IsNullOrWhiteSpace(definition.AxisReference))
                {
                    throw new InvalidOperationException($"H{headNo:00} {definition.AxisName} axis name is not configured.");
                }

                if (!axisSet.Add(definition.AxisReference))
                {
                    continue;
                }

                targets.Add(new ST_RESET_SEQUENCE_AXIS_TARGET(
                    headNo,
                    definition.AutomationNo,
                    definition.AxisName,
                    definition.AxisReference,
                    definition.AioNo,
                    definition.ReadExtendedStatus));
            }
        }

        return targets;
    }

    private static IReadOnlyList<ST_RESET_SEQUENCE_DIO_TARGET> BuildResetSequenceDioTargets(
        IReadOnlyList<ST_SYSTEM_PARAMETER> settings,
        int automationNo)
    {
        var targets = new List<ST_RESET_SEQUENCE_DIO_TARGET>();
        var addressSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var enabledHeadNos = CScannerStatusSnapshotReader.BuildEnabledHeadNumbers(settings, 8);
        foreach (var headNo in enabledHeadNos)
        {
            var headAutomationNo = ReadManualHeadAutomationNo(settings, headNo);
            if (headAutomationNo != automationNo)
            {
                continue;
            }

            var defaultGxAxisNo = ((headNo - 1) % 4) * 2;
            var gxAxisNo = ReadOptionalHeadSettingInt(settings, defaultGxAxisNo, headNo, "GX_AXIS_NO");
            ValidateDioAxisNo(headNo, gxAxisNo);
            var dioNo = ReadRequiredHeadSettingInt(settings, headNo, "SCANNER_DIO_NO");
            ValidateDioNo(headNo, dioNo);
            var address = $"A{gxAxisNo.ToString(CultureInfo.InvariantCulture)}.DO{dioNo.ToString(CultureInfo.InvariantCulture)}";
            if (!addressSet.Add(address))
            {
                continue;
            }

            targets.Add(new ST_RESET_SEQUENCE_DIO_TARGET(headNo, automationNo, address));
        }

        return targets;
    }

    private async Task HomeAutomationControllerAxes(object? parameter, CancellationToken cancellationToken = default)
    {
        if (parameter is not ST_MANUAL_HEAD_GROUP group)
        {
            return;
        }

        var commandName = $"CONTROLLER_{group.AutomationNo + 1}_ALL_HOME";
        if (TryBlockManualAutomationCommand(commandName))
        {
            return;
        }

        if (!_manager.automation.IsSimul(group.AutomationNo) &&
            !_manager.automation.IsConnect(group.AutomationNo))
        {
            _lastCommand = commandName;
            _lastResult = "OFFLINE";
            _setStatusMessage($"{group.Title} all home failed. Automation is offline.");
            RefreshCommandStateRows();
            _refreshShellStatus();
            CRecipeConfirmDialog.ShowWarning(
                "컨트롤러 ALL HOME 실패",
                $"{group.Title} Automation 장비가 연결되어 있지 않아 ALL HOME을 실행할 수 없습니다.");
            return;
        }

        IReadOnlyList<ST_CONTROLLER_HOME_TASK> homeTasks;
        try
        {
            var optionSettings = _manager.Setting().LoadSection(EN_SETTING_TAB.Option, cancellationToken);
            homeTasks = BuildControllerHomeTasks(optionSettings, group.AutomationNo);
        }
        catch (Exception exception)when (exception is InvalidOperationException or IOException or TimeoutException or KeyNotFoundException)
        {
            _lastCommand = commandName;
            _lastResult = $"ERROR: {exception.Message}";
            _setStatusMessage($"{group.Title} all home failed. {exception.Message}");
            RefreshCommandStateRows();
            _refreshShellStatus();
            CRecipeConfirmDialog.ShowWarning("컨트롤러 ALL HOME 실패", exception.Message);
            return;
        }

        if (homeTasks.Count == 0)
        {
            _lastCommand = commandName;
            _lastResult = "NO AXIS";
            _setStatusMessage($"{group.Title} all home skipped. No enabled scanner axis is configured.");
            RefreshCommandStateRows();
            _refreshShellStatus();
            CRecipeConfirmDialog.ShowWarning(
                "컨트롤러 ALL HOME 실패",
                $"{group.Title}에 사용 설정된 스캐너 축이 없습니다.");
            return;
        }

        var axisList = FormatControllerHomeAxisList(homeTasks);
        var confirmationMessage = $"{axisList} 의 Home을 실행하시겠습니까?";
        if (homeTasks.Count > 1)
        {
            confirmationMessage = $"{confirmationMessage}{Environment.NewLine}{FormatControllerHomeTaskSummary(homeTasks)}";
        }

        if (!CRecipeConfirmDialog.ShowConfirmation("컨트롤러 ALL HOME", confirmationMessage))
        {
            return;
        }

        CancelStatusPolling();
        _lastCommand = commandName;
        _lastResult = "Building";
        RefreshCommandStateRows();
        _refreshShellStatus();

        try
        {
            var runItems = new List<ST_CONTROLLER_HOME_RUN>(homeTasks.Count);
            foreach (var homeTask in homeTasks)
            {
                var taskAxisList = string.Join(",", homeTask.AxisReferences);
                var scriptFileName = BuildControllerHomeScriptFileName(homeTask);
                var script = _scriptFile.Create(scriptFileName);
                script.Start($"Manual {group.Title} {FormatControllerHomeHeadSummary(homeTask.HeadNos)} ALL HOME");
                script.AddLine($"Home([{taskAxisList}])");
                script.End();
                var savedScript = script.Save(cancellationToken);
                var uploadResponse = await _manager.automation.UploadScript(savedScript.FilePath, savedScript.FileName, group.AutomationNo, cancellationToken);
                EnsureAutomationResponse(uploadResponse, $"{commandName} upload T{homeTask.TaskNo}");
                var runResponse = await _manager.automation.RunScript(savedScript.FileName, homeTask.TaskNo, group.AutomationNo, cancellationToken);
                EnsureAutomationResponse(runResponse, $"{commandName} run T{homeTask.TaskNo}");
                runItems.Add(new ST_CONTROLLER_HOME_RUN(homeTask.TaskNo, savedScript.FileName, runResponse));
            }

            _lastResult = $"Running {runItems.Count} task(s)";
            _setStatusMessage($"{group.Title} all home scripts uploaded and started: {FormatControllerHomeRunSummary(runItems)}");
            var statusCancellation = CreateStatusPollingCancellation(cancellationToken);
            var statusToken = statusCancellation.Token;
            try
            {
                foreach (var runItem in runItems)
                {
                    await WaitManualTaskCompleted(
                        runItem.InitialResponse,
                        requireExecutionStart: !_manager.automation.IsSimul(group.AutomationNo),
                        automationNo: group.AutomationNo,
                        taskNo: runItem.TaskNo,
                        cancellationToken: statusToken);
                }

                statusToken.ThrowIfCancellationRequested();
            }
            finally
            {
                ReleaseStatusPollingCancellation(statusCancellation);
            }

            _lastResult = $"Completed {runItems.Count} task(s)";
            _setStatusMessage($"{group.Title} all home completed: {FormatControllerHomeRunSummary(runItems)}");
            RefreshCommandStateRows();
            _refreshShellStatus();
            await _refreshCurrentScreen();
        }
        catch (OperationCanceledException)
        {
            // 화면을 벗어나면 완료 상태 조회와 후속 팝업만 중단한다.
            // 이미 Automation1에 전달된 실제 Home 스크립트는 별도의 정지 명령 없이 계속된다.
        }
        catch (Exception exception)when (exception is InvalidDataException or InvalidOperationException or IOException or TimeoutException or KeyNotFoundException)
        {
            _lastResult = $"ERROR: {exception.Message}";
            _setStatusMessage($"{group.Title} all home failed. {exception.Message}");
            RefreshCommandStateRows();
            _refreshShellStatus();
            CRecipeConfirmDialog.ShowWarning(
                "컨트롤러 ALL HOME 실패",
                $"ALL HOME 동작을 완료하지 못했습니다.\n{exception.Message}");
        }
    }

    private async Task ExecuteScannerAxisCommand(object? parameter, string commandName, CancellationToken cancellationToken = default)
    {
        if (parameter is not ST_MANUAL_SCANNER_AXIS axis)
        {
            return;
        }

        if (!IsConfiguredScannerAxisName(axis.AxisReference))
        {
            _lastCommand = $"SCANNER_{axis.Head}_{axis.AxisRole}_{commandName}";
            _lastResult = "NOT CONFIGURED";
            _setStatusMessage($"{axis.Head} {axis.AxisRole} axis name is not configured.");
            RefreshCommandStateRows();
            _refreshShellStatus();
            CRecipeConfirmDialog.ShowWarning(
                "스캐너 축 제어 실패",
                $"{axis.Head} {axis.AxisRole}축의 Automation1 축 이름을 설정한 뒤 다시 시도하십시오.");
            return;
        }

        if (TryBlockManualAutomationCommand($"SCANNER_{axis.Head}_{axis.AxisRole}_{commandName}"))
        {
            return;
        }

        var commandText = commandName switch
        {
            "HOME" => "원점으로 복귀",
            "ENABLE" => "활성화",
            "DISABLE" => "비활성화",
            _ => commandName
        };

        if (!_manager.automation.IsSimul(axis.AutomationNo) &&
            !_manager.automation.IsConnect(axis.AutomationNo))
        {
            _lastCommand = $"SCANNER_{axis.Head}_{axis.AxisRole}_{commandName}";
            _lastResult = "OFFLINE";
            _setStatusMessage($"{axis.Head} {axis.AxisRole} {commandName} failed. Automation is offline.");
            RefreshCommandStateRows();
            _refreshShellStatus();
            CRecipeConfirmDialog.ShowWarning(
                "스캐너 축 제어 실패",
                "Automation 장비가 연결되어 있지 않아 동작을 실행할 수 없습니다.");
            return;
        }

        if (!CRecipeConfirmDialog.ShowConfirmation("스캐너 축 제어", $"{axis.Head} / {axis.AxisReference}축을 {commandText}하시겠습니까?"))
        {
            return;
        }

        _lastCommand = $"SCANNER_{axis.Head}_{axis.AxisRole}_{commandName}";
        _lastResult = "Sending";
        RefreshCommandStateRows();
        try
        {
            string response;
            if (commandName.Equals("HOME", StringComparison.OrdinalIgnoreCase))
            {
                response = await _manager.automation.HomeAsync(axis.AxisReference, axis.AutomationNo, cancellationToken);
            }
            else if (commandName.Equals("ENABLE", StringComparison.OrdinalIgnoreCase))
            {
                response = await _manager.automation.ServoOn(axis.AxisReference, axis.AutomationNo, cancellationToken);
            }
            else if (commandName.Equals("DISABLE", StringComparison.OrdinalIgnoreCase))
            {
                response = await _manager.automation.ServoOff(axis.AxisReference, axis.AutomationNo, cancellationToken);
            }
            else
            {
                throw new InvalidOperationException($"Scanner axis command is unknown: {commandName}.");
            }

            EnsureAutomationResponse(response, $"{commandName} {axis.Head} {axis.AxisRole}");
            _lastResult = $"OK: {axis.AxisReference}";
            _setStatusMessage($"{axis.Head} {axis.AxisRole} axis {axis.AxisReference} {commandName} command OK.");
            RefreshCommandStateRows();
            _refreshShellStatus();
            await _refreshCurrentScreen();
        }
        catch (Exception exception)when (exception is InvalidOperationException or IOException or TimeoutException or KeyNotFoundException)
        {
            _lastResult = $"ERROR: {exception.Message}";
            _setStatusMessage($"{axis.Head} {axis.AxisRole} {commandName} failed. {exception.Message}");
            RefreshCommandStateRows();
            _refreshShellStatus();
            await _refreshCurrentScreen();
            CRecipeConfirmDialog.ShowWarning(
                "스캐너 축 제어 실패",
                $"{axis.AxisRole}축 {commandText} 동작을 완료하지 못했습니다.\n{exception.Message}");
        }
    }

    private async Task SendVisionProtocolCommand()
    {
        if (IsVisionProtocolBusy)
        {
            return;
        }

        var interfaceManager = _manager.Interface();
        int SelectInterfaceNumber(ST_INTERFACE_DATA data)
        {
            return data.Number;
        }

        var interfaceData = interfaceManager
            .GetInterfaceList(EN_EQP_MODULE.Vision)
            .OrderBy(SelectInterfaceNumber)
            .FirstOrDefault();
        if (interfaceData is null)
        {
            const string message = "Vision interface is not configured.";
            AppendVisionProtocolLog("ERR", message);
            VisionProtocolStatus = "NOT CONFIGURED";
            _setStatusMessage(message);
            _refreshShellStatus();
            return;
        }

        IsVisionProtocolBusy = true;

        try
        {
            var function = BuildVisionProtocolFunction(validate: true);
            _setStatusMessage($"Vision protocol command sending: {SelectedVisionProtocolCommand.DisplayName}");
            _refreshShellStatus();
            var response = await interfaceManager.ExecuteFunction(
                EN_EQP_MODULE.Vision,
                interfaceData.Number,
                function,
                _menuLifetimeCancellation.Token);
            RefreshVisionProtocolStatus(writeLog: false);
            if (string.IsNullOrWhiteSpace(response))
            {
                var status = GetVisionProtocolCommunicationStatus(interfaceData.Number);
                var error = string.IsNullOrWhiteSpace(status?.LastError)
                    ? "No response was returned."
                    : status.LastError;
                AppendVisionProtocolLog("ERR", error);
                _setStatusMessage($"Vision protocol command failed. {error}");
            }
            else
            {
                _setStatusMessage($"Vision protocol command completed: {SelectedVisionProtocolCommand.DisplayName}");
            }
        }
        catch (OperationCanceledException)
        {
            AppendVisionProtocolLog("ERR", "Command canceled.");
            _setStatusMessage("Vision protocol command canceled.");
        }
        catch (Exception exception) when (exception is
            InvalidOperationException or IOException or TimeoutException or KeyNotFoundException or FormatException)
        {
            AppendVisionProtocolLog("ERR", exception.Message);
            VisionProtocolStatus = $"ERROR / {exception.Message}";
            _setStatusMessage($"Vision protocol command failed. {exception.Message}");
        }
        finally
        {
            IsVisionProtocolBusy = false;
            _refreshShellStatus();
        }
    }

    private void ResetVisionProtocolInputs()
    {
        _visionProtocolInspectionType = "0";
        VisionProtocolMarkRows.Clear();
        if (VisionProtocolUsesMarkRows)
        {
            VisionProtocolMarkRows.Add(CreateVisionProtocolMarkRow());
        }

        OnPropertyChanged(nameof(VisionProtocolCommandDescription));
        OnPropertyChanged(nameof(VisionProtocolUsesMarkRows));
        OnPropertyChanged(nameof(VisionProtocolIsFlyingReady));
        OnPropertyChanged(nameof(VisionProtocolHasNoArguments));
        OnPropertyChanged(nameof(VisionProtocolInspectionType));
        NotifyVisionProtocolInputChanged();
    }

    private void AddVisionProtocolMarkRow()
    {
        if (!VisionProtocolIsFlyingReady ||
            VisionProtocolMarkRows.Count >= CVisionProtocol.MaximumMarkCount)
        {
            return;
        }

        VisionProtocolMarkRows.Add(CreateVisionProtocolMarkRow());
        NotifyVisionProtocolInputChanged();
    }

    private void RemoveVisionProtocolMarkRow()
    {
        if (!VisionProtocolIsFlyingReady || VisionProtocolMarkRows.Count == 0)
        {
            return;
        }

        VisionProtocolMarkRows.RemoveAt(VisionProtocolMarkRows.Count - 1);
        NotifyVisionProtocolInputChanged();
    }

    private ST_MANUAL_VISION_MARK_SEARCH CreateVisionProtocolMarkRow()
    {
        return new ST_MANUAL_VISION_MARK_SEARCH(
            "1",
            "1",
            "1",
            "1",
            "1",
            "1",
            NotifyVisionProtocolInputChanged);
    }

    private void NotifyVisionProtocolInputChanged()
    {
        OnPropertyChanged(nameof(VisionProtocolRequestPreview));
        OnPropertyChanged(nameof(VisionProtocolMarkRowCountText));
        VisionProtocolAddMarkCommand.NotifyCanExecuteChanged();
        VisionProtocolRemoveMarkCommand.NotifyCanExecuteChanged();
    }

    private string BuildVisionProtocolFunction(bool validate)
    {
        var command = SelectedVisionProtocolCommand.CommandText;
        if (!VisionProtocolUsesMarkRows)
        {
            return command;
        }

        if (command == "MARK_FIND_SINGLE")
        {
            if (VisionProtocolMarkRows.Count != 1)
            {
                return validate
                    ? throw new FormatException("Mark Find Single은 Mark 입력 행이 1개여야 합니다.")
                    : $"{command}:입력 필요";
            }

            return $"{command}:{BuildVisionProtocolMarkSearch(VisionProtocolMarkRows[0], validate)}";
        }

        var inspectionType = NormalizeVisionProtocolInteger(
            VisionProtocolInspectionType,
            "Inspection Type",
            validate);
        var marks = new string[VisionProtocolMarkRows.Count];
        for (var index = 0; index < VisionProtocolMarkRows.Count; index++)
        {
            marks[index] = BuildVisionProtocolMarkSearch(
                VisionProtocolMarkRows[index],
                validate);
        }

        return $"{command}:{inspectionType}:{string.Join(';', marks)}";
    }

    private static string BuildVisionProtocolMarkSearch(
        ST_MANUAL_VISION_MARK_SEARCH row,
        bool validate)
    {
        return string.Join(
            ',',
            NormalizeVisionProtocolInteger(row.CellNo, "Cell No", validate),
            NormalizeVisionProtocolInteger(row.DoeNo, "DOE/Beam", validate),
            NormalizeVisionProtocolInteger(row.LineNo, "Line No", validate),
            NormalizeVisionProtocolInteger(row.IndexX, "Index X", validate),
            NormalizeVisionProtocolInteger(row.IndexY, "Index Y", validate),
            NormalizeVisionProtocolInteger(row.HeadNo, "Head No", validate));
    }

    private static string NormalizeVisionProtocolInteger(
        string value,
        string fieldName,
        bool validate)
    {
        var normalized = value.Trim();
        if (!validate)
        {
            return string.IsNullOrWhiteSpace(normalized) ? "?" : normalized;
        }

        return int.TryParse(normalized, NumberStyles.Integer, CultureInfo.InvariantCulture, out var parsed)
            ? parsed.ToString(CultureInfo.InvariantCulture)
            : throw new FormatException($"{fieldName}에는 정수를 입력해야 합니다. 입력값={value}");
    }

    private void RefreshVisionProtocolStatus(bool writeLog)
    {
        int SelectStatusNumber(ST_INTERFACE_COMM_STATUS item)
        {
            return item.Number;
        }

        var status = _manager.Interface()
            .GetInterfaceCommunicationList(EN_EQP_MODULE.Vision)
            .OrderBy(SelectStatusNumber)
            .FirstOrDefault();
        if (status is null)
        {
            VisionProtocolEndpoint = "-";
            VisionProtocolStatus = "NOT CONFIGURED";
            VisionProtocolKeepAlive = "NOT CONFIGURED";
            if (writeLog)
            {
                AppendVisionProtocolLog("ERR", "Vision interface is not configured.");
            }

            return;
        }

        VisionProtocolEndpoint = $"{status.NickName}[{status.Number}] / {status.Endpoint}";
        var state = status.IsSimulation
            ? "SIMULATION"
            : status.ConnectionState.ToString().ToUpperInvariant();
        if (status.IsSimulation)
        {
            VisionProtocolKeepAlive = "SIMULATION";
        }

        VisionProtocolStatus = string.IsNullOrWhiteSpace(status.LastError)
            ? state
            : $"{state} / {status.LastError}";
        if (writeLog)
        {
            AppendVisionProtocolLog("INFO", $"{VisionProtocolEndpoint} / {VisionProtocolStatus}");
        }
    }

    private ST_INTERFACE_COMM_STATUS? GetVisionProtocolCommunicationStatus(int number)
    {
        foreach (var status in _manager.Interface()
            .GetInterfaceCommunicationList(EN_EQP_MODULE.Vision))
        {
            if (status.Number == number)
            {
                return status;
            }
        }

        return null;
    }

    private ST_INTERFACE_COMM_STATUS? GetPrimaryVisionProtocolCommunicationStatus()
    {
        ST_INTERFACE_COMM_STATUS? selected = null;
        foreach (var status in _manager.Interface()
            .GetInterfaceCommunicationList(EN_EQP_MODULE.Vision))
        {
            if (selected is null || status.Number < selected.Number)
            {
                selected = status;
            }
        }

        return selected;
    }

    private void OnVisionProtocolTrace(ST_INTERFACE_PROTOCOL_TRACE trace)
    {
        if (trace.Module != EN_EQP_MODULE.Vision)
        {
            return;
        }

        var dispatcher = Application.Current?.Dispatcher;
        if (dispatcher is null || dispatcher.CheckAccess())
        {
            ApplyVisionProtocolTrace(trace);
            return;
        }

        void ApplyVisionProtocolTraceCallback()
        {
            ApplyVisionProtocolTrace(trace);
        }

        dispatcher.BeginInvoke(ApplyVisionProtocolTraceCallback);
    }

    private void ApplyVisionProtocolTrace(ST_INTERFACE_PROTOCOL_TRACE trace)
    {
        if (trace.Direction.Equals("PACKET", StringComparison.OrdinalIgnoreCase))
        {
            AppendVisionProtocolPacketLog(trace.OccurredAt, trace.Message);
        }
        else
        {
            AppendVisionProtocolLog(trace.Direction, $"{trace.NickName}[{trace.Number}] {trace.Message}");
        }

        if (trace.Message.Contains("Code : 1999", StringComparison.OrdinalIgnoreCase) ||
            trace.Message.Contains("CMD=1999", StringComparison.OrdinalIgnoreCase))
        {
            VisionProtocolKeepAlive = trace.Message.Contains("[RECV]", StringComparison.OrdinalIgnoreCase) ||
                                      trace.Direction.Equals("RX", StringComparison.OrdinalIgnoreCase)
                ? $"{trace.OccurredAt.LocalDateTime:HH:mm:ss.fff} RECEIVED"
                : $"{trace.OccurredAt.LocalDateTime:HH:mm:ss.fff} ACK SENT";
        }
        else if (trace.Message.Contains("KEEP-ALIVE TIMEOUT", StringComparison.OrdinalIgnoreCase))
        {
            VisionProtocolKeepAlive = "TIMEOUT";
        }
        else if (trace.Message.Contains("CLIENT_DISCONNECTED", StringComparison.OrdinalIgnoreCase))
        {
            VisionProtocolKeepAlive = "DISCONNECTED";
        }
        else if (trace.Message.Contains("CLIENT_CONNECTED", StringComparison.OrdinalIgnoreCase))
        {
            VisionProtocolKeepAlive = "WAITING";
        }

        RefreshVisionProtocolStatus(writeLog: false);
    }

    private void AppendVisionProtocolLog(string direction, string message)
    {
        AddVisionProtocolLogLine(
            $"{DateTime.Now:yy/MM/dd HH:mm:ss.fff} [{direction.Trim().ToUpperInvariant()}] {message}");
    }

    private void AppendVisionProtocolPacketLog(DateTimeOffset occurredAt, string message)
    {
        var timestamp = occurredAt.LocalDateTime.ToString(
            "yy/MM/dd HH:mm:ss.fff",
            CultureInfo.InvariantCulture);
        var lines = message.Split(
            ['\r', '\n'],
            StringSplitOptions.RemoveEmptyEntries);
        foreach (var line in lines)
        {
            AddVisionProtocolLogLine($"{timestamp} {line}");
        }
    }

    private void AddVisionProtocolLogLine(string line)
    {
        // UI log retention is independent of the variable-length inspection packet capacity.
        const int maxLogCount = 2048 + 40;
        while (VisionProtocolLogs.Count >= maxLogCount)
        {
            VisionProtocolLogs.RemoveAt(0);
        }

        VisionProtocolLogs.Add(line);
    }

    private async Task SelectSetting(object? parameter)
    {
        var settingName = GetManualSettingNameFromParameter(parameter);
        if (string.IsNullOrWhiteSpace(settingName))
        {
            return;
        }

        _selectedSettingNameSetter(settingName);
        _setStatusMessage($"Manual setting {settingName} selected.");
        _refreshShellStatus();
        await _refreshCurrentScreen();
    }

    private async Task Create()
    {
        var settingNames = await _scanFile.List();
        string ValidateNewSettingNameCallback(string value)
        {
            return ValidateManualSettingName(NormalizeManualSettingNameInput(value), settingNames);
        }

        var newSettingName = ShowManualSettingNameDialog("Manual Setting 생성", "새 Manual Setting 이름을 입력하세요.", "", ValidateNewSettingNameCallback);
        if (newSettingName is null)
        {
            _setStatusMessage("Manual setting create canceled.");
            return;
        }

        var validationMessage = ValidateManualSettingName(newSettingName, settingNames);
        if (!string.IsNullOrWhiteSpace(validationMessage))
        {
            _setStatusMessage(validationMessage);
            return;
        }

        if (!TryReadManualParamFromScreen(out var settings, out var errorMessage))
        {
            _setStatusMessage(errorMessage);
            ShowManualWarning(errorMessage);
            return;
        }

        if (!await TrySaveSetting(newSettingName, settings))
        {
            return;
        }

        _selectedSettingNameSetter(newSettingName);
        _setStatusMessage($"Manual setting {newSettingName} created and CSV verified.");
        _refreshShellStatus();
        await _refreshCurrentScreen();
    }

    private async Task Save()
    {
        if (string.IsNullOrWhiteSpace(LoadedSettingName))
        {
            _setStatusMessage("Manual setting save skipped. No manual setting is selected.");
            return;
        }

        if (!CRecipeConfirmDialog.ShowConfirmation("Manual Setting 저장", $"{LoadedSettingName} 설정을 저장하시겠습니까?"))
        {
            return;
        }

        if (!TryReadManualParamFromScreen(out var settings, out var errorMessage))
        {
            _setStatusMessage(errorMessage);
            ShowManualWarning(errorMessage);
            return;
        }

        if (!await TrySaveSetting(LoadedSettingName, settings))
        {
            return;
        }

        _selectedSettingNameSetter(LoadedSettingName);
        _setStatusMessage($"Manual setting {LoadedSettingName} saved and CSV verified.");
        _refreshShellStatus();
        await _refreshCurrentScreen();
        CRecipeConfirmDialog.ShowCompletion("Manual Setting 저장 완료", $"{LoadedSettingName} 설정을 저장하였습니다.");
    }

    private async Task Rename()
    {
        var oldSettingName = GetManualSettingNameFromParameter(LoadedSettingName);
        if (string.IsNullOrWhiteSpace(oldSettingName))
        {
            _setStatusMessage("Manual setting rename skipped. No manual setting is selected.");
            return;
        }

        var settingNames = await _scanFile.List();
        string ValidateRenamedSettingNameCallback(string value)
        {
            return ValidateManualSettingName(NormalizeManualSettingNameInput(value), settingNames, oldSettingName);
        }

        var newSettingName = ShowManualSettingNameDialog("Manual Setting 이름 변경", "변경할 Manual Setting 이름을 입력하세요.", Path.GetFileNameWithoutExtension(oldSettingName), ValidateRenamedSettingNameCallback);
        if (newSettingName is null)
        {
            _setStatusMessage("Manual setting rename canceled.");
            return;
        }

        if (newSettingName.Equals(oldSettingName, StringComparison.OrdinalIgnoreCase))
        {
            _setStatusMessage("Manual setting rename skipped. Name was not changed.");
            return;
        }

        var validationMessage = ValidateManualSettingName(newSettingName, settingNames, oldSettingName);
        if (!string.IsNullOrWhiteSpace(validationMessage))
        {
            _setStatusMessage(validationMessage);
            return;
        }

        if (!TryReadManualParamFromScreen(out var settings, out var errorMessage))
        {
            _setStatusMessage(errorMessage);
            ShowManualWarning(errorMessage);
            return;
        }

        if (!await TrySaveSetting(oldSettingName, settings))
        {
            return;
        }

        try
        {
            await _scanFile.Rename(oldSettingName, newSettingName);
            ScanAssignments.RenameSetting(oldSettingName, newSettingName);
        }
        catch (IOException exception)
        {
            _setStatusMessage($"Manual setting rename blocked. {exception.Message}");
            return;
        }

        _selectedSettingNameSetter(newSettingName);
        _setStatusMessage($"Manual setting {oldSettingName} renamed to {newSettingName}.");
        _refreshShellStatus();
        await _refreshCurrentScreen();
    }

    private async Task<bool> TrySaveSetting(string settingName, ST_MANUAL_SCAN_PARAM settings)
    {
        try
        {
            await _scanFile.Save(settingName, settings);
            return true;
        }
        catch (InvalidDataException exception)
        {
            _setStatusMessage(exception.Message);
            ShowManualWarning(exception.Message);
            return false;
        }
        catch (IOException exception)
        {
            _setStatusMessage($"Manual setting save blocked. {exception.Message}");
            return false;
        }
    }

    private async Task Delete()
    {
        var settingName = GetManualSettingNameFromParameter(LoadedSettingName);
        if (string.IsNullOrWhiteSpace(settingName))
        {
            _setStatusMessage("Manual setting delete skipped. No manual setting is selected.");
            return;
        }

        if (!ConfirmManualSettingDelete(settingName))
        {
            _setStatusMessage($"Manual setting {settingName} delete canceled.");
            return;
        }

        await _scanFile.Delete(settingName);
        var remainingSettings = await _scanFile.List();
        _selectedSettingNameSetter(remainingSettings.FirstOrDefault() ?? "CIRCLE_TEST.scan");
        _setStatusMessage($"Manual setting {settingName} deleted.");
        _refreshShellStatus();
        await _refreshCurrentScreen();
        CRecipeConfirmDialog.ShowCompletion("Manual Setting 삭제 완료", $"{settingName} 설정을 삭제하였습니다.");
    }

    private async Task CenterMove()
    {
        if (!CRecipeConfirmDialog.ShowConfirmation("중앙 이동", "스캐너를 중앙으로 이동하시겠습니까?"))
        {
            return;
        }

        void AppendCenterMoveScript(global::Drilling.Common.Station.CAutomation1ScriptBase script, global::Drilling.Common.Managers.ST_MANUAL_SCAN_PARAM arg1)
        {
            script.Jump(0.0, 0.0);
            script.WaitMoveDone();
        }

        await RunManualScript("CENTER_MOVE", AppendCenterMoveScript);
    }

    private async Task PositionMove()
    {
        ST_MANUAL_SCRIPT_AXES axes;
        try
        {
            var headNo = ReadEnabledManualScannerHeadNo(CancellationToken.None);
            axes = ReadManualScriptAxes(headNo, CancellationToken.None);
        }
        catch (Exception exception)when (exception is InvalidDataException or InvalidOperationException or IOException or TimeoutException or KeyNotFoundException)
        {
            _lastCommand = "POSITION_MOVE";
            _lastResult = $"ERROR: {exception.Message}";
            _setStatusMessage($"POSITION_MOVE failed. {exception.Message}");
            RefreshCommandStateRows();
            _refreshShellStatus();
            return;
        }

        if (!CRecipeConfirmDialog.ShowConfirmation("위치 이동", $"스캐너를 {axes.XAxis} = {TargetGx}, {axes.YAxis} = {TargetGy} 위치로 이동하시겠습니까?"))
        {
            return;
        }

        void AppendPositionMoveScript(global::Drilling.Common.Station.CAutomation1ScriptBase script, global::Drilling.Common.Managers.ST_MANUAL_SCAN_PARAM arg1)
        {
            var gx = ReadRequiredDouble(TargetGx, $"{axes.XAxis} Target");
            var gy = ReadRequiredDouble(TargetGy, $"{axes.YAxis} Target");
            script.Jump(gx, gy);
            script.WaitMoveDone();
        }

        await RunManualScript("POSITION_MOVE", AppendPositionMoveScript);
    }

    private async Task ZPositionMove()
    {
        var commandName = "Z_MOVE";
        if (TryBlockManualAutomationCommand(commandName))
        {
            return;
        }

        ST_MANUAL_SCRIPT_Z_AXIS zAxis;
        int headNo;
        double targetPosition;
        double zSpeed;
        double zRampRate;
        try
        {
            headNo = ReadEnabledManualScannerHeadNo(CancellationToken.None);
            zAxis = ReadManualScriptZAxis(headNo, CancellationToken.None);
            targetPosition = ReadRequiredDouble(TargetGz, $"{zAxis.Axis} Target");
            var selectedRecipe = await LoadSelectedRecipe(CancellationToken.None);
            zSpeed = ReadHeadRecipeDouble(selectedRecipe, headNo, 1.0, "SCANNER_Z_SPEED");
            zRampRate = ReadHeadRecipeDouble(selectedRecipe, headNo, 500000.0, "SCANNER_Z_RAMP_RATE");
            if (!double.IsFinite(zSpeed) || zSpeed <= 0.0)
            {
                throw new InvalidDataException($"H{headNo:00} Scanner Z Speed must be greater than 0. Value={zSpeed.ToString(CultureInfo.InvariantCulture)}");
            }

            if (!double.IsFinite(zRampRate) || zRampRate <= 0.0)
            {
                throw new InvalidDataException($"H{headNo:00} Scanner Z Ramp Rate must be greater than 0. Value={zRampRate.ToString(CultureInfo.InvariantCulture)}");
            }
        }
        catch (Exception exception)when (exception is InvalidDataException or InvalidOperationException or IOException or TimeoutException or KeyNotFoundException)
        {
            _lastCommand = commandName;
            _lastResult = $"ERROR: {exception.Message}";
            _setStatusMessage($"{commandName} failed. {exception.Message}");
            RefreshCommandStateRows();
            _refreshShellStatus();
            CRecipeConfirmDialog.ShowWarning(
                "Z축 이동 실패",
                $"Z축 이동 조건을 확인하지 못했습니다.\n{exception.Message}");
            return;
        }

        if (!_manager.automation.IsSimul(zAxis.AutomationNo) && !_manager.automation.IsConnect(zAxis.AutomationNo))
        {
            _lastCommand = commandName;
            _lastResult = "ERROR: OFFLINE";
            _setStatusMessage($"{commandName} failed. Automation{zAxis.AutomationNo.ToString(CultureInfo.InvariantCulture)} is offline.");
            RefreshCommandStateRows();
            _refreshShellStatus();
            CRecipeConfirmDialog.ShowWarning(
                "Z축 이동 실패",
                "Automation 장비가 연결되어 있지 않아 Z축 이동을 실행할 수 없습니다.");
            return;
        }

        if (!CRecipeConfirmDialog.ShowConfirmation("Z축 이동", $"{zAxis.Axis}축을 {TargetGz} 위치로 이동하시겠습니까?"))
        {
            return;
        }

        await RunManualZPositionScript(headNo, zAxis, targetPosition, zSpeed, zRampRate);
    }

    private async Task MoveStop()
    {
        await StopManualTask("MOVE_STOP");
    }

    private Task SelectShape(object? parameter)
    {
        var shapeName = NormalizeShapeName(parameter?.ToString() ?? "");
        ShapeName = shapeName;
        _lastCommand = "SELECT_SHAPE";
        _lastResult = shapeName;
        _setStatusMessage($"Manual shape selected: {shapeName}.");
        return Task.CompletedTask;
    }

    private async Task ShapeStart(bool useCurrentPosition)
    {
        await RunSelectedManualShapeScans(useCurrentPosition);
    }

    private async Task ShapeStop()
    {
        await StopSelectedManualShapeScans();
    }

    private async Task LaserOn(bool useCurrentPosition)
    {
        await RunSelectedManualLaserActions(useCurrentPosition);
    }

    private void AppendLaserOnScript(CAutomation1ScriptBase script, ST_MANUAL_SCAN_PARAM settings)
    {
        if (!int.TryParse(LaserRepeatCount?.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out var repeatCount) || repeatCount < 1)
        {
            throw new InvalidDataException("Repeat Count는 1 이상의 정수로 입력해 주세요.");
        }

        var repeatDelayMsec = ReadRequiredDouble(LaserRepeatDelayTimeMsec, "Repeat Delay Time");
        if (!double.IsFinite(repeatDelayMsec) || repeatDelayMsec < 0.0)
        {
            throw new InvalidDataException("Repeat Delay Time은 0 이상의 유한한 숫자로 입력해 주세요. (msec)");
        }

        var laserActionSettings = ReadLaserActionSettings(settings);
        var onTimeMsec = ReadLaserMoveDelaySeconds(laserActionSettings);
        void AppendLaserCycle()
        {
            script.SetMoveDelay(laserActionSettings.LaserOnDelay, applyMinimumDelay: false);
            script.LaserOn();
            script.SetMoveDelay(onTimeMsec);
            script.LaserOff();
            script.SetMoveDelay(laserActionSettings.LaserOffDelay, applyMinimumDelay: false);
        }
        if (repeatCount > 1)
        {
            // Keep script size bounded; emit the last block separately so it has no trailing delay.
            script.AddLine($"repeat {repeatCount - 1}");
            AppendLaserCycle();
            if (repeatDelayMsec > 0.0)
            {
                script.SetMoveDelay(repeatDelayMsec, applyMinimumDelay: false);
            }

            script.AddLine("end");
        }

        AppendLaserCycle();
    }

    private async Task LaserOff()
    {
        await StopAllManualLasers();
    }

    private async Task CenterOn()
    {
        if (!CRecipeConfirmDialog.ShowConfirmation("레이저 동작", "중앙 위치로 이동한 후 레이저를 동작시키시겠습니까?"))
        {
            return;
        }

        void AppendCenterOnScript(global::Drilling.Common.Station.CAutomation1ScriptBase script, global::Drilling.Common.Managers.ST_MANUAL_SCAN_PARAM settings)
        {
            var laserActionSettings = ReadLaserActionSettings(settings);
            var moveDelaySeconds = ReadLaserMoveDelaySeconds(laserActionSettings);
            script.Jump(0.0, 0.0);
            script.WaitMoveDone();
            script.SetMoveDelay(laserActionSettings.LaserOnDelay, applyMinimumDelay: false);
            script.LaserOn();
            script.SetMoveDelay(moveDelaySeconds);
            script.LaserOff();
            script.SetMoveDelay(laserActionSettings.LaserOffDelay, applyMinimumDelay: false);
        }

        await RunManualScript("CENTER_ON", AppendCenterOnScript, ApplyLaserActionScriptSetup);
        if (!_lastResult.StartsWith("ERROR", StringComparison.OrdinalIgnoreCase))
        {
            _laserState = "OFF";
            _centerState = "OFF";
        }
    }

    private Task<ST_MANUAL_DIO_TARGET> ResolveDioTarget(int headNo, CancellationToken cancellationToken)
        => Task.FromResult(CreateManualDioTarget(_manager.Setting().LoadSection(EN_SETTING_TAB.Option, cancellationToken), headNo));

    private static ST_MANUAL_DIO_TARGET CreateManualDioTarget(IReadOnlyList<ST_SYSTEM_PARAMETER> settings, int headNo)
    {
        if (headNo is < 1 or > 8)
        {
            throw new InvalidOperationException($"Manual scanner DIO head number is invalid: {headNo}. Use H01-H08.");
        }

        var automationNo = ReadOptionalHeadSettingInt(settings, headNo <= 4 ? 0 : 1, headNo, "AUTOMATION_NO");
        var defaultGxAxisNo = ((headNo - 1) % 4) * 2;
        var gxAxisNo = ReadOptionalHeadSettingInt(settings, defaultGxAxisNo, headNo, "GX_AXIS_NO");
        var gxAxisName = ReadHeadSettingText(settings, $"GX_{headNo.ToString(CultureInfo.InvariantCulture)}", headNo, "X_AXIS", "GX_AXIS");
        ValidateDioAxisNo(headNo, gxAxisNo);
        var dioNo = ReadRequiredHeadSettingInt(settings, headNo, "SCANNER_DIO_NO");
        ValidateDioNo(headNo, dioNo);
        var address = $"A{gxAxisNo.ToString(CultureInfo.InvariantCulture)}.DO{dioNo.ToString(CultureInfo.InvariantCulture)}";
        return new ST_MANUAL_DIO_TARGET(automationNo, address, gxAxisName, dioNo);
    }

    private void ApplyDioTarget(ST_MANUAL_DIO_TARGET target)
    {
        _dioAutomationNo = target.AutomationNo;
        DioAddress = target.Address;
        DioAxisName = target.AxisName;
        DioNo = target.DioNo.ToString(CultureInfo.InvariantCulture);
        DioLastResult = "Ready";
        IsDioTargetReady = true;
    }

    private void InvalidateDioTarget(string result)
    {
        _dioAutomationNo = 0;
        DioAddress = "";
        DioAxisName = "-";
        DioNo = "-";
        DioCurrentValue = "UNKNOWN";
        DioLastResult = result;
        IsDioTargetReady = false;
    }

    private long BeginDioTargetRefresh(string result)
    {
        var generation = Interlocked.Increment(ref _dioGeneration);
        InvalidateDioTarget(result);
        return generation;
    }

    private bool IsCurrentDioGeneration(long generation)
    {
        return Interlocked.Read(ref _dioGeneration) == generation;
    }

    private static void ValidateDioAxisNo(int headNo, int axisNo)
    {
        if (axisNo < 0)
        {
            throw new InvalidOperationException($"H{headNo:00} scanner GX axis number is invalid: {axisNo}.");
        }
    }

    private static void ValidateDioNo(int headNo, int dioNo)
    {
        if (dioNo == UnconfiguredScannerDioNo)
        {
            throw new InvalidOperationException($"H{headNo:00} scanner DIO number is not configured.");
        }

        if (dioNo is < 0 or > 63)
        {
            throw new InvalidOperationException($"H{headNo:00} scanner DIO number must be between 0 and 63. Value={dioNo}.");
        }
    }

    private static int ReadOptionalHeadSettingInt(IReadOnlyList<ST_SYSTEM_PARAMETER> settings, int defaultValue, int headNo, params string[] suffixes)
    {
        return TryFindHeadSetting(settings, headNo, suffixes, out var key, out var value) ? ParseHeadSettingInt(headNo, key, value) : defaultValue;
    }

    private static int ReadRequiredHeadSettingInt(IReadOnlyList<ST_SYSTEM_PARAMETER> settings, int headNo, params string[] suffixes)
    {
        if (!TryFindHeadSetting(settings, headNo, suffixes, out var key, out var value))
        {
            throw new InvalidOperationException($"H{headNo:00} scanner DIO number is not configured.");
        }

        return ParseHeadSettingInt(headNo, key, value);
    }

    private static bool TryFindHeadSetting(IReadOnlyList<ST_SYSTEM_PARAMETER> settings, int headNo, IReadOnlyList<string> suffixes, out string key, out string value)
    {
        var prefix = $"H{headNo:00}_";
        foreach (var suffix in suffixes)
        {
            var searchKey = prefix + suffix;
            bool MatchesHeadSettingKey(global::Drilling.Common.Managers.ST_SYSTEM_PARAMETER item)
            {
                return searchKey.Equals(item.Key, StringComparison.OrdinalIgnoreCase) || searchKey.Equals(item.Name, StringComparison.OrdinalIgnoreCase);
            }

            var setting = settings.FirstOrDefault(MatchesHeadSettingKey);
            if (setting is not null)
            {
                key = searchKey;
                value = setting.Value;
                return true;
            }
        }

        key = "";
        value = "";
        return false;
    }

    private static int ParseHeadSettingInt(int headNo, string key, string value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            throw new InvalidOperationException($"H{headNo:00} setting {key} is empty.");
        }

        if (!int.TryParse(value.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out var parsed))
        {
            throw new InvalidOperationException($"H{headNo:00} setting {key} must be an integer. Value={value}");
        }

        return parsed;
    }

    private static string ReadHeadSettingText(IReadOnlyList<ST_SYSTEM_PARAMETER> settings, string defaultValue, int headNo, params string[] suffixes)
    {
        var prefix = $"H{headNo:00}_";
        foreach (var suffix in suffixes)
        {
            var key = prefix + suffix;
            bool MatchesHeadSettingKey(global::Drilling.Common.Managers.ST_SYSTEM_PARAMETER item)
            {
                return key.Equals(item.Key, StringComparison.OrdinalIgnoreCase) || key.Equals(item.Name, StringComparison.OrdinalIgnoreCase);
            }

            var setting = settings.FirstOrDefault(MatchesHeadSettingKey);
            if (setting is not null && !string.IsNullOrWhiteSpace(setting.Value))
            {
                return setting.Value.Trim();
            }
        }

        return defaultValue;
    }

    private async Task RefreshDioState(string commandName = "DIO_READ", bool recordCommand = true, bool showStatus = true, long? expectedGeneration = null, CancellationToken cancellationToken = default)
    {
        if (!TryBeginDioCommand(commandName, recordCommand, showStatus, "Reading", expectedGeneration, out var target))
        {
            return;
        }

        try
        {
            var response = await _manager.automation.ReadIo(target.Address, target.AutomationNo, cancellationToken: cancellationToken);
            EnsureAutomationResponse(response, $"{commandName} read");
            var dioValue = ReadDioValueFromResponse(response);
            if (!IsCurrentDioGeneration(target.Generation))
            {
                return;
            }

            DioCurrentValue = dioValue;
            DioLastResult = $"Current {dioValue}";
            if (recordCommand)
            {
                _lastResult = DioLastResult;
            }

            if (showStatus)
            {
                _setStatusMessage($"Manual scanner DIO {target.Address} read: {dioValue}.");
            }
        }
        catch (Exception exception)when (exception is InvalidOperationException or IOException or TimeoutException or KeyNotFoundException)
        {
            if (!IsCurrentDioGeneration(target.Generation))
            {
                return;
            }

            DioCurrentValue = "UNKNOWN";
            DioLastResult = $"ERROR: {exception.Message}";
            if (recordCommand)
            {
                _lastResult = DioLastResult;
            }

            if (showStatus)
            {
                _setStatusMessage($"{commandName} failed. {exception.Message}");
            }
        }
        finally
        {
            IsDioControlBusy = false;
            if (recordCommand)
            {
                RefreshCommandStateRows();
            }

            if (showStatus)
            {
                _refreshShellStatus();
            }
        }
    }

    private async Task SetDioOutput(bool isOn, CancellationToken cancellationToken = default)
    {
        var commandName = isOn ? "DIO_ON" : "DIO_OFF";
        if (!TryBeginDioCommand(commandName, recordCommand: true, showStatus: true, "Sending", expectedGeneration: null, out var target))
        {
            return;
        }

        try
        {
            var response = await _manager.automation.SetIo(target.Address, isOn, target.AutomationNo, cancellationToken: cancellationToken);
            EnsureAutomationResponse(response, $"{commandName} output");
            var dioValue = ReadDioValueFromResponse(response);
            var expectedValue = isOn ? "ON" : "OFF";
            if (!dioValue.Equals(expectedValue, StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException($"DIO output state mismatch. Requested={expectedValue}, Response={dioValue}.");
            }

            if (!IsCurrentDioGeneration(target.Generation))
            {
                return;
            }

            DioCurrentValue = dioValue;
            DioLastResult = $"Output {dioValue}";
            _lastResult = DioLastResult;
            _setStatusMessage($"Manual scanner DIO {target.Address} set to {dioValue}.");
        }
        catch (Exception exception)when (exception is InvalidOperationException or IOException or TimeoutException or KeyNotFoundException)
        {
            if (!IsCurrentDioGeneration(target.Generation))
            {
                return;
            }

            DioCurrentValue = "UNKNOWN";
            DioLastResult = $"ERROR: {exception.Message}";
            _lastResult = DioLastResult;
            _setStatusMessage($"{commandName} failed. {exception.Message}");
        }
        finally
        {
            IsDioControlBusy = false;
            RefreshCommandStateRows();
            _refreshShellStatus();
        }
    }

    private bool TryBeginDioCommand(string commandName, bool recordCommand, bool showStatus, string pendingResult, long? expectedGeneration, out ST_ACTIVE_DIO_TARGET target)
    {
        target = default;
        if (expectedGeneration.HasValue && !IsCurrentDioGeneration(expectedGeneration.Value))
        {
            return false;
        }

        if (IsAutoProcessRunning())
        {
            var message = "Auto process is running. Manual scanner DIO command is blocked.";
            if (recordCommand)
            {
                _lastCommand = commandName;
                _lastResult = message;
                RefreshCommandStateRows();
            }

            DioLastResult = message;
            if (showStatus)
            {
                _setStatusMessage(message);
                _refreshShellStatus();
            }

            return false;
        }

        if (IsDioControlBusy)
        {
            var message = "Manual scanner DIO command is already running.";
            if (recordCommand)
            {
                _lastCommand = commandName;
                _lastResult = message;
                RefreshCommandStateRows();
            }

            if (showStatus)
            {
                _setStatusMessage(message);
                _refreshShellStatus();
            }

            return false;
        }

        var generation = Interlocked.Read(ref _dioGeneration);
        if (expectedGeneration.HasValue && generation != expectedGeneration.Value)
        {
            return false;
        }

        if (!IsDioTargetReady || string.IsNullOrWhiteSpace(DioAddress))
        {
            var message = "Manual scanner DIO target is not ready.";
            DioCurrentValue = "UNKNOWN";
            DioLastResult = message;
            if (recordCommand)
            {
                _lastCommand = commandName;
                _lastResult = message;
                RefreshCommandStateRows();
            }

            if (showStatus)
            {
                _setStatusMessage(message);
                _refreshShellStatus();
            }

            return false;
        }

        if (recordCommand)
        {
            _lastCommand = commandName;
            _lastResult = pendingResult;
        }

        DioLastResult = pendingResult;
        IsDioControlBusy = true;
        target = new ST_ACTIVE_DIO_TARGET(generation, _dioAutomationNo, DioAddress);
        return true;
    }

    private async Task RunManualScript(string commandName, Action<CAutomation1ScriptBase, ST_MANUAL_SCAN_PARAM> buildScript, Action<CAutomation1ScriptBase, ST_MANUAL_SCAN_PARAM>? setupScript = null, string? scriptFileName = null, CancellationToken cancellationToken = default)
    {
        if (TryBlockManualAutomationCommand(commandName))
        {
            return;
        }

        CancelStatusPolling();
        _lastCommand = commandName;
        _lastResult = "Building";

        try
        {
            var headNo = ReadEnabledManualScannerHeadNo(cancellationToken);
            var options = _manager.Setting().LoadSection(EN_SETTING_TAB.Option, cancellationToken);
            var automationNo = ReadManualHeadAutomationNo(options, headNo);
            if (!_manager.automation.IsSimul(automationNo) && !_manager.automation.IsConnect(automationNo))
                throw new InvalidOperationException($"CONTROLLER {automationNo + 1}이 연결되어 있지 않습니다.");
            var settings = commandName == "LASER_OFF" ? CreateFallbackManualParam() : await ReadAssignedManualScanParam(headNo, cancellationToken);
            var fileName = string.IsNullOrWhiteSpace(scriptFileName) ? $"MANUAL_H{headNo:00}_{NormalizeScriptName(commandName)}.ascript" : $"{NormalizeScriptName(scriptFileName)}.ascript";
            var script = _scriptFile.Create(fileName);
            script.SetDeviceNo(headNo - 1);
            SetManualScriptAxes(script, headNo, cancellationToken);
            AppendManualSettingComment(script, settings);
            script.Start($"Manual H{headNo:00} {commandName}");
            (setupScript ?? ApplyManualScriptSetup)(script, settings);
            buildScript(script, settings);
            script.End();
            var savedScript = script.Save(cancellationToken);
            var uploadResponse = await _manager.automation.UploadScript(savedScript.FilePath, savedScript.FileName, number: automationNo, cancellationToken: cancellationToken);
            EnsureAutomationResponse(uploadResponse, $"{commandName} upload");
            _lastManualScriptAutomationNo = automationNo;
            var runResponse = await _manager.automation.RunScript(savedScript.FileName, ManualTaskIndex, number: automationNo, cancellationToken: cancellationToken);
            EnsureAutomationResponse(runResponse, $"{commandName} run");
            _lastResult = $"Running {savedScript.FileName}";
            _setStatusMessage($"{commandName} script uploaded and started: {savedScript.FileName}");
            var statusCancellation = CreateStatusPollingCancellation(cancellationToken);
            var statusToken = statusCancellation.Token;
            try
            {
                await WaitManualTaskCompleted(
                    runResponse,
                    requireExecutionStart: !_manager.automation.IsSimul(automationNo),
                    automationNo: automationNo,
                    cancellationToken: statusToken);
                statusToken.ThrowIfCancellationRequested();
            }
            finally
            {
                ReleaseStatusPollingCancellation(statusCancellation);
            }
            _lastResult = $"Completed {savedScript.FileName}";
            _setStatusMessage($"{commandName} completed: {savedScript.FileName}");
            RefreshCommandStateRows();
            _refreshShellStatus();
        }
        catch (OperationCanceledException)
        {
            // 화면을 벗어나면 완료 상태 조회와 후속 팝업만 중단한다.
            // 이미 Automation1에 전달된 실제 동작은 별도의 정지 명령 없이 계속된다.
        }
        catch (Exception exception)when (exception is InvalidDataException or InvalidOperationException or IOException or TimeoutException or KeyNotFoundException)
        {
            _lastResult = $"ERROR: {exception.Message}";
            _setStatusMessage($"{commandName} failed. {exception.Message}");
            RefreshCommandStateRows();
            _refreshShellStatus();
            if (exception is InvalidDataException)
            {
                ShowManualWarning(exception.Message);
            }
            else
            {
                CRecipeConfirmDialog.ShowWarning(
                    "수동 동작 실패",
                    $"동작을 완료하지 못했습니다.\n{exception.Message}");
            }
        }

    }

    private async Task RunManualZPositionScript(int headNo, ST_MANUAL_SCRIPT_Z_AXIS zAxis, double targetPosition, double zSpeed, double zRampRate, CancellationToken cancellationToken = default)
    {
        var commandName = "Z_MOVE";
        CancelStatusPolling();
        _lastCommand = commandName;
        _lastResult = "Building";

        try
        {
            var fileName = $"MANUAL_H{headNo:00}_Z_MOVE.ascript";
            var script = _scriptFile.Create(fileName);
            script.SetDeviceNo(headNo - 1);
            script.Start($"Manual H{headNo:00} {commandName}");
            AppendManualZMoveScript(script, zAxis.Axis, targetPosition, zSpeed, zRampRate);
            script.End();
            var savedScript = script.Save(cancellationToken);
            var uploadResponse = await _manager.automation.UploadScript(savedScript.FilePath, savedScript.FileName, zAxis.AutomationNo, cancellationToken);
            EnsureAutomationResponse(uploadResponse, $"{commandName} upload");
            var runResponse = await _manager.automation.RunScript(savedScript.FileName, ManualTaskIndex, zAxis.AutomationNo, cancellationToken);
            EnsureAutomationResponse(runResponse, $"{commandName} run");
            _lastResult = $"Running {savedScript.FileName}";
            _setStatusMessage($"{commandName} script uploaded and started: {savedScript.FileName}");
            var statusCancellation = CreateStatusPollingCancellation(cancellationToken);
            var statusToken = statusCancellation.Token;
            try
            {
                await WaitManualTaskCompleted(
                    runResponse,
                    requireExecutionStart: !_manager.automation.IsSimul(zAxis.AutomationNo),
                    automationNo: zAxis.AutomationNo,
                    taskNo: ManualTaskIndex,
                    cancellationToken: statusToken);
                statusToken.ThrowIfCancellationRequested();
            }
            finally
            {
                ReleaseStatusPollingCancellation(statusCancellation);
            }

            TargetGz = FormatDouble(targetPosition, 3);
            _lastResult = $"Completed {savedScript.FileName}";
            _setStatusMessage($"{commandName} completed: {savedScript.FileName}");
            RefreshCommandStateRows();
            _refreshShellStatus();
        }
        catch (OperationCanceledException)
        {
            // 화면을 벗어나면 완료 상태 조회와 후속 팝업만 중단한다.
            // 이미 Automation1에 전달된 실제 동작은 별도의 정지 명령 없이 계속된다.
        }
        catch (Exception exception)when (exception is InvalidDataException or InvalidOperationException or IOException or TimeoutException or KeyNotFoundException)
        {
            _lastResult = $"ERROR: {exception.Message}";
            _setStatusMessage($"{commandName} failed. {exception.Message}");
            RefreshCommandStateRows();
            _refreshShellStatus();
            CRecipeConfirmDialog.ShowWarning(
                "Z축 이동 실패",
                $"Z축 이동을 완료하지 못했습니다.\n{exception.Message}");
        }
    }

    private static void AppendManualZMoveScript(CAutomation1ScriptBase script, string zAxis, double targetPosition, double zSpeed, double zRampRate)
    {
        script.AddLine("IfovOff()");
        script.AddLine("SetupTaskDistanceUnits(DistanceUnits.Primary)");
        script.AddLine("SetupTaskTimeUnits(TimeUnits.Seconds)");
        script.AddLine("VelocityBlendingOff()");
        script.AddLine("SetupTaskWaitMode(WaitMode.Auto)");
        script.AddLine("SetupTaskTargetMode(TargetMode.Absolute)");
        script.AddLine($"SetupAxisRampType([{zAxis}], RampType.Sine)");
        script.AddLine($"SetupAxisRampValue([{zAxis}], RampMode.Rate, {FormatDouble(zRampRate, 6)})");
        script.AddLine($"MoveAbsolute({zAxis}, {FormatDouble(targetPosition, 6)}, {FormatDouble(zSpeed, 6)})");
        script.AddLine($"WaitForMotionDone({zAxis})");
    }

    private void SetManualScriptAxes(CAutomation1ScriptBase script, int headNo, CancellationToken cancellationToken)
    {
        var axes = ReadManualScriptAxes(headNo, cancellationToken);
        script.SetAxis(axes.XAxis, axes.YAxis);
    }

    private ST_MANUAL_SCRIPT_AXES ReadManualScriptAxes(int headNo, CancellationToken cancellationToken)
    {
        var optionSettings = _manager.Setting().LoadSection(EN_SETTING_TAB.Option, cancellationToken);
        var definitions = CScannerStatusSnapshotReader.BuildAxisDefinitions(optionSettings, headNo);
        var xAxis = "";
        var yAxis = "";
        foreach (var definition in definitions)
        {
            if (definition.AxisName.Equals("X", StringComparison.OrdinalIgnoreCase))
            {
                xAxis = definition.AxisReference;
            }
            else if (definition.AxisName.Equals("Y", StringComparison.OrdinalIgnoreCase))
            {
                yAxis = definition.AxisReference;
            }
        }

        if (string.IsNullOrWhiteSpace(xAxis) || string.IsNullOrWhiteSpace(yAxis))
        {
            throw new InvalidOperationException($"H{headNo:00} scanner axis settings are not configured.");
        }

        return new ST_MANUAL_SCRIPT_AXES(xAxis, yAxis);
    }

    private ST_MANUAL_SCRIPT_Z_AXIS ReadManualScriptZAxis(int headNo, CancellationToken cancellationToken)
    {
        var optionSettings = _manager.Setting().LoadSection(EN_SETTING_TAB.Option, cancellationToken);
        var zAxis = FindScannerAxisDefinition(optionSettings, headNo, "Z");
        if (zAxis is null || !zAxis.Value.IsUsed)
        {
            throw new InvalidOperationException($"H{headNo:00} scanner Z axis is not used.");
        }

        if (!string.IsNullOrWhiteSpace(zAxis.Value.ConfigurationError))
        {
            throw new InvalidOperationException(zAxis.Value.ConfigurationError);
        }

        if (!IsConfiguredScannerAxisName(zAxis.Value.AxisReference))
        {
            throw new InvalidOperationException($"H{headNo:00} scanner Z axis settings are not configured.");
        }

        return new ST_MANUAL_SCRIPT_Z_AXIS(zAxis.Value.AxisReference, zAxis.Value.AutomationNo);
    }

    private bool TryBlockManualAutomationCommand(string commandName)
    {
        if (_manager.Station().ManualMofStatus is { IsRunning: true } or { RequiresStop: true })
        {
            ShowManualWarning("MOF 가공이 실행 중이거나 정지가 확인되지 않았습니다. MOF STOP 후 실행해 주세요.");
            return true;
        }
        if (IsManualMotionScriptActive && commandName is not "MANUAL_MOTION" and not "MOVE_STOP")
        {
            ShowManualWarning("수동 이동 스크립트가 실행 중이거나 정지가 확인되지 않았습니다. 완료 또는 MOVE STOP 후 실행해 주세요.");
            return true;
        }
        // A faulted Task can require RESET before STOP can be verified on retry.
        var canRecoverStoppedScan = _activeManualShapeScan is null && !_manualShapeScanStopInProgress &&
            _activeManualLaserAction is null && !_manualLaserOffInProgress &&
            (commandName.Equals("SCANNER_FAULT_CLEAR", StringComparison.OrdinalIgnoreCase) ||
             commandName.StartsWith("CONTROLLER_", StringComparison.OrdinalIgnoreCase) && commandName.EndsWith("_RESET", StringComparison.OrdinalIgnoreCase));
        if (IsManualShapeScanActive && !canRecoverStoppedScan && !commandName.Equals("SHAPE_START", StringComparison.OrdinalIgnoreCase))
        {
            const string scanMessage = "수동 가공이 진행 중이거나 정지가 확인되지 않았습니다. LASER OFF 또는 Scan STOP으로 정지한 후 실행해 주세요.";
            _setStatusMessage(scanMessage);
            ShowManualWarning(scanMessage);
            return true;
        }
        if (!IsAutoProcessRunning())
        {
            return false;
        }

        var message = "Auto process is running. Manual Automation1 command is blocked.";
        _lastCommand = commandName;
        _lastResult = message;
        RefreshCommandStateRows();
        _setStatusMessage(message);
        _refreshShellStatus();
        return true;
    }

    private bool IsAutoProcessRunning()
    {
        try
        {
            var snapshot = _manager.Station().GetStatus(CancellationToken.None);
            return snapshot.ScriptStatus == EN_SCRIPT_STATUS.Running || snapshot.ProcessStep is EN_PROCESS_STEP.PowerCheck or EN_PROCESS_STEP.Align or EN_PROCESS_STEP.Process or EN_PROCESS_STEP.Inspection;
        }
        catch
        {
            return false;
        }
    }

    private async Task StopManualTask(string commandName, CancellationToken cancellationToken = default)
    {
        if (TryBlockManualAutomationCommand(commandName))
        {
            return;
        }

        CancelStatusPolling();
        _lastCommand = commandName;
        _lastResult = "Stopping";
        var automationNo = _lastManualScriptAutomationNo ?? 0;

        if (!_manager.automation.IsSimul(automationNo) && !_manager.automation.IsConnect(automationNo))
        {
            _lastResult = "ERROR: OFFLINE";
            _setStatusMessage($"{commandName} failed. Automation1 is offline.");
            RefreshCommandStateRows();
            _refreshShellStatus();
            CRecipeConfirmDialog.ShowWarning(
                "수동 동작 실패",
                "Automation 장비가 연결되어 있지 않아 정지 명령을 실행할 수 없습니다.");
            return;
        }

        try
        {
            var response = await _manager.automation.StopTask(ManualTaskIndex, number: automationNo, cancellationToken: cancellationToken);
            EnsureAutomationResponse(response, $"{commandName} stop");
            var statusCancellation = CreateStatusPollingCancellation(cancellationToken);
            var statusToken = statusCancellation.Token;
            try
            {
                await WaitManualTaskCompleted(
                    response,
                    requireExecutionStart: false,
                    automationNo: automationNo,
                    cancellationToken: statusToken);
                statusToken.ThrowIfCancellationRequested();
            }
            finally
            {
                ReleaseStatusPollingCancellation(statusCancellation);
            }
            _laserState = "OFF";
            _centerState = "OFF";
            _lastResult = "Stopped";
            _setStatusMessage($"{commandName} command sent.");
            RefreshCommandStateRows();
            _refreshShellStatus();
        }
        catch (OperationCanceledException)
        {
            // 메뉴 이탈로 상태 확인이 취소된 경우 완료/실패 팝업을 표시하지 않는다.
        }
        catch (Exception exception)when (exception is InvalidOperationException or IOException or TimeoutException or KeyNotFoundException)
        {
            _lastResult = $"ERROR: {exception.Message}";
            _setStatusMessage($"{commandName} failed. {exception.Message}");
            RefreshCommandStateRows();
            _refreshShellStatus();
            CRecipeConfirmDialog.ShowWarning(
                "수동 동작 실패",
                $"정지 동작을 완료하지 못했습니다.\n{exception.Message}");
        }

    }

    private CancellationTokenSource CreateStatusPollingCancellation(CancellationToken cancellationToken)
    {
        lock (_menuLifetimeSync)
        {
            _statusPollingCancellation?.Cancel();
            _statusPollingCancellation?.Dispose();
            _statusPollingCancellation = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken, _menuLifetimeCancellation.Token);
            return _statusPollingCancellation;
        }
    }

    private void CancelStatusPolling()
    {
        lock (_menuLifetimeSync)
        {
            _statusPollingCancellation?.Cancel();
            _statusPollingCancellation?.Dispose();
            _statusPollingCancellation = null;
        }
    }

    private void ReleaseStatusPollingCancellation(CancellationTokenSource cancellation)
    {
        lock (_menuLifetimeSync)
        {
            if (!ReferenceEquals(_statusPollingCancellation, cancellation))
            {
                return;
            }

            _statusPollingCancellation = null;
            cancellation.Dispose();
        }
    }

    private async Task WaitManualTaskCompleted(string initialResponse, bool requireExecutionStart, int automationNo = 0, int taskNo = ManualTaskIndex, CancellationToken cancellationToken = default)
    {
        var response = initialResponse;
        var executionStarted = !requireExecutionStart;
        while (true)
        {
            var fields = response.Split(':');
            if (fields.Length < 4 || !fields[0].Equals("OK", StringComparison.OrdinalIgnoreCase) || !fields[1].Equals("TASK", StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException($"Automation1 task status response is invalid: {response}");
            }

            var state = fields[3].Trim();
            if (state.Equals("ProgramComplete", StringComparison.OrdinalIgnoreCase) ||
                executionStarted && state.Equals("Idle", StringComparison.OrdinalIgnoreCase))
            {
                return;
            }

            if (state.Equals("Error", StringComparison.OrdinalIgnoreCase) || state.Equals("Unavailable", StringComparison.OrdinalIgnoreCase) || state.Equals("Inactive", StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException($"Automation1 manual task failed. State={state}, Response={response}");
            }

            if (!state.Equals("Idle", StringComparison.OrdinalIgnoreCase))
            {
                executionStarted = true;
            }

            await Task.Delay(100, cancellationToken);
            response = await _manager.automation.ReadTaskStatus(taskNo, automationNo, cancellationToken);
        }
    }

    private void RefreshCommandStateRows()
    {
        bool IsSelectedHeadCard(global::Drilling.UI.Menu.Menus.ST_MANUAL_HEAD_CARD head)
        {
            return head.HeadNo == _selectedHeadNoProvider();
        }

        var selectedHead = HeadCards.FirstOrDefault(IsSelectedHeadCard);
        bool IsFallbackSelectedHeadCard(global::Drilling.UI.Menu.Menus.ST_MANUAL_HEAD_CARD head)
        {
            return head.IsSelected;
        }

        if (selectedHead is null)
        {
            var optionSettings = _manager.Setting().LoadSection(EN_SETTING_TAB.Option, CancellationToken.None);
            var selectedHeadNo = NormalizeManualScannerHeadNo(optionSettings, Math.Clamp(_selectedHeadNoProvider(), 1, 8));
            var scannerAxes = ReadManualScannerAxesSnapshot(optionSettings, selectedHeadNo);
            selectedHead = BuildHeadCards(selectedHeadNo, optionSettings, scannerAxes).FirstOrDefault(IsFallbackSelectedHeadCard);
        }

        selectedHead ??= new ST_MANUAL_HEAD_CARD(Math.Clamp(_selectedHeadNoProvider(), 1, 8), "H--", "X -", "Y -", "Z -", "Disabled", true);

        var settings = TryReadManualParamFromScreen(out var currentSettings, out _) ? currentSettings : CreateFallbackManualParam();
        CommandStateItems = [new("Laser", _laserState), new("CENTER", _centerState), new("Last Command", _lastCommand), new("Result", _lastResult)];
        CommandStateRows = BuildCommandStateRows(selectedHead);
        OnPropertyChanged(nameof(CommandStateItems));
        OnPropertyChanged(nameof(CommandStateRows));
    }

    private static void ApplyManualScriptSetup(CAutomation1ScriptBase script, ST_MANUAL_SCAN_PARAM settings)
    {
        script.DefaultSetting(resetPso: false);
        script.SetFrequency(settings.LaserFrequency);
        script.SetLaserDelay(0.0, 0.0);
        script.SetLaserPower(settings.LaserPower);
        script.SetJumpSpeed(settings.JumpSpeed);
        script.SetMarkSpeed(settings.MarkSpeed);
    }

    private void ApplyLaserActionScriptSetup(CAutomation1ScriptBase script, ST_MANUAL_SCAN_PARAM settings)
    {
        ApplyManualScriptSetup(script, ReadLaserActionSettings(settings));
    }

    private static void ApplyManualLaserOffScriptSetup(CAutomation1ScriptBase script, ST_MANUAL_SCAN_PARAM _)
    {
        script.DefaultSetting(resetPso: false);
    }

    private static void ApplyManualFigureScanSetup(CAutomation1ScriptBase script, ST_MANUAL_SCAN_PARAM settings)
    {
        script.DefaultFigureScanSetting(moveToCenter: false);
        script.SetJumpSpeed(settings.JumpSpeed);
        script.SetMarkSpeed(settings.MarkSpeed);
        script.SetMoveDelay(0.0);
        script.SetScannerAcc(50000.0);
        script.SetLaserDelay(0.0, 0.0);
        script.SetFrequency(settings.LaserFrequency);
        // Optical output (W) is set by the ATT before this script runs.
        script.SetLaserPowerNoDelay(100.0);
        script.SetLaserMode(0);
        script.LaserAuto();
    }

    private static void AppendManualSettingComment(CAutomation1ScriptBase script, ST_MANUAL_SCAN_PARAM settings)
    {
        script.AddLine($"// ManualSetting LaserPower={FormatDouble(settings.LaserPower, 3)} W");
        script.AddLine($"// ManualSetting JumpSpeed={FormatDouble(settings.JumpSpeed, 3)} m/sec");
        script.AddLine($"// ManualSetting MarkSpeed={FormatDouble(settings.MarkSpeed, 3)} m/sec");
        script.AddLine($"// ManualSetting Frequency={FormatDouble(settings.LaserFrequency, 3)} kHz");
        script.AddLine($"// ManualSetting Delay={FormatDouble(settings.LaserOnDelay, 3)}/{FormatDouble(settings.LaserOffDelay, 3)} msec");
        script.AddLine($"// ManualSetting Grid={settings.GridRowLines}x{settings.GridColLines}");
    }

    private void AppendShape(CAutomation1ScriptBase script, ST_MANUAL_SCAN_PARAM settings)
    {
        var shapeName = NormalizeShapeName(settings.ShapeName);
        var cx = settings.OffsetX;
        var cy = settings.OffsetY;
        var half = Math.Abs(settings.ShapeSize) / 2.0;
        switch (shapeName.ToUpperInvariant())
        {
            case "CROSS":
                DrawLine(script, cx - half, cy, cx + half, cy, settings.LaserOnDelay, settings.LaserOffDelay);
                DrawLine(script, cx, cy - half, cx, cy + half, settings.LaserOnDelay, settings.LaserOffDelay);
                break;
            case "RECT":
                DrawRect(script, cx, cy, half, settings.Direction, settings.LaserOnDelay, settings.LaserOffDelay);
                break;
            case "GRID":
                DrawGrid(script, cx, cy, half, settings.GridRowLines, settings.GridColLines, settings.LaserOnDelay, settings.LaserOffDelay);
                break;
            case "H-LINE":
            case "HLINE":
                DrawLine(script, cx - half, cy, cx + half, cy, settings.LaserOnDelay, settings.LaserOffDelay);
                break;
            case "V-LINE":
            case "VLINE":
                DrawLine(script, cx, cy - half, cx, cy + half, settings.LaserOnDelay, settings.LaserOffDelay);
                break;
            default:
                DrawCircle(script, cx, cy, half, settings.Direction, settings.LaserOnDelay, settings.LaserOffDelay);
                break;
        }
    }

    private static void DrawGrid(CAutomation1ScriptBase script, double cx, double cy, double half, int rows, int cols,
        double onDelayMsec, double offDelayMsec)
    {
        var rowCount = Math.Max(2, rows);
        var colCount = Math.Max(2, cols);
        var left = cx - half;
        var right = cx + half;
        var bottom = cy - half;
        var top = cy + half;
        for (var row = 0; row < rowCount; row++)
        {
            var y = bottom + ((top - bottom) * row / (rowCount - 1));
            if (row % 2 == 0)
            {
                DrawLine(script, left, y, right, y, onDelayMsec, offDelayMsec);
            }
            else
            {
                DrawLine(script, right, y, left, y, onDelayMsec, offDelayMsec);
            }
        }

        for (var col = 0; col < colCount; col++)
        {
            var x = left + ((right - left) * col / (colCount - 1));
            if (col % 2 == 0)
            {
                DrawLine(script, x, bottom, x, top, onDelayMsec, offDelayMsec);
            }
            else
            {
                DrawLine(script, x, top, x, bottom, onDelayMsec, offDelayMsec);
            }
        }
    }

    private static void DrawLine(CAutomation1ScriptBase script, double startX, double startY, double endX, double endY,
        double onDelayMsec, double offDelayMsec)
    {
        script.Jump(startX, startY);
        script.SetMoveDelay(onDelayMsec, applyMinimumDelay: false);
        script.Mark(endX, endY);
        script.SetMoveDelay(offDelayMsec, applyMinimumDelay: false);
    }

    private static void DrawRect(CAutomation1ScriptBase script, double cx, double cy, double half, string direction,
        double onDelayMsec, double offDelayMsec)
    {
        var points = new List<(double X, double Y)>
        {
            (cx - half, cy - half),
            (cx + half, cy - half),
            (cx + half, cy + half),
            (cx - half, cy + half),
            (cx - half, cy - half)
        };
        if (direction.Equals("CCW", StringComparison.OrdinalIgnoreCase))
        {
            points.Reverse();
        }

        for (var index = 0; index < points.Count - 1; index++)
        {
            DrawLine(script, points[index].X, points[index].Y, points[index + 1].X, points[index + 1].Y,
                onDelayMsec, offDelayMsec);
        }
    }

    private static void DrawCircle(CAutomation1ScriptBase script, double cx, double cy, double radius, string direction,
        double onDelayMsec, double offDelayMsec)
    {
        if (radius <= 0.0)
        {
            radius = 0.0005;
        }

        var angle = direction.Equals("CCW", StringComparison.OrdinalIgnoreCase) ? -360.0 : 360.0;
        var startX = cx - radius;
        var startY = cy;
        script.Jump(startX, startY);
        script.SetMoveDelay(onDelayMsec, applyMinimumDelay: false);
        script.Arc(startX, startY, startX, startY, cx, cy, angle);
        script.SetMoveDelay(offDelayMsec, applyMinimumDelay: false);
    }

    private static void EnsureAutomationResponse(string response, string action)
    {
        if (string.IsNullOrWhiteSpace(response))
        {
            throw new InvalidOperationException($"{action} failed. Check Automation connection.");
        }

        if (ContainsAutomationFailureToken(response))
        {
            throw new InvalidOperationException($"{action} failed. {FormatAutomationFailureResponse(response)}");
        }
    }

    private static string ReadDioValueFromResponse(string response)
    {
        var tokens = response.Split(':', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries);
        if (tokens.Any(IsAutomationFailureToken))
        {
            throw new InvalidOperationException($"Automation1 DIO response failed: {response}");
        }

        bool IsOnOffToken(string token)
        {
            return token.Equals("ON", StringComparison.OrdinalIgnoreCase) || token.Equals("OFF", StringComparison.OrdinalIgnoreCase);
        }

        var value = tokens.LastOrDefault(IsOnOffToken);
        if (value is null)
        {
            throw new InvalidOperationException($"Automation1 DIO response is invalid: {response}");
        }

        return value.ToUpperInvariant();
    }

    private static bool ContainsAutomationFailureToken(string response)
    {
        var tokens = response.Split(':', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries);
        for (var index = 0; index < tokens.Length; index++)
        {
            if (IsAutomationFailureToken(tokens[index]))
            {
                return true;
            }
        }

        return false;
    }

    private static string FormatAutomationFailureResponse(string response)
    {
        if (string.IsNullOrWhiteSpace(response))
        {
            return "<empty>";
        }

        var fields = response.Trim().Split(':', 4, StringSplitOptions.TrimEntries);
        if (fields.Length >= 4 && fields[0].Equals("ERROR", StringComparison.OrdinalIgnoreCase) && fields[1].Equals("AUTOMATION1", StringComparison.OrdinalIgnoreCase))
        {
            return $"{fields[2]}: {fields[3]}";
        }

        return response.Trim();
    }

    private static bool IsAutomationFailureToken(string token)
    {
        return token.Equals("ERROR", StringComparison.OrdinalIgnoreCase) || token.Equals("ERR", StringComparison.OrdinalIgnoreCase) || token.Equals("FAIL", StringComparison.OrdinalIgnoreCase) || token.Equals("FAILED", StringComparison.OrdinalIgnoreCase) || token.Equals("NG", StringComparison.OrdinalIgnoreCase) || token.Equals("NAK", StringComparison.OrdinalIgnoreCase);
    }

    private bool TryReadManualParamFromScreen(out ST_MANUAL_SCAN_PARAM settings, out string errorMessage)
    {
        try
        {
            settings = ReadManualParamFromScreen();
            errorMessage = "";
            return true;
        }
        catch (InvalidDataException exception)
        {
            settings = CreateFallbackManualParam();
            errorMessage = exception.Message;
            return false;
        }
    }

    private ST_MANUAL_SCAN_PARAM ReadManualParamFromScreen()
    {
        var settings = new ST_MANUAL_SCAN_PARAM(
            ReadManualDouble("ShapeSize"), ReadManualDouble("OffsetX"), ReadManualDouble("OffsetY"),
            ReadManualText(FindManualParameter("Direction")), ReadManualText(FindManualParameter("ShapeName")),
            ReadManualDouble("LaserPower"), ReadManualDouble("JumpSpeed"), ReadManualDouble("MarkSpeed"), 0.0,
            ReadManualDouble("LaserFrequency"), ReadManualDouble("LaserOnDelay"), ReadManualDouble("LaserOffDelay"),
            ReadManualDouble("Time"), ReadManualInt("Count"), ReadManualInt("GridRowLines"), ReadManualInt("GridColLines"),
            ReadManualText(FindManualParameter("LaserOnMode")), ReadManualInt("RepeatCount"), ReadManualDouble("RepeatDelayTime"));
        ValidateManualScanParameters(settings, []);
        return settings;
    }

    private void Apply(IReadOnlyList<ST_DISPLAY_ITEM> manualSettings, IReadOnlyList<ST_DISPLAY_ITEM> selectedHeadItems, IReadOnlyList<ST_DISPLAY_ITEM> positionMoveItems, IReadOnlyList<ST_DISPLAY_ITEM> shapeScanItems, IReadOnlyList<ST_DISPLAY_ITEM> commandStateItems, string selectedHead, string loadedSettingName, string loadedSettingPath, IReadOnlyList<ST_MANUAL_HEAD_CARD> headCards, IReadOnlyList<ST_MANUAL_SETTING_FILE> settingFiles, IReadOnlyList<ST_MANUAL_PARAMETER> settingParameters, IReadOnlyList<ST_MANUAL_COMMAND_STATE> commandStateRows, IReadOnlyList<ST_MANUAL_SCANNER_AXIS> scannerAxes)
    {
        ManualSettings = manualSettings;
        SelectedHeadItems = selectedHeadItems;
        PositionMoveItems = positionMoveItems;
        ShapeScanItems = shapeScanItems;
        CommandStateItems = commandStateItems;
        SelectedHead = selectedHead;
        LoadedSettingName = loadedSettingName;
        LoadedSettingPath = loadedSettingPath;
        HeadCards = headCards;
        HeadGroups = BuildHeadGroups(headCards);
        SettingFiles = settingFiles;
        SettingParameters = settingParameters;
        CommandStateRows = commandStateRows;
        ScannerAxes = scannerAxes;
    }

    private static IReadOnlyList<ST_DISPLAY_ITEM> BuildManualSettings(ST_MANUAL_SCAN_PARAM settings)
    {
        return[new("Laser Power", FormatDouble(settings.LaserPower, 2), "W"), new("Jump Speed", FormatDouble(settings.JumpSpeed, 3), "m/sec"), new("Mark Speed", FormatDouble(settings.MarkSpeed, 3), "m/sec"), new("Laser Frequency", FormatDouble(settings.LaserFrequency, 3), "kHz"), new("Laser On Delay", FormatDouble(settings.LaserOnDelay, 3), "msec"), new("Laser Off Delay", FormatDouble(settings.LaserOffDelay, 3), "msec")];
    }

    private static IReadOnlyList<ST_DISPLAY_ITEM> BuildSelectedHeadItems(ST_MANUAL_HEAD_CARD selectedHead)
    {
        return
        [
            new("Head", selectedHead.HeadName),
            new("X Axis", selectedHead.XSummary),
            new("Y Axis", selectedHead.YSummary),
            new("Z Axis", selectedHead.ZSummary),
            new("Servo", selectedHead.State),
            new("Motion", selectedHead.State)
        ];
    }

    private IReadOnlyList<ST_MANUAL_SCANNER_AXIS> ReadManualScannerAxesSnapshot(IReadOnlyList<ST_SYSTEM_PARAMETER> settings, int selectedHeadNo)
    {
        _scannerStatusSnapshotReader.SelectHeads(_manualHeadSelectionInitialized ? SelectedManualHeadNos : [selectedHeadNo], settings);
        var snapshot = _scannerStatusSnapshotReader.GetSnapshot().Where(axis => axis.HeadNo == selectedHeadNo).ToArray();
        if (snapshot.Length > 0)
        {
            return snapshot;
        }

        return CManualScannerSnapshotReader.BuildFallbackAxes(settings, selectedHeadNo);
    }

    private static IReadOnlyList<ST_MANUAL_HEAD_CARD> BuildHeadCards(int selectedHeadNo, IReadOnlyList<ST_SYSTEM_PARAMETER> settings, IReadOnlyList<ST_MANUAL_SCANNER_AXIS> selectedScannerAxes)
    {
        const int headCount = 8;
        var enabledHeadNos = CScannerStatusSnapshotReader.BuildEnabledHeadNumbers(settings, headCount);
        var cards = new List<ST_MANUAL_HEAD_CARD>(headCount);
        for (var headNo = 1; headNo <= headCount; headNo++)
        {
            var automationNo = ReadManualHeadAutomationNo(settings, headNo);
            cards.Add(enabledHeadNos.Contains(headNo)
                ? Head(headNo, selectedHeadNo, automationNo, settings, selectedScannerAxes)
                : new ST_MANUAL_HEAD_CARD(headNo, $"H{headNo:00}", "X NOT USE", "Y NOT USE", "Z NOT USE", "NOT USE", enabledHeadNos.Count == 0 && headNo == selectedHeadNo, false, automationNo));
        }

        return cards;
    }

    private static int NormalizeManualScannerHeadNo(IReadOnlyList<ST_SYSTEM_PARAMETER> settings, int selectedHeadNo)
    {
        var enabledHeadNos = CScannerStatusSnapshotReader.BuildEnabledHeadNumbers(settings);
        return enabledHeadNos.Count == 0 || enabledHeadNos.Contains(selectedHeadNo) ? selectedHeadNo : enabledHeadNos[0];
    }

    private int ReadEnabledManualScannerHeadNo(CancellationToken cancellationToken)
    {
        var optionSettings = _manager.Setting().LoadSection(EN_SETTING_TAB.Option, cancellationToken);
        var enabledHeadNos = CScannerStatusSnapshotReader.BuildEnabledHeadNumbers(optionSettings);
        if (enabledHeadNos.Count == 0)
        {
            throw new InvalidOperationException("No manual scanner head is enabled. Check Hxx_USE option settings.");
        }

        var selectedHeadNo = Math.Clamp(_selectedHeadNoProvider(), 1, 8);
        return enabledHeadNos.Contains(selectedHeadNo) ? selectedHeadNo : enabledHeadNos[0];
    }

    private static int ReadManualHeadAutomationNo(IReadOnlyList<ST_SYSTEM_PARAMETER> settings, int headNo)
    {
        return ReadOptionalHeadSettingInt(settings, headNo <= 4 ? 0 : 1, headNo, "AUTOMATION_NO");
    }

    private static int ReadManualHeadAutomationTaskNo(IReadOnlyList<ST_SYSTEM_PARAMETER> settings, int headNo)
    {
        var defaultTaskNo = ((headNo - 1) % 4) + 1;
        return Math.Max(1, ReadOptionalHeadSettingInt(settings, defaultTaskNo, headNo, "AUTOMATION_TASK_NO"));
    }

    private static IReadOnlyList<ST_CONTROLLER_HOME_TASK> BuildControllerHomeTasks(IReadOnlyList<ST_SYSTEM_PARAMETER> settings, int automationNo)
    {
        const int headCount = 8;
        var axesByTask = new SortedDictionary<int, List<string>>();
        var headsByTask = new SortedDictionary<int, List<int>>();
        var axisSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        for (var headNo = 1; headNo <= headCount; headNo++)
        {
            var taskNo = ReadManualHeadAutomationTaskNo(settings, headNo);
            var definitions = CScannerStatusSnapshotReader.BuildAxisDefinitions(settings, headNo);
            var headHasAxis = false;
            for (var index = 0; index < definitions.Count; index++)
            {
                var definition = definitions[index];
                if (definition.AutomationNo != automationNo)
                {
                    continue;
                }

                if (!definition.IsUsed)
                {
                    continue;
                }

                if (!string.IsNullOrWhiteSpace(definition.ConfigurationError))
                {
                    throw new InvalidOperationException(definition.ConfigurationError);
                }

                if (string.IsNullOrWhiteSpace(definition.AxisReference))
                {
                    throw new InvalidOperationException($"H{headNo:00} {definition.AxisName} axis name is not configured.");
                }

                if (!axisSet.Add(definition.AxisReference))
                {
                    continue;
                }

                if (!axesByTask.TryGetValue(taskNo, out var axes))
                {
                    axes = [];
                    axesByTask.Add(taskNo, axes);
                    headsByTask.Add(taskNo, []);
                }

                axes.Add(definition.AxisReference);
                headHasAxis = true;
            }

            if (headHasAxis && headsByTask.TryGetValue(taskNo, out var heads) && !heads.Contains(headNo))
            {
                heads.Add(headNo);
            }
        }

        var tasks = new List<ST_CONTROLLER_HOME_TASK>(axesByTask.Count);
        foreach (var item in axesByTask)
        {
            var heads = headsByTask.TryGetValue(item.Key, out var taskHeads) ? taskHeads : [];
            tasks.Add(new ST_CONTROLLER_HOME_TASK(item.Key, heads, item.Value));
        }

        return tasks;
    }

    private static string FormatControllerHomeAxisList(IReadOnlyList<ST_CONTROLLER_HOME_TASK> homeTasks)
    {
        var axes = new List<string>();
        foreach (var homeTask in homeTasks)
        {
            for (var index = 0; index < homeTask.AxisReferences.Count; index++)
            {
                axes.Add(homeTask.AxisReferences[index]);
            }
        }

        return string.Join(",", axes);
    }

    private static string FormatControllerHomeTaskSummary(IReadOnlyList<ST_CONTROLLER_HOME_TASK> homeTasks)
    {
        var items = new List<string>(homeTasks.Count);
        foreach (var homeTask in homeTasks)
        {
            items.Add($"TASK {homeTask.TaskNo}: {string.Join(",", homeTask.AxisReferences)}");
        }

        return string.Join(Environment.NewLine, items);
    }

    private static string BuildControllerHomeScriptFileName(ST_CONTROLLER_HOME_TASK homeTask)
    {
        return $"MANUAL_{FormatControllerHomeHeadSummary(homeTask.HeadNos)}_ALL_HOME.ascript";
    }

    private static string FormatControllerHomeHeadSummary(IReadOnlyList<int> headNos)
    {
        if (headNos.Count == 0)
        {
            return "HEAD";
        }

        var names = new List<string>(headNos.Count);
        for (var index = 0; index < headNos.Count; index++)
        {
            names.Add($"H{headNos[index]:00}");
        }

        return string.Join("_", names);
    }

    private static string FormatControllerHomeRunSummary(IReadOnlyList<ST_CONTROLLER_HOME_RUN> runItems)
    {
        var items = new List<string>(runItems.Count);
        foreach (var runItem in runItems)
        {
            items.Add($"T{runItem.TaskNo}:{runItem.ScriptFileName}");
        }

        return string.Join(", ", items);
    }

    private static IReadOnlyList<ST_MANUAL_HEAD_GROUP> BuildHeadGroups(IReadOnlyList<ST_MANUAL_HEAD_CARD> headCards)
    {
        var groupedHeads = new SortedDictionary<int, List<ST_MANUAL_HEAD_CARD>>();
        for (var index = 0; index < headCards.Count; index++)
        {
            var head = headCards[index];
            if (!groupedHeads.TryGetValue(head.AutomationNo, out var heads))
            {
                heads = [];
                groupedHeads.Add(head.AutomationNo, heads);
            }

            heads.Add(head);
        }

        var groups = new List<ST_MANUAL_HEAD_GROUP>(groupedHeads.Count);
        foreach (var item in groupedHeads)
        {
            groups.Add(new ST_MANUAL_HEAD_GROUP(item.Key, $"CONTROLLER {item.Key + 1}", item.Value));
        }

        return groups;
    }

    private static ST_MANUAL_HEAD_CARD Head(int headNo, int selectedHeadNo, int automationNo, IReadOnlyList<ST_SYSTEM_PARAMETER> settings, IReadOnlyList<ST_MANUAL_SCANNER_AXIS> selectedScannerAxes)
    {
        var definitions = CScannerStatusSnapshotReader.BuildAxisDefinitions(settings, headNo);
        var xSummary = FormatHeadAxisSummary(headNo, "X", definitions, selectedScannerAxes);
        var ySummary = FormatHeadAxisSummary(headNo, "Y", definitions, selectedScannerAxes);
        var zSummary = FormatHeadAxisSummary(headNo, "Z", definitions, selectedScannerAxes);
        var state = headNo == selectedHeadNo ? FormatManualHeadState(selectedScannerAxes) : "Ready";
        return new ST_MANUAL_HEAD_CARD(headNo, $"H{headNo:00}", xSummary, ySummary, zSummary, state, headNo == selectedHeadNo, true, automationNo);
    }

    private static string FormatHeadAxisSummary(int headNo, string axisName, IReadOnlyList<ST_SCANNER_AXIS_SETTING> definitions, IReadOnlyList<ST_MANUAL_SCANNER_AXIS> selectedScannerAxes)
    {
        foreach (var axis in selectedScannerAxes)
        {
            if (axis.HeadNo == headNo && axis.AxisRole.Equals(axisName, StringComparison.OrdinalIgnoreCase))
            {
                if (IsManualScannerAxisNotUsed(axis))
                {
                    return $"{axisName} NOT USE";
                }

                return $"{axisName} {axis.AxisReference} {axis.CurrentPosition}";
            }
        }

        foreach (var definition in definitions)
        {
            if (definition.AxisName.Equals(axisName, StringComparison.OrdinalIgnoreCase))
            {
                if (!definition.IsUsed)
                {
                    return $"{axisName} NOT USE";
                }

                return $"{axisName} {definition.AxisReference}";
            }
        }

        return $"{axisName} -";
    }

    private static string FormatManualHeadState(IReadOnlyList<ST_MANUAL_SCANNER_AXIS> axes)
    {
        var hasError = false;
        var allReady = axes.Count > 0;
        foreach (var axis in axes)
        {
            if (IsManualScannerAxisNotUsed(axis))
            {
                continue;
            }

            if (axis.Error.Equals("ERROR", StringComparison.OrdinalIgnoreCase) || axis.Error.Equals("OFFLINE", StringComparison.OrdinalIgnoreCase))
            {
                hasError = true;
            }

            if (!axis.Enable.Equals("ENABLE", StringComparison.OrdinalIgnoreCase) || !axis.Home.Equals("OK", StringComparison.OrdinalIgnoreCase))
            {
                allReady = false;
            }
        }

        if (hasError)
        {
            return "Error";
        }

        return allReady ? "Ready" : "Wait";
    }

    private static bool IsManualScannerAxisNotUsed(ST_MANUAL_SCANNER_AXIS axis)
    {
        return axis.AxisReference.Equals("Z NOT USE", StringComparison.OrdinalIgnoreCase) || axis.Enable.Equals("NOT USE", StringComparison.OrdinalIgnoreCase);
    }

    private static string ResolveSelectedSettingName(IReadOnlyList<string> settingNames, string selectedSettingName)
    {
        if (settingNames.Count == 0)
        {
            return "CIRCLE_TEST.scan";
        }

        var normalizedSelectedName = NormalizeSettingName(selectedSettingName);
        bool MatchesSelectedSettingName(string name)
        {
            return name.Equals(normalizedSelectedName, StringComparison.OrdinalIgnoreCase);
        }

        bool MatchesDefaultSettingName(string name)
        {
            return name.Equals("CIRCLE_TEST.scan", StringComparison.OrdinalIgnoreCase);
        }

        return settingNames.FirstOrDefault(MatchesSelectedSettingName) ?? settingNames.FirstOrDefault(MatchesDefaultSettingName) ?? settingNames[0];
    }

    private void SyncSettingFilesPage(IReadOnlyList<string> orderedSettingNames, string selectedSettingName)
    {
        _settingFilesPageCount = GetSettingFilesPageCount(orderedSettingNames.Count);
        if (!_lastSettingListSelectedName.Equals(selectedSettingName, StringComparison.OrdinalIgnoreCase))
        {
            var selectedSettingIndex = FindSettingNameIndex(orderedSettingNames, selectedSettingName);
            if (selectedSettingIndex >= 0)
            {
                _settingFilesPageIndex = selectedSettingIndex / SettingFilesPageSize;
            }
        }

        if (_settingFilesPageCount <= 0)
        {
            _settingFilesPageIndex = 0;
            SettingFilesPageText = "PAGE 0 / 0";
        }
        else
        {
            if (_settingFilesPageIndex < 0)
            {
                _settingFilesPageIndex = 0;
            }

            if (_settingFilesPageIndex >= _settingFilesPageCount)
            {
                _settingFilesPageIndex = _settingFilesPageCount - 1;
            }

            SettingFilesPageText = $"PAGE {_settingFilesPageIndex + 1} / {_settingFilesPageCount}";
        }

        _lastSettingListSelectedName = selectedSettingName;
        NotifySettingFilesPageCommands();
    }

    private static int GetSettingFilesPageCount(int settingFileCount)
    {
        if (settingFileCount <= 0)
        {
            return 0;
        }

        return ((settingFileCount - 1) / SettingFilesPageSize) + 1;
    }

    private static int FindSettingNameIndex(IReadOnlyList<string> settingNames, string selectedSettingName)
    {
        for (var index = 0; index < settingNames.Count; index++)
        {
            if (settingNames[index].Equals(selectedSettingName, StringComparison.OrdinalIgnoreCase))
            {
                return index;
            }
        }

        return -1;
    }

    private static IReadOnlyList<string> OrderSettingNames(IReadOnlyList<string> settingNames)
    {
        var orderedSettingNames = new List<string>(settingNames.Count);
        for (var index = 0; index < settingNames.Count; index++)
        {
            orderedSettingNames.Add(settingNames[index]);
        }

        orderedSettingNames.Sort(StringComparer.OrdinalIgnoreCase);
        return orderedSettingNames;
    }

    private static IReadOnlyList<ST_MANUAL_SETTING_FILE> BuildSettingFiles(IReadOnlyList<string> orderedSettingNames, string selectedSettingName, int pageIndex)
    {
        var startIndex = Math.Max(0, pageIndex) * SettingFilesPageSize;
        if (startIndex >= orderedSettingNames.Count)
        {
            return [];
        }

        var itemCount = Math.Min(SettingFilesPageSize, orderedSettingNames.Count - startIndex);
        var settingFiles = new List<ST_MANUAL_SETTING_FILE>(itemCount);
        for (var index = 0; index < itemCount; index++)
        {
            var settingName = orderedSettingNames[startIndex + index];
            settingFiles.Add(new ST_MANUAL_SETTING_FILE(settingName, settingName.Equals(selectedSettingName, StringComparison.OrdinalIgnoreCase)));
        }

        return settingFiles;
    }

    private static IReadOnlyList<ST_MANUAL_PARAMETER> BuildSettingParameters(ST_MANUAL_SCAN_PARAM settings, IReadOnlyList<ST_MANUAL_SCAN_FORM> formItems)
    {
        var values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            ["ShapeSize"] = FormatDouble(settings.ShapeSize, 3),
            ["OffsetX"] = FormatDouble(settings.OffsetX, 3),
            ["OffsetY"] = FormatDouble(settings.OffsetY, 3),
            ["Direction"] = settings.Direction,
            ["ShapeName"] = settings.ShapeName,
            ["GridRowLines"] = settings.GridRowLines.ToString(CultureInfo.InvariantCulture),
            ["GridColLines"] = settings.GridColLines.ToString(CultureInfo.InvariantCulture),
            ["LaserPower"] = FormatDouble(settings.LaserPower, 2),
            ["JumpSpeed"] = FormatDouble(settings.JumpSpeed, 3),
            ["MarkSpeed"] = FormatDouble(settings.MarkSpeed, 3),
            ["LaserFrequency"] = FormatDouble(settings.LaserFrequency, 3),
            ["LaserOnDelay"] = FormatDouble(settings.LaserOnDelay, 3),
            ["LaserOffDelay"] = FormatDouble(settings.LaserOffDelay, 3),
            ["LaserOnMode"] = settings.LaserOnMode?.Trim().ToUpperInvariant() ?? "",
            ["Time"] = settings.Time.ToString("R", CultureInfo.InvariantCulture),
            ["Count"] = settings.Count.ToString(CultureInfo.InvariantCulture),
            ["RepeatCount"] = settings.RepeatCount.ToString(CultureInfo.InvariantCulture),
            ["RepeatDelayTime"] = settings.RepeatDelayTime.ToString("R", CultureInfo.InvariantCulture)
        };
        ST_MANUAL_SCAN_FORM[] requiredParameters =
        [
            new("ShapeName", "Shape Type", EN_RECIPE_DATA_TYPE.String, "", true, true, "Circle", 0, 0, "", 1),
            new("ShapeSize", "Shape Size", EN_RECIPE_DATA_TYPE.Double, "mm", true, true, "0.350", 0.001, 100, "", 2),
            new("Direction", "Direction", EN_RECIPE_DATA_TYPE.String, "", true, true, "CW", 0, 0, "", 3),
            new("OffsetX", "Offset X", EN_RECIPE_DATA_TYPE.Double, "mm", true, true, "0.000", -100, 100, "", 4),
            new("OffsetY", "Offset Y", EN_RECIPE_DATA_TYPE.Double, "mm", true, true, "0.000", -100, 100, "", 5),
            new("GridRowLines", "Grid Row Count", EN_RECIPE_DATA_TYPE.Int, "ea", true, true, "5", 2, 200, "", 6),
            new("GridColLines", "Grid Col Count", EN_RECIPE_DATA_TYPE.Int, "ea", true, true, "5", 2, 200, "", 7),
            new("LaserOnMode", "LaserAction_Mode", EN_RECIPE_DATA_TYPE.String, "", true, true, "TIME", 0, 0, "", 70),
            new("Time", "LaserAction_On Time", EN_RECIPE_DATA_TYPE.Double, "msec", true, true, "1000", 0, 0, "", 80),
            new("Count", "LaserAction_Shot Count", EN_RECIPE_DATA_TYPE.Int, "count", true, true, "1", 1, int.MaxValue, "", 90),
            new("RepeatCount", "LaserAction_Repeat Count", EN_RECIPE_DATA_TYPE.Int, "count", true, true, "1", 1, int.MaxValue, "", 100),
            new("RepeatDelayTime", "LaserAction_Repeat Delay Time", EN_RECIPE_DATA_TYPE.Double, "msec", true, true, "0", 0, 0, "", 110)
        ];
        var requiredKeys = requiredParameters.Select(item => item.Name).ToHashSet(StringComparer.OrdinalIgnoreCase);
        // Older form files hid these fields. They remain editable after upgrading the UI.
        var parameters = requiredParameters.Select(item => formItems.FirstOrDefault(form => form.Name.Equals(item.Name, StringComparison.OrdinalIgnoreCase)) is { } form
                ? form with { DisplayName = item.DisplayName, Show = true, Use = true, DisplayOrder = item.DisplayOrder }
                : item)
            .Concat(formItems.Where(item => !requiredKeys.Contains(item.Name)));
        bool IsVisibleManualParameter(global::Drilling.Common.Managers.ST_MANUAL_SCAN_FORM item)
        {
            return item.Show && item.Use;
        }

        int SelectManualParameterDisplayOrder(global::Drilling.Common.Managers.ST_MANUAL_SCAN_FORM item)
        {
            return item.DisplayOrder;
        }

        global::Drilling.UI.Menu.Menus.ST_MANUAL_PARAMETER BuildManualParameterRow(global::Drilling.Common.Managers.ST_MANUAL_SCAN_FORM item)
        {
            return new ST_MANUAL_PARAMETER(item.Name, item.DisplayName, values.TryGetValue(item.Name, out var value) ? value : item.DefaultValue, item.Unit, item.DataType, item.Min, item.Max);
        }

        return parameters.Where(IsVisibleManualParameter).OrderBy(SelectManualParameterDisplayOrder).Select(BuildManualParameterRow).ToArray();
    }

    private static void ValidateManualScanParameters(ST_MANUAL_SCAN_PARAM settings, IReadOnlyList<ST_MANUAL_SCAN_FORM> formItems)
    {
        if (!double.IsFinite(settings.ShapeSize) || settings.ShapeSize <= 0)
            throw new InvalidDataException("Shape Size는 0보다 큰 유한한 값이어야 합니다.");
        if (!ST_MANUAL_PARAMETER.ShapeOptions.Contains(settings.ShapeName, StringComparer.OrdinalIgnoreCase))
            throw new InvalidDataException($"지원하지 않는 Shape Type입니다: {settings.ShapeName}");
        if (!ST_MANUAL_PARAMETER.DirectionOptions.Contains(settings.Direction, StringComparer.OrdinalIgnoreCase))
            throw new InvalidDataException("Direction은 CW 또는 CCW여야 합니다.");
        if (settings.GridRowLines < 2 || settings.GridColLines < 2)
            throw new InvalidDataException("Grid Row Count / Col Count는 2 이상의 정수여야 합니다.");
        if (!ST_MANUAL_PARAMETER.LaserModeOptions.Contains(settings.LaserOnMode, StringComparer.OrdinalIgnoreCase))
            throw new InvalidDataException("Mode는 TIME 또는 COUNT여야 합니다.");
        if (!double.IsFinite(settings.Time) || settings.Time <= 0)
            throw new InvalidDataException("On Time은 0보다 큰 유한한 값이어야 합니다. (msec)");
        if (settings.Count < 1 || settings.RepeatCount < 1)
            throw new InvalidDataException("Shot Count / Repeat Count는 1 이상의 정수여야 합니다.");
        if (!double.IsFinite(settings.RepeatDelayTime) || settings.RepeatDelayTime < 0)
            throw new InvalidDataException("Repeat Delay Time은 0 이상의 유한한 값이어야 합니다. (msec)");
        foreach (var value in new[] { settings.OffsetX, settings.OffsetY, settings.LaserPower, settings.JumpSpeed,
                     settings.MarkSpeed, settings.LaserFrequency, settings.LaserOnDelay, settings.LaserOffDelay })
            if (!double.IsFinite(value)) throw new InvalidDataException("Scan Parameter는 유한한 숫자여야 합니다.");
        if (settings.LaserPower < 0 || settings.JumpSpeed <= 0 || settings.MarkSpeed <= 0 || settings.LaserFrequency <= 0 ||
            settings.LaserOnDelay < 0 || settings.LaserOffDelay < 0)
            throw new InvalidDataException("레이저 Power·Delay는 0 이상, Speed·Frequency는 0보다 커야 합니다.");
        var numericValues = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase)
        {
            ["ShapeSize"] = settings.ShapeSize, ["OffsetX"] = settings.OffsetX, ["OffsetY"] = settings.OffsetY,
            ["GridRowLines"] = settings.GridRowLines, ["GridColLines"] = settings.GridColLines,
            ["LaserPower"] = settings.LaserPower, ["JumpSpeed"] = settings.JumpSpeed, ["MarkSpeed"] = settings.MarkSpeed,
            ["LaserFrequency"] = settings.LaserFrequency, ["LaserOnDelay"] = settings.LaserOnDelay, ["LaserOffDelay"] = settings.LaserOffDelay,
            ["Time"] = settings.Time, ["Count"] = settings.Count,
            ["RepeatCount"] = settings.RepeatCount, ["RepeatDelayTime"] = settings.RepeatDelayTime
        };
        foreach (var parameter in BuildSettingParameters(settings, formItems))
            if (parameter.DataType is EN_RECIPE_DATA_TYPE.Double or EN_RECIPE_DATA_TYPE.Int)
                ValidateManualParameterRange(parameter, numericValues.TryGetValue(parameter.Key, out var value)
                    ? value : ReadRequiredDouble(parameter.Value, parameter.Parameter));
    }

    private IReadOnlyList<ST_MANUAL_COMMAND_STATE> BuildCommandStateRows(ST_MANUAL_HEAD_CARD selectedHead)
    {
        void SetLaserActionPower(string value)
        {
            _laserActionPower = value;
        }

        void SetLaserActionFrequency(string value)
        {
            _laserActionFrequency = value;
        }

        void SetLaserOnMode(string value)
        {
            LaserOnMode = value;
        }

        void SetLaserOnTimeMsec(string value)
        {
            LaserOnTimeMsec = value;
        }

        void SetLaserShotCount(string value)
        {
            LaserShotCount = value;
        }

        return[new("Selected Head", selectedHead.HeadName), new("Laser Power", _laserActionPower, "W", true, SetLaserActionPower), new("Frequency", _laserActionFrequency, "kHz", true, SetLaserActionFrequency), new("Laser On Mode", LaserOnMode, "-", true, SetLaserOnMode, NormalizeLaserOnMode), new("Laser On Time", LaserOnTimeMsec, "msec", true, SetLaserOnTimeMsec), new("Shot Count", LaserShotCount, "count", true, SetLaserShotCount)];
    }

    private double ReadManualDouble(string parameterName)
    {
        var row = FindManualParameter(parameterName);
        var value = ReadManualText(row);
        if (double.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out var result) && double.IsFinite(result))
        {
            ValidateManualParameterRange(row, result);
            return result;
        }

        throw new InvalidDataException($"{parameterName} value is not a valid number: {value}");
    }

    private double ReadLaserMoveDelaySeconds(ST_MANUAL_SCAN_PARAM settings)
    {
        if (IsLaserTimeMode)
        {
            return ReadLaserOnTimeMsec();
        }

        var shotCount = ReadLaserShotCount();
        if (settings.LaserFrequency <= 0.0)
        {
            throw new InvalidDataException("Laser Frequency must be greater than 0 for COUNT mode.");
        }

        return (shotCount + 1.0) / settings.LaserFrequency;
    }

    private ST_MANUAL_SCAN_PARAM ReadLaserActionSettings(ST_MANUAL_SCAN_PARAM manualSettings)
    {
        return manualSettings with
        {
            LaserPower = ReadRequiredDouble(_laserActionPower, "Laser Action Power"),
            LaserFrequency = ReadRequiredDouble(_laserActionFrequency, "Laser Action Frequency"),
            Time = ReadLaserOnTimeMsec(),
            Count = ReadLaserShotCount()
        };
    }

    private double ReadLaserOnTimeMsec()
    {
        return ReadRequiredDouble(LaserOnTimeMsec, "Laser On Time");
    }

    private int ReadLaserShotCount()
    {
        if (int.TryParse(LaserShotCount?.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out var result))
        {
            return result;
        }

        throw new InvalidDataException($"Shot Count value is not a valid integer: {LaserShotCount}");
    }

    private static int ReadGridLineCount(string value, string name)
    {
        if (!int.TryParse(value.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out var result))
        {
            throw new InvalidDataException($"{name} value is not a valid integer: {value}");
        }

        if (result < 2)
        {
            throw new InvalidDataException($"{name} must be greater than or equal to 2.");
        }

        return result;
    }

    private int ReadManualInt(string parameterName)
    {
        var row = FindManualParameter(parameterName);
        var value = ReadManualText(row);
        if (int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var result))
        {
            ValidateManualParameterRange(row, result);
            return result;
        }

        throw new InvalidDataException($"{parameterName} value is not a valid integer: {value}");
    }

    private string ReadManualText(string parameterName, string defaultValue = "")
    {
        bool MatchesManualParameterDisplayName(global::Drilling.UI.Menu.Menus.ST_MANUAL_PARAMETER parameter)
        {
            return parameter.Parameter.Equals(parameterName, StringComparison.OrdinalIgnoreCase);
        }

        var row = SettingParameters.FirstOrDefault(MatchesManualParameterDisplayName);
        if (row is null)
        {
            if (!string.IsNullOrWhiteSpace(defaultValue))
            {
                return defaultValue.Trim();
            }

            throw new InvalidDataException($"{parameterName} parameter does not exist in Manual Setting.");
        }

        return ReadManualText(row, defaultValue);
    }

    private ST_MANUAL_PARAMETER FindManualParameter(string parameterName)
    {
        bool MatchesManualParameterName(global::Drilling.UI.Menu.Menus.ST_MANUAL_PARAMETER parameter)
        {
            return parameter.Key.Equals(parameterName, StringComparison.OrdinalIgnoreCase) || parameter.Parameter.Equals(parameterName, StringComparison.OrdinalIgnoreCase);
        }

        return SettingParameters.FirstOrDefault(MatchesManualParameterName) ?? throw new InvalidDataException($"{parameterName} parameter does not exist in Manual Setting.");
    }

    private static string ReadManualText(ST_MANUAL_PARAMETER row, string defaultValue = "")
    {
        var value = row.Value?.Trim() ?? "";
        if (!string.IsNullOrWhiteSpace(value))
        {
            return value;
        }

        if (!string.IsNullOrWhiteSpace(defaultValue))
        {
            return defaultValue.Trim();
        }

        throw new InvalidDataException($"{row.Parameter} value is empty.");
    }

    private static void ValidateManualParameterRange(ST_MANUAL_PARAMETER parameter, double value)
    {
        if (parameter.Min.Equals(parameter.Max))
        {
            return;
        }

        if (value < parameter.Min || value > parameter.Max)
        {
            throw new InvalidDataException($"{parameter.Parameter} range warning. Input {value:0.###} {parameter.Unit} is outside {parameter.Min:0.###} - {parameter.Max:0.###} {parameter.Unit}.");
        }
    }

    private static double ReadRequiredDouble(string value, string name)
    {
        if (double.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out var result))
        {
            return result;
        }

        throw new InvalidDataException($"{name} is not a valid number: {value}");
    }

    private static ST_MANUAL_SCAN_PARAM CreateFallbackManualParam()
    {
        return new ST_MANUAL_SCAN_PARAM(10.0, 0.0, 0.0, "CW", "Circle");
    }

    private static string NormalizeLaserOnMode(string? value)
    {
        return value?.Trim().Equals("COUNT", StringComparison.OrdinalIgnoreCase) == true ? "COUNT" : "TIME";
    }

    private static bool IsLaserTimeModeValue(string? value)
    {
        return !NormalizeLaserOnMode(value).Equals("COUNT", StringComparison.OrdinalIgnoreCase);
    }

    private static string GetManualSettingNameFromParameter(object? parameter)
    {
        var value = parameter switch
        {
            ST_MANUAL_SETTING_FILE settingFile => settingFile.Name,
            string text => text,
            _ => ""
        };
        return NormalizeManualSettingNameInput(value);
    }

    private static string? ShowManualSettingNameDialog(string title, string message, string initialValue, Func<string, string>? validate = null)
    {
        var dialog = new CRecipeNameDialog(title, message, initialValue, validate)
        {
            Owner = GetActiveWindow()
        };
        return dialog.ShowDialog() == true ? NormalizeManualSettingNameInput(dialog.RecipeName) : null;
    }

    private static bool ConfirmManualSettingDelete(string settingName)
    {
        var dialog = new CRecipeConfirmDialog("Manual Setting 삭제", $"{settingName} 설정을 삭제하시겠습니까?\n삭제한 설정 파일은 복구할 수 없습니다.", "삭제")
        {
            Owner = GetActiveWindow()
        };
        return dialog.ShowDialog() == true;
    }

    private static void ShowManualWarning(string message)
    {
        MessageBox.Show(GetActiveWindow(), message, "수동 스캔 경고", MessageBoxButton.OK, MessageBoxImage.Warning);
    }

    private static Window? GetActiveWindow()
    {
        return Application.Current?.Windows.OfType<Window>().FirstOrDefault(window => window.IsActive);
    }

    private static string NormalizeManualSettingNameInput(string value)
    {
        var normalized = value.Trim();
        if (normalized.EndsWith(".scan", StringComparison.OrdinalIgnoreCase))
        {
            normalized = normalized[..^5];
        }

        normalized = normalized.Trim();
        return string.IsNullOrWhiteSpace(normalized) ? "" : $"{normalized}.scan";
    }

    private static string ValidateManualSettingName(string settingName, IReadOnlyList<string> settingNames, string currentSettingName = "")
    {
        if (string.IsNullOrWhiteSpace(settingName))
        {
            return "Manual Setting 이름을 입력하세요.";
        }

        var settingId = Path.GetFileNameWithoutExtension(settingName.Trim());
        foreach (var character in settingId)
        {
            if (Path.GetInvalidFileNameChars().Contains(character))
            {
                return $"Manual Setting 이름에는 '{character}' 문자를 사용할 수 없습니다.";
            }
        }

        if (settingId is "." or ".." || settingId.EndsWith(".", StringComparison.Ordinal))
        {
            return "파일 이름으로 사용할 수 없는 Manual Setting 이름입니다.";
        }

        var reservedNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "CON",
            "PRN",
            "AUX",
            "NUL",
            "COM1",
            "COM2",
            "COM3",
            "COM4",
            "COM5",
            "COM6",
            "COM7",
            "COM8",
            "COM9",
            "LPT1",
            "LPT2",
            "LPT3",
            "LPT4",
            "LPT5",
            "LPT6",
            "LPT7",
            "LPT8",
            "LPT9"
        };
        if (reservedNames.Contains(settingId))
        {
            return "Windows에서 예약된 이름은 사용할 수 없습니다.";
        }

        bool IsDuplicateSettingName(string name)
        {
            return name.Equals(settingName, StringComparison.OrdinalIgnoreCase) && !name.Equals(currentSettingName, StringComparison.OrdinalIgnoreCase);
        }

        var exists = settingNames.Any(IsDuplicateSettingName);
        return exists ? $"{settingName} Manual Setting이 이미 존재합니다." : "";
    }

    private static string NormalizeSettingName(string settingName)
    {
        var normalized = Path.GetFileName(settingName.Trim());
        if (string.IsNullOrWhiteSpace(normalized))
        {
            normalized = "CIRCLE_TEST.scan";
        }

        return normalized.EndsWith(".scan", StringComparison.OrdinalIgnoreCase) ? normalized : $"{normalized}.scan";
    }

    private static string NormalizeScriptName(string commandName)
    {
        bool IsValidScriptNameCharacter(char character)
        {
            return char.IsLetterOrDigit(character) || character == '_' || character == '-';
        }

        var normalized = new string (commandName.Where(IsValidScriptNameCharacter).ToArray());
        return string.IsNullOrWhiteSpace(normalized) ? "MANUAL" : normalized.ToUpperInvariant();
    }

    private static string BuildShapeScanScriptName(int headNo, string shapeName)
    {
        var normalizedShape = NormalizeShapeName(shapeName).Replace("-", "", StringComparison.OrdinalIgnoreCase).ToUpperInvariant();
        return $"MANUAL_H{Math.Clamp(headNo, 1, 8):00}_SHAPE_{normalizedShape}";
    }

    private static string NormalizeShapeName(string shapeName)
    {
        var normalized = shapeName.Trim();
        return normalized.ToUpperInvariant() switch
        {
            "CROSS" => "Cross",
            "RECT" or "RECTANGLE" => "Rect",
            "GRID" => "Grid",
            "H-LINE" or "HLINE" or "H_LINE" => "H-Line",
            "V-LINE" or "VLINE" or "V_LINE" => "V-Line",
            _ => "Circle"
        };
    }

    private static string FormatDouble(double value, int decimals)
    {
        var format = decimals <= 0 ? "0" : $"0.{new string ('0', decimals)}";
        return value.ToString(format, CultureInfo.InvariantCulture);
    }

    private static string ReadScannerAxisTarget(IReadOnlyList<ST_MANUAL_SCANNER_AXIS> axes, string axisRole, string defaultValue = "0.000")
    {
        foreach (var axis in axes)
        {
            if (axis.AxisRole.Equals(axisRole, StringComparison.OrdinalIgnoreCase) && double.TryParse(axis.CurrentPosition, NumberStyles.Float, CultureInfo.InvariantCulture, out _))
            {
                return axis.CurrentPosition;
            }
        }

        return defaultValue;
    }

    private static string ReadScannerAxisReference(IReadOnlyList<ST_MANUAL_SCANNER_AXIS> axes, string axisRole, string defaultValue)
    {
        foreach (var axis in axes)
        {
            if (axis.AxisRole.Equals(axisRole, StringComparison.OrdinalIgnoreCase) && !string.IsNullOrWhiteSpace(axis.AxisReference))
            {
                return axis.AxisReference;
            }
        }

        return defaultValue;
    }

    private static ST_MANUAL_SCANNER_AXIS? FindScannerAxis(IReadOnlyList<ST_MANUAL_SCANNER_AXIS> axes, string axisRole)
    {
        foreach (var axis in axes)
        {
            if (axis.AxisRole.Equals(axisRole, StringComparison.OrdinalIgnoreCase))
            {
                return axis;
            }
        }

        return null;
    }

    private static bool IsScannerAxisAvailable(IReadOnlyList<ST_MANUAL_SCANNER_AXIS> axes, string axisRole)
    {
        var axis = FindScannerAxis(axes, axisRole);
        return axis is not null && !IsManualScannerAxisNotUsed(axis) && IsConfiguredScannerAxisName(axis.AxisReference);
    }

    private static ST_SCANNER_AXIS_SETTING? FindScannerAxisDefinition(IReadOnlyList<ST_SYSTEM_PARAMETER> settings, int headNo, string axisRole)
    {
        var definitions = CScannerStatusSnapshotReader.BuildAxisDefinitions(settings, headNo);
        foreach (var definition in definitions)
        {
            if (definition.AxisName.Equals(axisRole, StringComparison.OrdinalIgnoreCase))
            {
                return definition;
            }
        }

        return null;
    }

    private async Task<ST_RECIPE_DEFINITION?> LoadSelectedRecipe(CancellationToken cancellationToken)
    {
        var selectedRecipeId = (_selectedRecipeIdProvider() ?? "").Trim();
        var recipes = await _manager.Recipe().LoadRecipes(cancellationToken);
        if (!string.IsNullOrWhiteSpace(selectedRecipeId))
        {
            foreach (var recipe in recipes)
            {
                if (recipe.Id.Equals(selectedRecipeId, StringComparison.OrdinalIgnoreCase))
                {
                    return recipe;
                }
            }
        }

        foreach (var recipe in recipes)
        {
            if (recipe.Id.Equals("DRILL_A01", StringComparison.OrdinalIgnoreCase))
            {
                return recipe;
            }
        }

        return recipes.Count > 0 ? recipes[0] : null;
    }

    private static double ReadHeadRecipeDouble(ST_RECIPE_DEFINITION? recipe, int headNo, double defaultValue, params string[] suffixes)
    {
        if (recipe is null)
        {
            return defaultValue;
        }

        var prefix = $"H{headNo:00}_";
        foreach (var suffix in suffixes)
        {
            var key = prefix + suffix;
            foreach (var parameter in recipe.Parameters)
            {
                if (!key.Equals(parameter.Key, StringComparison.OrdinalIgnoreCase) && !key.Equals(parameter.Name, StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                if (double.TryParse(parameter.Value, NumberStyles.Float, CultureInfo.InvariantCulture, out var value))
                {
                    return value;
                }
            }
        }

        return defaultValue;
    }

    private static bool IsConfiguredScannerAxisName(string axisReference)
    {
        var normalized = axisReference.Trim();
        if (normalized.Length == 0 || normalized.Equals("-", StringComparison.Ordinal) || !char.IsAsciiLetter(normalized[0]))
        {
            return false;
        }

        foreach (var character in normalized)
        {
            if (!char.IsAsciiLetter(character) && !char.IsAsciiDigit(character) && character != '_')
            {
                return false;
            }
        }

        return true;
    }

    private static bool HasReadableScannerPosition(IReadOnlyList<ST_MANUAL_SCANNER_AXIS> axes)
    {
        foreach (var axis in axes)
        {
            if (double.TryParse(axis.CurrentPosition, NumberStyles.Float, CultureInfo.InvariantCulture, out _))
            {
                return true;
            }
        }

        return false;
    }

    private readonly record struct ST_ACTIVE_DIO_TARGET(long Generation, int AutomationNo, string Address);
    private readonly record struct ST_MANUAL_SCRIPT_AXES(string XAxis, string YAxis);
    private readonly record struct ST_MANUAL_SCRIPT_Z_AXIS(string Axis, int AutomationNo);
    private sealed record ST_CONTROLLER_HOME_TASK(int TaskNo, IReadOnlyList<int> HeadNos, IReadOnlyList<string> AxisReferences);
    private sealed record ST_CONTROLLER_HOME_RUN(int TaskNo, string ScriptFileName, string InitialResponse);
    private sealed record ST_RESET_SEQUENCE_AXIS_TARGET(int HeadNo, int AutomationNo, string AxisRole, string AxisReference, int AioNo, bool ReadExtendedStatus);
    private sealed record ST_RESET_SEQUENCE_DIO_TARGET(int HeadNo, int AutomationNo, string Address);
}

public sealed record ST_MANUAL_HEAD_GROUP(int AutomationNo, string Title, IReadOnlyList<ST_MANUAL_HEAD_CARD> Heads);
public sealed record ST_MANUAL_HEAD_CARD(int HeadNo, string HeadName, string XSummary, string YSummary, string ZSummary, string State, bool IsSelected, bool IsEnabled = true, int AutomationNo = 0)
{
    public Brush StateBrush
    {
        get
        {
            return CStatusBrush.ForHeadStatus(State);
        }
    }

    public Brush TextBrush
    {
        get
        {
            return IsSelected ? Brushes.White : CStatusBrush.PrimaryText;
        }
    }
}

public sealed record ST_MANUAL_SETTING_FILE(string Name, bool IsSelected);
public sealed record ST_MANUAL_DIO_TARGET(int AutomationNo, string Address, string AxisName, int DioNo);
public sealed record ST_MANUAL_VISION_PROTOCOL_COMMAND(
    string DisplayName,
    string CommandText,
    string Description)
{
    public override string ToString()
    {
        return DisplayName;
    }
}

public sealed class ST_MANUAL_VISION_MARK_SEARCH : CBindingBase
{
    private readonly Action _valueChanged;
    private string _cellNo;
    private string _doeNo;
    private string _lineNo;
    private string _indexX;
    private string _indexY;
    private string _headNo;

    public ST_MANUAL_VISION_MARK_SEARCH(
        string cellNo,
        string doeNo,
        string lineNo,
        string indexX,
        string indexY,
        string headNo,
        Action valueChanged)
    {
        _cellNo = cellNo;
        _doeNo = doeNo;
        _lineNo = lineNo;
        _indexX = indexX;
        _indexY = indexY;
        _headNo = headNo;
        _valueChanged = valueChanged;
    }

    public string CellNo
    {
        get
        {
            return _cellNo;
        }

        set
        {
            SetValue(ref _cellNo, value);
        }
    }

    public string DoeNo
    {
        get
        {
            return _doeNo;
        }

        set
        {
            SetValue(ref _doeNo, value);
        }
    }

    public string LineNo
    {
        get
        {
            return _lineNo;
        }

        set
        {
            SetValue(ref _lineNo, value);
        }
    }

    public string IndexX
    {
        get
        {
            return _indexX;
        }

        set
        {
            SetValue(ref _indexX, value);
        }
    }

    public string IndexY
    {
        get
        {
            return _indexY;
        }

        set
        {
            SetValue(ref _indexY, value);
        }
    }

    public string HeadNo
    {
        get
        {
            return _headNo;
        }

        set
        {
            SetValue(ref _headNo, value);
        }
    }

    private void SetValue(ref string field, string value)
    {
        if (SetProperty(ref field, value ?? ""))
        {
            _valueChanged();
        }
    }
}

public sealed record ST_MANUAL_SCANNER_AXIS(int HeadNo, string Head, string Automation, int AutomationNo, string AxisRole, string AxisReference, string Enable, string Home, string CurrentPosition, string AuxFeedback, string Error, string Detail)
{
    public long? FaultMask { get; init; }
    public string FaultState => FaultMask.HasValue ? FaultMask.Value == 0 ? "OK" : "FAULT" : Error switch
    {
        "NOT USE" => "-",
        "OFFLINE" => "OFFLINE",
        "STALE" => "STALE",
        _ => "UNKNOWN"
    };
    public string FaultDetail => FaultMask.HasValue ? CAutomationAxisFault.Describe(FaultMask.Value) : $"Fault 상태를 확인할 수 없습니다.\n{Detail}";
    public Brush FaultBrush => FaultMask.HasValue ? FaultMask.Value == 0 ? CStatusBrush.Online : CStatusBrush.Offline : CStatusBrush.Muted;
    public bool CanClearFault => IsControlEnabled && FaultMask is > 0 && !CAutomationAxisFault.RequiresReset(FaultMask.Value);

    public string AxisTitle
    {
        get
        {
            if (AxisReference.Equals("Z NOT USE", StringComparison.OrdinalIgnoreCase))
            {
                return "Z NOT USE";
            }

            return $"{AxisRole}  {AxisReference}";
        }
    }

    public bool IsControlEnabled
    {
        get
        {
            return !AxisReference.Equals("Z NOT USE", StringComparison.OrdinalIgnoreCase)
                && !Enable.Equals("NOT USE", StringComparison.OrdinalIgnoreCase);
        }
    }

    public Brush EnableBrush
    {
        get
        {
            return ScannerStateBrush(Enable);
        }
    }

    public Brush HomeBrush
    {
        get
        {
            return ScannerStateBrush(Home);
        }
    }

    public Brush ErrorBrush
    {
        get
        {
            return ScannerStateBrush(Error);
        }
    }

    private static Brush ScannerStateBrush(string state)
    {
        return state.Trim().ToUpperInvariant() switch
        {
            "ENABLE" or "HOME" or "OK" => CStatusBrush.Online,
            "DISABLE" or "WAIT" => CStatusBrush.Wait,
            "NO" or "ERROR" or "OFFLINE" => CStatusBrush.Offline,
            _ => CStatusBrush.Muted
        };
    }
}

public sealed class ST_MANUAL_STAGE_AXIS : CBindingBase
{
    private string _currentPosition = "-";
    private string _currentSpeed = "-";
    private bool _isSelected;
    private string _status = "WAIT";
    private string _statusMessage = "";
    private string _targetPosition = "0.000";
    private string _targetSpeed = "0.000";
    public ST_MANUAL_STAGE_AXIS(string key, string displayName, string unit, string readPositionId, string writePositionId)
    {
        Key = key;
        DisplayName = displayName;
        Unit = unit;
        ReadPositionId = readPositionId;
        WritePositionId = writePositionId;
    }

    public string Key { get; }
    public string DisplayName { get; }
    public string Unit { get; }
    public string ReadPositionId { get; }
    public string WritePositionId { get; }
    public string SpeedUnit
    {
        get
        {
            return $"{Unit}/s";
        }
    }

    public bool IsSelected
    {
        get
        {
            return _isSelected;
        }

        set
        {
            SetProperty(ref _isSelected, value);
        }
    }

    public string CurrentPosition
    {
        get
        {
            return _currentPosition;
        }

        set
        {
            SetProperty(ref _currentPosition, value);
        }
    }

    public string CurrentSpeed
    {
        get
        {
            return _currentSpeed;
        }

        set
        {
            SetProperty(ref _currentSpeed, value);
        }
    }

    public string Status
    {
        get
        {
            return _status;
        }

        set
        {
            SetProperty(ref _status, value);
        }
    }

    public string StatusMessage
    {
        get
        {
            return _statusMessage;
        }

        set
        {
            SetProperty(ref _statusMessage, value);
        }
    }

    public string TargetPosition
    {
        get
        {
            return _targetPosition;
        }

        set
        {
            SetProperty(ref _targetPosition, value);
        }
    }

    public string TargetSpeed
    {
        get
        {
            return _targetSpeed;
        }

        set
        {
            SetProperty(ref _targetSpeed, value);
        }
    }
}

public sealed class ST_MANUAL_PARAMETER : CBindingBase
{
    public static IReadOnlyList<string> ShapeOptions { get; } = ["Cross", "Circle", "Rect", "Grid", "H-Line", "V-Line"];
    public static IReadOnlyList<string> DirectionOptions { get; } = ["CW", "CCW"];
    public static IReadOnlyList<string> LaserModeOptions { get; } = ["TIME", "COUNT"];
    private string _value;
    public ST_MANUAL_PARAMETER(string key, string parameter, string value, string unit, EN_RECIPE_DATA_TYPE dataType = EN_RECIPE_DATA_TYPE.String, double min = 0.0, double max = 0.0)
    {
        Key = key;
        Parameter = parameter;
        _value = value;
        Unit = unit;
        DataType = dataType;
        Min = min;
        Max = max;
    }

    public string Key { get; }
    public string Parameter { get; }

    public string Value
    {
        get
        {
            return _value;
        }

        set
        {
            SetProperty(ref _value, value);
        }
    }

    public string Unit { get; }
    public EN_RECIPE_DATA_TYPE DataType { get; }

    public bool UsesSelectionEditor
    {
        get
        {
            return DataType == EN_RECIPE_DATA_TYPE.Bool || Key.Equals("ShapeName", StringComparison.OrdinalIgnoreCase) ||
                Key.Equals("Direction", StringComparison.OrdinalIgnoreCase) || Key.Equals("LaserOnMode", StringComparison.OrdinalIgnoreCase);
        }
    }

    public IReadOnlyList<string> ValueOptions
    {
        get
        {
            if (Key.Equals("ShapeName", StringComparison.OrdinalIgnoreCase)) return ShapeOptions;
            if (Key.Equals("Direction", StringComparison.OrdinalIgnoreCase)) return DirectionOptions;
            if (Key.Equals("LaserOnMode", StringComparison.OrdinalIgnoreCase)) return LaserModeOptions;
            return Value.Trim()is "0" or "1" ? ["0", "1"] : ["OFF", "ON"];
        }
    }

    public double Min { get; }
    public double Max { get; }
}

public sealed class ST_MANUAL_COMMAND_STATE : CBindingBase
{
    private readonly Action<string>? _valueChanged;
    private readonly Func<string, string>? _normalizeValue;
    private string _value;
    public ST_MANUAL_COMMAND_STATE(string name, string value, string unit = "", bool isEditable = false, Action<string>? valueChanged = null, Func<string, string>? normalizeValue = null)
    {
        Name = name;
        _value = value;
        Unit = unit;
        IsEditable = isEditable;
        _valueChanged = valueChanged;
        _normalizeValue = normalizeValue;
    }

    public string Name { get; }

    public string Value
    {
        get
        {
            return _value;
        }

        set
        {
            var nextValue = _normalizeValue?.Invoke(value) ?? value;
            if (SetProperty(ref _value, nextValue))
            {
                _valueChanged?.Invoke(nextValue);
            }
        }
    }

    public string Unit { get; }
    public bool IsEditable { get; }

    public bool IsReadOnly
    {
        get
        {
            return !IsEditable;
        }
    }

    public bool UsesSelectionEditor
    {
        get
        {
            return Name.Equals("Laser On Mode", StringComparison.OrdinalIgnoreCase);
        }
    }

    public IReadOnlyList<string> ValueOptions { get; } = ["TIME", "COUNT"];
}
