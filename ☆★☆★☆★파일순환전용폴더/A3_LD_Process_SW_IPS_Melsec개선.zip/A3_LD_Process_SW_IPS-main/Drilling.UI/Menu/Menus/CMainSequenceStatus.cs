using System.Globalization;
using System.Windows.Media;
using Drilling.Common.Interface;
using Drilling.Common.Station;
using Drilling.Common.Review;

namespace Drilling.UI.Menu.Menus;

/// <summary>One ordered signal/action flow, using shared communication and execution snapshots.</summary>
public sealed class CMainSequenceStatus
{
    private string _selectedKey = "DO_READY";
    private IReadOnlyDictionary<string, ST_MELSEC_CACHED_VALUE> _values = new Dictionary<string, ST_MELSEC_CACHED_VALUE>();
    private IReadOnlyDictionary<string, ST_MELSEC_MAP_DATA> _map = new Dictionary<string, ST_MELSEC_MAP_DATA>();
    private IReadOnlyDictionary<int, EN_COMM_STATE> _connections = new Dictionary<int, EN_COMM_STATE>();
    private IReadOnlyDictionary<string, ST_SEQUENCE_ACTION_STATUS> _actions = new Dictionary<string, ST_SEQUENCE_ACTION_STATUS>();

    public CMainSequenceStatus()
    {
        SelectScenarioCommand = new CButtonCommand(parameter => Select(parameter?.ToString()));
        Tabs = Scenarios.Select(scenario => new CMainSequenceTab(scenario.Key, scenario.Name)).ToArray();
        Rebuild();
    }

    public event EventHandler? CardsChanged;
    public CButtonCommand SelectScenarioCommand { get; }
    public IReadOnlyList<CMainSequenceTab> Tabs { get; }
    public IReadOnlyList<CMainSequenceCard> Cards { get; private set; } = [];
    public Action? OpenReviewMonitor { get; set; }
    private string _reviewProgress = "클릭: Review Monitor";
    public void RefreshReviewMonitor(ST_FINE_REVIEW_MONITOR? frame)
    {
        _reviewProgress = frame is null ? "클릭: Review Monitor" : frame.Request.Context?.Origin != "AUTO"
            ? "최근 MANUAL FINE · 클릭: Monitor"
            : $"{frame.Progress.Lines.Sum(line => line.Points.Count(point => point.State is EN_REVIEW_POINT_STATE.Ok or EN_REVIEW_POINT_STATE.Ng)):N0} / {frame.Request.Plan.Points.Count:N0} Shots · " +
                $"NG {frame.Progress.Lines.Sum(line => line.Points.Count(point => point.State == EN_REVIEW_POINT_STATE.Ng))}";
        foreach (var card in Cards.Where(card => card.Id == "REVIEW_MEASURE")) card.SetProgress(_reviewProgress);
    }

    public void Refresh(IReadOnlyDictionary<string, ST_MELSEC_CACHED_VALUE> values, IReadOnlyList<ST_MELSEC_MAP_DATA> map,
        IReadOnlyDictionary<int, EN_COMM_STATE> connections, IReadOnlyDictionary<string, ST_SEQUENCE_ACTION_STATUS>? actions = null)
    {
        _values = values;
        _map = map.ToDictionary(row => row.Id, StringComparer.OrdinalIgnoreCase);
        _connections = connections;
        _actions = actions ?? new Dictionary<string, ST_SEQUENCE_ACTION_STATUS>();
        RefreshCards();
        RefreshTabs();
    }

    private void Select(string? key)
    {
        if (key == _selectedKey || !Scenarios.Any(scenario => scenario.Key == key)) return;
        _selectedKey = key!;
        Rebuild();
    }

    private void Rebuild()
    {
        var scenario = Scenarios.Single(item => item.Key == _selectedKey);
        Cards = scenario.Steps.Select((step, index) => new CMainSequenceCard(step.Id, step.Title, step.Owner, step.IsSignal, index + 1)).ToArray();
        foreach (var card in Cards.Where(card => card.Id == "REVIEW_MEASURE")) card.SetProgress(_reviewProgress);
        RefreshCards();
        RefreshTabs();
        CardsChanged?.Invoke(this, EventArgs.Empty);
    }

    private void RefreshTabs()
    {
        // Use the full action snapshot, including scenarios whose cards are not displayed.
        // Keep tab objects stable so unchanged snapshots do not restart their animations.
        for (var index = 0; index < Scenarios.Length; index++)
        {
            var scenario = Scenarios[index];
            var running = scenario.Steps.Any(step => !step.IsSignal &&
                _actions.TryGetValue(step.Id, out var action) && action.State == EN_SEQUENCE_ACTION_STATE.Running);
            Tabs[index].Refresh(scenario.Key == _selectedKey, running);
        }
    }

    private void RefreshCards()
    {
        foreach (var card in Cards)
        {
            if (card.IsSignal)
            {
                _map.TryGetValue(card.Id, out var row);
                _values.TryGetValue(card.Id, out var value);
                var connected = row is not null && _connections.TryGetValue(row.DeviceNo, out var connection) &&
                    connection is EN_COMM_STATE.Online or EN_COMM_STATE.Simulation;
                card.RefreshSignal(row, value, connected);
            }
            else
            {
                _actions.TryGetValue(card.Id, out var action);
                card.RefreshAction(action);
            }
        }
    }

    private sealed record Step(string Id, string Title, string Owner, bool IsSignal);
    private sealed record Scenario(string Key, string Name, Step[] Steps);
    private static Step S(string owner, string scenario, string signal) =>
        new($"HANDSHAKE_{owner}_{scenario}_{signal}", $"{ScenarioName(scenario)} {signal.Replace('_', ' ')}",
            owner == "STG" ? "STAGE → PROCESS" : "PROCESS → STAGE", true);
    private static Step A(string id, string title) => new(id, title, "PROCESS ACTION", false);
    private static string ScenarioName(string scenario) => scenario switch
    {
        "DOREADY" => "DoReady", "PROCESS" => "Process", "REVIEW" => "Review", "TOP_POWERMETER" => "TPM", _ => scenario
    };

    // Cards display the scenario; selecting/viewing them never writes a signal or starts an action.
    private static readonly Scenario[] Scenarios =
    [
        new("DO_READY", "DoReady",
        [
            S("STG", "DOREADY", "ABLE"), S("PRC", "DOREADY", "ABLE"),
            S("STG", "DOREADY", "START"), S("PRC", "DOREADY", "START"),
            A(CSequenceActionIds.PrepareData, "Prepare coordinates / MOF data"),
            A(CSequenceActionIds.BuildUploadScript, "Build & script upload"),
            S("PRC", "DOREADY", "COMPLETE"), S("STG", "DOREADY", "COMPLETE"),
            A(CSequenceActionIds.DoReadySignalsClear, "Clear DoReady signals")
        ]),
        new("PROCESS", "Process",
        [
            S("STG", "PROCESS", "ABLE"), A(CSequenceActionIds.ProcessReadyPosition, "Verify Ready Position"),
            A(CSequenceActionIds.ProcessMofZero, "MOF ZeroSet"), A(CSequenceActionIds.ProcessTaskRun, "Run Task / encoder wait"),
            S("PRC", "PROCESS", "ABLE"), S("STG", "PROCESS", "START"), S("PRC", "PROCESS", "START"),
            A("PROCESS_MACHINING_INSPECTION", "MOF machining / 0-line inspection"),
            A(CSequenceActionIds.ProcessResults, "Validate results / save"),
            S("PRC", "PROCESS", "COMPLETE"), S("STG", "PROCESS", "COMPLETE"),
            A("PROCESS_SIGNALS_CLEAR", "Clear Process signals")
        ]),
        new("REVIEW", "Review",
        [
            S("STG", "REVIEW", "ABLE"), A("REVIEW_PLAN", "Prepare inspection plan"),
            S("PRC", "REVIEW", "ABLE"), S("STG", "REVIEW", "START"), S("PRC", "REVIEW", "START"),
            A("REVIEW_MEASURE", "Move targets / vision inspection"), A("REVIEW_RESULTS", "Validate results / save judgments"),
            S("PRC", "REVIEW", "COMPLETE"), S("STG", "REVIEW", "COMPLETE"),
            A("REVIEW_SIGNALS_CLEAR", "Clear Review signals")
        ]),
        new("TOP_POWERMETER", "TPM",
        [
            S("STG", "TOP_POWERMETER", "ABLE"), A("TPM_PREPARE", "Prepare measurement conditions"),
            S("PRC", "TOP_POWERMETER", "ABLE"), A("TPM_MEASURE", "Move ATT / measure power"),
            A("TPM_RESULTS", "Validate measurements / save results"),
            S("PRC", "TOP_POWERMETER", "COMPLETE"), S("STG", "TOP_POWERMETER", "COMPLETE"),
            A("TPM_SIGNALS_CLEAR", "Clear TPM signals")
        ]),
        new("PROCESS_MOVE", "Process Move",
        [
            new("HANDSHAKE_STG_REVIEW_ABLE_SDC", "Review X movement permission", "STAGE → PROCESS", true),
            A("MOVE_TARGETS", "Write target position / speed"),
            new("HANDSHAKE_PRC_REVIEW_MOVE_START", "Review X MOVE START", "PROCESS → STAGE", true),
            new("HANDSHAKE_STG_REVIEW_COMPLETE_SDC", "Review X arrival", "STAGE → PROCESS", true),
            A("MOVE_SETTLE", "Verify arrival / settling"), A("MOVE_RELEASE", "Clear request / verify signal reset"),
            new("HANDSHAKE_PRC_REVIEW_GENERAL_RUNNING", "Review GENERAL RUNNING", "PROCESS → STAGE", true),
            A("MOVE_XREADY", "Hand over current XReady to IOF")
        ]),
        new("IOF", "IOF",
        [
            new("HANDSHAKE_PRC_IOF_START_REQUEST", "IOF START REQUEST", "PROCESS → STAGE", true),
            A("IOF_VISION_READY", "Vision ready (1900 / 1001)"), A("IOF_CAPTURE", "Capture line / receive 1002 ACK"),
            new("HANDSHAKE_STG_IOF_COMPLETE", "IOF COMPLETE", "STAGE → PROCESS", true),
            A("IOF_RESULTS", "Receive 1003 results / validate / save"),
            new("HANDSHAKE_PRC_IOF_COMPLETE_RESPONSE", "IOF COMPLETE RESPONSE", "PROCESS → STAGE", true)
        ])
    ];
}

public sealed class CMainSequenceTab(string key, string name) : CBindingBase
{
    private static readonly Brush RunningGreen = CStatusBrush.Frozen(0x2E, 0x8B, 0x57);
    private bool _isSelected;
    private bool _isBlinking;
    public event EventHandler? IsBlinkingChanged;
    public string Key { get; } = key;
    public string Name { get; } = name;
    public bool IsSelected => _isSelected;
    public bool IsBlinking => _isBlinking;
    public Brush BackgroundBrush => IsBlinking ? RunningGreen : IsSelected ? CStatusBrush.CommandBlue : CStatusBrush.CommandDark;
    public Brush BorderBrush => IsBlinking ? RunningGreen : IsSelected ? CStatusBrush.CommandBlueBorder : CStatusBrush.CommandDarkBorder;
    public Brush TextBrush => Brushes.White;

    internal void Refresh(bool selected, bool blinking)
    {
        if (_isSelected == selected && _isBlinking == blinking) return;
        var blinkChanged = _isBlinking != blinking;
        _isSelected = selected;
        _isBlinking = blinking;
        OnPropertyChanged(nameof(BackgroundBrush));
        OnPropertyChanged(nameof(BorderBrush));
        if (blinkChanged) IsBlinkingChanged?.Invoke(this, EventArgs.Empty);
    }
}

public sealed class CMainSequenceCard(string id, string title, string owner, bool isSignal, int order) : CBindingBase
{
    private static readonly Brush Yellow = CStatusBrush.Frozen(0xFF, 0xD9, 0x66);
    private static readonly Brush Green = CStatusBrush.Frozen(0x2E, 0x8B, 0x57);
    private static readonly Brush Red = CStatusBrush.Frozen(0xE6, 0x21, 0x21);
    private string _state = isSignal ? "OFFLINE" : "WAIT";
    private string _detail = "";
    private string _progressText = "";
    public string ProgressText => _progressText;
    internal void SetProgress(string text)
    {
        if (_progressText == text) return;
        _progressText = text; OnPropertyChanged(nameof(ProgressText));
    }
    public event EventHandler? IsBlinkingChanged;
    public string Id { get; } = id;
    public string Title { get; } = title;
    public string Owner { get; } = owner;
    public bool IsSignal { get; } = isSignal;
    public string Order { get; } = order.ToString("00", CultureInfo.InvariantCulture);
    public string State => _state;
    public string Detail => _detail;
    public bool IsBlinking => !IsSignal && State == "RUNNING";
    public Brush StateBrush => State is "ON" or "RUNNING" or "DONE" ? Green : State is "OFF" or "WAIT" ? Yellow : Red;
    public Brush TextBrush => State is "OFF" or "WAIT" ? Brushes.Black : Brushes.White;

    internal void RefreshSignal(ST_MELSEC_MAP_DATA? row, ST_MELSEC_CACHED_VALUE? value, bool connected)
    {
        var state = "OFFLINE";
        var detail = row is null ? $"{Id}: Not configured." : $"{Id} / {row.Address}";
        if (connected)
        {
            if (row?.Use != true) state = "NOT SET";
            else if (value?.IsValid == true)
            {
                double number;
                try { number = value.Value is null ? double.NaN : Convert.ToDouble(value.Value, CultureInfo.InvariantCulture); }
                catch (Exception exception) when (exception is FormatException or InvalidCastException or OverflowException) { number = double.NaN; }
                state = number == 0 ? "OFF" : number == 1 ? "ON" : "ERROR";
                detail += $" / Value: {value.Value}";
            }
            else state = value?.State switch
            {
                EN_MELSEC_CACHE_STATE.Stale => "STALE", EN_MELSEC_CACHE_STATE.Offline => "OFFLINE",
                EN_MELSEC_CACHE_STATE.Error => "ERROR", _ => "WAIT DATA"
            };
        }
        if (value is { IsValid: false }) detail += $" / {value.State}: {value.ErrorMessage}";
        Apply(state, detail);
    }

    internal void RefreshAction(ST_SEQUENCE_ACTION_STATUS? action)
    {
        var state = action?.State switch
        {
            EN_SEQUENCE_ACTION_STATE.Running => "RUNNING", EN_SEQUENCE_ACTION_STATE.Completed => "DONE",
            EN_SEQUENCE_ACTION_STATE.Error => "ERROR", EN_SEQUENCE_ACTION_STATE.Stopped => "STOPPED", _ => "WAIT"
        };
        Apply(state, action?.Detail ?? "아직 실행되지 않은 동작입니다.");
    }

    private void Apply(string state, string detail)
    {
        if (SetProperty(ref _state, state, nameof(State)))
        {
            OnPropertyChanged(nameof(StateBrush));
            OnPropertyChanged(nameof(TextBrush));
            IsBlinkingChanged?.Invoke(this, EventArgs.Empty);
        }
        SetProperty(ref _detail, detail, nameof(Detail));
    }
}
