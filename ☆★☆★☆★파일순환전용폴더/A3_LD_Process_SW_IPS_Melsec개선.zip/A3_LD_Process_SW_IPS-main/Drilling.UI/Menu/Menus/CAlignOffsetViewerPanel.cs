using System.ComponentModel;
using System.Globalization;
using System.Windows.Media;
using Drilling.Common.Managers;
using Drilling.Common.Recipe;
using Drilling.Common.Review;

namespace Drilling.UI.Menu.Menus;

public sealed class CAlignOffsetViewerPanel : INotifyPropertyChanged
{
    private readonly IReadOnlyDictionary<int, ST_DESIGN_SHOT_POINT[]> _shotsByCell;
    private readonly IReadOnlyDictionary<string, ST_HEAD_SHOT_POINT> _headShots;
    private readonly IReadOnlyDictionary<string, string> _parameters;
    private readonly Func<int, ST_CORRECTION_OFFSET_VIEWER_PREVIEW> _buildPreview;
    private readonly bool _reviewOffsets;

    public CAlignOffsetViewerPanel(ST_RECIPE_DEFINITION recipe, IReadOnlyDictionary<string, string> parameters,
        Func<int, ST_CORRECTION_OFFSET_VIEWER_PREVIEW> buildPreview, bool reviewOffsets = false)
    {
        _reviewOffsets = reviewOffsets;
        RecipeName = recipe.Name;
        _buildPreview = buildPreview;
        var current = new Dictionary<string, string>(parameters, StringComparer.OrdinalIgnoreCase);
        // Assignment is shown for all physical heads, including currently disabled heads.
        for (var headNo = 1; headNo <= 8; headNo++) current[$"H{headNo:00}_USE"] = "ON";
        _parameters = current;
        var designShots = CShotCoordinatePlanBuilder.BuildDesignShots(current);
        _shotsByCell = designShots.GroupBy(shot => shot.CellNo).ToDictionary(group => group.Key, group => group.ToArray());
        _headShots = CShotCoordinatePlanBuilder.Build(current).Shots.ToDictionary(shot => shot.ShotKey, StringComparer.Ordinal);
        TotalShotCount = designShots.Count;
        SelectCellCommand = new CButtonCommand(SelectCell);
        ApplyPreview(0);
    }

    public event PropertyChangedEventHandler? PropertyChanged;
    public CButtonCommand SelectCellCommand { get; }
    public string RecipeName { get; }
    public string ViewerTitle => _reviewOffsets ? "Cur Review Offset View" : "Current Offset View";
    public string OffsetDescription => _reviewOffsets
        ? "Review Offset: Saved value   |   Scanner Converted Offset: Current head direction"
        : "Design Offset: X/Y   |   Scanner Converted Offset: Current head direction";
    public int TotalShotCount { get; }
    public ImageSource? PreviewImage { get; private set; }
    public IReadOnlyList<ST_CELL_PREVIEW_LABEL> CellLabels { get; private set; } = [];
    public IReadOnlyList<ST_ALIGN_OFFSET_VIEW_ROW> Rows { get; private set; } = [];
    public IReadOnlyList<ST_ALIGN_OFFSET_VIEW_CARD_ROW> ShotRows { get; private set; } = [];
    public bool HasSelectedCell => Rows.Count > 0;
    public string Summary { get; private set; } = "";
    public string SelectedCellTitle { get; private set; } = "Select a Cell";

    private void SelectCell(object? value)
    {
        if (!int.TryParse(value?.ToString(), NumberStyles.Integer, CultureInfo.InvariantCulture, out var cellNo) ||
            !_shotsByCell.TryGetValue(cellNo, out var shots)) return;
        Rows = shots.OrderBy(shot => shot.CellShotNo).Select(shot =>
        {
            var assigned = _headShots.GetValueOrDefault(shot.ShotKey);
            var xValue = _reviewOffsets ? shot.ReviewOffsetX : shot.AlignOffsetX;
            var yValue = _reviewOffsets ? shot.ReviewOffsetY : shot.AlignOffsetY;
            var design = !_reviewOffsets || shot.ReviewOffsetIsDesign;
            var converted = assigned is null ? ((double X, double Y)?)null
                : CReviewOffsetData.ToScanner(_parameters, assigned.HeadNo, xValue, yValue, design);
            return new ST_ALIGN_OFFSET_VIEW_ROW(CReviewShotNameFormatter.ToMatrixName(shot.CellShotNo, shot.GroupCountX),
                assigned is null ? "-" : $"H{assigned.HeadNo:00}", xValue, yValue,
                converted is { } x ? CAlignShotOffsetData.RoundValue(x.X) : null,
                converted is { } y ? CAlignShotOffsetData.RoundValue(y.Y) : null, assigned is null ? "Head not assigned"
                    : CScannerAxisTransform.Format(CScannerAxisTransform.Read(_parameters, assigned.HeadNo)))
                { StoredTitle = !_reviewOffsets ? "Design Offset (mm)" : design ? "Design Review Offset (mm)" : "Review Offset · Scanner (mm)" };
        }).ToArray();
        var cards = shots.OrderBy(shot => shot.CellShotNo).Zip(Rows).ToDictionary(pair => pair.First.ShotKey, pair => pair.Second);
        ShotRows = shots.GroupBy(shot => shot.GroupRow).OrderBy(group => group.Key)
            .Select(group => new ST_ALIGN_OFFSET_VIEW_CARD_ROW(group.Key,
                group.OrderBy(shot => shot.GroupColumn).Select(shot => cards[shot.ShotKey]).ToArray())).ToArray();
        SelectedCellTitle = $"Cell{cellNo:00} / {Rows.Count:N0} Shots";
        ApplyPreview(cellNo);
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(null));
    }

    private void ApplyPreview(int selectedCellNo)
    {
        var preview = _buildPreview(selectedCellNo);
        PreviewImage = preview.Image;
        CellLabels = preview.CellLabels.Select(label => label with { Width = 26 }).ToArray();
        Summary = preview.Summary;
    }
}

public sealed record ST_ALIGN_OFFSET_VIEW_ROW(string ShotName, string Head, double StoredX, double StoredY,
    double? ScannerX, double? ScannerY, string HeadTransform)
{
    public string StoredTitle { get; init; } = "Design Offset (mm)";
}

public sealed record ST_ALIGN_OFFSET_VIEW_CARD_ROW(int RowNo, IReadOnlyList<ST_ALIGN_OFFSET_VIEW_ROW> Shots);
