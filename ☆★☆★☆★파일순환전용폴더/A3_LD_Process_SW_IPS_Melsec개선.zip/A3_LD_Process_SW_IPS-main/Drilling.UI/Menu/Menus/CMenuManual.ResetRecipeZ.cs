using System.Globalization;
using System.IO;
using Drilling.Common.Automation;
using Drilling.Common.Managers;
using Drilling.UI.Popup;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuManual
{
    private async Task<IReadOnlyDictionary<int, IReadOnlyList<ST_AUTOMATION_ABSOLUTE_MOVE_TARGET>>> PrepareResetRecipeZMoves(
        IReadOnlyList<ST_SYSTEM_PARAMETER> settings, IReadOnlyList<ST_CONTROLLER_RESET_SEQUENCE_TARGET_OPTION> controllers,
        CancellationToken cancellationToken)
    {
        var selectedControllers = controllers.Select(controller => controller.AutomationNo).ToHashSet();
        var hasZ = CScannerStatusSnapshotReader.BuildEnabledHeadNumbers(settings).SelectMany(head => CScannerStatusSnapshotReader.BuildAxisDefinitions(settings, head))
            .Any(axis => axis.AxisName == "Z" && axis.IsUsed && selectedControllers.Contains(axis.AutomationNo));
        var recipe = hasZ ? await LoadExactMotionRecipe(cancellationToken) : null;
        return controllers.ToDictionary(controller => controller.AutomationNo,
            controller => BuildResetRecipeZMoves(settings, recipe, controller.AutomationNo));
    }

    private async Task<ST_RECIPE_DEFINITION> LoadExactMotionRecipe(CancellationToken cancellationToken)
    {
        var recipeId = (_selectedRecipeIdProvider() ?? "").Trim();
        if (recipeId.Length == 0) throw new InvalidOperationException("DOE Z 이동에 사용할 Recipe를 선택해 주세요.");
        var recipe = await LoadSelectedRecipe(cancellationToken);
        if (recipe is null || !recipe.Id.Equals(recipeId, StringComparison.OrdinalIgnoreCase) ||
            !recipeId.Equals((_selectedRecipeIdProvider() ?? "").Trim(), StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("선택된 Recipe가 변경되었거나 Recipe를 불러올 수 없습니다.");
        return recipe;
    }

    private static IReadOnlyList<ST_AUTOMATION_ABSOLUTE_MOVE_TARGET> BuildResetRecipeZMoves(
        IReadOnlyList<ST_SYSTEM_PARAMETER> settings, ST_RECIPE_DEFINITION? recipe, int controller)
    {
        var moves = new List<ST_AUTOMATION_ABSOLUTE_MOVE_TARGET>();
        foreach (var head in CScannerStatusSnapshotReader.BuildEnabledHeadNumbers(settings))
        {
            var axis = CScannerStatusSnapshotReader.BuildAxisDefinitions(settings, head)
                .FirstOrDefault(axis => axis.AxisName == "Z" && axis.IsUsed && axis.AutomationNo == controller);
            if (!axis.IsUsed) continue;
            if (axis.ConfigurationError.Length > 0 || !IsConfiguredScannerAxisName(axis.AxisReference))
                throw new InvalidDataException($"HEAD {head:00} DOE Z축 설정을 확인해 주세요. {axis.ConfigurationError}");
            var position = ReadMotionRecipeValue(recipe, head, "DOE_Z_POSITION", double.NaN);
            var speed = ReadMotionRecipeValue(recipe, head, "SCANNER_Z_SPEED", 1.0);
            if (speed <= 0) throw new InvalidDataException($"HEAD {head:00} Scanner Z Speed는 0보다 커야 합니다.");
            var move = new ST_AUTOMATION_ABSOLUTE_MOVE_TARGET($"HEAD {head:00} / {axis.AxisReference}",
                controller, axis.AxisReference, axis.AioNo, axis.ReadExtendedStatus, position, speed);
            var duplicate = moves.FirstOrDefault(existing => existing.AxisReference.Equals(move.AxisReference, StringComparison.OrdinalIgnoreCase));
            if (duplicate is not null)
            {
                if (duplicate.Position != move.Position || duplicate.Speed != move.Speed)
                    throw new InvalidDataException($"{duplicate.Label}와 {move.Label}에 동일 축의 서로 다른 Recipe 이동값이 지정되어 있습니다.");
                continue;
            }
            moves.Add(move);
        }
        return moves;
    }

    private static double ReadMotionRecipeValue(ST_RECIPE_DEFINITION? recipe, int head, string suffix, double defaultValue)
    {
        if (recipe is null) throw new InvalidDataException("선택된 Recipe를 불러올 수 없습니다.");
        var key = $"H{head:00}_{suffix}";
        var parameter = recipe.Parameters.FirstOrDefault(p => key.Equals(p.Key, StringComparison.OrdinalIgnoreCase) || key.Equals(p.Name, StringComparison.OrdinalIgnoreCase));
        var value = defaultValue;
        if (parameter is not null && !double.TryParse(parameter.Value, NumberStyles.Float, CultureInfo.InvariantCulture, out value) || !double.IsFinite(value))
            throw new InvalidDataException($"Recipe {recipe.Id}: {key} 값을 확인해 주세요.");
        return value;
    }
}
