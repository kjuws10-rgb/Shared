using System.ComponentModel;
using System.Globalization;
using System.Windows;
using System.Windows.Media;
using Drilling.Common.Correction;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CAlignDistortionPanel
{
    public string AlgorithmPreviewHint { get; private set; } = "현재 레시피의 키 위치를 확인하세요.";
    public int PreviewRegionCount { get; private set; }
    public double? OffsetTolerance { get; private set; } = CAlignOffsetTolerance.DefaultValue;
    public string SettingToleranceText => OffsetTolerance is { } value
        ? $"Setting Tolerance : ±{value.ToString("0.000", CultureInfo.InvariantCulture)} mm"
        : "Setting Tolerance : 설정값 확인 필요";

    public void UpdateOffsetTolerance(double? value)
    {
        if (OffsetTolerance == value) return;
        OffsetTolerance = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SettingToleranceText)));
    }

    private ST_ALIGN_INTERPOLATION_KEY[] InterpolationKeys() => Keys.Select(key => new ST_ALIGN_INTERPOLATION_KEY(
        key.Name, key.GlassX, key.GlassY, key.BaseRawX - key.LastLoadRawX, key.BaseRawY - key.LastLoadRawY)).ToArray();

    private CAlignInterpolation CreateInterpolationModel()
    {
        if (Keys.Count != 10) throw new InvalidOperationException("현재 레시피의 AK / DK 위치를 확인하세요.");
        var selected = LoadKeyNames;
        if (Keys.Any(key => selected.Contains(key.Name) && !key.IsInsideGlass))
            throw new InvalidOperationException("선택한 키가 Glass 영역 밖에 있습니다. 레시피의 키 위치를 확인하세요.");
        return new CAlignInterpolation(InterpolationKeys(), selected.Where(name => name.StartsWith("DK", StringComparison.Ordinal)).ToArray());
    }

    public string OffsetInputSignature => RecipeId + "|" + LoadSelectionSignature + "|" +
        string.Join("|", Keys.Where(key => LoadKeyNames.Contains(key.Name)).Select(key => FormattableString.Invariant(
            $"{key.Name}:{key.BaseRawX:R},{key.BaseRawY:R},{key.LastLoadRawX:R},{key.LastLoadRawY:R}")));

    public CAlignInterpolation CreateLoadedInterpolationModel()
    {
        if (LastLoadedAt is null) throw new InvalidOperationException("선택한 AK / DK 값을 먼저 Load해 주세요.");
        foreach (var key in Keys.Where(key => LoadKeyNames.Contains(key.Name)))
        {
            if (key.LastLoadRawX is null || key.LastLoadRawY is null)
                throw new InvalidOperationException($"{key.Name}의 LastLoad가 없습니다. 현재 선택한 키를 다시 Load해 주세요.");
            if (!_lastLoadedPositions.TryGetValue(key.Name, out var position) || position.X != key.GlassX || position.Y != key.GlassY)
                throw new InvalidOperationException("Load 후 키 위치가 변경되었습니다. 현재 위치 기준으로 다시 Load해 주세요.");
        }
        var model = CreateInterpolationModel();
        model.ValidateMeasurements();
        return model;
    }

    private void DrawAlgorithmPreview(DrawingContext drawing)
    {
        PreviewRegionCount = 0;
        CAlignInterpolation model;
        try { model = CreateInterpolationModel(); }
        catch (InvalidOperationException error) { AlgorithmPreviewHint = error.Message; return; }
        Point Position(ST_ALIGN_INTERPOLATION_KEY key)
        {
            var source = Keys.Single(item => item.Name == key.Name);
            return new Point(source.MarkerX, source.MarkerY);
        }
        var rows = model.Rows;
        PreviewRegionCount = 1;
        var purple = MakeBrush(155, 116, 207);
        var outline = rows.Select(row => Position(row.Left)).Concat(rows.Reverse().Select(row => Position(row.Right))).ToArray();
        drawing.DrawGeometry(MakeBrush(155, 116, 207, 26), new Pen(purple, 1.8), Polygon(outline));
        foreach (var key in rows.SelectMany(row => new[] { row.Left, row.Right }))
            drawing.DrawEllipse(null, new Pen(MakeBrush(155, 116, 207, 180), 1.3), Position(key), 10, 10);
        var top = rows[0];
        var bottom = rows[^1];
        var center = new Point((Position(top.Left).X + Position(top.Right).X + Position(bottom.Left).X + Position(bottom.Right).X) / 4,
            (Position(top.Left).Y + Position(bottom.Left).Y) / 2);
        DrawRegionLabel(drawing, $"LAGRANGE\n{rows.Count * 2} KEYS", center, purple);
        AlgorithmPreviewHint = $"라그랑쥬: {rows.Count * 2}개 키를 함께 사용하는 전체 범위입니다. 보정량 분포는 표시하지 않습니다.";
    }

    private static StreamGeometry Polygon(IReadOnlyList<Point> points)
    {
        var geometry = new StreamGeometry();
        using (var context = geometry.Open())
        {
            context.BeginFigure(points[0], true, true);
            context.PolyLineTo(points.Skip(1).ToArray(), true, false);
        }
        geometry.Freeze();
        return geometry;
    }

    private static void DrawRegionLabel(DrawingContext drawing, string label, Point center, Brush brush)
    {
        if (Thread.CurrentThread.GetApartmentState() != ApartmentState.STA) return;
        var text = new FormattedText(label, CultureInfo.InvariantCulture, FlowDirection.LeftToRight,
            new Typeface(new FontFamily("Segoe UI"), FontStyles.Normal, FontWeights.SemiBold, FontStretches.Normal), 14, brush, 1)
            { TextAlignment = TextAlignment.Center };
        drawing.DrawText(text, new Point(center.X, center.Y - text.Height / 2));
    }
}
