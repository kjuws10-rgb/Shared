using System.Globalization;
using Drilling.Common.Interface;
using Drilling.Common.Managers;

namespace Drilling.UI.Menu.Menus;

// This service is called only by Load; it owns no polling timer or device worker.
public sealed class CAlignLastLoadService
{
    private readonly Func<IReadOnlyList<ST_INTERFACE_COMM_STATUS>> _connections;
    private readonly Func<IReadOnlyList<ST_MELSEC_MAP_DATA>> _map;
    private readonly Func<string, CancellationToken, double> _read;

    public CAlignLastLoadService(CInterfaceManager? manager) : this(
        () => manager?.GetInterfaceCommunicationList(EN_EQP_MODULE.Melsec) ?? [],
        () => manager?.Melsec.GetMapList() ?? [],
        (id, token) => manager?.Melsec.ReadDoubleNoLog(id, token)
            ?? throw new InvalidOperationException("MELSEC이 연결되어 있지 않습니다.")) { }

    public CAlignLastLoadService(Func<IReadOnlyList<ST_INTERFACE_COMM_STATUS>> connections,
        Func<IReadOnlyList<ST_MELSEC_MAP_DATA>> map, Func<string, CancellationToken, double> read)
    {
        _connections = connections;
        _map = map;
        _read = read;
    }

    public EN_COMM_STATE GetMode(IReadOnlyCollection<string>? parameterKeys = null)
    {
        var ids = Targets(parameterKeys).Select(MapId).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var numbers = _map().Where(row => ids.Contains(row.Id)).Select(row => row.DeviceNo).DefaultIfEmpty(0).Distinct().ToArray();
        var connections = _connections();
        var sources = numbers.Select(number => connections.FirstOrDefault(connection =>
            connection.Module == EN_EQP_MODULE.Melsec && connection.Number == number)).ToArray();
        // The configured simulation flag takes precedence even if the connection reports Offline or Online.
        if (sources.Any(source => source?.IsSimulation == true || source?.ConnectionState == EN_COMM_STATE.Simulation))
            return EN_COMM_STATE.Simulation;
        return sources.All(source => source?.ConnectionState == EN_COMM_STATE.Online) ? EN_COMM_STATE.Online : EN_COMM_STATE.Offline;
    }

    public static IReadOnlyDictionary<string, double> CreateSimulationValues(ST_RECIPE_DEFINITION recipe, Func<double>? random = null,
        IReadOnlyCollection<string>? parameterKeys = null)
    {
        random ??= Random.Shared.NextDouble;
        var values = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
        foreach (var key in Targets(parameterKeys))
        {
            var parameter = recipe.Parameters.SingleOrDefault(parameter => parameter.Key.Equals(key, StringComparison.OrdinalIgnoreCase));
            if (parameter is null || !double.TryParse(parameter.Value, NumberStyles.Float, CultureInfo.InvariantCulture, out var basis) || !double.IsFinite(basis))
                throw new InvalidOperationException($"{key}의 Base 값을 확인하세요.");
            var sample = random();
            if (!double.IsFinite(sample) || sample < 0 || sample > 1)
                throw new InvalidOperationException("시뮬레이션 랜덤값이 올바르지 않습니다.");
            values[key] = basis + (sample * 2 - 1);
        }
        return values;
    }

    public async Task<IReadOnlyDictionary<string, double>> ReadOnlineAsync(CancellationToken token = default,
        IReadOnlyCollection<string>? parameterKeys = null)
    {
        var requested = Targets(parameterKeys);
        token.ThrowIfCancellationRequested();
        if (GetMode(requested) != EN_COMM_STATE.Online)
            throw new InvalidOperationException("MELSEC 연결 상태가 변경되었습니다. Load를 다시 실행하세요.");
        var map = _map().ToDictionary(row => row.Id, StringComparer.OrdinalIgnoreCase);
        var targets = requested.Select(key => (Key: key, Id: MapId(key))).ToArray();
        // Validate the entire set before issuing any read, so missing addresses cannot publish a partial load.
        foreach (var target in targets)
        {
            if (!map.TryGetValue(target.Id, out var row) || !row.Use || string.IsNullOrWhiteSpace(row.Address) ||
                row.Address.Equals("UNASSIGNED", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException($"{target.Id}의 MELSEC 수신 주소가 설정되어 있지 않습니다.");
            if (row.Access == EN_MELSEC_ACCESS.Write || row.DataType is not (EN_MELSEC_DATA_TYPE.Double or EN_MELSEC_DATA_TYPE.Float))
                throw new InvalidOperationException($"{target.Id}의 읽기 권한과 데이터 형식(DOUBLE/FLOAT)을 확인하세요.");
            CMelsec.ValidateMapData(row);
        }
        var result = await Task.Run(() =>
        {
            var values = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
            foreach (var target in targets)
            {
                token.ThrowIfCancellationRequested();
                var value = _read(target.Id, token); // Serialized by the existing shared MELSEC request worker.
                if (!double.IsFinite(value)) throw new InvalidOperationException($"{target.Id}를 정상적으로 읽지 못했습니다.");
                values[target.Key] = value;
            }
            return values;
        }, token);
        token.ThrowIfCancellationRequested();
        var currentMap = _map().ToDictionary(row => row.Id, StringComparer.OrdinalIgnoreCase);
        if (GetMode(requested) != EN_COMM_STATE.Online || targets.Any(target => !currentMap.TryGetValue(target.Id, out var current) || current != map[target.Id]))
            throw new InvalidOperationException("MELSEC 연결 또는 맵이 변경되었습니다. Load를 다시 실행하세요.");
        return result;
    }

    private static string MapId(string key) => key.Replace("ALIGNBASE_", "ALIGN_LASTLOAD_", StringComparison.Ordinal);

    private static string[] Targets(IReadOnlyCollection<string>? parameterKeys)
    {
        var requested = (parameterKeys ?? CAlignBaseData.ParameterKeys).ToArray();
        if (requested.Length == 0 || requested.Distinct(StringComparer.Ordinal).Count() != requested.Length ||
            requested.Any(key => !CAlignBaseData.ParameterKeys.Contains(key)))
            throw new InvalidOperationException("Load 대상 키의 X/Y 항목을 확인하세요.");
        return requested;
    }
}
