using System.Globalization;
using System.IO;
using Drilling.Common.Managers;
using Drilling.Common.Recipe;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuManual
{
    private IReadOnlyDictionary<int, (double X, double Y)> CaptureManualScanOrigins(
        IReadOnlyList<ST_MANUAL_SHAPE_SCAN_ROUTE> routes, IReadOnlyList<ST_SYSTEM_PARAMETER> options,
        bool useCurrentPosition)
    {
        var origins = new Dictionary<int, (double X, double Y)>();
        // Capture every selected Head before the first asynchronous file read or confirmation.
        foreach (var route in routes)
        {
            if (!_manager.automation.IsSimul(route.AutomationNo) && !_manager.automation.IsConnect(route.AutomationNo))
                throw new InvalidOperationException($"CONTROLLER {route.AutomationNo + 1}이 연결되어 있지 않습니다.");
            if (!useCurrentPosition)
            {
                origins.Add(route.HeadNo, (0, 0));
                continue;
            }

            var definitions = CScannerStatusSnapshotReader.BuildAxisDefinitions(options, route.HeadNo);
            double ReadPosition(string role)
            {
                var axis = definitions.Single(definition => definition.AxisName == role);
                var snapshot = _manager.automation.StatusSnapshots.GetAxis(
                    axis.AxisReference, axis.AutomationNo, axis.AioNo, axis.ReadExtendedStatus);
                if (snapshot.State != "OK" || snapshot.Value is not { } status || !double.IsFinite(status.PositionFeedback))
                    throw new InvalidOperationException($"HEAD {route.HeadNo:00} / {axis.AxisReference}의 현재 위치를 확인할 수 없습니다.\n" +
                        $"상태: {snapshot.State}\n공통 위치 스냅샷이 갱신된 후 CurPos를 다시 눌러 주세요.");
                return status.PositionFeedback;
            }
            origins.Add(route.HeadNo, (ReadPosition("X"), ReadPosition("Y")));
        }
        return origins;
    }

    private static ST_MANUAL_SCAN_POSITION ResolveManualScanPosition(ST_MANUAL_SHAPE_SCAN_ROUTE route,
        IReadOnlyList<ST_SYSTEM_PARAMETER> options, ST_MANUAL_SCAN_PARAM settings,
        (double X, double Y) origin, bool useCurrentPosition)
    {
        var offset = CScannerAxisTransform.DesignOffsetToScanner(options, route.HeadNo, settings.OffsetX, settings.OffsetY);
        var position = new ST_MANUAL_SCAN_POSITION(useCurrentPosition, route.XAxis, route.YAxis,
            origin.X, origin.Y, offset.X, offset.Y);
        if (!double.IsFinite(position.TargetX) || !double.IsFinite(position.TargetY))
            throw new InvalidDataException($"HEAD {route.HeadNo:00}의 Offset 적용 위치를 계산할 수 없습니다.");
        return position;
    }

    private static string BuildManualScanConfirmation(IReadOnlyList<ST_MANUAL_SHAPE_SCAN_PROGRAM> programs, bool shapeScan)
    {
        var heads = programs.Select(program =>
        {
            var position = program.Position ?? throw new InvalidOperationException("가공 위치가 준비되지 않았습니다.");
            var action = shapeScan ? program.Settings.ShapeName : $"{program.Settings.LaserOnMode} / Repeat {program.Settings.RepeatCount}";
            var heading = $"HEAD {program.HeadNo:00} · {program.SettingName} / {action}";
            if (!position.UseCurrentPosition)
                return $"{heading}\nCenter (0, 0) + Offset = {position.XAxis} {Coordinate(position.TargetX)} mm / {position.YAxis} {Coordinate(position.TargetY)} mm";
            return $"{heading}\nCurPos {position.XAxis} {Coordinate(position.BaseX)} mm + Offset {Coordinate(position.OffsetX)} mm = {Coordinate(position.TargetX)} mm\n" +
                $"CurPos {position.YAxis} {Coordinate(position.BaseY)} mm + Offset {Coordinate(position.OffsetY)} mm = {Coordinate(position.TargetY)} mm";
        });
        var purpose = shapeScan ? "해당 위치를 중심으로 형상 가공하시겠습니까?" : "해당 위치에서 레이저를 동작시키시겠습니까?";
        return $"각 Head의 .scan 출력(W)에 맞춰 ATT를 이동합니다.\nOffset은 헤드별 축 좌표로 변환된 값입니다.\n\n{string.Join("\n\n", heads)}\n\n{purpose}";
    }

    private static string Coordinate(double value)
        => (Math.Round(value, 3) == 0 ? 0 : value).ToString("F3", CultureInfo.InvariantCulture);

    private sealed record ST_MANUAL_SCAN_POSITION(bool UseCurrentPosition, string XAxis, string YAxis,
        double BaseX, double BaseY, double OffsetX, double OffsetY)
    {
        public double TargetX => BaseX + OffsetX;
        public double TargetY => BaseY + OffsetY;
        public string ScriptComment => FormattableString.Invariant(
            $"// Position Reference={(UseCurrentPosition ? "CurPos" : "Center")}; Base=({BaseX:R}, {BaseY:R}) mm; Offset=({OffsetX:R}, {OffsetY:R}) mm; Target=({TargetX:R}, {TargetY:R}) mm");
    }
}
