using Drilling.Common.Interface;

namespace Drilling.UI.Menu.Menus;

internal static class CMelsecCachePresentation
{
    public static double NumericValue(object? value) => value switch
    {
        double number => number,
        float number => number,
        int number => number,
        uint number => number,
        short number => number,
        ushort number => number,
        long number => number,
        _ => double.NaN
    };

    public static string Describe(ST_MELSEC_CACHED_VALUE value)
    {
        var state = value.State.ToString().ToUpperInvariant();
        var message = string.IsNullOrWhiteSpace(value.ErrorMessage) ? state : $"{state}: {value.ErrorMessage}";
        return value.UpdatedAt is { } updatedAt
            ? $"{message} | Last received: {updatedAt.ToLocalTime():yyyy-MM-dd HH:mm:ss.fff}"
            : message;
    }
}
