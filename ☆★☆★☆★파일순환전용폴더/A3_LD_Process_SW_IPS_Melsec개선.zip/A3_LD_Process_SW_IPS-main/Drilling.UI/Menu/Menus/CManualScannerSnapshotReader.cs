﻿using System.Globalization;
using Drilling.Common.Automation;
using Drilling.Common.Managers;

namespace Drilling.UI.Menu.Menus;
// Presentation adapter only: no timer, thread, or device reads.
internal sealed class CManualScannerSnapshotReader(CAutomationManager automationManager)
{
    private readonly object _snapshotLock = new();
    private IReadOnlyList<ST_MANUAL_SCANNER_AXIS> _snapshot = [];
    private IReadOnlyList<ST_SCANNER_AXIS_SETTING> _axisDefinitions = [];
    private int[] _selectedHeadNos = [];
    private long _selectionGeneration;

    public void SelectHead(int headNo, IReadOnlyList<ST_SYSTEM_PARAMETER> settings)
        => SelectHeads([headNo], settings);

    public void SelectHeads(IEnumerable<int> headNos, IReadOnlyList<ST_SYSTEM_PARAMETER> settings)
    {
        var heads = headNos.Where(head => head is >= 1 and <= 8).Distinct().Order().ToArray();
        var axisDefinitions = heads.SelectMany(head => CScannerStatusSnapshotReader.BuildAxisDefinitions(settings, head)).ToArray();
        lock (_snapshotLock)
        {
            if (_selectedHeadNos.SequenceEqual(heads) && IsSameAxisDefinitions(_axisDefinitions, axisDefinitions))
            {
                return;
            }

            _selectedHeadNos = heads;
            _selectionGeneration++;
            _axisDefinitions = axisDefinitions;
            _snapshot = [];
        }
    }

    public IReadOnlyList<ST_MANUAL_SCANNER_AXIS> GetSnapshot()
    {
        RefreshSnapshot(CancellationToken.None);
        lock (_snapshotLock) return _snapshot;
    }

    internal static IReadOnlyList<ST_MANUAL_SCANNER_AXIS> BuildFallbackAxes(IReadOnlyList<ST_SYSTEM_PARAMETER> settings, int selectedHeadNo)
    {
        return BuildFallbackAxes(settings, selectedHeadNo, "LOADING", "Waiting for shared Automation snapshot...");
    }

    private static IReadOnlyList<ST_MANUAL_SCANNER_AXIS> BuildFallbackAxes(IReadOnlyList<ST_SYSTEM_PARAMETER> settings, int selectedHeadNo, string state, string detail)
    {
        var definitions = CScannerStatusSnapshotReader.BuildAxisDefinitions(settings, selectedHeadNo);
        var axes = new List<ST_MANUAL_SCANNER_AXIS>(definitions.Count);
        foreach (var definition in definitions)
        {
            var automationLabel = $"#{definition.AutomationNo.ToString(CultureInfo.InvariantCulture)}";
            if (!definition.IsUsed)
            {
                axes.Add(new ST_MANUAL_SCANNER_AXIS(definition.HeadNo, $"H{definition.HeadNo:00}", automationLabel, definition.AutomationNo, definition.AxisName, "Z NOT USE", "NOT USE", "-", "-", "-", "NOT USE", "Scanner Z axis is not used."));
                continue;
            }

            var axisReference = definition.AxisReference.Trim();
            axes.Add(new ST_MANUAL_SCANNER_AXIS(definition.HeadNo, $"H{definition.HeadNo:00}", automationLabel, definition.AutomationNo, definition.AxisName, axisReference, state, "-", "-", "-", state, detail));
        }

        return axes;
    }

    private void RefreshSnapshot(CancellationToken cancellationToken)
    {
        int[] heads;
        IReadOnlyList<ST_SCANNER_AXIS_SETTING> definitions;
        long generation;
        lock (_snapshotLock)
        {
            heads = _selectedHeadNos;
            definitions = _axisDefinitions;
            generation = _selectionGeneration;
        }
        var axes = new List<ST_MANUAL_SCANNER_AXIS>();
        foreach (var head in heads)
        {
            cancellationToken.ThrowIfCancellationRequested();
            try
            {
                foreach (var definition in definitions.Where(axis => axis.HeadNo == head))
                    axes.Add(BuildManualScannerAxis(definition, cancellationToken));
            }
            catch (Exception exception) when (exception is not OperationCanceledException)
            {
                axes.AddRange(CreatePollingErrorSnapshot(head, exception.Message));
            }
        }
        lock (_snapshotLock)
        {
            if (_selectionGeneration == generation) _snapshot = axes;
        }
    }

    private ST_MANUAL_SCANNER_AXIS BuildManualScannerAxis(ST_SCANNER_AXIS_SETTING axis, CancellationToken cancellationToken)
    {
        var axisReference = axis.AxisReference.Trim();
        var displayAxisReference = string.IsNullOrWhiteSpace(axisReference) ? "-" : axisReference;
        var automationLabel = $"#{axis.AutomationNo.ToString(CultureInfo.InvariantCulture)}";
        if (!axis.IsUsed)
        {
            return new ST_MANUAL_SCANNER_AXIS(axis.HeadNo, $"H{axis.HeadNo:00}", automationLabel, axis.AutomationNo, axis.AxisName, "Z NOT USE", "NOT USE", "-", "-", "-", "NOT USE", "Scanner Z axis is not used.");
        }

        if (!string.IsNullOrWhiteSpace(axis.ConfigurationError))
        {
            return new ST_MANUAL_SCANNER_AXIS(axis.HeadNo, $"H{axis.HeadNo:00}", automationLabel, axis.AutomationNo, axis.AxisName, displayAxisReference, "NOT CONFIGURED", "NO", "-", "-", "NOT CONFIGURED", axis.ConfigurationError);
        }

        try
        {
            if (!automationManager.IsSimul(axis.AutomationNo) && !automationManager.IsConnect(axis.AutomationNo))
            {
                return new ST_MANUAL_SCANNER_AXIS(axis.HeadNo, $"H{axis.HeadNo:00}", automationLabel, axis.AutomationNo, axis.AxisName, displayAxisReference, "DISABLE", "NO", "-", "-", "OFFLINE", "Automation not connected.");
            }

            var snapshot = automationManager.StatusSnapshots.GetAxis(axisReference, axis.AutomationNo, axis.AioNo, axis.ReadExtendedStatus);
            if (snapshot.Value is not { } status)
                return new ST_MANUAL_SCANNER_AXIS(axis.HeadNo, $"H{axis.HeadNo:00}", automationLabel, axis.AutomationNo, axis.AxisName, displayAxisReference, snapshot.State, "-", "-", "-", snapshot.State, snapshot.Detail);
            return CreateManualScannerAxis(axis, automationLabel, displayAxisReference, status);
        }
        catch (Exception exception)when (exception is not OperationCanceledException)
        {
            return new ST_MANUAL_SCANNER_AXIS(axis.HeadNo, $"H{axis.HeadNo:00}", automationLabel, axis.AutomationNo, axis.AxisName, displayAxisReference, "ERROR", "NO", "-", "-", "ERROR", exception.Message);
        }
    }

    private static ST_MANUAL_SCANNER_AXIS CreateManualScannerAxis(ST_SCANNER_AXIS_SETTING axis, string automationLabel, string axisReference, ST_AUTOMATION_AXIS_STATUS status)
    {
        return new ST_MANUAL_SCANNER_AXIS(axis.HeadNo, $"H{axis.HeadNo:00}", automationLabel, axis.AutomationNo, axis.AxisName, axisReference, status.Able ? "ENABLE" : "DISABLE", status.HomeDone ? "OK" : "NO", FormatScannerPosition(status.PositionFeedback), FormatExtendedScannerPosition(status.AuxiliaryFeedback, axis.ReadExtendedStatus), status.HasError ? "ERROR" : "OK", string.IsNullOrWhiteSpace(status.RawResponse) ? "-" : status.RawResponse)
        { FaultMask = CAutomationAxisFault.ParseMask(status.Fault) };
    }

    private static IReadOnlyList<ST_MANUAL_SCANNER_AXIS> CreatePollingErrorSnapshot(int selectedHeadNo, string message)
    {
        var normalizedHeadNo = NormalizeHeadNo(selectedHeadNo);
        var headName = $"H{normalizedHeadNo:00}";
        var detail = string.IsNullOrWhiteSpace(message) ? "Manual scanner status polling failed." : message;
        return [new ST_MANUAL_SCANNER_AXIS(normalizedHeadNo, headName, "-", 0, "-", "-", "ERROR", "NO", "-", "-", "ERROR", detail)];
    }

    private static bool IsSameAxisDefinitions(IReadOnlyList<ST_SCANNER_AXIS_SETTING> left, IReadOnlyList<ST_SCANNER_AXIS_SETTING> right)
    {
        if (left.Count != right.Count)
        {
            return false;
        }

        for (var index = 0; index < left.Count; index++)
        {
            if (!left[index].Equals(right[index]))
            {
                return false;
            }
        }

        return true;
    }

    private static int NormalizeHeadNo(int headNo)
    {
        return Math.Clamp(headNo, 1, 8);
    }

    private static string FormatScannerPosition(double value)
    {
        if (!double.IsFinite(value))
        {
            return "-";
        }

        return value.ToString("F3", CultureInfo.InvariantCulture);
    }

    private static string FormatExtendedScannerPosition(double value, bool readExtendedStatus)
    {
        return readExtendedStatus ? FormatScannerPosition(value) : "-";
    }
}
