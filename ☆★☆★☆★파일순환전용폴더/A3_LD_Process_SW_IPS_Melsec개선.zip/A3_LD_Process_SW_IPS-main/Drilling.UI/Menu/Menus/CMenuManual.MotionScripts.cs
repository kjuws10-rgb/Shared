using System.Diagnostics;
using System.IO;
using Drilling.Common.Managers;
using Drilling.Common.Station;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuManual
{
    private CancellationTokenSource? _manualMotionScriptCancellation;
    private (int Controller, int Task)? _manualMotionScriptTask;
    private bool _manualMotionStopPending;
    private bool IsManualMotionScriptActive => _manualMotionStopPending || _manualMotionScriptCancellation is not null || _manualMotionScriptTask is not null;

    private async Task RunMotionScript(CManualMotionAxis row, string mode)
    {
        var generation = MotionSession.Generation;
        var head = MotionPanel.SelectedHead?.HeadNo ?? 0;
        CancellationTokenSource? run = null;
        var attemptedAxes = new List<(int Controller, string Axis)>();
        try
        {
            var axis = ValidateMotionAxis(head, row.Role, row.AxisName);
            var y = mode == "CENTER" ? ValidateMotionAxis(head, "Y", MotionPanel.Axes[1].AxisName) : axis;
            var options = _manager.Setting().LoadSection(EN_SETTING_TAB.Option);
            var task = ReadManualHeadAutomationTaskNo(options, head);
            var position = 0.0;
            var speed = mode == "CENTER" ? ReadManualDouble("JumpSpeed") * 1000.0 : 1.0;
            var ramp = 500000.0;
            if (mode == "RECIPE")
            {
                var recipe = await LoadExactMotionRecipe(default);
                position = ReadMotionRecipeValue(recipe, head, "DOE_Z_POSITION", double.NaN);
                speed = ReadMotionRecipeValue(recipe, head, "SCANNER_Z_SPEED", 1.0);
                ramp = ReadMotionRecipeValue(recipe, head, "SCANNER_Z_RAMP_RATE", 500000.0);
            }
            if (!double.IsFinite(speed) || speed <= 0 || !double.IsFinite(ramp) || ramp <= 0)
                throw new InvalidDataException("Recipe/Manual 이동 속도와 가속도를 확인해 주세요.");
            if (generation != MotionSession.Generation || IsManualMotionScriptActive) return;
            run = new CancellationTokenSource();
            _manualMotionScriptCancellation = run;
            var token = run.Token;
            var name = $"MANUAL_H{head:00}_{(mode == "CENTER" ? "CENTER_MOVE" : "Z_RECIPE_POSITION_MOVE")}.ascript";
            var script = _scriptFile.Create(name);
            script.SetDeviceNo(head - 1);
            script.Start($"Manual HEAD {head:00} {mode}");
            AppendMotionPositionScript(script, mode, axis.AxisReference, y.AxisReference, position, speed, ramp);
            script.End();
            var saved = script.Save(token);
            string? response = null;
            var launchedAt = 0L;
            await MotionSession.Execute(generation, async () =>
            {
                if (ValidateMotionAxis(head, row.Role, row.AxisName) != axis ||
                    mode == "CENTER" && ValidateMotionAxis(head, "Y", y.AxisReference) != y)
                    throw new InvalidOperationException("이동 축 설정이 변경되었습니다.");
                await EnsureMotionScriptTaskReady(axis.AutomationNo, task, token);
                EnsureAutomationResponse(await _manager.automation.UploadScript(saved.FilePath, saved.FileName, axis.AutomationNo, token), "Motion script upload");
                token.ThrowIfCancellationRequested();
                if (generation != MotionSession.Generation) return;
                await EnsureMotionScriptTaskReady(axis.AutomationNo, task, token);
                token.ThrowIfCancellationRequested();
                if (generation != MotionSession.Generation) return;
                _manualMotionTargets.Add((axis.AutomationNo, axis.AxisReference));
                if (mode == "CENTER") _manualMotionTargets.Add((y.AutomationNo, y.AxisReference));
                _manualMotionScriptTask = (axis.AutomationNo, task);
                attemptedAxes.Add((axis.AutomationNo, axis.AxisReference));
                if (mode == "CENTER") attemptedAxes.Add((y.AutomationNo, y.AxisReference));
                response = await _manager.automation.RunScript(saved.FileName, task, axis.AutomationNo, token);
                EnsureAutomationResponse(response, "Motion script run");
                launchedAt = Stopwatch.GetTimestamp();
            });
            if (response is null) return;
            _setStatusMessage($"HEAD {head:00}: {saved.FileName} 실행 중");
            await WaitMotionScriptFinished(response, axis.AutomationNo, task, launchedAt, token);
            _manualMotionScriptTask = null;
            _setStatusMessage($"HEAD {head:00}: {saved.FileName} 완료");
        }
        catch (Exception exception)
        {
            var stopErrors = new List<string>();
            try { await StopMotionScriptTask(); }
            catch (Exception stopFailure) { stopErrors.Add(stopFailure.Message); }
            foreach (var target in attemptedAxes)
            {
                try
                {
                    using var stop = new CancellationTokenSource(TimeSpan.FromSeconds(5));
                    EnsureAutomationResponse(await _manager.automation.AbortMotion(target.Axis, target.Controller, stop.Token).WaitAsync(stop.Token), "Motion STOP");
                }
                catch (Exception stopFailure) { stopErrors.Add($"{target.Axis}: {stopFailure.Message}"); }
            }
            if (stopErrors.Count > 0)
            {
                _manualMotionStopPending = true;
                exception = new InvalidOperationException($"{exception.Message}\n정지 실패 (MOVE STOP으로 다시 정지해 주세요): {string.Join("\n", stopErrors)}", exception);
            }
            if (exception is not OperationCanceledException) MotionError(exception);
        }
        finally
        {
            if (ReferenceEquals(_manualMotionScriptCancellation, run)) _manualMotionScriptCancellation = null;
            run?.Dispose();
        }
    }

    private static void AppendMotionPositionScript(CAutomation1ScriptBase script, string mode, string axis,
        string yAxis, double position, double speed, double ramp)
    {
        if (mode == "RECIPE") { AppendManualZMoveScript(script, axis, position, speed, ramp); return; }
        script.SetAxis(axis, yAxis);
        script.AddLine("IfovOff()");
        script.AddLine("SetupTaskDistanceUnits(DistanceUnits.Primary)");
        script.AddLine("SetupTaskTimeUnits(TimeUnits.Seconds)");
        script.AddLine("VelocityBlendingOff()");
        script.AddLine("SetupTaskWaitMode(WaitMode.Auto)");
        script.AddLine("SetupTaskTargetMode(TargetMode.Absolute)");
        script.SetJumpSpeed(speed / 1000.0);
        script.Jump(0, 0);
        script.WaitMoveDone();
    }

    private async Task EnsureMotionScriptTaskReady(int controller, int task, CancellationToken token)
    {
        var response = await _manager.automation.ReadTaskStatus(task, controller, token);
        var state = ReadMotionTaskState(response, task);
        if (state is not "Idle" and not "ProgramComplete")
            throw new InvalidOperationException($"CONTROLLER {controller + 1} Task {task}: {state}");
    }

    private async Task WaitMotionScriptFinished(string response, int controller, int task, long launchedAt, CancellationToken token)
    {
        var state = ReadMotionTaskState(response, task);
        if (_manager.automation.IsSimul(controller) && state == "Idle" || state == "ProgramComplete") return;
        var started = state is "Running" or "ProgramRunning";
        var elapsed = Stopwatch.StartNew();
        while (elapsed.Elapsed < TimeSpan.FromSeconds(60))
        {
            token.ThrowIfCancellationRequested();
            var snapshot = _manager.automation.StatusSnapshots.GetTask(task, controller);
            if (snapshot.State is "ERROR" or "OFFLINE" or "STOPPED") throw new InvalidOperationException(snapshot.Detail);
            if (snapshot.State == "OK" && snapshot.Value is { } status && snapshot.CollectedTimestamp > launchedAt)
            {
                state = ReadMotionTaskState(status, task);
                if (state == "ProgramComplete" || started && state == "Idle") return;
                if (state is "Error" or "Unavailable" or "Inactive") throw new InvalidOperationException(status);
                started |= state is "Running" or "ProgramRunning";
            }
            await Task.Delay(200, token);
        }
        throw new TimeoutException($"CONTROLLER {controller + 1} Task {task} 이동 완료 확인 시간 초과");
    }

    private static string ReadMotionTaskState(string response, int task)
    {
        var fields = response.Split(':');
        if (fields.Length < 4 || fields[0] != "OK" || fields[1] != "TASK" || fields[2] != task.ToString(System.Globalization.CultureInfo.InvariantCulture))
            throw new InvalidOperationException($"이동 Task 응답이 올바르지 않습니다: {response}");
        return fields[3];
    }

    private async Task StopMotionScriptTask()
    {
        if (_manualMotionScriptTask is not { } target) return;
        using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(5));
        EnsureAutomationResponse(await _manager.automation.StopTask(target.Task, target.Controller, timeout.Token).WaitAsync(timeout.Token), "Motion script STOP");
        _manualMotionScriptTask = null;
    }
}
