using System.ComponentModel;
using Drilling.Common.Automation;
using Drilling.Common.Managers;
using Drilling.UI.Popup;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuManual
{
    private CManualMotionPanel? _motionPanel;
    public CManualMotionPanel MotionPanel => _motionPanel ??= new(this);
    private CManualMotionSession? _motionSession;
    private CManualMotionSession MotionSession => _motionSession ??= new();
    private readonly HashSet<(int Controller, string Axis)> _manualMotionTargets = [];
    private bool _stoppingMotionJog;
    private bool _motionErrorOpen;
    internal bool IsMotionConfirmationOpen { get; private set; }

    internal async Task StopMotionJog()
    {
        // A failed stop can open a dialog and cause another window-deactivation event.
        // Coalesce those events while retaining the session's stop target for a later retry.
        if (_stoppingMotionJog) { MotionSession.Invalidate(); return; }
        _stoppingMotionJog = true;
        try { await MotionSession.StopJog(); }
        catch (Exception exception) { MotionError(exception); }
        finally { _stoppingMotionJog = false; }
    }

    private void MotionError(Exception exception)
    {
        _setStatusMessage?.Invoke($"Manual Motion: {exception.Message}");
        if (_motionErrorOpen) return;
        _motionErrorOpen = true;
        try { CRecipeConfirmDialog.ShowWarning("Manual Motion", exception.Message); }
        finally { _motionErrorOpen = false; }
    }

    private ST_SCANNER_AXIS_SETTING ValidateMotionAxis(int head, string role, string expectedAxis)
    {
        if (TryBlockManualAutomationCommand("MANUAL_MOTION")) throw new InvalidOperationException("자동 운전 중에는 수동 이동할 수 없습니다.");
        if (!IsManualMotionTab || MotionPanel.SelectedHead?.HeadNo != head || !SelectedManualHeadNos.Contains(head))
            throw new InvalidOperationException("이동할 Head를 다시 선택해 주세요.");
        var settings = _manager.Setting().LoadSection(EN_SETTING_TAB.Option);
        if (!CScannerStatusSnapshotReader.BuildEnabledHeadNumbers(settings).Contains(head))
            throw new InvalidOperationException("사용하지 않는 Head입니다.");
        var axis = CScannerStatusSnapshotReader.BuildAxisDefinitions(settings, head).Single(a => a.AxisName == role);
        if (!axis.IsUsed || axis.ConfigurationError.Length > 0 || axis.AxisReference != expectedAxis)
            throw new InvalidOperationException("축 설정을 확인하고 Head를 다시 선택해 주세요.");
        if (!_manager.automation.IsSimul(axis.AutomationNo) && !_manager.automation.IsConnect(axis.AutomationNo))
            throw new InvalidOperationException($"Automation {axis.AutomationNo}: OFFLINE");
        return axis;
    }

    internal async Task RunMotion(CManualMotionAxis row, string mode)
    {
        if (IsManualMotionScriptActive) { MotionError(new InvalidOperationException("이동 스크립트가 실행 중입니다. 완료 또는 MOVE STOP 후 실행해 주세요.")); return; }
        if (mode is "CENTER" or "RECIPE") { await RunMotionScript(row, mode); return; }
        var generation = MotionSession.Generation;
        var head = MotionPanel.SelectedHead?.HeadNo ?? 0;
        var axisName = row.AxisName;
        var input = mode == "REL" ? row.Relative : row.Absolute;
        try
        {
            var target = ValidateMotionAxis(head, row.Role, axisName);
            var centerY = mode == "CENTER" ? ValidateMotionAxis(head, "Y", MotionPanel.Axes[1].AxisName) : target;
            var value = mode == "CENTER" ? 0 : mode == "RECIPE" ? double.NaN : ReadRequiredDouble(input, axisName);
            var speed = row.Role == "Z" ? 1.0 : ReadManualDouble("JumpSpeed") * 1000.0;
            if (row.Role == "Z")
            {
                var recipeId = _selectedRecipeIdProvider();
                var recipe = await LoadSelectedRecipe(default);
                if (recipe is null || !recipe.Id.Equals(recipeId, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("선택된 Recipe를 확인해 주세요.");
                speed = ReadHeadRecipeDouble(recipe, head, 1.0, "SCANNER_Z_SPEED");
                if (mode == "RECIPE") value = ReadHeadRecipeDouble(recipe, head, double.NaN, "DOE_Z_POSITION");
            }
            if (!double.IsFinite(value) || !double.IsFinite(speed) || speed <= 0)
                throw new InvalidOperationException("이동값과 Recipe/Manual 이동 속도를 확인해 주세요.");
            if (generation != MotionSession.Generation) return;
            if (mode is "ABS" or "REL")
            {
                IsMotionConfirmationOpen = true;
                try
                {
                    var description = mode == "ABS" ? "절대 목표 위치" : "상대 이동 거리";
                    if (!CRecipeConfirmDialog.ShowConfirmation($"{mode} 이동 확인",
                        $"HEAD {head:00} / {axisName}\n{description}: {value:G} mm\n\n이동하시겠습니까?", "이동")) return;
                }
                finally { IsMotionConfirmationOpen = false; }
            }
            await MotionSession.Execute(generation, async () =>
            {
                if (ValidateMotionAxis(head, row.Role, axisName) != target)
                    throw new InvalidOperationException("이동 축 설정이 변경되었습니다.");
                _manualMotionTargets.Add((target.AutomationNo, target.AxisReference));
                EnsureAutomationResponse(await _manager.automation.ManualMove(axisName, value, speed, mode == "REL", target.AutomationNo), "Manual Motion");
                if (mode == "CENTER" && generation == MotionSession.Generation)
                {
                    if (ValidateMotionAxis(head, "Y", centerY.AxisReference) != centerY)
                        throw new InvalidOperationException("Y축 설정이 변경되었습니다.");
                    _manualMotionTargets.Add((centerY.AutomationNo, centerY.AxisReference));
                    EnsureAutomationResponse(await _manager.automation.ManualMove(centerY.AxisReference, 0, speed, false, centerY.AutomationNo), "CENTER MOVE Y");
                }
                _setStatusMessage($"HEAD {head:00} · {axisName} {mode} {value:0.###} mm 명령 전송");
            });
        }
        catch (Exception exception) { MotionError(exception); }
    }

    internal async Task StartMotionJog(CManualMotionAxis row, int direction)
    {
        if (IsManualMotionScriptActive) { MotionError(new InvalidOperationException("이동 스크립트 실행 중에는 JOG를 시작할 수 없습니다.")); return; }
        var generation = MotionSession.Generation;
        var head = MotionPanel.SelectedHead?.HeadNo ?? 0;
        var axisName = row.AxisName;
        try
        {
            var target = ValidateMotionAxis(head, row.Role, axisName);
            await MotionSession.Execute(generation, async () =>
            {
                if (ValidateMotionAxis(head, row.Role, axisName) != target)
                    throw new InvalidOperationException("이동 축 설정이 변경되었습니다.");
                _manualMotionTargets.Add((target.AutomationNo, axisName));
                EnsureAutomationResponse(await _manager.automation.JogStart(axisName, direction < 0 ? -5.0 : 5.0, target.AutomationNo), "JOG");
            }, async () => EnsureAutomationResponse(await _manager.automation.JogStop(axisName, target.AutomationNo), "JOG STOP"));
        }
        catch (Exception exception)
        {
            // Release any start that may have reached the controller before reporting failure.
            await StopMotionJog();
            MotionError(exception);
        }
    }

    internal async Task StopAllManualMotion()
    {
        _manualMotionScriptCancellation?.Cancel();
        try
        {
            await MotionSession.StopAll(async () =>
            {
                var targets = new HashSet<(int Controller, string Axis)>(_manualMotionTargets);
                var errors = new List<string>();
                try { await StopMotionScriptTask(); }
                catch (Exception exception) { errors.Add(exception.Message); }
                try
                {
                    var settings = _manager.Setting().LoadSection(EN_SETTING_TAB.Option);
                    foreach (var head in CScannerStatusSnapshotReader.BuildEnabledHeadNumbers(settings))
                        foreach (var axis in CScannerStatusSnapshotReader.BuildAxisDefinitions(settings, head))
                            if (axis.IsUsed && axis.ConfigurationError.Length == 0) targets.Add((axis.AutomationNo, axis.AxisReference));
                }
                catch (Exception exception) { errors.Add(exception.Message); }
                foreach (var target in targets)
                {
                    try { EnsureAutomationResponse(await _manager.automation.AbortMotion(target.Axis, target.Controller), "MOVE STOP"); }
                    catch (Exception exception) { errors.Add($"Automation {target.Controller} / {target.Axis}: {exception.Message}"); }
                }
                if (errors.Count > 0) throw new InvalidOperationException(string.Join("\n", errors));
                  _manualMotionStopPending = false;
                _setStatusMessage("모든 Head 축에 MOVE STOP 명령을 전송했습니다.");
            });
        }
        catch (Exception exception) { MotionError(exception); }
    }
}

public sealed class CManualMotionPanel : INotifyPropertyChanged
{
    private readonly CMenuManual _owner;
    private ST_MANUAL_CONTROLLER_HEAD? _selectedHead;
    public event PropertyChangedEventHandler? PropertyChanged;
    public IReadOnlyList<CManualMotionAxis> Axes { get; }
    public ST_MANUAL_CONTROLLER_HEAD? SelectedHead
    {
        get => _selectedHead;
        set
        {
            if (ReferenceEquals(value, _selectedHead)) return;
            if (_selectedHead is not null) _selectedHead.PropertyChanged -= HeadChanged;
            _selectedHead = value;
            if (_selectedHead is not null) _selectedHead.PropertyChanged += HeadChanged;
            _ = _owner.StopMotionJog();
            RefreshAxes();
            PropertyChanged?.Invoke(this, new(nameof(SelectedHead)));
            PropertyChanged?.Invoke(this, new(nameof(Title)));
        }
    }
    public string Title => SelectedHead is null ? "표에서 이동할 Head를 선택해 주세요." : $"{SelectedHead.HeadName} · MOTION";
    public CButtonCommand CenterCommand { get; }
    public CButtonCommand RecipeCommand { get; }
    public CButtonCommand StopCommand { get; }
    public CManualMotionPanel(CMenuManual owner)
    {
        _owner = owner;
        Axes = new[] { "X", "Y", "Z" }.Select(role => new CManualMotionAxis(owner, role)).ToArray();
        CenterCommand = new(async _ => await owner.RunMotion(Axes[0], "CENTER"), _ => Axes[0].CanMove && Axes[1].CanMove);
        RecipeCommand = new(async _ => await owner.RunMotion(Axes[2], "RECIPE"), _ => Axes[2].CanMove);
        StopCommand = new(async _ => await owner.StopAllManualMotion());
    }
    private void HeadChanged(object? sender, PropertyChangedEventArgs e) { if (e.PropertyName == nameof(ST_MANUAL_CONTROLLER_HEAD.Axes)) RefreshAxes(); }
    private void RefreshAxes()
    {
        foreach (var row in Axes) row.SetAxis(SelectedHead?.Axes.FirstOrDefault(a => a.AxisRole == row.Role));
        CenterCommand.NotifyCanExecuteChanged(); RecipeCommand.NotifyCanExecuteChanged();
    }
    public void RefreshHeads(IReadOnlyList<ST_MANUAL_CONTROLLER_HEAD> heads)
    {
        if (SelectedHead is not null && !heads.Contains(SelectedHead)) SelectedHead = null;
    }
    public Task CancelPendingAndStopJog() => _owner.StopMotionJog();
    public bool IsConfirmationOpen => _owner.IsMotionConfirmationOpen;
}

public sealed class CManualMotionAxis : INotifyPropertyChanged
{
    private readonly CMenuManual _owner;
    private ST_MANUAL_SCANNER_AXIS? _axis;
    public event PropertyChangedEventHandler? PropertyChanged;
    public string Role { get; }
    public string AxisName => _axis?.AxisReference ?? Role;
    public bool CanMove => _axis is { IsControlEnabled: true } && AxisName != "-";
    public string Absolute { get; set; } = "0.000";
    public string Relative { get; set; } = "0.000";
    public CButtonCommand AbsoluteCommand { get; }
    public CButtonCommand RelativeCommand { get; }
    public CManualMotionAxis(CMenuManual owner, string role)
    {
        _owner = owner; Role = role;
        AbsoluteCommand = new(async _ => await owner.RunMotion(this, "ABS"), _ => CanMove);
        RelativeCommand = new(async _ => await owner.RunMotion(this, "REL"), _ => CanMove);
    }
    public Task StartJog(int direction) => _owner.StartMotionJog(this, direction);
    public Task StopJog() => _owner.StopMotionJog();
    internal void SetAxis(ST_MANUAL_SCANNER_AXIS? axis)
    {
        if (_axis == axis) return;
        var changed = _axis?.HeadNo != axis?.HeadNo || _axis?.AxisReference != axis?.AxisReference || _axis?.AutomationNo != axis?.AutomationNo;
        _axis = axis;
        if (changed) { Absolute = "0.000"; Relative = "0.000"; _ = StopJog(); }
        PropertyChanged?.Invoke(this, new(string.Empty));
        AbsoluteCommand.NotifyCanExecuteChanged(); RelativeCommand.NotifyCanExecuteChanged();
    }
}
