using System.ComponentModel;
using System.Globalization;
using System.Windows;
using Drilling.Common.Automation;
using Drilling.Common.Managers;
using Drilling.UI.Popup;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuManual
{
    private CManualHomeSpeedPanel? _homeSpeedPanel;
    private int? _homeSpeedController;
    private CManualHomeSpeedDialog? _homeSpeedDialog;
    private CButtonCommand? _openHomeSpeedSettingsCommand;
    public CButtonCommand OpenHomeSpeedSettingsCommand => _openHomeSpeedSettingsCommand ??= new(
        OpenHomeSpeedSettings, value => _homeSpeedDialog is null && value is ST_MANUAL_HEAD_GROUP group &&
            group.Heads.Any(head => SelectedManualHeadNos.Contains(head.HeadNo)));
    public CManualHomeSpeedPanel HomeSpeedPanel => _homeSpeedPanel ??= new(
        (controller, axes) => _manager.automation.StatusSnapshots.GetConfiguredHomeSpeeds(axes, controller),
        controller => _manager.automation.StatusSnapshots.RequestConfiguredHomeSpeedsRefresh(controller),
        SaveManualHomeSpeed,
        message => CRecipeConfirmDialog.ShowWarning("HOME SPEED SET", message, _homeSpeedDialog is { IsVisible: true } ? _homeSpeedDialog : null),
        message => { _setStatusMessage(message); CRecipeConfirmDialog.ShowCompletion("HOME SPEED 저장 완료", message, _homeSpeedDialog is { IsVisible: true } ? _homeSpeedDialog : null); });

    private void OpenHomeSpeedSettings(object? parameter)
    {
        if (parameter is not ST_MANUAL_HEAD_GROUP group || _homeSpeedDialog is not null) return;
        try
        {
            _homeSpeedController = group.AutomationNo;
            RefreshManualHomeSpeedTargets();
            var dialog = new CManualHomeSpeedDialog(group.Title, HomeSpeedPanel) { Owner = Application.Current?.MainWindow };
            _homeSpeedDialog = dialog;
            OpenHomeSpeedSettingsCommand.NotifyCanExecuteChanged();
            dialog.ShowDialog();
        }
        finally
        {
            _homeSpeedDialog = null;
            _homeSpeedController = null;
            HomeSpeedPanel.SetActive(false);
            OpenHomeSpeedSettingsCommand.NotifyCanExecuteChanged();
        }
    }

    private void RefreshManualHomeSpeedTargets()
    {
        _openHomeSpeedSettingsCommand?.NotifyCanExecuteChanged();
        if (_homeSpeedController is not { } controller) { _homeSpeedPanel?.SetActive(false); return; }
        var targets = SelectedManualHeadNos.SelectMany(head => CScannerStatusSnapshotReader.BuildAxisDefinitions(_manualScannerOptionSettings, head))
            .Where(axis => axis.AutomationNo == controller)
            .Select(axis => new ST_MANUAL_HOME_SPEED_TARGET(axis.HeadNo, axis.AutomationNo, axis.AxisName, axis.AxisReference,
                axis.IsUsed && string.IsNullOrEmpty(axis.ConfigurationError), axis.IsUsed ? axis.ConfigurationError : "NOT USE")).ToArray();
        HomeSpeedPanel.UpdateTargets(targets);
        HomeSpeedPanel.SetActive(IsManualControllerTab && IsScannerWorkspace);
        HomeSpeedPanel.ApplySnapshots();
    }

    private async Task<double> SaveManualHomeSpeed(ST_MANUAL_HOME_SPEED_TARGET target, double speed)
    {
        if (TryBlockManualAutomationCommand("HOME_SPEED_SET")) throw new InvalidOperationException("자동 운전 중에는 홈 속도를 저장할 수 없습니다.");
        var settings = _manager.Setting().LoadSection(EN_SETTING_TAB.Option);
        var current = CScannerStatusSnapshotReader.BuildAxisDefinitions(settings, target.HeadNo).SingleOrDefault(axis => axis.AxisName == target.Role);
        if (_homeSpeedController != target.Controller || !IsManualControllerTab || !IsScannerWorkspace || !SelectedManualHeadNos.Contains(target.HeadNo) || !current.IsUsed ||
            !string.IsNullOrEmpty(current.ConfigurationError) || current.AutomationNo != target.Controller || current.AxisReference != target.AxisName)
            throw new InvalidOperationException("Head 또는 축 설정이 변경되었습니다. 다시 선택해 주세요.");
        if (!_manager.automation.IsSimul(target.Controller) && !_manager.automation.IsConnect(target.Controller))
            throw new InvalidOperationException($"Automation {target.Controller}: OFFLINE");
        return await _manager.automation.SetConfiguredHomeSpeed(target.AxisName, speed, target.Controller);
    }
}

public sealed record ST_MANUAL_HOME_SPEED_TARGET(int HeadNo, int Controller, string Role, string AxisName, bool IsUsed, string ConfigurationError);
public sealed record ST_MANUAL_HOME_SPEED_HEAD(int HeadNo, IReadOnlyList<CManualHomeSpeedAxis> Axes)
{
    public string HeadName => $"HEAD {HeadNo:00}";
}

/// <summary>Only displays shared snapshots. Device reads belong to the common collector.</summary>
public sealed class CManualHomeSpeedPanel : INotifyPropertyChanged
{
    private readonly Func<int, IReadOnlyList<string>, ST_AUTOMATION_STATUS_SNAPSHOT<IReadOnlyDictionary<string, double>>> _snapshot;
    private readonly Action<int> _requestRefresh;
    private readonly Func<ST_MANUAL_HOME_SPEED_TARGET, double, Task<double>> _save;
    private readonly Action<string> _warning;
    private readonly Action<string> _completed;
    private IReadOnlyList<ST_MANUAL_HOME_SPEED_TARGET> _targets = [];
    private readonly Dictionary<ST_MANUAL_HOME_SPEED_TARGET, CManualHomeSpeedAxis> _cache = [];
    private bool _active;
    public event PropertyChangedEventHandler? PropertyChanged;
    public IReadOnlyList<ST_MANUAL_HOME_SPEED_HEAD> Heads { get; private set; } = [];
    public CButtonCommand RefreshCommand { get; }

    public CManualHomeSpeedPanel(
        Func<int, IReadOnlyList<string>, ST_AUTOMATION_STATUS_SNAPSHOT<IReadOnlyDictionary<string, double>>> snapshot,
        Action<int> requestRefresh,
        Func<ST_MANUAL_HOME_SPEED_TARGET, double, Task<double>> save, Action<string> warning, Action<string> completed)
    {
        _snapshot = snapshot; _requestRefresh = requestRefresh; _save = save; _warning = warning; _completed = completed;
        RefreshCommand = new(_ => Refresh(), _ => _active && Heads.Count > 0 && !Rows.Any(row => row.IsSaving));
    }

    private IEnumerable<CManualHomeSpeedAxis> Rows => Heads.SelectMany(head => head.Axes);
    public void UpdateTargets(IReadOnlyList<ST_MANUAL_HOME_SPEED_TARGET> targets)
    {
        if (_targets.SequenceEqual(targets)) return;
        _targets = targets;
        Heads = targets.GroupBy(target => target.HeadNo).Select(group => new ST_MANUAL_HOME_SPEED_HEAD(group.Key,
            group.Select(target =>
            {
                if (!_cache.TryGetValue(target, out var row)) _cache.Add(target, row = new(target, Save));
                return row;
            }).ToArray())).ToArray();
        PropertyChanged?.Invoke(this, new(nameof(Heads)));
        foreach (var row in _cache.Values) row.SetActive(_active && targets.Contains(row.Target));
        RefreshCommand.NotifyCanExecuteChanged();
        ApplySnapshots();
    }

    public void SetActive(bool active)
    {
        if (_active == active) return;
        _active = active;
        foreach (var row in Rows) row.SetActive(active);
        RefreshCommand.NotifyCanExecuteChanged();
        ApplySnapshots();
    }

    public void Refresh()
    {
        if (!_active) return;
        foreach (var controller in Rows.Where(row => row.Target.IsUsed).Select(row => row.Target.Controller).Distinct())
            _requestRefresh(controller);
        ApplySnapshots();
    }

    public void ApplySnapshots()
    {
        if (!_active) return;
        foreach (var group in Rows.Where(row => row.Target.IsUsed).GroupBy(row => row.Target.Controller))
        {
            try
            {
                var snapshot = _snapshot(group.Key, group.Select(row => row.Target.AxisName).Distinct(StringComparer.OrdinalIgnoreCase).ToArray());
                foreach (var row in group)
                {
                    row.SetUnit(snapshot.Value is CConfiguredHomeSpeedValues unitValues &&
                        unitValues.Units.TryGetValue(row.Target.AxisName, out var unit) ? unit : "단위 미확인");
                    if (snapshot.Value is { } values && values.TryGetValue(row.Target.AxisName, out var speed) && double.IsFinite(speed) && speed >= 0)
                        row.SetSaved(speed);
                    else row.SetSnapshotState(snapshot.Value is null ? snapshot.State : "LOADING", snapshot.Detail);
                }
            }
            catch (Exception exception) { foreach (var row in group) row.SetSnapshotState("ERROR", exception.Message); }
        }
    }

    private async Task Save(CManualHomeSpeedAxis row)
    {
        if (!row.CanSet || !_targets.Contains(row.Target)) return;
        if (!double.TryParse(row.NewValue, NumberStyles.Float, CultureInfo.InvariantCulture, out var speed) || !double.IsFinite(speed) || speed <= 0)
        { _warning("HomeSpeed는 0보다 큰 숫자로 입력해 주세요."); return; }
        row.SetSaving(true);
        var unit = row.SpeedUnit;
        RefreshCommand.NotifyCanExecuteChanged();
        try
        {
            var saved = await _save(row.Target, speed);
            if (!double.IsFinite(saved) || saved <= 0) throw new InvalidOperationException("저장 결과를 확인하지 못했습니다. 새로고침 후 확인해 주세요.");
            row.AcceptSavedInput(saved);
            ApplySnapshots();
            _completed($"HEAD {row.Target.HeadNo:00} / {row.Target.AxisName}\n저장된 HomeSpeed: {saved:G} {unit}\n\n변경값을 적용하려면 CONTROLLER {row.Target.Controller + 1}을 RESET해 주세요.");
        }
        catch (Exception exception)
        {
            row.SetSnapshotState("ERROR", exception.Message);
            _warning($"{row.Target.AxisName} 홈 속도 저장 실패\n{exception.Message}\n\n새로고침 후 저장값을 확인해 주세요.");
        }
        finally { row.SetSaving(false); RefreshCommand.NotifyCanExecuteChanged(); ApplySnapshots(); }
    }
}

public sealed class CManualHomeSpeedAxis : INotifyPropertyChanged
{
    private double? _saved;
    private string _input = "";
    private bool _dirty;
    private bool _active;
    private string _state = "LOADING";
    public event PropertyChangedEventHandler? PropertyChanged;
    public ST_MANUAL_HOME_SPEED_TARGET Target { get; }
    public string AxisName => Target.IsUsed ? Target.AxisName : Target.ConfigurationError == "NOT USE" ? "Z NOT USE" : Target.AxisName;
    public string SavedValue => !Target.IsUsed ? Target.ConfigurationError == "NOT USE" ? "NOT USE" : "CONFIG ERR" : _saved?.ToString("G", CultureInfo.InvariantCulture) ?? _state;
    public string NewValue { get => _input; set { _input = value; _dirty = true; Notify(); } }
    public string Error { get; private set; } = "";
    public string SpeedUnit { get; private set; } = "단위 미확인";
    public bool IsSaving { get; private set; }
    public bool IsLoading { get; private set; }
    public bool CanSet => _active && Target.IsUsed && _saved.HasValue && !IsSaving && !IsLoading;
    public CButtonCommand SetCommand { get; }
    public CManualHomeSpeedAxis(ST_MANUAL_HOME_SPEED_TARGET target, Func<CManualHomeSpeedAxis, Task> save)
    {
        Target = target;
        if (!target.IsUsed) SpeedUnit = "-";
        SetCommand = new(async _ => await save(this), _ => CanSet);
    }
    internal void SetActive(bool active) { _active = active; Notify(); }
    internal void SetUnit(string unit)
    {
        if (SpeedUnit == unit) return;
        SpeedUnit = unit;
        PropertyChanged?.Invoke(this, new(nameof(SpeedUnit)));
    }
    internal void SetSaving(bool saving) { IsSaving = saving; Notify(); }
    internal void SetSaved(double value, bool forceInput = false)
    {
        if (_saved == value && !IsLoading && Error.Length == 0 && !forceInput) return;
        _saved = value; IsLoading = false; Error = "";
        if (!_dirty || forceInput) { _input = value.ToString("G", CultureInfo.InvariantCulture); _dirty = false; }
        Notify();
    }
    internal void AcceptSavedInput(double value) { _input = value.ToString("G", CultureInfo.InvariantCulture); _dirty = false; Notify(); }
    internal void SetSnapshotState(string state, string detail)
    {
        if (_saved is null && _state == state && Error == detail && IsLoading == (state == "LOADING")) return;
        _saved = null; _state = state; Error = detail; IsLoading = state == "LOADING"; Notify();
    }
    private void Notify() { PropertyChanged?.Invoke(this, new(string.Empty)); SetCommand.NotifyCanExecuteChanged(); }
}
