using System.Windows;
using Drilling.Common.Review;
using Drilling.UI.Popup;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuReview
{
    private ST_BEAM_INSPECTION_SNAPSHOT? _beamInspectionSnapshot;
    private int _beamInspectionBrowseIndex;
    private bool _followBeamInspection = true;
    private CancellationTokenSource? _beamInspectionCancellation;

    public CButtonCommand PreviousInspectionShotCommand { get; }
    public CButtonCommand NextInspectionShotCommand { get; }

    public bool IsInspectionExecutionViewVisible => IsBeamInspectionMode && (IsReviewExecutionActive || _loadedBeamInspectionResult is not null);
    public bool IsInspectionSelectionControlsVisible => IsBeamInspectionMode && !IsReviewExecutionActive && _loadedBeamInspectionResult is null && !_isBeamInspectionResultLoading;

    public string InspectionShotSummary
    {
        get
        {
            if (GetLoadedInspectionShot() is { } loaded)
                return $"{loaded.GlassName} / {loaded.HeadName} / {loaded.CellName} / {loaded.ShotName} · {_beamInspectionBrowseIndex + 1}/{_loadedBeamInspectionResult!.Shots.Count}";
            var shots = GetInspectionDisplayShots();
            if (shots.Count == 0) return "선택된 Shot 없음";
            var index = Math.Clamp(_beamInspectionBrowseIndex, 0, shots.Count - 1);
            var shot = shots[index];
            return $"HEAD {shot.HeadNo:00} / CELL {shot.CellNo:00} / {ToMatrixShotName(shot)} · {index + 1}/{shots.Count}";
        }
    }

    public string InspectionProgressText
    {
        get
        {
            if (_loadedBeamInspectionResult is { } loaded)
                return $"불러온 결과{(loaded.IsSimulation ? " · SIM" : "")} · {loaded.FileName} · {loaded.SavedAt:yyyy-MM-dd HH:mm:ss}";
            if (_isBeamInspectionResultLoading) return "최근 Beam Inspection 결과를 불러오는 중입니다.";
            var snapshot = _beamInspectionSnapshot;
            if (snapshot is null) return "검사 대기 · 결과: ΔX / ΔY (mm)";
            var mode = $"MELSEC {(snapshot.IsStageSimulation ? "SIM" : "REAL")} / Vision {(snapshot.IsVisionSimulation ? "SIM" : "REAL")} · ";
            var active = snapshot.ActiveIndex >= 0 ? snapshot.Points[snapshot.ActiveIndex] : null;
            return active is null
                ? $"{mode}{snapshot.Message} · {snapshot.CompletedCount}/{snapshot.Points.Count} Beam"
                : $"{mode}검사 중: C{active.CellNo} / {ToMatrixShotName(active)} / Beam{active.BeamNo} · {snapshot.CompletedCount}/{snapshot.Points.Count}";
        }
    }

    private IReadOnlyList<ST_REVIEW_PLAN_POINT> GetInspectionDisplayShots() =>
        _beamInspectionSnapshot is { } snapshot
            ? snapshot.Points.DistinctBy(p => p.ShotKey, StringComparer.OrdinalIgnoreCase).ToArray()
            : _selectedInspectionShotKeys.Select(key => FindPointByShotKey(_lastAllPlan, key))
                .OfType<ST_REVIEW_PLAN_POINT>().Where(p => !IsReviewPointExcluded(p))
                .OrderBy(p => p.CellNo).ThenBy(p => p.ShotNo).ToArray();

    private IReadOnlyDictionary<int, ST_REVIEW_PLAN_POINT> GetDisplayedInspectionResults()
    {
        if (!IsInspectionExecutionViewVisible || _beamInspectionSnapshot is null) return new Dictionary<int, ST_REVIEW_PLAN_POINT>();
        var shots = GetInspectionDisplayShots();
        if (shots.Count == 0) return new Dictionary<int, ST_REVIEW_PLAN_POINT>();
        var shot = shots[Math.Clamp(_beamInspectionBrowseIndex, 0, shots.Count - 1)];
        return _beamInspectionSnapshot.Points.Where(p => p.ShotKey == shot.ShotKey).ToDictionary(p => p.BeamNo);
    }

    private void BrowseInspectionShot(int delta)
    {
        var count = GetInspectionDisplayShotCount();
        if (!IsInspectionExecutionViewVisible || count == 0) return;
        _beamInspectionBrowseIndex = Math.Clamp(_beamInspectionBrowseIndex + delta, 0, count - 1);
        _followBeamInspection = false;
        RefreshBeamInspectionDisplay();
    }

    private void ResetBeamInspectionResults()
    {
        if (IsReviewExecutionActive) return;
        _beamInspectionSnapshot = null;
        if (_loadedBeamInspectionResult is null)
        {
            _beamInspectionBrowseIndex = 0;
            _followBeamInspection = true;
        }
        RefreshBeamInspectionDisplay();
    }

    private void RefreshBeamInspectionDisplay()
    {
        RunBeamRows = BuildBeamRows(_selectedRunBeamNo);
        OnPropertyChanged(nameof(RunBeamRows));
        OnPropertyChanged(nameof(BeamSelectionSummary));
        OnPropertyChanged(nameof(InspectionShotSummary));
        OnPropertyChanged(nameof(InspectionProgressText));
        OnPropertyChanged(nameof(IsInspectionExecutionViewVisible));
        OnPropertyChanged(nameof(IsInspectionSelectionControlsVisible));
        OnPropertyChanged(nameof(CanSelectBeam));
        OnPropertyChanged(nameof(CanLoadBeamInspectionResult));
        OnPropertyChanged(nameof(CanClearLoadedBeamInspectionResult));
        LoadLastBeamInspectionResultCommand?.NotifyCanExecuteChanged();
        ClearLoadedBeamInspectionResultCommand?.NotifyCanExecuteChanged();
        SelectRunBeamCommand?.NotifyCanExecuteChanged();
        SelectRunShotCommand?.NotifyCanExecuteChanged();
        SelectAllInspectionBeamsCommand?.NotifyCanExecuteChanged();
        ClearInspectionBeamsCommand?.NotifyCanExecuteChanged();
        ClearInspectionShotsCommand?.NotifyCanExecuteChanged();
        PreviousInspectionShotCommand?.NotifyCanExecuteChanged();
        NextInspectionShotCommand?.NotifyCanExecuteChanged();
        StartCommand?.NotifyCanExecuteChanged();
    }

    private void ApplyBeamInspectionProgress(ST_BEAM_INSPECTION_SNAPSHOT snapshot)
    {
        void Apply()
        {
            _beamInspectionSnapshot = snapshot;
            if (_followBeamInspection && snapshot.ActiveIndex >= 0)
            {
                var key = snapshot.Points[snapshot.ActiveIndex].ShotKey;
                _beamInspectionBrowseIndex = GetInspectionDisplayShots().ToList().FindIndex(p => p.ShotKey == key);
            }
            RefreshBeamInspectionDisplay();
        }
        var dispatcher = Application.Current?.Dispatcher;
        if (dispatcher is not null && !dispatcher.CheckAccess()) dispatcher.Invoke(Apply);
        else Apply();
    }

    private async Task StartBeamInspectionSequence()
    {
        if (IsReviewExecutionActive || IsSampleSelectTab || _loadedBeamInspectionResult is not null || _isBeamInspectionResultLoading) return;
        InvalidateBeamInspectionResultLoad(clearLoaded: true);
        ResetBeamInspectionResults();
        _isStartRequestPending = true;
        _beamInspectionCancellation = new CancellationTokenSource();
        var token = _beamInspectionCancellation.Token;
        NotifyReviewExecutionCommandStates();
        try
        {
            var recipe = await LoadSelectedRecipe(token)
                ?? throw new InvalidOperationException("Recipe를 불러올 수 없습니다.");
            if (_lastRecipe is null || !recipe.Id.Equals(_lastRecipe.Id, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Recipe가 변경되었습니다. Shot과 Beam을 다시 선택해 주세요.");
            var allPlan = _reviewManager.CreateAllPlan(recipe, _selectedRunBeamNo);
            // Snapshot the choices before any screen refresh, and revalidate against the latest Recipe.
            var shots = _selectedInspectionShotKeys.ToArray();
            var beams = _selectedInspectionBeamNos.ToArray();
            _lastRecipe = recipe;
            _lastAllPlan = allPlan;
            _lastAllPlanBeamNo = _selectedRunBeamNo;
            _followBeamInspection = true;
            _beamInspectionBrowseIndex = 0;
            var result = await _reviewManager.StartBeamInspection(recipe, allPlan, shots, beams,
                ApplyBeamInspectionProgress, token);
            _statusReporter($"{result.Message} ({result.CompletedCount}/{result.Points.Count}, NG={result.NgCount})");
            if (result.SaveError is not null)
            {
                CRecipeConfirmDialog.ShowWarning("Beam Inspection 결과 저장 실패",
                    $"{result.Message}\n검사 결과를 저장하지 못했습니다.\n{result.SaveError}");
                return;
            }
            _statusReporter($"{result.Message} · 결과 저장: {result.SavedPath}");
            if (result.State == EN_REVIEW_SEQUENCE_STATE.Failed)
                CRecipeConfirmDialog.ShowWarning("Beam Inspection 실패", result.Message);
            else if (result.State == EN_REVIEW_SEQUENCE_STATE.Completed)
                CRecipeConfirmDialog.ShowCompletion("Beam Inspection", $"검사가 완료되었습니다.\n완료 {result.CompletedCount} Beam / NG {result.NgCount}\n결과 저장: {result.SavedPath}");
        }
        catch (OperationCanceledException)
        {
            _statusReporter("Beam Inspection 시작이 취소되었습니다.");
        }
        catch (Exception exception)
        {
            CRecipeConfirmDialog.ShowWarning("Beam Inspection 시작 불가", exception.Message);
        }
        finally
        {
            _beamInspectionCancellation.Dispose();
            _beamInspectionCancellation = null;
            _isStartRequestPending = false;
            NotifyReviewExecutionCommandStates();
            RefreshBeamInspectionDisplay();
            _refreshScreen();
        }
    }
}
