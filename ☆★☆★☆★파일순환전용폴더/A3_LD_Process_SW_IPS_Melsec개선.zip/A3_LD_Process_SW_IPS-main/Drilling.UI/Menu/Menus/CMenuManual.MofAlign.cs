using Drilling.UI.Popup;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuManual
{
    private CManualMofAlignPanel? _mofAlign;
    public CManualMofAlignPanel MofAlign => _mofAlign ??= new(
        _manager.Interface().Melsec,
        () => CRecipeConfirmDialog.ShowConfirmation("ALIGN REQUEST", "STAGE PC에 얼라인 요청하시겠습니까?"),
        message => CRecipeConfirmDialog.ShowWarning("STAGE ALIGN", message),
        _setStatusMessage,
        () => TryBlockManualAutomationCommand("STAGE_ALIGN_REQUEST"));
}
