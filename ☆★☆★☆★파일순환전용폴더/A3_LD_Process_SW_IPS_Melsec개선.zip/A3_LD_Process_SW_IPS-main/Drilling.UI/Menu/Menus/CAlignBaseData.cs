using System.ComponentModel;
using System.Globalization;
using System.Windows.Media;
using Drilling.Common.Managers;

namespace Drilling.UI.Menu.Menus;

public static class CAlignBaseData
{
    public static IReadOnlyList<string> KeyNames { get; } = Enumerable.Range(1, 4).Select(n => $"AK{n}")
        .Concat(Enumerable.Range(1, 6).Select(n => $"DK{n}")).ToArray();
    public static IReadOnlyList<string> ParameterKeys { get; } = KeyNames
        .SelectMany(name => new[] { $"ALIGNBASE_{name}_X", $"ALIGNBASE_{name}_Y" }).ToArray();

    public static IReadOnlyDictionary<string, string> ZeroValues() => ParameterKeys
        .ToDictionary(key => key, _ => "0.0", StringComparer.OrdinalIgnoreCase);

    public static IReadOnlyDictionary<string, string> ReadLastLoads(CAlignDistortionPanel panel)
    {
        var keys = panel.Keys.ToDictionary(key => key.Name, StringComparer.OrdinalIgnoreCase);
        var values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var name in KeyNames)
        {
            if (!keys.TryGetValue(name, out var key)) throw new InvalidOperationException($"{name}의 Base 값을 확인하세요.");
            var selected = panel.LoadKeyNames.Contains(name);
            var x = selected ? key.LastLoadX : key.BaseSourceX;
            var y = selected ? key.LastLoadY : key.BaseSourceY;
            if (!IsFinite(x) || !IsFinite(y))
                throw new InvalidOperationException($"{name}의 {(selected ? "LastLoad" : "Base")} 값이 없습니다. 선택한 키를 Load한 뒤 실행하세요.");
            values[$"ALIGNBASE_{name}_X"] = selected ? key.LastLoadRawX?.ToString("R", CultureInfo.InvariantCulture) ?? x.Trim() : x;
            values[$"ALIGNBASE_{name}_Y"] = selected ? key.LastLoadRawY?.ToString("R", CultureInfo.InvariantCulture) ?? y.Trim() : y;
        }
        return values;
    }

    public static ST_RECIPE_DEFINITION Apply(ST_RECIPE_DEFINITION recipe, IReadOnlyDictionary<string, string> values)
    {
        if (values.Count != ParameterKeys.Count || ParameterKeys.Any(key => !values.ContainsKey(key)))
            throw new InvalidOperationException("AK1~AK4, DK1~DK6의 Base X/Y 20개 값이 모두 필요합니다.");
        var parameters = recipe.Parameters.ToArray();
        foreach (var key in ParameterKeys)
        {
            var indices = Enumerable.Range(0, parameters.Length).Where(i => parameters[i].Key.Equals(key, StringComparison.OrdinalIgnoreCase)).ToArray();
            if (indices.Length != 1)
                throw new InvalidOperationException($"레시피의 {key} 항목을 확인하세요.");
            var index = indices[0];
            var parameter = parameters[index];
            var text = values[key].Trim();
            if (!double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out var number) || !double.IsFinite(number))
                throw new InvalidOperationException($"{parameter.Name}: 유효한 숫자를 입력하세요.");
            if (parameter.Min != parameter.Max && (number < parameter.Min || number > parameter.Max))
                throw new InvalidOperationException($"{parameter.Name}: {parameter.Min.ToString(CultureInfo.InvariantCulture)} ~ {parameter.Max.ToString(CultureInfo.InvariantCulture)} mm 범위로 입력하세요.");
            if (parameter.ChangeLimit > 0 && double.TryParse(parameter.DefaultValue, NumberStyles.Float, CultureInfo.InvariantCulture, out var oldValue) &&
                Math.Abs(number - oldValue) > parameter.ChangeLimit)
                throw new InvalidOperationException($"{parameter.Name}: 변경 허용 범위는 ±{parameter.ChangeLimit.ToString(CultureInfo.InvariantCulture)} mm입니다.");
            parameters[index] = parameter with { Value = text };
        }
        return recipe with { Parameters = parameters };
    }

    private static bool IsFinite(string text) => double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out var value) && double.IsFinite(value);
}

public sealed class CAlignBaseEditPanel
{
    private readonly ST_RECIPE_DEFINITION _recipe;

    public CAlignBaseEditPanel(ST_RECIPE_DEFINITION recipe, CAlignDistortionPanel preview)
    {
        _recipe = recipe;
        if (!recipe.Id.Equals(preview.RecipeId, StringComparison.OrdinalIgnoreCase) || preview.Keys.Count != 10)
            throw new InvalidOperationException("현재 레시피의 Glass Preview를 확인하세요.");
        RecipeName = recipe.Name;
        PreviewImage = preview.PreviewImage;
        PreviewHeight = preview.PreviewHeight;
        Keys = preview.Keys.Select(key => new CAlignBaseEditKey(key,
            recipe.Parameters.Single(parameter => parameter.Key.Equals($"ALIGNBASE_{key.Name}_X", StringComparison.OrdinalIgnoreCase)),
            recipe.Parameters.Single(parameter => parameter.Key.Equals($"ALIGNBASE_{key.Name}_Y", StringComparison.OrdinalIgnoreCase)))).ToArray();
    }

    public string RecipeName { get; }
    public ImageSource? PreviewImage { get; }
    public double PreviewHeight { get; }
    public IReadOnlyList<CAlignBaseEditKey> Keys { get; }

    public IReadOnlyDictionary<string, string> BuildValues()
    {
        var values = Keys.SelectMany(key => new[]
            { new KeyValuePair<string, string>(key.ParameterX.Key, key.BaseX), new KeyValuePair<string, string>(key.ParameterY.Key, key.BaseY) })
            .ToDictionary(pair => pair.Key, pair => pair.Value, StringComparer.OrdinalIgnoreCase);
        CAlignBaseData.Apply(_recipe, values);
        return values;
    }
}

public sealed class CAlignBaseEditKey : INotifyPropertyChanged
{
    private string _baseX;
    private string _baseY;

    public CAlignBaseEditKey(ST_ALIGN_DISTORTION_KEY key, ST_RECIPE_PARAMETER parameterX, ST_RECIPE_PARAMETER parameterY)
    {
        Name = key.Name;
        KeyBrush = key.KeyBrush;
        EditorLeft = key.EditorLeft;
        EditorTop = key.EditorTop + (ST_ALIGN_DISTORTION_KEY.EditorHeight - 96) / 2;
        ParameterX = parameterX;
        ParameterY = parameterY;
        _baseX = parameterX.Value;
        _baseY = parameterY.Value;
    }

    public event PropertyChangedEventHandler? PropertyChanged;
    public string Name { get; }
    public Brush KeyBrush { get; }
    public double EditorLeft { get; }
    public double EditorTop { get; }
    public ST_RECIPE_PARAMETER ParameterX { get; }
    public ST_RECIPE_PARAMETER ParameterY { get; }
    public string BaseX { get => _baseX; set { if (_baseX == value) return; _baseX = value; PropertyChanged?.Invoke(this, new(nameof(BaseX))); } }
    public string BaseY { get => _baseY; set { if (_baseY == value) return; _baseY = value; PropertyChanged?.Invoke(this, new(nameof(BaseY))); } }
}
