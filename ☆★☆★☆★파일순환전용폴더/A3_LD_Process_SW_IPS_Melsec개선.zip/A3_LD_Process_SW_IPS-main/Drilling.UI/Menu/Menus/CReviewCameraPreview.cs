using System.ComponentModel;
using System.Globalization;
using System.Windows;
using Drilling.Common.Recipe;

namespace Drilling.UI.Menu.Menus;

/// <summary>Projects shared Stage/Review feedback onto a fixed Glass. Never reads files or sends device commands.</summary>
public sealed class CReviewCameraPreview : INotifyPropertyChanged
{
    public const string UseSettingKey = "VISION_ANIMATION_USE";
    public const string XFlipSettingKey = "REVIEW_X_ANIMATION_FLIP";
    private Projection? _projection;
    private bool _hasFeedback;
    private double _stageY, _reviewX;
    public event PropertyChangedEventHandler? PropertyChanged;
    public bool IsVisible { get; private set; }
    public Point Center { get; private set; }
    public double? DesignX { get; private set; }
    public double? DesignY { get; private set; }
    public int ProjectionVersion { get; private set; }

    public void Configure(IReadOnlyDictionary<string, string> parameters, Rect glassBounds)
    {
        Projection? next = null;
        if (!glassBounds.IsEmpty && glassBounds.Width > 0 && glassBounds.Height > 0 &&
            Read(parameters, "GLASS_SIZE_X", double.NaN, out var width) && width > 0 &&
            Read(parameters, "GLASS_SIZE_Y", double.NaN, out var height) && height > 0 &&
            Read(parameters, "REVIEW_CAMERA_ALIGN_KEY_POS_X", 0, out var akX) &&
            Read(parameters, "REVIEW_CAMERA_ALIGN_KEY_POS_Y", 0, out var akY) &&
            Read(parameters, "AK_MARGIN_X", 55, out var marginX, "ALIGN_MARGIN_X") &&
            Read(parameters, "AK_MARGIN_Y", 45, out var marginY, "ALIGN_MARGIN_Y"))
        {
            try
            {
                next = new(glassBounds, width, height, akX, akY, marginX, marginY,
                    CScannerAxisTransform.ReadStageDirection(parameters), IsOn(parameters.GetValueOrDefault(UseSettingKey)),
                    IsOn(parameters.GetValueOrDefault(XFlipSettingKey)) ? -1 : 1);
            }
            catch (InvalidOperationException) { /* An invalid direction must not create a fabricated camera position. */ }
        }
        if (_projection == next) return;
        _projection = next; ProjectionVersion++;
        Project(forceNotify: true);
    }

    public void UpdateFeedback(string stageY, string reviewX, string mode)
    {
        _hasFeedback = mode is "ONLINE" or "SIMULATION" &&
            double.TryParse(stageY, NumberStyles.Float, CultureInfo.InvariantCulture, out _stageY) && double.IsFinite(_stageY) &&
            double.TryParse(reviewX, NumberStyles.Float, CultureInfo.InvariantCulture, out _reviewX) && double.IsFinite(_reviewX);
        Project();
    }

    public void Clear()
    {
        _projection = null; _hasFeedback = false; ProjectionVersion++; Project(forceNotify: true);
    }

    private void Project(bool forceNotify = false)
    {
        double? x = null, y = null;
        var center = new Point();
        if (_hasFeedback && _projection is { Enabled: true } p)
        {
            // Animate around the fixed AK reference. X flip affects display only, never motion/measurement coordinates.
            var designX = (_reviewX - p.AkX) * p.XDirection + p.MarginX;
            var designY = (_stageY - p.AkY) / p.Direction + p.MarginY;
            var pixelX = p.Bounds.Left + designX / p.Width * p.Bounds.Width;
            var pixelY = p.Bounds.Top + designY / p.Height * p.Bounds.Height;
            if (double.IsFinite(designX) && double.IsFinite(designY) && double.IsFinite(pixelX) && double.IsFinite(pixelY))
            { x = designX; y = designY; center = new(pixelX, pixelY); }
        }
        var visible = x.HasValue && y.HasValue;
        if (!forceNotify && IsVisible == visible && DesignX == x && DesignY == y && Center == center) return;
        IsVisible = visible; DesignX = x; DesignY = y; Center = center;
        PropertyChanged?.Invoke(this, new(null));
    }

    private static bool Read(IReadOnlyDictionary<string, string> parameters, string key, double fallback, out double value, string? alias = null)
    {
        if (!parameters.TryGetValue(key, out var text) && (alias is null || !parameters.TryGetValue(alias, out text)))
        { value = fallback; return double.IsFinite(value); }
        return double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out value) && double.IsFinite(value);
    }

    private static bool IsOn(string? value) => value?.Trim().ToUpperInvariant() is "ON" or "TRUE" or "1" or "YES";

    private sealed record Projection(Rect Bounds, double Width, double Height, double AkX, double AkY,
        double MarginX, double MarginY, double Direction, bool Enabled, double XDirection);
}
