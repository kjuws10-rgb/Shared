using System.Data;
using System.Windows;
using System.Windows.Media;
using System.Windows.Threading;
using Drilling.Common.Review;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuReview
{
    private readonly object _runtimeUiGate = new();
    private readonly Dictionary<string, ST_REVIEW_PLAN_POINT> _runtimePendingPoints = new(StringComparer.OrdinalIgnoreCase);
    private ST_REVIEW_PLAN? _runtimePendingPlan;
    private ST_REVIEW_PLAN? _runtimeSeedPlan;
    private Guid _runtimeQueuedId;
    private int _runtimeTimerScheduled;
    private DispatcherTimer? _runtimeDisplayTimer;
    private readonly Dictionary<string, int> _runtimeCurrentPointCells = new(StringComparer.OrdinalIgnoreCase);
    private readonly DataView _emptyRuntimeMatrix = CreateEmptyResultMatrix();
    private ST_REVIEW_PLAN? _finishedResultPlan;
    private DataView? _finishedResultMatrix;
    private bool _deferResultMatrix;
    private int _resultDisplayGeneration;
    private HashSet<int> _runtimePreviewCells = [];
    private int _runtimePreviewCell;
    private bool _runtimePreviewActive;
    private ImageSource? _runtimePreviewBase;
    private int _runtimeDisplayRefreshCount;

    public bool IsReviewResultDeferred => _deferResultMatrix && !IsOneShotReviewMode && !IsBeamInspectionMode;

    private DataView GetRuntimeResultMatrix(ST_REVIEW_PLAN plan)
    {
        if (_deferResultMatrix || _reviewManager.SequenceState is EN_REVIEW_SEQUENCE_STATE.Running or EN_REVIEW_SEQUENCE_STATE.Stopping)
            return _emptyRuntimeMatrix;
        if (!ReferenceEquals(_finishedResultPlan, plan) || _finishedResultMatrix is null)
        {
            _finishedResultPlan = plan;
            _finishedResultMatrix = BuildResultMatrix(plan);
        }
        return _finishedResultMatrix;
    }

    private void BeginDeferredResults()
    {
        _resultDisplayGeneration++;
        _deferResultMatrix = true;
        _finishedResultPlan = null;
        _finishedResultMatrix = null;
        ResultMatrix = _emptyRuntimeMatrix;
        OnPropertyChanged(nameof(ResultMatrix));
        OnPropertyChanged(nameof(IsReviewResultDeferred));
    }

    private async Task CompleteDeferredResults()
    {
        var generation = _resultDisplayGeneration;
        var plan = _reviewManager.CurrentPlan;
        // Build from the final immutable snapshot on a worker, including the
        // measured subset of a stopped/failed run. Bind the table exactly once.
        var matrix = plan is null ? _emptyRuntimeMatrix : await Task.Run(() => BuildResultMatrix(plan));
        if (generation != _resultDisplayGeneration) return;
        _finishedResultPlan = plan;
        _finishedResultMatrix = matrix;
        _deferResultMatrix = false;
        ResultMatrix = matrix;
        OnPropertyChanged(nameof(ResultMatrix));
        OnPropertyChanged(nameof(IsReviewResultDeferred));
    }

    private void QueueRuntimeDisplayRefresh(ST_REVIEW_PLAN plan)
    {
        // The sequence publishes immutable snapshots on a worker. Keep only the
        // latest state per changed Shot until the next UI tick; never drop results.
        lock (_runtimeUiGate)
        {
            if (_runtimeQueuedId != plan.RuntimeId || plan.PointUpdates is null)
            {
                _runtimeQueuedId = plan.RuntimeId;
                _runtimeSeedPlan = plan;
                _runtimePendingPoints.Clear();
            }
            _runtimePendingPlan = plan;
            foreach (var point in plan.PointUpdates ?? []) _runtimePendingPoints[point.ShotKey] = point;
        }
        if (Interlocked.Exchange(ref _runtimeTimerScheduled, 1) != 0) return;
        var dispatcher = Application.Current?.Dispatcher;
        if (dispatcher is null || dispatcher.HasShutdownStarted || dispatcher.HasShutdownFinished)
        {
            Interlocked.Exchange(ref _runtimeTimerScheduled, 0);
            return;
        }
        _ = dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() =>
        {
            lock (_runtimeUiGate)
            {
                if (_runtimePendingPlan is null)
                {
                    Interlocked.Exchange(ref _runtimeTimerScheduled, 0);
                    return;
                }
            }
            if (_runtimeDisplayTimer is null)
            {
                _runtimeDisplayTimer = new DispatcherTimer(DispatcherPriority.Background, dispatcher)
                    { Interval = TimeSpan.FromMilliseconds(200) };
                _runtimeDisplayTimer.Tick += (_, _) => FlushRuntimeDisplay();
            }
            _runtimeDisplayTimer.Start();
        }));
    }

    private void FlushRuntimeDisplay()
    {
        ST_REVIEW_PLAN? plan;
        ST_REVIEW_PLAN? seed;
        ST_REVIEW_PLAN_POINT[] changes;
        lock (_runtimeUiGate)
        {
            plan = _runtimePendingPlan;
            seed = _runtimeSeedPlan;
            changes = _runtimePendingPoints.Values.ToArray();
            _runtimePendingPlan = null;
            _runtimeSeedPlan = null;
            _runtimePendingPoints.Clear();
        }
        if (plan is not null && !IsOneShotReviewMode && !IsBeamInspectionMode)
        {
            _runtimeDisplayRefreshCount++;
            if (seed is not null)
            {
                _runtimeCurrentPointCells.Clear();
                foreach (var point in seed.ReviewPoints)
                    if (point.State == EN_REVIEW_POINT_STATE.Current) _runtimeCurrentPointCells[point.ShotKey] = point.CellNo;
            }
            foreach (var point in changes)
                if (point.State == EN_REVIEW_POINT_STATE.Current) _runtimeCurrentPointCells[point.ShotKey] = point.CellNo;
                else _runtimeCurrentPointCells.Remove(point.ShotKey);
            _activePlanPointCount = plan.ReviewPoints.Count;
            var currentPoint = _reviewManager.CurrentPoint;
            var measurementPoint = _reviewManager.LastMeasuredPoint;
            SelectedPointItems = BuildSelectedPointItems(measurementPoint);
            if (seed is not null) SynchronizeMaterializedRunShotRows(plan);
            else foreach (var point in changes) UpdateRunShotRuntimeState(point);
            RefreshRuntimePreview(plan, currentPoint ?? measurementPoint);
            OnPropertyChanged(nameof(PlanSummary));
            OnPropertyChanged(nameof(SelectedPointItems));
            NotifyReviewExecutionCommandStates();
        }
        lock (_runtimeUiGate)
        {
            if (_runtimePendingPlan is null && _reviewManager.SequenceState is not
                (EN_REVIEW_SEQUENCE_STATE.Running or EN_REVIEW_SEQUENCE_STATE.Stopping))
            {
                _runtimeDisplayTimer?.Stop();
                Interlocked.Exchange(ref _runtimeTimerScheduled, 0);
            }
        }
    }

    private void RefreshRuntimePreview(ST_REVIEW_PLAN plan, ST_REVIEW_PLAN_POINT? point)
    {
        if (_lastRecipe is null || point is null || !IsRunTab) return;
        var cells = _runtimeCurrentPointCells.Values.ToHashSet();
        var active = _reviewManager.SequenceState is EN_REVIEW_SEQUENCE_STATE.Running or EN_REVIEW_SEQUENCE_STATE.Stopping;
        if (_runtimePreviewCells.SetEquals(cells) && _runtimePreviewCell == point.CellNo &&
            _runtimePreviewActive == active && ReferenceEquals(_runtimePreviewBase, RunGlassPreviewImage)) return;
        var preview = CReviewGlassPreviewBuilder.Build(_lastRecipe, plan.CellCount, point.CellNo,
            visibleCellNos: IsRuleReviewMode ? plan.ReviewPoints.Select(p => p.CellNo).ToHashSet() : null,
            defaultPointState: IsRuleReviewMode ? EN_REVIEW_POINT_STATE.Skip : EN_REVIEW_POINT_STATE.Ready,
            showShotPoints: false, expandSmallCellBounds: false, emphasizeCurrentCell: active, currentCellNos: cells);
        // Cell geometry and the base image are static for the run. Only change
        // the highlight overlay/labels when its Cell set actually changes.
        if (RunGlassPreviewImage is null)
        {
            RunGlassPreviewImage = preview.Image;
            SetCameraPreviewGeometry(preview);
            OnPropertyChanged(nameof(RunGlassPreviewImage));
        }
        RunGlassPreviewInspectionOverlayImage = preview.InspectionOverlayImage;
        RunCellPreviewLabels = preview.CellLabels;
        OnPropertyChanged(nameof(RunGlassPreviewInspectionOverlayImage));
        OnPropertyChanged(nameof(RunCellPreviewLabels));
        _runtimePreviewCells = cells.ToHashSet();
        _runtimePreviewCell = point.CellNo;
        _runtimePreviewActive = active;
        _runtimePreviewBase = RunGlassPreviewImage;
    }
}
