using System.Globalization;
using System.IO;
using Drilling.Common.Interface;
using Drilling.Common.Managers;
using Drilling.File.PowerTable;
using Drilling.UI.Popup;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuManual
{
    private CManualShapeScanRun? _activeManualShapeScan;
    private IReadOnlyList<ST_MANUAL_SHAPE_SCAN_PROGRAM>? _manualShapeScanPendingStops;
    private CAttenuatorPositioningService? _manualShapeScanAttenuatorPositioning;
    private bool _manualShapeScanStopInProgress;
    private bool IsManualShapeScanActive => _activeManualShapeScan is not null || _manualShapeScanStopInProgress ||
        _manualShapeScanPendingStops is { Count: > 0 } || _manualShapeScanAttenuatorPositioning?.HasPendingStops == true || IsManualLaserActionActive;

    private async Task RunSelectedManualShapeScans(bool useCurrentPosition)
    {
        if (IsManualShapeScanActive)
        {
            CRecipeConfirmDialog.ShowWarning("형상 스캔", "수동 가공이 진행 중이거나 정지가 확인되지 않은 Head가 있습니다. LASER OFF 또는 STOP으로 정지한 후 다시 시도해 주세요.");
            return;
        }
        if (TryBlockManualAutomationCommand("SHAPE_START")) return;

        var run = new CManualShapeScanRun();
        _activeManualShapeScan = run;
        try
        {
            var programs = await PrepareManualShapeScanPrograms(run.Cancellation.Token, useCurrentPosition);
            run.Programs = programs;
            if (!CRecipeConfirmDialog.ShowConfirmation("형상 레이저 가공",
                    BuildManualScanConfirmation(programs, shapeScan: true))) return;
            run.Cancellation.Token.ThrowIfCancellationRequested();
            if (TryBlockManualAutomationCommand("SHAPE_START")) return;

            _lastCommand = "SHAPE_START";
            _lastResult = $"Preparing ATT / {programs.Count} Heads";
            RefreshCommandStateRows();
            _setStatusMessage($"선택한 {programs.Count}개 Head의 ATT를 설정 출력(W)에 맞는 각도로 이동한 후 형상 가공을 시작합니다.");
            _refreshShellStatus();
            await ExecuteManualShapeScanPrograms(programs, run.Cancellation.Token);
            _lastResult = $"Completed {programs.Count} Heads";
            _setStatusMessage($"선택한 {programs.Count}개 Head의 형상 가공이 완료되었습니다.");
        }
        catch (OperationCanceledException)
        {
            _laserState = "OFF";
            _lastResult = "Stopped";
            _setStatusMessage("선택한 Head의 형상 가공을 정지했습니다.");
        }
        catch (Exception exception) when (exception is InvalidDataException or InvalidOperationException or IOException or TimeoutException or KeyNotFoundException)
        {
            _lastResult = $"ERROR: {exception.Message}";
            _setStatusMessage($"형상 가공을 완료하지 못했습니다. {exception.Message}");
            CRecipeConfirmDialog.ShowWarning("형상 스캔 실패", exception.Message);
        }
        finally
        {
            _activeManualShapeScan = null;
            run.Completed.TrySetResult();
            run.Cancellation.Dispose();
            RefreshCommandStateRows();
            _refreshShellStatus();
        }
    }

    private async Task StopSelectedManualShapeScans()
    {
        var run = _activeManualShapeScan;
        if (run is null)
        {
            if (_manualShapeScanStopInProgress) return;
            var pending = _manualShapeScanPendingStops ?? [];
            if (pending.Count == 0 && _manualShapeScanAttenuatorPositioning?.HasPendingStops != true)
            {
                _setStatusMessage("진행 중인 형상 가공이 없습니다.");
                return;
            }
            _manualShapeScanStopInProgress = true;
            try
            {
                var failures = (await StopManualShapeScanPrograms(pending)).ToList();
                if (_manualShapeScanAttenuatorPositioning?.HasPendingStops == true)
                {
                    try { await _manualShapeScanAttenuatorPositioning.StopPendingAsync(); }
                    catch (Exception exception) { failures.Add(exception.Message); }
                }
                if (failures.Count > 0)
                    CRecipeConfirmDialog.ShowWarning("형상 스캔 정지 실패", string.Join("\n", failures));
                else
                {
                    _laserState = "OFF";
                    _lastResult = "Stopped";
                    _setStatusMessage("형상 가공 Head의 정지를 확인했습니다.");
                }
            }
            finally
            {
                _manualShapeScanStopInProgress = false;
                RefreshCommandStateRows();
                _refreshShellStatus();
            }
            return;
        }
        _lastCommand = "SHAPE_STOP";
        run.Cancellation.Cancel();
        await run.Completed.Task;
    }

    private async Task<IReadOnlyList<ST_MANUAL_SHAPE_SCAN_PROGRAM>> PrepareManualShapeScanPrograms(CancellationToken cancellationToken, bool useCurrentPosition)
    {
        var options = _manager.Setting().LoadSection(EN_SETTING_TAB.Option, cancellationToken);
        var routes = BuildManualShapeScanRoutes(options, SelectedManualHeadNos);
        var origins = CaptureManualScanOrigins(routes, options, useCurrentPosition);
        var programs = new List<ST_MANUAL_SHAPE_SCAN_PROGRAM>(routes.Count);
        foreach (var route in routes)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (!_manager.automation.IsSimul(route.AutomationNo) && !_manager.automation.IsConnect(route.AutomationNo))
                throw new InvalidOperationException($"CONTROLLER {route.AutomationNo + 1}이 연결되어 있지 않습니다.");
            ST_MANUAL_SCAN_PARAM settings;
            try { settings = await ReadAssignedManualScanParam(route.HeadNo, cancellationToken); }
            catch (Exception exception) when (exception is InvalidDataException or IOException or InvalidOperationException)
            {
                throw new InvalidDataException($"HEAD {route.HeadNo:00} / {ScanAssignments.GetSettingName(route.HeadNo)}\n{exception.Message}", exception);
            }

            var scriptName = BuildShapeScanScriptName(route.HeadNo, settings.ShapeName);
            var script = _scriptFile.Create($"{scriptName}.ascript");
            script.SetDeviceNo(route.HeadNo - 1);
            script.SetAxis(route.XAxis, route.YAxis);
            AppendManualSettingComment(script, settings);
            script.Start($"Manual H{route.HeadNo:00} {scriptName}");
            script.LaserOff();
            ApplyManualFigureScanSetup(script, settings);
            var position = ResolveManualScanPosition(route, options, settings, origins[route.HeadNo], useCurrentPosition);
            script.AddLine(position.ScriptComment);
            AppendShape(script, settings with { OffsetX = position.TargetX, OffsetY = position.TargetY });
            script.WaitMoveDone();
            script.LaserOff();
            script.End();
            var saved = script.Save(cancellationToken);
            programs.Add(new(route.HeadNo, route.AutomationNo, route.TaskNo,
                ScanAssignments.GetSettingName(route.HeadNo), settings, saved.FileName, saved.FilePath) { LaserAxis = route.XAxis, Position = position });
        }
        await EnsureManualShapeScanTasksReady(programs, cancellationToken);
        return programs;
    }

    private static IReadOnlyList<ST_MANUAL_SHAPE_SCAN_ROUTE> BuildManualShapeScanRoutes(
        IReadOnlyList<ST_SYSTEM_PARAMETER> options, IReadOnlyList<int> headNos)
    {
        if (headNos.Count == 0) throw new InvalidDataException("형상 가공할 Head를 먼저 선택해 주세요.");
        var enabledHeads = CScannerStatusSnapshotReader.BuildEnabledHeadNumbers(options);
        var tasks = new HashSet<(int Controller, int Task)>();
        var axes = new HashSet<(int Controller, string Axis)>();
        var routes = new List<ST_MANUAL_SHAPE_SCAN_ROUTE>(headNos.Count);
        foreach (var headNo in headNos.Distinct().Order())
        {
            if (!enabledHeads.Contains(headNo)) throw new InvalidDataException($"HEAD {headNo:00}은 사용 설정된 Head가 아닙니다.");
            var controller = ReadManualHeadAutomationNo(options, headNo);
            var task = ReadManualHeadAutomationTaskNo(options, headNo);
            if (!tasks.Add((controller, task)))
                throw new InvalidDataException($"선택한 Head에 동일한 CONTROLLER {controller + 1} / Task {task}가 중복 지정되어 있습니다.");
            var definitions = CScannerStatusSnapshotReader.BuildAxisDefinitions(options, headNo);
            var names = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (var role in new[] { "X", "Y" })
            {
                var axis = definitions.FirstOrDefault(definition => definition.AxisName.Equals(role, StringComparison.OrdinalIgnoreCase));
                if (!axis.IsUsed || !string.IsNullOrWhiteSpace(axis.ConfigurationError) || !IsConfiguredScannerAxisName(axis.AxisReference))
                    throw new InvalidDataException($"HEAD {headNo:00} {role}축 설정을 확인해 주세요. {axis.ConfigurationError}");
                if (axis.AutomationNo != controller || !axes.Add((controller, axis.AxisReference.ToUpperInvariant())))
                    throw new InvalidDataException($"HEAD {headNo:00} {role}축의 컨트롤러 또는 축 중복 설정을 확인해 주세요.");
                names[role] = axis.AxisReference;
            }
            routes.Add(new(headNo, controller, task, names["X"], names["Y"]));
        }
        return routes;
    }

    private async Task EnsureManualShapeScanTasksReady(IReadOnlyList<ST_MANUAL_SHAPE_SCAN_PROGRAM> programs, CancellationToken cancellationToken)
    {
        foreach (var program in programs)
        {
            var response = await _manager.automation.ReadTaskStatus(program.TaskNo, program.AutomationNo, cancellationToken);
            var fields = response.Split(':');
            if (fields.Length < 4 || !fields[0].Equals("OK", StringComparison.OrdinalIgnoreCase) ||
                !fields[1].Equals("TASK", StringComparison.OrdinalIgnoreCase) ||
                !int.TryParse(fields[2], NumberStyles.Integer, CultureInfo.InvariantCulture, out var task) || task != program.TaskNo ||
                !(fields[3].Equals("Idle", StringComparison.OrdinalIgnoreCase) || fields[3].Equals("ProgramComplete", StringComparison.OrdinalIgnoreCase)))
                throw new InvalidOperationException($"HEAD {program.HeadNo:00}의 Task {program.TaskNo}를 시작할 수 없습니다. {response}");
        }
    }

    private async Task ExecuteManualShapeScanPrograms(IReadOnlyList<ST_MANUAL_SHAPE_SCAN_PROGRAM> programs, CancellationToken cancellationToken)
    {
        var started = new List<ST_MANUAL_SHAPE_SCAN_PROGRAM>(programs.Count);
        try
        {
            // Every upload must succeed before the first Head is allowed to start.
            foreach (var program in programs)
            {
                cancellationToken.ThrowIfCancellationRequested();
                var response = await _manager.automation.UploadScript(program.FilePath, program.FileName,
                    program.AutomationNo, cancellationToken);
                EnsureAutomationResponse(response, $"HEAD {program.HeadNo:00} shape upload");
            }
            await EnsureManualShapeScanTasksReady(programs, cancellationToken);
            EnsureManualShapeScanAutoStopped();
            await PrepareManualShapeScanAttenuators(programs, cancellationToken);
            // Tasks may have changed while the ATT devices were moving.
            await EnsureManualShapeScanTasksReady(programs, cancellationToken);
            var responses = new List<string>(programs.Count);
            foreach (var program in programs)
            {
                cancellationToken.ThrowIfCancellationRequested();
                EnsureManualShapeScanAutoStopped();
                // Include an attempted RUN, because a lost response can still mean the controller started it.
                started.Add(program);
                var response = await _manager.automation.RunScript(program.FileName, program.TaskNo,
                    program.AutomationNo, cancellationToken);
                EnsureAutomationResponse(response, $"HEAD {program.HeadNo:00} shape run");
                responses.Add(response);
            }

            using var monitors = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            async Task Monitor(ST_MANUAL_SHAPE_SCAN_PROGRAM program, string response)
            {
                try
                {
                    await WaitManualTaskCompleted(response, !_manager.automation.IsSimul(program.AutomationNo),
                        program.AutomationNo, program.TaskNo, monitors.Token);
                }
                catch
                {
                    monitors.Cancel();
                    throw;
                }
            }
            await Task.WhenAll(programs.Select((program, index) => Monitor(program, responses[index])));
            cancellationToken.ThrowIfCancellationRequested();
        }
        catch (Exception exception)
        {
            var failures = await StopManualShapeScanPrograms(started);
            if (failures.Count > 0)
                throw new IOException($"{exception.Message}\n일부 Head의 정지를 확인하지 못했습니다.\n{string.Join("\n", failures)}", exception);
            throw;
        }
    }

    private void EnsureManualShapeScanAutoStopped()
    {
        if (IsAutoProcessRunning())
            throw new InvalidOperationException("자동 운전이 시작되어 형상 스캔을 차단했습니다. 자동 운전을 정지한 후 다시 시도해 주세요.");
    }

    private async Task PrepareManualShapeScanAttenuators(
        IReadOnlyList<ST_MANUAL_SHAPE_SCAN_PROGRAM> programs, CancellationToken cancellationToken)
    {
        // Resolve every Head first: a bad or missing table must not leave other Heads moving.
        var targets = await Task.Run(() =>
        {
            var table = new CPowerTableFile(_manager.ConfigRoot);
            return programs.Select(program =>
            {
                cancellationToken.ThrowIfCancellationRequested();
                return new ST_ATTENUATOR_MOVE_TARGET(program.HeadNo,
                    table.ResolveAttenuatorAngle(program.HeadNo, program.Settings.LaserPower, cancellationToken));
            }).ToArray();
        }, cancellationToken);
        var positioning = _manualShapeScanAttenuatorPositioning ??= new CAttenuatorPositioningService(_manager.Interface());
        await positioning.MoveAndWaitAsync(targets, cancellationToken);
    }

    private async Task<IReadOnlyList<string>> StopManualShapeScanPrograms(IReadOnlyList<ST_MANUAL_SHAPE_SCAN_PROGRAM> programs)
    {
        var failures = new List<string>();
        var pending = new List<ST_MANUAL_SHAPE_SCAN_PROGRAM>();
        foreach (var program in programs)
        {
            using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(5));
            var failed = false;
            try
            {
                var response = await _manager.automation.StopTask(program.TaskNo, program.AutomationNo, timeout.Token);
                EnsureAutomationResponse(response, $"HEAD {program.HeadNo:00} shape stop");
                await WaitManualTaskCompleted(response, false, program.AutomationNo, program.TaskNo, timeout.Token);
            }
            catch (Exception stopException)
            {
                failed = true;
                failures.Add($"HEAD {program.HeadNo:00}: {stopException.Message}");
            }
            if (!string.IsNullOrWhiteSpace(program.LaserAxis))
            {
                using var offTimeout = new CancellationTokenSource(TimeSpan.FromSeconds(5));
                try
                {
                    var response = await _manager.automation.SetGalvoLaserOutput(program.LaserAxis, false,
                        program.TaskNo, program.AutomationNo, offTimeout.Token);
                    EnsureAutomationResponse(response, $"HEAD {program.HeadNo:00} laser off");
                }
                catch (Exception exception)
                {
                    failed = true;
                    failures.Add($"HEAD {program.HeadNo:00} LASER OFF: {exception.Message}");
                }
            }
            if (failed) pending.Add(program);
        }
        // Keep uncertain Tasks available for STOP retries even if Head selection changes or the run has failed.
        _manualShapeScanPendingStops = pending;
        return failures;
    }

    private sealed class CManualShapeScanRun
    {
        public CancellationTokenSource Cancellation { get; } = new();
        public TaskCompletionSource Completed { get; } = new(TaskCreationOptions.RunContinuationsAsynchronously);
        public IReadOnlyList<ST_MANUAL_SHAPE_SCAN_PROGRAM> Programs { get; set; } = [];
    }

    private sealed record ST_MANUAL_SHAPE_SCAN_ROUTE(int HeadNo, int AutomationNo, int TaskNo, string XAxis, string YAxis);
    private sealed record ST_MANUAL_SHAPE_SCAN_PROGRAM(int HeadNo, int AutomationNo, int TaskNo, string SettingName,
        ST_MANUAL_SCAN_PARAM Settings, string FileName, string FilePath)
    {
        public string LaserAxis { get; init; } = "";
        public ST_MANUAL_SCAN_POSITION? Position { get; init; }
    }
}
