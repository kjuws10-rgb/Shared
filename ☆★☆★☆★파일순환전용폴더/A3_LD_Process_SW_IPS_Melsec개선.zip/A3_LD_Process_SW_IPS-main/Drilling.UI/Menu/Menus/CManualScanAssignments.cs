using System.ComponentModel;

namespace Drilling.UI.Menu.Menus;

public sealed class CManualScanAssignments : INotifyPropertyChanged
{
    private readonly Dictionary<int, CManualScanAssignment> _headCache = [];
    private IReadOnlyList<string> _settingNames = [];

    public event PropertyChangedEventHandler? PropertyChanged;
    public IReadOnlyList<CManualScanAssignment> Heads { get; private set; } = [];

    public void Update(IReadOnlyList<int> heads, IReadOnlyList<string> settingNames, string defaultSettingName)
    {
        _settingNames = NormalizeNames(settingNames);
        // Hidden Heads retain their choices, but deletion applies to them as well.
        foreach (var row in _headCache.Values)
            row.UpdateAvailableSettings(_settingNames);

        var visible = new List<CManualScanAssignment>();
        foreach (var head in heads.Where(head => head > 0).Distinct().Order())
        {
            if (!_headCache.TryGetValue(head, out var row))
            {
                row = new CManualScanAssignment(head, _settingNames, defaultSettingName);
                _headCache.Add(head, row);
            }
            visible.Add(row);
        }

        if (Heads.SequenceEqual(visible)) return;
        Heads = visible;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Heads)));
    }

    // Call after a successful file rename, before refreshing the file list.
    public void RenameSetting(string oldName, string newName)
    {
        var oldFile = NormalizeName(oldName);
        var newFile = NormalizeName(newName);
        if (oldFile.Length == 0 || newFile.Length == 0 ||
            !_settingNames.Any(name => name.Equals(oldFile, StringComparison.OrdinalIgnoreCase))) return;

        _settingNames = NormalizeNames(_settingNames.Select(name =>
            name.Equals(oldFile, StringComparison.OrdinalIgnoreCase) ? newFile : name).ToArray());
        foreach (var row in _headCache.Values)
            row.RenameSetting(oldFile, newFile, _settingNames);
    }

    public string GetSettingName(int head)
        => _headCache.TryGetValue(head, out var row) ? row.SelectedSettingName : "";

    private static IReadOnlyList<string> NormalizeNames(IReadOnlyList<string> names)
        => names.Select(NormalizeName).Where(name => name.Length > 0)
            .Distinct(StringComparer.OrdinalIgnoreCase).ToArray();

    private static string NormalizeName(string? value)
    {
        var name = value?.Trim() ?? "";
        if (!name.EndsWith(".scan", StringComparison.OrdinalIgnoreCase) || name.Length <= 5 ||
            name.Any(character => character < 32 || "<>:\"/\\|?*".Contains(character))) return "";
        var stem = name.Split('.')[0];
        if (stem.Length == 0 || stem.Equals("CON", StringComparison.OrdinalIgnoreCase) ||
            stem.Equals("PRN", StringComparison.OrdinalIgnoreCase) || stem.Equals("AUX", StringComparison.OrdinalIgnoreCase) ||
            stem.Equals("NUL", StringComparison.OrdinalIgnoreCase) ||
            (stem.Length == 4 && (stem.StartsWith("COM", StringComparison.OrdinalIgnoreCase) ||
                                  stem.StartsWith("LPT", StringComparison.OrdinalIgnoreCase)) && stem[3] is >= '1' and <= '9')) return "";
        return name;
    }
}

public sealed class CManualScanAssignment : INotifyPropertyChanged
{
    private string _selectedSettingName;

    public event PropertyChangedEventHandler? PropertyChanged;
    public int HeadNo { get; }
    public string HeadName => $"HEAD {HeadNo:00}";
    public IReadOnlyList<string> SettingNames { get; private set; }
    public string SelectedSettingName
    {
        get => _selectedSettingName;
        set
        {
            // ComboBox can write null while its ItemsSource is replaced. Only a
            // choice from the complete current file list can change assignment.
            var canonical = FindSetting(value);
            if (canonical is null || _selectedSettingName == canonical) return;
            _selectedSettingName = canonical;
            Notify(nameof(SelectedSettingName));
        }
    }

    internal CManualScanAssignment(int headNo, IReadOnlyList<string> settingNames, string defaultSettingName)
    {
        HeadNo = headNo;
        SettingNames = settingNames;
        _selectedSettingName = FindSetting(defaultSettingName) ?? "";
    }

    internal void UpdateAvailableSettings(IReadOnlyList<string> names)
    {
        var previous = _selectedSettingName;
        var namesChanged = !SettingNames.SequenceEqual(names);
        SettingNames = names;
        _selectedSettingName = FindSetting(previous) ?? "";
        if (namesChanged) Notify(nameof(SettingNames));
        if (_selectedSettingName != previous) Notify(nameof(SelectedSettingName));
    }

    internal void RenameSetting(string oldName, string newName, IReadOnlyList<string> names)
    {
        var renamed = _selectedSettingName.Equals(oldName, StringComparison.OrdinalIgnoreCase);
        if (renamed) _selectedSettingName = newName;
        UpdateAvailableSettings(names);
        if (renamed) Notify(nameof(SelectedSettingName));
    }

    private string? FindSetting(string? name)
        => string.IsNullOrWhiteSpace(name) ? null : SettingNames.FirstOrDefault(candidate =>
            candidate.Equals(name.Trim(), StringComparison.OrdinalIgnoreCase));

    private void Notify(string name) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}
