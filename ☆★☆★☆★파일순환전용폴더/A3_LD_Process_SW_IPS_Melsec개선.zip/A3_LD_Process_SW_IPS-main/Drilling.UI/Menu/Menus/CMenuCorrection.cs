﻿using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Media;
using Drilling.Common.Managers;
using Drilling.Common.Recipe;
using Drilling.Common.Review;
using Drilling.Common.Interface;
using Drilling.Common.Correction;
using Drilling.UI.Menu;
using Microsoft.Win32;
using Drilling.UI.Popup;

namespace Drilling.UI.Menu.Menus;
public sealed partial class CMenuCorrection : CMenuBase
{
    private static readonly string[] CorrectionTabs = ["ALIGN/DISTORTION", "REVIEW", "APC / ICR", "VIEWER / HISTORY"];
    private readonly CReviewResultFileBase _reviewResultFile;
    private readonly CReviewOffsetFileBase _reviewOffsetFile;
    private readonly CReviewManager _reviewManager;
    private readonly CRecipeManager _recipeManager;
    private readonly CSettingManager _settingManager;
    private readonly Func<string> _selectedRecipeIdProvider;
    private readonly Action<string> _statusReporter;
    private readonly Func<Task> _refreshCurrentScreen;
    private readonly CAlignLastLoadService _alignLastLoad;
    private readonly CAlignOffsetLogFileBase? _alignOffsetLogFile;
    private readonly List<ST_CORRECTION_HISTORY_ROW> _reviewDataHistory = [];
    private ST_REVIEW_RESULT_FILE_DATA? _loadedReviewResult;
    private bool _hasPendingReviewOffsetApply;
    private string _reviewLoadStatus = "Select a Review Result CSV.";
    private string _reviewLoadState = "WAIT";
    private string _currentSettingState = "Vision: - | Scanner: -";
    private string _currentVisionSettingState = "-";
    private string _currentScannerSettingState = "-";
    private string _currentSettingDetail = "Vision Flip: -\nScanner Flip: -";
    private string _calculatedSettingDetail = "";
    private string _currentReviewOffsetRecipeName = "Recipe: -";
    private bool _outputViewerIsCellDetailVisible;
    private int _outputViewerSelectedCellNo;
    private string _selectedTab = "ALIGN/DISTORTION";
    private string _simpleOffsetRecipeId = "";
    private Task<ST_REVIEW_OFFSET_FILE_DATA>? _simpleOffsetLoad;
    private bool _isReviewOperationRunning;
    public CMenuCorrection(CReviewResultFileBase reviewResultFile, CReviewOffsetFileBase reviewOffsetFile, CReviewManager reviewManager, CRecipeManager recipeManager, CSettingManager settingManager, Func<string> selectedRecipeIdProvider, Action<string> statusReporter, Func<Task> refreshCurrentScreen, CInterfaceManager? interfaceManager = null, CAlignOffsetLogFileBase? alignOffsetLogFile = null)
    {
        _reviewResultFile = reviewResultFile;
        _reviewOffsetFile = reviewOffsetFile;
        _reviewManager = reviewManager;
        _recipeManager = recipeManager;
        _settingManager = settingManager;
        _selectedRecipeIdProvider = selectedRecipeIdProvider;
        _statusReporter = statusReporter;
        _refreshCurrentScreen = refreshCurrentScreen;
        _alignLastLoad = new CAlignLastLoadService(interfaceManager);
        _alignOffsetLogFile = alignOffsetLogFile;
        AlignDistortion = new CAlignDistortionPanel(ExecuteAlignBaseAction);
        Simple = new CSimpleCorrectionPanel(action => ExecuteSimpleOffsetAction(action));
        Rough = new CSimpleCorrectionPanel(action => ExecuteRoughAction(action), isRough: true);
        Fine = new CFineCorrectionPanel(action => _ = ExecuteFineAction(action),
            CRecipeConfirmDialog.ShowFineRetryChoice) { ShowLineDetails = CFineLineDetailsDialog.Show };
        Fine.SourceInvalidated += () => _fineCancellation?.Cancel();
        InitializeRough(interfaceManager);
        SelectTabCommand = new CButtonCommand(SelectTab);
        ExecuteCommand = new CButtonCommand(
            Execute,
            _ => !_isReviewOperationRunning);
        async void SelectOutputViewerCellCallback(object? parameter)
        {
            await SelectOutputViewerCell(parameter);
        }

        SelectOutputViewerCellCommand = new CButtonCommand(SelectOutputViewerCellCallback);
        async void BackToOutputViewerGlassCallback(object? parameter)
        {
            await BackToOutputViewerGlass(parameter);
        }

        BackToOutputViewerGlassCommand = new CButtonCommand(BackToOutputViewerGlassCallback);
    }

    public override EN_MENU Menu
    {
        get
        {
            return EN_MENU.Correction;
        }
    }

    public string Title
    {
        get
        {
            return $"CORRECTION / {_selectedTab}";
        }
    }

    public string Subtitle
    {
        get
        {
            return GetSubtitle(_selectedTab);
        }
    }

    public string SelectedTab
    {
        get
        {
            return _selectedTab;
        }
    }

    public bool IsOtherCorrectionTab
    {
        get
        {
            return !IsOutputHistoryTab && !IsAlignDistortionTab && !IsReviewCorrectionTab;
        }
    }

    public bool IsAlignDistortionTab => _selectedTab == "ALIGN/DISTORTION";
    public bool IsReviewCorrectionTab => _selectedTab == "REVIEW";
    public CSimpleCorrectionPanel Simple { get; }
    public CSimpleCorrectionPanel Rough { get; }
    public CFineCorrectionPanel Fine { get; }
    public bool IsCorrectionCommandsVisible => !IsAlignDistortionTab && !IsReviewCorrectionTab;
    public CAlignDistortionPanel AlignDistortion { get; }

    public bool IsOutputHistoryTab
    {
        get
        {
            return _selectedTab.Equals("VIEWER / HISTORY", StringComparison.OrdinalIgnoreCase);
        }
    }

    public bool IsCorrectionHistoryVisible
    {
        get
        {
            return !IsOutputHistoryTab;
        }
    }

    public IReadOnlyList<ST_CORRECTION_TAB> Tabs { get; private set; } = [];
    public IReadOnlyList<ST_DISPLAY_ITEM> SummaryItems { get; private set; } = [];
    public IReadOnlyList<ST_CORRECTION_SOURCE_ROW> SourceRows { get; private set; } = [];
    public IReadOnlyList<ST_CORRECTION_VALUE_ROW> CandidateRows { get; private set; } = [];
    public IReadOnlyList<ST_CORRECTION_VALUE_ROW> ApplyRows { get; private set; } = [];
    public IReadOnlyList<ST_CORRECTION_HISTORY_ROW> HistoryRows { get; private set; } = [];
    public IReadOnlyList<ST_DISPLAY_ITEM> DetailItems { get; private set; } = [];
    public IReadOnlyList<ST_CORRECTION_REVIEW_RESULT_ROW> ReviewResultRows { get; private set; } = [];
    public IReadOnlyList<ST_CORRECTION_REVIEW_OFFSET_ROW> CalculatedOffsetRows { get; private set; } = [];
    public IReadOnlyList<ST_CORRECTION_REVIEW_OFFSET_ROW> CurrentOffsetRows { get; private set; } = [];
    public IReadOnlyList<ST_CORRECTION_REVIEW_OFFSET_ROW> ApplyPreviewRows { get; private set; } = [];
    public ImageSource? OutputViewerGlassPreviewImage { get; private set; }
    public IReadOnlyList<ST_CELL_PREVIEW_LABEL> OutputViewerCellPreviewLabels { get; private set; } = [];
    public IReadOnlyList<ST_CORRECTION_OFFSET_SHOT_MATRIX_ROW> OutputViewerShotMatrixRows { get; private set; } = [];
    public string OutputViewerSummary { get; private set; } = "0 Cells / 0 Shots";
    public string OutputViewerSelectedCellName => _outputViewerIsCellDetailVisible && _outputViewerSelectedCellNo > 0 ? $"CELL{_outputViewerSelectedCellNo:00}" : "GLASS";
    public bool OutputViewerIsGlassPreviewVisible => IsOutputHistoryTab && !_outputViewerIsCellDetailVisible;
    public bool OutputViewerIsCellDetailVisible => IsOutputHistoryTab && _outputViewerIsCellDetailVisible;
    public ST_CORRECTION_AXIS_FLIP_ROW CurrentVisionFlipRow { get; private set; } = new("VISION", false, false, false);
    public IReadOnlyList<ST_CORRECTION_AXIS_FLIP_ROW> CurrentScannerFlipRows { get; private set; } = [];

    public string LoadedReviewFileName
    {
        get
        {
            return _loadedReviewResult?.FileName ?? "Not loaded";
        }
    }

    public string LoadedReviewSettingSummary
    {
        get
        {
            var detail = FormatReviewSettingDetail(_loadedReviewResult);
            return string.IsNullOrWhiteSpace(detail)
                ? LoadedReviewRule
                : $"{LoadedReviewRule} · {detail}";
        }
    }

    public string LoadedReviewRule => string.IsNullOrWhiteSpace(_loadedReviewResult?.Rule)
        ? "-"
        : _loadedReviewResult.Rule.ToUpperInvariant();

    public string LoadedReviewSettingDetail => FormatReviewSettingDetail(_loadedReviewResult);

    public string ReviewLoadStatus
    {
        get
        {
            return _reviewLoadStatus;
        }
    }

    public Brush ReviewLoadStatusBrush
    {
        get
        {
            return CStatusBrush.ForDisplayState(_reviewLoadState);
        }
    }

    public string CurrentSettingState
    {
        get
        {
            return _currentSettingState;
        }
    }

    public string CurrentSettingDetail
    {
        get
        {
            return _currentSettingDetail;
        }
    }

    public string CurrentVisionSettingState
    {
        get
        {
            return _currentVisionSettingState;
        }
    }

    public string CurrentScannerSettingState
    {
        get
        {
            return _currentScannerSettingState;
        }
    }

    public string CurrentReviewOffsetRecipeName
    {
        get
        {
            return _currentReviewOffsetRecipeName;
        }
    }

    public CButtonCommand SelectTabCommand { get; }
    public CButtonCommand ExecuteCommand { get; }
    public CButtonCommand SelectOutputViewerCellCommand { get; }
    public CButtonCommand BackToOutputViewerGlassCommand { get; }

    public override async Task<CScreenViewModel> Build(CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        ApplyTabData(_selectedTab);
        if (IsAlignDistortionTab)
        {
            try
            {
                AlignDistortion.Update(await LoadSelectedOutputViewerRecipe(cancellationToken, fallbackToFirst: false));
                RefreshAlignOffsetTolerance();
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) { throw; }
            catch (Exception exception) { AlignDistortion.Clear($"Glass preview unavailable: {exception.Message}"); }
        }
        if (IsReviewCorrectionTab)
        {
            try
            {
                var recipe = await LoadSelectedOutputViewerRecipe(cancellationToken, fallbackToFirst: false);
                var settings = _settingManager.LoadSection(EN_SETTING_TAB.Option, cancellationToken)
                    .Concat(_settingManager.LoadSection(EN_SETTING_TAB.Motor, cancellationToken)).ToArray();
                ST_REVIEW_OFFSET_FILE_DATA? current = null;
                if (recipe is not null)
                {
                    if (_simpleOffsetLoad is null || _simpleOffsetLoad.IsFaulted || _simpleOffsetLoad.IsCanceled || _simpleOffsetRecipeId != recipe.Id)
                    {
                        _simpleOffsetRecipeId = recipe.Id;
                        _simpleOffsetLoad = _reviewOffsetFile is null ? Task.FromResult(ST_REVIEW_OFFSET_FILE_DATA.Empty(recipe.Id))
                            : Task.Run(() => _reviewOffsetFile.LoadLatest(recipe.Id, cancellationToken), cancellationToken);
                    }
                    current = await _simpleOffsetLoad.WaitAsync(cancellationToken);
                }
                Simple.Update(recipe, settings, current);
                Rough.Update(recipe, settings, current);
                try { Fine.Update(recipe, settings); }
                catch (Exception exception) { Fine.Clear($"Glass preview unavailable: {exception.Message}"); }
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) { throw; }
            catch (Exception exception) { Simple.Clear($"Glass preview unavailable: {exception.Message}"); Rough.Clear($"Glass preview unavailable: {exception.Message}"); Fine.Clear($"Glass preview unavailable: {exception.Message}"); }
        }
        if (IsOutputHistoryTab)
        {
            await RefreshOutputViewerData(cancellationToken);
        }

        var screen = new CScreenViewModel(EN_MENU.Correction, Title, Subtitle, [new("Selected", _selectedTab), new("Source", GetSourceName(_selectedTab)), new("State", GetStateName(_selectedTab))], [new("Correction Source", []), new("Correction Candidate", []), new("Apply Preview", [])], correction: this);
        return screen;
    }

    private void SelectTab(object? parameter)
    {
        var tabName = parameter?.ToString()?.Trim();
        if (string.IsNullOrWhiteSpace(tabName))
        {
            return;
        }

        bool MatchesItem(string tab)
        {
            return tab.Equals(tabName, StringComparison.OrdinalIgnoreCase);
        }

        var normalizedTab = CorrectionTabs.FirstOrDefault(MatchesItem);
        if (normalizedTab is null)
        {
            return;
        }

        if (normalizedTab == "REVIEW" && _selectedTab != "REVIEW") _simpleOffsetLoad = null;
        _selectedTab = normalizedTab;
        _statusReporter($"Correction tab selected: {_selectedTab}.");
        _ = _refreshCurrentScreen();
    }

    private async Task SelectOutputViewerCell(object? parameter)
    {
        if (!int.TryParse(parameter?.ToString(), NumberStyles.Integer, CultureInfo.InvariantCulture, out var cellNo))
        {
            return;
        }

        _outputViewerSelectedCellNo = Math.Max(1, cellNo);
        _outputViewerIsCellDetailVisible = true;
        _statusReporter($"Offset Viewer cell selected: CELL{_outputViewerSelectedCellNo:00}.");
        await _refreshCurrentScreen();
    }

    private async Task BackToOutputViewerGlass(object? parameter)
    {
        _outputViewerIsCellDetailVisible = false;
        _outputViewerSelectedCellNo = 0;
        _statusReporter("Offset Viewer glass preview opened.");
        await _refreshCurrentScreen();
    }

    private async Task RefreshOutputViewerData(CancellationToken cancellationToken)
    {
        try
        {
            var recipe = await LoadSelectedOutputViewerRecipe(cancellationToken);
            if (recipe is null)
            {
                OutputViewerGlassPreviewImage = null;
                OutputViewerCellPreviewLabels = [];
                OutputViewerShotMatrixRows = [];
                OutputViewerSummary = "Recipe not loaded";
                return;
            }

            var settings = new List<ST_SYSTEM_PARAMETER>();
            settings.AddRange(_settingManager.LoadSection(EN_SETTING_TAB.Option, cancellationToken));
            settings.AddRange(_settingManager.LoadSection(EN_SETTING_TAB.Motor, cancellationToken));
            var parameters = BuildOutputViewerParameterMap(recipe, settings);
            var reviewOffsetFile = await _reviewOffsetFile.LoadLatest(recipe.Id, cancellationToken);
            ApplyReviewOffsetsToOutputViewerParameters(parameters, reviewOffsetFile);
            var cellCount = Math.Max(CCellPatternCalculator.MinCellCount, ReadOutputViewerInt(parameters, CCellPatternCalculator.MinCellCount, "MAX_CELL_NUMBER"));
            if (_outputViewerIsCellDetailVisible)
            {
                _outputViewerSelectedCellNo = Math.Clamp(Math.Max(1, _outputViewerSelectedCellNo), 1, cellCount);
            }
            else
            {
                _outputViewerSelectedCellNo = 0;
            }

            var selectedCellNo = _outputViewerIsCellDetailVisible ? _outputViewerSelectedCellNo : 0;
            var preview = BuildOutputViewerGlassPreview(parameters, cellCount, selectedCellNo);
            OutputViewerGlassPreviewImage = preview.Image;
            OutputViewerCellPreviewLabels = preview.CellLabels;
            OutputViewerSummary = preview.Summary;
            OutputViewerShotMatrixRows = _outputViewerIsCellDetailVisible
                ? BuildOutputViewerShotMatrixRows(parameters, _outputViewerSelectedCellNo)
                : [];
        }
        catch (Exception exception)
        {
            OutputViewerGlassPreviewImage = null;
            OutputViewerCellPreviewLabels = [];
            OutputViewerShotMatrixRows = [];
            OutputViewerSummary = $"Offset Viewer unavailable: {exception.Message}";
        }
    }

    private async Task<ST_RECIPE_DEFINITION?> LoadSelectedOutputViewerRecipe(CancellationToken cancellationToken, bool fallbackToFirst = true)
    {
        var recipes = await _recipeManager.LoadRecipes(cancellationToken);
        var selectedRecipeId = NormalizeRecipeId(_selectedRecipeIdProvider());
        bool MatchById(ST_RECIPE_DEFINITION recipe)
        {
            return recipe.Id.Equals(selectedRecipeId, StringComparison.OrdinalIgnoreCase);
        }

        bool MatchByName(ST_RECIPE_DEFINITION recipe)
        {
            return recipe.Name.Equals(selectedRecipeId, StringComparison.OrdinalIgnoreCase);
        }

        return string.IsNullOrWhiteSpace(selectedRecipeId)
            ? (fallbackToFirst ? recipes.FirstOrDefault() : null)
            : recipes.FirstOrDefault(MatchById) ?? recipes.FirstOrDefault(MatchByName) ?? (fallbackToFirst ? recipes.FirstOrDefault() : null);
    }

    private static Dictionary<string, string> BuildOutputViewerParameterMap(ST_RECIPE_DEFINITION recipe, IReadOnlyList<ST_SYSTEM_PARAMETER> settings)
    {
        var parameters = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var parameter in recipe.Parameters)
        {
            SetOutputViewerParameter(parameters, parameter.Key, parameter.Value);
            SetOutputViewerParameter(parameters, parameter.Name, parameter.Value);
        }

        foreach (var setting in settings)
        {
            SetOutputViewerParameter(parameters, setting.Key, setting.Value);
            SetOutputViewerParameter(parameters, setting.Name, setting.Value);
        }

        parameters.TryAdd("HEAD_COUNT", "8");
        return parameters;
    }

    private static void SetOutputViewerParameter(IDictionary<string, string> parameters, string key, string value)
    {
        if (!string.IsNullOrWhiteSpace(key))
        {
            parameters[key.Trim()] = value;
        }
    }

    internal static void ApplyReviewOffsetsToOutputViewerParameters(
        IDictionary<string, string> parameters,
        ST_REVIEW_OFFSET_FILE_DATA reviewOffsetFile)
    {
        CReviewOffsetData.ApplyToParameters(parameters, reviewOffsetFile);
    }

    private static ST_CORRECTION_OFFSET_VIEWER_PREVIEW BuildOutputViewerGlassPreview(IReadOnlyDictionary<string, string> parameters, int cellCount, int selectedCellNo)
    {
        const double canvasWidth = 860.0;
        const double canvasHeight = 430.0;
        const double maxLeft = 44.0;
        const double maxTop = 50.0;
        const double maxWidth = 772.0;
        const double maxHeight = 340.0;
        var glassWidth = ReadOutputViewerDouble(parameters, 500.0, "GLASS_SIZE_X");
        var glassHeight = ReadOutputViewerDouble(parameters, 300.0, "GLASS_SIZE_Y");
        var akMarginX = ReadOutputViewerDouble(parameters, 55.0, "AK_MARGIN_X");
        var akMarginY = ReadOutputViewerDouble(parameters, 45.0, "AK_MARGIN_Y");
        var pixelSize = ReadOutputViewerDouble(parameters, 0.09, "PIXEL_SIZE");
        var splitBeamCount = ReadOutputViewerInt(parameters, 1, "SPLITED_BEAM_COUNT");
        var modelTypeCount = CRecipeModelPixelCountReader.ReadModelTypeCount(parameters);
        if (glassWidth <= 0.0 || glassHeight <= 0.0)
        {
            return new ST_CORRECTION_OFFSET_VIEWER_PREVIEW(null, [], "Glass size is not valid.");
        }

        double? ReadDistortionValue(string key)
        {
            return ReadOutputViewerNullableDouble(parameters, key);
        }

        var distortionKeys = CCellPreviewDrawing.CreateDistortionKeyPreviews(glassWidth, glassHeight, akMarginX, akMarginY, ReadDistortionValue);
        var scale = Math.Min(maxWidth / glassWidth, maxHeight / glassHeight);
        var frameWidth = glassWidth * scale;
        var frameHeight = glassHeight * scale;
        var frameLeft = maxLeft + (maxWidth - frameWidth) / 2.0;
        var frameTop = maxTop + (maxHeight - frameHeight) / 2.0;
        var frame = new ST_GLASS_PREVIEW_FRAME(frameLeft, frameTop, frameWidth, frameHeight);
        var frameBounds = new Rect(frameLeft, frameTop, frameWidth, frameHeight);
        var drawing = new DrawingGroup();
        var cellLabels = new List<ST_CELL_PREVIEW_LABEL>();
        var drawnCellBoundaries = new List<(StreamGeometry Boundary, Pen Pen)>();
        long totalShotGroupCount = 0;
        var invalidCellCount = 0;
        using (var context = drawing.Open())
        {
            context.DrawRectangle(new SolidColorBrush(Color.FromArgb(1, 0, 0, 0)), null, new Rect(0, 0, canvasWidth, canvasHeight));
            context.PushClip(new RectangleGeometry(frameBounds));
            for (var cellNo = 1; cellNo <= cellCount; cellNo++)
            {
                var firstPixelX = ReadOutputViewerDouble(parameters, 0.0, $"CELL{cellNo}_ALIGN_TO_1ST_PIXEL_X");
                var firstPixelY = ReadOutputViewerDouble(parameters, 0.0, $"CELL{cellNo}_ALIGN_TO_1ST_PIXEL_Y");
                var rotation = ReadOutputViewerDouble(parameters, 0.0, $"CELL{cellNo}_ROTATION");
                var modelType = CRecipeModelPixelCountReader.ReadCellModelType(parameters, cellNo, modelTypeCount);
                var modelPattern = CRecipeModelPixelCountReader.ReadPatternForModel(parameters, modelType);
                var layout = CCellPatternCalculator.Calculate(new ST_CELL_PATTERN_DEFINITION(cellNo, firstPixelX, firstPixelY, rotation, pixelSize, modelPattern.PixelCountX, modelPattern.PixelCountY, modelPattern.ProcessPitch, splitBeamCount, akMarginX, akMarginY));
                if (!layout.IsValid)
                {
                    invalidCellCount++;
                }

                totalShotGroupCount += layout.ShotCenters.Count;
                var boundary = BuildOutputViewerCellBoundaryGeometry(frameLeft, frameTop, scale, pixelSize, modelPattern.PixelCountX, modelPattern.PixelCountY, akMarginX + firstPixelX, akMarginY + firstPixelY, rotation);
                if (boundary is null)
                {
                    continue;
                }

                var isSelectedCell = selectedCellNo > 0 && cellNo == selectedCellNo;
                var cellBrush = CMenuMain.CreateHeadBrush(((cellNo - 1) % 8) + 1, (byte)(selectedCellNo <= 0 || isSelectedCell ? 230 : 105));
                var boundaryBrush = CMenuMain.CreateHeadBrush(((cellNo - 1) % 8) + 1, (byte)(isSelectedCell ? 255 : 150));
                var boundaryPen = new Pen(boundaryBrush, isSelectedCell ? 2.4 : 1.2);
                boundaryPen.Freeze();
                context.DrawGeometry(cellBrush, null, boundary);
                drawnCellBoundaries.Add((boundary, boundaryPen));

                var label = CCellPreviewDrawing.CreateCellLabel(cellNo, boundary.Bounds, canvasWidth, canvasHeight, isSelectedCell);
                if (label is not null)
                {
                    cellLabels.Add(label);
                }
            }

            foreach (var drawnCell in drawnCellBoundaries)
            {
                context.DrawGeometry(null, drawnCell.Pen, drawnCell.Boundary);
            }

            context.Pop();
            CCellPreviewDrawing.DrawAlignKeys(context, frame, glassWidth, glassHeight, akMarginX, akMarginY);
            CCellPreviewDrawing.DrawDistortionKeys(context, frame, glassWidth, glassHeight, distortionKeys);
        }

        drawing.Freeze();
        var paddingX = frameWidth * 0.03;
        var paddingY = Math.Max(22.0, frameHeight * 0.03);
        var cellRect = new Rect(0, 0, frameWidth + (paddingX * 2.0), frameHeight + (paddingY * 2.0));
        var glassRect = new Rect(paddingX, paddingY, frameWidth, frameHeight);
        var translatedCellLabels = cellLabels
            .Select(label => label with
            {
                CanvasCenterX = label.CanvasCenterX - frameLeft + paddingX,
                CanvasCenterY = label.CanvasCenterY - frameTop + paddingY,
                DesignWidth = cellRect.Width,
                DesignHeight = cellRect.Height
            })
            .ToArray();
        var cellDrawing = new DrawingGroup();
        using (var cellContext = cellDrawing.Open())
        {
            cellContext.DrawRectangle(new SolidColorBrush(Color.FromArgb(1, 0, 0, 0)), null, cellRect);
            cellContext.DrawRectangle(null, new Pen(new SolidColorBrush(Color.FromRgb(102, 136, 164)), 1.8), glassRect);
            cellContext.PushClip(new RectangleGeometry(cellRect));
            cellContext.PushTransform(new TranslateTransform(-(frameLeft - paddingX), -(frameTop - paddingY)));
            cellContext.DrawDrawing(drawing);
            cellContext.Pop();
            cellContext.Pop();
            DrawOutputViewerPreviewAxisIndicator(cellContext, glassRect);
        }

        cellDrawing.Freeze();
        var cellImage = new DrawingImage(cellDrawing);
        cellImage.Freeze();
        var summary = $"{cellCount:N0} Cells / {totalShotGroupCount:N0} Shot Centers / Glass {FormatOutputViewerPreviewDouble(glassWidth)} x {FormatOutputViewerPreviewDouble(glassHeight)} mm";
        if (invalidCellCount > 0)
        {
            summary += $" / {invalidCellCount:N0} Invalid Cells";
        }

        return new ST_CORRECTION_OFFSET_VIEWER_PREVIEW(cellImage, translatedCellLabels, summary);
    }

    private static StreamGeometry? BuildOutputViewerCellBoundaryGeometry(double frameLeft, double frameTop, double scale, double pixelSize, int pixelCountX, int pixelCountY, double firstX, double firstY, double rotationDegrees)
    {
        if (pixelCountX <= 0 || pixelCountY <= 0 || !double.IsFinite(pixelSize) || pixelSize <= 0.0)
        {
            return null;
        }

        var radians = rotationDegrees * Math.PI / 180.0;
        var cos = Math.Cos(radians);
        var sin = Math.Sin(radians);
        var halfPixel = pixelSize / 2.0;
        var localMaxX = ((pixelCountX - 1) * pixelSize) + halfPixel;
        var localMaxY = ((pixelCountY - 1) * pixelSize) + halfPixel;
        var localCorners = new[]
        {
            new Point(-halfPixel, -halfPixel),
            new Point(localMaxX, -halfPixel),
            new Point(localMaxX, localMaxY),
            new Point(-halfPixel, localMaxY)
        };
        var canvasCorners = localCorners
            .Select(local =>
            {
                var x = firstX + (local.X * cos) - (local.Y * sin);
                var y = firstY + (local.X * sin) + (local.Y * cos);
                return new Point(frameLeft + (x * scale), frameTop + (y * scale));
            })
            .ToArray();
        var geometry = new StreamGeometry();
        using (var geometryContext = geometry.Open())
        {
            geometryContext.BeginFigure(canvasCorners[0], false, true);
            geometryContext.PolyLineTo(canvasCorners.Skip(1).ToArray(), true, false);
        }

        geometry.Freeze();
        return geometry;
    }

    private static void DrawOutputViewerPreviewAxisIndicator(DrawingContext context, Rect glassRect)
    {
        var axisBrush = new SolidColorBrush(Color.FromRgb(248, 250, 252));
        axisBrush.Freeze();
        var axisPen = new Pen(axisBrush, 2.0)
        {
            StartLineCap = PenLineCap.Round,
            EndLineCap = PenLineCap.Round
        };
        axisPen.Freeze();
        var origin = new Point(Math.Max(4.0, glassRect.Left - 8.0), Math.Max(4.0, glassRect.Top - 12.0));
        var xEnd = new Point(origin.X + 46.0, origin.Y);
        var yEnd = new Point(origin.X, origin.Y + 42.0);
        context.DrawLine(axisPen, origin, xEnd);
        context.DrawLine(axisPen, new Point(xEnd.X - 8.0, xEnd.Y - 4.0), xEnd);
        context.DrawLine(axisPen, new Point(xEnd.X - 8.0, xEnd.Y + 4.0), xEnd);
        context.DrawLine(axisPen, origin, yEnd);
        context.DrawLine(axisPen, new Point(yEnd.X - 4.0, yEnd.Y - 8.0), yEnd);
        context.DrawLine(axisPen, new Point(yEnd.X + 4.0, yEnd.Y - 8.0), yEnd);
        DrawOutputViewerPreviewAxisText(context, "X+", new Point(xEnd.X + 4.0, Math.Max(2.0, xEnd.Y - 10.0)), axisBrush);
        DrawOutputViewerPreviewAxisText(context, "Y+", new Point(yEnd.X + 4.0, yEnd.Y - 4.0), axisBrush);
    }

    private static void DrawOutputViewerPreviewAxisText(DrawingContext context, string text, Point point, Brush brush)
    {
        var label = new FormattedText(text, CultureInfo.InvariantCulture, FlowDirection.LeftToRight, new Typeface("Segoe UI Semibold"), 13.0, brush, 1.0);
        context.DrawText(label, point);
    }

    private static IReadOnlyList<ST_CORRECTION_OFFSET_SHOT_MATRIX_ROW> BuildOutputViewerShotMatrixRows(IReadOnlyDictionary<string, string> parameters, int selectedCellNo)
    {
        var viewerParameters = BuildOutputViewerCoordinateParameterMap(parameters);
        var coordinatePlan = CShotCoordinatePlanBuilder.Build(viewerParameters);
        var selectedShots = coordinatePlan.Shots
            .Where(shot => shot.CellNo == selectedCellNo)
            .GroupBy(shot => shot.GroupRow)
            .OrderBy(group => group.Key)
            .Select(group => new ST_CORRECTION_OFFSET_SHOT_MATRIX_ROW(
                group.Key + 1,
                group
                    .OrderBy(shot => shot.GroupColumn)
                    .ThenBy(shot => shot.CellShotNo)
                    .Select(CreateOutputViewerShotItem)
                    .ToArray()))
            .ToArray();
        return selectedShots;
    }

    private static IReadOnlyDictionary<string, string> BuildOutputViewerCoordinateParameterMap(IReadOnlyDictionary<string, string> parameters)
    {
        var viewerParameters = new Dictionary<string, string>(parameters, StringComparer.OrdinalIgnoreCase);
        var headCount = Math.Clamp(ReadOutputViewerInt(viewerParameters, 8, "HEAD_COUNT"), 1, 8);
        for (var headNo = 1; headNo <= headCount; headNo++)
        {
            viewerParameters[$"H{headNo:00}_USE"] = "ON";
        }

        return viewerParameters;
    }

    private static ST_CORRECTION_OFFSET_SHOT_ITEM CreateOutputViewerShotItem(ST_HEAD_SHOT_POINT shot)
    {
        var shotName = CReviewShotNameFormatter.ToMatrixName(shot.CellShotNo, shot.GroupCountX);
        return new ST_CORRECTION_OFFSET_SHOT_ITEM(
            shot.ShotKey,
            shotName,
            shot.HeadNo > 0 ? $"H{shot.HeadNo:00}" : "-",
            FormatOffsetPair(shot.RecipeOffsetX, shot.RecipeOffsetY),
            FormatOffsetPair(shot.ReviewOffsetX, shot.ReviewOffsetY),
            FormatOffsetPair(shot.HeadDefaultOffsetX, shot.HeadDefaultOffsetY),
            FormatOffsetPair(shot.FirstBeamOffsetX, shot.FirstBeamOffsetY),
            FormatOffsetPair(shot.FinalScannerOffsetX, shot.FinalScannerOffsetY))
        {
            AlignOffset = FormatOffsetPair(shot.AlignScannerOffsetX, shot.AlignScannerOffsetY)
        };
    }

    private static int ReadOutputViewerInt(IReadOnlyDictionary<string, string> parameters, int defaultValue, params string[] keys)
    {
        foreach (var key in keys)
        {
            if (!parameters.TryGetValue(key, out var value))
            {
                continue;
            }

            if (int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var intResult))
            {
                return intResult;
            }

            if (double.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out var doubleResult))
            {
                return (int)Math.Round(doubleResult);
            }
        }

        return defaultValue;
    }

    private static double ReadOutputViewerDouble(IReadOnlyDictionary<string, string> parameters, double defaultValue, params string[] keys)
    {
        foreach (var key in keys)
        {
            if (!parameters.TryGetValue(key, out var value))
            {
                continue;
            }

            if (double.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out var result) && double.IsFinite(result))
            {
                return result;
            }
        }

        return defaultValue;
    }

    private static double? ReadOutputViewerNullableDouble(IReadOnlyDictionary<string, string> parameters, string key)
    {
        return parameters.TryGetValue(key, out var value) && double.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out var result) && double.IsFinite(result)
            ? result
            : null;
    }

    private static string FormatOutputViewerPreviewDouble(double value)
    {
        return value.ToString("0.###", CultureInfo.InvariantCulture);
    }

    private static string FormatOffsetPair(double x, double y)
    {
        return $"{FormatOffsetValue(x)} / {FormatOffsetValue(y)}";
    }

    private static string FormatOffsetValue(double value)
    {
        return value.ToString("+0.000;-0.000;0.000", CultureInfo.InvariantCulture);
    }

    private void Execute(object? parameter)
    {
        var command = parameter?.ToString()?.Trim().ToUpperInvariant();
        if (string.IsNullOrWhiteSpace(command))
        {
            return;
        }

        if (command == "CALCULATE")
        {
            if (!CRecipeConfirmDialog.ShowConfirmation("보정값 계산", "보정값을 계산하시겠습니까?"))
            {
                return;
            }
        }

        if (command == "APPLY")
        {
            if (!CRecipeConfirmDialog.ShowConfirmation("보정값 적용", "계산된 보정값을 적용하시겠습니까?"))
            {
                return;
            }
        }

        if (command == "SAVE")
        {
            var saveTitle = "보정값 저장";
            var saveMessage = "적용된 보정값을 저장하시겠습니까?";
            if (!CRecipeConfirmDialog.ShowConfirmation(saveTitle, saveMessage))
            {
                return;
            }
        }

        _statusReporter($"Correction {command} requested. Tab={_selectedTab}.");
    }

    private void ApplyTabData(string selectedTab)
    {
        global::Drilling.UI.Menu.Menus.ST_CORRECTION_TAB BuildCORRECTION_TAB(string tab)
        {
            return new ST_CORRECTION_TAB(tab, tab.Equals(selectedTab, StringComparison.OrdinalIgnoreCase));
        }

        Tabs = CorrectionTabs.Select(BuildCORRECTION_TAB).ToArray();
        (SummaryItems, SourceRows, CandidateRows, ApplyRows, DetailItems, HistoryRows) = selectedTab switch
        {
            "ALIGN/DISTORTION" or "REVIEW" => ([], [], [], [], [], []),
            "APC / ICR" => CreateApcIcrData(),
            "VIEWER / HISTORY" => CreateOutputHistoryData(),
            _ => ([], [], [], [], [], [])};
        OnPropertyChanged(nameof(Tabs));
        OnPropertyChanged(nameof(IsAlignDistortionTab));
        OnPropertyChanged(nameof(IsReviewCorrectionTab));
        OnPropertyChanged(nameof(IsCorrectionCommandsVisible));
        OnPropertyChanged(nameof(IsOtherCorrectionTab));
        OnPropertyChanged(nameof(IsOutputHistoryTab));
        OnPropertyChanged(nameof(SelectedTab));
        OnPropertyChanged(nameof(Title));
        OnPropertyChanged(nameof(Subtitle));
    }

    private async Task LoadReviewResult()
    {
        var dialog = new OpenFileDialog
        {
            Title = "Load Review Result",
            Filter = "Review Result CSV (*.csv)|*.csv|All Files (*.*)|*.*",
            CheckFileExists = true,
            Multiselect = false,
            InitialDirectory = Directory.Exists(_reviewResultFile.RootPath) ? _reviewResultFile.RootPath : AppContext.BaseDirectory
        };
        if (dialog.ShowDialog() != true)
        {
            _statusReporter("Review Result load canceled.");
            return;
        }

        await LoadReviewResultFile(
            dialog.FileName,
            showCompletionDialog: true,
            confirmRecipeMismatch: true);
    }

    private async Task<bool> LoadReviewResultFile(
        string filePath,
        bool showCompletionDialog = false,
        bool confirmRecipeMismatch = false)
    {
        try
        {
            var result = await _reviewResultFile.Load(filePath);
            var recipeMismatch = HasSelectedRecipeMismatch(result);
            if (recipeMismatch)
            {
                if (!confirmRecipeMismatch)
                {
                    throw CreateRecipeMismatchException(result);
                }

                var selectedRecipeId = NormalizeRecipeId(_selectedRecipeIdProvider());
                if (!CRecipeConfirmDialog.ShowConfirmation(
                        "Recipe 불일치",
                        $"현재 Recipe: {selectedRecipeId}\nReview Result Recipe: {NormalizeRecipeId(result.RecipeId)}\n\nRecipe가 서로 다릅니다. 조회하시겠습니까?",
                        "조회"))
                {
                    _statusReporter("Review Result load canceled because the Recipe does not match.");
                    return false;
                }
            }

            _loadedReviewResult = result;
            var settingState = await LoadCurrentSettingState(GetReviewResultHeadNos(result));
            _currentSettingState = settingState.Summary;
            _currentSettingDetail = settingState.Detail;
            _currentVisionSettingState = settingState.Vision;
            _currentScannerSettingState = settingState.Scanner;
            CurrentVisionFlipRow = settingState.VisionRow;
            CurrentScannerFlipRows = settingState.ScannerRows;
            _currentReviewOffsetRecipeName = "Recipe: -";
            ReviewResultRows = result.Rows.Select(row => new ST_CORRECTION_REVIEW_RESULT_ROW(row.ShotKey, $"H{row.HeadNo:00}", row.CellNo, row.ErrorX, row.ErrorY, row.Judge)).ToArray();
            string? offsetLoadWarning = null;
            try
            {
                CurrentOffsetRows = await LoadCurrentReviewOffsets(result);
            }
            catch (Exception exception)
            {
                CurrentOffsetRows = [];
                offsetLoadWarning = exception.Message;
            }

            CalculatedOffsetRows = [];
            ApplyPreviewRows = [];
            _calculatedSettingDetail = "";
            _hasPendingReviewOffsetApply = false;
            _reviewLoadStatus = recipeMismatch
                ? $"{result.Rows.Count} rows loaded. Recipe mismatch: view only."
                : offsetLoadWarning is null
                    ? $"{result.Rows.Count} rows loaded."
                    : $"{result.Rows.Count} rows loaded. Current Review Offset unavailable: {offsetLoadWarning}";
            _reviewLoadState = recipeMismatch || offsetLoadWarning is not null ? "WARN" : "OK";
            _reviewDataHistory.Insert(0, new ST_CORRECTION_HISTORY_ROW(DateTime.Now.ToString("HH:mm:ss", CultureInfo.InvariantCulture), Environment.UserName, "REVIEW DATA", result.FileName, "-", $"{result.Rows.Count} Rows", "Loaded"));
            ApplyTabData(_selectedTab);
            _statusReporter($"Review Result loaded: {result.FileName} / {result.Rows.Count} rows.");
            await _refreshCurrentScreen();
            if (showCompletionDialog)
            {
                CRecipeConfirmDialog.ShowCompletion("검사 결과 불러오기 완료", $"{result.FileName} 파일을 불러왔습니다.");
            }

            return true;
        }
        catch (Exception exception)
        {
            var message = $"Review Result load failed: {exception.Message}";
            _reviewLoadStatus = message;
            _reviewLoadState = "NG";
            _reviewDataHistory.Insert(0, new ST_CORRECTION_HISTORY_ROW(DateTime.Now.ToString("HH:mm:ss", CultureInfo.InvariantCulture), Environment.UserName, "REVIEW DATA", Path.GetFileName(filePath), "-", "Not Loaded", "NG"));
            ApplyTabData(_selectedTab);
            _statusReporter(message);
            await _refreshCurrentScreen();
            return false;
        }
    }

    private async Task CalculateReviewOffsets(bool replacePendingApply = false)
    {
        if (_loadedReviewResult is null)
        {
            await ReportReviewDataCommand("Calculate", "Load a Review Result CSV before calculating.", "WARN");
            return;
        }

        if (HasSelectedRecipeMismatch(_loadedReviewResult))
        {
            await ReportReviewDataCommand(
                "Calculate",
                "Review Result Recipe와 현재 Recipe가 다릅니다. 조회만 가능하며 계산하려면 같은 Recipe를 선택해 주세요.",
                "WARN");
            return;
        }

        if (_hasPendingReviewOffsetApply)
        {
            if (!replacePendingApply)
            {
                await ReportReviewDataCommand("Calculate", "Review Offsets are pending save. Save or load the Review Result again before recalculating.", "WARN");
                return;
            }

            _hasPendingReviewOffsetApply = false;
            ApplyPreviewRows = [];
        }

        _isReviewOperationRunning = true;
        ExecuteCommand.NotifyCanExecuteChanged();
        _reviewLoadStatus = "Calculating Review Offsets...";
        _reviewLoadState = "WAIT";
        ApplyTabData(_selectedTab);
        NotifyReviewDataPropertiesChanged();
        _statusReporter(_reviewLoadStatus);

        try
        {
            var result = _loadedReviewResult;
            var recipe = await LoadReviewResultRecipe(_loadedReviewResult);
            // Plan construction materializes the process coordinate plan and can
            // project thousands of Review points. Keep it off the dispatcher so
            // the Correction screen remains responsive while Calculate runs.
            var correctionRows = await Task.Run(() => CreateCorrectionRows(result, recipe));
            var flipType = await LoadCurrentVisionFlipType();
            var scannerAxisTransforms = LoadCurrentScannerAxisTransforms(
                GetCorrectionHeadNos(correctionRows));
            _currentVisionSettingState = FormatVisionFlipSummary(flipType);
            _currentScannerSettingState = FormatScannerSettingSummary(scannerAxisTransforms);
            _currentSettingState = FormatAxisSettingSummary(_currentVisionSettingState, _currentScannerSettingState);
            _currentSettingDetail = FormatAxisSettingDetail(flipType, scannerAxisTransforms);
            CurrentVisionFlipRow = CreateVisionFlipRow(flipType);
            CurrentScannerFlipRows = CreateScannerFlipRows(scannerAxisTransforms);
            var currentReviewOffsetFile = await _reviewOffsetFile.LoadLatest(recipe.Id);
            _currentReviewOffsetRecipeName = FormatReviewOffsetSource(recipe.Id, currentReviewOffsetFile);
            var offsetParameters = BuildOutputViewerParameterMap(recipe, LoadSimpleOffsetSettings());
            var calculation = await Task.Run(() =>
            {
                var currentRows = CreateCurrentReviewOffsets(currentReviewOffsetFile, correctionRows, offsetParameters);
                var calculatedRows = new List<ST_CORRECTION_REVIEW_OFFSET_ROW>(correctionRows.Count);
                foreach (var row in correctionRows)
                {
                    var shotKey = NormalizeReviewShotKey(row.ShotKey, row.CellNo);
                    var calculated = CReviewCoordinateTransformer.VisionErrorToScannerOffset(
                        row.ErrorX,
                        row.ErrorY,
                        flipType,
                        scannerAxisTransforms[row.HeadNo]);
                    var judge = row.Judge.Equals("NG", StringComparison.OrdinalIgnoreCase) ? "NG" : "OK";
                    calculatedRows.Add(new ST_CORRECTION_REVIEW_OFFSET_ROW(
                        shotKey,
                        $"H{row.HeadNo:00}",
                        calculated.X,
                        calculated.Y,
                        judge));
                }

                return (CurrentRows: currentRows, CalculatedRows: calculatedRows);
            });

            CurrentOffsetRows = calculation.CurrentRows;
            CalculatedOffsetRows = calculation.CalculatedRows;
            ApplyPreviewRows = [];
            _calculatedSettingDetail = _currentSettingDetail;
            await ReportReviewDataCommand("Calculate", $"{calculation.CalculatedRows.Count} Review Offsets calculated. Select Apply to create Apply Preview.", "OK", $"{_currentSettingState} / {calculation.CalculatedRows.Count} Rows");
        }
        catch (Exception exception)
        {
            CalculatedOffsetRows = [];
            ApplyPreviewRows = [];
            _calculatedSettingDetail = "";
            await ReportReviewDataCommand("Calculate", $"Review Offset calculation failed: {exception.Message}", "NG");
        }
        finally
        {
            _isReviewOperationRunning = false;
            ExecuteCommand.NotifyCanExecuteChanged();
        }
    }

    private async Task ApplyReviewOffsets()
    {
        if (_loadedReviewResult is null)
        {
            await ReportReviewDataCommand("Apply", "Load and calculate a Review Result before applying.", "WARN");
            return;
        }

        if (CalculatedOffsetRows.Count == 0)
        {
            await ReportReviewDataCommand("Apply", "Calculate the Review Offsets before applying.", "WARN");
            return;
        }

        if (HasSelectedRecipeMismatch(_loadedReviewResult))
        {
            await ReportReviewDataCommand(
                "Apply",
                "Review Result Recipe와 현재 Recipe가 다릅니다. 보정값을 적용할 수 없습니다.",
                "WARN");
            return;
        }

        ST_CORRECTION_AXIS_SETTING_STATE currentSettingState;
        try
        {
            currentSettingState = await LoadCurrentSettingState(
                GetReviewResultHeadNos(_loadedReviewResult));
        }
        catch (Exception exception)
        {
            await ReportReviewDataCommand(
                "Apply",
                $"현재 Flip 설정을 확인하지 못했습니다: {exception.Message}",
                "NG");
            return;
        }

        var flipSettingsChanged = !_calculatedSettingDetail.Equals(
            currentSettingState.Detail,
            StringComparison.Ordinal);
        if (flipSettingsChanged)
        {
            ApplyCurrentSettingState(currentSettingState);
            if (!CRecipeConfirmDialog.ShowConfirmation(
                    "Flip 설정 변경 확인",
                    "Calculate 이후 Vision 또는 Scanner Flip 설정이 변경되었습니다.\n변경된 Flip 설정으로 다시 계산한 뒤 적용하시겠습니까?",
                    "재계산 후 적용"))
            {
                await ReportReviewDataCommand(
                    "Apply",
                    "Flip 설정 변경으로 적용을 취소했습니다. 기존 계산값은 적용되지 않았습니다.",
                    "WARN");
                return;
            }

            await CalculateReviewOffsets(replacePendingApply: true);
            if (CalculatedOffsetRows.Count == 0 ||
                !_calculatedSettingDetail.Equals(currentSettingState.Detail, StringComparison.Ordinal))
            {
                return;
            }
        }
        else if (!CRecipeConfirmDialog.ShowConfirmation(
                     "보정값 적용",
                     "계산된 보정값을 적용하시겠습니까?"))
        {
            return;
        }

        if (CalculatedOffsetRows.Count != CurrentOffsetRows.Count)
        {
            await ReportReviewDataCommand("Apply", $"Current Review Offset is incomplete: {CurrentOffsetRows.Count}/{CalculatedOffsetRows.Count} rows.", "NG");
            return;
        }

        string SelectShotKey(global::Drilling.UI.Menu.Menus.ST_CORRECTION_REVIEW_OFFSET_ROW row)
        {
            return row.ShotKey;
        }

        var currentKeys = CurrentOffsetRows.Select(SelectShotKey).ToHashSet(StringComparer.OrdinalIgnoreCase);
        bool MatchesItem(global::Drilling.UI.Menu.Menus.ST_CORRECTION_REVIEW_OFFSET_ROW row)
        {
            return !currentKeys.Contains(row.ShotKey);
        }

        if (CalculatedOffsetRows.Any(MatchesItem))
        {
            await ReportReviewDataCommand("Apply", "Calculated Review Offset contains a Shot that is not present in the current Review Offsets.", "NG");
            return;
        }

        string SelectShotKey2(global::Drilling.UI.Menu.Menus.ST_CORRECTION_REVIEW_OFFSET_ROW row)
        {
            return row.ShotKey;
        }

        string SelectKey(global::System.Linq.IGrouping<string, global::Drilling.UI.Menu.Menus.ST_CORRECTION_REVIEW_OFFSET_ROW> group)
        {
            return group.Key;
        }

        global::Drilling.UI.Menu.Menus.ST_CORRECTION_REVIEW_OFFSET_ROW SelectValue(global::System.Linq.IGrouping<string, global::Drilling.UI.Menu.Menus.ST_CORRECTION_REVIEW_OFFSET_ROW> group)
        {
            return group.Last();
        }

        var currentOffsets = CurrentOffsetRows.GroupBy(SelectShotKey2, StringComparer.OrdinalIgnoreCase).ToDictionary(SelectKey, SelectValue, StringComparer.OrdinalIgnoreCase);
        global::Drilling.UI.Menu.Menus.ST_CORRECTION_REVIEW_OFFSET_ROW SelectItem(global::Drilling.UI.Menu.Menus.ST_CORRECTION_REVIEW_OFFSET_ROW row)
        {
            var current = currentOffsets[row.ShotKey];
            var preview = row with
            {
                OffsetXValue = current.OffsetXValue + row.OffsetXValue,
                OffsetYValue = current.OffsetYValue + row.OffsetYValue
            };
            return preview with
            {
                State = HasOffsetChanged(current, preview) ? "PENDING" : "CURRENT"
            };
        }

        ApplyPreviewRows = CalculatedOffsetRows.Select(SelectItem).ToArray();
        bool MatchesItem2(global::Drilling.UI.Menu.Menus.ST_CORRECTION_REVIEW_OFFSET_ROW row)
        {
            return row.State.Equals("PENDING", StringComparison.OrdinalIgnoreCase);
        }

        _hasPendingReviewOffsetApply = ApplyPreviewRows.Any(MatchesItem2);
        if (!_hasPendingReviewOffsetApply)
        {
            await ReportReviewDataCommand("Apply", "There are no Review Offset changes to apply.", "OK", "0 Rows / No Change");
            return;
        }

        bool MatchesState(global::Drilling.UI.Menu.Menus.ST_CORRECTION_REVIEW_OFFSET_ROW row)
        {
            return row.State.Equals("PENDING", StringComparison.OrdinalIgnoreCase);
        }

        bool MatchesState2(global::Drilling.UI.Menu.Menus.ST_CORRECTION_REVIEW_OFFSET_ROW row)
        {
            return row.State.Equals("PENDING", StringComparison.OrdinalIgnoreCase);
        }

        await ReportReviewDataCommand("Apply", $"{ApplyPreviewRows.Count(MatchesState)} calculated values are shown in Apply Preview. Save is required.", "WARN", $"{ApplyPreviewRows.Count(MatchesState2)} Rows / Pending Save");
    }

    private async Task SaveAppliedReviewOffsets()
    {
        if (_loadedReviewResult is null)
        {
            await ReportReviewDataCommand("Save", "Apply the calculated Review Offsets before saving.", "WARN");
            return;
        }

        if (HasSelectedRecipeMismatch(_loadedReviewResult))
        {
            await ReportReviewDataCommand(
                "Save",
                "Review Result Recipe와 현재 Recipe가 다릅니다. 보정값을 저장할 수 없습니다.",
                "WARN");
            return;
        }

        if (!_hasPendingReviewOffsetApply)
        {
            await ReportReviewDataCommand("Save", "Apply the calculated Review Offsets before saving.", "WARN");
            return;
        }

        bool MatchesState(global::Drilling.UI.Menu.Menus.ST_CORRECTION_REVIEW_OFFSET_ROW row)
        {
            return row.State.Equals("PENDING", StringComparison.OrdinalIgnoreCase);
        }

        global::Drilling.UI.Menu.Menus.ST_CORRECTION_REVIEW_OFFSET_ROW SelectValue(global::Drilling.UI.Menu.Menus.ST_CORRECTION_REVIEW_OFFSET_ROW row)
        {
            return row with
            {
                State = row.State.Equals("PENDING", StringComparison.OrdinalIgnoreCase) ? "SAVED" : row.State
            };
        }

        global::Drilling.UI.Menu.Menus.ST_CORRECTION_REVIEW_OFFSET_ROW SelectCORRECTION_REVIEW_OFFSET_ROW(global::Drilling.UI.Menu.Menus.ST_CORRECTION_REVIEW_OFFSET_ROW row)
        {
            return row with
            {
                State = "CURRENT"
            };
        }

        var pendingRows = ApplyPreviewRows.Where(MatchesState).ToArray();
        if (pendingRows.Length == 0)
        {
            _hasPendingReviewOffsetApply = false;
            await ReportReviewDataCommand("Save", "There are no pending Review Offsets to save.", "OK", "0 Rows / No Change");
            return;
        }

        _isReviewOperationRunning = true;
        ExecuteCommand.NotifyCanExecuteChanged();
        _reviewLoadStatus = "Saving Review Offsets...";
        _reviewLoadState = "WAIT";
        ApplyTabData(_selectedTab);
        NotifyReviewDataPropertiesChanged();
        _statusReporter(_reviewLoadStatus);

        try
        {
            var selectedRecipeId = NormalizeRecipeId(_selectedRecipeIdProvider());
            if (string.IsNullOrWhiteSpace(selectedRecipeId))
            {
                selectedRecipeId = NormalizeRecipeId(_loadedReviewResult.RecipeId);
            }

            var latestOffsets = await _reviewOffsetFile.LoadLatest(selectedRecipeId);
            var offsetRecipe = await LoadReviewResultRecipe(_loadedReviewResult);
            var offsetParameters = BuildOutputViewerParameterMap(offsetRecipe, LoadSimpleOffsetSettings());
            var savedOffsetFile = await Task.Run(() =>
            {
                var mergedRows = MergeReviewOffsetRows(latestOffsets.Rows, ApplyPreviewRows, offsetParameters);
                return _reviewOffsetFile
                    .SaveNew(selectedRecipeId, mergedRows)
                    .GetAwaiter()
                    .GetResult();
            });

            ApplyPreviewRows = ApplyPreviewRows.Select(SelectValue).ToArray();
            CurrentOffsetRows = ApplyPreviewRows.Select(SelectCORRECTION_REVIEW_OFFSET_ROW).ToArray();
            _hasPendingReviewOffsetApply = false;
            _currentReviewOffsetRecipeName = FormatReviewOffsetSource(selectedRecipeId, savedOffsetFile);
            await ReportReviewDataCommand("Save", $"{pendingRows.Length} Review Offsets saved to {savedOffsetFile.FileName}.", "OK", $"{savedOffsetFile.FileName} / {savedOffsetFile.Rows.Count} Rows");
            CRecipeConfirmDialog.ShowCompletion("Review Offset 저장 완료", $"{savedOffsetFile.FileName} 파일에 Review Offset을 저장하였습니다.");
        }
        catch (Exception exception)
        {
            await ReportReviewDataCommand("Save", $"Review Offset save failed: {exception.Message}", "NG");
        }
        finally
        {
            _isReviewOperationRunning = false;
            ExecuteCommand.NotifyCanExecuteChanged();
        }
    }

    private static bool HasOffsetChanged(ST_CORRECTION_REVIEW_OFFSET_ROW before, ST_CORRECTION_REVIEW_OFFSET_ROW after)
    {
        const double comparisonTolerance = 0.0000005;
        return Math.Abs(before.OffsetXValue - after.OffsetXValue) >= comparisonTolerance || Math.Abs(before.OffsetYValue - after.OffsetYValue) >= comparisonTolerance;
    }

    private Task ReportReviewDataCommand(string item, string message, string result, string? historyAfter = null)
    {
        _reviewLoadStatus = message;
        _reviewLoadState = result;
        _reviewDataHistory.Insert(0, new ST_CORRECTION_HISTORY_ROW(DateTime.Now.ToString("HH:mm:ss", CultureInfo.InvariantCulture), Environment.UserName, "REVIEW DATA", item, LoadedReviewFileName, historyAfter ?? message, result));
        ApplyTabData(_selectedTab);
        _statusReporter(message);
        NotifyReviewDataPropertiesChanged();
        return Task.CompletedTask;
    }

    private void NotifyReviewDataPropertiesChanged()
    {
        OnPropertyChanged(nameof(SummaryItems));
        OnPropertyChanged(nameof(SourceRows));
        OnPropertyChanged(nameof(CandidateRows));
        OnPropertyChanged(nameof(ApplyRows));
        OnPropertyChanged(nameof(DetailItems));
        OnPropertyChanged(nameof(HistoryRows));
        OnPropertyChanged(nameof(ReviewResultRows));
        OnPropertyChanged(nameof(CalculatedOffsetRows));
        OnPropertyChanged(nameof(CurrentOffsetRows));
        OnPropertyChanged(nameof(ApplyPreviewRows));
        OnPropertyChanged(nameof(CurrentVisionFlipRow));
        OnPropertyChanged(nameof(CurrentScannerFlipRows));
        OnPropertyChanged(nameof(LoadedReviewFileName));
        OnPropertyChanged(nameof(LoadedReviewSettingSummary));
        OnPropertyChanged(nameof(LoadedReviewRule));
        OnPropertyChanged(nameof(LoadedReviewSettingDetail));
        OnPropertyChanged(nameof(ReviewLoadStatus));
        OnPropertyChanged(nameof(ReviewLoadStatusBrush));
        OnPropertyChanged(nameof(CurrentSettingState));
        OnPropertyChanged(nameof(CurrentSettingDetail));
        OnPropertyChanged(nameof(CurrentVisionSettingState));
        OnPropertyChanged(nameof(CurrentScannerSettingState));
        OnPropertyChanged(nameof(CurrentReviewOffsetRecipeName));
    }

    private async Task<IReadOnlyList<ST_CORRECTION_REVIEW_OFFSET_ROW>> LoadCurrentReviewOffsets(ST_REVIEW_RESULT_FILE_DATA result)
    {
        var recipe = await LoadReviewResultRecipe(result);
        var reviewOffsetFile = await _reviewOffsetFile.LoadLatest(recipe.Id);
        _currentReviewOffsetRecipeName = FormatReviewOffsetSource(recipe.Id, reviewOffsetFile);
        var offsetValues = CreateReviewOffsetLookup(reviewOffsetFile.Rows);
        var parameters = BuildOutputViewerParameterMap(recipe, LoadSimpleOffsetSettings());
        var rows = new List<ST_CORRECTION_REVIEW_OFFSET_ROW>(result.Rows.Count);
        foreach (var row in result.Rows)
        {
            var shotKey = NormalizeReviewShotKey(row.ShotKey, row.CellNo);
            var saved = offsetValues.GetValueOrDefault(shotKey);
            var offset = saved is null ? (0.0, 0.0)
                : CReviewOffsetData.ToScanner(parameters, row.HeadNo, saved.ReviewOffsetX, saved.ReviewOffsetY, saved.IsDesignCoordinate);
            rows.Add(new ST_CORRECTION_REVIEW_OFFSET_ROW(
                shotKey,
                $"H{row.HeadNo:00}",
                offset.Item1,
                offset.Item2,
                "CURRENT"));
        }

        return rows;
    }

    private async Task<ST_RECIPE_DEFINITION> LoadReviewResultRecipe(ST_REVIEW_RESULT_FILE_DATA result)
    {
        var reviewRecipeId = NormalizeRecipeId(result.RecipeId);

        bool MatchesItem(global::Drilling.Common.Managers.ST_RECIPE_DEFINITION item)
        {
            return NormalizeRecipeId(item.Id).Equals(reviewRecipeId, StringComparison.OrdinalIgnoreCase);
        }

        var recipe = (await _recipeManager.LoadRecipes()).FirstOrDefault(MatchesItem);
        if (recipe is null)
        {
            throw new InvalidOperationException($"Review Result recipe could not be loaded: {reviewRecipeId}.");
        }

        return recipe;
    }

    private IReadOnlyList<ST_REVIEW_PLAN_POINT> CreateCorrectionRows(
        ST_REVIEW_RESULT_FILE_DATA result,
        ST_RECIPE_DEFINITION recipe)
    {
        var beamNo = Math.Max(1, result.BeamNo);
        var requestedShotKeys = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var row in result.Rows)
        {
            requestedShotKeys.Add(NormalizeReviewShotKey(row.ShotKey, row.CellNo));
        }

        var allPlan = _reviewManager.CreateAllPlan(recipe, beamNo);
        var sourceByShotKey = new Dictionary<string, ST_REVIEW_PLAN_POINT>(StringComparer.OrdinalIgnoreCase);
        foreach (var point in allPlan.Points)
        {
            var numericShotKey = NormalizeReviewShotKey(point.ShotKey, point.CellNo);
            var displayShotKey = NormalizeReviewShotKey(
                $"CELL{point.CellNo}_{FormatReviewShotName(point)}",
                point.CellNo);
            if (requestedShotKeys.Contains(numericShotKey))
            {
                sourceByShotKey[numericShotKey] = point;
            }

            if (requestedShotKeys.Contains(displayShotKey))
            {
                sourceByShotKey[displayShotKey] = point;
            }

            if (sourceByShotKey.Count == requestedShotKeys.Count)
            {
                break;
            }
        }

        var measuredRows = new List<ST_REVIEW_PLAN_POINT>(result.Rows.Count);
        foreach (var row in result.Rows)
        {
            var shotKey = NormalizeReviewShotKey(row.ShotKey, row.CellNo);
            if (!sourceByShotKey.TryGetValue(shotKey, out var sourcePoint))
            {
                throw new InvalidDataException($"Review Result Shot is not present in the selected Recipe: {shotKey}.");
            }

            if (sourcePoint.HeadNo != row.HeadNo)
            {
                throw new InvalidDataException(
                    $"Review Result Head does not match the selected Recipe: {shotKey} / File=H{row.HeadNo:00}, Recipe=H{sourcePoint.HeadNo:00}.");
            }

            var isNg = row.Judge.Equals("NG", StringComparison.OrdinalIgnoreCase);
            measuredRows.Add(sourcePoint with
            {
                Use = true,
                BeamNo = beamNo,
                ErrorX = row.ErrorX,
                ErrorY = row.ErrorY,
                State = isNg ? EN_REVIEW_POINT_STATE.Ng : EN_REVIEW_POINT_STATE.Ok,
                Judge = isNg ? "NG" : "OK"
            });
        }

        var rule = ParseCorrectionRule(result.Rule);
        if (rule is null)
        {
            return UseDisplayShotKeys(measuredRows);
        }

        var scope = result.RuleScope.Equals("HEAD_CELL", StringComparison.OrdinalIgnoreCase)
            ? EN_REVIEW_CORRECTION_SCOPE.HeadCell
            : EN_REVIEW_CORRECTION_SCOPE.Head;
        var roughReference = ParseRoughReference(result.RoughReference);
        var reviewCorrectionPlan = new ST_REVIEW_CORRECTION_PLAN(
            rule.Value,
            scope,
            allPlan.Points,
            roughReference,
            result.FineLineCount);
        var correctionPlan = allPlan with
        {
            Points = measuredRows,
            CorrectionPlan = reviewCorrectionPlan
        };
        return UseDisplayShotKeys(
            CReviewManager.ProjectCorrectionRows(correctionPlan, measuredRows));
    }

    private static IReadOnlyList<ST_REVIEW_PLAN_POINT> UseDisplayShotKeys(
        IReadOnlyList<ST_REVIEW_PLAN_POINT> rows)
    {
        var displayRows = new List<ST_REVIEW_PLAN_POINT>(rows.Count);
        foreach (var row in rows)
        {
            displayRows.Add(row with
            {
                ShotKey = $"CELL{row.CellNo}_{FormatReviewShotName(row)}"
            });
        }

        return displayRows;
    }

    private static EN_REVIEW_CORRECTION_RULE? ParseCorrectionRule(string rule)
    {
        if (rule.Equals("SIMPLE", StringComparison.OrdinalIgnoreCase))
        {
            return EN_REVIEW_CORRECTION_RULE.Simple;
        }

        if (rule.Equals("ROUGH", StringComparison.OrdinalIgnoreCase))
        {
            return EN_REVIEW_CORRECTION_RULE.Rough;
        }

        if (rule.Equals("FINE", StringComparison.OrdinalIgnoreCase))
        {
            return EN_REVIEW_CORRECTION_RULE.Fine;
        }

        if (rule.Equals("EDGE", StringComparison.OrdinalIgnoreCase))
        {
            return EN_REVIEW_CORRECTION_RULE.Edge;
        }

        return null;
    }

    private static EN_REVIEW_REFERENCE_LINE ParseRoughReference(string reference)
    {
        if (reference.Equals("CENTER", StringComparison.OrdinalIgnoreCase))
        {
            return EN_REVIEW_REFERENCE_LINE.Center;
        }

        if (reference.Equals("LAST", StringComparison.OrdinalIgnoreCase))
        {
            return EN_REVIEW_REFERENCE_LINE.Last;
        }

        return EN_REVIEW_REFERENCE_LINE.First;
    }

    private static IReadOnlyList<ST_CORRECTION_REVIEW_OFFSET_ROW> CreateCurrentReviewOffsets(
        ST_REVIEW_OFFSET_FILE_DATA reviewOffsetFile,
        IReadOnlyList<ST_REVIEW_PLAN_POINT> correctionRows,
        IReadOnlyDictionary<string, string> parameters)
    {
        var offsetValues = CreateReviewOffsetLookup(reviewOffsetFile.Rows);
        var rows = new List<ST_CORRECTION_REVIEW_OFFSET_ROW>(correctionRows.Count);
        foreach (var point in correctionRows)
        {
            var shotKey = NormalizeReviewShotKey(point.ShotKey, point.CellNo);
            var saved = offsetValues.GetValueOrDefault(shotKey);
            var offset = saved is null ? (0.0, 0.0)
                : CReviewOffsetData.ToScanner(parameters, point.HeadNo, saved.ReviewOffsetX, saved.ReviewOffsetY, saved.IsDesignCoordinate);
            rows.Add(new ST_CORRECTION_REVIEW_OFFSET_ROW(
                shotKey,
                $"H{point.HeadNo:00}",
                offset.Item1,
                offset.Item2,
                "CURRENT"));
        }

        return rows;
    }

    private static IEnumerable<int> GetCorrectionHeadNos(
        IReadOnlyList<ST_REVIEW_PLAN_POINT> correctionRows)
    {
        foreach (var row in correctionRows)
        {
            yield return row.HeadNo;
        }
    }

    private async Task<ST_CORRECTION_AXIS_SETTING_STATE> LoadCurrentSettingState(IEnumerable<int> headNos)
    {
        var flipType = await LoadCurrentVisionFlipType();
        var scannerAxisTransforms = LoadCurrentScannerAxisTransforms(headNos);
        var vision = FormatVisionFlipSummary(flipType);
        var scanner = FormatScannerSettingSummary(scannerAxisTransforms);
        return new ST_CORRECTION_AXIS_SETTING_STATE(
            FormatAxisSettingSummary(vision, scanner),
            FormatAxisSettingDetail(flipType, scannerAxisTransforms),
            vision,
            scanner,
            CreateVisionFlipRow(flipType),
            CreateScannerFlipRows(scannerAxisTransforms));
    }

    private void ApplyCurrentSettingState(ST_CORRECTION_AXIS_SETTING_STATE settingState)
    {
        _currentSettingState = settingState.Summary;
        _currentSettingDetail = settingState.Detail;
        _currentVisionSettingState = settingState.Vision;
        _currentScannerSettingState = settingState.Scanner;
        CurrentVisionFlipRow = settingState.VisionRow;
        CurrentScannerFlipRows = settingState.ScannerRows;
    }

    private static ST_CORRECTION_AXIS_FLIP_ROW CreateVisionFlipRow(EN_VISION_FLIP_TYPE flipType)
    {
        return new ST_CORRECTION_AXIS_FLIP_ROW(
            "VISION",
            flipType.HasFlag(EN_VISION_FLIP_TYPE.XFlip),
            flipType.HasFlag(EN_VISION_FLIP_TYPE.YFlip),
            flipType.HasFlag(EN_VISION_FLIP_TYPE.XyFlip));
    }

    private static string FormatReviewSettingDetail(ST_REVIEW_RESULT_FILE_DATA? result)
    {
        if (result is null)
        {
            return "";
        }

        var rule = string.IsNullOrWhiteSpace(result.Rule) ? "ALL" : result.Rule.ToUpperInvariant();
        var parts = new List<string>();
        if (!string.IsNullOrWhiteSpace(result.RuleScope))
        {
            parts.Add(result.RuleScope.Replace("_", " + ", StringComparison.Ordinal));
        }

        if (rule == "SIMPLE")
        {
            var cell = result.ReferenceCellNo is null ? "Cell-" : $"Cell{result.ReferenceCellNo.Value}";
            var shot = string.IsNullOrWhiteSpace(result.ReferenceShot) ? "-" : result.ReferenceShot;
            parts.Add($"{cell} / {shot}");
        }
        else if (rule == "ROUGH" && !string.IsNullOrWhiteSpace(result.RoughReference))
        {
            parts.Add(result.RoughReference.ToUpperInvariant());
        }
        else if (rule == "FINE" && result.FineLineCount > 0)
        {
            parts.Add(result.FineLineCount == 1 ? "1 Line" : $"{result.FineLineCount} Lines");
        }

        parts.Add($"Beam{Math.Max(1, result.BeamNo)}");
        if (!string.IsNullOrWhiteSpace(result.InspectionMethod))
        {
            parts.Add(result.InspectionMethod.ToUpperInvariant());
        }

        return string.Join(" · ", parts);
    }

    private static IReadOnlyList<ST_CORRECTION_AXIS_FLIP_ROW> CreateScannerFlipRows(
        IReadOnlyDictionary<int, ST_SCANNER_AXIS_TRANSFORM> scannerAxisTransforms)
    {
        static int GetHeadNo(KeyValuePair<int, ST_SCANNER_AXIS_TRANSFORM> item)
        {
            return item.Key;
        }

        var rows = new List<ST_CORRECTION_AXIS_FLIP_ROW>(scannerAxisTransforms.Count);
        foreach (var item in scannerAxisTransforms.OrderBy(GetHeadNo))
        {
            rows.Add(new ST_CORRECTION_AXIS_FLIP_ROW(
                $"H{item.Key:00}",
                item.Value.XFlip,
                item.Value.YFlip,
                item.Value.XyFlip));
        }

        return rows;
    }

    private static IEnumerable<int> GetReviewResultHeadNos(ST_REVIEW_RESULT_FILE_DATA result)
    {
        foreach (var row in result.Rows)
        {
            yield return row.HeadNo;
        }
    }

    private static string FormatAxisSettingSummary(string vision, string scanner)
    {
        return $"Vision: {vision} | Scanner: {scanner}";
    }

    private static string FormatScannerSettingSummary(
        IReadOnlyDictionary<int, ST_SCANNER_AXIS_TRANSFORM> scannerAxisTransforms)
    {
        static int GetHeadNo(KeyValuePair<int, ST_SCANNER_AXIS_TRANSFORM> item)
        {
            return item.Key;
        }

        if (scannerAxisTransforms.Count == 0)
        {
            return "-";
        }

        var orderedTransforms = scannerAxisTransforms.OrderBy(GetHeadNo).ToArray();
        var groupedHeadNos = new Dictionary<ST_SCANNER_AXIS_TRANSFORM, List<int>>();
        foreach (var item in orderedTransforms)
        {
            if (!groupedHeadNos.TryGetValue(item.Value, out var headNos))
            {
                headNos = [];
                groupedHeadNos.Add(item.Value, headNos);
            }

            headNos.Add(item.Key);
        }

        var settingGroups = new List<string>();
        foreach (var group in groupedHeadNos)
        {
            settingGroups.Add($"{FormatHeadRange(group.Value)} · {FormatScannerFlipSummary(group.Key)}");
        }

        return string.Join("  /  ", settingGroups);
    }

    private static string FormatHeadRange(IReadOnlyList<int> headNos)
    {
        if (headNos.Count == 0)
        {
            return "-";
        }

        var ranges = new List<string>();
        var rangeStart = headNos[0];
        var rangeEnd = rangeStart;
        for (var index = 1; index < headNos.Count; index++)
        {
            var headNo = headNos[index];
            if (headNo == rangeEnd + 1)
            {
                rangeEnd = headNo;
                continue;
            }

            ranges.Add(FormatHeadRangePart(rangeStart, rangeEnd));
            rangeStart = headNo;
            rangeEnd = headNo;
        }

        ranges.Add(FormatHeadRangePart(rangeStart, rangeEnd));
        return string.Join(", ", ranges);
    }

    private static string FormatHeadRangePart(int rangeStart, int rangeEnd)
    {
        return rangeStart == rangeEnd
            ? $"H{rangeStart:00}"
            : $"H{rangeStart:00}-H{rangeEnd:00}";
    }

    private static string FormatVisionFlipSummary(EN_VISION_FLIP_TYPE flipType)
    {
        var items = new List<string>();
        if (flipType.HasFlag(EN_VISION_FLIP_TYPE.XFlip))
        {
            items.Add("X");
        }

        if (flipType.HasFlag(EN_VISION_FLIP_TYPE.YFlip))
        {
            items.Add("Y");
        }

        if (flipType.HasFlag(EN_VISION_FLIP_TYPE.XyFlip))
        {
            items.Add("XY");
        }

        return items.Count == 0 ? "OFF" : string.Join("+", items);
    }

    private static string FormatScannerFlipSummary(ST_SCANNER_AXIS_TRANSFORM transform)
    {
        var items = new List<string>();
        if (transform.XFlip)
        {
            items.Add("X");
        }

        if (transform.YFlip)
        {
            items.Add("Y");
        }

        if (transform.XyFlip)
        {
            items.Add("XY");
        }

        return items.Count == 0 ? "OFF" : string.Join("+", items);
    }

    private static string FormatAxisSettingDetail(
        EN_VISION_FLIP_TYPE visionFlipType,
        IReadOnlyDictionary<int, ST_SCANNER_AXIS_TRANSFORM> scannerAxisTransforms)
    {
        static int GetHeadNo(KeyValuePair<int, ST_SCANNER_AXIS_TRANSFORM> item)
        {
            return item.Key;
        }

        var lines = new List<string>
        {
            $"Vision Flip: {CReviewCoordinateTransformer.FormatVisionFlipType(visionFlipType)}",
            "Scanner Flip:"
        };
        foreach (var item in scannerAxisTransforms.OrderBy(GetHeadNo))
        {
            lines.Add($"H{item.Key:00}: {CScannerAxisTransform.Format(item.Value)}");
        }

        if (scannerAxisTransforms.Count == 0)
        {
            lines.Add("-");
        }

        return string.Join(Environment.NewLine, lines);
    }

    private Task<EN_VISION_FLIP_TYPE> LoadCurrentVisionFlipType()
    {
        var xFlipValue = _settingManager.GetValue(EN_SETTING_TAB.Option, "VisionXFlip", "");
        var yFlipValue = _settingManager.GetValue(EN_SETTING_TAB.Option, "VisionYFlip", "");
        var xyFlipValue = _settingManager.GetValue(EN_SETTING_TAB.Option, "VisionXyFlip", "");
        return Task.FromResult(CReviewCoordinateTransformer.ParseVisionFlipType(xFlipValue, yFlipValue, xyFlipValue));
    }

    private IReadOnlyDictionary<int, ST_SCANNER_AXIS_TRANSFORM> LoadCurrentScannerAxisTransforms(
        IEnumerable<int> headNos)
    {
        static int GetHeadNo(int headNo)
        {
            return headNo;
        }

        static bool IsInvalidHeadNo(int headNo)
        {
            return headNo is < 1 or > 8;
        }

        var distinctHeadNos = headNos.Distinct().OrderBy(GetHeadNo).ToArray();
        var invalidHeadNo = distinctHeadNos.FirstOrDefault(IsInvalidHeadNo);
        if (invalidHeadNo != 0)
        {
            throw new InvalidOperationException(
                $"Review Result Head number must be between 1 and 8. Current value: {invalidHeadNo}.");
        }

        var optionSettings = _settingManager.LoadSection(EN_SETTING_TAB.Option);
        const int firstHeadNo = 1;
        const int lastHeadNo = 8;
        var transforms = new Dictionary<int, ST_SCANNER_AXIS_TRANSFORM>(lastHeadNo);
        for (var headNo = firstHeadNo; headNo <= lastHeadNo; headNo++)
        {
            transforms[headNo] = CScannerAxisTransform.Read(optionSettings, headNo);
        }

        return transforms;
    }

    private bool HasSelectedRecipeMismatch(ST_REVIEW_RESULT_FILE_DATA result)
    {
        var selectedRecipeId = NormalizeRecipeId(_selectedRecipeIdProvider());
        if (string.IsNullOrWhiteSpace(selectedRecipeId))
        {
            return false;
        }

        return !selectedRecipeId.Equals(
            NormalizeRecipeId(result.RecipeId),
            StringComparison.OrdinalIgnoreCase);
    }

    private InvalidDataException CreateRecipeMismatchException(ST_REVIEW_RESULT_FILE_DATA result)
    {
        return new InvalidDataException(
            $"Review Result recipe mismatch. Selected={NormalizeRecipeId(_selectedRecipeIdProvider())}, File={result.RecipeId}.");
    }

    private (IReadOnlyList<ST_DISPLAY_ITEM> Summary, IReadOnlyList<ST_CORRECTION_SOURCE_ROW> Source, IReadOnlyList<ST_CORRECTION_VALUE_ROW> Candidate, IReadOnlyList<ST_CORRECTION_VALUE_ROW> Apply, IReadOnlyList<ST_DISPLAY_ITEM> Detail, IReadOnlyList<ST_CORRECTION_HISTORY_ROW> History) CreateReviewData()
    {
        var result = _loadedReviewResult;
        bool MatchesJudge(global::Drilling.Common.Review.ST_REVIEW_RESULT_FILE_ROW row)
        {
            return row.Judge.Equals("NG", StringComparison.OrdinalIgnoreCase);
        }

        var ngCount = result?.Rows.Count(MatchesJudge) ?? 0;
        return ([new("Review Result", result?.FileName ?? "Not Loaded"), new("Shot Count", result?.Rows.Count.ToString(CultureInfo.InvariantCulture) ?? "0"), new("NG Count", ngCount.ToString(CultureInfo.InvariantCulture), ngCount > 0 ? "WARN" : "OK"), new("Recipe", result?.RecipeId ?? NormalizeRecipeId(_selectedRecipeIdProvider()))], [], [], [], [], _reviewDataHistory.ToArray());
    }

    private static string NormalizeRecipeId(string value)
    {
        return Path.GetFileNameWithoutExtension(value?.Trim() ?? "");
    }

    private static string NormalizeReviewShotKey(string value, int cellNo)
    {
        var normalized = (value ?? "").Trim().Replace("-", "_", StringComparison.Ordinal).Replace(".", "_", StringComparison.Ordinal).ToUpperInvariant();
        return normalized.StartsWith("CELL", StringComparison.Ordinal) ? normalized : $"CELL{cellNo}_{normalized}";
    }

    private static string FormatReviewOffsetSource(string recipeId, ST_REVIEW_OFFSET_FILE_DATA reviewOffsetFile)
    {
        var normalizedRecipeId = NormalizeRecipeId(recipeId);
        return string.IsNullOrWhiteSpace(reviewOffsetFile.FileName)
            ? $"{normalizedRecipeId}_reviewoffset / NONE"
            : $"{normalizedRecipeId}_reviewoffset / {reviewOffsetFile.FileName}";
    }

    private static IReadOnlyDictionary<string, ST_REVIEW_OFFSET_ROW> CreateReviewOffsetLookup(
        IReadOnlyList<ST_REVIEW_OFFSET_ROW> rows)
    {
        var values = new Dictionary<string, ST_REVIEW_OFFSET_ROW>(StringComparer.OrdinalIgnoreCase);
        foreach (var row in rows)
        {
            var shotId = NormalizeReviewOffsetShotId(row.ShotId);
            if (row.CellId <= 0 || string.IsNullOrWhiteSpace(shotId))
            {
                continue;
            }

            values[$"CELL{row.CellId}_{shotId}"] = row;
        }

        return values;
    }

    private static IReadOnlyList<ST_REVIEW_OFFSET_ROW> MergeReviewOffsetRows(
        IReadOnlyList<ST_REVIEW_OFFSET_ROW> currentRows,
        IReadOnlyList<ST_CORRECTION_REVIEW_OFFSET_ROW> appliedRows,
        IReadOnlyDictionary<string, string> parameters)
    {
        var rows = new Dictionary<string, ST_REVIEW_OFFSET_ROW>(StringComparer.OrdinalIgnoreCase);
        foreach (var row in currentRows)
        {
            var shotId = NormalizeReviewOffsetShotId(row.ShotId);
            if (row.CellId <= 0 || string.IsNullOrWhiteSpace(shotId))
            {
                continue;
            }

            rows[$"CELL{row.CellId}_{shotId}"] = row with
            {
                ShotId = shotId
            };
        }

        foreach (var row in appliedRows)
        {
            if (!TryParseReviewOffsetShotKey(row.ShotKey, out var cellId, out var shotId))
            {
                continue;
            }

            if (!int.TryParse(row.Head.Trim().TrimStart('H', 'h'), NumberStyles.Integer, CultureInfo.InvariantCulture, out var headNo) || headNo is < 1 or > 8)
                throw new InvalidOperationException($"Review Offset Head를 확인할 수 없습니다: {row.Head} / {row.ShotKey}");
            var design = CScannerAxisTransform.ScannerOffsetToDesign(parameters, headNo, row.OffsetXValue, row.OffsetYValue);
            rows[$"CELL{cellId}_{shotId}"] = new ST_REVIEW_OFFSET_ROW(
                cellId,
                shotId,
                design.X,
                design.Y) { IsDesignCoordinate = true };
        }

        return rows.Values
            .OrderBy(row => row.CellId)
            .ThenBy(row => row.ShotId, StringComparer.OrdinalIgnoreCase)
            .ToArray();
    }

    private static bool TryParseReviewOffsetShotKey(string value, out int cellId, out string shotId)
    {
        cellId = 0;
        shotId = "";
        var normalized = (value ?? "")
            .Trim()
            .Replace("-", "_", StringComparison.Ordinal)
            .Replace(".", "_", StringComparison.Ordinal)
            .ToUpperInvariant();
        if (!normalized.StartsWith("CELL", StringComparison.Ordinal))
        {
            return false;
        }

        var separatorIndex = normalized.IndexOf('_');
        if (separatorIndex <= 4 || separatorIndex >= normalized.Length - 1)
        {
            return false;
        }

        if (!int.TryParse(
                normalized[4..separatorIndex],
                NumberStyles.Integer,
                CultureInfo.InvariantCulture,
                out cellId))
        {
            return false;
        }

        shotId = NormalizeReviewOffsetShotId(normalized[(separatorIndex + 1)..]);
        return cellId > 0 && !string.IsNullOrWhiteSpace(shotId);
    }

    private static string NormalizeReviewOffsetShotId(string value)
    {
        return (value ?? "")
            .Trim()
            .Replace("-", "_", StringComparison.Ordinal)
            .Replace(".", "_", StringComparison.Ordinal)
            .ToUpperInvariant();
    }

    private static string FormatReviewShotName(ST_REVIEW_PLAN_POINT point)
    {
        return CReviewShotNameFormatter.ToMatrixName(point.ShotNo, point.PixelCountX);
    }

    private static (IReadOnlyList<ST_DISPLAY_ITEM> Summary, IReadOnlyList<ST_CORRECTION_SOURCE_ROW> Source, IReadOnlyList<ST_CORRECTION_VALUE_ROW> Candidate, IReadOnlyList<ST_CORRECTION_VALUE_ROW> Apply, IReadOnlyList<ST_DISPLAY_ITEM> Detail, IReadOnlyList<ST_CORRECTION_HISTORY_ROW> History) CreateAlignCompData()
    {
        return ([new("Align Result", "Ready"), new("Distortion Key", "6"), new("Theta", "+0.002 deg"), new("Weight", "X 0.80 / Y 0.80")], [new("Align", "Front Key", "X +0.012 / Y -0.006", "OK", "Vision PC"), new("Align", "Rear Key", "X +0.009 / Y -0.004", "OK", "Vision PC"), new("Distortion", "KEY 01-06", "6 point", "Ready", "Vision Result")], [new("Align X", "Weighted", "+0.010", "mm", "Ready"), new("Align Y", "Weighted", "-0.005", "mm", "Ready"), new("Align Theta", "Rotation", "+0.002", "deg", "Ready"), new("Distortion", "Max DA", "42.0", "um", "OK")], [new("X Start Weight", "Recipe", "0.80", "-", "Ready"), new("X End Weight", "Recipe", "0.80", "-", "Ready"), new("Y Start Weight", "Recipe", "0.80", "-", "Ready"), new("Y End Weight", "Recipe", "0.80", "-", "Ready")], [new("Target", "Align result compensation"), new("Apply To", "Process coordinate transform"), new("Distortion Key", "6 key display / result storage")], CreateCommonHistory());
    }

    private static (IReadOnlyList<ST_DISPLAY_ITEM> Summary, IReadOnlyList<ST_CORRECTION_SOURCE_ROW> Source, IReadOnlyList<ST_CORRECTION_VALUE_ROW> Candidate, IReadOnlyList<ST_CORRECTION_VALUE_ROW> Apply, IReadOnlyList<ST_DISPLAY_ITEM> Detail, IReadOnlyList<ST_CORRECTION_HISTORY_ROW> History) CreateOffsetCompData()
    {
        return ([new("Mode", "Recipe Offset"), new("Review Offset", "Ready"), new("Cell Shift", "50"), new("Default Offset", "Ready")], [new("Recipe", "Shot Offset", "Cell / Shot", "Loaded", "JHMI_RCP"), new("Recipe", "Cell Shift", "CELL01-CELL50", "Loaded", "JHMI_RCP"), new("Setup", "Scanner Default Offset", "8 scanner", "Ready", "Default Offset")], [new("CELL1_A1_RECIPE_OFFSET_X", "Shot", "+0.003", "mm", "Ready"), new("CELL7_A1_RECIPE_OFFSET_Y", "Shot", "+0.002", "mm", "Ready"), new("CELL12_ALIGN_X", "Cell", "-0.010", "mm", "Ready"), new("SCANNER_04_DEFAULT_X", "Default", "+0.006", "mm", "Ready")], [new("Simple Offset", "Key-in", "Recipe value edit", "-", "Ready"), new("Rough Offset", "Cell 1 Point", "Cell batch apply", "-", "Pending"), new("Default Offset", "Scanner interval", "Head default apply", "-", "Ready")], [new("Target", "Recipe offset parameter"), new("Simple Offset", "Direct key-in value"), new("Excluded", "Scanner Field Correction / Scan Comp")], CreateCommonHistory());
    }

    private static (IReadOnlyList<ST_DISPLAY_ITEM> Summary, IReadOnlyList<ST_CORRECTION_SOURCE_ROW> Source, IReadOnlyList<ST_CORRECTION_VALUE_ROW> Candidate, IReadOnlyList<ST_CORRECTION_VALUE_ROW> Apply, IReadOnlyList<ST_DISPLAY_ITEM> Detail, IReadOnlyList<ST_CORRECTION_HISTORY_ROW> History) CreateApcIcrData()
    {
        return ([new("APC", "OFF", "WAIT"), new("ICR", "OFF", "WAIT"), new("Precision", "+/-13 um"), new("Source", "CIM Share")], [new("APC", "APC File", "Not Loaded", "WAIT", "CIM PC Share"), new("ICR", "ICR File", "Not Loaded", "WAIT", "CIM PC Share"), new("Setting", "OFFSET_PRECISION", "+/-13", "Ready", "EC_LD")], [new("APC_USE", "External", "0", "-", "WAIT"), new("ICR_USE", "External", "0", "-", "WAIT"), new("OFFSET_PRECISION", "Limit", "13", "um", "Ready")], [new("APC Apply", "Correction Table", "Standby", "-", "WAIT"), new("ICR Apply", "Correction Table", "Standby", "-", "WAIT"), new("Source Backup", "History", "Required", "-", "Ready")], [new("Target", "External precision compensation"), new("Input", "CIM/shared folder file"), new("Apply To", "Correction table / process model")], CreateCommonHistory());
    }

    private static (IReadOnlyList<ST_DISPLAY_ITEM> Summary, IReadOnlyList<ST_CORRECTION_SOURCE_ROW> Source, IReadOnlyList<ST_CORRECTION_VALUE_ROW> Candidate, IReadOnlyList<ST_CORRECTION_VALUE_ROW> Apply, IReadOnlyList<ST_DISPLAY_ITEM> Detail, IReadOnlyList<ST_CORRECTION_HISTORY_ROW> History) CreateZeroDefenseData()
    {
        return ([new("0-Line Point", "5"), new("Mode", "Review"), new("Judge", "Ready"), new("Apply", "Standby")], [new("Recipe", "ZERO_DEFENCE_REVIEW_POINT", "5", "Loaded", "JHMI_RCP"), new("Review", "0-Line Result", "5 point", "Ready", "Review Result"), new("Stage", "Line Move", "Stage PC", "Ready", "Melsec / Stage PC")], [new("Line Error X", "Average", "+0.008", "mm", "OK"), new("Line Error Y", "Average", "-0.006", "mm", "OK"), new("Max Deviation", "0-Line", "0.018", "mm", "OK")], [new("0-Line Offset X", "Recipe", "+0.008", "mm", "Ready"), new("0-Line Offset Y", "Recipe", "-0.006", "mm", "Ready"), new("Defense Result", "Interlock", "OK", "-", "Ready")], [new("Target", "0-line defense review"), new("Review Point", "Recipe ZERO_DEFENCE_REVIEW_POINT"), new("Apply To", "Recipe offset / process model")], CreateCommonHistory());
    }

    private static (IReadOnlyList<ST_DISPLAY_ITEM> Summary, IReadOnlyList<ST_CORRECTION_SOURCE_ROW> Source, IReadOnlyList<ST_CORRECTION_VALUE_ROW> Candidate, IReadOnlyList<ST_CORRECTION_VALUE_ROW> Apply, IReadOnlyList<ST_DISPLAY_ITEM> Detail, IReadOnlyList<ST_CORRECTION_HISTORY_ROW> History) CreateOutputHistoryData()
    {
        return ([new("Output", "Correction Table"), new("Recipe", "DRILL_A01"), new("Last Apply", "10:24:36"), new("State", "Modified", "WARN")], [new("Output", "Recipe", "DRILL_A01.csv", "Modified", "Config\\RECIPE"), new("Output", "Correction Table", "Current", "Ready", "Config\\Correction"), new("Log", "Correction History", "Today", "Ready", "Data\\Log")], [new("Review Offset", "Recipe", "+0.006 / -0.004", "mm", "Ready"), new("Align Offset", "Transform", "+0.010 / -0.005", "mm", "Ready"), new("Zero Defense", "Recipe", "+0.008 / -0.006", "mm", "Ready")], [new("Recipe Save", "DRILL_A01.csv", "Required", "-", "Pending"), new("Script Build", "Process Model", "Correction applied", "-", "Ready"), new("History Write", "Correction Log", "Required", "-", "Ready")], [new("Target", "Final correction output"), new("Apply Order", "Review / Align / Offset / APC-ICR / Zero"), new("History", "Before / After / User / Time")], [new("10:24:36", "ENG1", "ZERO DEFENSE", "Line Offset", "0.000 / 0.000", "+0.008 / -0.006", "Pending"), new("10:18:11", "ENG1", "OFFSET COMP", "CELL1_A1_RECIPE_OFFSET_X", "0.000", "+0.003", "Saved"), new("10:12:40", "ENG1", "ALIGN/DISTORTION", "Theta", "0.000", "+0.002", "Saved"), new("10:04:29", "ENG1", "REVIEW DATA", "Review Result", "-", "Loaded", "OK")]);
    }

    private static IReadOnlyList<ST_CORRECTION_HISTORY_ROW> CreateCommonHistory()
    {
        return[new("10:24:36", "ENG1", "REVIEW DATA", "Review Result", "-", "Loaded", "OK"), new("10:18:11", "ENG1", "OFFSET COMP", "CELL1_A1_RECIPE_OFFSET_X", "0.000", "+0.003", "Saved"), new("10:12:40", "ENG1", "ALIGN/DISTORTION", "Theta", "0.000", "+0.002", "Saved"), new("10:05:09", "ENG1", "APC / ICR", "APC File", "-", "Standby", "WAIT")];
    }

    private static string GetSubtitle(string selectedTab)
    {
        return selectedTab switch
        {
            "REVIEW DATA" => "Review result load, measurement error review and compensation point selection",
            "ALIGN/DISTORTION" => "Align Key / Distortion Key base coordinates",
            "REVIEW" => "User-entered correction / Glass, Cell and Shot preview",
            "APC / ICR" => "External APC / ICR precision correction file apply",
            "VIEWER / HISTORY" => "Final correction offset viewer and apply history",
            _ => "Correction operation"
        };
    }

    private static string GetSourceName(string selectedTab)
    {
        return selectedTab switch
        {
            "APC / ICR" => "External",
            "ALIGN/DISTORTION" => "Vision",
            "REVIEW" => "Recipe",
            "VIEWER / HISTORY" => "Mixed",
            _ => "Review"
        };
    }

    private static string GetStateName(string selectedTab)
    {
        return selectedTab is "APC / ICR" ? "WAIT" : "Ready";
    }
}

public sealed record ST_CORRECTION_TAB(string Name, bool IsSelected);
public sealed record ST_CORRECTION_SOURCE_ROW(string Type, string Name, string Value, string State, string Source)
{
    public Brush StateBrush
    {
        get
        {
            return CStatusBrush.ForDisplayState(State);
        }
    }
}

public sealed record ST_CORRECTION_VALUE_ROW(string Item, string Target, string Value, string Unit, string State)
{
    public Brush ValueBrush
    {
        get
        {
            return CStatusBrush.ForDisplayState(State);
        }
    }

    public Brush StateBrush
    {
        get
        {
            return CStatusBrush.ForDisplayState(State);
        }
    }
}

public sealed record ST_CORRECTION_HISTORY_ROW(string Time, string User, string Tab, string Item, string Before, string After, string Result)
{
    public string DisplayTime
    {
        get
        {
            return FormatDisplayTime(Time);
        }
    }

    public string ApplyResult
    {
        get
        {
            return IsApplyOk(Result) ? "OK" : "NG";
        }
    }

    public Brush ResultBrush
    {
        get
        {
            return CStatusBrush.ForDisplayState(Result);
        }
    }

    public Brush ApplyResultBrush
    {
        get
        {
            return CStatusBrush.ForDisplayState(ApplyResult);
        }
    }

    private static string FormatDisplayTime(string value)
    {
        var text = (value ?? "").Trim();
        if (DateTime.TryParse(text, CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal, out var dateTime))
        {
            return dateTime.ToString("yy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);
        }

        if (TimeSpan.TryParse(text, CultureInfo.InvariantCulture, out var time))
        {
            return DateTime.Today.Add(time).ToString("yy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);
        }

        return text;
    }

    private static bool IsApplyOk(string value)
    {
        return (value ?? "").Trim().ToUpperInvariant() is "OK" or "SAVED" or "APPLIED" or "LOADED" or "READY" or "CURRENT";
    }
}

public sealed record ST_CORRECTION_OFFSET_SHOT_MATRIX_ROW(int RowNo, IReadOnlyList<ST_CORRECTION_OFFSET_SHOT_ITEM> Shots);
public sealed record ST_CORRECTION_OFFSET_SHOT_ITEM(string ShotKey, string ShotName, string Head, string RecipeOffset, string ReviewOffset, string HeadOffset, string FirstBeamOffset, string FinalOffset)
{
    public string AlignOffset { get; init; } = "0 / 0";
    public string Detail
    {
        get
        {
            return $"Recipe {RecipeOffset}\nReview {ReviewOffset}\nAlign {AlignOffset}\nHead {HeadOffset}\nFirst Beam {FirstBeamOffset}\nSum {FinalOffset}";
        }
    }
}

public sealed record ST_CORRECTION_OFFSET_VIEWER_PREVIEW(ImageSource? Image, IReadOnlyList<ST_CELL_PREVIEW_LABEL> CellLabels, string Summary);

internal readonly record struct ST_CORRECTION_AXIS_SETTING_STATE(
    string Summary,
    string Detail,
    string Vision,
    string Scanner,
    ST_CORRECTION_AXIS_FLIP_ROW VisionRow,
    IReadOnlyList<ST_CORRECTION_AXIS_FLIP_ROW> ScannerRows);

public sealed record ST_CORRECTION_AXIS_FLIP_ROW(
    string Name,
    bool XFlip,
    bool YFlip,
    bool XyFlip)
{
    public string XState => XFlip ? "ON" : "OFF";
    public string YState => YFlip ? "ON" : "OFF";
    public string XyState => XyFlip ? "ON" : "OFF";
}

public sealed record ST_CORRECTION_REVIEW_RESULT_ROW(string ShotKey, string Head, int Cell, double ErrorXValue, double ErrorYValue, string Judge)
{
    public string ErrorX
    {
        get
        {
            return FormatDisplayValue(ErrorXValue);
        }
    }

    public string ErrorY
    {
        get
        {
            return FormatDisplayValue(ErrorYValue);
        }
    }

    public Brush JudgeBrush
    {
        get
        {
            return CStatusBrush.ForDisplayState(Judge);
        }
    }

    private static string FormatDisplayValue(double value)
    {
        return value.ToString("+0.000;-0.000;0.000", CultureInfo.InvariantCulture);
    }
}

public sealed record ST_CORRECTION_REVIEW_OFFSET_ROW(string ShotKey, string Head, double OffsetXValue, double OffsetYValue, string State)
{
    public string OffsetX
    {
        get
        {
            return FormatDisplayValue(OffsetXValue);
        }
    }

    public string OffsetY
    {
        get
        {
            return FormatDisplayValue(OffsetYValue);
        }
    }

    public Brush StateBrush
    {
        get
        {
            return CStatusBrush.ForDisplayState(State);
        }
    }

    public Brush OffsetValueBrush
    {
        get
        {
            return State.Trim().ToUpperInvariant() switch
            {
                "PENDING" => CStatusBrush.Wait,
                "SAVED" => CStatusBrush.Online,
                _ => CStatusBrush.PrimaryText
            };
        }
    }

    private static string FormatDisplayValue(double value)
    {
        return value.ToString("+0.000;-0.000;0.000", CultureInfo.InvariantCulture);
    }
}
