using System.Windows;
using Drilling.Common.Interface;
using Drilling.UI.Popup;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuCorrection
{
    private async Task ExecuteAlignBaseAction(string action)
    {
        try
        {
            if (action is "OFFSET_APPLY" or "OFFSET_INIT" or "OFFSET_VIEW")
            {
                await ExecuteAlignOffsetAction(action);
                return;
            }
            if (action == "LOAD")
            {
                await LoadAlignLastData();
                return;
            }
            if (action == "REFRESH")
            {
                var recipeId = NormalizeRecipeId(_selectedRecipeIdProvider());
                if (string.IsNullOrWhiteSpace(recipeId))
                    throw new InvalidOperationException("현재 선택된 레시피가 없습니다.");
                var refreshed = await _recipeManager.RefreshRecipe(recipeId);
                if (!recipeId.Equals(NormalizeRecipeId(_selectedRecipeIdProvider()), StringComparison.OrdinalIgnoreCase)) return;
                if (refreshed is null)
                {
                    AlignDistortion.Clear("현재 레시피 파일을 찾을 수 없습니다.");
                    throw new InvalidOperationException("현재 레시피 파일을 찾을 수 없습니다.");
                }
                AlignDistortion.Update(refreshed);
                _statusReporter($"{refreshed.Name} 레시피에서 Base 값을 다시 읽었습니다.");
                return;
            }
            var recipe = await LoadSelectedOutputViewerRecipe(CancellationToken.None, fallbackToFirst: false)
                ?? throw new InvalidOperationException("현재 선택된 레시피가 없습니다.");
            AlignDistortion.Update(recipe);
            switch (action)
            {
                case "INIT":
                    if (!CRecipeConfirmDialog.ShowConfirmation("Base 초기화",
                        $"현재 레시피: {recipe.Name}\n\nAK1~AK4, DK1~DK6의 Base X/Y 20개 값을 모두 0.0으로 초기화하시겠습니까?\n레시피에 즉시 저장되며 되돌릴 수 없습니다.",
                        "초기화", useDangerStyle: true)) return;
                    await SaveAlignBaseValues(recipe.Id, CAlignBaseData.ZeroValues());
                    CRecipeConfirmDialog.ShowCompletion("Base 초기화 완료", "Base X/Y 20개 값을 0.0으로 초기화하고 레시피에 저장했습니다.");
                    break;
                case "EDIT":
                    var editor = new CAlignBaseEditPanel(recipe, AlignDistortion);
                    var dialog = new CAlignBaseEditDialog(editor, values => SaveAlignBaseValues(recipe.Id, values))
                        { Owner = Application.Current?.MainWindow };
                    if (dialog.ShowDialog() == true)
                        CRecipeConfirmDialog.ShowCompletion("Base 저장 완료", $"{recipe.Name} 레시피에 Base 값을 저장했습니다.");
                    break;
                case "LOAD_TO_BASE":
                    var loaded = CAlignBaseData.ReadLastLoads(AlignDistortion);
                    CAlignBaseData.Apply(recipe, loaded);
                    if (!CRecipeConfirmDialog.ShowConfirmation("Load to Base",
                        $"현재 레시피: {recipe.Name}\n\nAK 및 선택한 DK {AlignDistortion.LoadKeyNames.Count}개 키의 Base X/Y를 화면의 LastLoad 값으로 덮어쓰시겠습니까?\n선택하지 않은 DK의 Base는 유지됩니다.\n레시피에 즉시 저장되며 되돌릴 수 없습니다.",
                        "적용", useDangerStyle: true)) return;
                    await SaveAlignBaseValues(recipe.Id, loaded);
                    CRecipeConfirmDialog.ShowCompletion("Load to Base 완료", "LastLoad X/Y 값을 Base에 반영하고 레시피에 저장했습니다.");
                    break;
            }
        }
        catch (Exception exception)
        {
            var title = action switch { "LOAD" => "Load 확인",
                "OFFSET_APPLY" => "Offset Apply 확인", "OFFSET_INIT" => "Offset Init 확인", "OFFSET_VIEW" => "Current Offset View 확인", _ => "Base 작업 확인" };
            _statusReporter($"{title}: {exception.Message}");
            CRecipeConfirmDialog.ShowWarning(title, exception.Message);
        }
    }

    private async Task LoadAlignLastData(Func<string, string, bool>? confirm = null, Action<string, string>? warn = null)
    {
        confirm ??= (title, message) => CRecipeConfirmDialog.ShowConfirmation(title, message, "Load");
        warn ??= (title, message) => CRecipeConfirmDialog.ShowWarning(title, message);
        var recipe = await LoadSelectedOutputViewerRecipe(CancellationToken.None, fallbackToFirst: false)
            ?? throw new InvalidOperationException("현재 선택된 레시피가 없습니다.");
        AlignDistortion.Update(recipe);
        var targets = AlignDistortion.LoadParameterKeys.ToArray();
        var selectionSignature = AlignDistortion.LoadSelectionSignature;
        var mode = _alignLastLoad.GetMode(targets);
        if (mode == EN_COMM_STATE.Offline)
        {
            warn("MELSEC 연결 확인", "MELSEC이 연결되어 있지 않습니다.");
            return;
        }
        var simulation = mode == EN_COMM_STATE.Simulation;
        var prompt = simulation
            ? $"시뮬레이션 랜덤값을 불러오시겠습니까?\n대상: {string.Join(", ", AlignDistortion.LoadKeyNames)} (X/Y {targets.Length}개 값)\n각 Base X/Y 값을 기준으로 -1 ~ +1 mm 범위의 랜덤값을 불러옵니다."
            : $"MELSEC Data를 Load하시겠습니까?\n대상: {string.Join(", ", AlignDistortion.LoadKeyNames)}\n선택한 키의 X/Y {targets.Length}개 값을 한 번 읽어옵니다.";
        if (!confirm(simulation ? "Simulation Load" : "MELSEC Data Load", prompt)) return;
        if (selectionSignature != AlignDistortion.LoadSelectionSignature)
            throw new InvalidOperationException("선택한 DK 또는 키 위치가 변경되었습니다. Load를 다시 실행하세요.");
        if (_alignLastLoad.GetMode(targets) != mode)
            throw new InvalidOperationException("MELSEC 상태가 변경되었습니다. Load를 다시 실행하세요.");

        using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(10));
        var values = simulation ? CAlignLastLoadService.CreateSimulationValues(recipe, parameterKeys: targets)
            : await _alignLastLoad.ReadOnlineAsync(timeout.Token, targets);
        var current = await LoadSelectedOutputViewerRecipe(CancellationToken.None, fallbackToFirst: false);
        if (current is null || !current.Id.Equals(recipe.Id, StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("현재 레시피가 변경되었습니다. Load를 다시 실행하세요.");
        AlignDistortion.Update(current);
        if (selectionSignature != AlignDistortion.LoadSelectionSignature)
            throw new InvalidOperationException("Load 중 선택한 DK 또는 키 위치가 변경되었습니다. 다시 Load해 주세요.");
        AlignDistortion.ApplyLastLoad(recipe.Id, values, DateTimeOffset.Now, targets, simulation);
        _statusReporter($"{(simulation ? "Simulation" : "MELSEC")} LastLoad X/Y {targets.Length}개 값을 불러왔습니다.");
    }

    private async Task SaveAlignBaseValues(string recipeId, IReadOnlyDictionary<string, string> values)
    {
        var current = await LoadSelectedOutputViewerRecipe(CancellationToken.None, fallbackToFirst: false);
        if (current is null || !current.Id.Equals(recipeId, StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("현재 레시피가 변경되었습니다. Base 작업을 다시 실행하세요.");
        // Merge only the twenty base fields into the current recipe; retain all other parameters and its history.
        var updated = CAlignBaseData.Apply(current, values);
        await _recipeManager.SaveRecipe(updated);
        var saved = (await _recipeManager.LoadRecipes()).Single(recipe => recipe.Id.Equals(recipeId, StringComparison.OrdinalIgnoreCase));
        AlignDistortion.Update(saved);
        _statusReporter($"{saved.Name} 레시피의 Base 값을 저장했습니다.");
    }
}
