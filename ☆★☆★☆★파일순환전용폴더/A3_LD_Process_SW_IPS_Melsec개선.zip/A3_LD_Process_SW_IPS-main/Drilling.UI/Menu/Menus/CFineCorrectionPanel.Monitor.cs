using System.Windows;
using System.Windows.Media;
using Drilling.Common.Managers;
using Drilling.Common.Review;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CFineCorrectionPanel
{
    private ST_REVIEW_PLAN_POINT? _monitorFocus;
    private IReadOnlyList<ST_REVIEW_PLAN_POINT> _monitorNgPoints = [];
    public ImageSource? MonitorNgImage { get; private set; }
    public Visibility MonitorFocusVisibility => _monitorFocus is null ? Visibility.Collapsed : Visibility.Visible;
    public double MonitorFocusX => _monitorFocus is null ? 0 : ProjectMonitorPoint(_monitorFocus).X - 7;
    public double MonitorFocusY => _monitorFocus is null ? 0 : ProjectMonitorPoint(_monitorFocus).Y - 7;
    internal void SetMonitorFocus(ST_REVIEW_PLAN_POINT? point) { _monitorFocus = point; Notify(); }
    internal void SetMonitorNgPoints(IReadOnlyList<ST_REVIEW_PLAN_POINT> points)
    {
        if (_monitorNgPoints.SequenceEqual(points)) return;
        _monitorNgPoints = points; RefreshMonitorMarkers(); Notify();
    }
    private void RefreshMonitorMarkers()
    {
        if (_monitorNgPoints.Count == 0) { MonitorNgImage = null; return; }
        // One frozen drawing instead of a WPF control per NG Shot.
        var drawing = new DrawingGroup();
        using (var context = drawing.Open())
        {
            context.DrawRectangle(Brushes.Transparent, null, new Rect(0, 0, PreviewWidth, PreviewHeight));
            foreach (var point in _monitorNgPoints) context.DrawEllipse(Brushes.Red, null, ProjectMonitorPoint(point), 3, 3);
        }
        drawing.Freeze(); var image = new DrawingImage(drawing); image.Freeze(); MonitorNgImage = image;
    }
    /// <summary>Read-only projection of the actual run plan, never a plan regenerated from current UI selections.</summary>
    internal void AttachMonitor(ST_FINE_REVIEW_REQUEST request)
    {
        Clear("검사 계획 표시");
        _operationRunning = true;
        _source = request.Plan;
        RecipeId = request.Plan.RecipeId;
        RecipeName = request.Context?.RecipeName ?? RecipeId;
        _parameters = request.Context?.Parameters ?? new Dictionary<string, string>();
        LineCount = request.Context?.LinesPerCell ?? 1;
        InspectionMethod = request.Method == EN_FINE_INSPECTION_METHOD.Flying ? "FLYING" : "P2P";
        _selectedBeam = request.Plan.Points.FirstOrDefault()?.BeamNo ?? 1;
        if (_parameters.Count > 0)
        {
            var settings = _parameters.Select(pair => new ST_SYSTEM_PARAMETER(EN_SETTING_TAB.Option,
                pair.Key, pair.Value, "", "", Key: pair.Key)).ToArray();
            var preview = CHeadAssignmentPreviewBuilder.BuildRecipePreview(_parameters, new HashSet<int>(),
                CHeadAssignmentPreviewBuilder.BuildHeadLayout(settings), showKeys: false);
            if (preview.ValidationMessage.Length > 0) throw new InvalidOperationException(preview.ValidationMessage);
            PreviewImage = preview.Image; _sourceFrame = preview.Frame; _sourceCells = preview.CellLabels;
        }
        var modelCounts = request.Lines.GroupBy(line => line.ModelNo).ToDictionary(group => group.Key,
            group => group.SelectMany(line => line.Points).Select(point => point.CellNo).Distinct().Count());
        Lines = request.Lines.Select(line => new CFineInspectionLine(line.Key, line.Number, line.ModelNo,
            modelCounts[line.ModelNo], line.Points[0].DesignY, line.Points[0].DesignX <= line.Points[^1].DesignX, line.Points)).ToArray();
        Layout(); Notify();
    }

    internal Point ProjectMonitorPoint(ST_REVIEW_PLAN_POINT point)
    {
        var scale = GlassBounds.Width / Read("GLASS_SIZE_X", 925);
        return new(GlassBounds.Left + point.DesignX * scale, GlassBounds.Top + point.DesignY * scale);
    }
}
