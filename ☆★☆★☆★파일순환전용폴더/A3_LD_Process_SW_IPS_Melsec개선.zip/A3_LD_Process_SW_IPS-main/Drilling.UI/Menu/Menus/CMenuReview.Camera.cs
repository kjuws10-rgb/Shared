using System.Windows;
using Drilling.Common.Interface;
using Drilling.Common.Managers;
using Drilling.Common.Recipe;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuReview
{
    private readonly CInterfaceManager? _cameraInterfaces;
    private readonly CSettingManager? _cameraSettings;
    private ST_RECIPE_DEFINITION? _cameraRecipe;
    private IReadOnlyList<ST_SYSTEM_PARAMETER>? _cameraSettingFrame;
    private Dictionary<string, string> _cameraParameters = new(StringComparer.OrdinalIgnoreCase);
    private Rect _cameraGlassBounds = Rect.Empty;
    private Size _cameraCanvasSize;
    public CReviewCameraPreview Camera { get; } = new();

    private void SetCameraPreviewGeometry(ST_REVIEW_GLASS_PREVIEW preview)
    { _cameraGlassBounds = preview.GlassBounds; _cameraCanvasSize = preview.CanvasSize; }

    /// <summary>Refreshes presentation from shared memory only. No device reads or file polling.</summary>
    public void RefreshCameraFeedback(double viewportWidth, double viewportHeight)
    {
        if (_cameraInterfaces is null || _lastRecipe is null || _cameraGlassBounds.IsEmpty ||
            _cameraCanvasSize.Width <= 0 || _cameraCanvasSize.Height <= 0 || viewportWidth <= 0 || viewportHeight <= 0)
        { Camera.Clear(); return; }
        var settings = _cameraSettings?.LoadSection(EN_SETTING_TAB.Option);
        if (!ReferenceEquals(_cameraRecipe, _lastRecipe) || !ReferenceEquals(_cameraSettingFrame, settings))
        {
            _cameraRecipe = _lastRecipe; _cameraSettingFrame = settings;
            var parameters = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (var item in _lastRecipe.Parameters)
            {
                parameters[item.Name] = item.Value;
                if (!string.IsNullOrWhiteSpace(item.Key)) parameters[item.Key] = item.Value;
            }
            foreach (var item in settings ?? [])
            {
                parameters[item.Name] = item.Value;
                if (!string.IsNullOrWhiteSpace(item.Key)) parameters[item.Key] = item.Value;
            }
            _cameraParameters = parameters;
        }
        // Match Image.Stretch=Uniform, including the cropped preview's padding and letterboxing.
        var scale = Math.Min(viewportWidth / _cameraCanvasSize.Width, viewportHeight / _cameraCanvasSize.Height);
        var left = (viewportWidth - _cameraCanvasSize.Width * scale) / 2;
        var top = (viewportHeight - _cameraCanvasSize.Height * scale) / 2;
        Camera.Configure(_cameraParameters, new Rect(left + _cameraGlassBounds.Left * scale,
            top + _cameraGlassBounds.Top * scale, _cameraGlassBounds.Width * scale, _cameraGlassBounds.Height * scale));
        var values = CMotorStatusPollingService.ReadCachedSnapshot(_cameraInterfaces);
        var state = CMotorStatusPollingService.ReadStageConnectionState(_cameraInterfaces);
        Camera.UpdateFeedback(values.FirstOrDefault(row => row.Name == "Stage Y")?.Position ?? "-",
            values.FirstOrDefault(row => row.Name == "Review X")?.Position ?? "-",
            state == EN_COMM_STATE.Simulation ? "SIMULATION" : state == EN_COMM_STATE.Online ? "ONLINE" : "OFFLINE");
    }
}
