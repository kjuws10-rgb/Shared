using System.ComponentModel;
using System.Globalization;
using System.Windows.Media;
using Drilling.Common.Review;

namespace Drilling.UI.Menu.Menus;

/// <summary>Raw received Target-Hole values, before Vision Flip. Null coordinates represent an NG without a numeric result.</summary>
public sealed record ST_FINE_SHOT_RESULT(string ShotKey, double? ReceivedX, double? ReceivedY, string Judge);

public sealed class CFineInspectionLine : INotifyPropertyChanged
{
    public CFineInspectionLine(string key, int orderNo, int modelNo, int modelCellCount, double designY,
        bool leftToRight, IReadOnlyList<ST_REVIEW_PLAN_POINT> points,
        ST_REVIEW_BEAM_POSITION? startPosition = null, ST_REVIEW_BEAM_POSITION? endPosition = null)
    {
        Key = key; OrderNo = orderNo; ModelNo = modelNo; ModelCellCount = modelCellCount;
        DesignY = designY; LeftToRight = leftToRight; Points = points;
        StartPosition = startPosition; EndPosition = endPosition;
        ApplyResults([], EN_VISION_FLIP_TYPE.Normal);
    }
    public event PropertyChangedEventHandler? PropertyChanged;
    public string Key { get; }
    public int OrderNo { get; }
    public int ModelNo { get; }
    public int ModelCellCount { get; }
    public double DesignY { get; }
    public bool LeftToRight { get; private set; }
    public IReadOnlyList<ST_REVIEW_PLAN_POINT> Points { get; private set; }
    public EN_FINE_LINE_STATE State { get; private set; }
    public string StateText => State switch { EN_FINE_LINE_STATE.Running => "RUNNING", EN_FINE_LINE_STATE.Complete => "COMPLETE", EN_FINE_LINE_STATE.Ng => "NG", EN_FINE_LINE_STATE.Error => "ERROR", _ => "WAIT" };
    public Brush StateBrush => State switch { EN_FINE_LINE_STATE.Running or EN_FINE_LINE_STATE.Complete => Brushes.SeaGreen, EN_FINE_LINE_STATE.Ng or EN_FINE_LINE_STATE.Error => Brushes.Firebrick, _ => Brushes.DarkGoldenrod };
    public string Title => $"#{OrderNo}  MODEL {ModelNo}  {(LeftToRight ? "→" : "←")}";
    public string Detail => $"Y {DesignY:0.000} mm · {Points.Select(point => point.CellNo).Distinct().Count()} Cells · {Points.Count} Shots · Beam {Points[0].BeamNo}";
    public ST_REVIEW_BEAM_POSITION? StartPosition { get; private set; }
    public ST_REVIEW_BEAM_POSITION? EndPosition { get; private set; }
    public string StartStageY => Format(StartPosition?.StageY);
    public string EndStageY => Format(EndPosition?.StageY);
    public string StartReviewX => Format(StartPosition?.ReviewX);
    public string EndReviewX => Format(EndPosition?.ReviewX);
    public IReadOnlyList<ST_FINE_SHOT_DETAIL> ShotResults { get; private set; } = [];
    public IReadOnlyList<ST_FINE_AXIS_STATISTICS> Statistics { get; private set; } = [];
    public int MeasuredCount { get; private set; }
    public int NgCount { get; private set; }
    public int UnmeasuredCount => Points.Count - MeasuredCount;
    public string ResultSummary => $"검사 {MeasuredCount} / {Points.Count} · NG {NgCount} · 미검사 {UnmeasuredCount}";
    public Brush NgBrush => NgCount > 0 ? Brushes.Firebrick : StateBrush;
    public void Update(EN_FINE_LINE_STATE state) { if (State == state) return; State = state; PropertyChanged?.Invoke(this, new(null)); }
    internal bool ApplyProgress(ST_FINE_REVIEW_LINE line, EN_VISION_FLIP_TYPE flip)
    {
        var routeChanged = !Points.Select(point => point.ShotKey).SequenceEqual(line.Points.Select(point => point.ShotKey));
        Points = line.Points;
        StartPosition = new(Points[0].BeamNo, Points[0].ReviewTargetY, Points[0].ReviewTargetX);
        EndPosition = new(Points[^1].BeamNo, Points[^1].ReviewTargetY, Points[^1].ReviewTargetX);
        if (Points.Count > 1) LeftToRight = Points[0].DesignX <= Points[^1].DesignX;
        State = line.State switch { EN_FINE_REVIEW_LINE_STATE.Running => EN_FINE_LINE_STATE.Running,
            EN_FINE_REVIEW_LINE_STATE.Complete => EN_FINE_LINE_STATE.Complete, EN_FINE_REVIEW_LINE_STATE.Ng => EN_FINE_LINE_STATE.Ng,
            EN_FINE_REVIEW_LINE_STATE.Error => EN_FINE_LINE_STATE.Error, _ => EN_FINE_LINE_STATE.Wait };
        ApplyResults(Points.Where(point => point.State is EN_REVIEW_POINT_STATE.Ok or EN_REVIEW_POINT_STATE.Ng or EN_REVIEW_POINT_STATE.Current || point.Judge == "ERROR")
            .Select(point => new ST_FINE_SHOT_RESULT(point.ShotKey,
                point.State is EN_REVIEW_POINT_STATE.Ok or EN_REVIEW_POINT_STATE.Ng ? point.ErrorX : null,
                point.State is EN_REVIEW_POINT_STATE.Ok or EN_REVIEW_POINT_STATE.Ng ? point.ErrorY : null,
                point.State == EN_REVIEW_POINT_STATE.Current ? "RUNNING" : point.Judge)).ToArray(), flip);
        return routeChanged;
    }

    internal void ApplyResults(IReadOnlyList<ST_FINE_SHOT_RESULT> results, EN_VISION_FLIP_TYPE flip)
    {
        var keys = Points.Select(point => point.ShotKey).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var received = new Dictionary<string, ST_FINE_SHOT_RESULT>(StringComparer.OrdinalIgnoreCase);
        foreach (var result in results)
        {
            var judge = result.Judge.Trim().ToUpperInvariant();
            if (!keys.Contains(result.ShotKey) || !received.TryAdd(result.ShotKey, result with { Judge = judge }))
                throw new ArgumentException("라인에 속하지 않거나 중복된 Shot 결과입니다.", nameof(results));
            if (judge is not ("OK" or "NG" or "ERROR" or "RUNNING") || result.ReceivedX.HasValue != result.ReceivedY.HasValue ||
                result.ReceivedX is { } x && !double.IsFinite(x) || result.ReceivedY is { } y && !double.IsFinite(y) ||
                judge == "OK" && !result.ReceivedX.HasValue || (judge is "ERROR" or "RUNNING") && result.ReceivedX.HasValue)
                throw new ArgumentException("검사 결과의 판정 또는 X/Y 수치가 올바르지 않습니다.", nameof(results));
        }
        // Compute once per result snapshot, never on the position feedback timer. Include numeric NG results;
        // unmeasured and NG without coordinates must not contribute a fabricated zero to the statistics.
        var rows = Points.Select((point, index) =>
        {
            received.TryGetValue(point.ShotKey, out var result);
            ST_REVIEW_COORDINATE_OFFSET? converted = result?.ReceivedX is { } x && result.ReceivedY is { } y
                ? CReviewCoordinateTransformer.VisionErrorToStageOffset(x, y, flip) : null;
            return new ST_FINE_SHOT_DETAIL(index + 1, $"HEAD {point.HeadNo:00}", $"Cell{point.CellNo:00}",
                CReviewShotNameFormatter.ToMatrixName(point.ShotNo, point.PixelCountX), point.BeamNo,
                result?.ReceivedX, result?.ReceivedY, converted?.X, converted?.Y, result?.Judge ?? "미검사");
        }).ToArray();
        var statistics = new[] { ST_FINE_AXIS_STATISTICS.Create("X", rows.Select(row => row.ConvertedX)),
            ST_FINE_AXIS_STATISTICS.Create("Y", rows.Select(row => row.ConvertedY)) };
        ShotResults = rows; Statistics = statistics; MeasuredCount = received.Values.Count(result => result.Judge is "OK" or "NG");
        NgCount = received.Values.Count(result => result.Judge == "NG");
        PropertyChanged?.Invoke(this, new(null));
    }
    internal static string Format(double? value) => value is { } number
        ? (Math.Round(number, 3, MidpointRounding.AwayFromZero) + 0d).ToString("0.000", CultureInfo.InvariantCulture) : "-";
}

public sealed record ST_FINE_SHOT_DETAIL(int No, string Head, string Cell, string Shot, int BeamNo,
    double? ReceivedX, double? ReceivedY, double? ConvertedX, double? ConvertedY, string Judge)
{
    public string ReceivedXText => CFineInspectionLine.Format(ReceivedX);
    public string ReceivedYText => CFineInspectionLine.Format(ReceivedY);
    public string ConvertedXText => CFineInspectionLine.Format(ConvertedX);
    public string ConvertedYText => CFineInspectionLine.Format(ConvertedY);
    public Brush JudgeBrush => Judge switch { "NG" or "ERROR" => Brushes.Firebrick, "OK" or "RUNNING" => Brushes.SeaGreen, _ => Brushes.DarkGoldenrod };
}

public sealed record ST_FINE_AXIS_STATISTICS(string Axis, string Maximum, string Minimum, string Average)
{
    internal static ST_FINE_AXIS_STATISTICS Create(string axis, IEnumerable<double?> coordinates)
    {
        var values = coordinates.Where(value => value.HasValue).Select(value => value!.Value).ToArray();
        return values.Length == 0 ? new(axis, "-", "-", "-") : new(axis, CFineInspectionLine.Format(values.Max()),
            CFineInspectionLine.Format(values.Min()), CFineInspectionLine.Format(values.Average()));
    }
}
