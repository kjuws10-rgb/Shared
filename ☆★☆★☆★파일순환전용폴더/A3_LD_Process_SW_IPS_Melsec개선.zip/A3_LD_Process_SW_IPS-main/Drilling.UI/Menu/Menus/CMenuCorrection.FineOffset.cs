using Drilling.Common.Recipe;
using Drilling.Common.Review;
using Drilling.UI.Popup;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuCorrection
{
    private async Task ExecuteFineOffsetAction(string action, Func<string, string, bool>? confirm = null,
        Action<string, string>? completed = null, Action<string, string>? warn = null,
        Action<CAlignOffsetViewerPanel>? showViewer = null)
    {
        if (_isReviewOperationRunning || !Fine.CanConfigure || action is not ("OFFSET_APPLY" or "OFFSET_INIT" or "OFFSET_VIEW")) return;
        if (action == "OFFSET_VIEW")
        {
            await ExecuteSimpleOffsetAction(action, confirm, completed, warn, showViewer);
            return;
        }
        var initialize = action == "OFFSET_INIT";
        var title = initialize ? "FINE Offset Init" : "FINE Offset Apply";
        confirm ??= (caption, message) => CRecipeConfirmDialog.ShowConfirmation(caption, message,
            initialize ? "초기화" : "적용", useDangerStyle: initialize);
        completed ??= (caption, message) => CRecipeConfirmDialog.ShowCompletion(caption, message);
        warn ??= (caption, message) => CRecipeConfirmDialog.ShowWarning(caption, message);
        var version = Fine.SourceVersion;
        var recipeId = Fine.RecipeId;
        _isReviewOperationRunning = true;
        Simple.SetOffsetOperationRunning(true); Rough.SetOffsetOperationRunning(true); Fine.SetOperationRunning(true);
        ExecuteCommand.NotifyCanExecuteChanged();
        try
        {
            var recipe = await LoadSelectedOutputViewerRecipe(CancellationToken.None, fallbackToFirst: false)
                ?? throw new InvalidOperationException("현재 레시피가 없습니다.");
            var settings = LoadSimpleOffsetSettings();
            EnsureSource(recipe, settings);
            // Capture full-precision results on the UI dispatcher. Calculation and file I/O run off the UI thread.
            var input = initialize ? null : Fine.CreateOffsetInput();
            var targets = Fine.GetOffsetTargets();
            var deltas = initialize ? targets.Select(point => new ST_FINE_OFFSET_DELTA(point, 0, 0)).ToArray()
                : await Task.Run(() => CFineReviewOffsetCalculator.Calculate(input!.Targets, input.Measurements, input.Flip));
            var cells = deltas.Select(delta => delta.Shot.CellNo).Distinct().Count();
            var preserved = Fine.GetOffsetTargets().Count - deltas.Count;
            var message = $"현재 레시피: {recipe.Name}\n대상: {cells:N0} Cells / {deltas.Count:N0} Shots\n\n" +
                (initialize ? "레시피 전체 Shot의 Review Offset X/Y를 0.000으로 초기화하시겠습니까?\n되돌릴 수 없습니다."
                : $"{Fine.LineCount} Line · 같은 Cell/열 기준 " + (Fine.LineCount == 1 ? "측정값" : "Y 방향 Lagrange 보간값") +
                    "을 기존 Review Offset에 누적하시겠습니까?\nVision Flip 변환값을 설계 좌표로 저장합니다." +
                    (preserved > 0 ? $"\n검사 기준값이 없는 {preserved:N0}개 Shot은 기존 값을 유지합니다." : "")) +
                "\n새 REVIEW OFFSET 파일을 생성합니다.";
            if (!confirm(title, message)) return;
            recipe = await LoadSelectedOutputViewerRecipe(CancellationToken.None, fallbackToFirst: false)
                ?? throw new InvalidOperationException("현재 레시피가 없습니다.");
            settings = LoadSimpleOffsetSettings();
            EnsureSource(recipe, settings);
            var parameters = BuildOutputViewerParameterMap(recipe, settings);
            var saved = await Task.Run(async () =>
            {
                var latest = await _reviewOffsetFile.LoadLatest(recipe.Id);
                if (!latest.RecipeId.Equals(recipe.Id, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("Review Offset 파일의 레시피가 일치하지 않습니다.");
                var rows = latest.Rows.ToDictionary(row => (row.CellId, NormalizeReviewOffsetShotId(row.ShotId)));
                foreach (var delta in deltas)
                {
                    var point = delta.Shot;
                    var name = CReviewShotNameFormatter.ToMatrixName(point.ShotNo, point.PixelCountX);
                    var key = (point.CellNo, NormalizeReviewOffsetShotId(name));
                    var previous = rows.GetValueOrDefault(key);
                    var current = initialize || previous is null ? (X: 0.0, Y: 0.0) : CReviewOffsetData.ToDesign(parameters,
                        point.HeadNo, previous.ReviewOffsetX, previous.ReviewOffsetY, previous.IsDesignCoordinate);
                    rows[key] = new(point.CellNo, key.Item2,
                        CAlignShotOffsetData.RoundValue(current.X + delta.X), CAlignShotOffsetData.RoundValue(current.Y + delta.Y)) { IsDesignCoordinate = true };
                }
                return await _reviewOffsetFile.SaveNew(recipe.Id, rows.Values.OrderBy(row => row.CellId).ThenBy(row => row.ShotId).ToArray());
            });
            _simpleOffsetRecipeId = saved.RecipeId; _simpleOffsetLoad = Task.FromResult(saved);
            Simple.Update(recipe, settings, saved); Rough.Update(recipe, settings, saved);
            if (version == Fine.SourceVersion && recipeId == Fine.RecipeId)
            {
                Fine.AcceptOffsetSave(initialize, saved.FileName);
                if (!initialize) _reviewManager?.FineMonitor.MarkOffsetSaved(Fine.MonitorRunId, saved.FileName);
            }
            _statusReporter($"{title}: {saved.FileName}");
            completed($"{title} 완료", $"{deltas.Count:N0}개 Shot의 Review Offset을 {(initialize ? "초기화" : "누적 적용")}했습니다.\n{saved.FileName}");
        }
        catch (Exception error) { _statusReporter($"{title}: {error.Message}"); warn(title, error.Message); }
        finally
        {
            _isReviewOperationRunning = false;
            Simple.SetOffsetOperationRunning(false); Rough.SetOffsetOperationRunning(false); Fine.SetOperationRunning(false);
            ExecuteCommand.NotifyCanExecuteChanged();
        }

        void EnsureSource(Drilling.Common.Managers.ST_RECIPE_DEFINITION recipe,
            IReadOnlyList<Drilling.Common.Managers.ST_SYSTEM_PARAMETER> settings)
        {
            Fine.Update(recipe, settings);
            if (Fine.RecipeId != recipeId || Fine.SourceVersion != version)
                throw new InvalidOperationException("레시피 또는 Setting이 변경되었습니다. 검사 대상을 다시 확인해 주세요.");
        }
    }
}
