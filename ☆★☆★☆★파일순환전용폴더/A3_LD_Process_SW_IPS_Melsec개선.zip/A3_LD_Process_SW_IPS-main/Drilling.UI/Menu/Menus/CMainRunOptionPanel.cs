using System.ComponentModel;
using System.Windows;
using System.Windows.Media;
using Drilling.Common.Review;
using Drilling.Common.Managers;
using System.Globalization;
using System.IO;

namespace Drilling.UI.Menu.Menus;

/// <summary>Setting-backed Run Options. The coordinator captures immutable execution options before Prc ABLE.</summary>
public sealed class CMainRunOptionPanel : INotifyPropertyChanged
{
    private ST_AUTO_REVIEW_OPTIONS _reviewOptions = new();
    private readonly Func<bool?>? _readReviewAble;
    private readonly CSettingManager? _settings;
    private readonly Action<string>? _reportError;
    private bool _reviewAble;
    public bool CanEditReview => !_reviewAble;
    public string ReviewInfoText => _reviewAble ? "Review ABLE ON · 리뷰 옵션 변경 불가" : "Beam 11 · 옵션은 Prc Review ABLE 전에 확정";
    public ST_AUTO_REVIEW_OPTIONS CaptureReviewOptions() => _settings is null
        ? Volatile.Read(ref _reviewOptions) : CRunOptionSettings.Read(_settings).ReviewOptions;
    public event PropertyChangedEventHandler? PropertyChanged;
    public bool ZeroLineEnabled { get; private set; }
    public bool FollowUpEnabled { get; private set; }
    public int ReviewLineCount { get; private set; } = 1;
    public string ReviewMethod { get; private set; } = "IOF";
    public int ReviewCountRetries { get; private set; } = 1;
    public bool ReviewImmediateRetry { get; private set; }
    public IReadOnlyList<CMainRunOptionChoice> ReviewImmediateRetryChoices => SwitchChoices(ReviewImmediateRetry);
    public IReadOnlyList<CMainRunOptionChoice> ReviewRetryChoices => new[] { 1, 2, 3 }
        .Select(count => new CMainRunOptionChoice(count, $"{count}회", count == ReviewCountRetries, Brushes.SteelBlue)).ToArray();
    public int CurrentGroup { get; private set; } = 1;
    public int TotalGroups { get; private set; } = 4;
    private bool _visible;
    public Visibility PanelVisibility => _visible ? Visibility.Visible : Visibility.Collapsed;
    public string GroupText => $"{CurrentGroup} / {TotalGroups}";
    public IReadOnlyList<CMainRunOptionChoice> ZeroLineChoices => SwitchChoices(ZeroLineEnabled);
    public IReadOnlyList<CMainRunOptionChoice> FollowUpChoices => SwitchChoices(FollowUpEnabled);
    public IReadOnlyList<CMainRunOptionChoice> ReviewLineChoices => new[] { 1, 3, 5, 7 }
        .Select(count => new CMainRunOptionChoice(count, $"{count}줄", count == ReviewLineCount, Brushes.SteelBlue)).ToArray();
    public IReadOnlyList<CMainRunOptionChoice> ReviewMethodChoices =>
        [new(0, "PtoP", ReviewMethod == "PtoP", Brushes.SteelBlue), new(1, "IOF", ReviewMethod == "IOF", Brushes.SteelBlue)];
    public CButtonCommand SelectZeroLineCommand { get; }
    public CButtonCommand SelectFollowUpCommand { get; }
    public CButtonCommand SelectReviewLineCommand { get; }
    public CButtonCommand SelectReviewMethodCommand { get; }
    public CButtonCommand SelectReviewRetryCommand { get; }
    public CButtonCommand SelectReviewImmediateRetryCommand { get; }
    public CButtonCommand InitGroupCommand { get; }

    public CMainRunOptionPanel(Func<bool?>? readReviewAble = null, CSettingManager? settings = null, Action<string>? reportError = null)
    {
        _readReviewAble = readReviewAble;
        _settings = settings;
        _reportError = reportError;
        SelectZeroLineCommand = new(value =>
        {
            if (!TryNumber(value, out var selected) || selected is not (0 or 1)) return;
            Commit(CRunOptionSettings.ZeroDefence, selected, () => ZeroLineEnabled = selected == 1);
        });
        SelectFollowUpCommand = new(value =>
        {
            if (!TryNumber(value, out var selected) || selected is not (0 or 1)) return;
            Commit(CRunOptionSettings.FollowUp, selected, () => FollowUpEnabled = selected == 1);
        });
        SelectReviewLineCommand = new(value =>
        {
            if (!CanChange() || !TryNumber(value, out var selected) || selected is not (1 or 3 or 5 or 7)) return;
            Commit(CRunOptionSettings.ReviewLine, CRunOptionSettings.EncodeLine(selected), () => ReviewLineCount = selected);
        }, _ => CanChange());
        SelectReviewMethodCommand = new(value =>
        {
            if (!CanChange() || !TryNumber(value, out var selected) || selected is not (0 or 1)) return;
            Commit(CRunOptionSettings.ReviewMethod, selected, () => ReviewMethod = selected == 0 ? "PtoP" : "IOF");
        }, _ => CanChange());
        InitGroupCommand = new(_ => Commit(CRunOptionSettings.CurrentGroup, 1, () => CurrentGroup = 1));
        SelectReviewRetryCommand = new(value =>
        {
            if (!CanChange() || !TryNumber(value, out var selected) || selected is not (1 or 2 or 3)) return;
            Commit(CRunOptionSettings.RetryCount, selected, () => ReviewCountRetries = selected);
        }, _ => CanChange());
        SelectReviewImmediateRetryCommand = new(value =>
        {
            if (!CanChange() || !TryNumber(value, out var selected) || selected is not (0 or 1)) return;
            Commit(CRunOptionSettings.ImmediateRetry, selected, () => ReviewImmediateRetry = selected == 1);
        }, _ => CanChange());
        ReloadFromSettings();
    }

    // Reads the SettingManager memory cache, never polls CSV or device I/O.
    public void ReloadFromSettings()
    {
        if (_settings is null) return;
        var value = CRunOptionSettings.Read(_settings);
        if ((ZeroLineEnabled, CurrentGroup, FollowUpEnabled, ReviewMethod, ReviewLineCount, ReviewImmediateRetry, ReviewCountRetries) ==
            (value.ZeroDefence, value.CurrentGroup, value.FollowUp, value.ReviewMethod == 0 ? "PtoP" : "IOF", value.ReviewLineCount, value.ImmediateRetry, value.RetryCount)) return;
        ZeroLineEnabled = value.ZeroDefence; CurrentGroup = value.CurrentGroup; FollowUpEnabled = value.FollowUp;
        ReviewMethod = value.ReviewMethod == 0 ? "PtoP" : "IOF"; ReviewLineCount = value.ReviewLineCount;
        ReviewImmediateRetry = value.ImmediateRetry; ReviewCountRetries = value.RetryCount; Refresh();
    }
    private void Commit(string key, int value, Action apply)
    {
        try
        {
            if (_settings is not null && _settings.GetValue(EN_SETTING_TAB.Option, key) != value.ToString(CultureInfo.InvariantCulture))
                _settings.SetValue(EN_SETTING_TAB.Option, key, value.ToString(CultureInfo.InvariantCulture));
            apply(); Refresh();
        }
        catch (Exception error) when (error is InvalidDataException or IOException or UnauthorizedAccessException)
        {
            _reportError?.Invoke($"Run Option 저장 실패: {error.Message}");
        }
    }

    // Called by Main's existing shared-snapshot refresh. Unknown data does not clear a known ON.
    public void UpdateReviewAble(bool? on)
    {
        if (on is null || _reviewAble == on.Value) return;
        _reviewAble = on.Value;
        PropertyChanged?.Invoke(this, new(null));
        foreach (var command in new[] { SelectReviewLineCommand, SelectReviewMethodCommand, SelectReviewRetryCommand,
            SelectReviewImmediateRetryCommand }) command.NotifyCanExecuteChanged();
    }
    private bool CanChange()
    {
        // Recheck memory at execution too, so a click cannot slip through before the next Main refresh.
        if (_readReviewAble is not null) UpdateReviewAble(_readReviewAble());
        return CanEditReview;
    }

    // Uses the recipe snapshot already loaded by Main; does not read a file or advance a cycle.
    public void UpdatePointCount(int pointCount)
    {
        var total = pointCount == 4 ? 2 : 4;
        var group = Math.Clamp(CurrentGroup, 1, total);
        if (total == TotalGroups && group == CurrentGroup) return;
        TotalGroups = total;
        if (group != CurrentGroup) Commit(CRunOptionSettings.CurrentGroup, group, () => CurrentGroup = group);
        else Refresh();
    }
    public void SetVisible(bool visible)
    {
        ReloadFromSettings();
        if (_visible == visible) return;
        _visible = visible; Refresh();
    }
    private static bool TryNumber(object? value, out int number) => int.TryParse(value?.ToString(), out number);
    private static IReadOnlyList<CMainRunOptionChoice> SwitchChoices(bool enabled) =>
        [new(1, "ON", enabled, Brushes.SeaGreen), new(0, "OFF", !enabled, Brushes.Firebrick)];
    private void Refresh()
    {
        Volatile.Write(ref _reviewOptions, new(ReviewLineCount,
            ReviewMethod == "PtoP" ? EN_FINE_INSPECTION_METHOD.PtoP : EN_FINE_INSPECTION_METHOD.Flying, ReviewCountRetries, ReviewImmediateRetry));
        PropertyChanged?.Invoke(this, new(null));
    }
}

public sealed record CMainRunOptionChoice(int Value, string Label, bool IsSelected, Brush SelectedBrush)
{
    public Brush Background => IsSelected ? SelectedBrush : Brushes.AliceBlue;
    public Brush Foreground => IsSelected ? Brushes.White : Brushes.Black;
}
