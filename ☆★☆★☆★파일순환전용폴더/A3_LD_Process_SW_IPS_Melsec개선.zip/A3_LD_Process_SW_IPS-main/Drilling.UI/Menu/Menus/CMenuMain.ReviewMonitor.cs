using Drilling.Common.Interface;
using Drilling.UI.Popup;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuMain
{
    private CAutoReviewMonitorDialog? _reviewMonitorWindow;
    private void OpenReviewMonitor()
    {
        if (_reviewMonitorWindow is { } open) { open.Activate(); return; }
        var panel = new CAutoReviewMonitorPanel(reviewManager.FineMonitor, () =>
        {
            var values = CMotorStatusPollingService.ReadCachedSnapshot(interfaceManager);
            var mode = CMotorStatusPollingService.ReadStageConnectionState(interfaceManager);
            return (values.FirstOrDefault(row => row.Name == "Stage Y")?.Position ?? "-",
                values.FirstOrDefault(row => row.Name == "Review X")?.Position ?? "-",
                mode == EN_COMM_STATE.Simulation ? "SIMULATION" : mode == EN_COMM_STATE.Online ? "ONLINE" : "OFFLINE");
        });
        var window = new CAutoReviewMonitorDialog(panel);
        if (System.Windows.Application.Current?.MainWindow is { } owner && !ReferenceEquals(owner, window)) window.Owner = owner;
        window.Closed += (_, _) => _reviewMonitorWindow = null;
        _reviewMonitorWindow = window;
        window.Show();
    }
}
