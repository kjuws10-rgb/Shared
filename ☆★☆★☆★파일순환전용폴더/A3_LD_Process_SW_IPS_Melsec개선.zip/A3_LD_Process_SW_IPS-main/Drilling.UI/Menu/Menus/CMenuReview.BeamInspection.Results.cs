using System.Globalization;
using System.IO;
using Drilling.Common.Review;
using Drilling.UI.Popup;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuReview
{
    private ST_BEAM_INSPECTION_RESULT_FILE_DATA? _loadedBeamInspectionResult;
    private bool _isBeamInspectionResultLoading;
    private long _beamInspectionResultLoadGeneration;
    private CancellationTokenSource? _beamInspectionResultLoadCancellation;
    private Func<CancellationToken, Task<ST_BEAM_INSPECTION_RESULT_FILE_DATA?>>? _beamInspectionResultLoader = null;

    public CButtonCommand LoadLastBeamInspectionResultCommand { get; }
    public CButtonCommand ClearLoadedBeamInspectionResultCommand { get; }
    public bool CanLoadBeamInspectionResult => IsBeamInspectionMode && !IsSampleSelectTab && !IsReviewExecutionActive && !_isBeamInspectionResultLoading;
    public bool CanClearLoadedBeamInspectionResult => CanLoadBeamInspectionResult && _loadedBeamInspectionResult is not null;

    private int GetInspectionDisplayShotCount() => _loadedBeamInspectionResult?.Shots.Count ?? GetInspectionDisplayShots().Count;
    private ST_BEAM_INSPECTION_RESULT_SHOT? GetLoadedInspectionShot() => _loadedBeamInspectionResult is { Shots.Count: > 0 } file
        ? file.Shots[Math.Clamp(_beamInspectionBrowseIndex, 0, file.Shots.Count - 1)] : null;

    private async Task LoadLastBeamInspectionResult()
    {
        if (!CanLoadBeamInspectionResult) return;
        var generation = ++_beamInspectionResultLoadGeneration;
        var request = new CancellationTokenSource();
        _beamInspectionResultLoadCancellation = request;
        _isBeamInspectionResultLoading = true;
        RefreshBeamInspectionDisplay();
        try
        {
            var loader = _beamInspectionResultLoader;
            var result = await Task.Run(async () => loader is null
                ? await _reviewManager.LoadLastBeamInspection(request.Token).ConfigureAwait(false)
                : await loader(request.Token).ConfigureAwait(false), request.Token);
            if (generation != _beamInspectionResultLoadGeneration || !IsBeamInspectionMode || IsSampleSelectTab || IsReviewExecutionActive) return;
            if (result is null)
            {
                CRecipeConfirmDialog.ShowWarning("Beam Inspection 결과", "저장된 Beam Inspection 결과가 없습니다.");
                return;
            }
            ApplyLoadedBeamInspectionResult(result);
            _statusReporter($"Beam Inspection 결과 불러오기: {result.FileName}");
        }
        catch (OperationCanceledException) when (request.IsCancellationRequested) { }
        catch (Exception exception)
        {
            if (generation == _beamInspectionResultLoadGeneration && IsBeamInspectionMode && !IsSampleSelectTab)
                CRecipeConfirmDialog.ShowWarning("Beam Inspection 결과 불러오기 실패", exception.Message);
        }
        finally
        {
            if (ReferenceEquals(_beamInspectionResultLoadCancellation, request))
            {
                _beamInspectionResultLoadCancellation = null;
                _isBeamInspectionResultLoading = false;
                RefreshBeamInspectionDisplay();
            }
            request.Dispose();
        }
    }

    private void ApplyLoadedBeamInspectionResult(ST_BEAM_INSPECTION_RESULT_FILE_DATA result)
    {
        if (IsReviewExecutionActive) return;
        if (result.Shots.Count == 0) throw new InvalidDataException("Beam Inspection 결과에 Shot이 없습니다.");
        _loadedBeamInspectionResult = result;
        _beamInspectionBrowseIndex = 0;
        RefreshBeamInspectionDisplay();
    }

    private void ClearLoadedBeamInspectionResult()
    {
        if (!CanClearLoadedBeamInspectionResult) return;
        InvalidateBeamInspectionResultLoad(clearLoaded: true);
        _beamInspectionBrowseIndex = 0;
        RefreshBeamInspectionDisplay();
        _statusReporter("불러온 Beam Inspection 결과 표시를 해제했습니다.");
    }

    private void InvalidateBeamInspectionResultLoad(bool clearLoaded)
    {
        ++_beamInspectionResultLoadGeneration;
        _beamInspectionResultLoadCancellation?.Cancel();
        if (clearLoaded) _loadedBeamInspectionResult = null;
    }

    private IReadOnlyList<ST_REVIEW_BEAM_MATRIX_ROW> BuildLoadedInspectionBeamRows()
    {
        var shot = GetLoadedInspectionShot();
        var beams = shot?.Beams.ToDictionary(beam => beam.BeamNo) ?? [];
        return Enumerable.Range(0, 4).Select(row => new ST_REVIEW_BEAM_MATRIX_ROW(row + 1,
            Enumerable.Range(0, 4).Select(column =>
            {
                var number = row * 4 + column + 1;
                beams.TryGetValue(number, out var beam);
                var measured = beam?.IsMeasured == true;
                var judge = measured ? beam!.Judge : "미검사";
                return new ST_REVIEW_BEAM_ROW(number, $"Beam{number}", row + 1, column + 1, measured, false,
                    "", measured ? judge : "READY", SelectRunBeamCommand)
                {
                    IsInspectionResult = true,
                    InspectionStatus = judge,
                    InspectionResultText = measured
                        ? $"ΔX {beam!.XMm!.Value.ToString("+0.0000;-0.0000;0.0000", CultureInfo.InvariantCulture)}\nΔY {beam.YMm!.Value.ToString("+0.0000;-0.0000;0.0000", CultureInfo.InvariantCulture)}" : ""
                };
            }).ToArray())).ToArray();
    }
}
