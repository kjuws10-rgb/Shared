using System.ComponentModel;
using System.Globalization;
using Drilling.Common.Interface;
using Drilling.Common.Managers;

namespace Drilling.UI.Menu.Menus;

// Live feedback comes exclusively from the shared MELSEC cache.
public sealed partial class CManualMofStagePanel : INotifyPropertyChanged
{
    private double? _targetPosition;
    private double? _targetSpeed;
    public event PropertyChangedEventHandler? PropertyChanged;
    public string TargetPosition { get; private set; } = "미설정";
    public string TargetSpeed { get; private set; } = "미설정";
    public string TargetSpeedSource { get; private set; } = "선택된 레시피 없음";
    public ST_MANUAL_MOF_STAGE_VALUE CurrentPosition { get; private set; } = Missing;
    public ST_MANUAL_MOF_STAGE_VALUE CurrentSpeed { get; private set; } = Missing;
    public ST_MANUAL_MOF_STAGE_VALUE Busy { get; private set; } = Missing;
    public ST_MANUAL_MOF_STAGE_VALUE AlarmCode { get; private set; } = Missing;
    public ST_MANUAL_MOF_STAGE_VALUE WarningCode { get; private set; } = Missing;
    public bool? IsAtTarget => CurrentPosition.Value is { } position && _targetPosition is { } target &&
        Math.Abs(position) < (double)decimal.MaxValue && Math.Abs(target) < (double)decimal.MaxValue
            ? Math.Abs(position - target) <= 1 && Math.Abs((decimal)position - (decimal)target) <= 0.03m : null;
    public string PositionComparison => IsAtTarget switch
    {
        true => "위치 일치 (±0.03 mm)", false => "위치 불일치 (±0.03 mm)", _ => "위치 확인 대기"
    };
    private static ST_MANUAL_MOF_STAGE_VALUE Missing => new("미설정", "MELSEC 맵이 미설정 또는 사용 해제 상태입니다.");

    public void UpdateTargets(ST_RECIPE_DEFINITION? recipe, IReadOnlyList<ST_SYSTEM_PARAMETER> motorSettings)
    {
        _targetPosition = ParseTarget(motorSettings.LastOrDefault(item =>
            string.Equals(item.Key, "STAGE_START_POS_Y", StringComparison.OrdinalIgnoreCase))?.Value);
        _targetSpeed = ParseTarget(recipe?.Parameters.LastOrDefault(item =>
            string.Equals(item.Key, "STAGE_SPEED", StringComparison.OrdinalIgnoreCase))?.Value);
        TargetPosition = FormatTarget(_targetPosition);
        TargetSpeed = FormatTarget(_targetSpeed);
        TargetSpeedSource = recipe is null ? "선택된 레시피 없음" : $"Recipe: {recipe.Name} / Stage Speed";
        NotifyStateChanged();
    }

    public void UpdateSnapshot(IReadOnlyList<ST_MELSEC_MAP_DATA> map,
        IReadOnlyDictionary<string, ST_MELSEC_CACHED_VALUE> snapshot)
    {
        var position = Read("MOTOR_STAGE_Y_CUR_POS", ValueKind.Number);
        var speed = Read("MOTOR_STAGE_Y_CUR_SPEED", ValueKind.Number);
        var busy = Read("MOTOR_STAGE_Y_BUSY", ValueKind.Flag);
        var alarm = Read("MOTOR_STAGE_Y_SERVO_ALARM_CODE", ValueKind.Code);
        var warning = Read("MOTOR_STAGE_Y_SERVO_WARNING_CODE", ValueKind.Code);
        var connection = _readConnectionState();
        if (CurrentPosition == position && CurrentSpeed == speed && Busy == busy && AlarmCode == alarm && WarningCode == warning && _connectionState == connection) return;
        _connectionState = connection;
        (CurrentPosition, CurrentSpeed, Busy, AlarmCode, WarningCode) = (position, speed, busy, alarm, warning);
        NotifyStateChanged();

        ST_MANUAL_MOF_STAGE_VALUE Read(string id, ValueKind kind)
        {
            var row = map.FirstOrDefault(item => string.Equals(item.Id, id, StringComparison.OrdinalIgnoreCase));
            if (row is null || !row.Use) return Missing;
            if (row.Access == EN_MELSEC_ACCESS.Write || row.PollMs <= 0)
                return new("미설정", "읽기용 주기 폴링이 설정되어 있지 않습니다.");
            if (!snapshot.TryGetValue(id, out var cached)) return new("대기", "MELSEC 수신 대기 중입니다.");
            var message = $"{row.Address} · {CMelsecCachePresentation.Describe(cached)}";
            if (!cached.IsValid)
                return new(cached.State switch
                {
                    EN_MELSEC_CACHE_STATE.Pending => "대기",
                    EN_MELSEC_CACHE_STATE.Offline => "OFFLINE",
                    EN_MELSEC_CACHE_STATE.Stale => "STALE",
                    _ => "ERR"
                }, message);
            var value = CMelsecCachePresentation.NumericValue(cached.Value);
            value = row.DataType switch
            {
                EN_MELSEC_DATA_TYPE.Word or EN_MELSEC_DATA_TYPE.DWord or EN_MELSEC_DATA_TYPE.Double or EN_MELSEC_DATA_TYPE.Float => value,
                _ => double.NaN
            };
            if (!double.IsFinite(value)) return new("ERR", message + " · 숫자 형식 오류");
            return kind switch
            {
                ValueKind.Flag when value is 0 or 1 => new(value == 1 ? "ON" : "OFF", message, Value: value),
                ValueKind.Flag => new("UNKNOWN", message + $" · Busy 값: {value}"),
                ValueKind.Code when value >= 0 && value == Math.Truncate(value) =>
                    new(value.ToString("0", CultureInfo.InvariantCulture), message, value != 0, value),
                ValueKind.Code => new("ERR", message + " · 상태 코드 형식 오류"),
                _ => new(value.ToString("F3", CultureInfo.InvariantCulture), message, Value: value)
            };
        }
    }

    private static double? ParseTarget(string? value) =>
        double.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out var number) && double.IsFinite(number)
            ? number : null;
    private static string FormatTarget(double? value) => value?.ToString("F3", CultureInfo.InvariantCulture) ?? "미설정";
    private void NotifyStateChanged()
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(null));
        MoveCommand.NotifyCanExecuteChanged();
        StopCommand.NotifyCanExecuteChanged();
    }
    private enum ValueKind { Number, Flag, Code }
}

public sealed record ST_MANUAL_MOF_STAGE_VALUE(string Text, string Message, bool IsActive = false, double? Value = null);
