using System.Windows;
using Drilling.Common.Correction;
using Drilling.Common.Managers;
using Drilling.Common.Recipe;
using Drilling.UI.Popup;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuCorrection
{
    private async Task ExecuteAlignOffsetAction(string action, Func<string, string, bool>? confirm = null,
        Action<string, string>? completed = null, Action<CAlignOffsetViewerPanel>? showViewer = null,
        Func<ST_ALIGN_OFFSET_TOLERANCE_CHECK, bool>? resolveExceeded = null)
    {
        confirm ??= (title, message) => CRecipeConfirmDialog.ShowConfirmation(title, message,
            action == "OFFSET_INIT" ? "초기화" : "적용", useDangerStyle: action == "OFFSET_INIT");
        completed ??= (title, message) => CRecipeConfirmDialog.ShowCompletion(title, message);
        resolveExceeded ??= review => new CAlignOffsetToleranceDialog(review) { Owner = Application.Current?.MainWindow }.ShowDialog() == true;
        var recipe = await LoadSelectedOutputViewerRecipe(CancellationToken.None, fallbackToFirst: false)
            ?? throw new InvalidOperationException("현재 선택된 레시피가 없습니다.");
        AlignDistortion.Update(recipe);
        var tolerance = RefreshAlignOffsetTolerance();
        if (action == "OFFSET_VIEW")
        {
            var settings = _settingManager.LoadSection(EN_SETTING_TAB.Option)
                .Concat(_settingManager.LoadSection(EN_SETTING_TAB.Motor)).ToArray();
            var parameters = BuildOutputViewerParameterMap(recipe, settings);
            var cellCount = int.Parse(parameters["MAX_CELL_NUMBER"], System.Globalization.CultureInfo.InvariantCulture);
            var viewer = new CAlignOffsetViewerPanel(recipe, parameters,
                cellNo => BuildOutputViewerGlassPreview(parameters, cellCount, cellNo));
            if (showViewer is not null) showViewer(viewer);
            else new CAlignOffsetViewerDialog(viewer) { Owner = Application.Current?.MainWindow }.ShowDialog();
            return;
        }
        if (action == "OFFSET_APPLY" && tolerance is null)
            throw new InvalidOperationException("Setting > Option > Interlock의 Align Offset Tolerance를 확인해 주세요.");
        var inputSignature = AlignDistortion.OffsetInputSignature;
        var model = action == "OFFSET_APPLY" ? AlignDistortion.CreateLoadedInterpolationModel() : null;
        var calculatedOffsets = await Task.Run(() => action == "OFFSET_APPLY"
            ? CAlignShotOffsetData.Calculate(recipe, model!) : CAlignShotOffsetData.ZeroValues(recipe));
        var offsets = calculatedOffsets;
        await EnsureAlignOffsetRecipeUnchanged(recipe);
        if (action == "OFFSET_APPLY" && inputSignature != AlignDistortion.OffsetInputSignature)
            throw new InvalidOperationException("계산 중 키 선택 또는 Load 값이 변경되었습니다. 다시 Apply해 주세요.");
        var title = action == "OFFSET_APPLY" ? "Offset Apply" : "Offset Init";
        var message = action == "OFFSET_APPLY"
            ? $"Lagrange 알고리즘 방식으로 전체 {offsets.Count:N0}개 Shot에 Align Offset을 적용하시겠습니까?\n기존 Align Offset은 새 계산값으로 대체됩니다."
            : $"전체 {offsets.Count:N0}개 Shot의 저장된 Align Offset X/Y를 0.000으로 초기화하시겠습니까?\n이 작업은 되돌릴 수 없습니다.";
        var check = action == "OFFSET_APPLY" ? CAlignOffsetTolerance.Check(tolerance!.Value, calculatedOffsets) : null;
        if (check is { ExceededShots.Count: > 0 })
        {
            if (!resolveExceeded(check) || !check.CanApplyRemaining)
            {
                _statusReporter("Align Offset 적용을 취소했습니다. 기존 레시피 값은 유지됩니다.");
                return;
            }
            // Filter whole records, never individual X/Y values.
            offsets = calculatedOffsets.Where(shot => !CAlignOffsetTolerance.Exceeds(shot, check.Tolerance)).ToArray();
        }
        else if (!confirm(title, message)) return;
        await EnsureAlignOffsetRecipeUnchanged(recipe);
        if (action == "OFFSET_APPLY" && inputSignature != AlignDistortion.OffsetInputSignature)
            throw new InvalidOperationException("키 선택 또는 Load 값이 변경되었습니다. 다시 Apply해 주세요.");
        if (action == "OFFSET_APPLY" && RefreshAlignOffsetTolerance() != tolerance)
            throw new InvalidOperationException("확인 중 Align Offset Tolerance가 변경되었습니다. 다시 Apply해 주세요.");
        var logFile = _alignOffsetLogFile ?? throw new InvalidOperationException("Align Offset 로그 저장 경로가 설정되지 않았습니다.");
        // Capture raw inputs before any await; UI selections may change during file I/O.
        var includedKeys = AlignDistortion.LoadKeyNames.ToHashSet(StringComparer.Ordinal);
        var keyLog = AlignDistortion.Keys.Select(key =>
        {
            var correction = action == "OFFSET_INIT" ? new ST_ALIGN_CORRECTION(0, 0)
                : model!.Contains(key.GlassX, key.GlassY) ? model.Evaluate(key.GlassX, key.GlassY) : (ST_ALIGN_CORRECTION?)null;
            if (correction is { } result)
                correction = new ST_ALIGN_CORRECTION(CAlignShotOffsetData.RoundValue(result.X), CAlignShotOffsetData.RoundValue(result.Y));
            return new ST_ALIGN_OFFSET_KEY_LOG(key.Name, includedKeys.Contains(key.Name), key.GlassX, key.GlassY,
                key.BaseRawX, key.BaseRawY, key.LastLoadRawX, key.LastLoadRawY, correction?.X, correction?.Y);
        }).ToArray();
        var excluded = check?.ExceededShots ?? [];
        var excludedKeys = excluded.Select(shot => (shot.CellNo, shot.ShotName)).ToHashSet();
        var previousValues = recipe.Parameters.ToDictionary(parameter => parameter.Key, parameter => parameter.Value, StringComparer.OrdinalIgnoreCase);
        var savedOffsets = calculatedOffsets.Select(shot => !excludedKeys.Contains((shot.CellNo, shot.ShotName)) ? shot : shot with
        {
            X = CAlignShotOffsetData.ReadValue(previousValues, CAlignShotOffsetData.ParameterKey(shot.CellNo, shot.ShotName, "X")),
            Y = CAlignShotOffsetData.ReadValue(previousValues, CAlignShotOffsetData.ParameterKey(shot.CellNo, shot.ShotName, "Y"))
        }).ToArray();
        var log = new ST_ALIGN_OFFSET_LOG(recipe.Id, recipe.Name, action == "OFFSET_INIT", default,
            AlignDistortion.LastLoadedAt, AlignDistortion.LastLoadIsSimulation, keyLog, savedOffsets)
        {
            Tolerance = action == "OFFSET_APPLY" ? tolerance : null,
            CalculatedOffsets = calculatedOffsets,
            ExcludedOffsets = excluded
        };
        var updated = CAlignShotOffsetData.Apply(recipe, offsets);
        await _recipeManager.SaveRecipe(updated);
        Exception? logError = null;
        try { await logFile.Save(log with { ChangedAt = DateTimeOffset.Now }); }
        catch (Exception exception) { logError = exception; }
        var current = await LoadSelectedOutputViewerRecipe(CancellationToken.None, fallbackToFirst: false);
        AlignDistortion.Update(current);
        await _refreshCurrentScreen();
        if (logError is not null)
            throw new InvalidOperationException($"레시피의 Align Offset {(action == "OFFSET_APPLY" ? "저장" : "초기화")}은 완료됐지만 CSV 로그를 저장하지 못했습니다.\n{logError.Message}", logError);
        var resultMessage = action == "OFFSET_INIT" ? $"{recipe.Name} 레시피의 전체 Shot Align Offset을 0.000으로 초기화했습니다."
            : $"{recipe.Name}: {offsets.Count:N0}개 Shot Align Offset을 저장했습니다." +
              (excluded.Count > 0 ? $"\nTolerance 초과 {excluded.Count:N0}개 Shot의 X/Y는 모두 기존 저장값을 유지했습니다." : "");
        _statusReporter(resultMessage);
        completed($"{title} 완료", resultMessage);
    }

    private double? RefreshAlignOffsetTolerance()
    {
        double? tolerance;
        try
        {
            tolerance = CAlignOffsetTolerance.Parse(_settingManager.GetValue(EN_SETTING_TAB.Option,
                CAlignOffsetTolerance.SettingKey, "0.500"));
        }
        catch (InvalidOperationException) { tolerance = null; }
        AlignDistortion.UpdateOffsetTolerance(tolerance);
        return tolerance;
    }

    private async Task EnsureAlignOffsetRecipeUnchanged(ST_RECIPE_DEFINITION expected)
    {
        var current = await LoadSelectedOutputViewerRecipe(CancellationToken.None, fallbackToFirst: false);
        if (current is null || !current.Id.Equals(expected.Id, StringComparison.OrdinalIgnoreCase) ||
            current.Parameters.Count != expected.Parameters.Count)
            throw new InvalidOperationException("현재 레시피가 변경되었습니다. Offset 작업을 다시 실행해 주세요.");
        var values = current.Parameters.ToDictionary(parameter => parameter.Key, parameter => parameter.Value, StringComparer.OrdinalIgnoreCase);
        if (expected.Parameters.Any(parameter => !values.TryGetValue(parameter.Key, out var value) || parameter.Value != value))
            throw new InvalidOperationException("현재 레시피 값이 변경되었습니다. Offset 작업을 다시 실행해 주세요.");
    }
}
