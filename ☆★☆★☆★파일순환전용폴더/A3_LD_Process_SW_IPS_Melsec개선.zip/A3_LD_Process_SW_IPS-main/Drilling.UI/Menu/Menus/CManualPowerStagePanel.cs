﻿using System.ComponentModel;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Windows.Media;
using System.Windows.Threading;
using Drilling.Common.Interface;
using Drilling.Common.Motion;

namespace Drilling.UI.Menu.Menus;

public sealed class CManualPowerStagePanel : INotifyPropertyChanged
{
    private readonly Func<IReadOnlyList<ST_MOTOR_STATUS_ITEM>> _readCachedStatus;
    private readonly Func<EN_COMM_STATE> _readConnectionState;
    private readonly Func<string, bool> _confirm;
    private readonly Action<string> _warn;
    private readonly CManualStageMotionSimulation _simulation;
    private readonly DispatcherTimer _animation;
    private EN_COMM_STATE _connectionState = EN_COMM_STATE.Offline;
    private bool _active;
    private bool _measurementRunning;
    private bool _confirming;
    private int _generation;
    private bool _reserved;
    public event PropertyChangedEventHandler? PropertyChanged;
    public IReadOnlyList<CManualPowerStageAxis> Axes { get; }
    public CButtonCommand StopCommand { get; }
    public string Mode => _connectionState switch { EN_COMM_STATE.Simulation => "SIMULATION", EN_COMM_STATE.Online => "MELSEC ONLINE", _ => "MELSEC OFFLINE" };
    public Brush ModeBackground => _connectionState switch
    {
        EN_COMM_STATE.Simulation => CStatusBrush.Simul,
        EN_COMM_STATE.Online => CStatusBrush.Online,
        _ => CStatusBrush.Offline
    };
    public bool IsSimulation => _connectionState == EN_COMM_STATE.Simulation;
    public bool CanMove => IsSimulation && _active && !_measurementRunning && !_confirming && !_simulation.IsReserved;
    public bool CanEdit => !_measurementRunning && !_confirming && !_simulation.IsReserved;
    public string StatusText => _connectionState == EN_COMM_STATE.Offline ? "MELSEC 연결 대기" :
        !IsSimulation ? "현재값 표시 · 실제 이동 연결 대기" :
        _simulation.IsReserved ? "SIMULATION · MOF 진행 중" :
        _measurementRunning ? "SIMULATION · PowerMeasure 진행 중" : "SIMULATION · JOG 속도 5 mm/sec";

    public CManualPowerStagePanel(Func<IReadOnlyList<ST_MOTOR_STATUS_ITEM>> readCachedStatus,
        Action<string> warn, Func<string, bool> confirm, CManualStageMotionSimulation? simulation = null,
        Func<EN_COMM_STATE>? readConnectionState = null)
    {
        _readCachedStatus = readCachedStatus; _warn = warn; _confirm = confirm;
        _readConnectionState = readConnectionState ?? (() => EN_COMM_STATE.Offline);
        _simulation = simulation ?? new();
        Axes = [new(this, EN_MANUAL_STAGE_AXIS.StageY, "Stage Y", "Stage Y"), new(this, EN_MANUAL_STAGE_AXIS.ReviewX, "Review X", "Review X")];
        StopCommand = new(_ => Stop(), _ => IsSimulation);
        // This timer animates local simulation only; MELSEC feedback is read from the shared cache by Refresh.
        _animation = new(DispatcherPriority.Background) { Interval = TimeSpan.FromMilliseconds(100) };
        _animation.Tick += (_, _) => Refresh();
        Refresh();
    }

    public void SetActive(bool active)
    {
        if (_active == active) return;
        _active = active;
        if (!active)
        {
            // Hide controls without cancelling an accepted ABS/REL move. JOG still
            // requires a held button, and pending confirmations cannot outlive the tab.
            _generation++;
            _simulation.StopJog();
        }
        UpdateCommands(); Refresh();
    }

    public void SetMeasurementRunning(bool running)
    {
        if (_measurementRunning == running) return;
        _measurementRunning = running;
        if (running) Stop();
        UpdateCommands();
    }

    public void Refresh()
    {
        if (_reserved != _simulation.IsReserved) { _reserved = _simulation.IsReserved; UpdateCommands(); }
        var connectionState = _readConnectionState();
        if (connectionState != _connectionState)
        {
            Stop(); _connectionState = connectionState;
            Notify(nameof(Mode)); Notify(nameof(ModeBackground)); Notify(nameof(IsSimulation)); UpdateCommands();
        }
        if (IsSimulation) { RefreshSimulation(); return; }
        if (_connectionState == EN_COMM_STATE.Offline)
        {
            foreach (var axis in Axes) axis.SetFeedback("—", "—", "MELSEC 연결 안 됨", "MELSEC 연결 안 됨");
            return;
        }
        var snapshot = _readCachedStatus();
        foreach (var axis in Axes)
        {
            var value = snapshot.FirstOrDefault(item => item.Name == axis.SnapshotName);
            axis.SetFeedback(value?.Position ?? "—", value?.Speed ?? "—",
                value?.PositionMessage ?? "현재 위치 미설정", value?.SpeedMessage ?? "현재 속도 미설정");
        }
    }

    private void RefreshSimulation()
    {
        if (!IsSimulation) { _animation.Stop(); return; }
        var snapshot = _simulation.GetSnapshot();
        foreach (var axis in Axes)
        {
            var value = snapshot.Single(item => item.Axis == axis.Axis);
            axis.SetFeedback(value.Position.ToString("F3", CultureInfo.InvariantCulture), value.Speed.ToString("F3", CultureInfo.InvariantCulture),
                "시뮬레이션 위치 (실장비 값 아님)", "시뮬레이션 속도 (실장비 값 아님)");
        }
        if (snapshot.All(axis => axis.Speed == 0)) _animation.Stop();
    }

    internal void Move(CManualPowerStageAxis axis, bool relative)
    {
        Refresh();
        if (!CanMove) return;
        var text = relative ? axis.Relative : axis.Absolute;
        if (!double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out var value) || !double.IsFinite(value))
        { _warn($"{axis.Name}: 올바른 이동값을 입력해 주세요."); return; }
        var speedText = relative ? axis.RelativeSpeed : axis.AbsoluteSpeed;
        if (!double.TryParse(speedText, NumberStyles.Float, CultureInfo.InvariantCulture, out var speed) || !double.IsFinite(speed) || speed <= 0)
        { _warn($"{axis.Name}: 이동 속도는 0보다 큰 숫자로 입력해 주세요. (mm/sec)"); return; }
        var generation = _generation;
        _confirming = true; UpdateCommands();
        bool accepted;
        try { accepted = _confirm($"[SIMULATION] {axis.Name}\n{(relative ? "REL 이동 거리" : "ABS 목표 위치")}: {value:G} mm\n이동 속도: {speed:G} mm/sec\n\n이동하시겠습니까?"); }
        finally { _confirming = false; UpdateCommands(); }
        Refresh();
        if (!accepted || !CanMove || generation != _generation) return;
        try { _simulation.Move(axis.Axis, value, relative, speed); _animation.Start(); RefreshSimulation(); }
        catch (ArgumentException error) { _warn(error.Message); }
    }

    public bool StartJog(string direction)
    {
        Refresh();
        if (!CanMove) return false;
        var target = direction switch
        {
            "Y+" => (EN_MANUAL_STAGE_AXIS.StageY, 1), "Y-" => (EN_MANUAL_STAGE_AXIS.StageY, -1),
            "X-" => (EN_MANUAL_STAGE_AXIS.ReviewX, -1), "X+" => (EN_MANUAL_STAGE_AXIS.ReviewX, 1),
            _ => (EN_MANUAL_STAGE_AXIS.StageY, 0)
        };
        if (target.Item2 == 0) return false;
        try { _simulation.StartJog(target.Item1, target.Item2); _animation.Start(); RefreshSimulation(); return true; }
        catch (InvalidOperationException error) { _warn(error.Message); return false; }
    }

    public void Stop()
    {
        _generation++; _simulation.Stop(); _animation.Stop();
        if (IsSimulation) RefreshSimulation();
    }

    private void UpdateCommands()
    {
        Notify(nameof(CanMove)); Notify(nameof(CanEdit)); Notify(nameof(StatusText));
        foreach (var axis in Axes) { axis.AbsoluteCommand.NotifyCanExecuteChanged(); axis.RelativeCommand.NotifyCanExecuteChanged(); }
        StopCommand.NotifyCanExecuteChanged();
    }
    private void Notify([CallerMemberName] string? name = null) => PropertyChanged?.Invoke(this, new(name));
}

public sealed class CManualPowerStageAxis : INotifyPropertyChanged
{
    private string _absolute = "0.000", _relative = "0.000";
    private string _absoluteSpeed = "5.000", _relativeSpeed = "5.000";
    public event PropertyChangedEventHandler? PropertyChanged;
    public EN_MANUAL_STAGE_AXIS Axis { get; }
    public string Name { get; }
    internal string SnapshotName { get; }
    public string Absolute { get => _absolute; set { _absolute = value; Notify(); } }
    public string Relative { get => _relative; set { _relative = value; Notify(); } }
    public string AbsoluteSpeed { get => _absoluteSpeed; set { _absoluteSpeed = value; Notify(); } }
    public string RelativeSpeed { get => _relativeSpeed; set { _relativeSpeed = value; Notify(); } }
    public string Position { get; private set; } = "—";
    public string Speed { get; private set; } = "—";
    public string PositionMessage { get; private set; } = "";
    public string SpeedMessage { get; private set; } = "";
    public CButtonCommand AbsoluteCommand { get; }
    public CButtonCommand RelativeCommand { get; }
    public CManualPowerStageAxis(CManualPowerStagePanel panel, EN_MANUAL_STAGE_AXIS axis, string name, string snapshotName)
    {
        Axis = axis; Name = name; SnapshotName = snapshotName;
        AbsoluteCommand = new(_ => panel.Move(this, false), _ => panel.CanMove);
        RelativeCommand = new(_ => panel.Move(this, true), _ => panel.CanMove);
    }
    internal void SetFeedback(string position, string speed, string positionMessage, string speedMessage)
    {
        if (Position == position && Speed == speed && PositionMessage == positionMessage && SpeedMessage == speedMessage) return;
        Position = position; Speed = speed; PositionMessage = positionMessage; SpeedMessage = speedMessage;
        foreach (var name in new[] { nameof(Position), nameof(Speed), nameof(PositionMessage), nameof(SpeedMessage) }) Notify(name);
    }
    private void Notify([CallerMemberName] string? name = null) => PropertyChanged?.Invoke(this, new(name));
}
