using Drilling.UI.Popup;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuReview
{
    private void RequestOpenCorrectionReview(Func<string, string, bool>? confirm = null)
    {
        if (!OpenCorrectionReviewCommand.CanExecute(null)) return;
        confirm ??= (title, message) => CRecipeConfirmDialog.ShowConfirmation(title, message, "OK");
        if (confirm("화면 이동", "SIMPLE/ROUGH/FINE 보정 및 검사 화면으로 이동하시겠습니까?") &&
            OpenCorrectionReviewCommand.CanExecute(null))
            _openCorrectionReview?.Invoke();
    }

    private async Task RequestReviewStart(Func<string, string, bool>? confirm = null)
    {
        if (!StartCommand.CanExecute(null)) return;
        confirm ??= (title, message) => CRecipeConfirmDialog.ShowConfirmation(title, message, "시작");
        var detail = IsBeamInspectionMode
            ? $"선택 Shot {_selectedInspectionShotKeys.Count:N0}개 / Beam {_selectedInspectionBeamNos.Count}개"
            : $"{_selectedInspectionMethod} / Beam{_selectedRunBeamNo}";
        if (!confirm($"{_selectedMode} 검사 시작", $"Recipe: {_recipeId}\n{detail}\n\n{_selectedMode} 검사를 시작하시겠습니까?")) return;
        await StartReviewSequence();
    }

    private void RequestReviewStop(Func<string, string, bool>? confirm = null)
    {
        if (!StopCommand.CanExecute(null)) return;
        if (IsAllShotReviewMode || IsBeamInspectionMode)
        {
            confirm ??= (title, message) => CRecipeConfirmDialog.ShowConfirmation(title, message, "중지", useDangerStyle: true);
            if (!confirm($"{_selectedMode} 검사 중지", $"{_selectedMode} 검사를 중지하시겠습니까?")) return;
        }
        StopReviewSequence();
    }
}
