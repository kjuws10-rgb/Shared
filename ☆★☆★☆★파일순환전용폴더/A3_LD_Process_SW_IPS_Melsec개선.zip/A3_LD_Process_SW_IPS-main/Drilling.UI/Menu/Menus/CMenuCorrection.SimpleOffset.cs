using System.Globalization;
using System.Windows;
using Drilling.Common.Managers;
using Drilling.Common.Recipe;
using Drilling.Common.Review;
using Drilling.UI.Popup;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuCorrection
{
    private async Task ExecuteSimpleOffsetAction(string action, Func<string, string, bool>? confirm = null,
        Action<string, string>? completed = null, Action<string, string>? warn = null,
        Action<CAlignOffsetViewerPanel>? showViewer = null)
    {
        if (_isReviewOperationRunning || action is not ("OFFSET_APPLY" or "OFFSET_INIT" or "OFFSET_VIEW")) return;
        var title = action switch { "OFFSET_INIT" => "Offset Init", "OFFSET_VIEW" => "Cur Review Offset View", _ => "Offset Apply" };
        confirm ??= (caption, message) => CRecipeConfirmDialog.ShowConfirmation(caption, message,
            action == "OFFSET_INIT" ? "초기화" : "적용", useDangerStyle: action == "OFFSET_INIT");
        completed ??= (caption, message) => CRecipeConfirmDialog.ShowCompletion(caption, message);
        warn ??= (caption, message) => CRecipeConfirmDialog.ShowWarning(caption, message);
        _isReviewOperationRunning = true;
        ExecuteCommand.NotifyCanExecuteChanged();
        Simple.SetOffsetOperationRunning(true);
        Fine.SetOperationRunning(true);
        try
        {
            var request = action == "OFFSET_VIEW" ? null : Simple.CreateOffsetChange(action == "OFFSET_INIT");
            var recipe = await LoadSelectedOutputViewerRecipe(CancellationToken.None, fallbackToFirst: false)
                ?? throw new InvalidOperationException("현재 선택된 레시피가 없습니다.");
            var settings = LoadSimpleOffsetSettings();
            if (action == "OFFSET_VIEW")
            {
                var saved = await Task.Run(() => _reviewOffsetFile.LoadLatest(recipe.Id));
                var parameters = BuildOutputViewerParameterMap(recipe, settings);
                CReviewOffsetData.ApplyToParameters(parameters, saved);
                var cellCount = int.Parse(parameters["MAX_CELL_NUMBER"], CultureInfo.InvariantCulture);
                var viewer = new CAlignOffsetViewerPanel(recipe, parameters,
                    cellNo => BuildOutputViewerGlassPreview(parameters, cellCount, cellNo), reviewOffsets: true);
                if (showViewer is not null) showViewer(viewer);
                else new CAlignOffsetViewerDialog(viewer) { Owner = Application.Current?.MainWindow }.ShowDialog();
                return;
            }
            EnsureSimpleOffsetSource(request!, recipe, settings);
            var message = $"현재 레시피: {recipe.Name}\n대상: {request!.Scope} / {request.Rows.Count:N0} Shot\n" +
                $"Design Offset: X {request.X:0.000} / Y {request.Y:0.000} mm\n\n" +
                (action == "OFFSET_INIT" ? "해당 범위의 Review Offset X/Y를 모두 0.000으로 초기화하시겠습니까?"
                    : "해당 범위의 모든 Shot을 입력한 X/Y 값으로 덮어쓰시겠습니까?") +
                "\n선택 범위 밖의 값은 유지하고 새 REVIEW OFFSET 파일을 생성합니다.";
            if (!confirm(title, message)) return;
            recipe = await LoadSelectedOutputViewerRecipe(CancellationToken.None, fallbackToFirst: false)
                ?? throw new InvalidOperationException("현재 선택된 레시피가 없습니다.");
            EnsureSimpleOffsetSource(request, recipe, LoadSimpleOffsetSettings());
            var result = await Task.Run(async () =>
            {
                var latest = await _reviewOffsetFile.LoadLatest(recipe.Id);
                if (!latest.RecipeId.Equals(recipe.Id, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("Review Offset 파일의 레시피가 일치하지 않습니다.");
                var rows = new Dictionary<(int Cell, string Shot), ST_REVIEW_OFFSET_ROW>();
                foreach (var row in latest.Rows.Concat(request.Rows))
                {
                    var shot = NormalizeReviewOffsetShotId(row.ShotId);
                    rows[(row.CellId, shot)] = row with { ShotId = shot };
                }
                return await _reviewOffsetFile.SaveNew(recipe.Id,
                    rows.Values.OrderBy(row => row.CellId).ThenBy(row => row.ShotId, StringComparer.Ordinal).ToArray());
            });
            _simpleOffsetRecipeId = result.RecipeId;
            _simpleOffsetLoad = Task.FromResult(result);
            Simple.AcceptSavedOffsets(result, request.Rows, recipe, settings);
            Rough.Update(recipe, settings, result);
            var resultMessage = $"{request.Scope} / {request.Rows.Count:N0} Shot의 Review Offset을 " +
                (action == "OFFSET_INIT" ? "0.000으로 초기화했습니다." : "입력값으로 저장했습니다.") + $"\n{result.FileName}";
            _statusReporter(resultMessage);
            completed($"{title} 완료", resultMessage);
        }
        catch (Exception exception)
        {
            _statusReporter($"{title}: {exception.Message}");
            warn(title, exception.Message);
        }
        finally
        {
            _isReviewOperationRunning = false;
            Simple.SetOffsetOperationRunning(false);
            Fine.SetOperationRunning(false);
            ExecuteCommand.NotifyCanExecuteChanged();
        }
    }

    private ST_SYSTEM_PARAMETER[] LoadSimpleOffsetSettings() => _settingManager.LoadSection(EN_SETTING_TAB.Option)
        .Concat(_settingManager.LoadSection(EN_SETTING_TAB.Motor)).ToArray();

    private static void EnsureSimpleOffsetSource(ST_SIMPLE_OFFSET_CHANGE request, ST_RECIPE_DEFINITION recipe,
        IReadOnlyList<ST_SYSTEM_PARAMETER> settings)
    {
        var parameters = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var item in recipe.Parameters.Where(item => !string.IsNullOrWhiteSpace(item.Key))) parameters[item.Key] = item.Value;
        foreach (var item in settings.Where(item => !string.IsNullOrWhiteSpace(item.Key))) parameters[item.Key] = item.Value;
        foreach (var key in parameters.Keys.Where(key => key.Contains("REVIEW_OFFSET", StringComparison.OrdinalIgnoreCase)).ToArray()) parameters.Remove(key);
        if (!recipe.Id.Equals(request.RecipeId, StringComparison.OrdinalIgnoreCase) || parameters.Count != request.SourceParameters.Count ||
            request.SourceParameters.Any(item => !parameters.TryGetValue(item.Key, out var value) || item.Value != value))
            throw new InvalidOperationException("레시피 또는 Head 설정이 변경되었습니다. 화면을 확인한 후 Offset 작업을 다시 실행해 주세요.");
    }
}
