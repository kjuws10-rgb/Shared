using System.Globalization;
using Drilling.Common.Interface;
using Drilling.Common.Threading;

namespace Drilling.UI.Menu.Menus;

internal sealed class CManualStageMotionPollingService(CMelsec melsec) : CtrlThread
{
    private static readonly TimeSpan PollInterval = TimeSpan.FromSeconds(1);
    private readonly object _snapshotLock = new();
    private IReadOnlyDictionary<string, ST_MANUAL_STAGE_MOTION_VALUE> _snapshot = new Dictionary<string, ST_MANUAL_STAGE_MOTION_VALUE>(StringComparer.OrdinalIgnoreCase);
    private IReadOnlyList<ST_MANUAL_STAGE_AXIS> _axes = [];

    public void SelectAxes(IReadOnlyList<ST_MANUAL_STAGE_AXIS> axes)
    {
        lock (_snapshotLock)
        {
            _axes = axes.ToArray();
        }
    }

    public void Start()
    {
        base.Start((int)PollInterval.TotalMilliseconds, "ManualStageMotionPolling");
    }

    public IReadOnlyDictionary<string, ST_MANUAL_STAGE_MOTION_VALUE> GetSnapshot()
    {
        lock (_snapshotLock)
        {
            return _snapshot;
        }
    }

    public override void Run()
    {
        IReadOnlyList<ST_MANUAL_STAGE_AXIS> axes;
        lock (_snapshotLock)
        {
            axes = _axes;
        }

        var cachedValues = melsec.GetCachedSnapshot();
        var values = new Dictionary<string, ST_MANUAL_STAGE_MOTION_VALUE>(StringComparer.OrdinalIgnoreCase);
        foreach (var axis in axes)
        {
            if (string.IsNullOrWhiteSpace(axis.ReadPositionId))
            {
                continue;
            }

            if (!cachedValues.TryGetValue(axis.ReadPositionId, out var cached) || cached.State == EN_MELSEC_CACHE_STATE.Pending)
            {
                values[axis.Key] = new ST_MANUAL_STAGE_MOTION_VALUE("-", "-", "WAIT", "Waiting for configured MELSEC feedback.");
                continue;
            }

            // Every numeric cache type already includes READ_SCALE from the common collector.
            var position = CMelsecCachePresentation.NumericValue(cached.Value);
            if (!cached.IsValid || !double.IsFinite(position))
            {
                values[axis.Key] = new ST_MANUAL_STAGE_MOTION_VALUE(
                    "ERR",
                    "-",
                    cached.IsValid ? "ERROR" : cached.State.ToString().ToUpperInvariant(),
                    cached.IsValid ? $"{axis.ReadPositionId} has invalid numeric feedback." : CMelsecCachePresentation.Describe(cached));
                continue;
            }

            values[axis.Key] = new ST_MANUAL_STAGE_MOTION_VALUE(
                FormatDouble(position), "-", "OK", CMelsecCachePresentation.Describe(cached));
        }

        lock (_snapshotLock)
        {
            _snapshot = values;
        }
    }

    private static string FormatDouble(double value)
    {
        return double.IsFinite(value)
            ? value.ToString("F3", CultureInfo.InvariantCulture)
            : "-";
    }
}

internal sealed record ST_MANUAL_STAGE_MOTION_VALUE(
    string Position,
    string Speed,
    string State,
    string Message);
