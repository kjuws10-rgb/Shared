using Drilling.Common.Managers;
using Drilling.Common.Station;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuManual
{
    private Func<ST_STATION_PROCESS_STATUS, IReadOnlyDictionary<string, string>, CancellationToken,
        IReadOnlyList<ST_AUTOMATION_CONTROLLER_STATUS_ITEM>>? _readAutomationStatus;
    private IReadOnlyDictionary<string, string> _automationStatusParameters = new Dictionary<string, string>();
    public IReadOnlyList<ST_AUTOMATION_CONTROLLER_STATUS_ITEM> AutomationControllerStatusItems { get; private set; } = [];

    internal void ConfigureAutomationStatusReader(Func<ST_STATION_PROCESS_STATUS, IReadOnlyDictionary<string, string>, CancellationToken,
        IReadOnlyList<ST_AUTOMATION_CONTROLLER_STATUS_ITEM>> read) => _readAutomationStatus = read;

    private void SetAutomationStatusInputs(ST_RECIPE_DEFINITION? recipe, IReadOnlyList<ST_SYSTEM_PARAMETER> settings)
    {
        var parameters = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        if (recipe is not null)
            foreach (var item in recipe.Parameters.Where(item => !string.IsNullOrWhiteSpace(item.Key))) parameters[item.Key] = item.Value;
        foreach (var item in settings.Where(item => !string.IsNullOrWhiteSpace(item.Key))) parameters[item.Key] = item.Value;
        _automationStatusParameters = parameters;
    }

    private void RefreshAutomationStatusSnapshot()
    {
        if (_readAutomationStatus is null) return;
        var next = _readAutomationStatus(_manager.Station().GetStatus(), _automationStatusParameters, CancellationToken.None);
        if (AutomationControllerStatusItems.Count == next.Count && AutomationControllerStatusItems.Zip(next).All(pair =>
            pair.First.AutomationNo == pair.Second.AutomationNo && pair.First.State == pair.Second.State &&
            pair.First.CpuUsagePercent == pair.Second.CpuUsagePercent && pair.First.Detail == pair.Second.Detail &&
            pair.First.Tasks.SequenceEqual(pair.Second.Tasks))) return;
        AutomationControllerStatusItems = next;
        OnPropertyChanged(nameof(AutomationControllerStatusItems));
    }
}
