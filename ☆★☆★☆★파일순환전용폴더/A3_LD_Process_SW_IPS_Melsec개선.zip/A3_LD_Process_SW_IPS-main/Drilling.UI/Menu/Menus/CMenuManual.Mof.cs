using System.IO;
using System.Text.RegularExpressions;
using System.Windows;
using Drilling.Common.Managers;
using Drilling.UI.Popup;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuManual
{
    private bool _mofDisableBusy;

    private async Task DisableControllerMof(object? parameter)
    {
        if (parameter is not ST_MANUAL_HEAD_GROUP group || _mofDisableBusy) return;
        var commandName = $"CONTROLLER_{group.AutomationNo + 1}_MOF_DISABLE";
        if (TryBlockManualAutomationCommand(commandName)) return;
        _mofDisableBusy = true;
        try
        {
            var simulation = _manager.automation.IsSimul(group.AutomationNo);
            if (!simulation && !_manager.automation.IsConnect(group.AutomationNo))
                throw new InvalidOperationException($"{group.Title} Automation 장비가 연결되어 있지 않습니다.");

            var settings = _manager.Setting().LoadSection(EN_SETTING_TAB.Option);
            IReadOnlyList<string> axes = simulation
                ? BuildControllerHomeTasks(settings, group.AutomationNo)
                    .SelectMany(task => task.AxisReferences).Distinct(StringComparer.OrdinalIgnoreCase).ToArray()
                : await _manager.automation.ReadControllerAxes(group.AutomationNo);
            axes = FilterMofAxes(axes, settings, group.AutomationNo);
            if (axes.Count == 0) throw new InvalidOperationException("컨트롤러에 표시할 축이 없습니다.");
            var dialog = new CMofDisableDialog(group.Title, axes) { Owner = Application.Current?.MainWindow };
            if (dialog.ShowDialog() != true) return;
            if (TryBlockManualAutomationCommand(commandName)) return;

            var selected = dialog.SelectedAxes;
            // Re-read the live controller list before creating any executable script.
            var currentAxes = simulation ? axes : await _manager.automation.ReadControllerAxes(group.AutomationNo);
            currentAxes = FilterMofAxes(currentAxes, _manager.Setting().LoadSection(EN_SETTING_TAB.Option), group.AutomationNo);
            if (selected.Any(axis => !currentAxes.Contains(axis, StringComparer.OrdinalIgnoreCase)))
                throw new InvalidOperationException("컨트롤러 축 구성이 변경되었습니다. 창을 다시 열어 선택하세요.");
            var taskStatus = await _manager.automation.ReadTaskStatus(1, group.AutomationNo);
            var fields = taskStatus.Split(':');
            if (fields.Length < 4 || fields[0] != "OK" || fields[1] != "TASK" || fields[2] != "1" ||
                !(fields[3].Equals("Idle", StringComparison.OrdinalIgnoreCase) || fields[3].Equals("ProgramComplete", StringComparison.OrdinalIgnoreCase)))
                throw new InvalidOperationException($"Task 1이 실행 가능한 대기 상태가 아닙니다. {taskStatus}");

            var lines = BuildMofDisableScriptLines(selected);
            var script = _scriptFile.Create("MANUAL_MOF_DISABLE.ascript");
            foreach (var line in lines) script.AddLine(line);
            var saved = script.Save();
            CancelStatusPolling();
            _lastCommand = commandName;
            _lastResult = "Running Task 1";
            RefreshCommandStateRows();
            var upload = await _manager.automation.UploadScript(saved.FilePath, saved.FileName, group.AutomationNo);
            EnsureAutomationResponse(upload, "MOF Disable upload");
            var response = await _manager.automation.RunScriptIfIdle(saved.FileName, 1, group.AutomationNo);
            EnsureAutomationResponse(response, "MOF Disable run Task 1");
            using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(30));
            var polling = CreateStatusPollingCancellation(timeout.Token);
            try
            {
                await WaitManualTaskCompleted(response, requireExecutionStart: false,
                    automationNo: group.AutomationNo, taskNo: 1, cancellationToken: polling.Token);
            }
            finally
            {
                ReleaseStatusPollingCancellation(polling);
            }
            _lastResult = "MOF Disable completed";
            var message = $"{group.Title} MOF 해제 완료: {string.Join(", ", selected)}";
            _setStatusMessage(message);
            CRecipeConfirmDialog.ShowCompletion("MOF Disable", message);
        }
        catch (OperationCanceledException)
        {
            _lastResult = "MOF Disable completion check cancelled";
            _setStatusMessage("MOF 해제 완료 확인이 중단되었습니다. 컨트롤러의 Task 1 상태를 확인하세요.");
        }
        catch (Exception exception)
        {
            _lastResult = $"ERROR: {exception.Message}";
            _setStatusMessage($"{group.Title} MOF 해제 실패: {exception.Message}");
            CRecipeConfirmDialog.ShowWarning("MOF Disable 실패", exception.Message);
        }
        finally
        {
            _mofDisableBusy = false;
            RefreshCommandStateRows();
            _refreshShellStatus();
            await _refreshCurrentScreen();
        }
    }

    internal static IReadOnlyList<string> FilterMofAxes(IReadOnlyList<string> axes, IReadOnlyList<ST_SYSTEM_PARAMETER> settings, int automationNo)
    {
        var zAxes = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        for (var head = 1; head <= 8; head++)
        {
            if (ReadManualHeadAutomationNo(settings, head) != automationNo) continue;
            foreach (var setting in settings.Where(item =>
                item.Key.Equals($"H{head:00}_SCANNER_Z_AXIS", StringComparison.OrdinalIgnoreCase) ||
                item.Key.Equals($"H{head:00}_Z_AXIS", StringComparison.OrdinalIgnoreCase)))
                zAxes.Add(setting.Value.Trim());
        }
        return axes.Where(axis => !zAxes.Contains(axis.Trim()) &&
            !Regex.IsMatch(axis.Trim(), @"\AG?Z(?:_?[0-9]+)?\z", RegexOptions.IgnoreCase)).ToArray();
    }

    internal static IReadOnlyList<string> BuildMofDisableScriptLines(IReadOnlyList<string> selectedAxes)
    {
        if (selectedAxes.Count == 0) throw new InvalidDataException("MOF를 해제할 축을 선택하세요.");
        var lines = new List<string> { "Program" };
        foreach (var axis in selectedAxes.Distinct(StringComparer.OrdinalIgnoreCase))
        {
            if (!Regex.IsMatch(axis, @"\A(?:[A-Za-z_][A-Za-z0-9_]*|[0-9]+)\z"))
                throw new InvalidDataException($"스크립트에서 사용할 수 없는 축 이름입니다: {axis}");
            lines.Add($"GalvoEncoderScaleFactorSet({axis}, 0)");
        }
        lines.Add("End");
        return lines;
    }
}
