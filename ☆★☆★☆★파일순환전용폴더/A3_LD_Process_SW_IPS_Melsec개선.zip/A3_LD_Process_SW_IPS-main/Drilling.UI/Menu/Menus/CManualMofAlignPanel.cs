using System.ComponentModel;
using System.Globalization;
using Drilling.Common.Interface;

namespace Drilling.UI.Menu.Menus;

public sealed class CManualMofAlignPanel : INotifyPropertyChanged
{
    public const string RequestId = "PROCESS_DO_ALIGN";
    public const string AvailableId = "SDC_DO_ALIGN_STATUS";
    public const string CompleteId = "SDC_DO_ALIGN_COMPLETE";
    private readonly CMelsec _melsec;
    private readonly Func<bool> _confirm;
    private readonly Action<string> _warning;
    private readonly Action<string> _status;
    private readonly Func<bool> _isBlocked;
    private bool _busy;

    public CManualMofAlignPanel(CMelsec melsec, Func<bool> confirm, Action<string> warning,
        Action<string> status, Func<bool> isBlocked)
    {
        (_melsec, _confirm, _warning, _status, _isBlocked) = (melsec, confirm, warning, status, isBlocked);
        RequestCommand = new CButtonCommand(async _ => await RequestAsync(), _ => CanRequest);
        CancelRequestCommand = new CButtonCommand(async _ => await CancelRequestAsync(), _ => !_busy);
    }

    public event PropertyChangedEventHandler? PropertyChanged;
    public CButtonCommand RequestCommand { get; }
    public CButtonCommand CancelRequestCommand { get; }
    public ST_MANUAL_MOF_ALIGN_STATE Availability { get; private set; } = Pending;
    public ST_MANUAL_MOF_ALIGN_STATE Completion { get; private set; } = Pending;
    public ST_MANUAL_MOF_ALIGN_STATE Request { get; private set; } = Pending;
    public bool IsRequested => Request.IsActive;
    public bool CanRequest => !_busy && Availability.IsActive;
    private static ST_MANUAL_MOF_ALIGN_STATE Pending => new("대기", "MELSEC 수신 대기 중입니다.");

    // Display shared readback only. These status boxes do not infer Stage completion from our write.
    public void UpdateSnapshot(IReadOnlyList<ST_MELSEC_MAP_DATA> map,
        IReadOnlyDictionary<string, ST_MELSEC_CACHED_VALUE> snapshot)
    {
        var available = Read(AvailableId, "가능", "불가능");
        var complete = Read(CompleteId, "완료", "미완료");
        var request = Read(RequestId, "ON", "OFF");
        if (Availability == available && Completion == complete && Request == request) return;
        var couldRequest = CanRequest;
        (Availability, Completion, Request) = (available, complete, request);
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(null));
        if (couldRequest != CanRequest) RequestCommand.NotifyCanExecuteChanged();

        ST_MANUAL_MOF_ALIGN_STATE Read(string id, string onText, string offText)
        {
            var row = map.FirstOrDefault(item => item.Id.Equals(id, StringComparison.OrdinalIgnoreCase));
            if (row is not { Use: true } || row.Access == EN_MELSEC_ACCESS.Write || row.PollMs <= 0)
                return new("미설정", "읽기용 MELSEC 맵이 설정되어 있지 않습니다.");
            if (!snapshot.TryGetValue(id, out var sample)) return Pending;
            var message = $"{row.Address} · {CMelsecCachePresentation.Describe(sample)}";
            if (!sample.IsValid)
                return new(sample.State switch
                {
                    EN_MELSEC_CACHE_STATE.Pending => "대기",
                    EN_MELSEC_CACHE_STATE.Offline => "OFFLINE",
                    EN_MELSEC_CACHE_STATE.Stale => "STALE",
                    _ => "ERR"
                }, message);
            var value = CMelsecCachePresentation.NumericValue(sample.Value);
            // Every numeric cache value already includes READ_SCALE from the shared collector.
            value = row.DataType switch
            {
                EN_MELSEC_DATA_TYPE.Word or EN_MELSEC_DATA_TYPE.DWord or EN_MELSEC_DATA_TYPE.Double or EN_MELSEC_DATA_TYPE.Float => value,
                _ => double.NaN
            };
            if (!double.IsFinite(value))
                return new("ERR", message + " · 상태값 형식 오류");
            var active = value == 1;
            var text = id == RequestId && !active && value != 0 ? "UNKNOWN" : active ? onText : offText;
            return new(text, message + " · 스케일 적용값: " + value.ToString("G", CultureInfo.InvariantCulture), active);
        }
    }

    public async Task RequestAsync()
    {
        if (_busy || _isBlocked()) return;
        RefreshSnapshot();
        if (!Availability.IsActive) return;
        SetBusy(true);
        try
        {
            if (!_confirm() || _isBlocked()) return;
            // A modal confirmation can remain open while the Stage becomes unavailable.
            RefreshSnapshot();
            if (!Availability.IsActive)
            {
                const string message = "현재 ALIGN이 불가능한 상태입니다. ALIGN 가능 상태를 확인해 주세요.";
                _status(message);
                _warning(message);
                return;
            }
            // WriteWord serializes the complete two-word Int32 through the existing MELSEC worker.
            await Task.Run(() => _melsec.WriteWord(RequestId, 1));
            _status("STAGE PC에 얼라인을 요청했습니다.");
        }
        catch (Exception exception)
        {
            var message = $"STAGE PC 얼라인 요청 실패: {exception.Message}";
            _status(message);
            _warning(message);
        }
        finally
        {
            RefreshSnapshot();
            SetBusy(false);
        }
    }

    public async Task CancelRequestAsync()
    {
        if (_busy || _isBlocked()) return;
        // Clearing our request must remain possible when the Stage is no longer available.
        SetBusy(true);
        try
        {
            await Task.Run(() => _melsec.WriteWord(RequestId, 0));
            _status("STAGE PC 얼라인 요청을 해제했습니다.");
        }
        catch (Exception exception)
        {
            var message = $"STAGE PC 얼라인 요청 해제 실패: {exception.Message}";
            _status(message);
            _warning(message);
        }
        finally
        {
            RefreshSnapshot();
            SetBusy(false);
        }
    }

    private void SetBusy(bool busy)
    {
        _busy = busy;
        RequestCommand.NotifyCanExecuteChanged();
        CancelRequestCommand.NotifyCanExecuteChanged();
    }

    private void RefreshSnapshot()
    {
        var snapshot = _melsec.GetCachedSnapshot(out var map);
        UpdateSnapshot(map, snapshot);
    }
}

public sealed record ST_MANUAL_MOF_ALIGN_STATE(string Text, string Message, bool IsActive = false);
