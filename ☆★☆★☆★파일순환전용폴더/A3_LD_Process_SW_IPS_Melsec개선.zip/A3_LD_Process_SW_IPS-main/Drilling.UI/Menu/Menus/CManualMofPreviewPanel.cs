using System.ComponentModel;
using System.Windows.Media;
using Drilling.Common.Managers;

namespace Drilling.UI.Menu.Menus;

// A view-only model that follows Manual Head Select without reading devices.
public sealed class CManualMofPreviewPanel : INotifyPropertyChanged
{
    private readonly HashSet<int> _selectedHeadNos = [];
    private IReadOnlyDictionary<string, string> _parameters = new Dictionary<string, string>();
    private ST_PREVIEW_HEAD_LAYOUT? _layout;
    private IReadOnlyList<int> _enabledHeadNos = [];

    public event PropertyChangedEventHandler? PropertyChanged;
    public IReadOnlyList<ST_HEAD_PREVIEW> OddHeadPreviews { get; private set; } = [];
    public IReadOnlyList<ST_HEAD_PREVIEW> EvenHeadPreviews { get; private set; } = [];
    public IReadOnlyList<ST_HEAD_ASSIGNMENT_AREA> HeadAssignmentAreas { get; private set; } = [];
    public ST_GLASS_PREVIEW_FRAME GlassFrame { get; private set; } = new(44, 62, 772, 420);
    // Fit the Glass and its key/head labels, rather than the empty 860 x 520 drawing surface.
    // All geometry retains its original design coordinates; only the displayed crop changes.
    public double PreviewContentWidth => GlassFrame.Width + 48;
    public double PreviewContentHeight => GlassFrame.Height + 56;
    public double PreviewContentLeft => 24 - GlassFrame.CanvasLeft;
    public double PreviewContentTop => 32 - GlassFrame.CanvasTop;
    public string GlassPreviewSummary { get; private set; } = "No recipe loaded";
    public ImageSource? RecipePreviewImage { get; private set; }
    public IReadOnlyList<ST_CELL_PREVIEW_LABEL> CellPreviewLabels { get; private set; } = [];

    public void Update(ST_RECIPE_DEFINITION? recipe, IReadOnlyList<ST_SYSTEM_PARAMETER> settings)
    {
        var parameters = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        if (recipe is not null)
            foreach (var parameter in recipe.Parameters.Where(item => !string.IsNullOrWhiteSpace(item.Key)))
                parameters[parameter.Key] = parameter.Value;
        foreach (var setting in settings.Where(item => !string.IsNullOrWhiteSpace(item.Key)))
            parameters[setting.Key] = setting.Value;

        var layout = CHeadAssignmentPreviewBuilder.BuildHeadLayout(settings);
        if (_layout is not null && _layout.Fields.SequenceEqual(layout.Fields) &&
            _parameters.Count == parameters.Count && parameters.All(item =>
                _parameters.TryGetValue(item.Key, out var value) && value == item.Value)) return;

        _parameters = parameters;
        _layout = layout;
        _enabledHeadNos = CHeadAssignmentPreviewBuilder.BuildEnabledHeadNumbers(parameters);
        Rebuild();
    }

    public void SetSelectedHeads(IEnumerable<int> headNos)
    {
        var selection = headNos.Where(headNo => headNo is >= 1 and <= 8).ToHashSet();
        if (_selectedHeadNos.SetEquals(selection)) return;
        _selectedHeadNos.Clear();
        _selectedHeadNos.UnionWith(selection);
        Rebuild();
    }

    private void Rebuild()
    {
        if (_layout is null) return;
        var selectedHeadNos = _selectedHeadNos.Intersect(_enabledHeadNos).ToHashSet();
        var preview = CHeadAssignmentPreviewBuilder.BuildRecipePreview(_parameters, selectedHeadNos, _layout);
        GlassFrame = preview.Frame;
        RecipePreviewImage = preview.Image;
        CellPreviewLabels = preview.CellLabels;
        HeadAssignmentAreas = CHeadAssignmentPreviewBuilder.BuildHeadAssignmentMap(_parameters, selectedHeadNos, _layout)
            .Areas.Select(area => area with { PointCount = (int)Math.Min(int.MaxValue, preview.HeadPointCounts.GetValueOrDefault(area.HeadNo)) }).ToArray();
        GlassPreviewSummary = string.IsNullOrWhiteSpace(preview.ValidationMessage)
            ? $"{HeadAssignmentAreas.Count}H / {preview.TotalPointCount:N0}P / {CHeadAssignmentPreviewBuilder.FormatGlassSizeText(_parameters)}" +
              (preview.UnassignedPointCount > 0 ? $" / U:{preview.UnassignedPointCount:N0}" : "")
            : preview.ValidationMessage;
        var heads = Enumerable.Range(1, 8).Select(headNo => new ST_HEAD_PREVIEW(
            headNo, $"HEAD {headNo:00}", "IDLE", selectedHeadNos.Contains(headNo), _enabledHeadNos.Contains(headNo))
            { AssignedShotCount = preview.HeadPointCounts.GetValueOrDefault(headNo) }).ToArray();
        OddHeadPreviews = heads.Where(head => head.HeadNo % 2 == 1).ToArray();
        EvenHeadPreviews = heads.Where(head => head.HeadNo % 2 == 0).ToArray();
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(null));
    }
}
