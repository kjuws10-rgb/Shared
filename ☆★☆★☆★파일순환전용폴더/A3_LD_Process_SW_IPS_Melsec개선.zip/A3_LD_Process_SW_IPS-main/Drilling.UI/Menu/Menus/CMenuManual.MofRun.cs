﻿using System.Globalization;
using System.Windows;
using Drilling.Common.Managers;
using Drilling.Common.Station;
using Drilling.UI.Popup;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuManual
{
    private CManualMofRunPanel? _mofRun;
    private readonly Func<(double X, double Y)> _manualMofShiftOffsetProvider;
    public CManualMofRunPanel MofRun => _mofRun ??= new(
        (parameters, heads) => _manager.Station().GetManualInterlockItems(parameters, heads),
        group => new CInterlockDetailsDialog(group) { Owner = Application.Current?.MainWindow }.ShowDialog(),
        _setStatusMessage, RunManualMof, StopManualMof, () => _manager.Station().ManualMofStatus);

    private async void RunManualMof()
    {
        if (MofRun.IsBusy || TryBlockManualAutomationCommand("MANUAL_MOF_RUN")) return;
        if (_powerMeasurePanel?.IsRunning == true) { ShowManualWarning("PowerMeasure 완료 후 실행해 주세요."); return; }
        var heads = SelectedManualHeadNos.ToHashSet();
        MofRun.SetRequesting(true);
        SelectHeadCommand.NotifyCanExecuteChanged();
        SelectManualHeadsCommand.NotifyCanExecuteChanged();
        try
        {
            var recipe = await LoadSelectedRecipe(CancellationToken.None);
            if (recipe is null || !recipe.Id.Equals(_selectedRecipeIdProvider(), StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("현재 선택한 Recipe를 불러올 수 없습니다.");
            MofRun.SetInputs(recipe, _manager.Setting().LoadSection(EN_SETTING_TAB.Option), heads);
            MofRun.Refresh();
            if (MofRun.State != "OK") throw new InvalidOperationException("Interlock/Safety를 확인해 주세요.");
            var shift = _manualMofShiftOffsetProvider();
            var parameters = recipe.Parameters.Where(item => !string.IsNullOrWhiteSpace(item.Key))
                .GroupBy(item => item.Key, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(group => group.Key, group => group.Last().Value, StringComparer.OrdinalIgnoreCase);
            parameters["SHIFT_OFFSET_X"] = shift.X.ToString("0.000000", CultureInfo.InvariantCulture);
            parameters["SHIFT_OFFSET_Y"] = shift.Y.ToString("0.000000", CultureInfo.InvariantCulture);
            if (!CRecipeConfirmDialog.ShowConfirmation("MOF Run", $"선택한 Head {string.Join(", ", heads.Order())}의 MOF 가공을 실행하시겠습니까?\n\nRecipe: {recipe.Name}\nTask 준비 완료 후 현재 Stage Y 위치에서 Glass Size Y만큼 설정 방향으로 이동합니다.")) return;
            if (TryBlockManualAutomationCommand("MANUAL_MOF_RUN")) return;
            var request = new ST_STAGE_PROCESS_REQUEST($"MANUAL_MOF_{DateTime.Now:yyyyMMdd_HHmmss_fff}", recipe.Id, recipe.Name, "", parameters);
            var execution = _manager.Station().RunManualMofAsync(request, heads);
            MofRun.RefreshExecution();
            _refreshShellStatus();
            await execution;
            _setStatusMessage("MOF 가공이 완료되었습니다.");
        }
        catch (OperationCanceledException)
        {
            var stopped = _manager.Station().ManualMofStatus;
            _setStatusMessage(stopped.RequiresStop ? stopped.Message : "MOF 가공을 정지했습니다. Stage 이동은 유지됩니다.");
            if (stopped.RequiresStop) CRecipeConfirmDialog.ShowWarning("MOF STOP", stopped.Message);
        }
        catch (Exception exception)
        {
            _setStatusMessage(exception.Message);
            CRecipeConfirmDialog.ShowWarning("MOF Run", exception.Message);
        }
        finally
        {
            MofRun.SetRequesting(false);
            SelectHeadCommand.NotifyCanExecuteChanged();
            SelectManualHeadsCommand.NotifyCanExecuteChanged();
            _refreshShellStatus();
        }
    }

    private async void StopManualMof()
    {
        try { await _manager.Station().StopManualMofAsync(); }
        catch (Exception exception)
        {
            _setStatusMessage(exception.Message);
            CRecipeConfirmDialog.ShowWarning("MOF STOP", exception.Message);
        }
        finally { MofRun.RefreshExecution(); _refreshShellStatus(); }
    }
}
