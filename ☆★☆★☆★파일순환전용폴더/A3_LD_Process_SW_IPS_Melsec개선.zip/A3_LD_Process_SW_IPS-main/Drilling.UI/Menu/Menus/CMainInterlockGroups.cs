using System.Windows.Media;
using Drilling.Common.InterLock;
using InterlockItem = Drilling.Common.InterLock.ST_INTERLOCK_ITEM;

namespace Drilling.UI.Menu.Menus;

/// <summary>Presentation of the existing interlock snapshot; performs no device reads or new checks.</summary>
public static class CMainInterlockGroups
{
    public static bool IsOk(InterlockItem item) => item.Level == EN_INTERLOCK_LEVEL.Ok && !item.BlocksAutoRun;

    public static IReadOnlyList<ST_INTERLOCK_GROUP> Build(IReadOnlyList<InterlockItem> items)
    {
        var groups = new Dictionary<string, List<ST_INTERLOCK_DETAIL>>(StringComparer.OrdinalIgnoreCase);
        void Add(string name, ST_INTERLOCK_DETAIL detail)
        {
            if (!groups.TryGetValue(name, out var rows)) groups[name] = rows = [];
            rows.Add(detail);
        }

        foreach (var item in items)
        {
            var detail = new ST_INTERLOCK_DETAIL(item.Signal, IsOk(item), item.State, item.Detail);
            var category = Category(item);
            if (category is not null) Add(category, detail);

            // Device rows summarize that device across heads. HEAD rows summarize all checks
            // belonging to one head, using the same checks rather than evaluating them again.
            if (item.HeadNo is > 0) Add($"HEAD {item.HeadNo}", detail);
        }

        return groups.OrderBy(group => Order(group.Key)).ThenBy(group => group.Key, StringComparer.Ordinal)
            .Select(group => new ST_INTERLOCK_GROUP(group.Key, group.Value.ToArray())).ToArray();
    }

    private static string? Category(InterlockItem item)
    {
        if (!string.IsNullOrWhiteSpace(item.Group)) return item.Group.Trim().ToUpperInvariant();
        var name = item.Signal.Trim().ToUpperInvariant();
        if (name.Contains("TILT")) return "TILT";
        if (name.Contains("MELSEC")) return "MELSEC";
        if (name.Contains("BET") || name.Contains("BEAM EXPANDER")) return "BET";
        if (name.Contains("ATT")) return "ATT";
        if (name.Contains("LASER")) return "LASER";
        if (name.Contains("VISION")) return "VISION";
        if (item.HeadNo is > 0) return null;
        if (name.Contains("SCANNER") || name.StartsWith("HEAD")) return "HEAD";
        if (name == "MOTION") return "MOTION";
        if (name is "DOOR" or "EMS" or "KEY SWITCH" or "LEAK SENSOR" or "SMOKE TEMP"
            or "PM LOCK" or "PANEL IN POSITION" or "VACUUM CHECK") return "SAFETY";
        return "SYSTEM";
    }

    private static int Order(string name) => name switch
    {
        "TILT" => 0, "MELSEC" => 1, "BET" => 2, "ATT" => 3,
        "LASER" => 20, "VISION" => 21, "MOTION" => 22, "SAFETY" => 23,
        _ when name.StartsWith("HEAD", StringComparison.Ordinal) =>
            int.TryParse(name.AsSpan(4).Trim(), out var head) ? 4 + head : 4,
        _ => 24
    };
}

public sealed record ST_INTERLOCK_GROUP(string Item, IReadOnlyList<ST_INTERLOCK_DETAIL> Details)
{
    public bool IsOk => Details.Count > 0 && Details.All(detail => detail.IsOk);
    public string State => IsOk ? "OK" : "NOT OK";
    public Brush StateBrush => CStatusBrush.ForDisplayState(IsOk ? "OK" : "NG");
}

public sealed record ST_INTERLOCK_DETAIL(string Item, bool IsOk, string Condition, string Detail)
{
    public string State => IsOk ? "OK" : "NOT OK";
    public Brush StateBrush => CStatusBrush.ForDisplayState(IsOk ? "OK" : "NG");
    public string Description => string.IsNullOrWhiteSpace(Detail) ? Condition : $"{Condition}\n{Detail}";
}
