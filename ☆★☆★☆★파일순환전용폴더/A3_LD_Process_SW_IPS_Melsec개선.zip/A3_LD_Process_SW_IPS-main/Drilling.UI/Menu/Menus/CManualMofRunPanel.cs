﻿using System.ComponentModel;
using System.Windows.Media;
using Drilling.Common.InterLock;
using Drilling.Common.Managers;
using Drilling.Common.Station;

namespace Drilling.UI.Menu.Menus;

public sealed class CManualMofRunPanel : INotifyPropertyChanged
{
    private readonly Func<IReadOnlyDictionary<string, string>, IReadOnlySet<int>, IReadOnlyList<ST_INTERLOCK_ITEM>>? _readSnapshot;
    private readonly Action<ST_INTERLOCK_GROUP> _showList;
    private readonly Action<string> _status;
    private readonly Func<ST_MANUAL_MOF_STATUS>? _execution;
    private bool _requesting;
    public bool IsRunning { get; private set; }
    public bool RequiresStop { get; private set; }
    public bool IsBusy => _requesting || IsRunning;
    public string Message { get; private set; } = "";
    public string ScriptDirectory { get; private set; } = "";
    public IReadOnlyList<CManualMofActionCard> Actions { get; } = CManualMofActionIds.All.Select((id, index) =>
        new CManualMofActionCard(id, $"{index + 1}. " + new[] { "Prepare Data", "Build Script", "Script Upload", "MOF ZeroSet", "Run Task / Ready", "Stage Move / MOF", "Complete" }[index])).ToArray();
    private IReadOnlyDictionary<string, string> _parameters = new Dictionary<string, string>();
    private HashSet<int> _selectedHeads = [];
    private IReadOnlyList<ST_INTERLOCK_ITEM> _items = [];
    private bool _hasSnapshot;

    public CManualMofRunPanel(
        Func<IReadOnlyDictionary<string, string>, IReadOnlySet<int>, IReadOnlyList<ST_INTERLOCK_ITEM>>? readSnapshot = null,
        Action<ST_INTERLOCK_GROUP>? showList = null, Action<string>? status = null,
        Action? run = null, Action? stop = null, Func<ST_MANUAL_MOF_STATUS>? execution = null)
    {
        _readSnapshot = readSnapshot;
        _showList = showList ?? (_ => { });
        _status = status ?? (_ => { });
        InterlockListCommand = new(_ => OpenList());
        _execution = execution;
        RunCommand = new(_ => { if (CanRun) run?.Invoke(); }, _ => CanRun);
        StopCommand = new(_ => stop?.Invoke(), _ => IsRunning || RequiresStop);
    }

    public event PropertyChangedEventHandler? PropertyChanged;
    public CButtonCommand InterlockListCommand { get; }
    public CButtonCommand RunCommand { get; }
    public CButtonCommand StopCommand { get; }
    public string State => _selectedHeads.Count == 0 ? "HEAD 미선택" : !_hasSnapshot ? "대기" :
        _items.Count > 0 && _items.All(CMainInterlockGroups.IsOk) ? "OK" : "NOT OK";
    public Brush StateBackground => State == "OK" ? CStatusBrush.Online : State == "NOT OK" ? CStatusBrush.Offline : CStatusBrush.Wait;
    public bool CanRun => State == "OK" && !IsBusy && !RequiresStop;
    public string SelectionText => _selectedHeads.Count == 0 ? "Head Select에서 Head를 선택해 주세요." :
        "선택 Head: " + string.Join(", ", _selectedHeads.Order().Select(head => head.ToString("00"))) + " / 공통 안전 항목 포함";
    public IReadOnlyList<ST_INTERLOCK_DETAIL> Details => _items.Select(item => new ST_INTERLOCK_DETAIL(
        item.HeadNo is > 0 ? $"HEAD {item.HeadNo:00} / {item.Signal}" : item.Signal,
        CMainInterlockGroups.IsOk(item), item.State, item.Detail)).ToArray();

    public void SetInputs(ST_RECIPE_DEFINITION? recipe, IReadOnlyList<ST_SYSTEM_PARAMETER> settings, IEnumerable<int> selectedHeads)
    {
        var parameters = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        if (recipe is not null)
            foreach (var parameter in recipe.Parameters.Where(item => !string.IsNullOrWhiteSpace(item.Key))) parameters[parameter.Key] = parameter.Value;
        foreach (var setting in settings.Where(item => !string.IsNullOrWhiteSpace(item.Key))) parameters[setting.Key] = setting.Value;
        if (_parameters.Count != parameters.Count || parameters.Any(item => !_parameters.TryGetValue(item.Key, out var value) || value != item.Value))
        {
            _parameters = parameters;
            _hasSnapshot = false;
        }
        SetSelectedHeads(selectedHeads);
        Notify();
    }

    public void SetSelectedHeads(IEnumerable<int> heads)
    {
        var selected = heads.Where(head => head is >= 1 and <= 8).ToHashSet();
        if (_selectedHeads.SetEquals(selected)) return;
        _selectedHeads = selected;
        _items = _items.Where(item => item.HeadNo is not > 0 || selected.Contains(item.HeadNo.Value)).ToArray();
        _hasSnapshot = false;
        Notify();
    }

    public void SetRequesting(bool requesting)
    {
        _requesting = requesting;
        RefreshExecution();
        Notify();
    }

    public void RefreshExecution()
    {
        if (_execution is null) return;
        var snapshot = _execution();
        var changed = IsRunning != snapshot.IsRunning || RequiresStop != snapshot.RequiresStop || Message != snapshot.Message || ScriptDirectory != snapshot.ScriptDirectory;
        IsRunning = snapshot.IsRunning;
        RequiresStop = snapshot.RequiresStop;
        Message = snapshot.Message;
        ScriptDirectory = snapshot.ScriptDirectory;
        foreach (var card in Actions) card.Update(snapshot.Actions.GetValueOrDefault(card.Id));
        if (changed) Notify();
    }

    public void Refresh()
    {
        RefreshExecution();
        if (_readSnapshot is null) return;
        IReadOnlyList<ST_INTERLOCK_ITEM> items;
        try
        {
            items = _readSnapshot(_parameters, _selectedHeads)
                .Where(item => item.HeadNo is not > 0 || _selectedHeads.Contains(item.HeadNo.Value)).ToArray();
            if (items.Count == 0 && _selectedHeads.Count > 0)
                items = [new("Interlock", EN_INTERLOCK_LEVEL.Error, "NO DATA", "인터락 상태를 확인할 수 없습니다.") { BlocksAutoRun = true }];
        }
        catch (Exception exception)
        {
            items = _items.Count > 0 ? _items.Select(item => item with { Level = EN_INTERLOCK_LEVEL.Error,
                State = "READ FAIL", Detail = exception.Message, BlocksAutoRun = true }).ToArray() :
                [new("Interlock", EN_INTERLOCK_LEVEL.Error, "READ FAIL", exception.Message) { BlocksAutoRun = true }];
        }
        if (_hasSnapshot && _items.SequenceEqual(items)) return;
        _items = items;
        _hasSnapshot = true;
        Notify();
    }

    private void OpenList()
    {
        Refresh();
        _showList(new("MOF Interlock", Details));
    }

    private void Notify()
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(null));
        RunCommand.NotifyCanExecuteChanged();
        StopCommand.NotifyCanExecuteChanged();
    }
}

public sealed class CManualMofActionCard(string id, string title) : INotifyPropertyChanged
{
    private ST_SEQUENCE_ACTION_STATUS? _status;
    public event PropertyChangedEventHandler? PropertyChanged;
    public string Id { get; } = id;
    public string Title { get; } = title;
    public bool IsRunning => _status?.State == EN_SEQUENCE_ACTION_STATE.Running;
    public string Detail => _status?.Detail ?? "";
    public string State => (_status?.State ?? EN_SEQUENCE_ACTION_STATE.Waiting) switch
    {
        EN_SEQUENCE_ACTION_STATE.Running => "RUNNING", EN_SEQUENCE_ACTION_STATE.Completed => "DONE",
        EN_SEQUENCE_ACTION_STATE.Error => "ERROR", EN_SEQUENCE_ACTION_STATE.Stopped => "STOPPED", _ => "WAIT"
    };
    public Brush Background => State switch
    {
        "DONE" or "RUNNING" => Brushes.ForestGreen, "ERROR" => Brushes.Firebrick,
        "STOPPED" => Brushes.SlateGray, _ => Brushes.Goldenrod
    };
    public void Update(ST_SEQUENCE_ACTION_STATUS? status)
    {
        if (_status == status) return;
        _status = status;
        PropertyChanged?.Invoke(this, new(null));
    }
}
