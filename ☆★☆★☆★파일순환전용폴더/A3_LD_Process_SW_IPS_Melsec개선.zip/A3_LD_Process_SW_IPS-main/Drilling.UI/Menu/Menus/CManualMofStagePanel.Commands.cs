﻿using System.Windows.Media;
using Drilling.Common.Interface;
using Drilling.Common.Motion;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CManualMofStagePanel
{
    private readonly Func<EN_COMM_STATE> _readConnectionState;
    private readonly Func<CManualStageMotionSimulation>? _simulation;
    private readonly Action _refresh;
    private readonly Func<string, bool> _confirm;
    private readonly Action<string> _warn;
    private readonly Action<string> _status;
    private readonly Func<bool> _isBlocked;
    private EN_COMM_STATE _connectionState;
    private bool _confirming;
    private int _generation;

    public CManualMofStagePanel(Func<EN_COMM_STATE>? readConnectionState = null,
        Func<CManualStageMotionSimulation>? simulation = null, Action? refresh = null,
        Func<string, bool>? confirm = null, Action<string>? warn = null,
        Action<string>? status = null, Func<bool>? isBlocked = null)
    {
        _readConnectionState = readConnectionState ?? (() => EN_COMM_STATE.Offline);
        _simulation = simulation;
        _refresh = refresh ?? (() => { });
        _confirm = confirm ?? (_ => false);
        _warn = warn ?? (_ => { });
        _status = status ?? (_ => { });
        _isBlocked = isBlocked ?? (() => false);
        MoveCommand = new(_ => Move(), _ => CanMove);
        StopCommand = new(_ => Stop(), _ => CanStop);
    }

    public CButtonCommand MoveCommand { get; }
    public CButtonCommand StopCommand { get; }
    public bool CanStop => _simulation is not null && _readConnectionState() == EN_COMM_STATE.Simulation;
    public bool CanMove => CanStop && !_confirming && Busy.Value == 0 && CurrentPosition.Value.HasValue &&
        _targetPosition.HasValue && _targetSpeed is > 0 &&
        !_simulation!().IsReserved && _simulation().GetSnapshot().Single(axis => axis.Axis == EN_MANUAL_STAGE_AXIS.StageY).Speed == 0;
    public string MotionMode => _connectionState switch
    {
        EN_COMM_STATE.Simulation => "SIMULATION",
        EN_COMM_STATE.Online => "실제 이동 연결 대기",
        _ => "MELSEC OFFLINE"
    };
    public Brush ModeBackground => _connectionState switch
    {
        EN_COMM_STATE.Simulation => CStatusBrush.Simul,
        EN_COMM_STATE.Online => CStatusBrush.Online,
        _ => CStatusBrush.Offline
    };

    public void Move()
    {
        _refresh();
        if (!CanMove || _isBlocked()) return;
        var target = _targetPosition!.Value;
        var speed = _targetSpeed!.Value;
        var generation = _generation;
        _confirming = true;
        NotifyStateChanged();
        try
        {
            if (!_confirm($"Stage Y를 READY POSITION으로 이동하시겠습니까?\n\n목표 위치: {target:F3} mm\n이동 속도: {speed:F3} mm/sec")) return;
            _refresh();
            if (generation != _generation || _isBlocked()) return;
            // Recheck shared feedback and the common simulation model after the modal dialog.
            // Another Manual tab may have started motion while the dialog was open.
            if (!CanStop || Busy.Value != 0 || !CurrentPosition.Value.HasValue ||
                _targetPosition != target || _targetSpeed != speed ||
                _simulation!().GetSnapshot().Single(axis => axis.Axis == EN_MANUAL_STAGE_AXIS.StageY).Speed != 0)
            {
                _warn("Stage 상태 또는 목표값이 변경되었습니다. 현재 상태를 확인한 뒤 다시 이동해 주세요.");
                return;
            }
            // TODO: Wire actual MELSEC Ready move/STOP after command addresses are confirmed.
            // Spec 0.04 provides Stage Y feedback but no confirmed processing-PC motion command.
            _simulation!().Move(EN_MANUAL_STAGE_AXIS.StageY, target, relative: false, speed: speed);
            _status($"SIMULATION · Stage Y READY POSITION 이동: {target:F3} mm");
        }
        catch (Exception exception)
        {
            _warn($"Stage Y 이동 실패: {exception.Message}");
        }
        finally
        {
            _confirming = false;
            NotifyStateChanged();
        }
    }

    public void Stop()
    {
        _generation++;
        if (!CanStop) return;
        _simulation!().Stop(EN_MANUAL_STAGE_AXIS.StageY);
        _status("SIMULATION · Stage Y STOP");
        _refresh();
        NotifyStateChanged();
    }
}
