using System.IO;
using Drilling.Common.Managers;

namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuManual
{
    private CManualScanAssignments? _scanAssignments;
    private IReadOnlyList<string> _manualScanSettingNames = [];
    public CManualScanAssignments ScanAssignments => _scanAssignments ??= new();

    private void RefreshManualScanAssignments()
        => ScanAssignments.Update(SelectedManualHeadNos, _manualScanSettingNames, LoadedSettingName);

    private Task<ST_MANUAL_SCAN_PARAM> ReadAssignedManualScanParam(int headNo, CancellationToken cancellationToken)
        => ReadAssignedManualScanParamCore(headNo, cancellationToken, validateShape: true);

    private async Task<ST_MANUAL_SCAN_PARAM> ReadAssignedManualScanParamCore(int headNo, CancellationToken cancellationToken, bool validateShape)
    {
        if (!SelectedManualHeadNos.Contains(headNo)) throw new InvalidDataException("이동할 Head를 먼저 선택해 주세요.");
        var name = ScanAssignments.GetSettingName(headNo);
        var files = await _scanFile.List(cancellationToken);
        var file = files.FirstOrDefault(file => file.Equals(name, StringComparison.OrdinalIgnoreCase));
        if (string.IsNullOrEmpty(file)) throw new InvalidDataException($"HEAD {headNo:00}에 사용할 .scan 파일을 지정해 주세요.");
        var settings = await _scanFile.Load(file, cancellationToken);
        var forms = await _scanFile.LoadForm(cancellationToken);
        if (validateShape) ValidateManualScanParameters(settings, forms);
        else ValidateSavedManualLaserActionSettings(settings);
        return settings;
    }
}
