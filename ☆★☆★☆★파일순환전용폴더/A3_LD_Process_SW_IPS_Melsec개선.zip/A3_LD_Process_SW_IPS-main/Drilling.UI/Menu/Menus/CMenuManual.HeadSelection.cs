namespace Drilling.UI.Menu.Menus;

public sealed partial class CMenuManual
{
    private readonly HashSet<int> _selectedManualHeadNos = [];
    private bool _manualHeadSelectionInitialized;
    private CButtonCommand _selectFocusedHeadCommand = CButtonCommand.NoOp;

    public IReadOnlyList<int> SelectedManualHeadNos => _selectedManualHeadNos.Order().ToArray();
    public CButtonCommand SelectManualHeadsCommand { get; }

    private void SelectManualHeads(object? parameter)
    {
        if (_powerMeasurePanel?.IsRunning == true) return;
        var selection = parameter?.ToString()?.Trim().ToUpperInvariant();
        if (selection is not ("ALL" or "ODD" or "EVEN" or "CLEAR") ||
            !_selectFocusedHeadCommand.CanExecute(null)) return;

        var heads = HeadCards.Where(head => head.IsEnabled && _selectFocusedHeadCommand.CanExecute(head.HeadNo))
            .Where(head => selection == "ALL" || selection == "ODD" && head.HeadNo % 2 == 1 ||
                selection == "EVEN" && head.HeadNo % 2 == 0)
            .Select(head => head.HeadNo).ToArray();
        _manualHeadSelectionInitialized = true;
        _selectedManualHeadNos.Clear();
        _selectedManualHeadNos.UnionWith(heads);
        HeadCards = ApplyManualHeadSelection(HeadCards, _selectedHeadNoProvider());
        HeadGroups = BuildHeadGroups(HeadCards);
        OnPropertyChanged(nameof(HeadCards));
        RefreshManualControllerHeads();
        if (_selectedManualHeadNos.Count > 0 && !_selectedManualHeadNos.Contains(_selectedHeadNoProvider()))
            _selectFocusedHeadCommand.Execute(_selectedManualHeadNos.Min());
    }

    private void ToggleManualHead(object? parameter)
    {
        if (_powerMeasurePanel?.IsRunning == true) return;
        if (!int.TryParse(parameter?.ToString(), out var headNo) ||
            !HeadCards.Any(head => head.HeadNo == headNo && head.IsEnabled) ||
            !_selectFocusedHeadCommand.CanExecute(headNo)) return;

        _manualHeadSelectionInitialized = true;
        if (!_selectedManualHeadNos.Add(headNo)) _selectedManualHeadNos.Remove(headNo);
        HeadCards = ApplyManualHeadSelection(HeadCards, _selectedHeadNoProvider());
        HeadGroups = BuildHeadGroups(HeadCards);
        OnPropertyChanged(nameof(HeadCards));
        RefreshManualControllerHeads();
        if (_selectedManualHeadNos.Contains(headNo))
            _selectFocusedHeadCommand.Execute(headNo);
        else if (_selectedManualHeadNos.Count > 0 && !_selectedManualHeadNos.Contains(_selectedHeadNoProvider()))
            _selectFocusedHeadCommand.Execute(_selectedManualHeadNos.Min());
    }

    private IReadOnlyList<ST_MANUAL_HEAD_CARD> ApplyManualHeadSelection(
        IReadOnlyList<ST_MANUAL_HEAD_CARD> cards, int initialHeadNo)
    {
        var enabled = cards.Where(head => head.IsEnabled).Select(head => head.HeadNo).ToHashSet();
        if (!_manualHeadSelectionInitialized)
        {
            if (enabled.Contains(initialHeadNo)) _selectedManualHeadNos.Add(initialHeadNo);
            _manualHeadSelectionInitialized = true;
        }
        _selectedManualHeadNos.IntersectWith(enabled);
        MofPreview.SetSelectedHeads(_selectedManualHeadNos);
        if (_mofRun is not null)
        {
            _mofRun.SetSelectedHeads(_selectedManualHeadNos);
            if (IsScannerWorkspace && IsManualMofTab) _mofRun.Refresh();
        }
        return cards.Select(head => head with { IsSelected = _selectedManualHeadNos.Contains(head.HeadNo) }).ToArray();
    }
}
