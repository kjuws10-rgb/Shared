using System.ComponentModel;
using Drilling.Common.Alarm;

namespace Drilling.UI.Menu.Menus;

public sealed class CAlarmListPanel : INotifyPropertyChanged
{
    private readonly CAlarmManager _alarms;
    private ST_ALARM_DEFINITION_SNAPSHOT? _displayedSnapshot;
    public CAlarmListPanel(CAlarmManager alarms)
    {
        _alarms = alarms;
        RefreshSnapshot();
    }

    public event PropertyChangedEventHandler? PropertyChanged;
    public IReadOnlyList<ST_ALARM_LIST_ROW> Rows { get; private set; } = [];
    public string Status { get; private set; } = "";
    public bool HasError { get; private set; }

    public void RefreshSnapshot()
    {
        var snapshot = _alarms.GetDefinitionsSnapshot();
        if (ReferenceEquals(snapshot, _displayedSnapshot)) return;
        _displayedSnapshot = snapshot;
        Rows = snapshot.Rows.Select((row, index) => new ST_ALARM_LIST_ROW(index + 1, row.Code, row.Group,
            row.Id, row.Level, row.Cause, row.Solution, row.CimAddress)).ToArray();
        HasError = !string.IsNullOrEmpty(snapshot.Error);
        Status = HasError ? $"알람 목록을 불러오지 못했습니다. {snapshot.Error} 파일 확인 후 프로그램을 다시 시작해 주세요."
            : Rows.Count == 0 ? "등록된 알람이 없습니다." : "";
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Rows)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Status)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(HasError)));
    }

}

public sealed record ST_ALARM_LIST_ROW(int No, int Code, string Group, string Id, string Level,
    string Cause, string Solution, string CimAddress);
