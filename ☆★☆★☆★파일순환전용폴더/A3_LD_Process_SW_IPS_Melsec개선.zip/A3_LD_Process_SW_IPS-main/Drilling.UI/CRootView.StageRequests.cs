using Drilling.Common.Product;
using Drilling.Common.Station;
using Drilling.Common.Managers;
using Drilling.Common.Review;
using Drilling.UI.Menu.Menus;
using Drilling.UI.Menu;

namespace Drilling.UI;

public sealed partial class CRootView
{
    private CAutoFineReviewCoordinator? _autoFineReview;
    private ST_STAGE_REVIEW_ACTIONS CreateAutoReviewActions()
    {
        _autoFineReview ??= new(_reviewManager, _manager.ReviewOffsetFile(), CreateStageReviewInput);
        return new(_autoFineReview.Prepare, _autoFineReview.Measure, _autoFineReview.Save);
    }

    private async Task<ST_AUTO_REVIEW_INPUT> CreateStageReviewInput(CancellationToken token)
    {
        // Called at Stage Review ABLE, before our ABLE. Later UI changes apply to the next request.
        var options = ((CMenuMain)_menus[EN_MENU.Main]).RunOptions.CaptureReviewOptions();
        var current = _stationManager.GetStatus(token).ProcessModel;
        var recipeId = current?.RecipeId ?? _selectedRecipeId;
        var recipe = (await _recipeManager.LoadRecipes(token).ConfigureAwait(false))
            .SingleOrDefault(item => item.Id.Equals(recipeId, StringComparison.OrdinalIgnoreCase))
            ?? throw new InvalidOperationException($"Review Recipe를 찾을 수 없습니다: {recipeId}");
        if (current is not null)
            recipe = recipe with { Parameters = current.Parameters.Select(pair =>
                new ST_RECIPE_PARAMETER(pair.Key, pair.Value, "", "", pair.Value, Key: pair.Key)).ToArray() };
        var glass = current?.GlassId;
        if (string.IsNullOrWhiteSpace(glass))
            glass = (await CreateStageProcessRequest(token).ConfigureAwait(false)).GlassId;
        return new(recipe, glass, options);
    }
    // Invoked only at DoReady START. Does not update UI or call a device read.
    private async Task<ST_STAGE_PROCESS_REQUEST> CreateStageProcessRequest(CancellationToken token)
    {
        var recipeId = _selectedRecipeId;
        var recipes = await _recipeManager.LoadRecipes(token).ConfigureAwait(false);
        var recipe = recipes.SingleOrDefault(value => value.Id.Equals(recipeId, StringComparison.OrdinalIgnoreCase))
            ?? throw new InvalidOperationException($"Selected recipe does not exist: {recipeId}.");
        var now = DateTime.Now;
        var product = _productManager.Current;
        if (product?.State == EN_PRODUCT_STATE.Completed) product = null;
        var glassId = string.IsNullOrWhiteSpace(product?.GlassId)
            ? $"{(IsSimulationEnvironment ? "SIM" : "DUMMY")}_{now:yyyyMMdd_HHmmssfff}" : product.GlassId;
        var lotId = product?.LotId?.Trim() ?? "";
        var parameters = CreateProcessParameters(recipe, glassId, lotId, 0, 0);
        // TODO: replace the existing local product identity fallback when Stage Glass/Lot mapping is agreed.
        return new($"AUTO-{now:yyyyMMddHHmmssfff}-{Guid.NewGuid():N}", recipe.Id, glassId, lotId, parameters);
    }
}
