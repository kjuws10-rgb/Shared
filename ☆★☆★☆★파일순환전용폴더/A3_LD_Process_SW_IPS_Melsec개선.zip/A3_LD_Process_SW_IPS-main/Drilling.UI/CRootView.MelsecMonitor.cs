using System.Windows.Threading;
using Drilling.UI.Menu.Menus;

namespace Drilling.UI;

public sealed partial class CRootView
{
    private DispatcherTimer? _melsecMonitorPresentationTimer;

    private void StartMelsecMonitorPresentation()
    {
        if (_melsecMonitorPresentationTimer is not null) return;
        // This is a presentation cadence, not a PLC polling interval. Keep the
        // existing clock, system status, and other monitor refresh schedules intact.
        _melsecMonitorPresentationTimer = new(DispatcherPriority.Background)
        {
            Interval = TimeSpan.FromMilliseconds(100)
        };
        _melsecMonitorPresentationTimer.Tick += RefreshMelsecMonitorPresentation;
        _melsecMonitorPresentationTimer.Start();
    }

    private void RefreshMelsecMonitorPresentation(object? sender, EventArgs e)
    {
        if (SelectedMenu.Menu != EN_MENU.Monitor || CurrentScreen.Monitor is not { IsMelsec: true } monitor) return;
        try
        {
            // Copies the common receive cache only; no device read, file load,
            // screen rebuild, or system-status refresh is started by this timer.
            monitor.RefreshMelsecPresentation();
        }
        catch (Exception exception)
        {
            ReportClockTickError(exception);
        }
    }

    private void StopMelsecMonitorPresentation()
    {
        var timer = _melsecMonitorPresentationTimer;
        if (timer is null) return;
        void Stop()
        {
            timer.Stop();
            timer.Tick -= RefreshMelsecMonitorPresentation;
            _melsecMonitorPresentationTimer = null;
        }
        if (timer.Dispatcher.CheckAccess()) Stop();
        else timer.Dispatcher.Invoke(Stop);
    }
}
