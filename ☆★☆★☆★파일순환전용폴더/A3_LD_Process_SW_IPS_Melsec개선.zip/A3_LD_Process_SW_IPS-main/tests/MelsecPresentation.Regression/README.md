# MELSEC presentation regression

Equipment-free console checks for the MELSEC UI row model, cache-presentation guards, preservation of write drafts/row objects, timestamp/block diagnostics and XAML/timer structure.

Build the current solution, then run the UI-only regression console:

```powershell
dotnet build Drilling.sln -c Release
dotnet run --project tests/MelsecPresentation.Regression -c Release
```

The console emits JSON and exits nonzero on failure. Do not commit bin/obj output.

No `CRootView`, `App`, device Manager, native API, window or communication worker is started. The monitor is constructed only with null device dependencies for inactive guards and direct in-memory row-application tests. Private row application is invoked by reflection to avoid starting Managers.

The active end-to-end monitor path and real Dispatcher/native-read/paint latency are **not** tested. Static source checks establish that the fast path consumes its own `GetCachedSnapshot` projection (rather than re-reading a shared intermediate UI snapshot) and obtains block diagnostics once without issuing fresh PLC reads. Fixed diagnostic samples verify full-attempt duration, successful update interval, in-flight/unknown values, and the explanatory limits. WRITE-only/disabled rows must not suggest that they are waiting for a periodic read. Real acquisition duration requires separately collected driver diagnostics and field verification.

The existing `CBindingBase` uses WPF property-specific `Changed` events, not `INotifyPropertyChanged`; the suite verifies the existing value/state events and the new timing events, including WPF's `TypeDescriptor` event bridge.
