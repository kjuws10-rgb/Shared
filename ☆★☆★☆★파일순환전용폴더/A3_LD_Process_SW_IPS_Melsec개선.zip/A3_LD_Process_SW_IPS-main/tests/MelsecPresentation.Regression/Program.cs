using System.Collections;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text.Json;
using System.Xml.Linq;
using Drilling.Common.Interface;
using Drilling.UI.Menu.Menus;

internal static class Program
{
    private static readonly List<object> Results = [];
    private static int _failures;
    private static readonly DateTimeOffset Received = new(2026, 10, 30, 5, 0, 0, TimeSpan.Zero);

    [STAThread]
    private static int Main()
    {
        Test("row_identity_and_write_draft_preserved", () =>
        {
            var row = Row();
            var identity = row;
            row.WriteValue = "123.456";
            row.UpdateReadValue("1", "OK", Received, Received.AddMilliseconds(150));
            Equal(identity, row);
            Equal("123.456", row.WriteValue);
            Equal("1", row.ReadValue);
        });
        Test("received_and_presented_timestamps_retained", () =>
        {
            var row = Row();
            var applied = Received.AddMilliseconds(100);
            row.UpdateReadValue("1", "OK", Received, applied);
            Equal<DateTimeOffset?>(Received, row.ReceivedAt);
            Equal<DateTimeOffset?>(applied, row.PresentedAt);
        });
        Test("receive_age_uses_instant_not_timezone_label", () =>
        {
            var row = Row();
            row.UpdateReadValue("1", "OK", Received, Received.AddMilliseconds(150).ToOffset(TimeSpan.FromHours(9)));
            Equal<double?>(150, row.ReceiveAgeMilliseconds);
        });
        Test("same_cached_value_age_advances_with_ui_application", () =>
        {
            var row = Row();
            row.UpdateReadValue("1", "OK", Received, Received.AddMilliseconds(100));
            row.UpdateReadValue("1", "OK", Received, Received.AddMilliseconds(200));
            Equal<double?>(200, row.ReceiveAgeMilliseconds);
        });
        Test("missing_receive_timestamp_is_not_zero_age", () =>
        {
            var row = Row();
            row.UpdateReadValue("-", "WAIT", null, Received);
            Equal<double?>(null, row.ReceiveAgeMilliseconds);
            Require(row.FeedbackTimingDescription.Contains("수신 대기"));
        });
        Test("missing_presentation_timestamp_is_unknown", () =>
        {
            var row = Row();
            row.UpdateReadValue("1", "OK", Received);
            Equal<double?>(null, row.ReceiveAgeMilliseconds);
        });
        Test("negative_clock_difference_reported_not_clamped", () =>
        {
            var row = Row();
            row.UpdateReadValue("1", "OK", Received, Received.AddMilliseconds(-50));
            Equal<double?>(-50, row.ReceiveAgeMilliseconds);
            Require(row.FeedbackTimingDescription.Contains("시계 차이 확인 필요"));
        });
        Test("tooltip_preserves_description_and_feedback_error", () =>
        {
            var row = Row();
            row.UpdateReadValue("ERR", "ERROR", Received, Received.AddMilliseconds(120), "simulated read failure");
            Require(row.FeedbackTimingDescription.Contains("test description"));
            Require(row.FeedbackTimingDescription.Contains("simulated read failure"));
            Require(row.FeedbackTimingDescription.Contains("120 ms"));
        });
        Test("diagnostics_do_not_claim_native_read_or_paint_duration", () =>
        {
            var row = Row();
            row.UpdateReadValue("1", "OK", Received, Received.AddMilliseconds(100));
            Require(row.FeedbackTimingDescription.Contains("ViewModel"));
            Require(row.FeedbackTimingDescription.Contains("PLC 통신 소요시간이 아닙니다"));
        });
        Test("stale_and_error_state_not_converted_to_ok", () =>
        {
            var row = Row();
            row.UpdateReadValue("ERR", "STALE", Received, Received.AddSeconds(5));
            Equal("STALE", row.State);
            Equal("ERR", row.ReadValue);
            Equal<double?>(5000, row.ReceiveAgeMilliseconds);
            row.UpdateReadValue("ERR", "ERROR", null, Received.AddSeconds(6), "unavailable");
            Equal("ERROR", row.State);
            Equal<DateTimeOffset?>(null, row.ReceivedAt);
        });
        Test("read_value_change_notification_once", () =>
        {
            var row = Row();
            var count = 0;
            row.ReadValueChanged += (_, _) => count++;
            row.UpdateReadValue("1", "OK");
            row.UpdateReadValue("1", "OK");
            Equal(1, count);
        });
        Test("state_and_brush_notifications_preserved", () =>
        {
            var row = Row();
            var states = 0;
            var stateBrush = 0;
            var valueBrush = 0;
            row.StateChanged += (_, _) => states++;
            row.StateBrushChanged += (_, _) => stateBrush++;
            row.ValueBrushChanged += (_, _) => valueBrush++;
            row.UpdateReadValue("1", "OK");
            row.UpdateReadValue("ERR", "STALE");
            Equal(2, states);
            Equal(2, stateBrush);
            Equal(2, valueBrush);
        });
        Test("read_refresh_does_not_publish_write_draft_change", () =>
        {
            var row = Row();
            row.WriteValue = "pending";
            var count = 0;
            row.WriteValueChanged += (_, _) => count++;
            row.UpdateReadValue("1", "OK", Received, Received.AddMilliseconds(100));
            Equal("pending", row.WriteValue);
            Equal(0, count);
        });
        Test("all_new_property_specific_notifications_fire", () =>
        {
            var row = Row();
            var received = 0;
            var presented = 0;
            var age = 0;
            var tooltip = 0;
            row.ReceivedAtChanged += (_, _) => received++;
            row.PresentedAtChanged += (_, _) => presented++;
            row.ReceiveAgeMillisecondsChanged += (_, _) => age++;
            row.FeedbackTimingDescriptionChanged += (_, _) => tooltip++;
            row.UpdateReadValue("1", "OK", Received, Received.AddMilliseconds(100));
            Equal(1, received); Equal(1, presented); Equal(1, age); Equal(1, tooltip);
            row.UpdateReadValue("1", "OK", Received, Received.AddMilliseconds(100));
            Equal(1, received); Equal(1, presented); Equal(1, age); Equal(1, tooltip);
        });
        Test("wpf_property_descriptor_receives_tooltip_change", () =>
        {
            var row = Row();
            var property = TypeDescriptor.GetProperties(row)[nameof(row.FeedbackTimingDescription)]!;
            var count = 0;
            EventHandler handler = (_, _) => count++;
            property.AddValueChanged(row, handler);
            try { row.UpdateReadValue("1", "OK", Received, Received.AddMilliseconds(100)); }
            finally { property.RemoveValueChanged(row, handler); }
            Equal(1, count);
        });
        Test("inactive_monitor_fastpath_never_touches_null_device_dependencies", () =>
        {
            var selected = "PRODUCT";
            var monitor = Monitor(() => selected);
            Equal(false, monitor.RefreshMelsecPresentation(Received));
            selected = "MELSEC"; // Accessor alone is not enough: the displayed workspace is still PRODUCT.
            Equal(false, monitor.RefreshMelsecPresentation(Received));
        });
        Test("changed_tab_accessor_blocks_old_melsec_workspace", () =>
        {
            var monitor = Monitor(() => "LASER");
            SetProperty(monitor, nameof(monitor.SelectedTab), "MELSEC");
            Equal(false, monitor.RefreshMelsecPresentation(Received));
        });
        Test("actual_update_method_keeps_rows_lists_and_drafts", () =>
        {
            var monitor = Monitor(() => "PRODUCT");
            var row = Row();
            row.WriteValue = "draft-42";
            var rows = new[] { row };
            SetProperty(monitor, nameof(monitor.MelsecRows), rows);
            var values = Values(row.Id, "7", "OK", "cache sample", Received);
            InvokeUpdate(monitor, values, Received.AddMilliseconds(125));
            Require(ReferenceEquals(rows, monitor.MelsecRows));
            Require(ReferenceEquals(row, monitor.MelsecRows.Single()));
            Equal("7", row.ReadValue);
            Equal("draft-42", row.WriteValue);
            Equal<double?>(125, row.ReceiveAgeMilliseconds);
        });
        Test("actual_update_method_missing_entry_publishes_wait", () =>
        {
            var monitor = Monitor(() => "PRODUCT");
            var row = Row();
            SetProperty(monitor, nameof(monitor.MelsecRows), new[] { row });
            InvokeUpdate(monitor, Values(), Received);
            Equal("WAIT", row.State);
            Equal("-", row.ReadValue);
            Equal<DateTimeOffset?>(null, row.ReceivedAt);
            Equal<DateTimeOffset?>(Received, row.PresentedAt);
        });
        Test("block_diagnostics_report_full_attempt_interval_and_inflight_limits", () =>
        {
            var block = new ST_MELSEC_POLLING_DIAGNOSTIC(0, "W100", 2, 100, ["TEST", "ALIAS"],
                EN_MELSEC_CACHE_STATE.Valid, 2, false, Received.AddMilliseconds(-13), Received,
                Received, 12.5, 115.25);
            var details = DiagnosticDetails([block]);
            Require(ReferenceEquals(details["TEST"], details["ALIAS"]));
            var text = details["TEST"];
            Require(text.Contains("블록 시도 전체 소요 (완료 시): 12.5 ms"));
            Require(text.Contains("성공 갱신 간격 (최근 2회): 115.25 ms"));
            Require(text.Contains("설정 주기: 100 ms"));
            Require(text.Contains("현재 블록 읽는 중: 아니오"));
            var inFlight = block with { IsReading = true, LastAttemptStartedAt = Received.AddMilliseconds(110),
                LastAttemptCompletedAt = null, LastAttemptDurationMs = null };
            var activeText = DiagnosticDetails([inFlight])["TEST"];
            Require(activeText.Contains("현재 블록 읽는 중: 예"));
            Require(activeText.Contains("완료 시간/소요는 미확정"));
            Require(activeText.Contains("블록 시도 전체 소요 (완료 시): 미확정/없음"));
            Require(activeText.Contains("성공 시각/간격은 마지막 성공 기준입니다"));
            Require(activeText.Contains("최근 성공 수집 완료:"));
            Require(text.Contains("순수 네트워크 시간이 아닙니다"));
            Require(text.Contains("Age가 낮아도 수신 주기 준수나 빠른 통신을 뜻하지 않습니다"));
            Require(text.Contains("별도 cache snapshot"));
        });
        Test("first_block_attempt_has_unknown_duration_and_interval", () =>
        {
            var block = new ST_MELSEC_POLLING_DIAGNOSTIC(0, "W100", 2, 100, ["TEST"],
                EN_MELSEC_CACHE_STATE.Pending, 0, false, null, null, null, null, null);
            var text = DiagnosticDetails([block])["TEST"];
            Require(text.Contains("블록 시도 전체 소요 (완료 시): 미확정/없음"));
            Require(text.Contains("성공 갱신 간격 (최근 2회): 없음"));
        });
        Test("diagnostics_append_to_feedback_without_losing_error_or_write_draft", () =>
        {
            var monitor = Monitor(() => "PRODUCT");
            var row = Row();
            row.WriteValue = "pending";
            SetProperty(monitor, nameof(monitor.MelsecRows), new[] { row });
            var details = new Dictionary<string, string> { [row.Id] = "block diagnostic test" };
            InvokeUpdate(monitor, Values(row.Id, "ERR", "ERROR", "read error", Received), Received, details);
            Require(row.FeedbackTimingDescription.Contains("read error"));
            Require(row.FeedbackTimingDescription.Contains("block diagnostic test"));
            Equal("ERROR", row.State);
            Equal("pending", row.WriteValue);
        });
        Test("write_only_and_disabled_rows_do_not_claim_waiting_for_feedback", () =>
        {
            var writeOnly = new ST_MONITOR_MELSEC_ROW("W", "IF", "write", "0", "W100", "WORD", "OUT", "W",
                "1", "1", "1", "100", "-", "7", "WRITE", "write description");
            Require(writeOnly.FeedbackTimingDescription.Contains("write description"));
            Require(writeOnly.FeedbackTimingDescription.Contains("WRITE 전용: 주기 수신 대상 아님"));
            Require(!writeOnly.FeedbackTimingDescription.Contains("수신 대기"));
            var disabled = Row();
            var tooltipChanges = 0;
            disabled.FeedbackTimingDescriptionChanged += (_, _) => tooltipChanges++;
            disabled.UpdateReadValue("-", "DISABLED");
            Require(disabled.FeedbackTimingDescription.Contains("test description"));
            Require(disabled.FeedbackTimingDescription.Contains("비활성"));
            Require(!disabled.FeedbackTimingDescription.Contains("수신 대기"));
            Equal(1, tooltipChanges);
        });

        var root = FindRepository();
        Test("xaml_tooltip_binding_uses_timing_property", () =>
        {
            var xml = XDocument.Load(Path.Combine(root, "Drilling.UI/Views/CMonitorView.xaml"));
            XNamespace x = "http://schemas.microsoft.com/winfx/2006/xaml";
            var style = xml.Descendants().Single(node => (string?)node.Attribute(x + "Key") == "MelsecDescriptionRow");
            Require(style.Descendants().Any(node => ((string?)node.Attribute("Text"))?.Contains("FeedbackTimingDescription") == true));
            Require(!style.Descendants().Any(node => (string?)node.Attribute("Property") == "ToolTipService.IsEnabled"));
        });
        Test("dedicated_timer_is_100ms_and_active_workspace_guarded", () =>
        {
            var source = File.ReadAllText(Path.Combine(root, "Drilling.UI/CRootView.MelsecMonitor.cs"));
            Require(source.Contains("TimeSpan.FromMilliseconds(100)"));
            Require(source.Contains("SelectedMenu.Menu != EN_MENU.Monitor"));
            Require(source.Contains("IsMelsec: true"));
            Require(source.Contains("DispatcherPriority.Background"));
        });
        Test("dedicated_timer_cleanup_unsubscribes_and_stops", () =>
        {
            var timer = File.ReadAllText(Path.Combine(root, "Drilling.UI/CRootView.MelsecMonitor.cs"));
            Require(timer.Contains("timer.Stop();"));
            Require(timer.Contains("timer.Tick -= RefreshMelsecMonitorPresentation"));
            var source = File.ReadAllText(Path.Combine(root, "Drilling.UI/CRootView.cs"));
            Require(Method(source, "public void StopAutomationStatusAcquisition()").Contains("StopMelsecMonitorPresentation();"));
        });
        Test("global_clock_and_other_monitor_cadences_unchanged", () =>
        {
            var source = File.ReadAllText(Path.Combine(root, "Drilling.UI/CRootView.cs"));
            Require(source.Contains("MonitorDefaultRefreshInterval = TimeSpan.FromSeconds(2)"));
            Require(Method(source, "private void StartClock()").Contains("Interval = TimeSpan.FromSeconds(1)"));
            Require(source.Contains("MainLiveStatusRefreshInterval = TimeSpan.FromSeconds(1)"));
        });
        Test("fastpath_call_chain_is_cache_only_static_contract", () =>
        {
            var source = File.ReadAllText(Path.Combine(root, "Drilling.UI/Menu/Menus/CMenuMonitor.cs"));
            var fast = Method(source, "public bool RefreshMelsecPresentation(");
            var apply = Method(source, "private void RefreshMelsecCacheDisplay(");
            Require(fast.Contains("RefreshMelsecCacheDisplay(presentedAt)"));
            Require(apply.Contains("RefreshMelsecNow()"));
            Require(!apply.Contains("ReadWord(") && !apply.Contains("ReadDouble(") && !apply.Contains("RefreshCachedValueAsync("));
            var poller = File.ReadAllText(Path.Combine(root, "Drilling.UI/Menu/Menus/CMonitorStatusPollingService.cs"));
            var poll = Method(poller, "private IReadOnlyDictionary<string, ST_MONITOR_MELSEC_VALUE> PollMelsec(");
            Require(poll.Contains("GetCachedSnapshot(out var mapRows)"));
            Require(!poll.Contains("ReadWord(") && !poll.Contains("ReadDouble(") && !poll.Contains("RefreshCachedValueAsync("));
        });
        Test("fastpath_consumes_own_projection_not_racy_shared_snapshot", () =>
        {
            var source = File.ReadAllText(Path.Combine(root, "Drilling.UI/Menu/Menus/CMenuMonitor.cs"));
            var apply = Method(source, "private void RefreshMelsecCacheDisplay(");
            Require(apply.Contains("var values = _statusPollingService.RefreshMelsecNow();"));
            Require(!apply.Contains("GetSnapshot()"));
            Require(apply.Split("GetPollingDiagnostics()", StringSplitOptions.None).Length == 2);
            var poller = File.ReadAllText(Path.Combine(root, "Drilling.UI/Menu/Menus/CMonitorStatusPollingService.cs"));
            var poll = Method(poller, "private IReadOnlyDictionary<string, ST_MONITOR_MELSEC_VALUE> PollMelsec(");
            Require(poll.Contains("return values;"));
            Require(poller.Contains("public IReadOnlyDictionary<string, ST_MONITOR_MELSEC_VALUE> RefreshMelsecNow()"));
        });
        Test("slow_monitor_refresh_uses_same_melsec_fastpath", () =>
        {
            var source = File.ReadAllText(Path.Combine(root, "Drilling.UI/Menu/Menus/CMenuMonitor.cs"));
            var start = source.IndexOf("if (selectedTab == \"MELSEC\")", source.IndexOf("public Task RefreshLiveData", StringComparison.Ordinal), StringComparison.Ordinal);
            Require(start >= 0);
            var branch = Method(source[start..], "if (selectedTab == \"MELSEC\")");
            Require(branch.Contains("RefreshMelsecPresentation();"));
            Require(branch.Contains("return Task.CompletedTask;"));
        });

        Console.WriteLine(JsonSerializer.Serialize(new
        {
            suite = "MelsecPresentation.Regression",
            checks = Results.Count,
            failures = _failures,
            pass = _failures == 0,
            scope = "Public row model, detached monitor with null device dependencies, and static timer/XAML contracts. No Root/App/Manager instance, worker, window, native API or equipment is started.",
            limitations = new[]
            {
                "The active end-to-end CMenuMonitor fast path requires a real CInterfaceManager; it is not instantiated here. Cache-only call-chain structure is checked instead.",
                "WPF bindings use property-specific Changed events in CBindingBase, not INotifyPropertyChanged. The tooltip event is additionally checked through TypeDescriptor.",
                "No Dispatcher timing, native read duration, or actual screen-paint latency is measured."
            },
            results = Results
        }, new JsonSerializerOptions { WriteIndented = true }));
        return _failures == 0 ? 0 : 1;
    }

    private static ST_MONITOR_MELSEC_ROW Row() => new("TEST", "IF", "test", "0", "W100", "DWORD", "IN", "R", "0.0001", "10000", "2", "100", "-", "", "WAIT", "test description");
    private static CMenuMonitor Monitor(Func<string> selected) => new(null!, null!, null!, null!, null!, null!,
        () => "", selected, _ => { }, _ => { }, () => { }, () => Task.CompletedTask, () => false, Path.GetTempPath());

    private static object Values(string? id = null, string value = "", string state = "", string message = "", DateTimeOffset? receivedAt = null)
    {
        var type = typeof(CMenuMonitor).Assembly.GetType("Drilling.UI.Menu.Menus.ST_MONITOR_MELSEC_VALUE", throwOnError: true)!;
        var dictionary = (IDictionary)Activator.CreateInstance(typeof(Dictionary<,>).MakeGenericType(typeof(string), type))!;
        if (id is not null) dictionary.Add(id, Activator.CreateInstance(type, id, value, state, message, receivedAt));
        return dictionary;
    }
    private static void InvokeUpdate(CMenuMonitor monitor, object values, DateTimeOffset presentedAt,
        IReadOnlyDictionary<string, string>? details = null)
        => typeof(CMenuMonitor).GetMethod("UpdateMelsecReadValues", BindingFlags.Instance | BindingFlags.NonPublic)!.Invoke(monitor, [values, presentedAt, details]);
    private static IReadOnlyDictionary<string, string> DiagnosticDetails(IReadOnlyList<ST_MELSEC_POLLING_DIAGNOSTIC> diagnostics)
        => (IReadOnlyDictionary<string, string>)typeof(CMenuMonitor).GetMethod("CreateMelsecDiagnosticDetails", BindingFlags.Static | BindingFlags.NonPublic)!.Invoke(null, [diagnostics])!;
    private static void SetProperty(object target, string name, object value) => target.GetType().GetProperty(name)!.SetValue(target, value);
    private static string FindRepository()
    {
        var directory = new DirectoryInfo(AppContext.BaseDirectory);
        while (directory is not null)
        {
            if (File.Exists(Path.Combine(directory.FullName, "Drilling.sln"))) return directory.FullName;
            directory = directory.Parent;
        }
        throw new DirectoryNotFoundException("Run this test from a checkout containing Drilling.sln.");
    }
    private static string Method(string source, string marker)
    {
        var start = source.IndexOf(marker, StringComparison.Ordinal);
        if (start < 0) throw new InvalidOperationException($"Source marker not found: {marker}");
        var open = source.IndexOf('{', start);
        var depth = 0;
        for (var index = open; index < source.Length; index++)
        {
            if (source[index] == '{') depth++;
            if (source[index] == '}' && --depth == 0) return source[open..(index + 1)];
        }
        throw new InvalidOperationException($"Unclosed source block: {marker}");
    }
    private static void Test(string name, Action action)
    {
        try { action(); Results.Add(new { name, pass = true }); }
        catch (Exception exception)
        {
            _failures++;
            Results.Add(new { name, pass = false, error = (exception is TargetInvocationException ? exception.InnerException : exception)?.ToString() });
        }
    }
    private static void Require(bool condition) { if (!condition) throw new InvalidOperationException("Assertion failed."); }
    private static void Equal<T>(T expected, T actual)
    {
        if (!EqualityComparer<T>.Default.Equals(expected, actual)) throw new InvalidOperationException($"Expected {expected}; actual {actual}.");
    }
}
