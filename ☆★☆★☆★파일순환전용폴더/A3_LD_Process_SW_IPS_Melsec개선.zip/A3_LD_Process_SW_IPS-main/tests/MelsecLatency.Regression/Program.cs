using System.Collections.Concurrent;
using System.Diagnostics;
using System.Reflection;
using System.Text.Json;
using Drilling.Common.Interface;
using Drilling.File.JHMI;

// Only FakeMelsecApi is instantiated. No UI/CManager/device other than one fake MELSEC.
var baseline = args.Contains("--baseline");
var root = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "../../../../../"));
while (!File.Exists(Path.Combine(root, "Drilling.sln")))
    root = Directory.GetParent(root)?.FullName ?? throw new Exception("Cannot locate repository root.");
var results = new List<object>();
var failures = 0;
async Task Test(string name, Func<Task<object?>> body)
{
    try { results.Add(new { name, passed = true, data = await body() }); }
    catch (Exception error) { failures++; results.Add(new { name, passed = false, error = error.ToString() }); }
}
static void Assert(bool condition, string message) { if (!condition) throw new Exception(message); }
static ST_MELSEC_MAP_DATA Map(string id, string address, EN_MELSEC_DATA_TYPE type = EN_MELSEC_DATA_TYPE.Word,
    EN_MELSEC_ACCESS access = EN_MELSEC_ACCESS.Read, int length = 1, int poll = 100,
    double readScale = 1, double writeScale = 1, int device = 0) =>
    new(id, true, "REGRESSION", id, device, address, type, EN_MELSEC_DIRECTION.InOut,
        access, readScale, writeScale, length, poll, "In-memory fake only");
static async Task Until(Func<bool> condition, int timeout = 4000)
{
    var elapsed = Stopwatch.StartNew();
    while (!condition()) { if (elapsed.ElapsedMilliseconds > timeout) throw new TimeoutException("Regression deadline elapsed."); await Task.Delay(2); }
}
static object Stats(IEnumerable<double> source)
{
    var a = source.Order().ToArray();
    double At(double p) => a.Length == 0 ? double.NaN : a[(int)Math.Ceiling((a.Length - 1) * p)];
    return new { count = a.Length, minMs = a.Length == 0 ? (double?)null : At(0),
        p50Ms = a.Length == 0 ? (double?)null : At(.5), p95Ms = a.Length == 0 ? (double?)null : At(.95),
        maxMs = a.Length == 0 ? (double?)null : At(1) };
}

async Task<object?> Benchmark(int fakeDelayMs, bool spinDelay)
{
    var path = Path.Combine(root, "Config/JHMI_MELSEC_MAP.csv");
    Assert(File.Exists(path), "Fixture map must exist; never generate a production map.");
    var map = new CMelsecMapFile(Path.GetDirectoryName(path)!).LoadAll();
    var api = new FakeMelsecApi { SpinDelay = spinDelay };
    await using var h = await Harness.Open(map, delayMs: fakeDelayMs, api: api);
    var blocks = h.PollBlockCount;
    Assert(blocks == 24, $"Baseline actual map changed: expected 24 blocks, actual {blocks}.");
    h.Api.ClearTrace();
    var ages = new List<double>();
    var elapsed = Stopwatch.StartNew();
    while (elapsed.ElapsedMilliseconds < 1800)
    {
        var snapshot = h.Melsec.GetCachedSnapshot();
        var now = DateTimeOffset.UtcNow;
        foreach (var entry in snapshot.Values)
            if (entry.IsValid && entry.UpdatedAt is { } at) ages.Add((now - at).TotalMilliseconds);
        await Task.Delay(10);
    }
    var receives = h.Api.Trace.Where(call => call.Kind == "RECEIVE").ToArray();
    var intervals = receives.GroupBy(call => (call.DeviceType, call.Address, call.Size)).SelectMany(group =>
        group.OrderBy(call => call.EndMs).Select(call => call.EndMs).Zip(
            group.OrderBy(call => call.EndMs).Select(call => call.EndMs).Skip(1), (a, b) => b - a)).ToArray();
    var arrivals = receives.GroupBy(call => (call.DeviceType, call.Address, call.Size))
        .Select(group => new { group.Key.DeviceType, group.Key.Address, group.Key.Size,
            interval = Stats(group.OrderBy(call => call.EndMs).Select(call => call.EndMs).Zip(
                group.OrderBy(call => call.EndMs).Select(call => call.EndMs).Skip(1), (a, b) => b - a)) }).ToArray();
    Assert(h.Api.Trace.All(call => call.Size <= 1920), "Transfer exceeded 1920 bytes.");
    Assert(h.Api.ThreadIds.Count == 1, "Native fake API used from multiple SDK threads.");
    return new { mapRows = map.Count, blocks, configured100msRows = map.Count(row => row.PollMs == 100),
        fakeReceiveDelayMs = fakeDelayMs, fakeDelayMode = spinDelay ? "Stopwatch busy-wait" : "Thread.Sleep request",
        observedNativeDuration = Stats(receives.Select(call => call.EndMs - call.StartMs)),
        allBlockArrival = Stats(intervals), observationMs = elapsed.ElapsedMilliseconds, perBlockArrival = arrivals,
        cachedAge = Stats(ages), sdkThreadCount = h.Api.ThreadIds.Count,
        uiNote = "Cache age is not UI redraw cadence; baseline UI gates 2000 ms and the UI change is verified separately. No WPF was launched." };
}
await Test("actual-map-poll-arrival-and-cache-age", () => Benchmark(4, false));
await Test("actual-map-fast-zero-delay", () => Benchmark(0, false));
await Test("actual-map-precise-four-ms-delay", () => Benchmark(4, true));

await Test("fixed-control-run-burst", async () =>
{
    var map = Enumerable.Range(0, 24).Select(i => Map($"P{i}", $"D{100 + i * 10}", poll: 10000)).ToArray();
    await using var h = await Harness.Open(map);
    h.Melsec.Pause(); await Task.Delay(30);
    h.Melsec.ReloadMap(map); h.Api.ClearTrace();
    var perRun = new List<int>();
    for (var i = 0; i < 6; i++)
    {
        var before = h.Api.ReceiveCount; h.Melsec.Run(); perRun.Add(h.Api.ReceiveCount - before);
    }
    Assert(perRun.All(x => x <= 4), "One Run exceeded four poll blocks.");
    if (baseline) Assert(perRun[0] == 1, "Baseline observation must use the original one-block Run driver.");
    if (!baseline) Assert(perRun[0] > 1, "Bounded burst did not process multiple ready blocks.");
    return new { baselineObservation = baseline, blocksReadPerRun = perRun, total = perRun.Sum() };
});

await Test("head-read-during-write-readback-wait", async () =>
{
    var map = new[] { Map("WRITE", "D100", access: EN_MELSEC_ACCESS.Write),
        Map("BACK", "D200", poll: 500), Map("HEAD", "D300", poll: 10000) };
    await using var h = await Harness.Open(map);
    h.Melsec.Pause(); await Task.Delay(30);
    var request = h.Melsec.QueueWriteWord("WRITE", 42, "BACK", 1200, 0);
    for (var i = 0; i < 5 && h.Melsec.GetWriteStatus(request)?.Result != EN_MELSEC_WRITE_RESULT.WaitReadback; i++) h.Melsec.Run();
    Assert(h.Melsec.GetWriteStatus(request)?.Result == EN_MELSEC_WRITE_RESULT.WaitReadback, "Write did not enter readback wait.");
    h.Melsec.Run(); // mismatched first read establishes the future readback deadline
    var pending = Task.Run(() => h.Melsec.ReadWordNoLog("HEAD"));
    await Task.Delay(20);
    for (var i = 0; i < 8 && !pending.IsCompleted; i++) { h.Melsec.Run(); await Task.Delay(2); }
    var served = pending.IsCompletedSuccessfully;
    if (baseline) Assert(!served, "Baseline driver changed; original readback starvation was not observed.");
    if (!baseline) Assert(served, "Independent head read was starved by pending readback.");
    h.Melsec.DeInitialize();
    try { await pending.WaitAsync(TimeSpan.FromSeconds(2)); } catch (OperationCanceledException) { }
    return new { servedBeforeReadbackDeadline = served, baselineObservation = baseline };
});

await Test("readback-wait-respects-write-head-fifo", async () =>
{
    var map = new[] { Map("WRITE", "D100", access: EN_MELSEC_ACCESS.Write), Map("BACK", "D200", poll: 500),
        Map("BLOCKER", "D300", access: EN_MELSEC_ACCESS.Write), Map("READ", "D400", poll: 10000) };
    await using var h = await Harness.Open(map);
    h.Melsec.Pause(); await Task.Delay(30);
    var id = h.Melsec.QueueWriteWord("WRITE", 42, "BACK", 2000, 0);
    for (var i = 0; i < 5 && h.Melsec.GetWriteStatus(id)?.Result != EN_MELSEC_WRITE_RESULT.WaitReadback; i++) h.Melsec.Run();
    Assert(h.Melsec.GetWriteStatus(id)?.Result == EN_MELSEC_WRITE_RESULT.WaitReadback, "Write did not enter wait.");
    h.Melsec.Run();
    var sentBefore = h.Api.SendCount;
    using var cancellation = new CancellationTokenSource();
    var write = Task.Factory.StartNew(() => h.Melsec.WriteWord("BLOCKER", 99, cancellation.Token),
        CancellationToken.None, TaskCreationOptions.LongRunning, TaskScheduler.Default);
    await Until(() => h.RequestCount == 1);
    var read = Task.Factory.StartNew(() => h.Melsec.ReadWordNoLog("READ", cancellation.Token),
        CancellationToken.None, TaskCreationOptions.LongRunning, TaskScheduler.Default);
    await Until(() => h.RequestCount == 2);
    try
    {
        for (var i = 0; i < 6; i++) { h.Melsec.Run(); await Task.Delay(2); }
        Assert(!write.IsCompleted && !read.IsCompleted && h.RequestCount == 2, "A read skipped queued control work or changed FIFO.");
        Assert(h.Api.SendCount == sentBefore, "Queued control write bypassed the active write.");
    }
    finally
    {
        cancellation.Cancel(); h.Melsec.DeInitialize();
        try { await Task.WhenAll(write, read).WaitAsync(TimeSpan.FromSeconds(2)); } catch (OperationCanceledException) { }
    }
    return new { preservedControlHeadAndReadOrder = true, extraSendCalls = h.Api.SendCount - sentBefore };
});

await Test("polling-burst-yields-to-pending-control", async () =>
{
    var map = Enumerable.Range(0, 8).Select(i => Map($"P{i}", $"D{100 + i * 10}", poll: 10000)).ToArray();
    await using var h = await Harness.Open(map);
    h.Melsec.Pause(); await Task.Delay(30); h.Melsec.ReloadMap(map); h.Api.ClearTrace();
    var first = Task.Factory.StartNew(() => h.Melsec.ReadWordNoLog("P6"), CancellationToken.None,
        TaskCreationOptions.LongRunning, TaskScheduler.Default);
    await Until(() => h.RequestCount == 1);
    var second = Task.Factory.StartNew(() => h.Melsec.ReadWordNoLog("P7"), CancellationToken.None,
        TaskCreationOptions.LongRunning, TaskScheduler.Default);
    await Until(() => h.RequestCount == 2);
    try
    {
        h.Melsec.Run();
        await first.WaitAsync(TimeSpan.FromSeconds(1));
        Assert(h.Api.ReceiveCount == 2 && h.RequestCount == 1 && !second.IsCompleted,
            "Polling burst did not yield after one poll opportunity with another control request pending.");
        h.Melsec.Run(); await second.WaitAsync(TimeSpan.FromSeconds(1));
    }
    finally { h.Melsec.DeInitialize(); }
    return new { firstTickReceives = 2, composition = "one control read + one poll block", secondControlCompleted = true };
});

await Test("stop-is-observed-between-poll-blocks", async () =>
{
    var map = Enumerable.Range(0, 8).Select(i => Map($"P{i}", $"D{100 + i * 10}", poll: 10000)).ToArray();
    await using var h = await Harness.Open(map);
    h.Melsec.Pause(); await Task.Delay(30); h.Melsec.ReloadMap(map); h.Api.ClearTrace();
    h.Api.HoldNextReceive();
    var run = Task.Factory.StartNew(h.Melsec.Run, CancellationToken.None, TaskCreationOptions.LongRunning, TaskScheduler.Default);
    try
    {
        await Until(() => h.Api.ReceiveIsHeld);
        // This deliberately uses the base worker Stop boundary, not DeInitialize:
        // DeInitialize first queues Close and a deliberately paused worker cannot
        // service that queue until its existing 3-second close timeout expires.
        var stop = Task.Factory.StartNew(h.Melsec.Stop, CancellationToken.None, TaskCreationOptions.LongRunning, TaskScheduler.Default);
        await stop.WaitAsync(TimeSpan.FromSeconds(2));
        h.Api.ReleaseReceive();
        await run.WaitAsync(TimeSpan.FromSeconds(2));
        Assert(h.Api.ReceiveCount == 1 && !h.Melsec.IsRunning, "Stop did not prevent the next native poll call.");
    }
    finally { h.Api.ReleaseReceive(); }
    return new { callsAfterStopBoundary = 0, totalReceiveCalls = h.Api.ReceiveCount,
        note = "Synthetic held call was explicitly released; cancellation of a stuck vendor call is not proven." };
});

// Failure/correctness tests are the same before/after; baseline mode only relaxes expected performance changes.
await Test("contiguous-decode-scale-and-atomic-cache", async () =>
{
    var map = new[] { Map("BIT0", "D100.0", EN_MELSEC_DATA_TYPE.Bit), Map("WORD", "D100", readScale: .5),
        Map("SIGNED", "D101", EN_MELSEC_DATA_TYPE.DWord, length: 2, readScale: .001),
        Map("TEXT", "D103", EN_MELSEC_DATA_TYPE.String, length: 2) };
    var api = new FakeMelsecApi(); api.Set(100, 3); api.Set(101, unchecked((ushort)-1234)); api.Set(102, 65535);
    api.Set(103, 0x4241); api.Set(104, 0x0043);
    await using var h = await Harness.Open(map, api: api);
    await Until(() => h.Melsec.GetCachedSnapshot().Values.All(v => v.IsValid));
    var snap = h.Melsec.GetCachedSnapshot();
    Assert((bool)snap["BIT0"].Value!, "Bit decode failed.");
    Assert(Convert.ToDouble(snap["WORD"].Value) == 1.5, "Word scale failed.");
    Assert(Math.Abs(Convert.ToDouble(snap["SIGNED"].Value) + 1.234) < 1e-9, "Signed DWORD scale failed.");
    Assert((string)snap["TEXT"].Value! == "ABC", "ASCII decode failed.");
    Assert(snap.Values.Select(v => v.ReadCycleNo).Distinct().Count() == 1, "Same block published mixed cycles.");
    Assert(snap.Values.Select(v => v.UpdatedAt).Distinct().Count() == 1, "Same block published mixed timestamps.");
    return new { blocks = h.PollBlockCount, size = api.Trace.Where(c => c.Kind == "RECEIVE").Max(c => c.Size) };
});

await Test("maximum-transfer-boundary-and-float-decode", async () =>
{
    var api = new FakeMelsecApi();
    var bits = BitConverter.SingleToInt32Bits(-12.5f); api.Set(2000, unchecked((ushort)bits)); api.Set(2001, unchecked((ushort)(bits >> 16)));
    var map = new[] { Map("MAX", "D100", EN_MELSEC_DATA_TYPE.String, length: 960, poll: 10000),
        Map("NEXT", "D1060", poll: 10000), Map("FLOAT", "D2000", EN_MELSEC_DATA_TYPE.Float, length: 2, readScale: .1) };
    await using var h = await Harness.Open(map, api: api);
    await Until(() => h.Melsec.GetCachedSnapshot().Values.All(v => v.IsValid));
    Assert(api.Trace.Any(c => c.Kind == "RECEIVE" && c.Size == 1920), "Exactly-1920-byte block was not read.");
    Assert(api.Trace.All(c => c.Size <= 1920), "Over-limit block was merged.");
    Assert(h.PollBlockCount == 3, "Transfer boundary or address gap was crossed.");
    Assert(Math.Abs(Convert.ToDouble(h.Melsec.GetCachedSnapshot()["FLOAT"].Value) + 1.25) < 1e-9, "Float decoding/scale failed.");
    return new { blocks = h.PollBlockCount, maxSize = api.Trace.Max(c => c.Size) };
});

await Test("inflight-map-reload-does-not-publish-old-generation", async () =>
{
    await using var h = await Harness.Open(new[] { Map("OLD", "D100", poll: 10000) });
    await Until(() => h.Melsec.GetCachedSnapshot()["OLD"].IsValid);
    h.Melsec.Pause(); await Task.Delay(30);
    h.Api.HoldNextReceive();
    h.Melsec.ReloadMap(new[] { Map("OLD", "D100", poll: 10000) });
    h.Melsec.Resume();
    try
    {
        await Until(() => h.Api.ReceiveIsHeld);
        var inflight = h.Melsec.GetPollingDiagnostics().Single();
        Assert(inflight.IsReading && inflight.LastAttemptStartedAt.HasValue && inflight.LastAttemptCompletedAt is null &&
            inflight.LastAttemptDurationMs is null, "In-flight diagnostics contain an old attempt's completion metrics.");
        var pending = h.Melsec.GetCachedSnapshot()["OLD"];
        Assert(pending.State == EN_MELSEC_CACHE_STATE.Pending, "A partial/inflight block became valid.");
        h.Melsec.ReloadMap(new[] { Map("NEW", "D200", poll: 10000) });
    }
    finally { h.Api.ReleaseReceive(); }
    await Until(() => h.Melsec.GetCachedSnapshot().TryGetValue("NEW", out var entry) && entry.IsValid);
    Assert(!h.Melsec.GetCachedSnapshot().ContainsKey("OLD"), "Late old-generation read was published.");
    return new { oldGenerationDiscarded = true };
});

await Test("write-confirm-fresh-cycle-and-retry", async () =>
{
    var api = new FakeMelsecApi { EchoFrom = 100, EchoTo = 200, EchoAfterSend = 2 };
    var map = new[] { Map("W", "D100", access: EN_MELSEC_ACCESS.Write, writeScale: 10000),
        Map("R", "D200", poll: 20, readScale: .0001) };
    await using var h = await Harness.Open(map, api: api);
    var id = h.Melsec.QueueWriteWord("W", 1, "R", 80, 1);
    await Until(() => Terminal(h.Melsec.GetWriteStatus(id)!.Result));
    var status = h.Melsec.GetWriteStatus(id)!;
    Assert(status.Result == EN_MELSEC_WRITE_RESULT.Confirmed, $"Retry failed: {status.Result}.");
    Assert(status.ConfirmReadCycle >= status.MinimumReadCycle, "Confirmed stale pre-write read.");
    Assert(api.SendCount == 2 && api.Read(100) == 10000, "Write scale/retry mismatch.");
    return new { status.CurrentRetryCount, status.MinimumReadCycle, status.ConfirmReadCycle, api.SendCount };
});

await Test("refresh-map-reload-and-disconnect", async () =>
{
    var map = new[] { Map("A", "D100", poll: 10000) };
    await using var h = await Harness.Open(map);
    await Until(() => h.Melsec.GetCachedSnapshot()["A"].IsValid);
    var before = h.Melsec.GetCachedSnapshot()["A"].ReadCycleNo;
    var forced = await h.Melsec.RefreshCachedValueAsync("A");
    Assert(forced.ReadCycleNo > before, "Forced refresh did not read a new cycle.");
    h.Melsec.ReloadMap(new[] { Map("B", "D200", poll: 10000) });
    Assert(!h.Melsec.GetCachedSnapshot().ContainsKey("A"), "Old-map cache leaked after reload.");
    await Until(() => h.Melsec.GetCachedSnapshot()["B"].IsValid);
    h.Melsec.DeInitialize();
    Assert(h.Melsec.GetCachedSnapshot()["B"].State == EN_MELSEC_CACHE_STATE.Offline, "Disconnect cache did not become Offline.");
    return new { newCycle = forced.ReadCycleNo, previousCycle = before };
});

await Test("read-failure-device-backoff-and-recovery", async () =>
{
    await using var h = await Harness.Open(new[] { Map("A", "D100", poll: 100) });
    await Until(() => h.Melsec.GetCachedSnapshot()["A"].IsValid);
    h.Api.FailReceives = true;
    await Until(() => h.Melsec.GetCachedSnapshot()["A"].State == EN_MELSEC_CACHE_STATE.Error);
    var diagnostic = h.Melsec.GetPollingDiagnostics().Single();
    Assert(diagnostic.State == EN_MELSEC_CACHE_STATE.Error && diagnostic.AttemptNo > 0,
        "Failure is absent from diagnostics.");
    var count = h.Api.ReceiveCount;
    await Task.Delay(120);
    Assert(h.Api.ReceiveCount == count, "Failure backoff hot-looped native reads.");
    h.Api.FailReceives = false;
    var result = await h.Melsec.RefreshCachedValueAsync("A");
    Assert(result.IsValid, "Force-refresh could not recover error/backoff.");
    return new { failedReceiveCount = count, recoveredCycle = result.ReadCycleNo };
});

await Test("short-native-read-is-not-valid", async () =>
{
    await using var h = await Harness.Open(new[] { Map("A", "D100", EN_MELSEC_DATA_TYPE.DWord, length: 2) });
    await Until(() => h.Melsec.GetCachedSnapshot()["A"].IsValid);
    h.Api.ShortReads = true;
    await Until(() => h.Melsec.GetCachedSnapshot()["A"].State == EN_MELSEC_CACHE_STATE.Error);
    Assert(h.Melsec.GetCachedSnapshot()["A"].Value is null, "Partial native read leaked a value.");
    h.Api.ShortReads = false;
    Assert((await h.Melsec.RefreshCachedValueAsync("A")).IsValid, "Short-read recovery failed.");
    return new { shortReadRejected = true };
});

await Test("command-load-polling-fairness-and-single-sdk-thread", async () =>
{
    var map = Enumerable.Range(0, 24).Select(i => Map($"P{i}", $"D{100 + i * 10}", poll: 1)).ToArray();
    await using var h = await Harness.Open(map);
    await Until(() => h.Melsec.GetCachedSnapshot().Values.All(v => v.IsValid));
    var initial = h.Melsec.GetCachedSnapshot();
    var before = initial["P23"].ReadCycleNo;
    var latestBeforeLoad = initial.Values.Max(v => v.ReadCycleNo);
    h.Api.ClearTrace();
    var timer = Stopwatch.StartNew();
    var tasks = Enumerable.Range(0, 24).Select(i => Task.Factory.StartNew(() => h.Melsec.ReadWordNoLog($"P{i}"),
        CancellationToken.None, TaskCreationOptions.LongRunning, TaskScheduler.Default)).ToArray();
    var all = Task.WhenAll(tasks);
    var pollsDuringLoad = false;
    while (!all.IsCompleted)
    {
        // A particular block may be the final round-robin block after the final
        // command, so test progress during load and full-round progress separately.
        pollsDuringLoad |= h.Melsec.GetCachedSnapshot().Values.Any(v => v.ReadCycleNo > latestBeforeLoad);
        if (timer.Elapsed.TotalSeconds > 5) throw new TimeoutException("Synthetic command load did not drain.");
        await Task.Delay(2);
    }
    await all;
    Assert(pollsDuringLoad, "Background polling did not advance while commands were pending.");
    await Until(() => h.Melsec.GetCachedSnapshot()["P23"].ReadCycleNo > before);
    Assert(h.Api.ThreadIds.Count == 1 && h.Api.MaxConcurrent == 1, "Command/poll calls overlapped or used multiple SDK threads.");
    return new { commands = tasks.Length, elapsedMs = timer.Elapsed.TotalMilliseconds, pollAdvancedDuringLoad = pollsDuringLoad,
        sdkThreads = h.Api.ThreadIds.Count, note = "Finite synthetic workload; no real-time SLA assertion." };
});

await Test("polling-diagnostics-immutable-zero-io-timing-and-reset", async () =>
{
    var map = new[] { Map("BIT", "D100.0", EN_MELSEC_DATA_TYPE.Bit), Map("WORD", "D100") };
    await using var h = await Harness.Open(map, delayMs: 2);
    await Until(() => h.Melsec.GetPollingDiagnostics().Single().LastUpdateIntervalMs.HasValue);
    h.Melsec.Pause(); await Task.Delay(40);
    var diagnostics = h.Melsec.GetPollingDiagnostics();
    var block = diagnostics.Single();
    Assert(block.Ids.SequenceEqual(new[] { "BIT", "WORD" }), "Diagnostics lost same-block IDs.");
    Assert(block.State == EN_MELSEC_CACHE_STATE.Valid && block.AttemptNo >= 2 && !block.IsReading, "Completed diagnostic state is inconsistent.");
    Assert(block.LastAttemptStartedAt.HasValue && block.LastAttemptCompletedAt >= block.LastAttemptStartedAt,
        "Attempt timestamp order is inconsistent.");
    Assert(block.LastSuccessfulUpdateAt.HasValue && block.LastAttemptCompletedAt >= block.LastSuccessfulUpdateAt,
        "Successful update timestamp is inconsistent.");
    Assert(block.LastAttemptDurationMs is >= 0 && block.LastUpdateIntervalMs >= block.PollMs - .5,
        "Periodic monotonic interval was less than its configured target.");
    var snapshot = h.Melsec.GetCachedSnapshot();
    Assert(snapshot.Values.Select(v => v.UpdatedAt).Distinct().Count() == 1 &&
        snapshot.Values.All(v => v.UpdatedAt == block.LastSuccessfulUpdateAt), "Diagnostics do not match atomic block publication.");
    var receiveCount = h.Api.ReceiveCount; var sendCount = h.Api.SendCount;
    for (var i = 0; i < 100; i++) { _ = h.Melsec.GetPollingDiagnostics(); _ = h.Melsec.GetCachedSnapshot(); }
    Assert(h.Api.ReceiveCount == receiveCount && h.Api.SendCount == sendCount, "Snapshot getter performed SDK I/O.");
    try { ((IList<ST_MELSEC_POLLING_DIAGNOSTIC>)diagnostics)[0] = block; throw new Exception("Outer diagnostics are mutable."); }
    catch (NotSupportedException) { }
    try { ((IList<string>)block.Ids)[0] = "BROKEN"; throw new Exception("Diagnostic IDs are mutable."); }
    catch (NotSupportedException) { }
    h.Melsec.ReloadMap(new[] { Map("NEW", "W10", poll: 100) });
    var reset = h.Melsec.GetPollingDiagnostics().Single();
    Assert(reset.Address == "W10" && reset.Ids.SequenceEqual(new[] { "NEW" }) && reset.AttemptNo == 0 && !reset.IsReading &&
        reset.State == EN_MELSEC_CACHE_STATE.Pending && reset.LastAttemptStartedAt is null && reset.LastAttemptCompletedAt is null &&
        reset.LastSuccessfulUpdateAt is null && reset.LastAttemptDurationMs is null && reset.LastUpdateIntervalMs is null,
        "Reload did not reset diagnostic generation/timings.");
    Assert(block.Ids.SequenceEqual(new[] { "BIT", "WORD" }), "Reload mutated the old diagnostic snapshot.");
    return new { block.PollMs, block.AttemptNo, block.LastAttemptDurationMs, block.LastUpdateIntervalMs,
        getterCallsWithoutIo = 200, immutableOuterAndIds = true, reloadReset = true,
        note = "Interval assertion covers periodic reads only. Force refresh intentionally bypasses the scheduled interval." };
});

await Test("stale-and-refresh-cancel", async () =>
{
    await using var h = await Harness.Open(new[] { Map("A", "D100", poll: 100) });
    await Until(() => h.Melsec.GetCachedSnapshot()["A"].IsValid);
    h.Melsec.Pause(); await Task.Delay(30); await Task.Delay(1050);
    var stale = h.Melsec.GetCachedSnapshot()["A"];
    Assert(stale.State == EN_MELSEC_CACHE_STATE.Stale && stale.Value is null, "Stale cache was exposed as valid.");
    Assert(h.Melsec.GetPollingDiagnostics().Single().State == EN_MELSEC_CACHE_STATE.Stale, "Stale diagnostics disagree with cache.");
    using var cts = new CancellationTokenSource(40);
    try { await h.Melsec.RefreshCachedValueAsync("A", cts.Token); throw new Exception("Cancellation was ignored."); }
    catch (OperationCanceledException) { }
    return new { state = stale.State.ToString(), cancellationObserved = true };
});

await Test("stop-cancels-pending-write-and-bounded-native-call", async () =>
{
    await using var h = await Harness.Open(new[] { Map("W", "D100", access: EN_MELSEC_ACCESS.Write), Map("R", "D200", poll: 500) }, delayMs: 5);
    var id = h.Melsec.QueueWriteWord("W", 7, "R", 2000, 0);
    await Until(() => h.Melsec.GetWriteStatus(id)!.Result == EN_MELSEC_WRITE_RESULT.WaitReadback);
    var elapsed = Stopwatch.StartNew(); h.Melsec.DeInitialize();
    Assert(!h.Melsec.IsRunning, "Stop left worker alive.");
    Assert(h.Melsec.GetWriteStatus(id)!.Result == EN_MELSEC_WRITE_RESULT.Cancelled, "Pending write was not cancelled.");
    Assert(h.Api.MaxConcurrent == 1, "SDK calls were concurrent.");
    return new { stopMs = elapsed.Elapsed.TotalMilliseconds, fakeNativeDelayMs = 5,
        caveat = "Real synchronous vendor-call cancellation was not tested; only finite fake delay." };
});

var json = JsonSerializer.Serialize(new { mode = baseline ? "baseline-observation" : "regression", checkedAt = DateTimeOffset.Now,
    commonAssemblySha256 = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(typeof(CMelsec).Assembly.Location))),
    fakeOnly = true, nativeLibraryLoaded = false, hardwareOrUiStarted = false, failures, tests = results },
    new JsonSerializerOptions { WriteIndented = true });
Console.WriteLine(json);
var outputIndex = Array.IndexOf(args, "--output");
if (outputIndex >= 0)
{
    var evidence = Path.GetFullPath(args[outputIndex + 1]);
    var allowed = Path.GetFullPath(Path.Combine(root, "tests/MelsecLatency.Regression/artifacts")) + Path.DirectorySeparatorChar;
    if (!evidence.StartsWith(allowed, StringComparison.OrdinalIgnoreCase)) throw new Exception("Evidence must stay in this test's artifacts directory.");
    Directory.CreateDirectory(Path.GetDirectoryName(evidence)!);
    File.WriteAllText(evidence, json + Environment.NewLine);
}
return failures == 0 ? 0 : 1;

static bool Terminal(EN_MELSEC_WRITE_RESULT r) => r is EN_MELSEC_WRITE_RESULT.Confirmed or EN_MELSEC_WRITE_RESULT.Timeout
    or EN_MELSEC_WRITE_RESULT.Cancelled or EN_MELSEC_WRITE_RESULT.InvalidParameter or EN_MELSEC_WRITE_RESULT.CommunicationError;

sealed class Harness(CInterfaceManager manager, FakeMelsecApi api) : IAsyncDisposable
{
    public FakeMelsecApi Api => api;
    public CMelsec Melsec => manager.Melsec;
    public int PollBlockCount => ((System.Collections.ICollection)typeof(CMelsec).GetField("_pollBlocks", BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(Melsec)!).Count;
    public int RequestCount
    {
        get
        {
            var sync = typeof(CMelsec).GetField("_requestLock", BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(Melsec)!;
            lock (sync) return ((System.Collections.ICollection)typeof(CMelsec).GetField("_requestQueue", BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(Melsec)!).Count;
        }
    }
    public static async Task<Harness> Open(IReadOnlyList<ST_MELSEC_MAP_DATA> map, int delayMs = 0, FakeMelsecApi? api = null)
    {
        api ??= new FakeMelsecApi(); api.DelayMs = delayMs;
        var manager = new CInterfaceManager(false, melsecMap: map, melsecNetApi: api);
        foreach (var device in map.Select(row => row.DeviceNo).Distinct())
            manager.Register(new(EN_INTERFACE_TYPE.MelsecNet, EN_EQP_MODULE.Melsec, device, $"FAKE_ONLY_{device}", "REGRESSION", true, false, ["51", "1", "1", "500", "0"]));
        try { await manager.Initialize(); return new(manager, api); }
        catch { await manager.Destroy(); throw; }
    }
    public async ValueTask DisposeAsync() => await manager.Destroy();
}

sealed record Call(string Kind, int DeviceType, int Address, int Size, int Thread, double StartMs, double EndMs);
sealed class FakeMelsecApi : CMelsecNetApi
{
    private readonly object _sync = new();
    private readonly Dictionary<int, ushort> _words = new();
    private readonly Stopwatch _time = Stopwatch.StartNew();
    private readonly ConcurrentQueue<Call> _trace = new();
    private int _active, _maxConcurrent, _receives, _sends;
    public int DelayMs { get; set; }
    public bool SpinDelay { get; set; }
    public bool FailReceives { get; set; }
    public bool ShortReads { get; set; }
    public int EchoFrom { get; set; } = -1;
    public int EchoTo { get; set; } = -1;
    public int EchoAfterSend { get; set; } = 1;
    public int ReceiveCount => Volatile.Read(ref _receives);
    public int SendCount => Volatile.Read(ref _sends);
    public int MaxConcurrent => Volatile.Read(ref _maxConcurrent);
    private int _holdNextReceive;
    private readonly ManualResetEventSlim _receiveEntered = new(false), _receiveRelease = new(true);
    public bool ReceiveIsHeld => _receiveEntered.IsSet && !_receiveRelease.IsSet;
    public void HoldNextReceive() { _receiveEntered.Reset(); _receiveRelease.Reset(); Interlocked.Exchange(ref _holdNextReceive, 1); }
    public void ReleaseReceive() => _receiveRelease.Set();
    public IReadOnlyList<Call> Trace => _trace.ToArray();
    public IReadOnlySet<int> ThreadIds => Trace.Select(call => call.Thread).ToHashSet();
    public void ClearTrace() { while (_trace.TryDequeue(out _)) { } Interlocked.Exchange(ref _receives, 0); Interlocked.Exchange(ref _sends, 0); }
    public void Set(int address, ushort value) { lock (_sync) _words[address] = value; }
    public ushort Read(int address) { lock (_sync) return _words.GetValueOrDefault(address); }
    public override int Open(short channelNo, out int path) { path = 7001; Record("OPEN", 0, 0, 0, _time.Elapsed.TotalMilliseconds); return 0; }
    public override int Close(int path) { Record("CLOSE", 0, 0, 0, _time.Elapsed.TotalMilliseconds); return 0; }
    public override int ReceiveEx(int path, int networkNo, int stationNo, int deviceType, int deviceNo, ref int size, short[] data)
    {
        var start = _time.Elapsed.TotalMilliseconds;
        var active = Interlocked.Increment(ref _active); Interlocked.Exchange(ref _maxConcurrent, Math.Max(active, _maxConcurrent));
        try
        {
            Interlocked.Increment(ref _receives);
            if (Interlocked.Exchange(ref _holdNextReceive, 0) == 1)
            {
                _receiveEntered.Set();
                if (!_receiveRelease.Wait(TimeSpan.FromSeconds(2))) throw new TimeoutException("Fake receive gate was not released.");
            }
            if (DelayMs > 0)
            {
                if (!SpinDelay) Thread.Sleep(DelayMs);
                else { var delay = Stopwatch.StartNew(); while (delay.Elapsed.TotalMilliseconds < DelayMs) Thread.SpinWait(30); }
            }
            if (FailReceives) return 0xC051;
            lock (_sync) for (var i = 0; i < data.Length; i++) data[i] = unchecked((short)_words.GetValueOrDefault(deviceNo + i));
            if (ShortReads) size = Math.Max(0, size - 2);
            return 0;
        }
        finally { Record("RECEIVE", deviceType, deviceNo, size, start); Interlocked.Decrement(ref _active); }
    }
    public override int SendEx(int path, int networkNo, int stationNo, int deviceType, int deviceNo, ref int size, short[] data)
    {
        var start = _time.Elapsed.TotalMilliseconds; var count = Interlocked.Increment(ref _sends);
        lock (_sync)
        {
            for (var i = 0; i < data.Length; i++) _words[deviceNo + i] = unchecked((ushort)data[i]);
            if (deviceNo == EchoFrom && count >= EchoAfterSend)
                for (var i = 0; i < data.Length; i++) _words[EchoTo + i] = unchecked((ushort)data[i]);
        }
        Record("SEND", deviceType, deviceNo, size, start); return 0;
    }
    private void Record(string kind, int type, int address, int size, double start) =>
        _trace.Enqueue(new(kind, type, address, size, Environment.CurrentManagedThreadId, start, _time.Elapsed.TotalMilliseconds));
}
