# MELSEC latency regression (fake API only)

This console harness never constructs the WPF app or the equipment-wide manager.
It registers only MELSEC interfaces and overrides every native API entry point.
No Mitsubishi native DLL, board, PLC, laser, Stage, or other device is used.

Run from the repository root:

```powershell
dotnet run --project tests/MelsecLatency.Regression --configuration Release
```

JSON is printed to stdout. Optional `--output <absolute-path>` saves the same JSON
under this project's `artifacts/` directory only. Artifacts and build output must
not be committed. The historical `--baseline` switch asserts the original one-block
Run and starved head-read behavior; it is not an alternate success mode for the
patched driver. Baseline evidence was captured before the driver changed with the
then-current eleven-case harness. The current harness also calls the new diagnostics
API, so simply checking out the old Common source will not compile these new tests.

The actual-map benchmark uses the tracked map read-only, 24 poll blocks, and three
conditions: no fake delay, requested 4 ms `Thread.Sleep`, and a 4 ms Stopwatch busy
wait. It reports observed native-fake duration, per-block min/p50/p95/max arrival
intervals and sample cache age. These are fake-driver measurements, not claims of
board/network latency. UI repaint cadence is a separate policy and no WPF timing
measurement is performed. Thread scheduling can affect wall-clock data.

The fixed-Run test deliberately pauses the worker and invokes `Run` manually to
isolate the bounded-burst scheduling policy. Its SDK thread count is not mixed with
the normal-worker single-SDK-thread assertion. Every harness is disposed after use.

Nineteen tests cover the three benchmarks, bounded burst, independent reads during
readback wait, FIFO control-write blocking, yielding to pending control work,
Stop between poll blocks, bit/word/signed-DWORD/float/string decode and scaling,
atomic publication, exactly-1920-byte transfer boundary, in-flight map generation
discard, fresh-cycle write confirmation/retry, force refresh, reload/disconnect,
failure/backoff, short-read rejection, polling during a 24-command load,
single-SDK-thread execution, stale data/cancellation, and finite-fake-call stop.
Diagnostics assertions cover immutable snapshots/IDs, zero getter I/O, UTC attempt
times, monotonic duration/interval, in-flight null completion metrics, Error/Stale
state, and reset on map reload. Periodic interval >= PollMs is checked separately
from force refresh, which intentionally bypasses the scheduled interval.

Real vendor calls are synchronous: this test does not prove that a stuck native
call is interruptible or that the physical board follows the configured timeout.
The new 8 ms / four-block limit is a soft budget checked between calls, not a
promise that one synchronous native call finishes within 8 ms.

The project needs no new test-framework NuGet packages. Build output is not source.

## Captured baseline and after (2026-10-30 KST)

The baseline at `223b905d` passed eleven then-existing cases at 14:05:32. The patched
driver passed all nineteen current cases at 14:13:36 (build: 0 warnings / 0 errors).
The nineteen-case repeat passed at 14:15:22. A final test-only stabilization split
"any poll advanced during command load" from "P23 completed its round afterward"
to avoid a last-command observation race; all nineteen then passed at 14:16:37.
An earlier patched run passed seventeen cases before two safety cases were added.
Common assembly SHA-256 evidence distinguishes the actual binaries:

- Baseline: `F4A14624AECFED92A8C431797586AB81C8482059DC5284AF54EF1EA34EEBD214`
- After: `70E800DDD63644ABBEBE72D4CABB701B73CCE760A9835C5AE0FC9ECE50D4A3C6`

Actual map: 102 rows, 24 poll blocks, 42 rows configured at 100 ms. Each benchmark
sample lasts approximately 1.8 seconds. The arrival table pools inter-arrival
measurements for every block; local JSON also preserves every block separately.
All numeric table cells are **min / p50 / p95 / max, in ms** (rounded).

| Fake condition | Before block arrivals | After block arrivals |
| --- | --- | --- |
| Requested Sleep(4) | 753.779 / 757.574 / 762.429 / 762.466 | 752.981 / 760.200 / 762.352 / 762.362 |
| No delay | 373.425 / 378.271 / 382.418 / 383.554 | 101.619 / 109.816 / 111.739 / 111.857 |
| Precise busy-wait(4) | 374.048 / 379.220 / 382.329 / 383.414 | 183.038 / 188.557 / 191.513 / 191.700 |

| Fake condition | Before observed fake-call duration | After observed fake-call duration |
| --- | --- | --- |
| Requested Sleep(4) | 13.632 / 15.901 / 15.976 / 16.035 | 13.433 / 15.896 / 15.965 / 15.977 |
| No delay | 0.0002 / 0.0007 / 0.0015 / 0.0018 | 0 / 0.0002 / 0.0011 / 0.0023 |
| Precise busy-wait(4) | 4.001 / 4.002 / 4.015 / 4.020 | 4.000 / 4.002 / 4.004 / 4.018 |

| Fake condition | Before sampled cache age | After sampled cache age |
| --- | --- | --- |
| Requested Sleep(4) | 0.015 / 332.376 / 698.640 / 758.808 | 0.049 / 333.263 / 698.615 / 762.419 |
| No delay | 0.003 / 173.705 / 350.649 / 383.549 | 0.031 / 47.947 / 107.873 / 111.853 |
| Precise busy-wait(4) | 7.833 / 184.539 / 360.330 / 379.439 | 2.845 / 90.834 / 181.454 / 187.686 |

The Sleep(4) condition **did not materially improve**: this machine actually slept
about 16 ms, so one call already exceeded the 8 ms budget. The no-delay and precise
conditions expose the scheduler improvement without implying PLC speed. Even the
precise condition still did not meet a 100 ms target. PollMs is a requested due
interval after completion, not a guaranteed scan deadline.

The final age sampler obtains the immutable cache snapshot before taking `now`.
The historical baseline took `now` first, permitting a rare negative minimum if
a new sample arrived between those operations. All recorded baseline minima were
positive; use median/p95 as trend evidence, not exact matched-age proof.

Policy checks were deterministic: six manual ticks changed from
`[1,1,1,1,1,1]` to `[4,4,4,4,4,4]`. Independent head reads changed from starved to
served while scheduled readback was waiting. A queued Write ahead of Read was not
overtaken (zero extra sends). Pending control work limited the next poll burst to
one opportunity; Stop prevented the next poll call. Under a 24-command synthetic
load, polling advanced during the load and all SDK calls remained on one worker.

One development-only Stop fixture originally paused the real worker and invoked
DeInitialize, which queues Close before Stop; it hit the existing 3-second Close
path with a 2-second test deadline, consistent with the existing Close wait rather
than isolating inter-block Stop. This fixture failure alone does not establish a
production-driver defect or prove every production stop scenario safe. The final boundary test
uses Stop directly and explicitly releases its held fake call. Normal-worker
DeInitialize with finite fake delay is tested separately; its final observed stop
was 31.645 ms, not a production stop-time guarantee. No vendor-call interruption,
live board/network timing, or end-to-end UI repaint timing has been verified.
