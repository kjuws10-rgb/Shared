﻿using System.Globalization;
using System.Text;
using Drilling.Common.Alarm;
using Drilling.Common.Interface;
using Drilling.Common.InterLock;
using Drilling.Common.Managers;
using Drilling.Common.Motion;
using Drilling.Common.Station;

namespace Drilling.Common.Log;
public sealed partial class CLogManager : IAlarmHistoryStore
{
    private const int DefaultReadDays = 14;
    private const int DefaultRecipeReadRows = 10;
    private const int DefaultSettingReadRows = 20;
    private const int DefaultInterfaceReadRows = 100;
    private static readonly object FileLock = new();
    private readonly string _recipeLogRoot;
    private readonly string _settingLogRoot;
    private readonly string _interfaceLogRoot;
    private readonly string _stationLogRoot;
    private readonly string _productLogRoot;
    private readonly string _uiLogRoot;
    public string LogDirectory { get; }
    public CLogManager(string configRoot)
    {
        var root = Directory.GetParent(configRoot)?.FullName ?? configRoot;
        LogDirectory = Path.Combine(root, "Log");
        _alarmLogRoot = Path.Combine(root, "Log", "Alarm");
        _recipeLogRoot = Path.Combine(root, "Log", "Recipe");
        _settingLogRoot = Path.Combine(root, "Log", "Setting");
        _interfaceLogRoot = Path.Combine(root, "Log", "Interface");
        _stationLogRoot = Path.Combine(root, "Log", "Station");
        _productLogRoot = Path.Combine(root, "Log", "Product");
        _uiLogRoot = Path.Combine(root, "Log", "UI");
    }

    public void WriteStationState(string stationName, string stateName, string action, string detail)
    {
        var now = DateTime.Now;
        var directory = Path.Combine(_stationLogRoot, now.ToString("yyyyMMdd", CultureInfo.InvariantCulture));
        var path = Path.Combine(directory, $"Station_{now.ToString("yyyyMMdd", CultureInfo.InvariantCulture)}_Trace.txt");
        var time = now.ToString("yy/MM/dd HH:mm:ss.fff", CultureInfo.InvariantCulture);
        var line = $"{time} \\STATION\\{EscapeField(stationName)}\\{EscapeField(stateName)}\\{EscapeField(action)}\\{EscapeField(detail)}";
        AppendLine(directory, path, line);
    }

    public IReadOnlyList<ST_RECIPE_HISTORY> ReadRecipeRecent(string recipeName, string recipeId, int maxRows = DefaultRecipeReadRows, int days = DefaultReadDays)
    {
        var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            recipeName,
            recipeId
        };
        bool ShouldIncludeItem(global::Drilling.Common.Managers.ST_RECIPE_HISTORY? item)
        {
            return item is not null;
        }

        bool ShouldIncludeRecipe(global::Drilling.Common.Managers.ST_RECIPE_HISTORY item)
        {
            return names.Contains(item.RecipeName);
        }

        global::System.DateTimeOffset SelectChangedAt(global::Drilling.Common.Managers.ST_RECIPE_HISTORY item)
        {
            return item.ChangedAt;
        }

        return EnumerateRecentLogFiles(_recipeLogRoot, days).SelectMany(ReadLogFile).Select(ParseRecipeLine).Where(ShouldIncludeItem).Cast<ST_RECIPE_HISTORY>().Where(ShouldIncludeRecipe).OrderByDescending(SelectChangedAt).Take(maxRows).ToArray();
    }

    public void WriteRecipeCreate(string recipeName)
    {
        WriteRecipeAction(recipeName, "CREATE", "Recipe", "-", recipeName);
    }

    public IReadOnlyList<ST_RECIPE_HISTORY> ReadRecipeRecent(int maxRows = 200, int days = DefaultReadDays)
    {
        return EnumerateRecentLogFiles(_recipeLogRoot, days)
            .SelectMany(ReadLogFile).Select(ParseRecipeLine).OfType<ST_RECIPE_HISTORY>()
            .OrderByDescending(item => item.ChangedAt).Take(maxRows).ToArray();
    }

    public void WriteRecipeSelect(string previousRecipeName, string recipeName)
    {
        WriteRecipeAction(recipeName, "SELECT", "Recipe",
            string.IsNullOrWhiteSpace(previousRecipeName) ? "-" : previousRecipeName, recipeName);
    }

    public void WriteRecipeDelete(string recipeName)
    {
        WriteRecipeAction(recipeName, "DELETE", "Recipe", recipeName, "-");
    }

    public void WriteRecipeSave(string recipeName)
    {
        WriteRecipeAction(recipeName, "SAVE", "Recipe", "-", recipeName);
    }

    public void WriteRecipeModify(string recipeName, string itemName, string oldValue, string newValue)
    {
        WriteRecipeAction(recipeName, "MODIFY", itemName, oldValue, newValue);
    }

    public void WriteRecipeModify(string recipeName, string tab, string group, string itemName, string oldValue, string newValue)
    {
        WriteRecipeAction(recipeName, "MODIFY", tab, group, itemName, oldValue, newValue);
    }

    public void WriteRecipeModifyBatch(
        string recipeName,
        IReadOnlyList<(string Tab, string Group, string ItemName, string OldValue, string NewValue)> changes)
    {
        if (changes.Count == 0)
        {
            return;
        }

        var now = DateTime.Now;
        var date = now.ToString("yyyyMMdd", CultureInfo.InvariantCulture);
        var directory = Path.Combine(_recipeLogRoot, date);
        var path = Path.Combine(directory, $"Recipe_{date}_Trace.txt");
        var time = now.ToString("yy/MM/dd HH:mm:ss.fff", CultureInfo.InvariantCulture);
        var escapedRecipeName = EscapeField(recipeName);
        var builder = new StringBuilder(changes.Count * 128);
        foreach (var change in changes)
        {
            builder.Append(time)
                .Append(" \\")
                .Append(escapedRecipeName)
                .Append("\\MODIFY\\")
                .Append(EscapeField(change.Tab))
                .Append('\\')
                .Append(EscapeField(change.Group))
                .Append('\\')
                .Append(EscapeField(change.ItemName))
                .Append('\\')
                .Append(EscapeField(change.OldValue))
                .Append('\\')
                .Append(EscapeField(change.NewValue))
                .AppendLine();
        }

        AppendText(directory, path, builder.ToString());
    }

    public void WriteRecipeRename(string oldRecipeName, string newRecipeName)
    {
        WriteRecipeAction(newRecipeName, "RENAME", "Recipe", oldRecipeName, newRecipeName);
    }

    public IReadOnlyList<ST_SETTING_HISTORY> ReadSettingRecent(EN_SETTING_TAB section, int maxRows = DefaultSettingReadRows, int days = DefaultReadDays)
    {
        bool ShouldIncludeItem(global::Drilling.Common.Managers.ST_SETTING_HISTORY? item)
        {
            return item is not null;
        }

        bool MatchesSection(global::Drilling.Common.Managers.ST_SETTING_HISTORY item)
        {
            return item.Section == section;
        }

        global::System.DateTimeOffset SelectChangedAt(global::Drilling.Common.Managers.ST_SETTING_HISTORY item)
        {
            return item.ChangedAt;
        }

        return EnumerateRecentLogFiles(_settingLogRoot, days).SelectMany(ReadLogFile).Select(ParseSettingLine).Where(ShouldIncludeItem).Cast<ST_SETTING_HISTORY>().Where(MatchesSection).OrderByDescending(SelectChangedAt).Take(maxRows).ToArray();
    }

    public void WriteSettingModify(EN_SETTING_TAB section, string parameterName, string oldValue, string newValue)
    {
        WriteSettingAction(section, "MODIFY", parameterName, oldValue, newValue);
    }

    public void WriteSettingSave(EN_SETTING_TAB section)
    {
        WriteSettingAction(section, "SAVE", "Section", "-", section.ToString().ToUpperInvariant());
    }

    public void WriteInterfaceConnection(EN_EQP_MODULE module, string action, string nickName, string oldState, string newState)
    {
        WriteInterfaceAction(module, action, nickName, oldState, newState);
    }

    public void WriteInterfaceCommand(EN_EQP_MODULE module, string nickName, string command, string response, string detail = "")
    {
        var after = string.IsNullOrWhiteSpace(detail) ? response : $"{response} / {detail}";
        WriteInterfaceAction(module, "COMMAND", nickName, command, after);
    }

    public void WriteInterfaceError(EN_EQP_MODULE module, string nickName, string command, string detail)
    {
        WriteInterfaceAction(module, "ERROR", nickName, command, $"ERROR / {detail}");
    }

    public void WriteInterfaceProtocolTrace(
        EN_EQP_MODULE module,
        DateTimeOffset occurredAt,
        string packetLog)
    {
        if (string.IsNullOrWhiteSpace(packetLog))
        {
            return;
        }

        var localTime = occurredAt.LocalDateTime;
        var moduleName = ModuleLogName(module);
        var date = localTime.ToString("yyyyMMdd", CultureInfo.InvariantCulture);
        var directory = Path.Combine(_interfaceLogRoot, moduleName, date);
        var path = Path.Combine(directory, $"Interface_{moduleName}_{date}_Trace.txt");
        var time = localTime.ToString("yy/MM/dd HH:mm:ss.fff", CultureInfo.InvariantCulture);
        var lines = packetLog.Split(
            ['\r', '\n'],
            StringSplitOptions.RemoveEmptyEntries);
        var builder = new StringBuilder();
        foreach (var line in lines)
        {
            builder.Append(time)
                .Append(' ')
                .AppendLine(line);
        }

        AppendText(directory, path, builder.ToString());
    }

    public void WriteProductEvent(string productId, string action, string state, string result, string detail)
    {
        var now = DateTime.Now;
        var directory = Path.Combine(_productLogRoot, now.ToString("yyyyMMdd", CultureInfo.InvariantCulture));
        var path = Path.Combine(directory, $"Product_{now.ToString("yyyyMMdd", CultureInfo.InvariantCulture)}_Trace.txt");
        var time = now.ToString("yy/MM/dd HH:mm:ss.fff", CultureInfo.InvariantCulture);
        var line = $"{time} \\PRODUCT\\{EscapeField(productId)}\\{EscapeField(action)}\\{EscapeField(state)}\\{EscapeField(result)}\\{EscapeField(detail)}";
        AppendLine(directory, path, line);
    }

    public void WriteUiClick(string screenName, string controlName, string parameter, string detail = "")
    {
        WriteUiAction("CLICK", screenName, controlName, parameter, detail);
    }

    public IReadOnlyList<ST_INTERFACE_HISTORY> ReadInterfaceRecent(EN_EQP_MODULE? module = null, string nickName = "", int maxRows = DefaultInterfaceReadRows, int days = DefaultReadDays, Func<ST_INTERFACE_HISTORY, bool>? filter = null)
    {
        var normalizedNickName = nickName.Trim();
        bool ShouldIncludeItem(global::Drilling.Common.Interface.ST_INTERFACE_HISTORY? item)
        {
            return item is not null;
        }

        bool ShouldIncludeInterface(global::Drilling.Common.Interface.ST_INTERFACE_HISTORY item)
        {
            return string.IsNullOrWhiteSpace(normalizedNickName) || item.NickName.Equals(normalizedNickName, StringComparison.OrdinalIgnoreCase);
        }

        global::System.DateTimeOffset SelectOccurredAt(global::Drilling.Common.Interface.ST_INTERFACE_HISTORY item)
        {
            return item.OccurredAt;
        }

        var history = EnumerateInterfaceLogFiles(module, days).SelectMany(ReadLogFile).Select(ParseInterfaceLine).Where(ShouldIncludeItem).Cast<ST_INTERFACE_HISTORY>().Where(ShouldIncludeInterface);
        if (filter is not null)
        {
            history = history.Where(filter);
        }

        return history.OrderByDescending(SelectOccurredAt).Take(Math.Max(1, maxRows)).ToArray();
    }

    private void WriteRecipeAction(string recipeName, string action, string itemName, string oldValue, string newValue)
    {
        var now = DateTime.Now;
        var directory = Path.Combine(_recipeLogRoot, now.ToString("yyyyMMdd", CultureInfo.InvariantCulture));
        var path = Path.Combine(directory, $"Recipe_{now.ToString("yyyyMMdd", CultureInfo.InvariantCulture)}_Trace.txt");
        var time = now.ToString("yy/MM/dd HH:mm:ss.fff", CultureInfo.InvariantCulture);
        var line = $"{time} \\{recipeName}\\{action}\\{itemName}\\{oldValue}\\{newValue}";
        AppendLine(directory, path, line);
    }

    private void WriteRecipeAction(string recipeName, string action, string tab, string group, string itemName, string oldValue, string newValue)
    {
        var now = DateTime.Now;
        var directory = Path.Combine(_recipeLogRoot, now.ToString("yyyyMMdd", CultureInfo.InvariantCulture));
        var path = Path.Combine(directory, $"Recipe_{now.ToString("yyyyMMdd", CultureInfo.InvariantCulture)}_Trace.txt");
        var time = now.ToString("yy/MM/dd HH:mm:ss.fff", CultureInfo.InvariantCulture);
        var line = $"{time} \\{EscapeField(recipeName)}\\{action}\\{EscapeField(tab)}\\{EscapeField(group)}\\{EscapeField(itemName)}\\{EscapeField(oldValue)}\\{EscapeField(newValue)}";
        AppendLine(directory, path, line);
    }

    private void WriteSettingAction(EN_SETTING_TAB section, string action, string parameterName, string oldValue, string newValue)
    {
        var now = DateTime.Now;
        var directory = Path.Combine(_settingLogRoot, now.ToString("yyyyMMdd", CultureInfo.InvariantCulture));
        var path = Path.Combine(directory, $"Setting_{now.ToString("yyyyMMdd", CultureInfo.InvariantCulture)}_Trace.txt");
        var time = now.ToString("yy/MM/dd HH:mm:ss.fff", CultureInfo.InvariantCulture);
        var line = $"{time} \\SETTING\\{section.ToString().ToUpperInvariant()}\\{action}\\{EscapeField(parameterName)}\\{EscapeField(oldValue)}\\{EscapeField(newValue)}";
        AppendLine(directory, path, line);
    }

    private void WriteInterfaceAction(EN_EQP_MODULE module, string action, string nickName, string oldState, string newState)
    {
        var now = DateTime.Now;
        var moduleName = ModuleLogName(module);
        var directory = Path.Combine(_interfaceLogRoot, moduleName, now.ToString("yyyyMMdd", CultureInfo.InvariantCulture));
        var path = Path.Combine(directory, $"Interface_{moduleName}_{now.ToString("yyyyMMdd", CultureInfo.InvariantCulture)}_Trace.txt");
        var time = now.ToString("yy/MM/dd HH:mm:ss.fff", CultureInfo.InvariantCulture);
        var line = $"{time} \\INTERFACE\\{moduleName}\\{EscapeField(nickName)}\\{action}\\{EscapeField(oldState)}\\{EscapeField(newState)}";
        AppendLine(directory, path, line);
    }

    private void WriteUiAction(string action, string screenName, string controlName, string parameter, string detail)
    {
        var now = DateTime.Now;
        var directory = Path.Combine(_uiLogRoot, now.ToString("yyyyMMdd", CultureInfo.InvariantCulture));
        var path = Path.Combine(directory, $"UI_{now.ToString("yyyyMMdd", CultureInfo.InvariantCulture)}_Trace.txt");
        var time = now.ToString("yy/MM/dd HH:mm:ss.fff", CultureInfo.InvariantCulture);
        var line = $"{time} \\UI\\{action}\\{EscapeField(screenName)}\\{EscapeField(controlName)}\\{EscapeField(parameter)}\\{EscapeField(detail)}";
        AppendLine(directory, path, line);
    }

    private static void AppendLine(string directory, string path, string line)
    {
        AppendText(directory, path, line + Environment.NewLine);
    }

    private static void AppendText(string directory, string path, string text)
    {
        lock (FileLock)
        {
            Directory.CreateDirectory(directory);
            System.IO.File.AppendAllText(path, text, Encoding.Unicode);
        }
    }

    private static IEnumerable<string> EnumerateRecentLogFiles(string logRoot, int days)
    {
        var today = DateTime.Today;
        for (var offset = 0; offset < days; offset++)
        {
            var date = today.AddDays(-offset).ToString("yyyyMMdd", CultureInfo.InvariantCulture);
            var directory = Path.Combine(logRoot, date);
            if (!Directory.Exists(directory))
            {
                continue;
            }

            foreach (var path in Directory.EnumerateFiles(directory, "*.txt"))
            {
                yield return path;
            }
        }
    }

    private static IEnumerable<string> ReadLogFile(string path)
    {
        try
        {
            return System.IO.File.ReadAllLines(path);
        }
        catch (IOException)
        {
            return[];
        }
        catch (UnauthorizedAccessException)
        {
            return[];
        }
    }

    private IEnumerable<string> EnumerateInterfaceLogFiles(EN_EQP_MODULE? module, int days)
    {
        if (module is not null)
        {
            return EnumerateRecentLogFiles(Path.Combine(_interfaceLogRoot, ModuleLogName(module.Value)), days);
        }

        if (!Directory.Exists(_interfaceLogRoot))
        {
            return[];
        }

        global::System.Collections.Generic.IEnumerable<string> SelectValue(string directory)
        {
            return EnumerateRecentLogFiles(directory, days);
        }

        return Directory.EnumerateDirectories(_interfaceLogRoot).SelectMany(SelectValue).ToArray();
    }

    private static ST_RECIPE_HISTORY? ParseRecipeLine(string line)
    {
        if (string.IsNullOrWhiteSpace(line))
        {
            return null;
        }

        var parts = SplitFields(line);
        if (parts.Length < 3)
        {
            return null;
        }

        var changedAt = ParseTimestamp(parts[0].Trim());
        var recipeName = UnescapeField(parts[1].Trim());
        var action = parts[2].Trim();
        if (string.IsNullOrWhiteSpace(recipeName) || string.IsNullOrWhiteSpace(action))
        {
            return null;
        }

        return action.ToUpperInvariant() switch
        {
            "MODIFY" when parts.Length >= 8 => CreateRecipeHistory(changedAt, recipeName, action, UnescapeField(parts[5]), UnescapeField(parts[6]), UnescapeField(parts[7]), UnescapeField(parts[3]), UnescapeField(parts[4])),
            "MODIFY" when parts.Length >= 6 => CreateRecipeHistory(changedAt, recipeName, action, UnescapeField(parts[3]), UnescapeField(parts[4]), UnescapeField(parts[5])),
            "PARAM CHANGE" when parts.Length >= 7 => CreateRecipeHistory(changedAt, recipeName, action, $"{parts[3]} / {parts[4]}", parts[5], parts[6]),
            "PARAM CHANGE OFFSET X" when parts.Length >= 7 => CreateRecipeHistory(changedAt, recipeName, action, $"{parts[3]} / {parts[4]}", parts[5], parts[6]),
            "PARAM CHANGE OFFSET Y" when parts.Length >= 7 => CreateRecipeHistory(changedAt, recipeName, action, $"{parts[3]} / {parts[4]}", parts[5], parts[6]),
            "CREATE" => CreateRecipeHistory(changedAt, recipeName, action, "Recipe", "-", recipeName),
            "HOST RECIPE CREATE" => CreateRecipeHistory(changedAt, recipeName, action, "Recipe", "-", recipeName),
            "DELETE" => CreateRecipeHistory(changedAt, recipeName, action, "Recipe", recipeName, "-"),
            "SELECT" when parts.Length >= 6 => CreateRecipeHistory(changedAt, recipeName, action, "Recipe", UnescapeField(parts[4]), UnescapeField(parts[5])),
            "RENAME" when parts.Length >= 6 => CreateRecipeHistory(changedAt, recipeName, action, parts[3], parts[4], parts[5]),
            "CHANGE" => CreateRecipeHistory(changedAt, recipeName, action, "Recipe", "-", recipeName),
            "SAVE" => CreateRecipeHistory(changedAt, recipeName, action, "Recipe", "-", recipeName),
            _ when parts.Length >= 6 => CreateRecipeHistory(changedAt, recipeName, action, parts[3], parts[4], parts[5]),
            _ => CreateRecipeHistory(changedAt, recipeName, action, "Recipe", "-", "-")};
    }

    private static ST_INTERFACE_HISTORY? ParseInterfaceLine(string line)
    {
        if (string.IsNullOrWhiteSpace(line))
        {
            return null;
        }

        var parts = SplitFields(line);
        if (parts.Length < 7 || !parts[1].Trim().Equals("INTERFACE", StringComparison.OrdinalIgnoreCase) || !TryReadModuleLogName(parts[2], out var module))
        {
            return null;
        }

        var afterState = UnescapeField(parts[6].Trim());
        var detail = "";
        var separator = afterState.IndexOf(" / ", StringComparison.Ordinal);
        if (separator >= 0)
        {
            detail = afterState[(separator + 3)..].Trim();
            afterState = afterState[..separator].Trim();
        }

        return new ST_INTERFACE_HISTORY(ParseTimestamp(parts[0].Trim()), module, UnescapeField(parts[3].Trim()), parts[4].Trim(), UnescapeField(parts[5].Trim()), afterState, detail);
    }

    private static ST_RECIPE_HISTORY CreateRecipeHistory(DateTimeOffset changedAt, string recipeName, string action, string itemName, string oldValue, string newValue, string tab = "", string group = "")
    {
        return new ST_RECIPE_HISTORY(changedAt, itemName.Trim(), oldValue.Trim(), newValue.Trim(), "LOG", recipeName, action, tab.Trim(), group.Trim());
    }

    private static ST_SETTING_HISTORY? ParseSettingLine(string line)
    {
        if (string.IsNullOrWhiteSpace(line))
        {
            return null;
        }

        var parts = SplitFields(line);
        if (parts.Length < 7 || !parts[1].Trim().Equals("SETTING", StringComparison.OrdinalIgnoreCase) || !TryReadSection(parts[2], out var section))
        {
            return null;
        }

        return new ST_SETTING_HISTORY(ParseTimestamp(parts[0].Trim()), section, UnescapeField(parts[4].Trim()), UnescapeField(parts[5].Trim()), UnescapeField(parts[6].Trim()), "LOG", parts[3].Trim());
    }

    private static string[] SplitFields(string line)
    {
        var fields = new List<string>();
        var value = new StringBuilder();
        for (var index = 0; index < line.Length; index++)
        {
            var current = line[index];
            if (current != '\\')
            {
                value.Append(current);
                continue;
            }

            if (index + 1 < line.Length && line[index + 1] == '\\')
            {
                value.Append('\\');
                index++;
                continue;
            }

            fields.Add(value.ToString());
            value.Clear();
        }

        fields.Add(value.ToString());
        return fields.ToArray();
    }

    private static string EscapeField(string value)
    {
        return value.Replace("\\", "\\\\").Replace("\r", " ").Replace("\n", " ");
    }

    private static string ModuleLogName(EN_EQP_MODULE module)
    {
        return module switch
        {
            EN_EQP_MODULE.WonikCtrl => "WONIK_CTRL",
            EN_EQP_MODULE.TalonLaser => "TALON_LASER",
            EN_EQP_MODULE.PowerMeter => "POWER_METER",
            _ => module.ToString().ToUpperInvariant()};
    }

    private static bool TryReadModuleLogName(string value, out EN_EQP_MODULE module)
    {
        var normalized = NormalizeModuleName(value);
        foreach (var candidate in Enum.GetValues<EN_EQP_MODULE>())
        {
            if (NormalizeModuleName(ModuleLogName(candidate)).Equals(normalized, StringComparison.Ordinal) || NormalizeModuleName(candidate.ToString()).Equals(normalized, StringComparison.Ordinal))
            {
                module = candidate;
                return true;
            }
        }

        module = EN_EQP_MODULE.WonikCtrl;
        return false;
    }

    private static string NormalizeModuleName(string value)
    {
        return new string (value.Where(char.IsLetterOrDigit).Select(char.ToUpperInvariant).ToArray());
    }

    private static string UnescapeField(string value)
    {
        return value.Replace("\\\\", "\\");
    }

    private static bool TryReadSection(string value, out EN_SETTING_TAB section)
    {
        section = value.Trim().ToUpperInvariant() switch
        {
            "OPTION" => EN_SETTING_TAB.Option,
            "INTERFACE" => EN_SETTING_TAB.Interface,
            "IO" => EN_SETTING_TAB.Io,
            "MOTOR" => EN_SETTING_TAB.Motor,
            "POSITION" => EN_SETTING_TAB.Option,
            "ALARM" => EN_SETTING_TAB.Alarm,
            _ => EN_SETTING_TAB.Option
        };
        return value.Trim().ToUpperInvariant()is "OPTION" or "INTERFACE" or "IO" or "MOTOR" or "POSITION" or "ALARM";
    }

    private static DateTimeOffset ParseTimestamp(string value)
    {
        var formats = new[]
        {
            "yy/MM/dd HH:mm:ss.fff",
            "yyyy/MM/dd HH:mm:ss.fff",
            "yy-MM-dd HH:mm:ss.fff",
            "yyyy-MM-dd HH:mm:ss.fff"
        };
        return DateTime.TryParseExact(value, formats, CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal, out var result) ? new DateTimeOffset(result) : DateTimeOffset.Now;
    }
}
