using System.Text;

namespace Drilling.Common.Log;

public sealed record ST_LOG_TEXT_PAGE(string Text, long NextOffset, long FileLength);

/// <summary>Reads bounded, unmodified text pages without indexing or loading the entire log.</summary>
public static class CLogTextReader
{
    public const int PageCharacterLimit = 128 * 1024;

    public static ST_LOG_TEXT_PAGE ReadPage(string path, long offset = 0)
    {
        var fullPath = Path.GetFullPath(path);
        if (fullPath.Split(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar)
            .Any(part => part.Equals("Alarm", StringComparison.OrdinalIgnoreCase))
            || Path.GetFileName(fullPath).StartsWith("Alarm_", StringComparison.OrdinalIgnoreCase))
            throw new ArgumentException("알람 로그는 ALARM 메뉴의 HISTORY/TREND에서 확인해 주세요.");

        using var stream = new FileStream(fullPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
        var length = stream.Length;
        if (offset < 0 || offset > length) throw new IOException("로그 파일 크기가 변경되었습니다. 파일을 다시 열어 주세요.");
        Span<byte> header = stackalloc byte[4];
        var count = stream.Read(header);
        var (encoding, preamble) = DetectEncoding(header[..count]);
        var start = offset == 0 ? preamble : offset;
        stream.Position = start;
        using var reader = new StreamReader(stream, encoding, detectEncodingFromByteOrderMarks: false);
        var buffer = new char[PageCharacterLimit];
        var characters = reader.ReadBlock(buffer, 0, buffer.Length);
        if (characters == buffer.Length)
        {
            // Keep complete lines where possible, and never split a surrogate pair across pages.
            var lastNewline = Array.LastIndexOf(buffer, '\n', characters - 1, characters);
            if (lastNewline >= 0) characters = lastNewline + 1;
            else if (char.IsHighSurrogate(buffer[characters - 1])) characters--;
        }
        var text = new string(buffer, 0, characters);
        var next = start + encoding.GetByteCount(text);
        return new(text, next, length);
    }

    private static (Encoding Encoding, int Preamble) DetectEncoding(ReadOnlySpan<byte> header)
    {
        if (header.StartsWith(new byte[] { 0xFF, 0xFE, 0, 0 })) return (new UTF32Encoding(false, true, true), 4);
        if (header.StartsWith(new byte[] { 0, 0, 0xFE, 0xFF })) return (new UTF32Encoding(true, true, true), 4);
        if (header.StartsWith(new byte[] { 0xFF, 0xFE })) return (new UnicodeEncoding(false, true, true), 2);
        if (header.StartsWith(new byte[] { 0xFE, 0xFF })) return (new UnicodeEncoding(true, true, true), 2);
        if (header.StartsWith(new byte[] { 0xEF, 0xBB, 0xBF })) return (new UTF8Encoding(false, true), 3);
        return (new UTF8Encoding(false, true), 0);
    }
}
