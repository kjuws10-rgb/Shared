namespace Drilling.Common.Log;

/// <summary>Limits log browsing and reading to ordinary files below the configured Log directory.</summary>
public sealed class CLogFileScope
{
    public CLogFileScope(string rootDirectory) => RootDirectory = Path.TrimEndingDirectorySeparator(Path.GetFullPath(rootDirectory));

    public string RootDirectory { get; }

    public string ResolveDirectory(string path)
    {
        var fullPath = ResolvePath(path);
        if (!Directory.Exists(fullPath)) throw new DirectoryNotFoundException("로그 폴더를 찾을 수 없습니다.");
        return fullPath;
    }

    public string ResolveFile(string path)
    {
        var fullPath = ResolvePath(path);
        if (!IsLogFile(fullPath) || Directory.Exists(fullPath))
            throw new ArgumentException("TXT, LOG, CSV 로그 파일만 열 수 있습니다.");
        return fullPath;
    }

    public static bool IsLogFile(string path) => Path.GetExtension(path).ToLowerInvariant() is ".txt" or ".log" or ".csv";

    public static bool IsAlarm(string name) => name.Equals("Alarm", StringComparison.OrdinalIgnoreCase)
        || name.StartsWith("Alarm_", StringComparison.OrdinalIgnoreCase);

    private string ResolvePath(string path)
    {
        var fullPath = Path.TrimEndingDirectorySeparator(Path.GetFullPath(path, RootDirectory));
        var relative = Path.GetRelativePath(RootDirectory, fullPath);
        if (Path.IsPathRooted(relative) || relative == ".."
            || relative.StartsWith(".." + Path.DirectorySeparatorChar, StringComparison.Ordinal))
            throw new ArgumentException("Log 폴더 밖으로 이동하거나 파일을 열 수 없습니다.");

        var parts = relative == "." ? [] : relative.Split(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
        if (parts.Any(IsAlarm)) throw new ArgumentException("알람 로그는 ALARM 메뉴의 HISTORY/TREND에서 확인해 주세요.");

        // Do not let a junction/symlink under Log redirect browsing or a later page read outside it.
        var current = RootDirectory;
        RejectLink(current);
        foreach (var part in parts)
        {
            current = Path.Combine(current, part);
            RejectLink(current);
        }
        return fullPath;
    }

    private static void RejectLink(string path)
    {
        if ((System.IO.File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0)
            throw new ArgumentException("연결된 폴더나 바로가기 파일은 로그 뷰어에서 열 수 없습니다.");
    }
}
