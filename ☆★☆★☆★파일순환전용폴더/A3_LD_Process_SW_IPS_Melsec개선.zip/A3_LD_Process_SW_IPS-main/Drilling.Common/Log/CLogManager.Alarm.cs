using System.Globalization;
using System.Text;
using System.Text.Json;
using Drilling.Common.Alarm;

namespace Drilling.Common.Log;

public sealed partial class CLogManager
{
    private readonly string _alarmLogRoot;
    private static readonly JsonSerializerOptions AlarmJson = new()
    {
        Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
    };

    public void Append(ST_ALARM_DATA alarm)
    {
        var entry = new ST_ALARM_HISTORY_ENTRY(alarm.OccurredAt, alarm.Code, alarm.Id, alarm.Group,
            alarm.Severity == EN_ALARM_LEVEL.Critical ? "HEAVY" : alarm.Severity == EN_ALARM_LEVEL.Warning ? "LIGHT" : "INFO",
            alarm.Message, alarm.RecoveryAction, alarm.CimAddress);
        var path = AlarmLogPath(alarm.OccurredAt.LocalDateTime.Date);
        var line = JsonSerializer.Serialize(entry, AlarmJson) + Environment.NewLine;
        lock (FileLock)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(path)!);
            System.IO.File.AppendAllText(path, line, new UTF8Encoding(false));
        }
    }

    public ST_ALARM_HISTORY_RESULT Read(DateTime from, DateTime through, CancellationToken token = default)
    {
        from = from.Date;
        through = through.Date;
        if (from > through) throw new ArgumentException("시작 날짜는 종료 날짜보다 늦을 수 없습니다.");
        var rows = new List<ST_ALARM_HISTORY_ENTRY>();
        var warnings = new List<string>();
        for (var date = from; ; date = date.AddDays(1))
        {
            token.ThrowIfCancellationRequested();
            var path = AlarmLogPath(date);
            try
            {
                string[] lines;
                lock (FileLock) lines = System.IO.File.Exists(path) ? System.IO.File.ReadAllLines(path, Encoding.UTF8) : [];
                var invalidLines = 0;
                foreach (var line in lines)
                {
                    token.ThrowIfCancellationRequested();
                    if (string.IsNullOrWhiteSpace(line)) continue;
                    try
                    {
                        var row = JsonSerializer.Deserialize<ST_ALARM_HISTORY_ENTRY>(line, AlarmJson);
                        if (row is null || row.OccurredAt == default || row.Code < 0 || row.Cause is null || row.Group is null)
                        { invalidLines++; continue; }
                        if (row.OccurredAt.LocalDateTime.Date >= from && row.OccurredAt.LocalDateTime.Date <= through)
                            rows.Add(row);
                    }
                    catch (JsonException) { invalidLines++; }
                }
                if (invalidLines > 0) warnings.Add($"{date:yyyy-MM-dd}: 손상된 로그 {invalidLines}건 제외");
            }
            catch (Exception exception) when (exception is IOException or UnauthorizedAccessException)
            {
                warnings.Add($"{date:yyyy-MM-dd}: {exception.Message}");
            }
            if (date == through) break;
        }
        return new(rows.OrderByDescending(row => row.OccurredAt).ThenBy(row => row.Code).ToArray(), string.Join(Environment.NewLine, warnings));
    }

    private string AlarmLogPath(DateTime date)
    {
        var day = date.ToString("yyyyMMdd", CultureInfo.InvariantCulture);
        return Path.Combine(_alarmLogRoot, day, $"Alarm_{day}.jsonl");
    }
}
