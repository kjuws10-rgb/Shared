using System.Globalization;
using Drilling.Common.Interface;

namespace Drilling.Common.Log;

public sealed partial class CLogManager
{
    public IReadOnlyList<ST_INTERFACE_HISTORY> ReadInterfaceWindow(
        EN_EQP_MODULE? module, string nickName, int maxRows,
        DateTimeOffset from, DateTimeOffset through,
        Func<ST_INTERFACE_HISTORY, bool>? filter = null,
        CancellationToken cancellationToken = default)
    {
        if (through < from) throw new ArgumentException("History end must not precede its start.", nameof(through));
        if (maxRows <= 0) return [];

        var name = nickName.Trim();
        var latest = new PriorityQueue<(ST_INTERFACE_HISTORY Item, long Order), (DateTimeOffset Time, long Order)>();
        long order = 0;
        foreach (var path in EnumerateInterfaceWindowFiles(module, from, through))
        {
            cancellationToken.ThrowIfCancellationRequested();
            try
            {
                // Logging may append while history is read. Stream only the relevant
                // daily files and keep at most maxRows records in memory.
                using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
                using var reader = new StreamReader(stream, detectEncodingFromByteOrderMarks: true);
                while (reader.ReadLine() is { } line)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    var item = ParseInterfaceLine(line);
                    if (item is null || item.OccurredAt < from || item.OccurredAt > through ||
                        (module.HasValue && item.Module != module.Value) ||
                        (name.Length > 0 && !item.NickName.Equals(name, StringComparison.OrdinalIgnoreCase)) ||
                        (filter is not null && !filter(item)))
                    {
                        continue;
                    }

                    var entry = (Item: item, Order: order++);
                    var priority = (item.OccurredAt, entry.Order);
                    if (latest.Count < maxRows) latest.Enqueue(entry, priority);
                    else latest.EnqueueDequeue(entry, priority);
                }
            }
            catch (IOException)
            {
                // Match existing history behavior when a log is temporarily unavailable.
            }
            catch (UnauthorizedAccessException)
            {
            }
        }

        return latest.UnorderedItems.Select(value => value.Element)
            .OrderByDescending(value => value.Item.OccurredAt)
            .ThenByDescending(value => value.Order)
            .Select(value => value.Item).ToArray();
    }

    private IEnumerable<string> EnumerateInterfaceWindowFiles(EN_EQP_MODULE? module, DateTimeOffset from, DateTimeOffset through)
    {
        if (!Directory.Exists(_interfaceLogRoot)) yield break;
        var moduleDirectories = module.HasValue
            ? new[] { Path.Combine(_interfaceLogRoot, ModuleLogName(module.Value)) }
            : Directory.GetDirectories(_interfaceLogRoot);
        foreach (var moduleDirectory in moduleDirectories)
        {
            for (var date = from.ToLocalTime().Date; date <= through.ToLocalTime().Date; date = date.AddDays(1))
            {
                var directory = Path.Combine(moduleDirectory, date.ToString("yyyyMMdd", CultureInfo.InvariantCulture));
                if (!Directory.Exists(directory)) continue;
                foreach (var path in Directory.EnumerateFiles(directory, "*.txt").OrderBy(path => path, StringComparer.OrdinalIgnoreCase))
                    yield return path;
            }
        }
    }
}
