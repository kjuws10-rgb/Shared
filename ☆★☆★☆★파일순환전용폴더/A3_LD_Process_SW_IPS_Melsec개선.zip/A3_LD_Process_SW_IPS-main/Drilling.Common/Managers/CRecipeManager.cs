using Drilling.Common.Alarm;
using Drilling.Common.Interface;
using Drilling.Common.InterLock;
using Drilling.Common.Managers;
using Drilling.Common.Motion;
using Drilling.Common.Station;

namespace Drilling.Common.Managers;
public enum EN_RECIPE_DATA_TYPE
{
    String,
    Int,
    Double,
    Bool
}

public sealed record ST_RECIPE_PARAMETER(string Name, string Value, string Unit, string Range, string DefaultValue, string Tab = "", string Group = "", string Key = "", string Description = "", bool Show = true, bool Use = true, int DisplayOrder = 0, EN_RECIPE_DATA_TYPE DataType = EN_RECIPE_DATA_TYPE.String, double ChangeLimit = 0.0, double Min = 0.0, double Max = 0.0, IReadOnlyDictionary<string, string>? Extra = null);
public sealed record ST_RECIPE_HISTORY(DateTimeOffset ChangedAt, string ItemName, string OldValue, string NewValue, string OperatorId, string RecipeName = "", string Action = "", string Tab = "", string Group = "");
public sealed record ST_RECIPE_DEFINITION(string Id, string Name, IReadOnlyList<ST_RECIPE_PARAMETER> Parameters, IReadOnlyList<ST_RECIPE_HISTORY> History);
public sealed record ST_RECIPE_FORM_ITEM(string Tab, string Group, string Name, string DisplayName, string CimName, EN_RECIPE_DATA_TYPE DataType, string Unit, bool Show, bool Use, string DefaultValue, double Scale, double ChangeLimit, double Min, double Max, string Description, int DisplayOrder, IReadOnlyDictionary<string, string>? Extra = null);
public sealed record ST_RECIPE_VALUE(string Tab, string Name, string Value, IReadOnlyList<string>? Extra = null);
public abstract class CRecipeFileBase
{
    public abstract Task<IReadOnlyList<ST_RECIPE_DEFINITION>> LoadAll(CancellationToken cancellationToken = default);
    public abstract Task<ST_RECIPE_DEFINITION?> Find(string recipeId, CancellationToken cancellationToken = default);
    public abstract Task Save(ST_RECIPE_DEFINITION recipe, CancellationToken cancellationToken = default);
    public abstract Task Rename(string oldRecipeId, string newRecipeId, CancellationToken cancellationToken = default);
    public abstract Task Delete(string recipeId, CancellationToken cancellationToken = default);
    public abstract Task<IReadOnlyList<ST_RECIPE_HISTORY>> LoadHistory(CancellationToken cancellationToken = default);
    public abstract Task RecordSelection(string previousRecipeId, string recipeId, CancellationToken cancellationToken = default);
}

public sealed class CRecipeManager(CRecipeFileBase recipeFile)
{
    private readonly object _cacheLock = new();
    private IReadOnlyList<ST_RECIPE_DEFINITION>? _recipeCache;
    private readonly SemaphoreSlim _historyGate = new(1, 1);
    private IReadOnlyList<ST_RECIPE_HISTORY>? _historyCache;

    public Task<IReadOnlyList<ST_RECIPE_HISTORY>> LoadHistory(CancellationToken cancellationToken = default)
        => LoadHistoryCore(false, cancellationToken);

    private async Task<IReadOnlyList<ST_RECIPE_HISTORY>> LoadHistoryCore(bool refresh, CancellationToken cancellationToken)
    {
        await _historyGate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            if (refresh || _historyCache is null)
                _historyCache = (await recipeFile.LoadHistory(cancellationToken).ConfigureAwait(false)).ToArray();
            return _historyCache;
        }
        finally
        {
            _historyGate.Release();
        }
    }

    public async Task RecordSelection(string previousRecipeId, string recipeId, CancellationToken cancellationToken = default)
    {
        await recipeFile.RecordSelection(previousRecipeId, recipeId, cancellationToken);
        await LoadHistoryCore(true, cancellationToken);
    }

    public async Task<IReadOnlyList<ST_RECIPE_DEFINITION>> LoadRecipes(CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        lock (_cacheLock)
        {
            if (_recipeCache is not null)
            {
                return _recipeCache;
            }
        }

        var recipes = (await recipeFile.LoadAll(cancellationToken)).ToArray();
        lock (_cacheLock)
        {
            _recipeCache ??= recipes;
            return _recipeCache;
        }
    }

    public async Task SaveRecipe(ST_RECIPE_DEFINITION recipe, CancellationToken cancellationToken = default)
    {
        ST_RECIPE_DEFINITION? current;
        lock (_cacheLock) current = _recipeCache?.FirstOrDefault(item => item.Id.Equals(recipe.Id, StringComparison.OrdinalIgnoreCase));
        current ??= await recipeFile.Find(recipe.Id, cancellationToken);
        recipe = global::Drilling.Common.Recipe.CAlignShotOffsetData.RetainUneditedOffsets(recipe, current);
        await recipeFile.Save(recipe, cancellationToken);
        // The editor supplies History = []; retain the persisted, newly logged history instead.
        var savedRecipe = await recipeFile.Find(recipe.Id, cancellationToken) ?? recipe;
        UpdateCachedRecipe(savedRecipe);
        await LoadHistoryCore(true, cancellationToken);
    }

    public async Task<ST_RECIPE_DEFINITION?> RefreshRecipe(string recipeId, CancellationToken cancellationToken = default)
    {
        var recipe = await recipeFile.Find(recipeId, cancellationToken);
        if (recipe is not null) UpdateCachedRecipe(recipe);
        else DeleteCachedRecipe(recipeId);
        return recipe;
    }

    public async Task RenameRecipe(string oldRecipeId, string newRecipeId, CancellationToken cancellationToken = default)
    {
        await recipeFile.Rename(oldRecipeId, newRecipeId, cancellationToken);
        RenameCachedRecipe(oldRecipeId, newRecipeId);
        var renamedRecipe = await recipeFile.Find(newRecipeId, cancellationToken);
        if (renamedRecipe is not null) UpdateCachedRecipe(renamedRecipe);
        await LoadHistoryCore(true, cancellationToken);
    }

    public async Task DeleteRecipe(string recipeId, CancellationToken cancellationToken = default)
    {
        await recipeFile.Delete(recipeId, cancellationToken);
        DeleteCachedRecipe(recipeId);
        await LoadHistoryCore(true, cancellationToken);
    }

    private void UpdateCachedRecipe(ST_RECIPE_DEFINITION recipe)
    {
        lock (_cacheLock)
        {
            if (_recipeCache is null)
            {
                return;
            }

            var recipes = new List<ST_RECIPE_DEFINITION>(_recipeCache.Count + 1);
            var updated = false;
            foreach (var cachedRecipe in _recipeCache)
            {
                if (cachedRecipe.Id.Equals(recipe.Id, StringComparison.OrdinalIgnoreCase))
                {
                    recipes.Add(CloneRecipe(recipe));
                    updated = true;
                    continue;
                }

                recipes.Add(cachedRecipe);
            }

            if (!updated)
            {
                recipes.Add(CloneRecipe(recipe));
            }

            _recipeCache = recipes.ToArray();
        }
    }

    private void RenameCachedRecipe(string oldRecipeId, string newRecipeId)
    {
        lock (_cacheLock)
        {
            if (_recipeCache is null)
            {
                return;
            }

            var recipes = new List<ST_RECIPE_DEFINITION>(_recipeCache.Count);
            foreach (var cachedRecipe in _recipeCache)
            {
                if (cachedRecipe.Id.Equals(oldRecipeId, StringComparison.OrdinalIgnoreCase))
                {
                    recipes.Add(CloneRecipe(cachedRecipe with
                    {
                        Id = newRecipeId,
                        Name = newRecipeId
                    }));
                    continue;
                }

                recipes.Add(cachedRecipe);
            }

            _recipeCache = recipes.ToArray();
        }
    }

    private void DeleteCachedRecipe(string recipeId)
    {
        lock (_cacheLock)
        {
            if (_recipeCache is null)
            {
                return;
            }

            var recipes = new List<ST_RECIPE_DEFINITION>(_recipeCache.Count);
            foreach (var cachedRecipe in _recipeCache)
            {
                if (!cachedRecipe.Id.Equals(recipeId, StringComparison.OrdinalIgnoreCase))
                {
                    recipes.Add(cachedRecipe);
                }
            }

            _recipeCache = recipes.ToArray();
        }
    }

    private static ST_RECIPE_DEFINITION CloneRecipe(ST_RECIPE_DEFINITION recipe)
    {
        return recipe with
        {
            Parameters = recipe.Parameters.ToArray(),
            History = recipe.History.ToArray()
        };
    }
}
