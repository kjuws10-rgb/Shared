using Drilling.Common.Interface;
using Drilling.Common.Alarm;
using Drilling.Common.InterLock;
using Drilling.Common.Managers;
using Drilling.Common.Motion;
using Drilling.Common.Station;
using System.IO;

namespace Drilling.Common.Managers;
public enum EN_SETTING_TAB
{
    Option,
    Interface,
    Io,
    Motor,
    Alarm
}

public sealed record ST_SYSTEM_PARAMETER(EN_SETTING_TAB Section, string Name, string Value, string Unit, string Description, string Group = "", string Key = "", string DefaultValue = "", EN_RECIPE_DATA_TYPE DataType = EN_RECIPE_DATA_TYPE.String, double Min = 0.0, double Max = 0.0, bool Show = true, bool Use = true, int DisplayOrder = 0, IReadOnlyDictionary<string, string>? Extra = null);
public sealed record ST_SETTING_HISTORY(DateTimeOffset ChangedAt, EN_SETTING_TAB Section, string ParameterName, string OldValue, string NewValue, string OperatorId, string Action);
public abstract class CSettingFileBase
{
    public abstract IReadOnlyList<ST_SYSTEM_PARAMETER> Load(EN_SETTING_TAB section, CancellationToken cancellationToken = default);
    public abstract void Save(EN_SETTING_TAB section, IReadOnlyList<ST_SYSTEM_PARAMETER> parameters, CancellationToken cancellationToken = default);
    public abstract IReadOnlyList<ST_SETTING_HISTORY> LoadHistory(EN_SETTING_TAB section, CancellationToken cancellationToken = default);
}

public abstract class CInterfaceFileBase
{
    public abstract IReadOnlyList<ST_INTERFACE_DATA> LoadAll(CancellationToken cancellationToken = default);
    public abstract void SaveAll(IReadOnlyList<ST_INTERFACE_DATA> interfaces, CancellationToken cancellationToken = default);
}

public sealed class CSettingManager(CSettingFileBase settingFile, CInterfaceFileBase interfaceFile, CInterfaceManager interfaceManager)
{
    private readonly object _cacheLock = new();
    private readonly object _saveLock = new();
    private readonly Dictionary<EN_SETTING_TAB, IReadOnlyList<ST_SYSTEM_PARAMETER>> _sectionCache = new();

    public IReadOnlyList<ST_SYSTEM_PARAMETER> LoadSection(EN_SETTING_TAB section, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        lock (_cacheLock)
        {
            if (_sectionCache.TryGetValue(section, out var cachedParameters))
            {
                return cachedParameters;
            }
        }

        return ReloadSection(section, cancellationToken);
    }

    public IReadOnlyList<ST_SYSTEM_PARAMETER> ReloadSection(EN_SETTING_TAB section, CancellationToken cancellationToken = default)
    {
        lock (_saveLock)
        {
            var loadedParameters = settingFile.Load(section, cancellationToken).ToArray();
            lock (_cacheLock) _sectionCache[section] = loadedParameters;
            return loadedParameters;
        }
    }

    public void LoadAllSections(CancellationToken cancellationToken = default)
    {
        foreach (var section in Enum.GetValues<EN_SETTING_TAB>())
        {
            ReloadSection(section, cancellationToken);
        }
    }

    public string GetValue(EN_SETTING_TAB section, string name, string defaultValue = "", CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(name);
        var parameters = LoadSection(section, cancellationToken);
        bool MatchesItem(global::Drilling.Common.Managers.ST_SYSTEM_PARAMETER item)
        {
            return item.Key.Equals(name, StringComparison.OrdinalIgnoreCase) || item.Name.Equals(name, StringComparison.OrdinalIgnoreCase);
        }

        var parameter = parameters.FirstOrDefault(MatchesItem);
        return parameter is null || string.IsNullOrWhiteSpace(parameter.Value) ? defaultValue : parameter.Value;
    }

    public void SetValue(EN_SETTING_TAB section, string name, string value, CancellationToken cancellationToken = default)
    {
        lock (_saveLock)
        {
            ArgumentException.ThrowIfNullOrWhiteSpace(name);
            var parameters = LoadSection(section, cancellationToken);
            var found = false;
            global::Drilling.Common.Managers.ST_SYSTEM_PARAMETER SelectParameter(global::Drilling.Common.Managers.ST_SYSTEM_PARAMETER parameter)
            {
                var isTarget = parameter.Key.Equals(name, StringComparison.OrdinalIgnoreCase) || parameter.Name.Equals(name, StringComparison.OrdinalIgnoreCase);
                if (!isTarget)
                {
                    return parameter;
                }

                found = true;
                return parameter with
                {
                    Value = value
                };
            }

            var editedParameters = parameters.Select(SelectParameter).ToArray();
            if (!found)
            {
                throw new InvalidDataException($"Setting parameter is not defined: {section}/{name}");
            }

            SaveSection(section, editedParameters, cancellationToken);
        }
    }

    public void SaveSection(EN_SETTING_TAB section, IReadOnlyList<ST_SYSTEM_PARAMETER> parameters, CancellationToken cancellationToken = default)
    {
        lock (_saveLock)
        {
            if (section == EN_SETTING_TAB.Option)
            {
                var edited = CRunOptionSettings.Read(parameters);
                var current = CRunOptionSettings.Read(LoadSection(section, cancellationToken));
                var able = interfaceManager?.Melsec.GetCachedSnapshot().GetValueOrDefault("HANDSHAKE_PRC_REVIEW_ABLE");
                if (edited.ReviewOptions != current.ReviewOptions && able?.IsValid == true &&
                    Convert.ToDouble(able.Value, System.Globalization.CultureInfo.InvariantCulture) == 1)
                    throw new InvalidDataException("Review ABLE ON 상태에서는 리뷰 Run Option을 변경할 수 없습니다.");
            }
            settingFile.Save(section, parameters, cancellationToken);
            lock (_cacheLock) _sectionCache[section] = parameters.ToArray();
        }
    }

    public IReadOnlyList<ST_SETTING_HISTORY> LoadHistory(EN_SETTING_TAB section, CancellationToken cancellationToken = default)
    {
        return settingFile.LoadHistory(section, cancellationToken);
    }

    public IReadOnlyList<ST_INTERFACE_DATA> LoadInterfaceList(CancellationToken cancellationToken = default)
    {
        return interfaceFile.LoadAll(cancellationToken);
    }

    public async Task SaveInterfaceList(IReadOnlyList<ST_INTERFACE_DATA> interfaces, CancellationToken cancellationToken = default)
    {
        interfaceFile.SaveAll(interfaces, cancellationToken);
        await interfaceManager.Reload(interfaces, reconnect: false, cancellationToken);
    }

    public Task ConnectInterface(EN_EQP_MODULE module, int number, CancellationToken cancellationToken = default)
    {
        return interfaceManager.Connect(module, number, cancellationToken: cancellationToken);
    }

    public Task DisconnectInterface(EN_EQP_MODULE module, int number, CancellationToken cancellationToken = default)
    {
        return interfaceManager.Disconnect(module, number, cancellationToken);
    }

    public Task ReconnectInterface(EN_EQP_MODULE module, int number, CancellationToken cancellationToken = default)
    {
        return interfaceManager.Reconnect(module, number, cancellationToken);
    }
}
