using System.Globalization;
using Drilling.Common.Review;

namespace Drilling.Common.Managers;

/// <summary>Numeric Setting storage contract; UI labels and execution counts are decoded here.</summary>
public static class CRunOptionSettings
{
    public const string ZeroDefence = "RUNOPTION_ZERO_DEFENCE_USE";
    public const string CurrentGroup = "RUNOPTION_CURRENT_GROUP";
    public const string FollowUp = "RUNOPTION_FOLLOWUP_USE";
    public const string ReviewMethod = "RUNOPTION_REVIEW_METHOD";
    public const string ReviewLine = "RUNOPTION_REVIEW_LINE";
    public const string ImmediateRetry = "RUNOPTION_REVIEW_IMMEDIATE_RETRY";
    public const string RetryCount = "RUNOPTION_REVIEW_RETRY_COUNT";
    private static readonly HashSet<string> Keys = new([ZeroDefence, CurrentGroup, FollowUp, ReviewMethod, ReviewLine, ImmediateRetry, RetryCount], StringComparer.OrdinalIgnoreCase);
    public static bool IsKey(string key) => Keys.Contains(key);

    public static ST_RUN_OPTION_SETTINGS Read(CSettingManager settings) => Read(settings.LoadSection(EN_SETTING_TAB.Option));
    public static ST_RUN_OPTION_SETTINGS Read(IReadOnlyList<ST_SYSTEM_PARAMETER> parameters)
    {
        var values = parameters.Where(p => IsKey(p.Key)).ToDictionary(p => p.Key, p => p.Value, StringComparer.OrdinalIgnoreCase);
        return new(Number(ZeroDefence, 0, 0, 1) == 1, Number(CurrentGroup, 1, 1, 4), Number(FollowUp, 0, 0, 1) == 1,
            Number(ReviewMethod, 1, 0, 1), Number(ReviewLine, 0, 0, 3), Number(ImmediateRetry, 0, 0, 1) == 1, Number(RetryCount, 1, 1, 3));

        int Number(string key, int fallback, int min, int max)
        {
            if (!values.TryGetValue(key, out var text)) return fallback;
            if (int.TryParse(text, NumberStyles.Integer, CultureInfo.InvariantCulture, out var value) && value >= min && value <= max) return value;
            throw new InvalidDataException($"{key}: {min}~{max} 범위의 정수를 입력해 주세요.");
        }
    }
    public static int EncodeLine(int count) => count switch
    {
        1 => 0, 3 => 1, 5 => 2, 7 => 3,
        _ => throw new ArgumentOutOfRangeException(nameof(count))
    };
}

public sealed record ST_RUN_OPTION_SETTINGS(bool ZeroDefence, int CurrentGroup, bool FollowUp,
    int ReviewMethod, int ReviewLineIndex, bool ImmediateRetry, int RetryCount)
{
    public int ReviewLineCount => ReviewLineIndex switch { 0 => 1, 1 => 3, 2 => 5, 3 => 7, _ => throw new InvalidDataException("Review Line 설정 오류") };
    public ST_AUTO_REVIEW_OPTIONS ReviewOptions => new(ReviewLineCount,
        ReviewMethod == 0 ? EN_FINE_INSPECTION_METHOD.PtoP : EN_FINE_INSPECTION_METHOD.Flying, RetryCount, ImmediateRetry);
}
