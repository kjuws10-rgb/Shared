namespace Drilling.Common.Motion;

/// <summary>Rest-to-rest trapezoidal/triangular motion, in mm and seconds.</summary>
public sealed class CTrapezoidalMotion
{
    public CTrapezoidalMotion(double distance, double speed, double acceleration, double? deceleration = null)
    {
        var dec = deceleration ?? acceleration;
        if (!double.IsFinite(distance) || distance < 0 || !double.IsFinite(speed) || speed <= 0 ||
            !double.IsFinite(acceleration) || acceleration <= 0 || !double.IsFinite(dec) || dec <= 0)
            throw new ArgumentException("이동 거리·속도·가감속 값을 확인해 주세요.");
        Distance = distance; Acceleration = acceleration; Deceleration = dec;
        PeakSpeed = Math.Min(speed, Math.Sqrt(2 * distance / (1 / acceleration + 1 / dec)));
        AccelerationDistance = PeakSpeed * PeakSpeed / (2 * acceleration);
        DecelerationDistance = PeakSpeed * PeakSpeed / (2 * dec);
        CruiseDistance = Math.Max(0, distance - AccelerationDistance - DecelerationDistance);
        AccelerationTime = PeakSpeed / acceleration;
        CruiseTime = PeakSpeed == 0 ? 0 : CruiseDistance / PeakSpeed;
        Duration = AccelerationTime + CruiseTime + PeakSpeed / dec;
    }
    public double Distance { get; }
    public double PeakSpeed { get; }
    public double Acceleration { get; }
    public double Deceleration { get; }
    public double AccelerationDistance { get; }
    public double DecelerationDistance { get; }
    public double CruiseDistance { get; }
    public double AccelerationTime { get; }
    public double CruiseTime { get; }
    public double Duration { get; }
    public double TimeAt(double distance)
    {
        if (!double.IsFinite(distance) || distance < -1e-8 || distance > Distance + 1e-8)
            throw new ArgumentOutOfRangeException(nameof(distance), "MCC 이동 구간 밖입니다.");
        distance = Math.Clamp(distance, 0, Distance);
        if (distance <= AccelerationDistance) return Math.Sqrt(2 * distance / Acceleration);
        if (distance <= AccelerationDistance + CruiseDistance) return AccelerationTime + (distance - AccelerationDistance) / PeakSpeed;
        return Duration - Math.Sqrt(2 * (Distance - distance) / Deceleration);
    }
    public (double Position, double Speed) At(double seconds)
    {
        if (seconds >= Duration) return (Distance, 0);
        if (seconds <= 0) return (0, 0);
        if (seconds < AccelerationTime) return (0.5 * Acceleration * seconds * seconds, Acceleration * seconds);
        if (seconds < AccelerationTime + CruiseTime)
            return (AccelerationDistance + PeakSpeed * (seconds - AccelerationTime), PeakSpeed);
        var left = Duration - seconds;
        return (Distance - 0.5 * Deceleration * left * left, Deceleration * left);
    }
}
