using System.Diagnostics;

namespace Drilling.Common.Motion;

public enum EN_MANUAL_STAGE_AXIS { StageY, ReviewX }
public sealed record ST_MANUAL_STAGE_SIMULATION_AXIS(EN_MANUAL_STAGE_AXIS Axis, double Position, double Speed)
{
    public bool IsMoving { get; init; }
}

/// <summary>Local motion preview only. Never sends commands to a device.</summary>
public sealed class CManualStageMotionSimulation(Func<double>? elapsedSeconds = null)
{
    public const double MoveSpeed = 5.0;
    private readonly object _sync = new();
    private readonly Func<double> _clock = elapsedSeconds ?? (() => (double)Stopwatch.GetTimestamp() / Stopwatch.Frequency);
    private readonly Dictionary<EN_MANUAL_STAGE_AXIS, AxisState> _axes = new()
    {
        [EN_MANUAL_STAGE_AXIS.StageY] = new(), [EN_MANUAL_STAGE_AXIS.ReviewX] = new()
    };
    private double? _updatedAt;
    private MotionLease? _lease;

    public bool IsReserved { get { lock (_sync) return _lease is not null; } }

    public MotionLease AcquireExclusiveMotion()
    {
        lock (_sync)
        {
            Advance();
            if (_lease is not null || _axes.Values.Any(axis => axis.Speed != 0 || axis.Target.HasValue))
                throw new InvalidOperationException("Stage가 사용 중입니다. 정지 후 다시 실행해 주세요.");
            return _lease = new MotionLease(this);
        }
    }

    public IReadOnlyList<ST_MANUAL_STAGE_SIMULATION_AXIS> GetSnapshot()
    {
        lock (_sync)
        {
            Advance();
            return _axes.Select(pair => new ST_MANUAL_STAGE_SIMULATION_AXIS(pair.Key, pair.Value.Position, pair.Value.Speed)
                { IsMoving = pair.Value.Target.HasValue || pair.Value.Speed != 0 }).ToArray();
        }
    }

    public void Move(EN_MANUAL_STAGE_AXIS axis, double value, bool relative, double speed = MoveSpeed)
        => MoveCore(axis, value, relative, speed, null);

    private void MoveCore(EN_MANUAL_STAGE_AXIS axis, double value, bool relative, double speed, MotionLease? owner, double? acceleration = null)
    {
        if (!double.IsFinite(value)) throw new ArgumentException("이동값은 유한한 숫자로 입력해 주세요.");
        if (!double.IsFinite(speed) || speed <= 0) throw new ArgumentException("이동 속도는 0보다 큰 유한한 숫자로 입력해 주세요.");
        lock (_sync)
        {
            if (!ReferenceEquals(_lease, owner)) throw new InvalidOperationException("MOF 실행 중에는 Stage 이동값을 변경할 수 없습니다.");
            Advance();
            var state = _axes[axis];
            var target = relative ? state.Position + value : value;
            if (!double.IsFinite(target)) throw new ArgumentException("계산된 목표 위치가 범위를 벗어났습니다.");
            var profile = acceleration.HasValue ? new CTrapezoidalMotion(Math.Abs(target - state.Position), speed, acceleration.Value) : null;
            state.Target = target == state.Position ? null : target;
            state.Speed = Math.Sign(target - state.Position) * speed;
            state.Profile = state.Target.HasValue ? profile : null;
            state.ProfileStart = _clock(); state.ProfileOrigin = state.Position;
        }
    }

    public void StartJog(EN_MANUAL_STAGE_AXIS axis, int direction)
    {
        if (direction is not (-1 or 1)) throw new ArgumentException("JOG 방향을 확인해 주세요.");
        lock (_sync)
        {
            if (_lease is not null) throw new InvalidOperationException("MOF 실행 중에는 JOG를 사용할 수 없습니다.");
            Advance();
            foreach (var state in _axes.Values) { state.Speed = 0; state.Target = null; state.Profile = null; }
            _axes[axis].Speed = direction * MoveSpeed;
        }
    }

    public void Stop()
    {
        lock (_sync)
        {
            Advance();
            foreach (var state in _axes.Values) { state.Speed = 0; state.Target = null; state.Profile = null; }
        }
    }

    public void StopJog()
    {
        lock (_sync)
        {
            Advance();
            foreach (var state in _axes.Values.Where(state => state.Target is null)) state.Speed = 0;
        }
    }

    public void Stop(EN_MANUAL_STAGE_AXIS axis)
    {
        lock (_sync)
        {
            Advance();
            _axes[axis].Speed = 0;
            _axes[axis].Target = null;
            _axes[axis].Profile = null;
        }
    }

    private void Advance()
    {
        var now = _clock();
        var seconds = _updatedAt.HasValue ? Math.Max(0, now - _updatedAt.Value) : 0;
        _updatedAt = now;
        foreach (var state in _axes.Values)
        {
            if (state.Profile is { } profile && state.Target is { } profileTarget)
            {
                var elapsed = Math.Max(0, now - state.ProfileStart);
                var sample = profile.At(elapsed);
                var direction = Math.Sign(profileTarget - state.ProfileOrigin);
                state.Position = state.ProfileOrigin + direction * sample.Position;
                state.Speed = direction * sample.Speed;
                if (elapsed >= profile.Duration) { state.Position = profileTarget; state.Target = null; state.Profile = null; }
                continue;
            }
            if (state.Speed == 0) continue;
            var next = state.Position + state.Speed * seconds;
            if (state.Target is { } target &&
                (state.Speed > 0 ? next >= target : next <= target))
            {
                state.Position = target; state.Speed = 0; state.Target = null;
            }
            else if (double.IsFinite(next)) state.Position = next;
            else { state.Speed = 0; state.Target = null; }
        }
    }

    private sealed class AxisState
    {
        public double Position;
        public double Speed;
        public double? Target;
        public CTrapezoidalMotion? Profile;
        public double ProfileStart;
        public double ProfileOrigin;
    }

    public sealed class MotionLease : IDisposable
    {
        private readonly CManualStageMotionSimulation _owner;
        internal MotionLease(CManualStageMotionSimulation owner) => _owner = owner;
        public void Move(EN_MANUAL_STAGE_AXIS axis, double value, double speed, double? acceleration = null)
            => _owner.MoveCore(axis, value, false, speed, this, acceleration);
        public void Dispose()
        {
            lock (_owner._sync)
                if (ReferenceEquals(_owner._lease, this)) _owner._lease = null;
        }
    }
}
