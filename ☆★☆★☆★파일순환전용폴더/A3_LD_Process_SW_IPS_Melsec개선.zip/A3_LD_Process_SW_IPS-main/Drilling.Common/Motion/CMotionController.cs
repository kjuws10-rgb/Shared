using System.Globalization;
using Drilling.Common.Managers;
using Drilling.Common.Interface;
using Drilling.Common.Motion;
using Drilling.Common.Alarm;
using Drilling.Common.InterLock;
using Drilling.Common.Station;

namespace Drilling.Common.Motion;
[AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
internal sealed class CMotionControllerTypeAttribute(params string[] controllerNames) : Attribute
{
    public IReadOnlyList<string> ControllerNames { get; } = controllerNames.Where(name => !string.IsNullOrWhiteSpace(name)).Select(NormalizeControllerName).Distinct(StringComparer.OrdinalIgnoreCase).ToArray();

    private static string NormalizeControllerName(string value)
    {
        return value.Trim().ToUpperInvariant().Replace(" ", "", StringComparison.OrdinalIgnoreCase);
    }
}

internal abstract class CMotionController(string controller, CInterfaceManager? interfaceManager, int deviceNo = 0)
{
    private readonly CInterfaceManager? _interfaceManager = interfaceManager;
    public string Controller { get; } = controller.Trim().ToUpperInvariant();
    public int DeviceNo { get; } = deviceNo;

    protected virtual EN_EQP_MODULE PrimaryModule
    {
        get
        {
            return EN_EQP_MODULE.Motion;
        }
    }

    protected abstract string CommandPrefix { get; }

    public bool IsSimulation()
    {
        var interfaceData = GetInterfaceData();
        return interfaceData is null || _interfaceManager?.IsSimul(interfaceData.Device, interfaceData.Number) != false;
    }

    public virtual async Task Initialize(IReadOnlyList<ST_MOTOR_DATA> axes, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var interfaceData = GetInterfaceData();
        if (_interfaceManager is null || interfaceData is null)
        {
            return;
        }

        if (!_interfaceManager.IsConnect(interfaceData.Device, interfaceData.Number))
        {
            await _interfaceManager.Connect(interfaceData.Device, interfaceData.Number, cancellationToken: cancellationToken);
        }
    }

    public virtual async Task Destroy(CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var interfaceData = GetInterfaceData();
        if (_interfaceManager is null || interfaceData is null)
        {
            return;
        }

        if (_interfaceManager.IsConnect(interfaceData.Device, interfaceData.Number))
        {
            await _interfaceManager.Disconnect(interfaceData.Device, interfaceData.Number, cancellationToken);
        }
    }

    public virtual async Task ExecuteAxisCommand(ST_MOTOR_DATA axis, EN_MOTION_COMMAND command, double parameter, CancellationToken cancellationToken = default, double? parameter2 = null)
    {
        await Send(BuildAxisCommand(axis, command, parameter, parameter2), cancellationToken);
    }

    public virtual async Task SetOutput(string address, bool isOn, CancellationToken cancellationToken = default)
    {
        await Send($"{CommandPrefix}:IO:{address}:{(isOn ? "ON" : "OFF")}", cancellationToken);
    }

    public virtual ST_MOTOR_AXIS_STATUS? ReadAxisStatus(ST_MOTOR_DATA axis, CancellationToken cancellationToken = default)
    {
        var response = Send(BuildAxisCommand(axis, EN_MOTION_COMMAND.Refresh, 0.0), cancellationToken).GetAwaiter().GetResult();
        return TryParseAxisStatus(axis, response);
    }

    public async Task<ST_MOTOR_AXIS_STATUS?> ReadAxisStatusAsync(ST_MOTOR_DATA axis, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var data = GetInterfaceData();
        if (data is null || _interfaceManager?.IsConnect(data.Device, data.Number) != true)
            throw new IOException($"{Controller} 상태 조회 대상이 연결되어 있지 않습니다.");
        var response = await Send(BuildAxisCommand(axis, EN_MOTION_COMMAND.Refresh, 0.0), cancellationToken).ConfigureAwait(false);
        cancellationToken.ThrowIfCancellationRequested();
        return TryParseAxisStatus(axis, response);
    }

    public virtual async Task<bool?> ReadIo(string address, bool isOutput, CancellationToken cancellationToken = default)
    {
        var response = await Send($"{CommandPrefix}:IO:{address}:READ", cancellationToken);
        var tokens = response.Split(':', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries);
        return tokens.Length >= 4 && tokens[0].Equals("OK", StringComparison.OrdinalIgnoreCase) && tokens[1].Equals("IO", StringComparison.OrdinalIgnoreCase) && tokens[2].Equals(address, StringComparison.OrdinalIgnoreCase) ? tokens[3].Equals("ON", StringComparison.OrdinalIgnoreCase) : null;
    }

    protected virtual string BuildAxisCommand(ST_MOTOR_DATA axis, EN_MOTION_COMMAND command, double parameter, double? parameter2 = null)
    {
        var commandText = command switch
        {
            EN_MOTION_COMMAND.ServoOn => "SERVO_ON",
            EN_MOTION_COMMAND.ServoOff => "SERVO_OFF",
            EN_MOTION_COMMAND.Home => "HOME",
            EN_MOTION_COMMAND.MoveAbs => $"MOVE_ABS:{FormatProtocolDouble(parameter, "F3")}",
            EN_MOTION_COMMAND.MoveRel => $"MOVE_REL:{FormatProtocolDouble(parameter, "F3")}",
            EN_MOTION_COMMAND.SetProfile => $"SET_PROFILE:{FormatProtocolDouble(parameter, "F3")}:{FormatProtocolDouble(RequireSecondaryParameter(command, parameter2), "F3")}",
            EN_MOTION_COMMAND.JogPositive => $"JOG:{FormatProtocolDouble(Math.Abs(parameter), "F3")}:{FormatProtocolDouble(Math.Abs(RequireSecondaryParameter(command, parameter2)), "F3")}",
            EN_MOTION_COMMAND.JogNegative => $"JOG:{FormatProtocolDouble(-Math.Abs(parameter), "F3")}:{FormatProtocolDouble(Math.Abs(RequireSecondaryParameter(command, parameter2)), "F3")}",
            EN_MOTION_COMMAND.JogStop => "JOG_STOP",
            EN_MOTION_COMMAND.Stop => "STOP",
            EN_MOTION_COMMAND.ResetAlarm => "RESET_ALARM",
            EN_MOTION_COMMAND.Refresh => "READ",
            _ => "READ"
        };
        return $"{CommandPrefix}:AXIS:{axis.Axis}:{axis.Name}:{commandText}";
    }

    protected static string FormatProtocolDouble(double value, string format)
    {
        if (!double.IsFinite(value))
        {
            throw new InvalidOperationException("Motion command parameter must be finite.");
        }

        return value.ToString(format, CultureInfo.InvariantCulture);
    }

    protected static double RequireSecondaryParameter(EN_MOTION_COMMAND command, double? parameter)
    {
        if (!parameter.HasValue)
        {
            throw new InvalidOperationException($"Motion {command} requires an acceleration parameter.");
        }

        return parameter.Value;
    }

    protected async Task<string> Send(string command, CancellationToken cancellationToken)
    {
        var isPriorityXpsStop = IsPriorityXpsStopCommand(command);
        if (!isPriorityXpsStop)
        {
            cancellationToken.ThrowIfCancellationRequested();
        }

        var interfaceData = GetInterfaceData();
        if (_interfaceManager is null || interfaceData is null)
        {
            throw new InvalidOperationException($"{Controller} motion interface is not registered.");
        }

        if (isPriorityXpsStop && !_interfaceManager.IsConnect(interfaceData.Device, interfaceData.Number))
        {
            throw new InvalidOperationException($"{Controller} priority stop failed because the interface is offline: " + $"{interfaceData.Device}[{interfaceData.Number}]/{interfaceData.NickName}");
        }

        if (!isPriorityXpsStop && !_interfaceManager.IsConnect(interfaceData.Device, interfaceData.Number))
        {
            await _interfaceManager.Connect(interfaceData.Device, interfaceData.Number, cancellationToken: cancellationToken);
        }

        if (!isPriorityXpsStop && !_interfaceManager.IsConnect(interfaceData.Device, interfaceData.Number))
        {
            throw new InvalidOperationException($"{Controller} motion interface is offline: {interfaceData.Device}[{interfaceData.Number}]/{interfaceData.NickName}");
        }

        CancellationTokenSource? priorityStopTimeout = null;
        var commandCancellationToken = cancellationToken;
        var priorityStopTimeoutMs = 0;
        if (isPriorityXpsStop)
        {
            priorityStopTimeoutMs = GetPriorityStopTimeoutMs(interfaceData);
            priorityStopTimeout = new CancellationTokenSource(TimeSpan.FromMilliseconds(priorityStopTimeoutMs));
            commandCancellationToken = priorityStopTimeout.Token;
        }

        string response;
        try
        {
            response = await _interfaceManager.ExecuteFunction(interfaceData.Device, interfaceData.Number, command, commandCancellationToken);
        }
        catch (OperationCanceledException exception)when (isPriorityXpsStop && priorityStopTimeout?.IsCancellationRequested == true)
        {
            throw new TimeoutException($"{Controller} priority stop timed out after {priorityStopTimeoutMs} ms: {command}", exception);
        }
        finally
        {
            priorityStopTimeout?.Dispose();
        }

        if (string.IsNullOrWhiteSpace(response))
        {
            throw new TimeoutException($"{Controller} motion command timeout: {command}");
        }

        if (response.StartsWith("ERR", StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException($"{Controller} motion command failed. Command={command}, Response={response}");
        }

        return response;
    }

    private int GetPriorityStopTimeoutMs(ST_INTERFACE_DATA interfaceData)
    {
        bool MatchesItem(global::Drilling.Common.Interface.CInterfaceDevice device)
        {
            return device.Data.Device == interfaceData.Device && device.Data.Number == interfaceData.Number && device.Data.InterfaceType == interfaceData.InterfaceType;
        }

        var configuredTimeoutMs = _interfaceManager?.Devices.FirstOrDefault(MatchesItem)?.ConnectOption.TimeoutMs ?? 0;
        return configuredTimeoutMs > 0 ? configuredTimeoutMs : 5000;
    }

    private static bool IsPriorityXpsStopCommand(string command)
    {
        return command.StartsWith("XPS:AXIS:", StringComparison.OrdinalIgnoreCase) && (command.EndsWith(":JOG_STOP", StringComparison.OrdinalIgnoreCase) || command.EndsWith(":STOP", StringComparison.OrdinalIgnoreCase));
    }

    protected virtual ST_MOTOR_AXIS_STATUS? TryParseAxisStatus(ST_MOTOR_DATA axis, string response)
    {
        var tokens = response.Split(':', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries);
        if (tokens.Length < 5 || !tokens[0].Equals("OK", StringComparison.OrdinalIgnoreCase) || !tokens[1].Equals("AXIS", StringComparison.OrdinalIgnoreCase))
        {
            return null;
        }

        var command = tokens[3].ToUpperInvariant();
        if (command != "FPOS" || !double.TryParse(tokens[4], NumberStyles.Float, CultureInfo.InvariantCulture, out var position) || !double.IsFinite(position))
        {
            return null;
        }

        var axisId = string.IsNullOrWhiteSpace(axis.Name) ? axis.Axis.ToString() : axis.Name.Trim().ToUpperInvariant();
        return new ST_MOTOR_AXIS_STATUS(axisId, string.IsNullOrWhiteSpace(axis.DisplayName) ? axisId : axis.DisplayName, position, position, position, true, true, false, false, false, AxisNo: axis.Axis);
    }

    private ST_INTERFACE_DATA? GetInterfaceData()
    {
        if (_interfaceManager is null)
        {
            return null;
        }

        bool ShouldIncludeItem(global::Drilling.Common.Interface.ST_INTERFACE_DATA data)
        {
            return data.Number == DeviceNo;
        }

        string SelectNickName(global::Drilling.Common.Interface.ST_INTERFACE_DATA data)
        {
            return data.NickName;
        }

        var primary = _interfaceManager.GetInterfaceList(PrimaryModule).Where(ShouldIncludeItem).OrderBy(SelectNickName, StringComparer.OrdinalIgnoreCase).FirstOrDefault();
        if (primary is not null)
        {
            return primary;
        }

        bool MatchesNumber(global::Drilling.Common.Interface.ST_INTERFACE_DATA data)
        {
            return data.Number == DeviceNo;
        }

        string SelectNickName2(global::Drilling.Common.Interface.ST_INTERFACE_DATA data)
        {
            return data.NickName;
        }

        return _interfaceManager.GetInterfaceList(EN_EQP_MODULE.Motion).Where(MatchesNumber).OrderBy(SelectNickName2, StringComparer.OrdinalIgnoreCase).FirstOrDefault();
    }
}
