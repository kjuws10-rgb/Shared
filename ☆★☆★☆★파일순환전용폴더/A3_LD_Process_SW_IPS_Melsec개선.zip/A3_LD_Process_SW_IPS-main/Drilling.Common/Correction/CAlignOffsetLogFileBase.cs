using Drilling.Common.Recipe;

namespace Drilling.Common.Correction;

public sealed record ST_ALIGN_OFFSET_KEY_LOG(string Name, bool Included, double DesignX, double DesignY,
    double? BaseX, double? BaseY, double? LastLoadX, double? LastLoadY, double? OffsetX, double? OffsetY);

public sealed record ST_ALIGN_OFFSET_LOG(string RecipeId, string RecipeName, bool IsInit,
    DateTimeOffset ChangedAt, DateTimeOffset? LastLoadedAt, bool IsSimulation,
    IReadOnlyList<ST_ALIGN_OFFSET_KEY_LOG> Keys, IReadOnlyList<ST_ALIGN_SHOT_OFFSET> Shots)
{
    public double? Tolerance { get; init; }
    public IReadOnlyList<ST_ALIGN_SHOT_OFFSET> CalculatedOffsets { get; init; } = [];
    public IReadOnlyList<ST_ALIGN_SHOT_OFFSET> ExcludedOffsets { get; init; } = [];
}

public abstract class CAlignOffsetLogFileBase
{
    public abstract Task<string> Save(ST_ALIGN_OFFSET_LOG entry, CancellationToken cancellationToken = default);
}
