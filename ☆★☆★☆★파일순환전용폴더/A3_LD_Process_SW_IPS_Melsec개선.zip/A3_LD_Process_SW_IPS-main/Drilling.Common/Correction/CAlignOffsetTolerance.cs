using System.Globalization;
using Drilling.Common.Recipe;

namespace Drilling.Common.Correction;

public sealed record ST_ALIGN_OFFSET_TOLERANCE_CHECK(double Tolerance,
    int TotalShots, IReadOnlyList<ST_ALIGN_SHOT_OFFSET> ExceededShots)
{
    public int ApplyCount => TotalShots - ExceededShots.Count;
    public bool CanApplyRemaining => ApplyCount > 0;
    public string Summary => $"{CAlignInterpolation.AlgorithmName} / Setting Tolerance : ±{Tolerance.ToString("0.000", CultureInfo.InvariantCulture)} mm\n" +
        $"전체 {TotalShots:N0} Shot · 초과 {ExceededShots.Count:N0} Shot · 적용 가능 {ApplyCount:N0} Shot";
}

public static class CAlignOffsetTolerance
{
    public const string SettingKey = "ALIGN_OFFSET_TOLERANCE";
    public const double DefaultValue = 0.5;

    public static double Parse(string value)
    {
        if (!double.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out var tolerance) ||
            !double.IsFinite(tolerance) || tolerance < 0 || tolerance > 100000)
            throw new InvalidOperationException("Setting > Option > Interlock의 Align Offset Tolerance를 0 ~ 100000 mm 범위로 설정해 주세요.");
        return CAlignShotOffsetData.RoundValue(tolerance);
    }

    // Reject the entire shot, including its other axis, if either axis exceeds the limit.
    public static bool Exceeds(ST_ALIGN_SHOT_OFFSET shot, double tolerance)
        => Math.Abs(shot.X) > tolerance || Math.Abs(shot.Y) > tolerance;

    public static ST_ALIGN_OFFSET_TOLERANCE_CHECK Check(double tolerance,
        IReadOnlyList<ST_ALIGN_SHOT_OFFSET> offsets)
        => new(tolerance, offsets.Count, offsets.Where(shot => Exceeds(shot, tolerance)).ToArray());
}
