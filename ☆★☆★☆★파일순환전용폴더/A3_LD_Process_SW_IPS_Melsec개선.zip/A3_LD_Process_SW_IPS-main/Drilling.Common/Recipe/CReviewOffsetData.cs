using System.Globalization;
using Drilling.Common.Review;

namespace Drilling.Common.Recipe;

/// <summary>Persist raw offsets and resolve their coordinate basis only when building process coordinates.</summary>
public static class CReviewOffsetData
{
    public static void ApplyToParameters(IDictionary<string, string> parameters, ST_REVIEW_OFFSET_FILE_DATA file)
    {
        foreach (var key in parameters.Keys.Where(key => key.Contains("REVIEW_OFFSET", StringComparison.OrdinalIgnoreCase)).ToArray())
            parameters.Remove(key);
        foreach (var row in file.Rows)
        {
            var shot = row.ShotId.Trim().Replace('-', '_').Replace('.', '_').ToUpperInvariant();
            if (row.CellId <= 0 || shot.Length == 0) continue;
            var prefix = $"CELL{row.CellId}_{shot}_REVIEW_OFFSET_";
            parameters[$"{prefix}X"] = row.ReviewOffsetX.ToString("R", CultureInfo.InvariantCulture);
            parameters[$"{prefix}Y"] = row.ReviewOffsetY.ToString("R", CultureInfo.InvariantCulture);
            parameters[$"{prefix}SPACE"] = row.IsDesignCoordinate ? "DESIGN" : "SCANNER";
        }
    }

    public static bool IsDesignCoordinate(IReadOnlyDictionary<string, string> parameters, string prefix)
    {
        var space = parameters.GetValueOrDefault($"{prefix}SPACE", "SCANNER").Trim().ToUpperInvariant();
        return space switch
        {
            "DESIGN" => true,
            "SCANNER" => false,
            _ => throw new InvalidOperationException($"Invalid Review Offset coordinate space: {space}")
        };
    }

    public static (double X, double Y) ToScanner(IReadOnlyDictionary<string, string> parameters, int headNo,
        double x, double y, bool isDesign) => isDesign ? CScannerAxisTransform.DesignOffsetToScanner(parameters, headNo, x, y) : (x, y);

    public static (double X, double Y) ToDesign(IReadOnlyDictionary<string, string> parameters, int headNo,
        double x, double y, bool isDesign) => isDesign ? (x, y) : CScannerAxisTransform.ScannerOffsetToDesign(parameters, headNo, x, y);
}
