using System.Globalization;
using System.Text.RegularExpressions;
using Drilling.Common.Correction;
using Drilling.Common.Managers;
using Drilling.Common.Review;

namespace Drilling.Common.Recipe;

public sealed record ST_ALIGN_SHOT_OFFSET(int CellNo, int CellShotNo, string ShotName,
    double DesignX, double DesignY, double X, double Y);

public static class CAlignShotOffsetData
{
    private static readonly Regex ParameterPattern = new(@"^CELL[1-9][0-9]*_[A-Z]+[1-9][0-9]*_ALIGN_OFFSET_[XY]$",
        RegexOptions.Compiled | RegexOptions.CultureInvariant | RegexOptions.IgnoreCase);
    public static bool IsParameterKey(string key) => ParameterPattern.IsMatch(key);
    public static string ParameterKey(int cellNo, string shotName, string axis) => $"CELL{cellNo}_{shotName}_ALIGN_OFFSET_{axis}";

    public static double RoundValue(double value)
    {
        if (!double.IsFinite(value)) throw new InvalidOperationException("유효하지 않은 Align Offset입니다.");
        // Round decimal millimetres at the final result; do not round interpolation intermediates.
        var rounded = (double)Math.Round((decimal)value, 3, MidpointRounding.AwayFromZero);
        return rounded == 0 ? 0 : rounded;
    }

    public static string FormatValue(double value) => RoundValue(value).ToString("0.000", CultureInfo.InvariantCulture);

    public static double ReadValue(IReadOnlyDictionary<string, string> parameters, string key)
    {
        if (!parameters.TryGetValue(key, out var text)) return 0;
        if (!double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out var value) || !double.IsFinite(value))
            throw new InvalidOperationException($"{key}의 Align Offset 값이 올바르지 않습니다.");
        return RoundValue(value);
    }

    public static IReadOnlyList<ST_ALIGN_SHOT_OFFSET> Calculate(ST_RECIPE_DEFINITION recipe,
        CAlignInterpolation model)
    {
        model.ValidateMeasurements();
        var parameters = recipe.Parameters.Where(parameter => !IsParameterKey(parameter.Key))
            .ToDictionary(parameter => parameter.Key, parameter => parameter.Value, StringComparer.OrdinalIgnoreCase);
        var shots = CShotCoordinatePlanBuilder.BuildDesignShots(parameters);
        if (shots.Count == 0) throw new InvalidOperationException("적용할 Shot이 없습니다.");
        var values = new List<ST_ALIGN_SHOT_OFFSET>(shots.Count);
        foreach (var shot in shots)
        {
            var name = CReviewShotNameFormatter.ToMatrixName(shot.CellShotNo, shot.GroupCountX);
            if (!model.Contains(shot.DesignX, shot.DesignY))
                throw new InvalidOperationException($"Cell{shot.CellNo} / {name} (X {shot.DesignX:0.###}, Y {shot.DesignY:0.###})가 선택 키의 보간 범위 밖에 있습니다. 전체 Shot 적용을 취소합니다.");
            var correction = model.Evaluate(shot.DesignX, shot.DesignY);
            if (Math.Abs(correction.X) > 100000 || Math.Abs(correction.Y) > 100000)
                throw new InvalidOperationException($"Cell{shot.CellNo} / {name}의 계산값이 레시피 Offset 저장 범위를 벗어납니다.");
            values.Add(new(shot.CellNo, shot.CellShotNo, name, shot.DesignX, shot.DesignY, RoundValue(correction.X), RoundValue(correction.Y)));
        }
        return values;
    }

    public static IReadOnlyList<ST_ALIGN_SHOT_OFFSET> ZeroValues(ST_RECIPE_DEFINITION recipe)
    {
        // Reset must also work if a manually edited old offset is invalid.
        var parameters = recipe.Parameters.Where(parameter => !IsParameterKey(parameter.Key))
            .ToDictionary(parameter => parameter.Key, parameter => parameter.Value, StringComparer.OrdinalIgnoreCase);
        return CShotCoordinatePlanBuilder.BuildDesignShots(parameters).Select(shot => new ST_ALIGN_SHOT_OFFSET(
            shot.CellNo, shot.CellShotNo, CReviewShotNameFormatter.ToMatrixName(shot.CellShotNo, shot.GroupCountX),
            shot.DesignX, shot.DesignY, 0, 0)).ToArray();
    }

    public static ST_RECIPE_DEFINITION Apply(ST_RECIPE_DEFINITION recipe, IReadOnlyList<ST_ALIGN_SHOT_OFFSET> offsets)
    {
        var parameters = recipe.Parameters.ToDictionary(parameter => parameter.Key, StringComparer.OrdinalIgnoreCase);
        foreach (var offset in offsets)
        {
            Add(offset, "X", offset.X);
            Add(offset, "Y", offset.Y);
        }
        return recipe with { Parameters = parameters.Values.ToArray() };

        void Add(ST_ALIGN_SHOT_OFFSET offset, string axis, double value)
        {
            if (!double.IsFinite(value) || Math.Abs(value) > 100000) throw new InvalidOperationException("유효하지 않은 Align Offset입니다.");
            var key = ParameterKey(offset.CellNo, offset.ShotName, axis);
            if (!IsParameterKey(key)) throw new InvalidOperationException("Shot Align Offset 항목을 확인하세요.");
            var text = FormatValue(value);
            parameters[key] = parameters.TryGetValue(key, out var existing) ? existing with { Value = text }
                : new ST_RECIPE_PARAMETER($"Shot Group {offset.ShotName} Align Offset {axis}", text, "mm", "-100000 - 100000", "0.000",
                    "CELL", "SHOT_GROUP", key, "Design-coordinate align correction; head direction is applied at script generation.",
                    false, true, DataType: EN_RECIPE_DATA_TYPE.Double, Min: -100000, Max: 100000);
        }
    }

    // The generic recipe editor does not expose generated align fields. Keep the
    // latest saved values when that editor saves only its visible parameters.
    public static ST_RECIPE_DEFINITION RetainUneditedOffsets(ST_RECIPE_DEFINITION edited, ST_RECIPE_DEFINITION? saved)
    {
        if (saved is null) return edited;
        var keys = edited.Parameters.Select(parameter => parameter.Key).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var retained = saved.Parameters.Where(parameter => IsParameterKey(parameter.Key) && !keys.Contains(parameter.Key)).ToArray();
        return retained.Length == 0 ? edited : edited with { Parameters = edited.Parameters.Concat(retained).ToArray() };
    }
}
