using Drilling.Common.Managers;

namespace Drilling.Common.Recipe;

public readonly record struct ST_SCANNER_AXIS_TRANSFORM(bool XyFlip, bool XFlip, bool YFlip)
{
    public (double X, double Y) Apply(double x, double y)
    {
        if (XyFlip)
        {
            (x, y) = (y, x);
        }

        if (XFlip)
        {
            x = -x;
        }

        if (YFlip)
        {
            y = -y;
        }

        return (x, y);
    }
}

public static class CScannerAxisTransform
{
    public static double ReadStageDirection(IReadOnlyDictionary<string, string> parameters)
        => CShotCoordinatePlanBuilder.ReadDirection(parameters, -1.0, "STAGE_SCAN_DIRECTION_Y");
    public static ST_SCANNER_AXIS_TRANSFORM CreateDefault(int headNo)
    {
        return new ST_SCANNER_AXIS_TRANSFORM(false, false, false);
    }

    public static ST_SCANNER_AXIS_TRANSFORM Read(IReadOnlyDictionary<string, string> parameters, int headNo)
    {
        ArgumentNullException.ThrowIfNull(parameters);

        var defaults = CreateDefault(headNo);
        return new ST_SCANNER_AXIS_TRANSFORM(
            ReadOnOff(parameters, defaults.XyFlip, $"H{headNo:00}_SCANNER_XY_FLIP"),
            ReadOnOff(parameters, defaults.XFlip, $"H{headNo:00}_SCANNER_X_FLIP"),
            ReadOnOff(parameters, defaults.YFlip, $"H{headNo:00}_SCANNER_Y_FLIP"));
    }

    public static ST_SCANNER_AXIS_TRANSFORM Read(IReadOnlyList<ST_SYSTEM_PARAMETER> settings, int headNo)
    {
        ArgumentNullException.ThrowIfNull(settings);

        var defaults = CreateDefault(headNo);
        return new ST_SCANNER_AXIS_TRANSFORM(
            ReadOnOff(settings, defaults.XyFlip, $"H{headNo:00}_SCANNER_XY_FLIP"),
            ReadOnOff(settings, defaults.XFlip, $"H{headNo:00}_SCANNER_X_FLIP"),
            ReadOnOff(settings, defaults.YFlip, $"H{headNo:00}_SCANNER_Y_FLIP"));
    }

    public static (double X, double Y) DesignOffsetToScanner(
        IReadOnlyList<ST_SYSTEM_PARAMETER> settings, int headNo, double offsetX, double offsetY)
    {
        ArgumentNullException.ThrowIfNull(settings);
        var parameters = settings
            .GroupBy(setting => string.IsNullOrWhiteSpace(setting.Key) ? setting.Name : setting.Key,
                StringComparer.OrdinalIgnoreCase)
            .ToDictionary(group => group.Key, group => group.Last().Value, StringComparer.OrdinalIgnoreCase);
        return DesignOffsetToScanner(parameters, headNo, offsetX, offsetY);
    }

    public static (double X, double Y) DesignOffsetToScanner(
        IReadOnlyDictionary<string, string> parameters, int headNo, double offsetX, double offsetY)
    {
        var stageDirectionY = CShotCoordinatePlanBuilder.ReadDirection(parameters, -1.0, "STAGE_SCAN_DIRECTION_Y");
        // Auto-run Shift Offset changes the scanner by Apply(X, Y * stage direction).
        return Read(parameters, headNo).Apply(offsetX, offsetY * stageDirectionY);
    }

    public static string Format(ST_SCANNER_AXIS_TRANSFORM transform)
    {
        return $"X {FormatOnOff(transform.XFlip)} / " +
               $"Y {FormatOnOff(transform.YFlip)} / " +
               $"XY {FormatOnOff(transform.XyFlip)}";
    }

    public static (double X, double Y) ScannerOffsetToDesign(
        IReadOnlyDictionary<string, string> parameters, int headNo, double offsetX, double offsetY)
    {
        var transform = Read(parameters, headNo);
        if (transform.XFlip) offsetX = -offsetX;
        if (transform.YFlip) offsetY = -offsetY;
        if (transform.XyFlip) (offsetX, offsetY) = (offsetY, offsetX);
        return (offsetX, offsetY / CShotCoordinatePlanBuilder.ReadDirection(parameters, -1.0, "STAGE_SCAN_DIRECTION_Y"));
    }

    private static bool ReadOnOff(IReadOnlyDictionary<string, string> parameters, bool defaultValue, string key)
    {
        return parameters.TryGetValue(key, out var value) ? ParseOnOff(value, defaultValue, key) : defaultValue;
    }

    private static bool ReadOnOff(IReadOnlyList<ST_SYSTEM_PARAMETER> settings, bool defaultValue, string key)
    {
        foreach (var setting in settings)
        {
            if (setting.Key.Equals(key, StringComparison.OrdinalIgnoreCase) ||
                setting.Name.Equals(key, StringComparison.OrdinalIgnoreCase))
            {
                return ParseOnOff(setting.Value, defaultValue, key);
            }
        }

        return defaultValue;
    }

    private static bool ParseOnOff(string? value, bool defaultValue, string key)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return defaultValue;
        }

        var normalized = value.Trim().ToUpperInvariant();
        if (normalized is "ON" or "TRUE" or "1" or "YES")
        {
            return true;
        }

        if (normalized is "OFF" or "FALSE" or "0" or "NO")
        {
            return false;
        }

        throw new InvalidOperationException($"Scanner axis flip setting {key} must be ON or OFF. Current value: {value}");
    }

    private static string FormatOnOff(bool value)
    {
        return value ? "ON" : "OFF";
    }
}
