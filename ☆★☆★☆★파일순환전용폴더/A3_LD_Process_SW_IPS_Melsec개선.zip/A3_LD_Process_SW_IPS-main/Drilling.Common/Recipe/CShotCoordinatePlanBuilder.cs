﻿using System.Globalization;
using Drilling.Common.Review;

namespace Drilling.Common.Recipe;
public sealed record ST_HEAD_SHOT_POINT(int SequenceNo, string ShotKey, int HeadNo, int CellNo, int CellShotNo, int GroupColumn, int GroupRow, int GroupCountX, int GroupCountY, double DesignX, double DesignY, double ScannerGx, double ScannerGy, double StageX, double StageY, double RecipeOffsetX, double RecipeOffsetY, double HeadDefaultOffsetX, double HeadDefaultOffsetY, double FirstBeamOffsetX, double FirstBeamOffsetY, double ReviewOffsetX, double ReviewOffsetY, double ShiftOffsetX, double ShiftOffsetY, double ShiftScannerOffsetX, double ShiftScannerOffsetY, double FinalScannerOffsetX, double FinalScannerOffsetY, double EncoderWaitPosition)
{
    public double AlignOffsetX { get; init; }
    public double AlignOffsetY { get; init; }
    public double AlignScannerOffsetX { get; init; }
    public double AlignScannerOffsetY { get; init; }
}
public sealed record ST_SHOT_COORDINATE_PLAN(int HeadCount, int CellCount, double GlassSizeX, double GlassSizeY, double EncoderScale, IReadOnlyList<ST_HEAD_SHOT_POINT> Shots);
public sealed record ST_DESIGN_SHOT_POINT(string ShotKey, int CellNo, int CellShotNo, int GroupColumn, int GroupRow, int GroupCountX, int GroupCountY, double DesignX, double DesignY, double RecipeOffsetX, double RecipeOffsetY, double ReviewOffsetX, double ReviewOffsetY, double AlignOffsetX = 0, double AlignOffsetY = 0)
{
    public bool ReviewOffsetIsDesign { get; init; }
}
internal readonly record struct ST_HEAD_ASSIGNMENT_CANDIDATE(int HeadNo, double Distance);
internal sealed record ST_PREPARED_SHOT_POINT(int Index, ST_DESIGN_SHOT_POINT DesignShot, int HeadNo, double HeadCenterX, ST_SCANNER_AXIS_TRANSFORM ScannerTransform, double HeadDefaultOffsetX, double HeadDefaultOffsetY, double FirstBeamOffsetX, double FirstBeamOffsetY, double StageShotX, double ShotStageY, double DesignDistanceYFromAlignKey, double BaseShotStageY, double BaseDesignDistanceYFromAlignKey, double EncoderScale);
public static class CShotCoordinatePlanBuilder
{
    public static ST_SHOT_COORDINATE_PLAN Build(IReadOnlyDictionary<string, string> parameters)
    {
        ArgumentNullException.ThrowIfNull(parameters);
        var headCount = Math.Clamp(ReadInt(parameters, 8, "HEAD_COUNT"), 1, 8);
        var cellCount = ReadInt(parameters, 0, "MAX_CELL_NUMBER");
        if (cellCount < CCellPatternCalculator.MinCellCount)
        {
            throw new InvalidOperationException($"MAX_CELL_NUMBER must be greater than or equal to {CCellPatternCalculator.MinCellCount}. Current value: {cellCount}");
        }

        var activeHeadNos = BuildActiveHeadNumbers(parameters, headCount);
        var activeHeadSet = activeHeadNos.ToHashSet();
        var assignmentHeadNos = Enumerable.Range(1, headCount).ToArray();
        var glassSizeX = ReadDouble(parameters, 0.0, "GLASS_SIZE_X");
        var glassSizeY = ReadDouble(parameters, 0.0, "GLASS_SIZE_Y");
        var encoderScale = ReadDouble(parameters, 16000.0, "SCAN_ENCODER_SCALE");
        var stageScanDirectionY = ReadDirection(parameters, -1.0, "STAGE_SCAN_DIRECTION_Y");
        var scanStartDelayLengthY = Math.Abs(ReadDouble(parameters, 0.0, "SCAN_START_DELAY_LENGTH_Y"));
        var akMarginY = ReadDouble(parameters, 0.0, "AK_MARGIN_Y");
        var scannerReferenceOffsetX = ReadScannerReferenceOffsetX(parameters);
        var shiftOffsetX = ReadDouble(parameters, 0.0, "SHIFT_OFFSET_X");
        var shiftOffsetY = ReadDouble(parameters, 0.0, "SHIFT_OFFSET_Y");
        int SelectHeadNo(int headNo)
        {
            return headNo;
        }

        int SelectValue(int arg0)
        {
            return 0;
        }

        var assignedHeadCounts = assignmentHeadNos.ToDictionary(SelectHeadNo, SelectValue);
        var designShots = BuildDesignShots(parameters, cellCount);
        var preparedShots = new List<ST_PREPARED_SHOT_POINT>(designShots.Count);
        for (var index = 0; index < designShots.Count; index++)
        {
            var designShot = designShots[index];
            var scannerReferenceX = designShot.DesignX + scannerReferenceOffsetX;
            var headNo = AssignHeadNo(scannerReferenceX, assignmentHeadNos, parameters, assignedHeadCounts);
            if (headNo <= 0 || !activeHeadSet.Contains(headNo))
            {
                continue;
            }

            assignedHeadCounts[headNo]++;
            var headCenterX = ReadHeadCenterX(parameters, headNo);
            var headCenterY = ReadHeadCenterY(parameters, headNo);
            var scannerTransform = CScannerAxisTransform.Read(parameters, headNo);
            var headDefaultOffsetX = ReadHeadDefaultOffset(parameters, headNo, "X");
            var headDefaultOffsetY = ReadHeadDefaultOffset(parameters, headNo, "Y");
            var firstBeamOffsetX = ReadFirstBeamOffset(parameters, headNo, "X");
            var firstBeamOffsetY = ReadFirstBeamOffset(parameters, headNo, "Y");
            var headEncoderScale = ReadHeadEncoderScale(parameters, headNo, encoderScale);
            var stageShotX = scannerReferenceX;
            var designDistanceYFromAlignKey = designShot.DesignY - akMarginY;
            var stageShotY = ConvertRecipeYToStageY(designDistanceYFromAlignKey);
            var shotStageY = headCenterY + stageShotY;
            preparedShots.Add(new ST_PREPARED_SHOT_POINT(index, designShot, headNo, headCenterX, scannerTransform, headDefaultOffsetX, headDefaultOffsetY, firstBeamOffsetX, firstBeamOffsetY, stageShotX, shotStageY, designDistanceYFromAlignKey, shotStageY, designDistanceYFromAlignKey, headEncoderScale));
        }

        var firstShotStageY = 0.0;
        var firstShotDesignDistanceY = 0.0;
        if (preparedShots.Count > 0)
        {
            var firstShot = preparedShots[0];
            firstShotStageY = firstShot.ShotStageY;
            for (var index = 1; index < preparedShots.Count; index++)
            {
                var preparedShot = preparedShots[index];
                var shotStageY = preparedShot.ShotStageY;
                if (stageScanDirectionY < 0.0 && shotStageY > firstShotStageY)
                {
                    firstShot = preparedShot;
                    firstShotStageY = shotStageY;
                }
                else if (stageScanDirectionY >= 0.0 && shotStageY < firstShotStageY)
                {
                    firstShot = preparedShot;
                    firstShotStageY = shotStageY;
                }
            }

            firstShotStageY = firstShot.ShotStageY;
            firstShotDesignDistanceY = Math.Abs(firstShot.DesignDistanceYFromAlignKey);
        }

        var scanStartStageY = firstShotStageY - (stageScanDirectionY * scanStartDelayLengthY);
        var calculatedShots = new List<ST_HEAD_SHOT_POINT>(preparedShots.Count);
        for (var index = 0; index < preparedShots.Count; index++)
        {
            var preparedShot = preparedShots[index];
            var baseStageWaitDistanceY = ((preparedShot.ShotStageY - scanStartStageY) * stageScanDirectionY) + firstShotDesignDistanceY;
            var stageWaitDistanceY = baseStageWaitDistanceY - shiftOffsetY;
            if (stageWaitDistanceY < 0.0 && Math.Abs(stageWaitDistanceY) <= 0.000001)
            {
                stageWaitDistanceY = 0.0;
            }
            if (baseStageWaitDistanceY < 0.0 && Math.Abs(baseStageWaitDistanceY) <= 0.000001)
            {
                baseStageWaitDistanceY = 0.0;
            }

            var baseScannerX = ApplyScannerAxis(preparedShot.StageShotX, preparedShot.HeadCenterX, 0.0);
            // Scanner follow motion compensates the moving stage, so use the opposite stage-basis direction.
            var baseScannerY = -(stageWaitDistanceY * stageScanDirectionY);
            var noShiftBaseScannerY = -(baseStageWaitDistanceY * stageScanDirectionY);
            var scannerBase = preparedShot.ScannerTransform.Apply(baseScannerX, baseScannerY);
            var noShiftScannerBase = preparedShot.ScannerTransform.Apply(baseScannerX, noShiftBaseScannerY);
            var headDefaultScannerOffset = preparedShot.ScannerTransform.Apply(preparedShot.HeadDefaultOffsetX, ConvertRecipeYToStageY(preparedShot.HeadDefaultOffsetY));
            var firstBeamScannerOffset = preparedShot.ScannerTransform.Apply(preparedShot.FirstBeamOffsetX, ConvertRecipeYToStageY(preparedShot.FirstBeamOffsetY));
            // Align offsets are persisted in design coordinates. Apply the current
            // stage/head direction here, when building scanner/script coordinates.
            var alignScannerOffset = CScannerAxisTransform.DesignOffsetToScanner(parameters, preparedShot.HeadNo,
                preparedShot.DesignShot.AlignOffsetX, preparedShot.DesignShot.AlignOffsetY);
            var reviewScannerOffset = CReviewOffsetData.ToScanner(parameters, preparedShot.HeadNo,
                preparedShot.DesignShot.ReviewOffsetX, preparedShot.DesignShot.ReviewOffsetY, preparedShot.DesignShot.ReviewOffsetIsDesign);
            var shiftScannerOffsetXOnly = preparedShot.ScannerTransform.Apply(shiftOffsetX, 0.0);
            var shiftScannerOffsetX = (scannerBase.X - noShiftScannerBase.X) + shiftScannerOffsetXOnly.X;
            var shiftScannerOffsetY = (scannerBase.Y - noShiftScannerBase.Y) + shiftScannerOffsetXOnly.Y;
            var finalScannerOffsetX = preparedShot.DesignShot.RecipeOffsetX + headDefaultScannerOffset.X + firstBeamScannerOffset.X + reviewScannerOffset.X + alignScannerOffset.X;
            var finalScannerOffsetY = preparedShot.DesignShot.RecipeOffsetY + headDefaultScannerOffset.Y + firstBeamScannerOffset.Y + reviewScannerOffset.Y + alignScannerOffset.Y;
            var scannerGx = scannerBase.X + finalScannerOffsetX + shiftScannerOffsetXOnly.X;
            var scannerGy = scannerBase.Y + finalScannerOffsetY + shiftScannerOffsetXOnly.Y;
            var encoderWaitPosition = stageWaitDistanceY * Math.Abs(preparedShot.EncoderScale) * stageScanDirectionY;
            calculatedShots.Add(new ST_HEAD_SHOT_POINT(preparedShot.Index + 1, preparedShot.DesignShot.ShotKey, preparedShot.HeadNo, preparedShot.DesignShot.CellNo, preparedShot.DesignShot.CellShotNo, preparedShot.DesignShot.GroupColumn, preparedShot.DesignShot.GroupRow, preparedShot.DesignShot.GroupCountX, preparedShot.DesignShot.GroupCountY, preparedShot.DesignShot.DesignX, preparedShot.DesignShot.DesignY, scannerGx, scannerGy, preparedShot.StageShotX, preparedShot.ShotStageY, preparedShot.DesignShot.RecipeOffsetX, preparedShot.DesignShot.RecipeOffsetY, preparedShot.HeadDefaultOffsetX, preparedShot.HeadDefaultOffsetY, preparedShot.FirstBeamOffsetX, preparedShot.FirstBeamOffsetY, reviewScannerOffset.X, reviewScannerOffset.Y, shiftOffsetX, shiftOffsetY, shiftScannerOffsetX, shiftScannerOffsetY, finalScannerOffsetX, finalScannerOffsetY, encoderWaitPosition)
            {
                AlignOffsetX = preparedShot.DesignShot.AlignOffsetX, AlignOffsetY = preparedShot.DesignShot.AlignOffsetY,
                AlignScannerOffsetX = alignScannerOffset.X, AlignScannerOffsetY = alignScannerOffset.Y
            });
        }
        global::Drilling.Common.Recipe.ST_HEAD_SHOT_POINT SelectItem(global::Drilling.Common.Recipe.ST_HEAD_SHOT_POINT shot, int index)
        {
            return shot with
            {
                SequenceNo = index + 1
            };
        }

        var shots = OrderShots(calculatedShots, stageScanDirectionY).Select(SelectItem).ToArray();
        return new ST_SHOT_COORDINATE_PLAN(headCount, cellCount, glassSizeX, glassSizeY, encoderScale, shots);
    }

    // All recipe shots, including disabled heads and masked/chess-skipped shots.
    // No head assignment or scanner transform participates in this geometry.
    public static IReadOnlyList<ST_DESIGN_SHOT_POINT> BuildDesignShots(IReadOnlyDictionary<string, string> parameters)
    {
        var cellCount = ReadInt(parameters, 0, "MAX_CELL_NUMBER");
        if (cellCount < CCellPatternCalculator.MinCellCount)
            throw new InvalidOperationException("MAX_CELL_NUMBER must be greater than or equal to 1.");
        return BuildDesignShots(parameters, cellCount);
    }

    private static IReadOnlyList<ST_DESIGN_SHOT_POINT> BuildDesignShots(IReadOnlyDictionary<string, string> parameters, int cellCount)
    {
        var akMarginX = ReadDouble(parameters, 0.0, "AK_MARGIN_X");
        var akMarginY = ReadDouble(parameters, 0.0, "AK_MARGIN_Y");
        var pixelSize = ReadDouble(parameters, 0.09, "PIXEL_SIZE");
        var splitBeamCount = ReadInt(parameters, 1, "SPLITED_BEAM_COUNT");
        var reviewOffsetX = ReadDouble(parameters, 0.0, "REVIEW_OFFSET_X");
        var reviewOffsetY = ReadDouble(parameters, 0.0, "REVIEW_OFFSET_Y");
        var modelTypeCount = CRecipeModelPixelCountReader.ReadModelTypeCount(parameters);
        var designShots = new List<ST_DESIGN_SHOT_POINT>();
        for (var cellNo = 1; cellNo <= cellCount; cellNo++)
        {
            var modelType = CRecipeModelPixelCountReader.ReadCellModelType(parameters, cellNo, modelTypeCount);
            var modelPattern = CRecipeModelPixelCountReader.ReadPatternForModel(parameters, modelType);
            var result = CCellPatternCalculator.Calculate(new ST_CELL_PATTERN_DEFINITION(cellNo, ReadDouble(parameters, 0.0, $"CELL{cellNo}_ALIGN_TO_1ST_PIXEL_X"), ReadDouble(parameters, 0.0, $"CELL{cellNo}_ALIGN_TO_1ST_PIXEL_Y"), ReadDouble(parameters, 0.0, $"CELL{cellNo}_ROTATION"), pixelSize, modelPattern.PixelCountX, modelPattern.PixelCountY, modelPattern.ProcessPitch, splitBeamCount, akMarginX, akMarginY));
            if (!result.IsValid)
            {
                throw new InvalidOperationException(result.ValidationMessage);
            }

            var totalShotGroupCount = (long)designShots.Count + result.ShotCenters.Count;
            if (totalShotGroupCount > CCellPatternCalculator.MaxTotalShotGroupCount)
            {
                throw new InvalidOperationException($"Shot Group Count {totalShotGroupCount:N0} exceeds the total limit " + $"{CCellPatternCalculator.MaxTotalShotGroupCount:N0}.");
            }

            foreach (var shotCenter in result.ShotCenters)
            {
                var shotGroupName = CReviewShotNameFormatter.ToMatrixName(shotCenter.CellShotNo, result.GroupCountX);
                var recipeOffsetPrefix = $"CELL{cellNo}_{shotGroupName}_RECIPE_OFFSET_";
                var reviewOffsetPrefix = $"CELL{cellNo}_{shotGroupName}_REVIEW_OFFSET_";
                var alignOffsetPrefix = $"CELL{cellNo}_{shotGroupName}_ALIGN_OFFSET_";
                designShots.Add(new ST_DESIGN_SHOT_POINT(ToShotKey(cellNo, shotCenter.CellShotNo), cellNo, shotCenter.CellShotNo, shotCenter.GroupColumn, shotCenter.GroupRow, result.GroupCountX, result.GroupCountY, shotCenter.DesignX, shotCenter.DesignY, ReadDouble(parameters, 0.0, $"{recipeOffsetPrefix}X"), ReadDouble(parameters, 0.0, $"{recipeOffsetPrefix}Y"), ReadDouble(parameters, reviewOffsetX, $"{reviewOffsetPrefix}X"), ReadDouble(parameters, reviewOffsetY, $"{reviewOffsetPrefix}Y"),
                    CAlignShotOffsetData.ReadValue(parameters, $"{alignOffsetPrefix}X"), CAlignShotOffsetData.ReadValue(parameters, $"{alignOffsetPrefix}Y"))
                    { ReviewOffsetIsDesign = CReviewOffsetData.IsDesignCoordinate(parameters, reviewOffsetPrefix) });
            }
        }

        return designShots;
    }

    private static IReadOnlyList<ST_HEAD_SHOT_POINT> OrderShots(IReadOnlyList<ST_HEAD_SHOT_POINT> shots, double stageScanDirectionY)
    {
        double SelectGroupKey(global::Drilling.Common.Recipe.ST_HEAD_SHOT_POINT shot)
        {
            return Math.Round(shot.EncoderWaitPosition, 6);
        }

        var rows = shots.GroupBy(SelectGroupKey).ToArray();
        double SelectDescendingRowKey(global::System.Linq.IGrouping<double, global::Drilling.Common.Recipe.ST_HEAD_SHOT_POINT> row)
        {
            return row.Key;
        }

        double SelectAscendingRowKey(global::System.Linq.IGrouping<double, global::Drilling.Common.Recipe.ST_HEAD_SHOT_POINT> row)
        {
            return row.Key;
        }

        var orderedRows = (stageScanDirectionY < 0.0 ? rows.OrderByDescending(SelectDescendingRowKey) : rows.OrderBy(SelectAscendingRowKey)).ToArray();
        var orderedShots = new List<ST_HEAD_SHOT_POINT>(shots.Count);
        int SelectHeadNo(global::Drilling.Common.Recipe.ST_HEAD_SHOT_POINT shot)
        {
            return shot.HeadNo;
        }

        int SelectHeadGroupKey(global::System.Linq.IGrouping<int, global::Drilling.Common.Recipe.ST_HEAD_SHOT_POINT> headGroup)
        {
            return headGroup.Key;
        }

        double SelectScannerGx(global::Drilling.Common.Recipe.ST_HEAD_SHOT_POINT shot)
        {
            return shot.ScannerGx;
        }

        double SelectScannerGy(global::Drilling.Common.Recipe.ST_HEAD_SHOT_POINT shot)
        {
            return shot.ScannerGy;
        }

        int SelectCellNo(global::Drilling.Common.Recipe.ST_HEAD_SHOT_POINT shot)
        {
            return shot.CellNo;
        }

        int SelectCellShotNo(global::Drilling.Common.Recipe.ST_HEAD_SHOT_POINT shot)
        {
            return shot.CellShotNo;
        }

        foreach (var row in orderedRows)
        {
            var headGroups = row.GroupBy(SelectHeadNo).OrderBy(SelectHeadGroupKey);
            foreach (var headGroup in headGroups)
            {
                var headRowShots = headGroup.ToArray();
                // Process each head row from the local machining-axis minus side to plus side.
                var rowShots = UseScannerGyForMachiningSort(headRowShots)
                    ? headRowShots.OrderBy(SelectScannerGy).ThenBy(SelectCellNo).ThenBy(SelectCellShotNo)
                    : headRowShots.OrderBy(SelectScannerGx).ThenBy(SelectCellNo).ThenBy(SelectCellShotNo);
                orderedShots.AddRange(rowShots);
            }
        }

        return orderedShots;
    }

    private static bool UseScannerGyForMachiningSort(IReadOnlyList<ST_HEAD_SHOT_POINT> shots)
    {
        if (shots.Count <= 1)
        {
            return false;
        }

        var minGx = shots[0].ScannerGx;
        var maxGx = shots[0].ScannerGx;
        var minGy = shots[0].ScannerGy;
        var maxGy = shots[0].ScannerGy;
        for (var index = 1; index < shots.Count; index++)
        {
            var shot = shots[index];
            minGx = Math.Min(minGx, shot.ScannerGx);
            maxGx = Math.Max(maxGx, shot.ScannerGx);
            minGy = Math.Min(minGy, shot.ScannerGy);
            maxGy = Math.Max(maxGy, shot.ScannerGy);
        }

        return maxGy - minGy > maxGx - minGx;
    }

    private static int AssignHeadNo(double designX, IReadOnlyList<int> assignmentHeadNos, IReadOnlyDictionary<string, string> parameters, IReadOnlyDictionary<int, int> assignedHeadCounts)
    {
        if (assignmentHeadNos.Count <= 0)
        {
            return 0;
        }

        global::Drilling.Common.Recipe.ST_HEAD_ASSIGNMENT_CANDIDATE? SelectItem(int headNo)
        {
            var centerX = ReadHeadCenterX(parameters, headNo);
            var widthX = ReadNullableDouble(parameters, $"H{headNo:00}_SCAN_FIELD_WIDTH_X", $"H{headNo:00}_HEAD_FIELD_WIDTH_X") ?? 110.0;
            widthX = widthX > 0.0 ? widthX : 110.0;
            var halfWidth = widthX / 2.0;
            return designX >= centerX - halfWidth && designX <= centerX + halfWidth ? new ST_HEAD_ASSIGNMENT_CANDIDATE(headNo, Math.Abs(designX - centerX)) : (ST_HEAD_ASSIGNMENT_CANDIDATE? )null;
        }

        bool IsHasValue(global::Drilling.Common.Recipe.ST_HEAD_ASSIGNMENT_CANDIDATE? candidate)
        {
            return candidate.HasValue;
        }

        global::Drilling.Common.Recipe.ST_HEAD_ASSIGNMENT_CANDIDATE SelectHead(global::Drilling.Common.Recipe.ST_HEAD_ASSIGNMENT_CANDIDATE? candidate)
        {
            return candidate!.Value;
        }

        var candidates = assignmentHeadNos.Select(SelectItem).Where(IsHasValue).Select(SelectHead).ToArray();
        return candidates.Length == 0 ? 0 : SelectHeadCandidate(candidates, assignedHeadCounts);
    }

    private static int SelectHeadCandidate(IReadOnlyList<ST_HEAD_ASSIGNMENT_CANDIDATE> candidates, IReadOnlyDictionary<int, int> assignedHeadCounts)
    {
        double SelectDistance(global::Drilling.Common.Recipe.ST_HEAD_ASSIGNMENT_CANDIDATE candidate)
        {
            return candidate.Distance;
        }

        int SelectValue(global::Drilling.Common.Recipe.ST_HEAD_ASSIGNMENT_CANDIDATE candidate)
        {
            return assignedHeadCounts.TryGetValue(candidate.HeadNo, out var count) ? count : 0;
        }

        int SelectHeadNo(global::Drilling.Common.Recipe.ST_HEAD_ASSIGNMENT_CANDIDATE candidate)
        {
            return candidate.HeadNo;
        }

        return candidates.OrderBy(SelectDistance).ThenBy(SelectValue).ThenBy(SelectHeadNo).First().HeadNo;
    }

    private static IReadOnlyList<int> BuildActiveHeadNumbers(IReadOnlyDictionary<string, string> parameters, int headCount)
    {
        var activeHeadNos = new List<int>(headCount);
        for (var headNo = 1; headNo <= headCount; headNo++)
        {
            if (ReadHeadUse(parameters, headNo))
            {
                activeHeadNos.Add(headNo);
            }
        }

        if (activeHeadNos.Count == 0)
        {
            throw new InvalidOperationException("At least one head must be enabled. Check Hxx_USE option settings.");
        }

        return activeHeadNos;
    }

    private static bool ReadHeadUse(IReadOnlyDictionary<string, string> parameters, int headNo)
    {
        return ReadBool(parameters, true, $"H{headNo:00}_USE");
    }

    private static double ReadHeadCenterX(IReadOnlyDictionary<string, string> parameters, int headNo)
    {
        const double fallbackHead1PositionX = -5.0;
        const double fallbackHeadGapX = 200.0;
        var head1PositionX = ReadDouble(parameters, fallbackHead1PositionX, "H01_AK_POSITION_X");
        var headGapX = ReadDouble(parameters, fallbackHeadGapX, "HeadGapX");
        var akMarginX = ReadDouble(parameters, 0.0, "AK_MARGIN_X");
        return akMarginX + head1PositionX + ((headNo - 1) * headGapX);
    }

    private static double ReadHeadCenterY(IReadOnlyDictionary<string, string> parameters, int headNo)
    {
        var explicitHeadY = ReadNullableDouble(parameters, $"H{headNo:00}_AK_POSITION_Y");
        if (explicitHeadY.HasValue)
        {
            return explicitHeadY.Value;
        }

        var head1CenterY = ReadDouble(parameters, 0.0, "REVIEW_TO_HEAD1_GAP_Y");
        var headGapY = ReadDouble(parameters, 0.0, "HeadGapY");
        return headNo % 2 == 0 ? head1CenterY + headGapY : head1CenterY;
    }

    private static double ReadHeadDefaultOffset(IReadOnlyDictionary<string, string> parameters, int headNo, string axis)
    {
        return ReadDouble(parameters, 0.0, $"H{headNo:00}_DEFAULT_OFFSET_{axis}");
    }

    private static double ReadFirstBeamOffset(IReadOnlyDictionary<string, string> parameters, int headNo, string axis)
    {
        return ReadDouble(parameters, 0.0, $"H{headNo:00}_FIRST_BEAM_OFFSET_{axis}");
    }

    private static double ReadHeadEncoderScale(IReadOnlyDictionary<string, string> parameters, int headNo, double defaultValue)
    {
        return ReadDouble(parameters, defaultValue, $"H{headNo:00}_ENCODER_SCALE", "SCAN_ENCODER_SCALE");
    }

    private static double ConvertRecipeYToStageY(double recipeY)
    {
        return -recipeY;
    }

    private static double ApplyScannerAxis(double designPosition, double stageStartPosition, double offset)
    {
        return (designPosition - stageStartPosition) + offset;
    }

    private static double ReadScannerReferenceOffsetX(IReadOnlyDictionary<string, string> parameters)
    {
        var escEdgeToGlassEdge = ReadDouble(parameters, 0.0, "ESC_EDGE_TO_GLASS_EDGE", "ESC_EDGE_TO_GLASS_EDGE_X");
        var glassCenterToScannerCenter = ReadDouble(parameters, 0.0, "GLASS_CENTER_TO_SCANNER_CENTER", "GLASS_CENTER_TO_SCANNER_CENTER_X");
        return escEdgeToGlassEdge + glassCenterToScannerCenter;
    }

    internal static double ReadDirection(IReadOnlyDictionary<string, string> parameters, double defaultValue, params string[] keys)
    {
        bool ShouldIncludeItem(string key)
        {
            return !string.IsNullOrWhiteSpace(key);
        }

        foreach (var key in keys.Where(ShouldIncludeItem))
        {
            if (!parameters.TryGetValue(key, out var value) || string.IsNullOrWhiteSpace(value))
            {
                continue;
            }

            var normalized = value.Trim().ToUpperInvariant();
            if (double.TryParse(normalized, NumberStyles.Any, CultureInfo.InvariantCulture, out var number))
            {
                return NormalizeDirection(number, key);
            }

            if (normalized is "-" or "-1" or "REVERSE" or "REV" or "NEGATIVE" or "MINUS")
            {
                return -1.0;
            }

            if (normalized is "+" or "+1" or "FORWARD" or "FWD" or "POSITIVE" or "PLUS")
            {
                return 1.0;
            }

            throw new InvalidOperationException($"Invalid direction value. {key}={value}");
        }

        return NormalizeDirection(defaultValue, "DEFAULT_DIRECTION");
    }

    private static double NormalizeDirection(double value, string key)
    {
        if (!double.IsFinite(value) || (value != -1.0 && value != 1.0))
        {
            throw new InvalidOperationException($"Direction setting {key} must be -1 or +1. Current value: {value}");
        }

        return value;
    }

    private static string ToShotKey(int cellNo, int cellShotNo)
    {
        return $"CELL{Math.Max(1, cellNo):000}_SHOT{Math.Max(1, cellShotNo):0000}";
    }

    private static double ReadDouble(IReadOnlyDictionary<string, string> parameters, double defaultValue, params string[] keys)
    {
        bool ShouldIncludeItem(string key)
        {
            return !string.IsNullOrWhiteSpace(key);
        }

        foreach (var key in keys.Where(ShouldIncludeItem))
        {
            if (parameters.TryGetValue(key, out var value) && double.TryParse(value, NumberStyles.Any, CultureInfo.InvariantCulture, out var result))
            {
                return result;
            }
        }

        return defaultValue;
    }

    private static double? ReadNullableDouble(IReadOnlyDictionary<string, string> parameters, params string[] keys)
    {
        bool ShouldIncludeItem(string key)
        {
            return !string.IsNullOrWhiteSpace(key);
        }

        foreach (var key in keys.Where(ShouldIncludeItem))
        {
            if (parameters.TryGetValue(key, out var value) && double.TryParse(value, NumberStyles.Any, CultureInfo.InvariantCulture, out var result))
            {
                return result;
            }
        }

        return null;
    }

    private static int ReadInt(IReadOnlyDictionary<string, string> parameters, int defaultValue, params string[] keys)
    {
        bool ShouldIncludeItem(string key)

        {
            return !string.IsNullOrWhiteSpace(key);
        }

        foreach (var key in keys.Where(ShouldIncludeItem))
        {
            if (!parameters.TryGetValue(key, out var value))
            {
                continue;
            }

            if (int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var intResult))
            {
                return intResult;
            }

            if (double.TryParse(value, NumberStyles.Any, CultureInfo.InvariantCulture, out var doubleResult))
            {
                return (int)Math.Round(doubleResult);
            }
        }

        return defaultValue;
    }

    private static bool ReadBool(IReadOnlyDictionary<string, string> parameters, bool defaultValue, params string[] keys)
    {
        bool ShouldIncludeItem(string key)
        {
            return !string.IsNullOrWhiteSpace(key);
        }

        foreach (var key in keys.Where(ShouldIncludeItem))
        {
            if (!parameters.TryGetValue(key, out var value) || string.IsNullOrWhiteSpace(value))
            {
                continue;
            }

            var normalized = value.Trim().ToUpperInvariant();
            if (normalized is "1" or "Y" or "YES" or "TRUE" or "ON" or "USE")
            {
                return true;
            }

            if (normalized is "0" or "N" or "NO" or "FALSE" or "OFF" or "SKIP" or "UNUSEsc")
            {
                return false;
            }

            return defaultValue;
        }

        return defaultValue;
    }
}
