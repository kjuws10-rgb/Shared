namespace Drilling.Common.Recipe;

public sealed record ST_RECIPE_CELL_PATTERN_ENTRY(
    ST_CELL_PATTERN_DEFINITION Definition,
    ST_CELL_PATTERN_LAYOUT Layout,
    int StartIndex,
    int Count);

/// <summary>
/// Lazily maps Review points to the current Recipe cell layout.  It does not
/// persist or alter Recipe data; it only prevents large Review plans from
/// materializing duplicate point lists.
/// </summary>
public sealed class CRecipeCellPatternCatalog
{
    private readonly IReadOnlyList<ST_RECIPE_CELL_PATTERN_ENTRY> _cells;

    private CRecipeCellPatternCatalog(
        IReadOnlyList<ST_RECIPE_CELL_PATTERN_ENTRY> cells,
        int count)
    {
        _cells = cells;
        Count = count;
    }

    public int Count { get; }

    public int CellCount => _cells.Count;

    public IReadOnlyList<ST_RECIPE_CELL_PATTERN_ENTRY> Cells => _cells;

    public static CRecipeCellPatternCatalog Create(
        IEnumerable<ST_CELL_PATTERN_DEFINITION> definitions)
    {
        ArgumentNullException.ThrowIfNull(definitions);
        var cells = new List<ST_RECIPE_CELL_PATTERN_ENTRY>();
        var totalCount = 0;

        foreach (var definition in definitions.OrderBy(item => item.CellNo))
        {
            var layout = CCellPatternCalculator.Calculate(definition);
            if (!layout.IsValid)
            {
                throw new InvalidOperationException(layout.ValidationMessage);
            }

            var cellCount = checked(layout.GroupCountX * layout.GroupCountY);
            if (cellCount > int.MaxValue - totalCount)
            {
                throw new InvalidOperationException(
                    $"Recipe Cell point count {(long)totalCount + cellCount:N0} exceeds the supported list size.");
            }

            cells.Add(new ST_RECIPE_CELL_PATTERN_ENTRY(
                definition,
                layout,
                totalCount,
                cellCount));
            totalCount += cellCount;
        }

        return new CRecipeCellPatternCatalog(cells, totalCount);
    }

    public ST_RECIPE_CELL_PATTERN_ENTRY GetCell(int cellNo) =>
        _cells.FirstOrDefault(cell => cell.Definition.CellNo == cellNo)
        ?? throw new ArgumentOutOfRangeException(nameof(cellNo));

    public ST_SHOT_GROUP_CENTER GetShotCenter(int index)
    {
        var (cell, pointIndex) = Resolve(index);
        return GetShotCenter(cell, pointIndex);
    }

    public static ST_SHOT_GROUP_CENTER GetShotCenter(
        ST_RECIPE_CELL_PATTERN_ENTRY cell,
        int pointIndex)
    {
        if ((uint)pointIndex >= (uint)cell.Count)
        {
            throw new ArgumentOutOfRangeException(nameof(pointIndex));
        }

        return CCellPatternCalculator.CalculateShotCenter(
            cell.Definition,
            pointIndex % cell.Layout.GroupCountX,
            pointIndex / cell.Layout.GroupCountX,
            cell.Layout);
    }

    public (ST_RECIPE_CELL_PATTERN_ENTRY Cell, int PointIndex) Resolve(int index)
    {
        if ((uint)index >= (uint)Count)
        {
            throw new ArgumentOutOfRangeException(nameof(index));
        }

        var low = 0;
        var high = _cells.Count - 1;
        while (low <= high)
        {
            var middle = low + ((high - low) / 2);
            var cell = _cells[middle];
            if (index < cell.StartIndex)
            {
                high = middle - 1;
            }
            else if (index >= cell.StartIndex + cell.Count)
            {
                low = middle + 1;
            }
            else
            {
                return (cell, index - cell.StartIndex);
            }
        }

        throw new ArgumentOutOfRangeException(nameof(index));
    }
}
