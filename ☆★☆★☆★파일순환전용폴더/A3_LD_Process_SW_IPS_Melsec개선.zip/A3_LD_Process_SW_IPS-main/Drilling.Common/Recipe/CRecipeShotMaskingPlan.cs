using System.Globalization;

namespace Drilling.Common.Recipe;

public sealed record ST_RECIPE_SHOT_MASKING_RESULT(IReadOnlyList<int> BeamNumbers, IReadOnlyList<int> HoleNumbers, bool IsEdgeMasked, bool IsChessSkipped = false)
{
    public static ST_RECIPE_SHOT_MASKING_RESULT Empty { get; } = new([], [], false);

    public bool IsMasked
    {
        get
        {
            return BeamNumbers.Count > 0;
        }
    }

    public bool ShouldSkipLaser
    {
        get
        {
            return IsMasked || IsChessSkipped;
        }
    }
}

public sealed class CRecipeShotMaskingPlan
{
    private const int MaximumCellModelTypeCount = 5;
    private const int MaximumMaskingHoleCount = 3;
    private const double Epsilon = 0.000000001;
    private readonly IReadOnlyDictionary<int, ST_MODEL_MASKING_AREA> _models;
    private readonly IReadOnlyDictionary<int, ST_MODEL_PATTERN_AREA> _modelPatterns;
    private readonly IReadOnlyDictionary<int, int> _cellModelTypes;
    private readonly int _modelTypeCount;
    private readonly int _splitBeamCount;

    private CRecipeShotMaskingPlan(
        IReadOnlyDictionary<int, ST_MODEL_MASKING_AREA> models,
        IReadOnlyDictionary<int, ST_MODEL_PATTERN_AREA> modelPatterns,
        IReadOnlyDictionary<int, int> cellModelTypes,
        int modelTypeCount,
        int splitBeamCount)
    {
        _models = models;
        _modelPatterns = modelPatterns;
        _cellModelTypes = cellModelTypes;
        _modelTypeCount = modelTypeCount;
        _splitBeamCount = splitBeamCount;
    }

    public static CRecipeShotMaskingPlan Build(IReadOnlyDictionary<string, string> parameters)
    {
        ArgumentNullException.ThrowIfNull(parameters);
        var modelTypeCount = Math.Clamp(ReadInt(parameters, 1, "CELL_MODEL_TYPE_COUNT"), 1, MaximumCellModelTypeCount);
        var pixelSize = ReadDouble(parameters, 0.09, "PIXEL_SIZE");
        var splitBeamCount = ReadInt(parameters, 1, "SPLITED_BEAM_COUNT");
        var models = new Dictionary<int, ST_MODEL_MASKING_AREA>();
        var modelPatterns = new Dictionary<int, ST_MODEL_PATTERN_AREA>();
        for (var modelType = 1; modelType <= modelTypeCount; modelType++)
        {
            var modelPattern = CRecipeModelPixelCountReader.ReadPatternForModel(parameters, modelType);
            var groupPitchMillimeters = pixelSize * modelPattern.ProcessPitch;
            var beamPitchMillimeters = splitBeamCount <= 0 ? 0.0 : groupPitchMillimeters / splitBeamCount;
            modelPatterns[modelType] = new ST_MODEL_PATTERN_AREA(
                modelPattern.PixelCountX,
                modelPattern.PixelCountY,
                pixelSize,
                Math.Clamp(modelPattern.Chess, 1, 4),
                Math.Clamp(modelPattern.ChessType, 0, 1),
                groupPitchMillimeters,
                beamPitchMillimeters,
                beamPitchMillimeters * (Math.Max(1, splitBeamCount) - 1) / 2.0);
            var model = BuildModel(parameters, modelType);
            if (model.HasMasking)
            {
                models[modelType] = model;
            }
        }

        var cellCount = Math.Max(CCellPatternCalculator.MinCellCount, ReadInt(parameters, CCellPatternCalculator.MinCellCount, "MAX_CELL_NUMBER"));
        var cellModelTypes = new Dictionary<int, int>(cellCount);
        for (var cellNo = 1; cellNo <= cellCount; cellNo++)
        {
            cellModelTypes[cellNo] = Math.Clamp(ReadInt(parameters, 1, $"CELL{cellNo}_MODEL_TYPE"), 1, modelTypeCount);
        }

        return new CRecipeShotMaskingPlan(models, modelPatterns, cellModelTypes, modelTypeCount, splitBeamCount);
    }

    public ST_RECIPE_SHOT_MASKING_RESULT EvaluateShot(ST_HEAD_SHOT_POINT point)
    {
        var modelType = GetModelType(point.CellNo);
        var modelPattern = _modelPatterns.TryGetValue(modelType, out var pattern)
            ? pattern
            : new ST_MODEL_PATTERN_AREA(0, 0, 0.0, 1, 1, 0.0, 0.0, 0.0);
        var isChessSkipped = IsChessSkipped(point, modelPattern);
        if (_splitBeamCount <= 0 || !double.IsFinite(modelPattern.BeamPitchMillimeters) || modelPattern.BeamPitchMillimeters <= 0.0 || !double.IsFinite(modelPattern.GroupPitchMillimeters))
        {
            return isChessSkipped ? new ST_RECIPE_SHOT_MASKING_RESULT([], [], false, true) : ST_RECIPE_SHOT_MASKING_RESULT.Empty;
        }

        if (!_models.TryGetValue(modelType, out var model))
        {
            return isChessSkipped ? new ST_RECIPE_SHOT_MASKING_RESULT([], [], false, true) : ST_RECIPE_SHOT_MASKING_RESULT.Empty;
        }

        var edgeArea = model.Edge?.Create(
            modelPattern.PixelCountX,
            modelPattern.PixelCountY,
            modelPattern.PixelSizeMillimeters,
            modelPattern.BeamHalfSpanMillimeters);
        var maskedBeamNumbers = new List<int>();
        var maskedHoleNumbers = new SortedSet<int>();
        var isEdgeMasked = false;
        var beamHalfSpan = modelPattern.BeamPitchMillimeters / 2.0;
        var centerIndex = (_splitBeamCount - 1) / 2.0;
        var centerX = (point.GroupColumn * modelPattern.GroupPitchMillimeters) + point.FinalScannerOffsetX;
        var centerY = (point.GroupRow * modelPattern.GroupPitchMillimeters) + point.FinalScannerOffsetY;
        for (var row = 0; row < _splitBeamCount; row++)
        {
            for (var column = 0; column < _splitBeamCount; column++)
            {
                var beamBounds = ST_MASKING_RECT.FromCenter(
                    centerX + ((column - centerIndex) * modelPattern.BeamPitchMillimeters),
                    centerY + ((row - centerIndex) * modelPattern.BeamPitchMillimeters),
                    beamHalfSpan);
                var isHoleMasked = false;
                foreach (var hole in model.Holes)
                {
                    if (!hole.Intersects(beamBounds))
                    {
                        continue;
                    }

                    maskedHoleNumbers.Add(hole.HoleNo);
                    isHoleMasked = true;
                    break;
                }

                var isOutsideEdge = edgeArea is not null && edgeArea.Touches(beamBounds);
                if (!isHoleMasked && !isOutsideEdge)
                {
                    continue;
                }

                maskedBeamNumbers.Add((row * _splitBeamCount) + column + 1);
                isEdgeMasked = isEdgeMasked || isOutsideEdge;
            }
        }

        return maskedBeamNumbers.Count == 0 && !isChessSkipped
            ? ST_RECIPE_SHOT_MASKING_RESULT.Empty
            : new ST_RECIPE_SHOT_MASKING_RESULT(maskedBeamNumbers, maskedHoleNumbers.ToArray(), isEdgeMasked, isChessSkipped);
    }

    private int GetModelType(int cellNo)
    {
        return _cellModelTypes.TryGetValue(cellNo, out var cellModelType)
            ? Math.Clamp(cellModelType, 1, _modelTypeCount)
            : 1;
    }

    private static bool IsChessSkipped(ST_HEAD_SHOT_POINT point, ST_MODEL_PATTERN_AREA modelPattern)
    {
        if (modelPattern.Chess <= 1)
        {
            return false;
        }

        return modelPattern.ChessType == 0
            ? PositiveModulo(point.GroupColumn, modelPattern.Chess) != 0 ||
              PositiveModulo(point.GroupRow, modelPattern.Chess) != 0
            : PositiveModulo(point.GroupColumn - point.GroupRow, modelPattern.Chess) != 0;
    }

    private static ST_MODEL_MASKING_AREA BuildModel(IReadOnlyDictionary<string, string> parameters, int modelType)
    {
        var prefix = $"MODEL{Math.Clamp(modelType, 1, MaximumCellModelTypeCount)}_";
        var holeCount = Math.Clamp(ReadInt(parameters, 0, $"{prefix}MASKING_HOLE_NUMBER"), 0, MaximumMaskingHoleCount);
        var holes = new List<ST_MASKING_HOLE_AREA>(holeCount);
        for (var holeNo = 1; holeNo <= holeCount; holeNo++)
        {
            var x = ReadDouble(parameters, double.NaN, $"{prefix}MASKING_HOLE{holeNo}_X");
            var y = ReadDouble(parameters, double.NaN, $"{prefix}MASKING_HOLE{holeNo}_Y");
            var sizeX = ReadDouble(parameters, 0.0, $"{prefix}MASKING_HOLE{holeNo}_SIZE_X");
            var sizeY = ReadDouble(parameters, 0.0, $"{prefix}MASKING_HOLE{holeNo}_SIZE_Y");
            if (!double.IsFinite(x) || !double.IsFinite(y) || !double.IsFinite(sizeX) || !double.IsFinite(sizeY) || sizeX <= 0.0 || sizeY <= 0.0)
            {
                continue;
            }

            holes.Add(new ST_MASKING_HOLE_AREA(holeNo, x, y, sizeX, sizeY));
        }

        return new ST_MODEL_MASKING_AREA(holes, BuildEdge(parameters, prefix));
    }

    private static ST_EDGE_MASKING_AREA? BuildEdge(IReadOnlyDictionary<string, string> parameters, string prefix)
    {
        const double tolerance = 0.001;
        var upLeft = ST_MASKING_POINT.FromPositiveOffset(
            ReadDouble(parameters, 0.0, $"{prefix}CELL_UP_LEFT_ROUND_X"),
            ReadDouble(parameters, 0.0, $"{prefix}CELL_UP_LEFT_ROUND_Y"));
        var upRight = ST_MASKING_POINT.FromPositiveOffset(
            ReadDouble(parameters, 0.0, $"{prefix}CELL_UP_RIGHT_ROUND_X"),
            ReadDouble(parameters, 0.0, $"{prefix}CELL_UP_RIGHT_ROUND_Y"));
        var downLeft = ST_MASKING_POINT.FromPositiveOffset(
            ReadDouble(parameters, 0.0, $"{prefix}CELL_DOWN_LEFT_ROUND_X"),
            ReadDouble(parameters, 0.0, $"{prefix}CELL_DOWN_LEFT_ROUND_Y"));
        var downRight = ST_MASKING_POINT.FromPositiveOffset(
            ReadDouble(parameters, 0.0, $"{prefix}CELL_DOWN_RIGHT_ROUND_X"),
            ReadDouble(parameters, 0.0, $"{prefix}CELL_DOWN_RIGHT_ROUND_Y"));
        var values = new[]
        {
            upLeft.X, upLeft.Y, upRight.X, upRight.Y,
            downLeft.X, downLeft.Y, downRight.X, downRight.Y
        };
        if (values.All(value => Math.Abs(value) <= tolerance))
        {
            return null;
        }

        return values.Any(value => !double.IsFinite(value))
            ? null
            : new ST_EDGE_MASKING_AREA(upLeft, upRight, downLeft, downRight);
    }

    private static int ReadInt(IReadOnlyDictionary<string, string> parameters, int defaultValue, params string[] keys)
    {
        foreach (var key in keys)
        {
            if (!parameters.TryGetValue(key, out var value))
            {
                continue;
            }

            if (int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var intResult))
            {
                return intResult;
            }

            if (double.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out var doubleResult))
            {
                return (int)Math.Round(doubleResult);
            }
        }

        return defaultValue;
    }

    private static double ReadDouble(IReadOnlyDictionary<string, string> parameters, double defaultValue, params string[] keys)
    {
        foreach (var key in keys)
        {
            if (parameters.TryGetValue(key, out var value) && double.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out var result))
            {
                return result;
            }
        }

        return defaultValue;
    }

    private static int PositiveModulo(int value, int divisor)
    {
        return ((value % divisor) + divisor) % divisor;
    }

    private readonly record struct ST_MASKING_POINT(double X, double Y)
    {
        public static ST_MASKING_POINT FromPositiveOffset(double x, double y)
        {
            return new ST_MASKING_POINT(Math.Abs(x), Math.Abs(y));
        }

    }

    private sealed record ST_EDGE_CORNER_MASKING_AREA(IReadOnlyList<ST_MASKING_RECT> Bounds)
    {
        public bool Touches(ST_MASKING_RECT bounds)
        {
            return Bounds.Any(area => area.Intersects(bounds));
        }
    }
    private sealed record ST_MODEL_PATTERN_AREA(int PixelCountX, int PixelCountY, double PixelSizeMillimeters, int Chess, int ChessType, double GroupPitchMillimeters, double BeamPitchMillimeters, double BeamHalfSpanMillimeters);

    private sealed record ST_MODEL_MASKING_AREA(IReadOnlyList<ST_MASKING_HOLE_AREA> Holes, ST_EDGE_MASKING_AREA? Edge)
    {
        public bool HasMasking
        {
            get
            {
                return Holes.Count > 0 || Edge is not null;
            }
        }
    }

    private readonly record struct ST_MASKING_RECT(double Left, double Right, double Top, double Bottom)
    {
        public static ST_MASKING_RECT FromCenter(double x, double y, double halfSpan)
        {
            return new ST_MASKING_RECT(x - halfSpan, x + halfSpan, y - halfSpan, y + halfSpan);
        }

        public static ST_MASKING_RECT FromCorners(double left, double right, double top, double bottom)
        {
            return new ST_MASKING_RECT(
                Math.Min(left, right),
                Math.Max(left, right),
                Math.Min(top, bottom),
                Math.Max(top, bottom));
        }

        public bool Intersects(ST_MASKING_RECT other)
        {
            return Left <= other.Right + Epsilon &&
                Right >= other.Left - Epsilon &&
                Top <= other.Bottom + Epsilon &&
                Bottom >= other.Top - Epsilon;
        }
    }

    private sealed record ST_MASKING_HOLE_AREA(int HoleNo, double X, double Y, double SizeX, double SizeY)
    {
        public bool Intersects(ST_MASKING_RECT bounds)
        {
            return new ST_MASKING_RECT(X, X + SizeX, Y, Y + SizeY).Intersects(bounds);
        }
    }

    private sealed record ST_EDGE_MASKING_AREA(ST_MASKING_POINT UpLeft, ST_MASKING_POINT UpRight, ST_MASKING_POINT DownLeft, ST_MASKING_POINT DownRight)
    {
        public ST_EDGE_CORNER_MASKING_AREA? Create(int pixelCountX, int pixelCountY, double pixelSizeMillimeters, double firstDoeCenterOffsetMillimeters)
        {
            if (pixelCountX <= 0 ||
                pixelCountY <= 0 ||
                !double.IsFinite(pixelSizeMillimeters) ||
                pixelSizeMillimeters <= 0.0 ||
                !double.IsFinite(firstDoeCenterOffsetMillimeters) ||
                firstDoeCenterOffsetMillimeters < 0.0)
            {
                return null;
            }

            var leftPixelX = -firstDoeCenterOffsetMillimeters;
            var topPixelY = -firstDoeCenterOffsetMillimeters;
            var rightPixelX = leftPixelX + (Math.Max(0, pixelCountX - 1) * pixelSizeMillimeters);
            var bottomPixelY = topPixelY + (Math.Max(0, pixelCountY - 1) * pixelSizeMillimeters);
            var bounds = new List<ST_MASKING_RECT>(4);
            AddCorner(bounds, leftPixelX, leftPixelX + UpLeft.X, topPixelY, topPixelY + UpLeft.Y);
            AddCorner(bounds, rightPixelX - UpRight.X, rightPixelX, topPixelY, topPixelY + UpRight.Y);
            AddCorner(bounds, leftPixelX, leftPixelX + DownLeft.X, bottomPixelY - DownLeft.Y, bottomPixelY);
            AddCorner(bounds, rightPixelX - DownRight.X, rightPixelX, bottomPixelY - DownRight.Y, bottomPixelY);
            return bounds.Count == 0 ? null : new ST_EDGE_CORNER_MASKING_AREA(bounds);
        }

        private static void AddCorner(List<ST_MASKING_RECT> bounds, double left, double right, double top, double bottom)
        {
            if (!double.IsFinite(left) ||
                !double.IsFinite(right) ||
                !double.IsFinite(top) ||
                !double.IsFinite(bottom) ||
                Math.Abs(right - left) <= Epsilon ||
                Math.Abs(bottom - top) <= Epsilon)
            {
                return;
            }

            bounds.Add(ST_MASKING_RECT.FromCorners(left, right, top, bottom));
        }
    }
}
