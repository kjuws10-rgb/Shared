using System.Globalization;

namespace Drilling.Common.Recipe;

public readonly record struct ST_RECIPE_MODEL_PIXEL_COUNT(int PixelCountX, int PixelCountY);
public readonly record struct ST_RECIPE_MODEL_PATTERN(int PixelCountX, int PixelCountY, int ProcessPitch, int Chess, int ChessType);

public static class CRecipeModelPixelCountReader
{
    public const int MaximumCellModelTypeCount = 5;

    public static int ReadModelTypeCount(IReadOnlyDictionary<string, string> parameters)
    {
        return Math.Clamp(ReadInt(parameters, 1, "CELL_MODEL_TYPE_COUNT"), 1, MaximumCellModelTypeCount);
    }

    public static int ReadCellModelType(IReadOnlyDictionary<string, string> parameters, int cellNo, int modelTypeCount = 0)
    {
        var maximum = modelTypeCount > 0 ? Math.Min(modelTypeCount, MaximumCellModelTypeCount) : ReadModelTypeCount(parameters);
        return Math.Clamp(ReadInt(parameters, 1, $"CELL{cellNo}_MODEL_TYPE"), 1, Math.Max(1, maximum));
    }

    public static ST_RECIPE_MODEL_PIXEL_COUNT ReadForCell(IReadOnlyDictionary<string, string> parameters, int cellNo)
    {
        return ReadForModel(parameters, ReadCellModelType(parameters, cellNo));
    }

    public static ST_RECIPE_MODEL_PATTERN ReadPatternForCell(IReadOnlyDictionary<string, string> parameters, int cellNo)
    {
        return ReadPatternForModel(parameters, ReadCellModelType(parameters, cellNo));
    }

    public static ST_RECIPE_MODEL_PIXEL_COUNT ReadForModel(IReadOnlyDictionary<string, string> parameters, int modelType)
    {
        var prefix = $"MODEL{Math.Clamp(modelType, 1, MaximumCellModelTypeCount)}_";
        return new ST_RECIPE_MODEL_PIXEL_COUNT(
            ReadInt(parameters, 0, $"{prefix}NUM_OF_PIXEL_X"),
            ReadInt(parameters, 0, $"{prefix}NUM_OF_PIXEL_Y"));
    }

    public static ST_RECIPE_MODEL_PATTERN ReadPatternForModel(IReadOnlyDictionary<string, string> parameters, int modelType)
    {
        var prefix = $"MODEL{Math.Clamp(modelType, 1, MaximumCellModelTypeCount)}_";
        return new ST_RECIPE_MODEL_PATTERN(
            ReadInt(parameters, 0, $"{prefix}NUM_OF_PIXEL_X"),
            ReadInt(parameters, 0, $"{prefix}NUM_OF_PIXEL_Y"),
            ReadInt(parameters, 1, $"{prefix}PITCH"),
            Math.Clamp(ReadInt(parameters, 1, $"{prefix}CHESS"), 1, 4),
            Math.Clamp(ReadInt(parameters, 1, $"{prefix}CHESS_TYPE"), 0, 1));
    }

    private static int ReadInt(IReadOnlyDictionary<string, string> parameters, int defaultValue, params string[] keys)
    {
        foreach (var key in keys)
        {
            if (!parameters.TryGetValue(key, out var value))
            {
                continue;
            }

            if (int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var intResult))
            {
                return intResult;
            }

            if (double.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out var doubleResult))
            {
                return (int)Math.Round(doubleResult);
            }
        }

        return defaultValue;
    }
}
