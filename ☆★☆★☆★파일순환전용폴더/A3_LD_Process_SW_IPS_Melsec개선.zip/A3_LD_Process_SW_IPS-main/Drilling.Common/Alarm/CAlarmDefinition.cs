namespace Drilling.Common.Alarm;

public sealed record ST_ALARM_DEFINITION(int Code, string Group, string Id, string Level,
    string Cause, string Solution, string CimAddress);

public abstract class CAlarmListFileBase
{
    public abstract IReadOnlyList<ST_ALARM_DEFINITION> Load();
}

public sealed record ST_ALARM_DEFINITION_SNAPSHOT(IReadOnlyList<ST_ALARM_DEFINITION> Rows, string Error);
