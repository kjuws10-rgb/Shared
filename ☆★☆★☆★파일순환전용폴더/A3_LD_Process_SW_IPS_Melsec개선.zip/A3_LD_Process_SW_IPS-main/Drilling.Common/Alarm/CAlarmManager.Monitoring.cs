using Drilling.Common.Automation;
using Drilling.Common.InterLock;
using Drilling.Common.Managers;

namespace Drilling.Common.Alarm;

public sealed partial class CAlarmManager
{
    private readonly object _monitoringLock = new();
    private CancellationTokenSource? _monitoringStop;
    private Task? _monitoringTask;
    private string _monitoringError = "";
    public string MonitoringError
    {
        get
        {
            var checks = Volatile.Read(ref _monitoringError);
            var history = HistoryStorageError;
            return string.IsNullOrEmpty(history) ? checks : string.IsNullOrEmpty(checks) ? history :
                checks + Environment.NewLine + history;
        }
    }

    /// <summary>단일 백그라운드 작업자에서 알람 조건을 감시합니다.</summary>
    /// <remarks>
    /// reportError는 감시 작업자 스레드에서 동기적으로 호출되며 동일 오류는 반복 보고하지 않습니다.
    /// CurrentChanged와 마찬가지로 UI를 갱신하는 콜백은 Dispatcher/BeginInvoke 또는
    /// SynchronizationContext.Post로 UI 스레드에 전달해야 합니다. 로그 전용 콜백은 저장소의 스레드 안전성을 보장해야 합니다.
    /// readDeviceSnapshot은 메모리에 공개된 스냅샷만 반환해야 하며 장치 통신을 수행하면 안 됩니다.
    /// </remarks>
    public void StartMonitoring(CSettingManager settings, CAutomationManager automation,
        Func<ST_DEVICE_STATUS> readDeviceSnapshot, CInterLockManager interLocks,
        Action<Exception>? reportError = null)
    {
        EnsureDefinitionsRequested();
        ArgumentNullException.ThrowIfNull(readDeviceSnapshot);
        var temperatures = new CScannerTemperatureAlarmMonitor(this, settings, automation);
        StartMonitoring([
            token => { token.ThrowIfCancellationRequested(); temperatures.Check(); },
            token =>
            {
                token.ThrowIfCancellationRequested();
                var status = readDeviceSnapshot();
                Build(status, interLocks.Evaluate(status));
                if (!string.IsNullOrEmpty(status.SnapshotError)) throw new IOException(status.SnapshotError);
            }
        ], reportError, TimeSpan.FromSeconds(1));
    }

    // A single worker executes the checks in order; slow checks never overlap the next cycle.
    internal void StartMonitoring(Action<CancellationToken>[] checks, Action<Exception>? reportError, TimeSpan interval)
    {
        ArgumentNullException.ThrowIfNull(checks);
        EnsureDefinitionsRequested();
        if (interval <= TimeSpan.Zero) throw new ArgumentOutOfRangeException(nameof(interval));
        var registeredChecks = checks.ToArray();
        lock (_monitoringLock)
        {
            if (_monitoringTask is not null) return;
            _monitoringStop = new CancellationTokenSource();
            var token = _monitoringStop.Token;
            _monitoringTask = Task.Run(() => Monitor(registeredChecks, reportError, interval, token));
        }
    }

    public async Task StopMonitoringAsync()
    {
        Task task;
        CancellationTokenSource stop;
        lock (_monitoringLock)
        {
            if (_monitoringTask is null || _monitoringStop is null) return;
            task = _monitoringTask;
            stop = _monitoringStop;
            stop.Cancel();
        }
        await task.ConfigureAwait(false);
        lock (_monitoringLock)
        {
            if (!ReferenceEquals(_monitoringTask, task)) return;
            _monitoringTask = null;
            _monitoringStop = null;
            stop.Dispose();
        }
    }

    private async Task Monitor(Action<CancellationToken>[] checks, Action<Exception>? reportError,
        TimeSpan interval, CancellationToken token)
    {
        using var timer = new PeriodicTimer(interval);
        var previousErrors = new string[checks.Length];
        var previousDefinitionError = "";
        try
        {
            do
            {
                var errors = new List<string>();
                var definitionError = RetryDefinitionInitialization();
                if (!string.IsNullOrEmpty(definitionError))
                {
                    Volatile.Write(ref _monitoringError, $"Alarm definitions: {definitionError}");
                    if (previousDefinitionError != definitionError)
                    {
                        previousDefinitionError = definitionError;
                        try { reportError?.Invoke(new InvalidOperationException($"알람 정의 초기화 대기: {definitionError}")); }
                        catch (Exception reportException) { System.Diagnostics.Debug.WriteLine(reportException); }
                    }
                    continue; // No SetAlarm/Build/device snapshot checks until catalog recovery succeeds.
                }
                previousDefinitionError = "";
                for (var index = 0; index < checks.Length; index++)
                {
                    token.ThrowIfCancellationRequested();
                    try
                    {
                        checks[index](token);
                        previousErrors[index] = "";
                    }
                    catch (OperationCanceledException) when (token.IsCancellationRequested) { throw; }
                    catch (Exception exception)
                    {
                        var message = $"Alarm check {index + 1}: {exception.Message}";
                        errors.Add(message);
                        if (previousErrors[index] != message)
                        {
                            previousErrors[index] = message;
                            try { reportError?.Invoke(exception); }
                            catch (Exception reportException) { System.Diagnostics.Debug.WriteLine(reportException); }
                        }
                    }
                }
                Volatile.Write(ref _monitoringError, string.Join(Environment.NewLine, errors));
            }
            while (await timer.WaitForNextTickAsync(token).ConfigureAwait(false));
        }
        catch (OperationCanceledException) when (token.IsCancellationRequested) { }
    }
}
