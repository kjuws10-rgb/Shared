namespace Drilling.Common.Alarm;

public sealed partial class CAlarmManager
{
    private readonly object _definitionLock = new();
    private bool _definitionsInitialized;
    private bool _definitionInitializationRequested;
    private Task? _definitionRetryTask;
    private CAlarmListFileBase? _definitionFile;
    private int _definitionRetriesRemaining;
    private long _nextDefinitionRetryAt;
    private ST_ALARM_DEFINITION_SNAPSHOT _definitions = new([], "알람 목록이 로드되지 않았습니다.");

    public ST_ALARM_DEFINITION_SNAPSHOT GetDefinitionsSnapshot() => Volatile.Read(ref _definitions);

    public ST_ALARM_DEFINITION_SNAPSHOT InitializeDefinitions(CAlarmListFileBase file)
    {
        ArgumentNullException.ThrowIfNull(file);
        Volatile.Write(ref _definitionInitializationRequested, true);
        lock (_definitionLock)
        {
            if (_definitionsInitialized) return _definitions;
            _definitionFile = file;
            _definitionRetriesRemaining = 2;
            LoadDefinitionsLocked(file);
            return _definitions;
        }
    }

    private void LoadDefinitionsLocked(CAlarmListFileBase file)
    {
        try
        {
            var codes = new HashSet<int>();
            var ids = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var rows = file.Load().Select(row =>
            {
                var level = row.Level?.Trim().ToUpperInvariant();
                var id = row.Id?.Trim();
                if (level is not ("HEAVY" or "LIGHT"))
                    throw new InvalidDataException($"알람 {row.Code}: LEVEL은 HEAVY 또는 LIGHT여야 합니다.");
                if (string.IsNullOrEmpty(id) || !codes.Add(row.Code) || !ids.Add(id))
                    throw new InvalidDataException($"알람 {row.Code}: CODE/ID가 중복되었거나 ID가 비어 있습니다.");
                return row with { Id = id, Level = level };
            }).ToArray();
            if (rows.Length == 0) throw new InvalidDataException("알람 정의 목록이 비어 있습니다.");
            Volatile.Write(ref _definitions, new(Array.AsReadOnly(rows), ""));
            // Freeze only a successfully validated catalog. UI reads never reload this file.
            _definitionsInitialized = true;
            _definitionFile = null;
            _definitionRetriesRemaining = 0;
        }
        catch (Exception exception)
        {
            Volatile.Write(ref _definitions, new(_definitions.Rows, exception.Message));
            _nextDefinitionRetryAt = Environment.TickCount64 + 1000;
        }
    }

    private string RetryDefinitionInitialization()
    {
        var snapshot = GetDefinitionsSnapshot();
        if (snapshot.Error == "" && snapshot.Rows.Count > 0) return "";
        // A slow file/network load must never hold the monitor's shutdown path.
        if (!global::System.Threading.Monitor.TryEnter(_definitionLock)) return snapshot.Error;
        try
        {
            if (_definitionsInitialized) return "";
            var file = _definitionFile;
            if (file is null) return _definitions.Error;
            // Recover transient startup failures without turning the catalog into a polled file.
            // After two background retries, an explicit InitializeDefinitions call can retry again.
            if (_definitionRetriesRemaining > 0 && _definitionRetryTask?.IsCompleted != false &&
                Environment.TickCount64 >= _nextDefinitionRetryAt)
            {
                _definitionRetriesRemaining--;
                _definitionRetryTask = Task.Run(() =>
                {
                    lock (_definitionLock)
                    {
                        if (!_definitionsInitialized) LoadDefinitionsLocked(file);
                    }
                });
            }
            return _definitions.Error;
        }
        finally { global::System.Threading.Monitor.Exit(_definitionLock); }
    }

    internal void EnsureDefinitionsRequested()
    {
        if (!Volatile.Read(ref _definitionInitializationRequested))
            throw new InvalidOperationException("알람 정의 초기화가 필요합니다. InitializeDefinitions 호출 후 감시를 시작해 주세요.");
    }
}
