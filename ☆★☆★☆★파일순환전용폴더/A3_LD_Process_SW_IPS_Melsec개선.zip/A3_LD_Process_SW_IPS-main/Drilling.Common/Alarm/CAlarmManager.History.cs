namespace Drilling.Common.Alarm;

public sealed partial class CAlarmManager
{
    private const int HistoryQueueCapacity = 1024;
    private readonly object _historyQueueLock = new();
    private readonly Queue<ST_ALARM_DATA> _historyQueue = [];
    private Task? _historyTask;
    private string _historyError = "";
    private long _historyWriteStartedAt;

    public string HistoryStorageError
    {
        get
        {
            var error = Volatile.Read(ref _historyError);
            var startedAt = Volatile.Read(ref _historyWriteStartedAt);
            if (startedAt > 0 && Environment.TickCount64 - startedAt >= 5000)
                return string.IsNullOrEmpty(error) ? "알람 이력 저장이 5초 이상 지연되고 있습니다." :
                    error + Environment.NewLine + "알람 이력 저장이 5초 이상 지연되고 있습니다.";
            return error;
        }
    }

    // Called under _currentLock, after publishing the occurrence. No external I/O or waiting here.
    private bool QueueHistory(ST_ALARM_DATA alarm)
    {
        if (_history is null) return true;
        lock (_historyQueueLock)
        {
            if (_historyQueue.Count >= HistoryQueueCapacity) return false;
            _historyQueue.Enqueue(alarm);
            _historyTask ??= Task.Run(WriteQueuedHistory);
            return true;
        }
    }

    private void WriteQueuedHistory()
    {
        while (true)
        {
            ST_ALARM_DATA alarm;
            lock (_historyQueueLock)
            {
                if (!_historyQueue.TryDequeue(out alarm!))
                {
                    _historyTask = null;
                    return;
                }
            }
            Volatile.Write(ref _historyWriteStartedAt, Environment.TickCount64);
            try { _history!.Append(alarm); }
            catch (Exception exception)
            {
                var error = $"알람 {alarm.Code} 로그 저장 실패: {exception.Message}";
                Volatile.Write(ref _historyError, error);
                lock (_currentLock)
                {
                    // A later RESET/new alarm must survive a delayed failure from an older write.
                    PublishCurrent(_current.OccurrenceVersion, error);
                }
                NotifyCurrentChanged();
            }
            finally { Volatile.Write(ref _historyWriteStartedAt, 0); }
            // Single attempt only: no retries, persistence journal, or replay after restart.
        }
    }

    /// <summary>현재 저장 대기열의 처리를 비동기로 기다립니다. 일반 감시 처리에서는 호출하지 않습니다.</summary>
    public Task FlushHistoryAsync(CancellationToken cancellationToken = default)
    {
        Task pending;
        lock (_historyQueueLock) pending = _historyTask ?? Task.CompletedTask;
        return pending.WaitAsync(cancellationToken);
    }
}
