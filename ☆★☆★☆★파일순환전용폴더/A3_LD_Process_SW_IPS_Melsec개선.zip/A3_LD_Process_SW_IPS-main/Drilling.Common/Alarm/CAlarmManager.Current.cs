namespace Drilling.Common.Alarm;

public sealed record ST_CURRENT_ALARM_SNAPSHOT(long Revision, long OccurrenceVersion,
    IReadOnlyList<ST_ALARM_DATA> Rows, string LogError);

public sealed partial class CAlarmManager
{
    private readonly object _currentLock = new();
    private readonly Dictionary<int, ST_ALARM_DATA> _curAlarm = [];
    private readonly IAlarmHistoryStore? _history;
    private readonly Func<DateTimeOffset> _now;
    private ST_CURRENT_ALARM_SNAPSHOT _current = new(0, 0, [], "");
    private string _notificationError = "";

    public CAlarmManager(IAlarmHistoryStore? history = null, Func<DateTimeOffset>? now = null)
    {
        _history = history;
        _now = now ?? (() => DateTimeOffset.Now);
    }

    /// <summary>현재 알람 스냅샷 변경을 상태를 변경한 스레드에서 동기적으로 통지합니다.</summary>
    /// <remarks>
    /// 등록/RESET 호출자, 감시 작업자 또는 이력 저장 작업자에서 호출될 수 있습니다.
    /// UI 구독자는 WPF Dispatcher.BeginInvoke, WinForms BeginInvoke 또는
    /// SynchronizationContext.Post를 사용해 자신의 UI 스레드로 전달해야 합니다.
    /// reportError 콜백에도 같은 UI 전달 규칙이 적용되며, 관리자는 UI 컨텍스트를 자동 전환하지 않습니다.
    /// 구독자는 오래 걸리는 작업을 직접 수행하지 않아야 합니다.
    /// </remarks>
    public event Action? CurrentChanged;
    public string NotificationError => Volatile.Read(ref _notificationError);
    public IReadOnlyList<ST_ALARM_DATA> CurAlarm => GetCurrentSnapshot().Rows;
    public ST_CURRENT_ALARM_SNAPSHOT GetCurrentSnapshot() => Volatile.Read(ref _current);

    public bool SetAlarm(int code)
    {
        var definition = GetDefinitionsSnapshot().Rows.FirstOrDefault(row => row.Code == code)
            ?? throw new ArgumentException($"등록되지 않은 알람 CODE: {code}", nameof(code));
        return SetAlarm(definition);
    }

    public bool SetAlarm(string id)
    {
        var definition = GetDefinitionsSnapshot().Rows.FirstOrDefault(row => row.Id.Equals(id, StringComparison.OrdinalIgnoreCase))
            ?? throw new ArgumentException($"등록되지 않은 알람 ID: {id}", nameof(id));
        return SetAlarm(definition);
    }

    private bool SetAlarm(ST_ALARM_DEFINITION definition) => AddCurrent(new(definition.Code,
        definition.Level == "LIGHT" ? EN_ALARM_LEVEL.Warning : EN_ALARM_LEVEL.Critical,
        definition.Cause, definition.Solution, _now(), definition.Group)
        { Id = definition.Id, Group = definition.Group, CimAddress = definition.CimAddress });

    private bool AddCurrent(ST_ALARM_DATA alarm)
    {
        lock (_currentLock)
        {
            if (!_curAlarm.TryAdd(alarm.Code, alarm)) return false;
            PublishCurrent(_current.OccurrenceVersion + 1, _current.LogError);
            // Only enqueue memory here, in occurrence order. The dedicated worker owns all Append I/O.
            if (!QueueHistory(alarm))
            {
                var error = $"알람 {alarm.Code} 로그 저장 대기열 포화: {HistoryQueueCapacity}건. 해당 이력은 저장되지 않았습니다.";
                Volatile.Write(ref _historyError, error);
                PublishCurrent(_current.OccurrenceVersion, error);
            }
        }
        NotifyCurrentChanged();
        return true;
    }

    public void Reset()
    {
        lock (_currentLock)
        {
            if (_curAlarm.Count == 0) return;
            _curAlarm.Clear();
            PublishCurrent(_current.OccurrenceVersion, _current.LogError);
        }
        NotifyCurrentChanged();
    }

    private void NotifyCurrentChanged()
    {
        var handlers = CurrentChanged;
        var errors = new List<string>();
        if (handlers is not null)
        {
            foreach (Action handler in handlers.GetInvocationList())
            {
                try { handler(); }
                catch (Exception exception)
                {
                    // Subscribers dispatch to their own UI context. A failed observer must not
                    // change SetAlarm/Reset's result or prevent the other observers from running.
                    errors.Add($"{handler.Method.Name}: {exception.Message}");
                }
            }
        }
        Volatile.Write(ref _notificationError, string.Join(Environment.NewLine, errors));
    }

    private void PublishCurrent(long occurrenceVersion, string error)
    {
        var rows = Array.AsReadOnly(_curAlarm.Values.OrderByDescending(row => row.Severity)
            .ThenBy(row => row.OccurredAt).ThenBy(row => row.Code).ToArray());
        Volatile.Write(ref _current, new(_current.Revision + 1, occurrenceVersion, rows, error));
    }

    public ST_ALARM_HISTORY_RESULT ReadHistory(DateTime from, DateTime through, CancellationToken token = default) =>
        _history?.Read(from, through, token) ?? new([], "알람 로그 저장소가 연결되지 않았습니다.");
}
