namespace Drilling.Common.Alarm;

public sealed record ST_ALARM_HISTORY_ENTRY(DateTimeOffset OccurredAt, int Code, string Id,
    string Group, string Level, string Cause, string Solution, string CimAddress);
public sealed record ST_ALARM_HISTORY_RESULT(IReadOnlyList<ST_ALARM_HISTORY_ENTRY> Rows, string Warning);

public interface IAlarmHistoryStore
{
    // Called in FIFO order by a dedicated writer, outside the alarm-state lock and monitoring worker.
    // Implementations synchronize shared storage with readers/other manager instances themselves.
    void Append(ST_ALARM_DATA alarm);
    ST_ALARM_HISTORY_RESULT Read(DateTime from, DateTime through, CancellationToken token = default);
}
