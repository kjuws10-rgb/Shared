using System.Globalization;
using Drilling.Common.Automation;
using Drilling.Common.Managers;

namespace Drilling.Common.Alarm;

// Uses the shared settings/Automation caches regardless of the currently selected menu or heads.
internal sealed class CScannerTemperatureAlarmMonitor(
    CAlarmManager alarms, CSettingManager settings, CAutomationManager automation)
{
    public void Check()
    {
        var options = settings.LoadSection(EN_SETTING_TAB.Option);
        var limitText = options.FirstOrDefault(option =>
            option.Key.Equals("SCANNER_TEMP_LIMIT", StringComparison.OrdinalIgnoreCase) ||
            option.Name.Equals("SCANNER_TEMP_LIMIT", StringComparison.OrdinalIgnoreCase))?.Value;
        if ((!double.TryParse(limitText, NumberStyles.Float, CultureInfo.InvariantCulture, out var limit) &&
             !double.TryParse(limitText, NumberStyles.Float, CultureInfo.CurrentCulture, out limit)) ||
            !double.IsFinite(limit) || limit < 0)
        {
            var displayedValue = limitText is null ? "<누락>" : string.IsNullOrWhiteSpace(limitText) ? "<빈 값>" : limitText;
            // Let the owning monitor expose MonitoringError and reportError instead of
            // silently treating a disabled temperature check as a successful cycle.
            throw new InvalidDataException($"Scanner Temp Limit (SCANNER_TEMP_LIMIT) 설정 오류: " +
                $"0 이상의 유한한 온도(°C)가 필요합니다. 현재 값: {displayedValue}. " +
                "Setting > OPTION > INTERLOCK에서 확인해 주세요.");
        }

        for (var headNo = 1; headNo <= 8; headNo++)
        {
            var overLimit = false;
            foreach (var axis in CScannerAxisConfiguration.BuildAxisDefinitions(options, headNo))
            {
                if (!axis.IsUsed || !axis.ReadExtendedStatus || !string.IsNullOrEmpty(axis.ConfigurationError)) continue;
                if (!automation.IsSimul(axis.AutomationNo) && !automation.IsConnect(axis.AutomationNo)) continue;

                // GetAxis only registers/reads the cache; the shared acquisition service owns device reads.
                var snapshot = automation.StatusSnapshots.GetAxis(axis.AxisReference, axis.AutomationNo, axis.AioNo, axis.ReadExtendedStatus);
                if (snapshot.State != "OK" || snapshot.Value is not { } status) continue;
                overLimit |= double.IsFinite(status.MotorTemperature) && status.MotorTemperature > limit;
            }

            // 1048..1055 correspond to SCANNER 1..8. Keep both X/Y subscribed even when one is hot.
            if (overLimit) alarms.SetAlarm(1047 + headNo);
        }
    }
}
