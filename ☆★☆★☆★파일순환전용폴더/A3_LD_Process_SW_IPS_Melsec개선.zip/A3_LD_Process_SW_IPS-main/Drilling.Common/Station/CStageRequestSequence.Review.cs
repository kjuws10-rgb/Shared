namespace Drilling.Common.Station;

public sealed record ST_STAGE_REVIEW_ACTIONS(Func<CancellationToken, Task> Prepare,
    Func<CancellationToken, Task> Measure, Func<CancellationToken, Task> Save);

public sealed partial class CStageRequestSequence
{
    public const string StgReviewAble = "HANDSHAKE_STG_REVIEW_ABLE";
    public const string StgReviewStart = "HANDSHAKE_STG_REVIEW_START";
    public const string StgReviewComplete = "HANDSHAKE_STG_REVIEW_COMPLETE";
    public const string PrcReviewAble = "HANDSHAKE_PRC_REVIEW_ABLE";
    public const string PrcReviewStart = "HANDSHAKE_PRC_REVIEW_START";
    public const string PrcReviewComplete = "HANDSHAKE_PRC_REVIEW_COMPLETE";
    private static readonly string[] ReviewOutputs = [PrcReviewComplete, PrcReviewStart, PrcReviewAble];
    private ST_STAGE_REVIEW_ACTIONS? _reviewActions;
    private bool _reviewOutputsOwned;

    private bool IsReviewReady(ST_STAGE_SIGNAL_SNAPSHOT sample) => _reviewActions is not null &&
        TrySignal(sample, StgReviewAble, out var able) && able == 1 &&
        TrySignal(sample, StgReviewStart, out var start) && start == 0 &&
        TrySignal(sample, StgReviewComplete, out var complete) && complete == 0;

    private async Task RunReview(CancellationToken token)
    {
        var review = _reviewActions ?? throw new InvalidOperationException("Review actions are not configured.");
        actions.ResetToWaiting([CSequenceActionIds.ReviewPlan, CSequenceActionIds.ReviewMeasure,
            CSequenceActionIds.ReviewResults, CSequenceActionIds.ReviewSignalsClear]);
        Set("REVIEW_PLAN", "Stage Review ABLE received; freezing Glass / Recipe / Run Option and Beam 11 plan before our ABLE.");
        await Action(CSequenceActionIds.ReviewPlan, review.Prepare, token).ConfigureAwait(false);
        await WriteConfirmed(PrcReviewAble, 1, token).ConfigureAwait(false);
        Set("REVIEW_WAIT_START", "Inspection plan ready; waiting for Stage Review START.");
        await WaitSignal(StgReviewStart, 1, token).ConfigureAwait(false);
        await WriteConfirmed(PrcReviewStart, 1, token).ConfigureAwait(false);
        Set("REVIEW_MEASURE", "FINE inspection running. Quality NG does not stop later targets.");
        await Action(CSequenceActionIds.ReviewMeasure, review.Measure, token, Timeout.InfiniteTimeSpan).ConfigureAwait(false);
        Set("REVIEW_RESULTS", "Validating all results; save accumulated FINE offset for the next Glass only when all targets are OK.");
        await Action(CSequenceActionIds.ReviewResults, review.Save, token).ConfigureAwait(false);
        await WriteConfirmed(PrcReviewComplete, 1, token).ConfigureAwait(false);
        Set("REVIEW_WAIT_COMPLETE", "All inspection results handled; waiting for Stage Review COMPLETE.");
        await WaitSignal(StgReviewComplete, 1, token).ConfigureAwait(false);
        Set("REVIEW_SIGNALS_CLEAR", "Clearing Review signals and waiting for all Stage Review signals OFF.");
        await Action(CSequenceActionIds.ReviewSignalsClear, async ct =>
        {
            foreach (var id in ReviewOutputs) await WriteConfirmed(id, 0, ct).ConfigureAwait(false);
            foreach (var id in new[] { StgReviewComplete, StgReviewStart, StgReviewAble })
                await WaitSignal(id, 0, ct).ConfigureAwait(false);
            actions.ResetToWaiting([CSequenceActionIds.ReviewPlan, CSequenceActionIds.ReviewMeasure, CSequenceActionIds.ReviewResults]);
        }, token, resetToWaitingOnSuccess: true).ConfigureAwait(false);
        Set("REVIEW_COMPLETE", "Review handshake completed; waiting for Stage's next request.");
    }
}
