using System.Globalization;
using Drilling.Common.Interface;
using Drilling.Common.Managers;

namespace Drilling.Common.Station;

public sealed record ST_STAGE_READY_POSITION_RESULT(bool IsReady, string Detail);

/// <summary>Reads existing MELSEC and setting snapshots only; never requests a device read or move.</summary>
public sealed class CStageReadyPositionCheck(CInterfaceManager interfaces, CSettingManager settings)
{
    private const decimal ToleranceValueMm = 0.03m;
    public const double ToleranceMm = (double)ToleranceValueMm;
    public const string PositionId = "MOTOR_STAGE_Y_CUR_POS";
    public const string BusyId = "MOTOR_STAGE_Y_BUSY";

    public ST_STAGE_READY_POSITION_RESULT Evaluate()
    {
        var values = interfaces.Melsec.GetCachedSnapshot(out var map);
        var positionRow = map.FirstOrDefault(row => row.Id.Equals(PositionId, StringComparison.OrdinalIgnoreCase));
        var deviceNo = positionRow?.DeviceNo ?? map.FirstOrDefault(row =>
            row.Id.Equals(CStageRequestSequence.StgAble, StringComparison.OrdinalIgnoreCase))?.DeviceNo;
        var device = interfaces.GetInterfaceCommunicationList(EN_EQP_MODULE.Melsec)
            .FirstOrDefault(row => row.Number == deviceNo);
        // Simulation is the MELSEC operating setting, including a simulated offline interface.
        if (device?.IsSimulation == true) return new(true, "MELSEC SIMULATION: Stage Y Ready OK.");
        if (device?.ConnectionState != EN_COMM_STATE.Online) return new(false, "Stage Y MELSEC is offline.");

        var targetText = settings.GetValue(EN_SETTING_TAB.Motor, "STAGE_START_POS_Y");
        if (!double.TryParse(targetText, NumberStyles.Float, CultureInfo.InvariantCulture, out var target) ||
            !double.IsFinite(target) || target < (double)decimal.MinValue || target > (double)decimal.MaxValue)
            throw new InvalidOperationException("Stage Y Start Position setting is missing or invalid.");

        var busyRow = map.FirstOrDefault(row => row.Id.Equals(BusyId, StringComparison.OrdinalIgnoreCase));
        if (!TryNumber(positionRow, values, out var position) || !TryNumber(busyRow, values, out var busy))
            return new(false, "Waiting for valid shared Stage Y position / Busy feedback.");
        if (position < (double)decimal.MinValue || position > (double)decimal.MaxValue)
            return new(false, "Stage Y position is out of range.");
        // Decimal comparison accepts the inclusive 30 µm boundary despite binary floating-point noise.
        var difference = Math.Abs((decimal)position - (decimal)target);
        var ready = difference <= ToleranceValueMm && busy == 0;
        return new(ready, string.Create(CultureInfo.InvariantCulture,
            $"Stage Y Current={position:F4} mm, Setting Target={target:F4} mm, Difference={difference:F4} mm, Tolerance={ToleranceValueMm:F4} mm, Busy={busy}."));
    }

    private static bool TryNumber(ST_MELSEC_MAP_DATA? row,
        IReadOnlyDictionary<string, ST_MELSEC_CACHED_VALUE> values, out double number)
    {
        number = double.NaN;
        if (row is not { Use: true } || row.Access == EN_MELSEC_ACCESS.Write ||
            !values.TryGetValue(row.Id, out var sample) || !sample.IsValid || sample.Value is null) return false;
        try
        {
            var value = Convert.ToDouble(sample.Value, CultureInfo.InvariantCulture);
            number = row.DataType switch
            {
                EN_MELSEC_DATA_TYPE.Word or EN_MELSEC_DATA_TYPE.DWord or EN_MELSEC_DATA_TYPE.Double or EN_MELSEC_DATA_TYPE.Float => value,
                _ => double.NaN
            };
            return double.IsFinite(number);
        }
        catch (Exception exception) when (exception is FormatException or InvalidCastException or OverflowException) { return false; }
    }
}
