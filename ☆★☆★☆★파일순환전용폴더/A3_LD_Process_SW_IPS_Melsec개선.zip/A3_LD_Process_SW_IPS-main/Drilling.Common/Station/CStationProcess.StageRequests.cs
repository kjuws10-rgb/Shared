﻿using Drilling.Common.Automation;
using Drilling.Common.Interface;

namespace Drilling.Common.Station;

public sealed record ST_STAGE_PROCESS_REQUEST(string ProcessId, string RecipeId, string GlassId, string LotId, IReadOnlyDictionary<string, string> Parameters);

public sealed partial class CStationProcess
{
    public CStageRequestSequence StageRequests { get; }
    private readonly System.Collections.Concurrent.ConcurrentDictionary<(int Controller, int Task), ST_HEAD_SCRIPT_RESULT> _stageOwnedTasks = new();
    private readonly System.Collections.Concurrent.ConcurrentDictionary<int, CStageBufferedRun> _stageBufferedRuns = new();

    private CStageRequestSequence CreateStageRequestSequence() => new(
        () =>
        {
            var cache = _interfaceManager.Melsec.GetCachedSnapshot(out var map);
            var required = new[] { CStageRequestSequence.StgAble, CStageRequestSequence.StgStart, CStageRequestSequence.StgComplete,
                CStageRequestSequence.PrcAble, CStageRequestSequence.PrcStart, CStageRequestSequence.PrcComplete };
            var rows = required.Select(id => map.FirstOrDefault(row => row.Use && row.Id.Equals(id, StringComparison.OrdinalIgnoreCase))).ToArray();
            var devices = _interfaceManager.GetInterfaceCommunicationList(EN_EQP_MODULE.Melsec);
            var connected = rows.All(row => row is not null && devices.Any(device => device.Number == row.DeviceNo &&
                (device.IsSimulation || device.ConnectionState == EN_COMM_STATE.Online)));
            return new(connected, cache);
        },
        (id, value, token) => Task.Run(() => _interfaceManager.Melsec.WriteWord(id, value, token), token),
        _sequenceActions, message => AddProcessLog("INFO", "STAGE_SEQUENCE", message), StopStageTasks, CheckStageBufferedRuns,
        VerifyStageReadyPosition, WaitStageMachining, SaveStageProcessResults, ReleaseCompletedStageTasks);

    private async Task VerifyStageReadyPosition(CancellationToken token)
    {
        if (ReadIntAny(GetProcessModel().Parameters, 0, "ZERO_DEFENCE_REVIEW_POINT") > 0)
            throw new NotSupportedException("0-line inspection coordinator is not connected yet. Process COMPLETE cannot be reported for an unperformed inspection.");
        var check = new CStageReadyPositionCheck(_interfaceManager, _settingManager);
        while (true)
        {
            token.ThrowIfCancellationRequested();
            CheckStageBufferedRuns();
            var result = check.Evaluate();
            if (result.IsReady)
            {
                AddProcessLog("INFO", "STAGE_READY", result.Detail);
                return;
            }
            await Task.Delay(50, token).ConfigureAwait(false);
        }
    }

    public void StartStageRequests(Func<CancellationToken, Task<ST_STAGE_PROCESS_REQUEST>> request, ST_STAGE_REVIEW_ACTIONS? review = null)
    {
        lock (_sequenceLock)
        {
            if (_manualMofRunning || _manualMofRequiresStop) throw new InvalidOperationException("Manual MOF is active or requires STOP.");
            if (SequenceState != EN_STATION_SEQUENCE.Ready) throw new InvalidOperationException("Station must be Ready before AUTO request monitoring.");
            if (!_stageOwnedTasks.IsEmpty || !_stageBufferedRuns.IsEmpty) throw new InvalidOperationException("Previous AUTO Tasks have not been confirmed stopped.");
            StageRequests.Start(async token =>
            {
                var data = await request(token).ConfigureAwait(false);
                var parameters = new Dictionary<string, string>(data.Parameters, StringComparer.OrdinalIgnoreCase);
                PrepareProcess(data.ProcessId, data.RecipeId, data.GlassId, data.LotId, parameters, token, preserveSequenceActions: true);
                // TODO: Prepare the recipe's per-head 0-line Shot / Beam plan here.
                // The 0.05 map's IOF count / packed Y-X transfer belongs to Process preparation;
                // wire it when the 0-line coordinator and Run Options are implemented.
            }, token => Task.Run(() =>
            {
                var model = GetProcessModel();
                BuildAutomationScript(model, token);
                UploadAutomationScript(model, token);
                token.ThrowIfCancellationRequested();
                // DoReady uploads only. MOF zero and Task RUN execute after DoReady signal reset,
                // in Process preparation, once Stage Ready position and Busy OFF are verified.
            }, token), token =>
            {
                var model = GetProcessModel();
                var targets = model.HeadPlans.Select(head => new ST_MOF_ZERO_TARGET(head.AutomationNo, head.TaskNo,
                    ReadTextAny(model.Parameters, ReadTextAny(model.Parameters, "GX", CreateHeadKeys(head.HeadNo, "X_AXIS")),
                        CreateHeadKeys(head.HeadNo, "ENCODER_AXIS"))));
                return _automationManager.ZeroMofFeedbackIfNeeded(targets, token);
            }, RunStageTasks, review);
        }
    }

    private async Task RunStageTasks(CancellationToken token)
    {
        _stageMachiningCompleted = false;
        if (_lastScript is null) throw new InvalidOperationException("No prepared scripts.");
        var heads = _lastScript.HeadScripts.Where(head => head.TotalShots > 0).ToArray();
        if (heads.Length == 0) throw new InvalidOperationException("No USE head machining scripts.");
        if (heads.GroupBy(head => (head.AutomationNo, head.TaskNo)).Any(group => group.Count() != 1))
            throw new InvalidOperationException("USE heads must have distinct controller / Task assignments.");
        var readyRunId = _lastScript.MofReadyRunId;
        if (readyRunId <= 0) throw new InvalidOperationException("Prepared scripts have no MOF readiness run ID. Rebuild the scripts before RUN.");
        var buffered = IsBufferedRunEnabled(GetProcessModel().Parameters);
        // Reset every controller-local slot before starting any queue. A write must never wait behind a running queue.
        foreach (var head in heads)
            await _automationManager.PrepareMofReadiness(head.TaskNo, head.AutomationNo, readyRunId, token).ConfigureAwait(false);
        foreach (var head in heads)
        {
            token.ThrowIfCancellationRequested();
            // Register before issuing: a lost acknowledgement can follow an accepted RUN.
            _stageOwnedTasks[(head.AutomationNo, head.TaskNo)] = head;
            _automationManager.StatusSnapshots.InvalidateTask(head.TaskNo, head.AutomationNo);
            if (!buffered)
                await _automationManager.RunStagePreparedScript(head.FileName, head.TaskNo, head.AutomationNo, token).ConfigureAwait(false);
        }
        if (buffered)
        {
            var parameters = GetProcessModel().Parameters;
            foreach (var group in heads.GroupBy(head => head.AutomationNo))
            {
                token.ThrowIfCancellationRequested();
                var controller = group.Key;
                var scripts = group.Select(head => new ST_BUFFERED_SCRIPT_RUN_ITEM(head.FilePath, head.FileName, head.TaskNo)).ToArray();
                // This lifetime must outlive Process preparation's RUN-verification action token.
                // STOP owns cancellation and retains the session until its queue worker finishes.
                var stop = new CancellationTokenSource();
                var run = new CStageBufferedRun(stop);
                if (!_stageBufferedRuns.TryAdd(controller, run))
                {
                    stop.Dispose();
                    throw new InvalidOperationException($"Buffered group already exists: Automation1 #{controller}.");
                }
                run.Completion = Task.Run(() => _automationManager.RunStagePreparedBufferedScripts(scripts, controller,
                    ReadBufferedRunQueueSize(parameters), ReadBufferedRunLinesPerCommand(parameters), ReadBufferedRunTimeoutMs(parameters), stop.Token));
                AddProcessLog("INFO", "A1_RUN", $"Stage buffered group started. Automation1 #{controller}, Tasks={string.Join(",", scripts.Select(script => script.TaskIndex))}");
            }
        }
        using var limit = CancellationTokenSource.CreateLinkedTokenSource(token);
        limit.CancelAfter(TimeSpan.FromSeconds(15));
        while (true)
        {
            if (limit.IsCancellationRequested && !token.IsCancellationRequested)
                throw new TimeoutException("MOF 준비 완료 확인 시간이 초과되었습니다. Task 실행 상태와 이번 실행번호가 15초 이내에 확인되지 않았습니다.");
            limit.Token.ThrowIfCancellationRequested();
            CheckStageBufferedRuns();
            var allRunning = true;
            foreach (var head in heads)
            {
                var ready = _automationManager.StatusSnapshots.GetMofReadiness(head.TaskNo, head.AutomationNo);
                if (ready.State is "ERROR" or "OFFLINE" or "STOPPED")
                    throw new InvalidOperationException($"MOF readiness unavailable: H{head.HeadNo:00}. {ready.Detail}");
                var sample = _automationManager.StatusSnapshots.GetTask(head.TaskNo, head.AutomationNo);
                if (sample.State is "ERROR" or "OFFLINE" or "STOPPED") throw new InvalidOperationException($"Task status unavailable: H{head.HeadNo:00}. {sample.Detail}");
                if (sample.State != "OK" || sample.Value is null) { allRunning = false; continue; }
                var status = ParseAutomationTaskStatus(sample.Value);
                if (IsAutomationTaskFailed(status.State)) throw new InvalidOperationException($"Task failed: H{head.HeadNo:00}. {sample.Value}");
                // Command queues may report QueueRunning rather than ProgramRunning.
                // A ProgramRunning sample must include this queue's status, not a previous ordinary program.
                var running = buffered
                    ? status.State.Equals("QueueRunning", StringComparison.OrdinalIgnoreCase) ||
                      (status.State.Equals("ProgramRunning", StringComparison.OrdinalIgnoreCase) && status.ErrorMessage.StartsWith("QueueEmpty=", StringComparison.Ordinal))
                    : status.State.Equals("ProgramRunning", StringComparison.OrdinalIgnoreCase);
                allRunning &= status.TaskNo == head.TaskNo && running && ready.State == "OK" && ready.Value?.RunId == readyRunId;
            }
            if (allRunning)
            {
                AddProcessLog("INFO", "MOF_READY", $"All participating Tasks initialized for RunId={readyRunId}. Heads={string.Join(",", heads.Select(head => head.HeadNo))}");
                return;
            }
            await Task.Delay(50, token).ConfigureAwait(false);
        }
    }

    private async Task StopStageTasks(CancellationToken token)
    {
        // End command queues before issuing ordinary task/laser commands on the same controller.
        foreach (var run in _stageBufferedRuns.Values) run.Stop.Cancel();
        foreach (var pair in _stageBufferedRuns.ToArray())
        {
            var run = pair.Value;
            try { await run.Completion.WaitAsync(token).ConfigureAwait(false); }
            catch (Exception exception) when (run.Completion.IsCompleted)
            {
                // Execution failure is already exposed by CheckStageBufferedRuns; cleanup still stops all owned Tasks.
                if (exception is not OperationCanceledException)
                    AddProcessLog("WARN", "A1_RUN", $"Buffered group ended with an error. Automation1 #{pair.Key}: {exception.Message}");
            }
            finally
            {
                if (run.Completion.IsCompleted && _stageBufferedRuns.TryRemove(pair.Key, out _)) run.Stop.Dispose();
            }
        }
        var errors = new List<Exception>();
        foreach (var pair in _stageOwnedTasks.ToArray())
        {
            try
            {
                await _automationManager.StopStagePreparedTask(pair.Key.Task, pair.Key.Controller, token).ConfigureAwait(false);
                var model = GetProcessModel();
                var x = ReadTextAny(model.Parameters, "GX", CreateHeadKeys(pair.Value.HeadNo, "X_AXIS"));
                var laser = ReadTextAny(model.Parameters, x, CreateHeadKeys(pair.Value.HeadNo, "LASER_AXIS"));
                await _automationManager.SetGalvoLaserOutput(laser, false, pair.Key.Task, pair.Key.Controller, token).ConfigureAwait(false);
                _stageOwnedTasks.TryRemove(pair.Key, out _);
            }
            catch (Exception exception) { errors.Add(exception); }
        }
        if (errors.Count != 0) throw new AggregateException("AUTO Task stop failed.", errors);
    }

    private void CheckStageBufferedRuns()
    {
        foreach (var pair in _stageBufferedRuns)
        {
            if (!pair.Value.Completion.IsCompleted) continue;
            try
            {
                var response = pair.Value.Completion.GetAwaiter().GetResult();
                if (!IsProcessControlSuccessResponse(response) &&
                    !(response.StartsWith("SIM:", StringComparison.OrdinalIgnoreCase) && response.EndsWith(":OK", StringComparison.OrdinalIgnoreCase)))
                    throw new InvalidOperationException(response);
            }
            catch (Exception exception)
            {
                var error = new InvalidOperationException($"Buffered run failed. Automation1 #{pair.Key}: {exception.Message}", exception);
                var action = _sequenceActions.GetSnapshot().GetValueOrDefault(CSequenceActionIds.ProcessMachining)?.State == EN_SEQUENCE_ACTION_STATE.Running
                    ? CSequenceActionIds.ProcessMachining : CSequenceActionIds.ProcessTaskRun;
                if (!_manualMofRunning) _sequenceActions.SetError(action, error.Message);
                throw error;
            }
        }
    }

    private sealed class CStageBufferedRun(CancellationTokenSource stop)
    {
        public CancellationTokenSource Stop { get; } = stop;
        public Task<string> Completion { get; set; } = Task.FromResult("OK:STARTING");
    }

}
