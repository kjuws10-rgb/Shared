using System.Globalization;
using Drilling.Common.Automation;
using Drilling.Common.Interface;
using Drilling.Common.InterLock;
using Drilling.Common.Motion;

namespace Drilling.Common.Station;

public sealed record ST_MANUAL_MOF_STATUS(bool IsRunning, bool RequiresStop, string Message,
    string ScriptDirectory, IReadOnlyDictionary<string, ST_SEQUENCE_ACTION_STATUS> Actions);

public static class CManualMofActionIds
{
    public static readonly string[] All = ["PREPARE", "BUILD", "UPLOAD", "ZERO", "RUN", "SCAN", "COMPLETE"];
}

public sealed partial class CStationProcess
{
    private readonly CSequenceActionStatusStore _manualMofActions = new();
    private CancellationTokenSource? _manualMofCancellation;
    private Task _manualMofExecution = Task.CompletedTask;
    private bool _manualMofRunning;
    private bool _manualMofRequiresStop;
    private string _manualMofMessage = "";
    private string _manualMofDirectory = "";

    public ST_MANUAL_MOF_STATUS ManualMofStatus
    {
        get
        {
            lock (_sequenceLock) return new(_manualMofRunning, _manualMofRequiresStop,
                _manualMofMessage, _manualMofDirectory, _manualMofActions.GetSnapshot());
        }
    }

    public Task RunManualMofAsync(ST_STAGE_PROCESS_REQUEST request, IReadOnlySet<int> selectedHeads,
        CancellationToken token = default)
    {
        var heads = selectedHeads.Where(head => head is >= 1 and <= 8).ToHashSet();
        if (heads.Count == 0) throw new InvalidOperationException("Head를 선택해 주세요.");
        var frozen = request with { Parameters = new Dictionary<string, string>(request.Parameters, StringComparer.OrdinalIgnoreCase) };
        lock (_sequenceLock)
        {
            if (_manualMofRunning || _manualMofRequiresStop || StageRequests.IsRunning ||
                _sequenceState != EN_STATION_SEQUENCE.Ready || !_stageOwnedTasks.IsEmpty || !_stageBufferedRuns.IsEmpty)
                throw new InvalidOperationException("다른 가공이 실행 중이거나 정지가 확인되지 않았습니다.");
            token.ThrowIfCancellationRequested();
            _manualMofCancellation?.Dispose();
            _manualMofCancellation = CancellationTokenSource.CreateLinkedTokenSource(token);
            _manualMofRunning = true;
            _manualMofMessage = "MOF 준비 중";
            _manualMofDirectory = "";
            _manualMofActions.ResetToWaiting(CManualMofActionIds.All);
            var runToken = _manualMofCancellation.Token;
            _manualMofExecution = Task.Run(() => ExecuteManualMof(frozen, heads, runToken));
            return _manualMofExecution;
        }
    }

    public Task StopManualMofAsync()
    {
        lock (_sequenceLock)
        {
            if (_manualMofRunning)
            {
                _manualMofCancellation?.Cancel();
                return ObserveManualMofStop(_manualMofExecution);
            }
            if (!_manualMofRequiresStop) return Task.CompletedTask;
            _manualMofRunning = true;
            return _manualMofExecution = Task.Run(async () =>
            {
                try
                {
                    using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(15));
                    await StopStageTasks(timeout.Token).ConfigureAwait(false);
                    lock (_sequenceLock) { _manualMofRequiresStop = false; _sequenceState = EN_STATION_SEQUENCE.Ready; _manualMofMessage = "MOF 정지 완료"; }
                }
                finally { lock (_sequenceLock) _manualMofRunning = false; }
            });
        }
    }

    private static async Task ObserveManualMofStop(Task execution)
    {
        try { await execution.ConfigureAwait(false); }
        catch (OperationCanceledException) { }
    }

    private async Task ExecuteManualMof(ST_STAGE_PROCESS_REQUEST request, HashSet<int> heads, CancellationToken token)
    {
        CManualStageMotionSimulation? simulation = null;
        CManualStageMotionSimulation.MotionLease? stage = null;
        var success = false;
        var cancelled = false;
        var message = "";
        try
        {
            double start = 0, target = 0, speed = 0;
            await _manualMofActions.RunAsync("PREPARE", async () =>
            {
                PrepareProcessCore(request.ProcessId, request.RecipeId, request.GlassId, request.LotId,
                    request.Parameters, token, preserveSequenceActions: true, manualHeads: heads);
                SetSequenceState(EN_STATION_SEQUENCE.Process);
                var model = GetProcessModel();
                if (model.HeadPlans.Count == 0 || !model.HeadPlans.Any(head => head.Shots.Count > 0))
                    throw new InvalidOperationException("선택한 Head에 가공할 Shot이 없습니다.");
                CheckManualMofInterlocks(model, heads, token);
                EnsureManualMofStageSimulation();
                await CheckManualMofTasksIdle(model, token).ConfigureAwait(false);
                simulation = _interfaceManager.GetStageMotionSimulation();
                stage = simulation.AcquireExclusiveMotion();
                start = simulation.GetSnapshot().Single(axis => axis.Axis == EN_MANUAL_STAGE_AXIS.StageY).Position;
                var length = ReadRequiredManualMofNumber(model.Parameters, "GLASS_SIZE_Y");
                speed = ReadRequiredManualMofNumber(model.Parameters, "STAGE_SPEED");
                var direction = ReadRequiredManualMofNumber(model.Parameters, "STAGE_SCAN_DIRECTION_Y");
                if (length <= 0 || speed <= 0 || direction is not (-1 or 1))
                    throw new InvalidOperationException("Glass Size Y와 Stage Speed는 0보다 커야 하며 Stage Direction은 -1 또는 1이어야 합니다.");
                target = start + length * direction;
                if (!double.IsFinite(target) || !double.IsFinite(length / speed))
                    throw new InvalidOperationException("Stage 목표 위치 또는 이동 시간을 확인해 주세요.");
                AddProcessLog("INFO", "MANUAL_MOF", $"Stage simulation: {start:F3} -> {target:F3} mm, {speed:F3} mm/sec; Heads={string.Join(",", heads.Order())}");
            }).ConfigureAwait(false);
            var model = GetProcessModel();
            await _manualMofActions.RunAsync("BUILD", () =>
            {
                token.ThrowIfCancellationRequested();
                var mode = IsBufferedRunEnabled(model.Parameters) ? "Buffered" : "Standard";
                _lastScript = _automationScriptFile.Build(model, Path.Combine("ManualMOF", mode), token);
                _scriptCreatedAt = _lastScript.CreatedAt;
                lock (_sequenceLock) _manualMofDirectory = Path.GetDirectoryName(_lastScript.FilePath) ?? "";
                return Task.CompletedTask;
            }).ConfigureAwait(false);
            await _manualMofActions.RunAsync("UPLOAD", () =>
            {
                UploadAutomationScript(model, token);
                return Task.CompletedTask;
            }).ConfigureAwait(false);
            await _manualMofActions.RunAsync("ZERO", async () =>
            {
                CheckManualMofInterlocks(model, heads, token);
                var targets = model.HeadPlans.Select(head => new ST_MOF_ZERO_TARGET(head.AutomationNo, head.TaskNo,
                    ReadTextAny(model.Parameters, ReadTextAny(model.Parameters, "GX", CreateHeadKeys(head.HeadNo, "X_AXIS")),
                        CreateHeadKeys(head.HeadNo, "ENCODER_AXIS"))));
                await _automationManager.ZeroMofFeedbackIfNeeded(targets, token).ConfigureAwait(false);
            }).ConfigureAwait(false);
            await _manualMofActions.RunAsync("RUN", () => RunStageTasks(token)).ConfigureAwait(false);
            await _manualMofActions.RunAsync("SCAN", async () =>
            {
                token.ThrowIfCancellationRequested();
                EnsureManualMofStageSimulation();
                var current = simulation!.GetSnapshot().Single(axis => axis.Axis == EN_MANUAL_STAGE_AXIS.StageY);
                if (current.Speed != 0 || Math.Abs(current.Position - start) > 0.001)
                    throw new InvalidOperationException("준비 중 Stage 위치가 변경되었습니다. 다시 실행해 주세요.");
                stage!.Move(EN_MANUAL_STAGE_AXIS.StageY, target, speed);
                using var scan = CancellationTokenSource.CreateLinkedTokenSource(token);
                var move = WaitManualMofStage(simulation, target, Math.Abs(target - start) / speed, scan.Token);
                var machining = WaitStageMachining(scan.Token);
                var first = await Task.WhenAny(move, machining).ConfigureAwait(false);
                if (!first.IsCompletedSuccessfully) scan.Cancel();
                try { await Task.WhenAll(move, machining).ConfigureAwait(false); }
                catch { scan.Cancel(); throw; }
            }).ConfigureAwait(false);
            await _manualMofActions.RunAsync("COMPLETE", () => ReleaseCompletedStageTasks(token)).ConfigureAwait(false);
            success = true;
            message = "MOF 가공 완료";
        }
        catch (Exception exception)
        {
            cancelled = exception is OperationCanceledException && token.IsCancellationRequested;
            message = cancelled ? "MOF 정지" : $"MOF 실패: {exception.Message}";
            // MOF cancellation/failure stops only our Tasks/queues. An accepted Stage
            // move continues; the operator's separate Stage STOP remains available.
            try
            {
                using var stop = new CancellationTokenSource(TimeSpan.FromSeconds(15));
                await StopStageTasks(stop.Token).ConfigureAwait(false);
            }
            catch (Exception stopError) { message += $" / Task 정지 확인 실패: {stopError.Message}"; }
            AddProcessLog(cancelled ? "WARN" : "ERROR", "MANUAL_MOF", message);
            if (cancelled) throw new OperationCanceledException(message, exception, token);
            throw new InvalidOperationException(message, exception);
        }
        finally
        {
            stage?.Dispose();
            var result = new ST_PROCESS_RESULT(success, message, DateTimeOffset.Now);
            _snapshot = CreateSnapshot(_processModel, SetHeadStatus(_snapshot.HeadPreviews,
                success ? EN_PROCESS_STEP.Completed : cancelled ? EN_PROCESS_STEP.Stopped : EN_PROCESS_STEP.Error),
                success ? EN_SCRIPT_STATUS.Completed : EN_SCRIPT_STATUS.Error,
                success ? EN_PROCESS_STEP.Completed : cancelled ? EN_PROCESS_STEP.Stopped : EN_PROCESS_STEP.Error, result);
            SetStationState(success ? EN_STATION_STATE.Complete : cancelled ? EN_STATION_STATE.Stopped : EN_STATION_STATE.Alarm,
                _snapshot.ProcessStep, _snapshot.ScriptStatus, message);
            lock (_sequenceLock)
            {
                _manualMofRunning = false;
                _manualMofRequiresStop = !_stageOwnedTasks.IsEmpty || !_stageBufferedRuns.IsEmpty;
                _manualMofMessage = message;
                _sequenceState = _manualMofRequiresStop ? EN_STATION_SEQUENCE.Error : EN_STATION_SEQUENCE.Ready;
            }
        }
    }

    private void CheckManualMofInterlocks(ST_PROCESS_MODEL model, IReadOnlySet<int> heads, CancellationToken token)
    {
        token.ThrowIfCancellationRequested();
        var items = GetManualInterlockItems(model.Parameters, heads, token);
        if (items.Count == 0 || items.Any(item => item.Level != EN_INTERLOCK_LEVEL.Ok || item.BlocksAutoRun))
            throw new InvalidOperationException("Interlock/Safety를 확인해 주세요.");
    }

    private async Task CheckManualMofTasksIdle(ST_PROCESS_MODEL model, CancellationToken token)
    {
        var targets = model.HeadPlans.Where(head => head.Shots.Count > 0).ToArray();
        if (targets.GroupBy(head => (head.AutomationNo, head.TaskNo)).Any(group => group.Count() > 1))
            throw new InvalidOperationException("선택한 Head의 Controller / Task 할당이 중복되었습니다.");
        var deadline = DateTimeOffset.UtcNow.AddSeconds(5);
        while (true)
        {
            token.ThrowIfCancellationRequested();
            var ready = true;
            foreach (var head in targets)
            {
                var sample = _automationManager.StatusSnapshots.GetTask(head.TaskNo, head.AutomationNo);
                if (sample.State is "ERROR" or "OFFLINE" or "STOPPED")
                    throw new InvalidOperationException($"HEAD {head.HeadNo:00} Task 상태를 확인할 수 없습니다. {sample.Detail}");
                if (sample.State != "OK" || sample.Value is null) { ready = false; continue; }
                var task = ParseAutomationTaskStatus(sample.Value);
                if (task.TaskNo != head.TaskNo || task.State.ToUpperInvariant() is not
                    ("IDLE" or "PROGRAMREADY" or "PROGRAMCOMPLETE" or "PROGRAMSTOPPED" or "QUEUECOMPLETE" or "STOPPED" or "READY"))
                    throw new InvalidOperationException($"HEAD {head.HeadNo:00}의 Task가 실행 가능한 대기 상태가 아닙니다. {task.State}");
            }
            if (ready) return;
            if (DateTimeOffset.UtcNow >= deadline) throw new TimeoutException("Task 대기 상태 확인 시간이 초과되었습니다.");
            await Task.Delay(50, token).ConfigureAwait(false);
        }
    }

    private void EnsureManualMofStageSimulation()
    {
        var deviceNo = _interfaceManager.Melsec.Map.FirstOrDefault(row => row.Id.Equals("MOTOR_STAGE_Y_CUR_POS", StringComparison.OrdinalIgnoreCase))?.DeviceNo
            ?? _interfaceManager.GetInterfaceList(EN_EQP_MODULE.Melsec).FirstOrDefault()?.Number;
        var device = _interfaceManager.GetInterfaceCommunicationList(EN_EQP_MODULE.Melsec).FirstOrDefault(item => item.Number == deviceNo);
        if (device?.IsSimulation == true) return;
        throw new InvalidOperationException(device?.ConnectionState == EN_COMM_STATE.Online
            ? "Stage Y 실제 이동 명령 주소가 아직 설정되지 않았습니다. 현재 MOF Stage 이동은 MELSEC 시뮬레이션에서 지원합니다."
            : "MELSEC이 연결되어 있지 않습니다.");
    }

    private async Task WaitManualMofStage(CManualStageMotionSimulation simulation, double target, double seconds, CancellationToken token)
    {
        var started = System.Diagnostics.Stopwatch.GetTimestamp();
        while (true)
        {
            token.ThrowIfCancellationRequested();
            EnsureManualMofStageSimulation();
            CheckStageBufferedRuns();
            var axis = simulation.GetSnapshot().Single(item => item.Axis == EN_MANUAL_STAGE_AXIS.StageY);
            if (axis.Speed == 0)
            {
                if (Math.Abs(axis.Position - target) <= 0.001) return;
                throw new InvalidOperationException("Stage가 목표 위치에 도달하기 전에 정지했습니다.");
            }
            if (System.Diagnostics.Stopwatch.GetElapsedTime(started).TotalSeconds >= seconds + 15)
                throw new TimeoutException("Stage Y 이동 완료 확인 시간이 초과되었습니다.");
            await Task.Delay(50, token).ConfigureAwait(false);
        }
    }

    private static double ReadRequiredManualMofNumber(IReadOnlyDictionary<string, string> parameters, string key)
    {
        if (!parameters.TryGetValue(key, out var text) || !double.TryParse(text, NumberStyles.Float,
                CultureInfo.InvariantCulture, out var value) || !double.IsFinite(value))
            throw new InvalidOperationException($"{key} 설정값을 확인해 주세요.");
        return value;
    }
}
