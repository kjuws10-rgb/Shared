using System.Globalization;
using System.Text;
using Drilling.Common.Automation;

namespace Drilling.Common.Station;

public sealed partial class CStationProcess
{
    private bool _stageMachiningCompleted;

    private async Task WaitStageMachining(CancellationToken token)
    {
        var heads = _stageOwnedTasks.Values.OrderBy(head => head.HeadNo).ToArray();
        if (heads.Length == 0) throw new InvalidOperationException("No Tasks owned by the current Process request.");
        var model = GetProcessModel();
        var buffered = IsBufferedRunEnabled(model.Parameters);
        var timeoutMs = buffered ? ReadBufferedRunTimeoutMs(model.Parameters) : ReadScriptRunTimeoutMs(model.Parameters);
        using var limit = CancellationTokenSource.CreateLinkedTokenSource(token);
        if (timeoutMs > 0) limit.CancelAfter(timeoutMs);
        _snapshot = CreateSnapshot(model, SetHeadStatus(_snapshot.HeadPreviews, EN_PROCESS_STEP.Process),
            EN_SCRIPT_STATUS.Running, EN_PROCESS_STEP.Process, null);
        SetStationState(EN_STATION_STATE.Process, EN_PROCESS_STEP.Process, EN_SCRIPT_STATUS.Running, "Stage Process START acknowledged.");
        // No second RUN. Real Tasks already execute from Process preparation; only simulated controllers get a virtual clock.
        _automationManager.StartStageMachiningSimulation(heads.Select(head =>
            new ST_STAGE_TASK_SIMULATION_TARGET(head.HeadNo, head.AutomationNo, head.TaskNo)).ToArray(), limit.Token);
        var completed = new HashSet<(int Controller, int Task)>();
        try
        {
            while (completed.Count < heads.Length)
            {
                limit.Token.ThrowIfCancellationRequested();
                CheckStageBufferedRuns();
                foreach (var head in heads)
                {
                    var key = (head.AutomationNo, head.TaskNo);
                    if (completed.Contains(key)) continue;
                    var sample = _automationManager.StatusSnapshots.GetTask(head.TaskNo, head.AutomationNo);
                    if (sample.State is "ERROR" or "OFFLINE" or "STOPPED")
                        throw new InvalidOperationException($"Task feedback unavailable: H{head.HeadNo:00}. {sample.Detail}");
                    if (sample.State != "OK" || sample.Value is null) continue;
                    var status = ParseAutomationTaskStatus(sample.Value);
                    if (status.TaskNo != head.TaskNo) throw new InvalidOperationException("Task feedback identity mismatch.");
                    if (IsAutomationTaskFailed(status.State) || status.State.Equals("Stopped", StringComparison.OrdinalIgnoreCase))
                        throw new InvalidOperationException($"Task did not finish normally: H{head.HeadNo:00}. {sample.Value}");
                    // An ordinary Idle is never sufficient evidence of a successful program end.
                    var done = status.State.Equals("ProgramComplete", StringComparison.OrdinalIgnoreCase);
                    if (buffered)
                    {
                        var groupComplete = _stageBufferedRuns.TryGetValue(head.AutomationNo, out var group) && group.Completion.IsCompletedSuccessfully;
                        done = _automationManager.IsSimul(head.AutomationNo)
                            ? groupComplete && status.State.Equals("QueueComplete", StringComparison.OrdinalIgnoreCase)
                            : groupComplete; // Includes the communication owner's drain + queue cleanup acknowledgement.
                    }
                    if (!done) continue;
                    completed.Add(key);
                    AddProcessLog("INFO", "STAGE_PROCESS", $"H{head.HeadNo:00} normal completion. A{head.AutomationNo}/T{head.TaskNo}, State={status.State}, Simulation={_automationManager.IsSimul(head.AutomationNo)}");
                }
                if (completed.Count < heads.Length) await Task.Delay(50, limit.Token).ConfigureAwait(false);
            }
            _stageMachiningCompleted = true;
            _scriptCompletedAt = DateTimeOffset.Now;
            _snapshot = CreateSnapshot(model, SetHeadStatus(_snapshot.HeadPreviews, EN_PROCESS_STEP.Completed),
                EN_SCRIPT_STATUS.Completed, EN_PROCESS_STEP.Process, null);
        }
        catch (OperationCanceledException) when (!token.IsCancellationRequested && limit.IsCancellationRequested)
        {
            throw new TimeoutException($"Process machining timeout. TimeoutMs={timeoutMs}.");
        }
    }

    private Task SaveStageProcessResults(CancellationToken token) => Task.Run(() =>
    {
        token.ThrowIfCancellationRequested();
        if (!_stageMachiningCompleted) throw new InvalidOperationException("Machining has not completed normally.");
        var model = GetProcessModel();
        var now = DateTimeOffset.Now;
        var heads = _stageOwnedTasks.Values.OrderBy(head => head.HeadNo).ToArray();
        var directory = Path.Combine(_logManager?.LogDirectory ?? Path.Combine(AppContext.BaseDirectory, "Log"),
            "Station", now.ToString("yyyyMMdd", CultureInfo.InvariantCulture));
        Directory.CreateDirectory(directory);
        var path = Path.Combine(directory, $"ProcessResult_{now:yyyyMMdd_HHmmss_fffffff}.csv");
        static string Field(string text) => "\"" + text.Replace("\"", "\"\"", StringComparison.Ordinal) + "\"";
        var lines = new List<string> { "Process ID,Recipe ID,Glass ID,Head,Automation,Task,Simulation,Result,Completed At" };
        lines.AddRange(heads.Select(head => string.Join(",", new[] { model.ProcessId, model.RecipeId, model.GlassId,
            $"HEAD {head.HeadNo:00}", head.AutomationNo.ToString(CultureInfo.InvariantCulture), head.TaskNo.ToString(CultureInfo.InvariantCulture),
            _automationManager.IsSimul(head.AutomationNo) ? "SIMULATION" : "ONLINE", "OK", now.ToString("O", CultureInfo.InvariantCulture) }.Select(Field))));
        System.IO.File.WriteAllLines(path, lines, new UTF8Encoding(true));
        token.ThrowIfCancellationRequested();
        var simulation = heads.Any(head => _automationManager.IsSimul(head.AutomationNo));
        var result = new ST_PROCESS_RESULT(true, simulation ? "Stage Process completed (includes simulated Tasks)." : "Stage Process completed.", now,
            simulation ? "SIMULATION" : "OK");
        CompleteProduct(result, true, token);
        ReportProcessResult(result, "COMPLETE", token, EN_STATION_STATE.Complete);
        _snapshot = CreateSnapshot(model, SetHeadStatus(_snapshot.HeadPreviews, EN_PROCESS_STEP.Completed),
            EN_SCRIPT_STATUS.Completed, EN_PROCESS_STEP.Completed, result);
        AddProcessLog("INFO", "STAGE_PROCESS", $"Process result saved: {path}");
    }, token);

    private async Task ReleaseCompletedStageTasks(CancellationToken token)
    {
        if (!_stageMachiningCompleted) throw new InvalidOperationException("Cannot release unfinished Process Tasks.");
        foreach (var pair in _stageBufferedRuns.ToArray())
        {
            await pair.Value.Completion.WaitAsync(token).ConfigureAwait(false);
            if (_stageBufferedRuns.TryRemove(pair.Key, out _)) pair.Value.Stop.Dispose();
        }
        _stageOwnedTasks.Clear();
        // Preserve DONE feedback. Do not issue STOP, rerun Tasks or change laser-device state on normal completion.
    }
}
