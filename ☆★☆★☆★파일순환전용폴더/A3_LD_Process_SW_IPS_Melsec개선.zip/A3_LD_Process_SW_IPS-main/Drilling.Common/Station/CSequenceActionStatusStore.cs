namespace Drilling.Common.Station;

public enum EN_SEQUENCE_ACTION_STATE { Waiting, Running, Completed, Error, Stopped }

public sealed record ST_SEQUENCE_ACTION_STATUS(string Id, EN_SEQUENCE_ACTION_STATE State, string Detail = "");

public static class CSequenceActionIds
{
    public const string PrepareData = "DOREADY_DATA_PREPARE";
    public const string BuildUploadScript = "DOREADY_SCRIPT_BUILD_UPLOAD";
    public const string DoReadySignalsClear = "DOREADY_SIGNALS_CLEAR";
    public const string ProcessReadyPosition = "PROCESS_READY_POSITION";
    public const string ProcessMofZero = "PROCESS_MOF_ZERO";
    public const string ProcessTaskRun = "PROCESS_TASK_RUN";
    public const string ProcessMachining = "PROCESS_MACHINING_INSPECTION";
    public const string ProcessResults = "PROCESS_RESULTS";
    public const string ProcessSignalsClear = "PROCESS_SIGNALS_CLEAR";
    public const string ReviewPlan = "REVIEW_PLAN";
    public const string ReviewMeasure = "REVIEW_MEASURE";
    public const string ReviewResults = "REVIEW_RESULTS";
    public const string ReviewSignalsClear = "REVIEW_SIGNALS_CLEAR";
}

/// <summary>In-memory execution feedback. Never holds its lock while an action executes.</summary>
public sealed class CSequenceActionStatusStore
{
    private readonly object _sync = new();
    private readonly Dictionary<string, (long Run, ST_SEQUENCE_ACTION_STATUS Status)> _states = new(StringComparer.OrdinalIgnoreCase);
    private long _run;

    public IReadOnlyDictionary<string, ST_SEQUENCE_ACTION_STATUS> GetSnapshot()
    {
        lock (_sync) return _states.ToDictionary(pair => pair.Key, pair => pair.Value.Status, StringComparer.OrdinalIgnoreCase);
    }

    public void Reset()
    {
        lock (_sync) _states.Clear();
    }

    public void ResetToWaiting(IEnumerable<string> ids)
    {
        ArgumentNullException.ThrowIfNull(ids);
        var selected = ids.Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
        foreach (var id in selected) ArgumentException.ThrowIfNullOrWhiteSpace(id);
        lock (_sync)
        {
            foreach (var id in selected)
                // A fresh run identity prevents an earlier completion from restoring DONE.
                _states[id] = (++_run, new(id, EN_SEQUENCE_ACTION_STATE.Waiting));
        }
    }

    public void SetError(string id, string detail)
    {
        lock (_sync)
            if (_states.TryGetValue(id, out var entry))
                _states[id] = (entry.Run, new(id, EN_SEQUENCE_ACTION_STATE.Error, detail));
    }

    public void Run(string id, Action action)
        => RunAsync(id, () => { action(); return Task.CompletedTask; }).GetAwaiter().GetResult();

    public async Task RunAsync(string id, Func<Task> action, bool resetToWaitingOnSuccess = false)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(id);
        ArgumentNullException.ThrowIfNull(action);
        long run;
        lock (_sync)
        {
            run = ++_run;
            _states[id] = (run, new(id, EN_SEQUENCE_ACTION_STATE.Running));
        }
        try
        {
            await action().ConfigureAwait(false);
            Finish(resetToWaitingOnSuccess ? EN_SEQUENCE_ACTION_STATE.Waiting : EN_SEQUENCE_ACTION_STATE.Completed, "");
        }
        catch (OperationCanceledException exception)
        {
            Finish(EN_SEQUENCE_ACTION_STATE.Stopped, exception.Message);
            throw;
        }
        catch (Exception exception)
        {
            Finish(EN_SEQUENCE_ACTION_STATE.Error, exception.Message);
            throw;
        }

        void Finish(EN_SEQUENCE_ACTION_STATE state, string detail)
        {
            lock (_sync)
            {
                // An earlier execution must not republish after RESET or a new execution.
                if (_states.TryGetValue(id, out var entry) && entry.Run == run)
                    _states[id] = (run, new(id, state, detail));
            }
        }
    }
}
