using System.Diagnostics;
using System.Globalization;
using Drilling.Common.Interface;

namespace Drilling.Common.Station;

public sealed record ST_STAGE_REQUEST_STATUS(string State, string Detail, bool ReadyForProcess = false);
public sealed record ST_STAGE_SIGNAL_SNAPSHOT(bool Connected, IReadOnlyDictionary<string, ST_MELSEC_CACHED_VALUE> Values);

/// <summary>Stage is master. Reads only shared snapshots; all writes use the central MELSEC queue.</summary>
public sealed partial class CStageRequestSequence(
    Func<ST_STAGE_SIGNAL_SNAPSHOT> read,
    Func<string, int, CancellationToken, Task> write,
    CSequenceActionStatusStore actions,
    Action<string> log,
    Func<CancellationToken, Task>? stopTasks = null,
    Action? checkActiveWork = null,
    Func<CancellationToken, Task>? verifyProcessReady = null,
    Func<CancellationToken, Task>? processMachining = null,
    Func<CancellationToken, Task>? processResults = null,
    Func<CancellationToken, Task>? releaseProcessTasks = null)
{
    public const string StgAble = "HANDSHAKE_STG_DOREADY_ABLE";
    public const string StgStart = "HANDSHAKE_STG_DOREADY_START";
    public const string StgComplete = "HANDSHAKE_STG_DOREADY_COMPLETE";
    public const string PrcAble = "HANDSHAKE_PRC_DOREADY_ABLE";
    public const string PrcStart = "HANDSHAKE_PRC_DOREADY_START";
    public const string PrcComplete = "HANDSHAKE_PRC_DOREADY_COMPLETE";
    public const string StgProcessAble = "HANDSHAKE_STG_PROCESS_ABLE";
    private readonly object _sync = new();
    private CancellationTokenSource? _stop;
    private Task? _worker;
    private bool _cleanupFailed;
    private bool _cleanupTasks;
    private bool _cleanupOutputs;
    private bool _tasksIssued;
    public bool NeedsCleanup => Volatile.Read(ref _cleanupFailed);
    private ST_STAGE_REQUEST_STATUS _status = new("DISABLED", "Stage request monitoring disabled.");
    public ST_STAGE_REQUEST_STATUS Status => Volatile.Read(ref _status);
    public bool IsRunning { get { lock (_sync) return _worker is { IsCompleted: false }; } }

    public void Start(Func<CancellationToken, Task> prepare, Func<CancellationToken, Task> buildUpload, Func<CancellationToken, Task> zero, Func<CancellationToken, Task> runTasks,
        ST_STAGE_REVIEW_ACTIONS? review = null)
    {
        lock (_sync)
        {
            if (_worker is { IsCompleted: false }) throw new InvalidOperationException("Previous Stage sequence has not stopped.");
            if (_cleanupFailed) throw new InvalidOperationException("Previous Stage cleanup has not completed.");
            _stop?.Dispose();
            _stop = new CancellationTokenSource();
            actions.Reset();
            _reviewActions = review; _reviewOutputsOwned = false;
            _worker = Task.Run(() => Run(prepare, buildUpload, zero, runTasks, _stop.Token));
        }
    }

    public async Task<bool> StopAsync()
    {
        Task? worker;
        lock (_sync)
        {
            _stop?.Cancel();
            if (_worker is { IsCompleted: true } && _cleanupFailed)
                _worker = Task.Run(() => Cleanup(_cleanupTasks, _cleanupOutputs));
            worker = _worker;
        }
        if (worker is null) return true;
        try { await worker.WaitAsync(TimeSpan.FromSeconds(5)).ConfigureAwait(false); return !NeedsCleanup; }
        catch (TimeoutException)
        {
            Set("STOPPING", "Waiting for the existing device operation to stop; restart is blocked.");
            return false; // Keep the worker and prohibit overlapping runs, even if a driver ignores cancellation.
        }
    }

    private async Task Run(Func<CancellationToken, Task> prepare, Func<CancellationToken, Task> buildUpload, Func<CancellationToken, Task> zero, Func<CancellationToken, Task> runTasks, CancellationToken token)
    {
        var outputsOwned = false;
        _tasksIssued = false;
        var failed = false;
        try
        {
            while (true)
            {
                Set(_reviewActions is null ? "WAIT_DOREADY" : "WAIT_REQUEST", "Waiting for Stage DoReady / Review ABLE (START/COMPLETE must be OFF).");
                // Synchronize our side first. A previous high COMPLETE can otherwise
                // prevent Stage from clearing its own COMPLETE after a reconnect.
                while (true)
                {
                    token.ThrowIfCancellationRequested();
                    var initial = read();
                    if (TrySignal(initial, StgAble, out _) && TrySignal(initial, StgStart, out _) && TrySignal(initial, StgComplete, out _)) break;
                    await Task.Delay(100, token).ConfigureAwait(false);
                }
                outputsOwned = true;
                if (processMachining is not null)
                {
                    _processOutputsOwned = true;
                    foreach (var id in ProcessOutputs) await WriteConfirmed(id, 0, token).ConfigureAwait(false);
                }
                foreach (var id in new[] { PrcComplete, PrcStart, PrcAble }) await WriteConfirmed(id, 0, token).ConfigureAwait(false);
                if (_reviewActions is not null)
                {
                    _reviewOutputsOwned = true;
                    foreach (var id in ReviewOutputs) await WriteConfirmed(id, 0, token).ConfigureAwait(false);
                }
                // Standing ABLE is allowed, but an old START/COMPLETE must never replay a request.
                while (true)
                {
                    token.ThrowIfCancellationRequested();
                    var sample = read();
                    // Review is independent of Process. When both requests are present, finish the
                    // previous glass's Review before preparing a new glass with its newly saved offsets.
                    if (IsReviewReady(sample))
                    {
                        await RunReview(token).ConfigureAwait(false);
                        Set("WAIT_REQUEST", "Waiting for Stage DoReady / Review ABLE.");
                        continue;
                    }
                    if (TrySignal(sample, StgAble, out var able) && TrySignal(sample, StgStart, out var start) &&
                        TrySignal(sample, StgComplete, out var complete) && able == 1 && start == 0 && complete == 0) break;
                    await Task.Delay(100, token).ConfigureAwait(false);
                }
                actions.Reset(); // Reset execution feedback only when accepting a new request.
                await WriteConfirmed(PrcAble, 1, token).ConfigureAwait(false);
                Set("WAIT_START", "DoReady ABLE acknowledged; waiting for Stage START.");
                await WaitSignal(StgStart, 1, token).ConfigureAwait(false);
                await WriteConfirmed(PrcStart, 1, token).ConfigureAwait(false);
                Set("PREPARE", "Preparing the request recipe and coordinates.");
                await Action(CSequenceActionIds.PrepareData, prepare, token).ConfigureAwait(false);
                Set("BUILD_UPLOAD", "Building and uploading scripts only; MOF initialization and Task RUN belong to Process preparation.");
                await Action(CSequenceActionIds.BuildUploadScript, buildUpload, token).ConfigureAwait(false);
                await WriteConfirmed(PrcComplete, 1, token).ConfigureAwait(false);
                Set("WAIT_COMPLETE", "Scripts uploaded; waiting for Stage DoReady COMPLETE.");
                await WaitSignal(StgComplete, 1, token).ConfigureAwait(false);
                Set("DOREADY_SIGNALS_CLEAR", "Clearing our DoReady signals and waiting for Stage DoReady signals OFF.");
                await Action(CSequenceActionIds.DoReadySignalsClear, async ct =>
                {
                    foreach (var id in new[] { PrcComplete, PrcStart, PrcAble })
                        await WriteConfirmed(id, 0, ct).ConfigureAwait(false);
                    foreach (var id in new[] { StgComplete, StgStart, StgAble })
                        await WaitSignal(id, 0, ct).ConfigureAwait(false);
                }, token).ConfigureAwait(false);
                Set("WAIT_PROCESS", "DoReady handshake cleared; waiting for Stage Process ABLE before MOF initialization and Task RUN.");
                if (processMachining is not null)
                {
                    await RunProcess(zero, runTasks, token).ConfigureAwait(false);
                    // Completed Task/queue ownership was released by RunProcess, without STOP.
                    // Continue AUTO, accepting a new glass only after the old START/COMPLETE clear.
                    _tasksIssued = false;
                    continue;
                }
                var processPrepared = false;
                // Process begins only after DoReady has finished, even when its ABLE arrived earlier.
                while (true)
                {
                    token.ThrowIfCancellationRequested();
                    var sample = EnsureConnectedSignals();
                    checkActiveWork?.Invoke();
                    if (!processPrepared && TrySignal(sample, StgProcessAble, out var able) && able == 1)
                    {
                        await PrepareProcessTasks(zero, runTasks, token).ConfigureAwait(false);
                        processPrepared = true;
                        Set("PROCESS_READY_VERIFIED", "Stage Y Ready position and Task encoder-wait readiness verified.", true);
                    }
                    // Observer-only callers without Process callbacks stay at prepared readiness.
                    await Task.Delay(100, token).ConfigureAwait(false);
                }
            }
        }
        catch (OperationCanceledException) when (token.IsCancellationRequested) { Set("STOPPED", "Stage request sequence stopped."); }
        catch (Exception exception) { failed = true; Set("ERROR", exception.Message); }
        finally
        {
            await Cleanup(_tasksIssued, outputsOwned).ConfigureAwait(false);
            if (!failed && !NeedsCleanup) Set("STOPPED", "Stage request sequence stopped.");
        }
    }

    private async Task Cleanup(bool tasksIssued, bool outputsOwned)
    {
        _cleanupTasks = tasksIssued;
        _cleanupOutputs = outputsOwned;
        var failed = false;
        if (tasksIssued && stopTasks is not null)
        {
            try
            {
                using var cleanup = new CancellationTokenSource(TimeSpan.FromSeconds(10));
                await stopTasks(cleanup.Token).ConfigureAwait(false);
            }
            catch (Exception exception) { failed = true; Set("ERROR", $"{Status.Detail} Task cleanup failed: {exception.Message}"); }
        }
        if (outputsOwned)
        {
            foreach (var id in new[] { PrcComplete, PrcStart, PrcAble }.Concat(_processOutputsOwned ? ProcessOutputs : [])
                .Concat(_reviewOutputsOwned ? ReviewOutputs : []))
            {
                try
                {
                    using var cleanup = new CancellationTokenSource(TimeSpan.FromSeconds(3));
                    await write(id, 0, cleanup.Token).ConfigureAwait(false);
                }
                catch (Exception exception) { failed = true; Set("ERROR", $"{Status.Detail} Signal cleanup failed: {id}. {exception.Message}"); }
            }
        }
        Volatile.Write(ref _cleanupFailed, failed);
        if (!failed && (Status.State is "STOPPING" or "ERROR") && _stop?.IsCancellationRequested == true)
            Set("STOPPED", "Stage request sequence stop and cleanup confirmed.");
    }

    private async Task Action(string id, Func<CancellationToken, Task> action, CancellationToken token, TimeSpan? timeout = null,
        bool resetToWaitingOnSuccess = false)
    {
        await actions.RunAsync(id, async () =>
        {
            using var limit = CancellationTokenSource.CreateLinkedTokenSource(token);
            limit.CancelAfter(timeout ?? TimeSpan.FromMinutes(2));
            try
            {
                await action(limit.Token).ConfigureAwait(false);
                limit.Token.ThrowIfCancellationRequested();
            }
            catch (OperationCanceledException) when (!token.IsCancellationRequested && limit.IsCancellationRequested)
            {
                throw new TimeoutException($"Sequence action timed out: {id}.");
            }
            EnsureConnectedSignals();
        }, resetToWaitingOnSuccess).ConfigureAwait(false);
    }

    private async Task WriteConfirmed(string id, int value, CancellationToken token)
    {
        EnsureConnectedSignals();
        await write(id, value, token).ConfigureAwait(false);
        var acknowledgedAt = DateTimeOffset.UtcNow;
        await WaitSignal(id, value, token, acknowledgedAt, TimeSpan.FromSeconds(5)).ConfigureAwait(false);
    }

    private async Task WaitSignal(string id, int value, CancellationToken token, DateTimeOffset? after = null, TimeSpan? timeout = null)
    {
        var elapsed = Stopwatch.StartNew();
        while (elapsed.Elapsed < (timeout ?? TimeSpan.FromMinutes(2)))
        {
            token.ThrowIfCancellationRequested();
            var sample = EnsureConnectedSignals();
            checkActiveWork?.Invoke();
            if (!TrySignal(sample, id, out var actual))
            {
                if (!sample.Values.TryGetValue(id, out var pending) || pending.State == EN_MELSEC_CACHE_STATE.Pending)
                {
                    await Task.Delay(50, token).ConfigureAwait(false);
                    continue;
                }
                throw new InvalidOperationException($"Invalid or unavailable handshake: {id}.");
            }
            if (actual == value && (after is null || sample.Values[id].UpdatedAt >= after)) return;
            await Task.Delay(50, token).ConfigureAwait(false);
        }
        throw new TimeoutException($"Handshake timeout: {id} = {value}.");
    }

    private ST_STAGE_SIGNAL_SNAPSHOT EnsureConnectedSignals()
    {
        var sample = read();
        if (!sample.Connected) throw new InvalidOperationException("MELSEC offline during Stage sequence.");
        foreach (var id in new[] { StgAble, StgStart, StgComplete })
            if (!TrySignal(sample, id, out _)) throw new InvalidOperationException($"Invalid or stale Stage handshake: {id}.");
        return sample;
    }

    private static bool TrySignal(ST_STAGE_SIGNAL_SNAPSHOT snapshot, string id, out int value)
    {
        value = -1;
        if (!snapshot.Connected || !snapshot.Values.TryGetValue(id, out var sample) || !sample.IsValid || sample.Value is null) return false;
        try
        {
            var number = Convert.ToDouble(sample.Value, CultureInfo.InvariantCulture);
            if (number is not (0 or 1)) return false;
            value = (int)number;
            return true;
        }
        catch (Exception exception) when (exception is FormatException or InvalidCastException or OverflowException) { return false; }
    }

    private void Set(string state, string detail, bool ready = false)
    {
        Volatile.Write(ref _status, new(state, detail, ready));
        try { log($"{state}: {detail}"); }
        catch (Exception exception) { Trace.TraceError($"Stage sequence log failed: {exception}"); }
    }
}
