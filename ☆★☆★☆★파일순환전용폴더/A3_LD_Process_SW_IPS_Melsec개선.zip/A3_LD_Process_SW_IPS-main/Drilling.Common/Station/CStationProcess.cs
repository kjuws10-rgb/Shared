﻿using System.Globalization;
using System.Diagnostics;
using System.Runtime.ExceptionServices;
using System.Text;
using Drilling.Common.Log;
using Drilling.Common.Interface;
using Drilling.Common.Motion;
using Drilling.Common.Alarm;
using Drilling.Common.InterLock;
using Drilling.Common.Managers;
using Drilling.Common.Product;
using Drilling.Common.Automation;
using Drilling.Common.Recipe;
using Drilling.Common.Review;
using Drilling.Common.Station;
using Drilling.Common.Threading;

namespace Drilling.Common.Station;
public sealed partial class CStationProcess : CtrlThread
{
    private delegate void CProcessStepAction(ST_PROCESS_MODEL processModel, CancellationToken cancellationToken);
    private const string AutoStepIdle = "IDLE";
    private const string AutoStepPowerCheck = "POWER_CHECK";
    private const string AutoStepAlign = "ALIGN";
    private const string AutoStepProcess = "PROCESS";
    private const string AutoStepInspection = "INSPECTION";
    private const string AutoStepComplete = "COMPLETE";
    private const string ScriptBufferedRunUseKey = "SCRIPT_BUFFERED_RUN_USE";
    private const string ScriptRunTimeoutMsKey = "SCRIPT_RUN_TIMEOUT_MS";
    private const string ScriptRunPollIntervalMsKey = "SCRIPT_RUN_POLL_INTERVAL_MS";
    private const string ScriptBufferedRunLinesPerCommandKey = "SCRIPT_BUFFERED_RUN_LINES_PER_COMMAND";
    private const string ScriptBufferedRunTimeoutMsKey = "SCRIPT_BUFFERED_RUN_TIMEOUT_MS";
    private const string ScriptBufferedRunQueueSizeKey = "SCRIPT_BUFFERED_RUN_QUEUE_SIZE";
    private const string StandardScriptDirectoryName = "Standard";
    private const string BufferedRunScriptDirectoryName = "BufferedRun";
    private const string QueueCountLogDirectoryName = "QueueCount";
    private const string ScannerStatusLogDirectoryName = "ScannerStatus";
    private const int ScriptRunDefaultTimeoutMs = 600000;
    private const int ScriptRunDefaultPollIntervalMs = 100;
    private const int EncoderScaleReleaseTimeoutMs = 5000;
    private const int QueueCountLogIntervalMs = 5000;
    private const int ScannerStatusLogIntervalMs = 1000;
    private const int QueueCountLogStopWaitMs = 2000;
    private const int MaximumProcessLogCount = 500;
    private const string AutoStepWait = "WAIT";
    private const string AutoStepRunning = "RUNNING";
    private const string AutoStepOk = "OK";
    private const string AutoStepDone = "DONE";
    private const string AutoStepError = "ERROR";
    private const string AutoStepStop = "STOP";
    private static readonly IReadOnlyList<ST_AUTO_STEP_INFO> AutoStepInfos = [new(AutoStepIdle, "IDLE"), new(AutoStepPowerCheck, "POWERCHECK"), new(AutoStepAlign, "ALIGN"), new(AutoStepProcess, "PROCESS"), new(AutoStepInspection, "INSPECTION"), new(AutoStepComplete, "COMPLETE")];
    private static readonly IReadOnlyList<ST_STATION_PROCESS_FLOW_ITEM> ProcessFlowItems = [new(1, AutoStepIdle, "IDLE", EN_STATION_STATE.Idle, EN_PROCESS_STEP.Idle, EN_SCRIPT_STATUS.NotCreated, AutoStepPowerCheck, "ALARM"), new(2, AutoStepPowerCheck, "POWERCHECK", EN_STATION_STATE.Check, EN_PROCESS_STEP.PowerCheck, EN_SCRIPT_STATUS.NotCreated, AutoStepAlign, "ALARM"), new(3, AutoStepAlign, "ALIGN", EN_STATION_STATE.Process, EN_PROCESS_STEP.Align, EN_SCRIPT_STATUS.NotCreated, AutoStepProcess, "ALARM"), new(4, AutoStepProcess, "PROCESS", EN_STATION_STATE.Process, EN_PROCESS_STEP.Process, EN_SCRIPT_STATUS.Running, AutoStepInspection, "ALARM"), new(5, AutoStepInspection, "INSPECTION", EN_STATION_STATE.Process, EN_PROCESS_STEP.Inspection, EN_SCRIPT_STATUS.Running, AutoStepComplete, "ALARM"), new(6, AutoStepComplete, "COMPLETE", EN_STATION_STATE.Complete, EN_PROCESS_STEP.Completed, EN_SCRIPT_STATUS.Completed, "IDLE/RESET", "ALARM")];
    private readonly CInterfaceManager _interfaceManager;
    private readonly CMotionManager _motionManager;
    private readonly CInterLockManager _interLockManager;
    private readonly CSettingManager _settingManager;
    private readonly CProductManager? _productManager;
    private readonly CReviewOffsetFileBase? _reviewOffsetFile;
    private readonly CAutomationScriptFileBase _automationScriptFile;
    private readonly CAutomationManager _automationManager;
    private readonly CLogManager? _logManager;
    private readonly object _sequenceLock = new();
    private readonly object _processLogLock = new();
    private readonly CSequenceActionStatusStore _sequenceActions = new();
    private readonly List<ST_PROCESS_LOG_ITEM> _processLogs = [];
    private readonly Dictionary<string, string> _autoStepStates = CreateAutoStepStateMap();
    private DateTimeOffset? _scriptCreatedAt;
    private DateTimeOffset? _scriptStartedAt;
    private DateTimeOffset? _scriptCompletedAt;
    private ST_SCRIPT_BUILD_RESULT? _lastScript;
    private IReadOnlyList<ST_INTERLOCK_ITEM> _lastInterLockItems = [];
    private ST_PROCESS_MODEL? _processModel;
    private ST_PROCESS_STATISTICS _statistics = EmptyStatistics();
    private ST_STATION_PROCESS_STATUS _snapshot;
    private ST_STATION_STATUS _stationStatus;
    private EN_STATION_SEQUENCE _sequenceState = EN_STATION_SEQUENCE.Ready;
    private CancellationTokenSource? _sequenceCancellation;
    private string _sequenceError = "";
    public CStationProcess(CInterfaceManager interfaceManager, CMotionManager motionManager, CInterLockManager interLockManager, CSettingManager settingManager, CAutomationScriptFileBase automationScriptFile, CAutomationManager automationManager, CReviewOffsetFileBase? reviewOffsetFile = null, CProductManager? productManager = null, CLogManager? logManager = null, string stationName = "PROCESS", string? scriptDirectory = null)
    {
        _interfaceManager = interfaceManager;
        _motionManager = motionManager;
        _interLockManager = interLockManager;
        _settingManager = settingManager;
        _productManager = productManager;
        _reviewOffsetFile = reviewOffsetFile;
        _automationScriptFile = automationScriptFile;
        _automationManager = automationManager;
        _logManager = logManager;
        _snapshot = CreateSnapshot(null, [], EN_SCRIPT_STATUS.NotCreated, EN_PROCESS_STEP.Idle, null);
        _stationStatus = new ST_STATION_STATUS(EN_STATION_ID.Process, stationName, EN_STATION_STATE.Idle, EN_PROCESS_STEP.Idle, EN_SCRIPT_STATUS.NotCreated, "Station idle.", DateTimeOffset.Now);
        StageRequests = CreateStageRequestSequence();
    }

    public ST_STATION_PROCESS_STATUS Current
    {
        get
        {
            return _snapshot with { SequenceActions = _sequenceActions.GetSnapshot(), StageRequest = StageRequests.Status };
        }
    }

    public ST_STATION_STATUS Status
    {
        get
        {
            return ReadStationStatus();
        }
    }

    public EN_STATION_SEQUENCE SequenceState
    {
        get
        {
            return ReadSequenceState();
        }
    }

    public static IReadOnlyList<ST_STATION_PROCESS_FLOW_ITEM> GetProcessFlow()
    {
        return ProcessFlowItems;
    }

    public ST_STATION_PROCESS_STATUS PrepareProcess(string processId, string recipeId, string glassId, string lotId, IReadOnlyDictionary<string, string> parameters, CancellationToken cancellationToken = default, bool preserveSequenceActions = false)
    {
        lock (_sequenceLock)
        {
            if (_manualMofRunning || _manualMofRequiresStop || ReadSequenceState() != EN_STATION_SEQUENCE.Ready)
                throw new InvalidOperationException("Station is busy. PrepareProcess is not allowed during processing.");
            return PrepareProcessCore(processId, recipeId, glassId, lotId, parameters, cancellationToken, preserveSequenceActions);
        }
    }

    private ST_STATION_PROCESS_STATUS PrepareProcessCore(string processId, string recipeId, string glassId, string lotId,
        IReadOnlyDictionary<string, string> parameters, CancellationToken cancellationToken,
        bool preserveSequenceActions, IReadOnlySet<int>? manualHeads = null)
    {
        cancellationToken.ThrowIfCancellationRequested();
        ClearProcessLogs();
        _lastInterLockItems = [];
        _scriptCreatedAt = null;
        _scriptStartedAt = null;
        _scriptCompletedAt = null;
        _lastScript = null;
        ResetAutoStepStatesCore(preserveSequenceActions);
        SetSequenceState(EN_STATION_SEQUENCE.Ready);
        var runtimeParameters = BuildRuntimeParameters(recipeId, parameters, cancellationToken);
        if (manualHeads is not null)
        {
            var scoped = new Dictionary<string, string>(runtimeParameters, StringComparer.OrdinalIgnoreCase);
            for (var head = 1; head <= 8; head++) scoped[$"H{head:00}_USE"] = manualHeads.Contains(head) ? "ON" : "OFF";
            runtimeParameters = scoped;
        }
        _processModel = BuildProcessModel(processId, recipeId, glassId, lotId, runtimeParameters);
        var preview = BuildPreview(_processModel, EN_HEAD_PROCESS_STATUS.Ready);
        _statistics = BuildStatistics(_processModel, 0.0, TimeSpan.Zero);
        AddProcessLog("INFO", "SCAN_PC", $"Process model prepared ({_processModel.ProcessId})");
        AddProcessLog("INFO", "PARSER", $"Head parameter parsed ({preview.Count} heads / {_statistics.TotalShots} shots)");
        SetAutoStepState(AutoStepIdle, AutoStepOk);
        _snapshot = CreateSnapshot(_processModel, preview, EN_SCRIPT_STATUS.NotCreated, EN_PROCESS_STEP.Idle, null);
        SetStationState(EN_STATION_STATE.Idle, EN_PROCESS_STEP.Idle, EN_SCRIPT_STATUS.NotCreated, $"Process model prepared: {_processModel.ProcessId}");
        return _snapshot;
    }

    public ST_STATION_PROCESS_STATUS Start(CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        ST_PROCESS_MODEL processModel;
        lock (_sequenceLock)
        {
            if (_sequenceState != EN_STATION_SEQUENCE.Ready)
            {
                return _snapshot;
            }

            if (_manualMofRunning || _manualMofRequiresStop) throw new InvalidOperationException("Manual MOF is active or requires STOP.");
            EnsureStartAllowed();
            processModel = ReadProcessModelForStart();
        }

        var startInterLock = GetInterLockSummary(cancellationToken, processModel);
        if (!startInterLock.CanAutoRun)
        {
            throw new InvalidOperationException(FormatStartInterLockBlockedMessage(startInterLock));
        }

        lock (_sequenceLock)
        {
            if (_sequenceState != EN_STATION_SEQUENCE.Ready)
            {
                return _snapshot;
            }

            if (_manualMofRunning || _manualMofRequiresStop) throw new InvalidOperationException("Manual MOF is active or requires STOP.");
            EnsureStartAllowed();
            _sequenceCancellation?.Dispose();
            _sequenceCancellation = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            _sequenceError = "";
            _sequenceState = EN_STATION_SEQUENCE.PowerCheck;
            _stationStatus = (_stationStatus with
            {
                ChangedAt = DateTimeOffset.Now
            }).WithSequenceState(EN_STATION_SEQUENCE.PowerCheck);
        }

        base.Start(10, "StationProcess");
        return _snapshot;
    }

    public override void Run()
    {
        EN_STATION_SEQUENCE sequenceState;
        lock (_sequenceLock)
        {
            // RESET can leave CtrlThread alive. Manual MOF owns its own async
            // execution; the legacy AUTO tick must never execute the same model.
            if (_manualMofRunning || _manualMofRequiresStop) return;
            sequenceState = _sequenceState;
        }
        try
        {
            switch (sequenceState)
            {
                case EN_STATION_SEQUENCE.Ready:
                    return;
                case EN_STATION_SEQUENCE.PowerCheck:
                    RunSequenceStep(EN_STATION_SEQUENCE.PowerCheck, AutoStepPowerCheck, RunPowerCheckStep, EN_STATION_SEQUENCE.Align);
                    break;
                case EN_STATION_SEQUENCE.Align:
                    RunSequenceStep(EN_STATION_SEQUENCE.Align, AutoStepAlign, RunAlignStep, EN_STATION_SEQUENCE.Process);
                    break;
                case EN_STATION_SEQUENCE.Process:
                    RunSequenceStep(EN_STATION_SEQUENCE.Process, AutoStepProcess, RunProcessStep, EN_STATION_SEQUENCE.Inspection);
                    break;
                case EN_STATION_SEQUENCE.Inspection:
                    RunSequenceStep(EN_STATION_SEQUENCE.Inspection, AutoStepInspection, RunInspectionStep, EN_STATION_SEQUENCE.Complete);
                    break;
                case EN_STATION_SEQUENCE.Complete:
                    RunSequenceStep(EN_STATION_SEQUENCE.Complete, AutoStepComplete, CompleteSequence, EN_STATION_SEQUENCE.Ready);
                    FinishSequence();
                    break;
                case EN_STATION_SEQUENCE.Stop:
                    ProcessStop(CancellationToken.None);
                    FinishSequence();
                    break;
                case EN_STATION_SEQUENCE.Reset:
                    ProcessReset(CancellationToken.None);
                    FinishSequence();
                    break;
                case EN_STATION_SEQUENCE.Error:
                    SetAlarm(_sequenceError, CancellationToken.None);
                    FinishSequence();
                    break;
            }
        }
        catch (OperationCanceledException)
        {
            SetSequenceState(EN_STATION_SEQUENCE.Stop);
        }
        catch (Exception exception)when (exception is InvalidOperationException or TimeoutException or IOException or KeyNotFoundException)
        {
            _sequenceError = exception.Message;
            SetSequenceState(EN_STATION_SEQUENCE.Error);
        }
    }

    private void RunSequenceStep(EN_STATION_SEQUENCE expectedSequence, string stepKey, CProcessStepAction action, EN_STATION_SEQUENCE nextSequence)
    {
        var cancellationToken = GetSequenceCancellationToken();
        var processModel = CheckProcessModelLoaded();
        ExecuteAutoStep(stepKey, processModel, action, cancellationToken);
        if (!TryMoveSequenceState(expectedSequence, nextSequence))
        {
            ProcessInterruptedSequence();
        }
    }

    private ST_PROCESS_MODEL CheckProcessModelLoaded()
    {
        return _processModel ?? throw new InvalidOperationException("Process Model is not loaded.");
    }

    private CancellationToken GetSequenceCancellationToken()
    {
        lock (_sequenceLock)
        {
            return _sequenceCancellation?.Token ?? CancellationToken.None;
        }
    }

    private void FinishSequence()
    {
        lock (_sequenceLock)
        {
            _sequenceState = EN_STATION_SEQUENCE.Ready;
            _stationStatus = (_stationStatus with
            {
                ChangedAt = DateTimeOffset.Now
            }).WithSequenceState(EN_STATION_SEQUENCE.Ready);
            _sequenceCancellation?.Dispose();
            _sequenceCancellation = null;
        }
    }

    private void ProcessInterruptedSequence()
    {
        var sequenceState = ReadSequenceState();
        if (sequenceState == EN_STATION_SEQUENCE.Stop)
        {
            throw new OperationCanceledException();
        }

        throw new InvalidOperationException($"Station sequence entered {sequenceState} during auto start.");
    }

    private void CompleteSequence(ST_PROCESS_MODEL processModel, CancellationToken cancellationToken)
    {
        CompleteProcess(cancellationToken);
    }

    private void EnsureStartAllowed()
    {
        if (ReadStationStatus().State == EN_STATION_STATE.Alarm)
        {
            throw new InvalidOperationException("Station alarm is active. Reset alarm before auto start.");
        }
    }

    private ST_PROCESS_MODEL ReadProcessModelForStart()
    {
        if (_snapshot.ProcessModel is not null)
        {
            return _snapshot.ProcessModel;
        }

        SetAutoStepState(AutoStepIdle, AutoStepError);
        SetSequenceState(EN_STATION_SEQUENCE.Error);
        throw new InvalidOperationException("Process model is not loaded.");
    }

    public IReadOnlyList<ST_INTERLOCK_ITEM> GetLiveInterlockItems(CancellationToken cancellationToken = default)
        => EvaluateInterlocks(_snapshot.ProcessModel?.Parameters, cancellationToken, cachedStatusOnly: true).Items;

    public IReadOnlyList<ST_INTERLOCK_ITEM> GetLiveInterlockItems(IReadOnlyDictionary<string, string> parameters, CancellationToken cancellationToken = default)
        => EvaluateInterlocks(parameters, cancellationToken, cachedStatusOnly: true).Items;

    public IReadOnlyList<ST_INTERLOCK_ITEM> GetManualInterlockItems(IReadOnlyDictionary<string, string> parameters,
        IReadOnlySet<int> selectedHeads, CancellationToken cancellationToken = default)
    {
        var heads = selectedHeads.Where(head => head is >= 1 and <= 8).ToHashSet();
        var manualParameters = new Dictionary<string, string>(parameters, StringComparer.OrdinalIgnoreCase);
        for (var head = 1; head <= 8; head++) manualParameters[$"H{head:00}_USE"] = heads.Contains(head) ? "ON" : "OFF";
        // Same rules and shared device snapshots as Main, without changing AUTO's published interlocks.
        var items = EvaluateInterlocks(manualParameters, cancellationToken, cachedStatusOnly: true, publish: false).Items;
        var firstBet = _interfaceManager.GetInterfaceList(EN_EQP_MODULE.Bet).FirstOrDefault();
        return items.Select(item => item.HeadNo is null && item.Signal.Equals("BET", StringComparison.OrdinalIgnoreCase) &&
                firstBet is { Number: >= 0 and < 8 } ? item with { HeadNo = firstBet.Number + 1 } : item)
            .Where(item => item.HeadNo is not > 0 || heads.Contains(item.HeadNo.Value)).ToArray();
    }

    private void ExecuteAutoStep(string stepKey, ST_PROCESS_MODEL processModel, CProcessStepAction action, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var stepName = GetAutoStepName(stepKey);
        var flowItem = GetProcessFlowItem(stepKey);
        var runningScriptStatus = ResolveStepScriptStatus(stepKey, flowItem.ScriptStatus);
        SetAutoStepState(stepKey, AutoStepRunning);
        AddProcessLog("INFO", "STEP", $"{stepName} started.");
        _snapshot = CreateSnapshot(_snapshot.ProcessModel, SetHeadStatus(_snapshot.HeadPreviews, flowItem.RunningStep), runningScriptStatus, flowItem.RunningStep, null);
        SetStationState(flowItem.RunningState, flowItem.RunningStep, runningScriptStatus, $"{stepName} started.");
        RefreshSnapshot();
        try
        {
            action(processModel, cancellationToken);
            SetAutoStepState(stepKey, stepKey == AutoStepComplete ? AutoStepDone : AutoStepOk);
            AddProcessLog("INFO", "STEP", $"{stepName} completed.");
            RefreshSnapshot();
        }
        catch (Exception exception)
        {
            SetAutoStepState(stepKey, AutoStepError);
            AddProcessLog("ERROR", "STEP", $"{stepName} failed. {exception.Message}");
            RefreshSnapshot();
            throw;
        }
    }

    private void RunAlignStep(ST_PROCESS_MODEL processModel, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var parameters = processModel.Parameters;
        var reviewCameraAlignKeyPosX = ReadDoubleAny(parameters, 0.0, "REVIEW_CAMERA_ALIGN_KEY_POS_X");
        var reviewCameraAlignKeyPosY = ReadDoubleAny(parameters, 0.0, "REVIEW_CAMERA_ALIGN_KEY_POS_Y");
        var stageYSpeed = ReadDoubleAny(parameters, 100.0, "STAGE_SPEED");
        try
        {
            UpdateProductAlignment(processModel, EN_PRODUCT_PROCESS_STATE.Running, "RUNNING", cancellationToken);
            SendProcessControlCommand("ALIGN_REVIEW_CAMERA_MOVE", [("CAMERA_X", FormatDouble(reviewCameraAlignKeyPosX)), ("STAGE_Y", FormatDouble(reviewCameraAlignKeyPosY)), ("SPEED_Y", FormatDouble(stageYSpeed))], cancellationToken);
            UpdateProductAlignment(processModel, EN_PRODUCT_PROCESS_STATE.Completed, "OK", cancellationToken);
        }
        catch (OperationCanceledException)
        {
            TryUpdateProductAlignmentAfterFailure(processModel, EN_PRODUCT_PROCESS_STATE.Stopped, "STOPPED");
            throw;
        }
        catch
        {
            TryUpdateProductAlignmentAfterFailure(processModel, EN_PRODUCT_PROCESS_STATE.Error, "ERROR");
            throw;
        }

        AddProcessLog("INFO", "ALIGN", $"Review camera align key position requested. CameraX={FormatDouble(reviewCameraAlignKeyPosX)}, StageY={FormatDouble(reviewCameraAlignKeyPosY)}");
    }

    private void UpdateProductAlignment(ST_PROCESS_MODEL processModel, EN_PRODUCT_PROCESS_STATE state, string result, CancellationToken cancellationToken)
    {
        var productId = GetCurrentProcessProductId();
        if (_productManager is null || string.IsNullOrWhiteSpace(productId))
        {
            return;
        }

        var parameters = processModel.Parameters;
        var includeResults = state == EN_PRODUCT_PROCESS_STATE.Completed;
        _productManager.SetAlignment(productId, new ST_PRODUCT_ALIGN_DATA(state, result, includeResults ? ReadNullableDoubleAny(parameters, "ALIGN_OFFSET_X") : null, includeResults ? ReadNullableDoubleAny(parameters, "ALIGN_OFFSET_Y") : null, includeResults ? ReadNullableDoubleAny(parameters, "ALIGN_ROTATION") : null), new ST_PRODUCT_DISTORTION_DATA(state, result, includeResults ? ReadNullableDoubleAny(parameters, "DISTORTION_MAX_DA", "MAX_DA") : null), cancellationToken).GetAwaiter().GetResult();
    }

    private void TryUpdateProductAlignmentAfterFailure(ST_PROCESS_MODEL processModel, EN_PRODUCT_PROCESS_STATE state, string result)
    {
        try
        {
            UpdateProductAlignment(processModel, state, result, CancellationToken.None);
        }
        catch (Exception updateException)
        {
            AddProcessLog("ERROR", "PRODUCT", $"Product align state update failed. {updateException.Message}");
        }
    }

    private void RunProcessStep(ST_PROCESS_MODEL processModel, CancellationToken cancellationToken)
    {
        _sequenceActions.Run(CSequenceActionIds.BuildUploadScript, () =>
        {
            BuildAutomationScript(processModel, cancellationToken);
            UploadAutomationScript(processModel, cancellationToken);
        });
        //test �Ⱓ���� �ӽ� �ּ�
        //MoveStageToScanStart(processModel, cancellationToken);
        RunScannerProcess(processModel, cancellationToken);
    }

    private void MoveStageToScanStart(ST_PROCESS_MODEL processModel, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var parameters = processModel.Parameters;
        var startX = ReadDoubleAny(parameters, 0.0, "STAGE_START_POS_X");
        var startY = ReadDoubleAny(parameters, 0.0, "STAGE_START_POS_Y");
        var reviewCameraAlignKeyPosX = ReadDoubleAny(parameters, 0.0, "REVIEW_CAMERA_ALIGN_KEY_POS_X");
        var reviewCameraAlignKeyPosY = ReadDoubleAny(parameters, startY, "REVIEW_CAMERA_ALIGN_KEY_POS_Y");
        var reviewToHead1GapY = ReadDoubleAny(parameters, 0.0, "REVIEW_TO_HEAD1_GAP_Y");
        var headGapY = ReadDoubleAny(parameters, 0.0, "HeadGapY");
        var head1AlignKeyY = reviewCameraAlignKeyPosY + reviewToHead1GapY;
        var head2AlignKeyY = head1AlignKeyY + headGapY;
        var delayLengthY = Math.Abs(ReadDoubleAny(parameters, 0.0, "SCAN_START_DELAY_LENGTH_Y"));
        var stageScanDirectionY = ReadDirectionAny(parameters, -1.0, "STAGE_SCAN_DIRECTION_Y");
        var firstShotStageY = ResolveFirstShotStageY(processModel, stageScanDirectionY);
        var scanStartY = reviewCameraAlignKeyPosY + firstShotStageY - (stageScanDirectionY * delayLengthY);
        var stageYSpeed = ReadDoubleAny(parameters, 100.0, "STAGE_SPEED");
        SendProcessControlCommand("PROCESS_STAGE_START_MOVE", [("X", FormatDouble(startX)), ("Y", FormatDouble(startY)), ("SPEED_Y", FormatDouble(stageYSpeed))], cancellationToken);
        SendProcessControlCommand("PROCESS_STAGE_SCAN_START_MOVE", [("Y", FormatDouble(scanStartY)), ("REVIEW_CAMERA_X", FormatDouble(reviewCameraAlignKeyPosX)), ("REVIEW_CAMERA_ALIGN_KEY_Y", FormatDouble(reviewCameraAlignKeyPosY)), ("REVIEW_TO_HEAD1_GAP_Y", FormatDouble(reviewToHead1GapY)), ("HeadGapY", FormatDouble(headGapY)), ("HEAD1_ALIGN_KEY_Y", FormatDouble(head1AlignKeyY)), ("HEAD2_ALIGN_KEY_Y", FormatDouble(head2AlignKeyY)), ("FIRST_SHOT_STAGE_Y", FormatDouble(reviewCameraAlignKeyPosY + firstShotStageY)), ("DELAY_LENGTH_Y", FormatDouble(delayLengthY)), ("SCAN_DIRECTION_Y", FormatDouble(stageScanDirectionY)), ("SPEED_Y", FormatDouble(stageYSpeed))], cancellationToken);
        AddProcessLog("INFO", "STAGE", $"Stage scan start ready. Start=({FormatDouble(startX)}, {FormatDouble(startY)}), ReviewCameraAlignKey=({FormatDouble(reviewCameraAlignKeyPosX)}, {FormatDouble(reviewCameraAlignKeyPosY)}), ReviewToHead1GapY={FormatDouble(reviewToHead1GapY)}, HeadGapY={FormatDouble(headGapY)}, FirstShotY={FormatDouble(reviewCameraAlignKeyPosY + firstShotStageY)}, DelayY={FormatDouble(delayLengthY)}, ScanStartY={FormatDouble(scanStartY)}");
    }

    private double ResolveFirstShotStageY(ST_PROCESS_MODEL processModel, double stageScanDirectionY)
    {
        global::System.Collections.Generic.IEnumerable<global::Drilling.Common.Recipe.ST_HEAD_SHOT_POINT> SelectShots(global::Drilling.Common.Station.ST_HEAD_PROCESS_PLAN head)
        {
            return head.Shots;
        }

        var shots = processModel.HeadPlans.SelectMany(SelectShots).ToArray();
        if (shots.Length == 0)
        {
            var reviewToHead1GapY = ReadDoubleAny(processModel.Parameters, 0.0, "REVIEW_TO_HEAD1_GAP_Y");
            var headGapY = ReadDoubleAny(processModel.Parameters, 0.0, "HeadGapY");
            return reviewToHead1GapY + headGapY;
        }

        double SelectStageY(global::Drilling.Common.Recipe.ST_HEAD_SHOT_POINT shot)
        {
            return shot.StageY;
        }

        double SelectStageY2(global::Drilling.Common.Recipe.ST_HEAD_SHOT_POINT shot)
        {
            return shot.StageY;
        }

        return stageScanDirectionY < 0.0 ? shots.Max(SelectStageY) : shots.Min(SelectStageY2);
    }

    private void SendProcessControlCommand(string commandName, IReadOnlyList<(string Key, string Value)> arguments, CancellationToken cancellationToken)
    {
        var command = FormatCommand(commandName, arguments);
        AddProcessLog("INFO", "STAGE", $"Stage command requested. {command}");
        var response = _interfaceManager.ExecuteFunction(EN_EQP_MODULE.WonikCtrl, 0, command, cancellationToken).GetAwaiter().GetResult();
        if (!IsProcessControlSuccessResponse(response))
        {
            AddProcessLog("ERROR", "STAGE", $"Stage command rejected. {commandName}: {FormatResponseForLog(response)}");
            throw new InvalidOperationException($"Stage command failed: {commandName}. Response={FormatResponseForLog(response)}");
        }

        AddProcessLog("INFO", "STAGE", $"Stage command accepted. {response}");
    }

    private void RunInspectionStep(ST_PROCESS_MODEL processModel, CancellationToken cancellationToken)
    {
        RunReviewStep(processModel, cancellationToken);
    }

    private void BuildAutomationScript(ST_PROCESS_MODEL processModel, CancellationToken cancellationToken)
    {
        var bufferedRun = IsBufferedRunEnabled(processModel.Parameters);
        var scriptDirectoryName = bufferedRun ? BufferedRunScriptDirectoryName : StandardScriptDirectoryName;
        _lastScript = _automationScriptFile.Build(GetProcessModel(), scriptDirectoryName, cancellationToken);
        _scriptCreatedAt = _lastScript.CreatedAt;
        _statistics = BuildStatistics(processModel, 35.0, TimeSpan.FromSeconds(12));
        AddProcessLog("INFO", "SCRIPT", $"{_lastScript.FileName} generated in {scriptDirectoryName}. ({_lastScript.TotalShots} shots)");
        _snapshot = CreateSnapshot(_snapshot.ProcessModel, _snapshot.HeadPreviews, EN_SCRIPT_STATUS.Created, EN_PROCESS_STEP.Process, null);
    }

    private void UploadAutomationScript(ST_PROCESS_MODEL processModel, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (_lastScript is null)
        {
            throw new InvalidOperationException("Automation script is not built.");
        }

        bool ShouldIncludeItem(global::Drilling.Common.Station.ST_HEAD_SCRIPT_RESULT script)
        {
            return script.TotalShots > 0;
        }

        foreach (var headScript in _lastScript.HeadScripts.Where(ShouldIncludeItem))
        {
            AddProcessLog("INFO", "A1_UPLOAD", $"Upload requested. H{headScript.HeadNo:00} -> Automation1 #{headScript.AutomationNo}, {headScript.FileName}");
            var response = _automationManager.UploadScript(headScript.FilePath, headScript.FileName, headScript.AutomationNo, cancellationToken: cancellationToken).GetAwaiter().GetResult();
            var simulationSucceeded = !string.IsNullOrWhiteSpace(response) &&
                response.StartsWith("SIM:", StringComparison.OrdinalIgnoreCase) && response.EndsWith(":OK", StringComparison.OrdinalIgnoreCase);
            if (!IsProcessControlSuccessResponse(response) && !simulationSucceeded)
                throw new InvalidOperationException($"Automation1 script upload failed. H{headScript.HeadNo:00}, {headScript.FileName}: {FormatResponseForLog(response)}");
            AddProcessLog("INFO", "A1_UPLOAD", $"Upload completed. H{headScript.HeadNo:00}, Automation1 #{headScript.AutomationNo}: {response}");
        }
    }

    private void RunScannerProcess(ST_PROCESS_MODEL processModel, CancellationToken cancellationToken)
    {
        SetStationState(EN_STATION_STATE.Process, EN_PROCESS_STEP.Process, EN_SCRIPT_STATUS.Running, $"Scanner run started. Process: {processModel.ProcessId}");
        _scriptStartedAt = DateTimeOffset.Now;
        var runningPreview = SetHeadStatus(_snapshot.HeadPreviews, EN_PROCESS_STEP.Process);
        _statistics = BuildStatistics(processModel, 56.3, TimeSpan.FromSeconds(45));
        if (_lastScript is null)
        {
            throw new InvalidOperationException("Automation script is not built.");
        }

        bool ShouldIncludeItem(global::Drilling.Common.Station.ST_HEAD_SCRIPT_RESULT script)
        {
            return script.TotalShots > 0;
        }

        var headScripts = _lastScript.HeadScripts.Where(ShouldIncludeItem).ToArray();
        var bufferedRun = IsBufferedRunEnabled(processModel.Parameters);
        using var queueCountLogger = CQueueCountLogger.Create(this, processModel.RecipeId, bufferedRun, headScripts);
        using var scannerStatusLogger = CScannerStatusLogger.Create(this, processModel.RecipeId, bufferedRun, processModel.Parameters, headScripts);
        var stopTasksOnExit = false;
        _snapshot = CreateSnapshot(_snapshot.ProcessModel, runningPreview, EN_SCRIPT_STATUS.Running, EN_PROCESS_STEP.Process, null);
        try
        {
            if (bufferedRun)
            {
                queueCountLogger.Start();
                scannerStatusLogger.Start();
                RunBufferedHeadScripts(processModel, headScripts, cancellationToken);
            }
            else
            {
                foreach (var headScript in headScripts)
                {
                    AddProcessLog("INFO", "A1_RUN", $"Automation1 #{headScript.AutomationNo} Task {headScript.TaskNo} run requested. H{headScript.HeadNo:00}, {headScript.FileName}");
                    var response = _automationManager.RunScript(headScript.FileName, headScript.TaskNo, headScript.AutomationNo, cancellationToken: cancellationToken).GetAwaiter().GetResult();
                    AddProcessLog("INFO", "A1_RUN", $"Run command accepted. H{headScript.HeadNo:00}, Automation1 #{headScript.AutomationNo}, Task {headScript.TaskNo}: {response}");
                }

                queueCountLogger.Start();
                scannerStatusLogger.Start();
                WaitAutomationHeadScriptsComplete(processModel, headScripts, cancellationToken);
            }
        }
        catch
        {
            stopTasksOnExit = !bufferedRun;
            throw;
        }
        finally
        {
            scannerStatusLogger.StopAndWriteFinal();
            queueCountLogger.StopAndWriteFinal();
            if (stopTasksOnExit)
            {
                StopAutomationScriptTasks(headScripts, "scanner process ended before task completion");
            }
        }
    }

    private void RunBufferedHeadScripts(ST_PROCESS_MODEL processModel, IReadOnlyList<ST_HEAD_SCRIPT_RESULT> headScripts, CancellationToken cancellationToken)
    {
        var queueSize = ReadBufferedRunQueueSize(processModel.Parameters);
        var linesPerCommand = ReadBufferedRunLinesPerCommand(processModel.Parameters);
        var timeoutMs = ReadBufferedRunTimeoutMs(processModel.Parameters);
        int SelectAutomationNo(global::Drilling.Common.Station.ST_HEAD_SCRIPT_RESULT script)
        {
            return script.AutomationNo;
        }

        var groups = headScripts.GroupBy(SelectAutomationNo).ToArray();
        string SelectItem(global::Drilling.Common.Station.ST_HEAD_SCRIPT_RESULT script)
        {
            return $"H{script.HeadNo:00}/T{script.TaskNo}";
        }

        foreach (var group in groups)
        {
            AddProcessLog("INFO", "A1_RUN", $"Automation1 #{group.Key} buffered run group requested. Heads={string.Join(", ", group.Select(SelectItem))}, Queue={queueSize}, LinesPerCommand={linesPerCommand}, TimeoutMs={timeoutMs}");
        }

        using var bufferedRunCancellation = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        var workers = groups.Select(group => new CBufferedRunWorker(this, group.Key, group.ToArray(), queueSize, linesPerCommand, timeoutMs, bufferedRunCancellation.Token)).ToArray();
        var results = new List<ST_BUFFERED_RUN_GROUP_RESULT>();
        Exception? firstException = null;
        foreach (var worker in workers)
        {
            worker.Start();
        }

        try
        {
            var completedWorkers = new HashSet<CBufferedRunWorker>();
            while (completedWorkers.Count < workers.Length)
            {
                cancellationToken.ThrowIfCancellationRequested();
                foreach (var worker in workers)
                {
                    if (completedWorkers.Contains(worker) || !worker.IsComplete)
                    {
                        continue;
                    }

                    completedWorkers.Add(worker);
                    if (worker.Error is not null)
                    {
                        firstException = worker.Error;
                        AddProcessLog("ERROR", "A1_RUN", $"Buffered run group failed. {firstException.Message}");
                        break;
                    }

                    if (worker.Result is not null)
                    {
                        results.Add(worker.Result);
                    }
                }

                if (firstException is not null)
                {
                    break;
                }

                if (completedWorkers.Count < workers.Length)
                {
                    Thread.Sleep(10);
                }
            }
        }
        catch (OperationCanceledException)when (cancellationToken.IsCancellationRequested)
        {
            var stopException = new OperationCanceledException("Automation1 buffered run canceled by station stop.", cancellationToken);
            bufferedRunCancellation.Cancel();
            WaitForBufferedRunWorkers(workers, 5000, "station stop");
            StopBufferedRunTasks(headScripts, stopException);
            WaitForBufferedRunWorkers(workers, 5000, "station stop fallback");
            throw;
        }

        if (firstException is not null)
        {
            bufferedRunCancellation.Cancel();
            StopBufferedRunTasks(headScripts, firstException);
            WaitForBufferedRunWorkers(workers, 3000, "failure cleanup");

            ExceptionDispatchInfo.Capture(firstException).Throw();
        }

        foreach (var result in results)
        {
            AddProcessLog("INFO", "A1_RUN", $"Buffered run completed. Automation1 #{result.AutomationNo}, Heads={result.HeadSummary}: {result.Response}");
        }
    }

    private void WaitForBufferedRunWorkers(IReadOnlyList<CBufferedRunWorker> workers, int timeoutMs, string reason)
    {
        var startedAt = Environment.TickCount64;
        foreach (var worker in workers)
        {
            if (worker.IsComplete)
            {
                continue;
            }

            var elapsedMs = Environment.TickCount64 - startedAt;
            var remainingTimeoutMs = Math.Max(0, timeoutMs - (int)Math.Min(timeoutMs, elapsedMs));
            if (remainingTimeoutMs > 0 && worker.WaitForCompletion(remainingTimeoutMs))
            {
                continue;
            }

            if (worker.IsComplete)
            {
                continue;
            }

            AddProcessLog("WARN", "A1_RUN", $"Buffered run worker did not finish during {reason}. Automation1 #{worker.AutomationNo}");
        }
    }

    private void WaitAutomationHeadScriptsComplete(ST_PROCESS_MODEL processModel, IReadOnlyList<ST_HEAD_SCRIPT_RESULT> headScripts, CancellationToken cancellationToken)
    {
        var targets = CreateAutomationTaskTargets(headScripts);
        if (targets.Count == 0)
        {
            return;
        }

        var timeoutMs = ReadScriptRunTimeoutMs(processModel.Parameters);
        var pollIntervalMs = ReadScriptRunPollIntervalMs(processModel.Parameters);
        var startedAt = Environment.TickCount64;
        global::Drilling.Common.Station.CStationProcess.ST_AUTOMATION_TASK_KEY BuildAutomation(global::Drilling.Common.Station.CStationProcess.ST_AUTOMATION_TASK_TARGET target)
        {
            return new ST_AUTOMATION_TASK_KEY(target.AutomationNo, target.TaskNo);
        }

        var pendingTargets = targets.ToDictionary(BuildAutomation);
        while (pendingTargets.Count > 0)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (ReadSequenceState() == EN_STATION_SEQUENCE.Stop)
            {
                throw new OperationCanceledException(cancellationToken);
            }

            foreach (var target in pendingTargets.Values.ToArray())
            {
                var response = _automationManager.ReadTaskStatus(target.TaskNo, target.AutomationNo, cancellationToken).GetAwaiter().GetResult();
                var status = ParseAutomationTaskStatus(response);
                if (status.TaskNo != target.TaskNo)
                {
                    throw new InvalidOperationException($"Automation1 task status response task mismatch. Expected={target.TaskNo}, Response={status.RawResponse}");
                }

                if (IsAutomationTaskComplete(status.State))
                {
                    pendingTargets.Remove(new ST_AUTOMATION_TASK_KEY(target.AutomationNo, target.TaskNo));
                    AddProcessLog("INFO", "A1_RUN", $"Automation1 #{target.AutomationNo} Task {target.TaskNo} completed. Heads={target.HeadSummary}, State={status.State}");
                    continue;
                }

                if (IsAutomationTaskFailed(status.State))
                {
                    throw new InvalidOperationException($"Automation1 task failed. Automation1=#{target.AutomationNo}, Task={target.TaskNo}, Heads={target.HeadSummary}, State={status.State}, Error={status.ErrorMessage}");
                }
            }

            if (pendingTargets.Count == 0)
            {
                return;
            }

            if (timeoutMs > 0)
            {
                var elapsedMs = Environment.TickCount64 - startedAt;
                if (elapsedMs >= timeoutMs)
                {
                    throw new TimeoutException($"Automation1 task completion timeout. TimeoutMs={timeoutMs}, Pending={FormatAutomationTaskTargets(pendingTargets.Values)}");
                }

                cancellationToken.WaitHandle.WaitOne((int)Math.Min(pollIntervalMs, Math.Max(1, timeoutMs - elapsedMs)));
            }
            else
            {
                cancellationToken.WaitHandle.WaitOne(pollIntervalMs);
            }
        }
    }

    private void StopAutomationScriptTasks(IReadOnlyList<ST_HEAD_SCRIPT_RESULT> headScripts, string reason)
    {
        var targets = CreateAutomationTaskTargets(headScripts);
        if (targets.Count == 0)
        {
            return;
        }

        AddProcessLog("WARN", "A1_RUN", $"Stopping Automation1 tasks. Reason={reason}, Targets={FormatAutomationTaskTargets(targets)}");
        foreach (var target in targets)
        {
            try
            {
                var response = _automationManager.StopTask(target.TaskNo, target.AutomationNo, CancellationToken.None).GetAwaiter().GetResult();
                AddProcessLog("WARN", "A1_RUN", $"Automation1 task stop requested. Automation1 #{target.AutomationNo}, Task {target.TaskNo}, Heads={target.HeadSummary}: {response}");
            }
            catch (Exception exception)
            {
                AddProcessLog("ERROR", "A1_RUN", $"Automation1 task stop failed. Automation1 #{target.AutomationNo}, Task {target.TaskNo}, Heads={target.HeadSummary}: {exception.Message}");
            }
        }

        WaitAutomationScriptTasksStopped(targets);
    }

    private void WaitAutomationScriptTasksStopped(IReadOnlyList<ST_AUTOMATION_TASK_TARGET> targets)
    {
        foreach (var target in targets)
        {
            try
            {
                WaitAutomationScriptTaskStopped(target);
                AddProcessLog("INFO", "A1_RUN", $"Automation1 task stopped. Automation1 #{target.AutomationNo}, Task {target.TaskNo}, Heads={target.HeadSummary}");
            }
            catch (Exception exception)
            {
                AddProcessLog("ERROR", "A1_RUN", $"Automation1 task stop confirmation failed. Automation1 #{target.AutomationNo}, Task {target.TaskNo}, Heads={target.HeadSummary}: {exception.Message}");
            }
        }
    }

    private void WaitAutomationScriptTaskStopped(ST_AUTOMATION_TASK_TARGET target)
    {
        var startedAt = Environment.TickCount64;
        while (true)
        {
            using var statusTimeout = new CancellationTokenSource(EncoderScaleReleaseTimeoutMs);
            var response = _automationManager.ReadTaskStatus(target.TaskNo, target.AutomationNo, statusTimeout.Token).GetAwaiter().GetResult();
            var status = ParseAutomationTaskStatus(response);
            if (status.TaskNo != target.TaskNo)
            {
                throw new InvalidOperationException($"Automation1 task status response task mismatch. Expected={target.TaskNo}, Response={status.RawResponse}");
            }

            if (IsAutomationTaskComplete(status.State) || IsAutomationTaskFailed(status.State))
            {
                return;
            }

            var elapsedMs = Environment.TickCount64 - startedAt;
            if (elapsedMs >= EncoderScaleReleaseTimeoutMs)
            {
                throw new TimeoutException($"Automation1 task did not stop after StopTask. State={status.State}, Response={status.RawResponse}");
            }

            Thread.Sleep((int)Math.Min(ScriptRunDefaultPollIntervalMs, Math.Max(1, EncoderScaleReleaseTimeoutMs - elapsedMs)));
        }
    }

    private static IReadOnlyList<ST_AUTOMATION_TASK_TARGET> CreateAutomationTaskTargets(IReadOnlyList<ST_HEAD_SCRIPT_RESULT> headScripts)
    {
        bool ShouldIncludeItem(global::Drilling.Common.Station.ST_HEAD_SCRIPT_RESULT script)
        {
            return script.TotalShots > 0;
        }

        return headScripts.Where(ShouldIncludeItem).GroupBy(script => new { script.AutomationNo, script.TaskNo }).Select(group => new ST_AUTOMATION_TASK_TARGET(group.Key.AutomationNo, group.Key.TaskNo, string.Join(", ", group.Select(script => $"H{script.HeadNo:00}")))).ToArray();
    }

    private static ST_AUTOMATION_TASK_STATUS ParseAutomationTaskStatus(string response)
    {
        var automationError = FormatAutomationErrorResponse(response);
        if (!string.IsNullOrWhiteSpace(automationError))
        {
            throw new InvalidOperationException($"Automation1 task status response failed: {automationError}");
        }

        var fields = response.Split(':');
        if (fields.Length < 4 || !fields[0].Equals("OK", StringComparison.OrdinalIgnoreCase) || !fields[1].Equals("TASK", StringComparison.OrdinalIgnoreCase) || !int.TryParse(fields[2], NumberStyles.Integer, CultureInfo.InvariantCulture, out var taskNo))
        {
            throw new InvalidOperationException($"Automation1 task status response is invalid: {response}");
        }

        return new ST_AUTOMATION_TASK_STATUS(taskNo, fields[3].Trim(), fields.Length > 4 ? fields[4].Trim() : "", fields.Length > 5 ? string.Join(":", fields.Skip(5)).Trim() : "", response);
    }

    private ST_AUTOMATION_TASK_LINE_STATUS ReadAutomationTaskLineStatus(int automationNo, int taskNo, CancellationToken cancellationToken)
    {
        var response = _automationManager.ReadTaskLineStatus(taskNo, automationNo, cancellationToken).GetAwaiter().GetResult();
        return ParseAutomationTaskLineStatus(response);
    }

    private static ST_AUTOMATION_TASK_LINE_STATUS ParseAutomationTaskLineStatus(string response)
    {
        var automationError = FormatAutomationErrorResponse(response);
        if (!string.IsNullOrWhiteSpace(automationError))
        {
            throw new InvalidOperationException($"Automation1 task line status response failed: {automationError}");
        }

        var fields = response.Split(':');
        if (fields.Length < 4 || !fields[0].Equals("OK", StringComparison.OrdinalIgnoreCase) || !fields[1].Equals("TASK_LINE", StringComparison.OrdinalIgnoreCase) || !int.TryParse(fields[2], NumberStyles.Integer, CultureInfo.InvariantCulture, out var taskNo) || !int.TryParse(fields[3], NumberStyles.Integer, CultureInfo.InvariantCulture, out var currentLine))
        {
            throw new InvalidOperationException($"Automation1 task line status response is invalid: {response}");
        }

        return new ST_AUTOMATION_TASK_LINE_STATUS(taskNo, Math.Max(0, currentLine), response);
    }

    private static string FormatAutomationErrorResponse(string response)
    {
        if (string.IsNullOrWhiteSpace(response))
        {
            return "";
        }

        var fields = response.Trim().Split(':', 4, StringSplitOptions.TrimEntries);
        if (fields.Length >= 4 && fields[0].Equals("ERROR", StringComparison.OrdinalIgnoreCase) && fields[1].Equals("AUTOMATION1", StringComparison.OrdinalIgnoreCase))
        {
            return $"{fields[2]}: {fields[3]}";
        }

        return "";
    }

    private static bool IsAutomationTaskComplete(string state)
    {
        return state.Equals("Idle", StringComparison.OrdinalIgnoreCase) || state.Equals("ProgramComplete", StringComparison.OrdinalIgnoreCase);
    }

    private static bool IsAutomationTaskFailed(string state)
    {
        return state.Equals("Error", StringComparison.OrdinalIgnoreCase) || state.Equals("Unavailable", StringComparison.OrdinalIgnoreCase) || state.Equals("Inactive", StringComparison.OrdinalIgnoreCase);
    }

    private static string FormatAutomationTaskTargets(IEnumerable<ST_AUTOMATION_TASK_TARGET> targets)
    {
        string SelectItem(global::Drilling.Common.Station.CStationProcess.ST_AUTOMATION_TASK_TARGET target)
        {
            return $"Automation1 #{target.AutomationNo}/Task {target.TaskNo}/Heads={target.HeadSummary}";
        }

        return string.Join(", ", targets.Select(SelectItem));
    }

    private ST_BUFFERED_RUN_GROUP_RESULT RunBufferedHeadScriptGroup(int automationNo, IReadOnlyList<ST_HEAD_SCRIPT_RESULT> headScripts, int queueSize, int linesPerCommand, int timeoutMs, CancellationToken cancellationToken)
    {
        global::Drilling.Common.Automation.ST_BUFFERED_SCRIPT_RUN_ITEM BuildBuffered(global::Drilling.Common.Station.ST_HEAD_SCRIPT_RESULT script)
        {
            return new ST_BUFFERED_SCRIPT_RUN_ITEM(script.FilePath, script.FileName, script.TaskNo);
        }

        var response = _automationManager.RunBufferedScripts(headScripts.Select(BuildBuffered).ToArray(), automationNo, queueSize, linesPerCommand, timeoutMs, cancellationToken).GetAwaiter().GetResult();
        string SelectItem(global::Drilling.Common.Station.ST_HEAD_SCRIPT_RESULT script)
        {
            return $"H{script.HeadNo:00}/T{script.TaskNo}";
        }

        return new ST_BUFFERED_RUN_GROUP_RESULT(automationNo, string.Join(", ", headScripts.Select(SelectItem)), response);
    }

    private void StopBufferedRunTasks(IReadOnlyList<ST_HEAD_SCRIPT_RESULT> headScripts, Exception cause)
    {
        bool ShouldIncludeItem(global::Drilling.Common.Station.ST_HEAD_SCRIPT_RESULT script)
        {
            return script.TotalShots > 0;
        }

        var targets = headScripts.Where(ShouldIncludeItem).GroupBy(script => new { script.AutomationNo, script.TaskNo }).Select(group => new { group.Key.AutomationNo, group.Key.TaskNo, HeadSummary = string.Join(", ", group.Select(script => $"H{script.HeadNo:00}")) }).ToArray();
        AddProcessLog("WARN", "A1_RUN", $"Stopping buffered run tasks after failure. Reason={cause.Message}, Targets={targets.Length}");
        var stopResults = targets.Select(target =>
        {
            try
            {
                var response = _automationManager.StopTask(target.TaskNo, target.AutomationNo, CancellationToken.None).GetAwaiter().GetResult();
                return new ST_BUFFERED_RUN_STOP_RESULT(target.AutomationNo, target.TaskNo, target.HeadSummary, true, response, "");
            }
            catch (Exception ex)
            {
                return new ST_BUFFERED_RUN_STOP_RESULT(target.AutomationNo, target.TaskNo, target.HeadSummary, false, "", ex.Message);
            }
        }).ToArray();
        foreach (var stopResult in stopResults)
        {
            if (stopResult.IsSuccess)
            {
                AddProcessLog("WARN", "A1_RUN", $"Buffered run stop requested. Automation1 #{stopResult.AutomationNo}, Task {stopResult.TaskNo}, Heads={stopResult.HeadSummary}: {stopResult.Response}");
            }
            else
            {
                AddProcessLog("ERROR", "A1_RUN", $"Buffered run stop failed. Automation1 #{stopResult.AutomationNo}, Task {stopResult.TaskNo}, Heads={stopResult.HeadSummary}: {stopResult.ErrorMessage}");
            }
        }
    }

    private void RunReviewStep(ST_PROCESS_MODEL processModel, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        AddProcessLog("INFO", "REVIEW", "Review step reserved. Stage PC Y move, Vision X move, and Vision measure will be connected later.");
    }

    private void RunPowerCheckStep(ST_PROCESS_MODEL processModel, CancellationToken cancellationToken)
    {
        var powerMeterStatus = _interfaceManager.GetPowerMeterStatus(cancellationToken);
        AddProcessLog("INFO", "POWER", $"Power check step reserved. Current power={powerMeterStatus.MeasuredPower.ToString("F4", CultureInfo.InvariantCulture)} {powerMeterStatus.Unit}");
    }

    private void CompleteProcess(CancellationToken cancellationToken)
    {
        var scriptStatus = GetCurrentScriptStatusForComplete();
        if (scriptStatus == EN_SCRIPT_STATUS.Completed)
        {
            _scriptCompletedAt = DateTimeOffset.Now;
            AddProcessLog("INFO", "A1_TASK", "Automation1 task completed.");
        }
        else
        {
            AddProcessLog("INFO", "A1_TASK", "Automation1 script was not executed. PROCESS step was skipped.");
        }

        var processExecuted = scriptStatus == EN_SCRIPT_STATUS.Completed;
        global::Drilling.Common.Station.ST_HEAD_PREVIEW_DATA SelectItem(global::Drilling.Common.Station.ST_HEAD_PREVIEW_DATA head)
        {
            return head with
            {
                Status = EN_HEAD_PROCESS_STATUS.Disabled
            };
        }

        var completedPreview = processExecuted ? SetHeadStatus(_snapshot.HeadPreviews, EN_PROCESS_STEP.Completed) : _snapshot.HeadPreviews.Select(SelectItem).ToArray();
        _statistics = BuildStatistics(_snapshot.ProcessModel, processExecuted ? 100.0 : _statistics.ProgressPercent, processExecuted ? TimeSpan.FromSeconds(80) : _statistics.ElapsedTime);
        var result = processExecuted ? new ST_PROCESS_RESULT(true, "Station PROCESS completed.", DateTimeOffset.Now, "OK") : new ST_PROCESS_RESULT(true, "Station PROCESS skipped by setting option.", DateTimeOffset.Now, "SKIPPED");
        CompleteProduct(result, processExecuted, cancellationToken);
        ReportProcessResult(result, processExecuted ? "COMPLETE" : "SKIP", cancellationToken, EN_STATION_STATE.Complete);
        _snapshot = CreateSnapshot(_snapshot.ProcessModel, completedPreview, scriptStatus, EN_PROCESS_STEP.Completed, result);
        SetStationState(EN_STATION_STATE.Complete, EN_PROCESS_STEP.Completed, scriptStatus, "Process station completed.");
    }

    public ST_STATION_PROCESS_STATUS Stop(CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        lock (_sequenceLock)
        {
            if (_manualMofRunning || _manualMofRequiresStop)
            {
                _ = StopManualMofAsync().ContinueWith(task =>
                {
                    if (task.Exception is { } error) AddProcessLog("ERROR", "MANUAL_MOF_STOP", error.GetBaseException().Message);
                }, TaskScheduler.Default);
                return _snapshot;
            }
        }
        lock (_sequenceLock)
        {
            _sequenceCancellation?.Cancel();
            _sequenceState = EN_STATION_SEQUENCE.Stop;
            _stationStatus = (_stationStatus with
            {
                ChangedAt = DateTimeOffset.Now
            }).WithSequenceState(EN_STATION_SEQUENCE.Stop);
        }

        base.Start(10, "StationProcess");
        return _snapshot;
    }

    private ST_STATION_PROCESS_STATUS ProcessStop(CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (ReadStationStatus().State == EN_STATION_STATE.Stopped)
        {
            return _snapshot;
        }

        AddProcessLog("WARN", "OPERATOR", "Station PROCESS stopped by operator.");
        if (_lastScript is not null && _snapshot.ScriptStatus == EN_SCRIPT_STATUS.Running)
        {
            StopAutomationScriptTasks(_lastScript.HeadScripts, "operator stop requested");
        }

        _statistics = BuildStatistics(_snapshot.ProcessModel, _statistics.ProgressPercent, _statistics.ElapsedTime);
        var result = new ST_PROCESS_RESULT(false, "Station PROCESS stopped by operator.", DateTimeOffset.Now);
        TryStopProduct(result.Message, cancellationToken);
        TryReportProcessResult(result, "STOP", cancellationToken, EN_STATION_STATE.Stopped);
        _snapshot = CreateSnapshot(_snapshot.ProcessModel, SetHeadStatus(_snapshot.HeadPreviews, EN_PROCESS_STEP.Stopped), EN_SCRIPT_STATUS.NotCreated, EN_PROCESS_STEP.Stopped, result);
        MarkRunningAutoSteps(AutoStepStop);
        RefreshSnapshot();
        SetStationState(EN_STATION_STATE.Stopped, EN_PROCESS_STEP.Stopped, EN_SCRIPT_STATUS.NotCreated, "Station stopped by operator.");
        return _snapshot;
    }

    public ST_STATION_PROCESS_STATUS Reset(CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        lock (_sequenceLock)
        {
            if (_manualMofRunning || _manualMofRequiresStop || _sequenceState != EN_STATION_SEQUENCE.Ready || _stationStatus.State == EN_STATION_STATE.Process)
            {
                AddProcessLog("WARN", "RESET", "Reset ignored while station is running.");
                RefreshSnapshot();
                return _snapshot;
            }

            _sequenceState = EN_STATION_SEQUENCE.Reset;
            _stationStatus = (_stationStatus with
            {
                ChangedAt = DateTimeOffset.Now
            }).WithSequenceState(EN_STATION_SEQUENCE.Reset);
        }

        base.Start(10, "StationProcess");
        return _snapshot;
    }

    private ST_STATION_PROCESS_STATUS ProcessReset(CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var stationStatus = ReadStationStatus();
        if (stationStatus.State == EN_STATION_STATE.Alarm)
        {
            var interLock = GetInterLockSummary(cancellationToken);
            if (!interLock.CanAutoRun)
            {
                var message = FormatInterLockBlockedMessage(interLock);
                AddProcessLog("WARN", "RESET", $"Reset blocked. {message}");
                SetSequenceState(EN_STATION_SEQUENCE.Error);
                _snapshot = CreateSnapshot(_snapshot.ProcessModel, SetHeadStatus(_snapshot.HeadPreviews, EN_PROCESS_STEP.Error), EN_SCRIPT_STATUS.Error, EN_PROCESS_STEP.Error, new ST_PROCESS_RESULT(false, message, DateTimeOffset.Now));
                SetStationState(EN_STATION_STATE.Alarm, EN_PROCESS_STEP.Error, EN_SCRIPT_STATUS.Error, $"Reset blocked. {message}");
                return _snapshot;
            }

            AddProcessLog("INFO", "RESET", "Alarm reset accepted. InterLock is clear.");
        }

        ClearProcessLogs();
        _lastInterLockItems = [];
        _scriptCreatedAt = null;
        _scriptStartedAt = null;
        _scriptCompletedAt = null;
        _lastScript = null;
        _processModel = null;
        ResetAutoStepStates();
        _statistics = EmptyStatistics();
        _snapshot = CreateSnapshot(null, [], EN_SCRIPT_STATUS.NotCreated, EN_PROCESS_STEP.Idle, null);
        SetStationState(EN_STATION_STATE.Idle, EN_PROCESS_STEP.Idle, EN_SCRIPT_STATUS.NotCreated, "Station reset to idle.");
        SetSequenceState(EN_STATION_SEQUENCE.Ready);
        return _snapshot;
    }

    private ST_STATION_PROCESS_STATUS CreateSnapshot(ST_PROCESS_MODEL? processModel, IReadOnlyList<ST_HEAD_PREVIEW_DATA> preview, EN_SCRIPT_STATUS scriptStatus, EN_PROCESS_STEP processStep, ST_PROCESS_RESULT? result)
    {
        return new ST_STATION_PROCESS_STATUS(processModel, preview, scriptStatus, processStep, result, BuildProcessSequence(scriptStatus, processStep), BuildCurrentStepDetails(processModel, scriptStatus, processStep), BuildProcessSummary(processModel, _statistics), GetProcessLogsSnapshot(), BuildScriptStatusItems(processModel, scriptStatus, result), BuildScriptLifecycleItems(scriptStatus, processStep), _lastInterLockItems, _statistics);
    }

    private ST_INTERLOCK_SUMMARY GetInterLockSummary(CancellationToken cancellationToken, ST_PROCESS_MODEL? processModel = null)
        => EvaluateInterlocks(processModel?.Parameters, cancellationToken);

    private ST_INTERLOCK_SUMMARY EvaluateInterlocks(IReadOnlyDictionary<string, string>? parameters, CancellationToken cancellationToken, bool cachedStatusOnly = false, bool publish = true)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var result = _interLockManager.Evaluate(GetDeviceStatus(cancellationToken, cachedStatusOnly));
        if (parameters is not null)
        {
            var optics = COpticInterlock.Evaluate(parameters, _interfaceManager.GetInterfaceList(),
                _interfaceManager.OpticSnapshots.GetLaser, _interfaceManager.OpticSnapshots.GetBet, _interfaceManager.AttenuatorSnapshots.GetSnapshot)
                .Concat(CDoeZInterlock.Evaluate(parameters, axis =>
                    _automationManager is not null && (_automationManager.IsSimul(axis.AutomationNo) || _automationManager.IsConnect(axis.AutomationNo))
                        ? _automationManager.StatusSnapshots.GetAxis(axis.AxisReference, axis.AutomationNo, axis.AioNo, axis.ReadExtendedStatus)
                        : new(null, "OFFLINE", "Automation controller is offline.", default)))
                .ToArray();
            result = result with { Items = result.Items.Concat(optics).ToArray(),
                CanAutoRun = result.CanAutoRun && optics.All(item => !item.BlocksAutoRun),
                HasError = result.HasError || optics.Any(item => item.Level == EN_INTERLOCK_LEVEL.Error) };
        }
        if (publish) _lastInterLockItems = result.Items;
        return result;
    }

    private ST_DEVICE_STATUS GetDeviceStatus(CancellationToken cancellationToken, bool cachedStatusOnly = false)
    {
        IReadOnlyList<ST_IO_STATUS> io = [];
        var motors = cachedStatusOnly ? _motionManager.GetCachedAxisStatus() : _motionManager.GetAxisStatus(cancellationToken);
        var laserNo = _interfaceManager.GetInterfaceList(EN_EQP_MODULE.TalonLaser).FirstOrDefault()?.Number ?? 0;
        var laserStatus = _interfaceManager.GetCachedLaserStatus(laserNo);
        var attenuatorStatus = _interfaceManager.GetAttenuatorStatus(cancellationToken);
        var betNo = _interfaceManager.GetInterfaceList(EN_EQP_MODULE.Bet).FirstOrDefault()?.Number ?? 0;
        var betStatus = _interfaceManager.GetCachedBetStatus(betNo);
        var powerMeterStatus = _interfaceManager.GetPowerMeterStatus(cancellationToken);
        return new ST_DEVICE_STATUS(io, motors, laserStatus, attenuatorStatus, betStatus, powerMeterStatus);
    }

    private void CompleteProduct(ST_PROCESS_RESULT result, bool processExecuted, CancellationToken cancellationToken)
    {
        var productId = GetCurrentProcessProductId();
        if (_productManager is null || string.IsNullOrWhiteSpace(productId))
        {
            return;
        }

        _productManager.CompleteProduct(productId, result.IsSuccess, processExecuted, result.Message, cancellationToken).GetAwaiter().GetResult();
        AddProcessLog("INFO", "PRODUCT", $"Product completed ({productId})");
    }

    private void StopProduct(string message, CancellationToken cancellationToken)
    {
        var productId = GetCurrentProcessProductId();
        if (_productManager is null || string.IsNullOrWhiteSpace(productId))
        {
            return;
        }

        _productManager.StopProduct(productId, message, cancellationToken).GetAwaiter().GetResult();
        AddProcessLog("WARN", "PRODUCT", $"Product stopped ({productId})");
    }

    private void TryStopProduct(string message, CancellationToken cancellationToken)
    {
        try
        {
            StopProduct(message, cancellationToken);
        }
        catch (Exception exception)when (IsTerminalCleanupException(exception))
        {
            AddSequenceLog("WARN", "PRODUCT", $"Product stop failed during station stop cleanup. {exception.Message}");
        }
    }

    private void SetProductError(string message, CancellationToken cancellationToken)
    {
        var productId = GetCurrentProcessProductId();
        if (_productManager is null || string.IsNullOrWhiteSpace(productId))
        {
            return;
        }

        _productManager.SetError(productId, message, cancellationToken).GetAwaiter().GetResult();
        AddProcessLog("ERROR", "PRODUCT", $"Product error ({productId})");
    }

    private void TrySetProductError(string message, CancellationToken cancellationToken)
    {
        try
        {
            SetProductError(message, cancellationToken);
        }
        catch (Exception exception)when (IsTerminalCleanupException(exception))
        {
            AddSequenceLog("WARN", "PRODUCT", $"Product error update failed during station alarm cleanup. {exception.Message}");
        }
    }

    private void ReportProcessResult(ST_PROCESS_RESULT result, string action, CancellationToken cancellationToken, EN_STATION_STATE? resultStationState = null)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var processId = _snapshot.ProcessModel?.ProcessId ?? "-";
        var recipeId = _snapshot.ProcessModel?.RecipeId ?? "-";
        var productId = GetCurrentProcessProductId() ?? processId;
        var reportState = GetProcessResultCode(result);
        var detail = FormatProcessResultDetail(result, processId, recipeId, productId);
        var hostNickName = _interfaceManager.GetInterfaceData(EN_EQP_MODULE.WonikCtrl, 0)?.NickName ?? "WONIK_CTRL";
        var stationStatus = ReadStationStatus();
        var stationState = resultStationState ?? stationStatus.State;
        AddProcessLog("INFO", "RESULT", $"{action} result reported. {detail}");
        _logManager?.WriteStationState(stationStatus.StationName, stationState.ToString().ToUpperInvariant(), $"RESULT_{action}", detail);
        _logManager?.WriteInterfaceCommand(EN_EQP_MODULE.WonikCtrl, hostNickName, $"PROCESS_RESULT_{action}", reportState, detail);
    }

    private void TryReportProcessResult(ST_PROCESS_RESULT result, string action, CancellationToken cancellationToken, EN_STATION_STATE resultStationState)
    {
        try
        {
            ReportProcessResult(result, action, cancellationToken, resultStationState);
        }
        catch (Exception exception)when (IsTerminalCleanupException(exception))
        {
            AddSequenceLog("WARN", "RESULT", $"{action} result report failed during station terminal cleanup. {exception.Message}");
        }
    }

    private static bool IsTerminalCleanupException(Exception exception)
    {
        return exception is InvalidOperationException or IOException or TimeoutException or KeyNotFoundException or OperationCanceledException or UnauthorizedAccessException;
    }

    private string? GetCurrentProcessProductId()
    {
        if (_productManager?.Current is null || _snapshot.ProcessModel is null)
        {
            return null;
        }

        return _productManager.Current.ProcessId.Equals(_snapshot.ProcessModel.ProcessId, StringComparison.OrdinalIgnoreCase) ? _productManager.Current.GlassId : null;
    }

    private static IReadOnlyList<ST_HEAD_PREVIEW_DATA> BuildPreview(ST_PROCESS_MODEL processModel, EN_HEAD_PROCESS_STATUS status)
    {
        global::Drilling.Common.Station.ST_HEAD_PREVIEW_DATA BuildHead(global::Drilling.Common.Station.ST_HEAD_PROCESS_PLAN head)
        {
            return new ST_HEAD_PREVIEW_DATA(head.HeadNo, status, head.Shots.Count);
        }

        return processModel.HeadPlans.Select(BuildHead).ToArray();
    }

    private IReadOnlyDictionary<string, string> BuildRuntimeParameters(string recipeId, IReadOnlyDictionary<string, string> sourceParameters, CancellationToken cancellationToken)
    {
        var parameters = new Dictionary<string, string>(sourceParameters, StringComparer.OrdinalIgnoreCase);
        var processSettings = new List<ST_SYSTEM_PARAMETER>();
        processSettings.AddRange(_settingManager.LoadSection(EN_SETTING_TAB.Option, cancellationToken));
        processSettings.AddRange(_settingManager.LoadSection(EN_SETTING_TAB.Motor, cancellationToken));
        foreach (var setting in processSettings)
        {
            if (string.IsNullOrWhiteSpace(setting.Key))
            {
                continue;
            }

            parameters[setting.Key] = setting.Value;
        }

        RemoveRecipeReviewOffsetParameters(parameters);
        MergeLatestReviewOffsets(recipeId, parameters, cancellationToken);
        return parameters;
    }

    private static void RemoveRecipeReviewOffsetParameters(IDictionary<string, string> parameters)
    {
        var keys = parameters.Keys
            .Where(key => key.Contains("REVIEW_OFFSET", StringComparison.OrdinalIgnoreCase))
            .ToArray();
        foreach (var key in keys)
        {
            parameters.Remove(key);
        }
    }

    private void MergeLatestReviewOffsets(string recipeId, IDictionary<string, string> parameters, CancellationToken cancellationToken)
    {
        if (_reviewOffsetFile is null)
        {
            return;
        }

        var reviewOffset = _reviewOffsetFile.LoadLatest(recipeId, cancellationToken).GetAwaiter().GetResult();
        if (reviewOffset.Rows.Count == 0)
        {
            return;
        }

        CReviewOffsetData.ApplyToParameters(parameters, reviewOffset);

        AddProcessLog("INFO", "REVIEW_OFFSET", $"Loaded latest Review Offset file: {reviewOffset.FileName} ({reviewOffset.Rows.Count} rows)");
    }

    private static string NormalizeReviewOffsetShotId(string value)
    {
        return (value ?? "")
            .Trim()
            .Replace("-", "_", StringComparison.Ordinal)
            .Replace(".", "_", StringComparison.Ordinal)
            .ToUpperInvariant();
    }

    private static ST_PROCESS_MODEL BuildProcessModel(string processId, string recipeId, string glassId, string lotId, IReadOnlyDictionary<string, string> sourceParameters)
    {
        var parameters = new Dictionary<string, string>(sourceParameters, StringComparer.OrdinalIgnoreCase);
        var coordinatePlan = CShotCoordinatePlanBuilder.Build(parameters);
        var shotMaskingPlan = CRecipeShotMaskingPlan.Build(parameters);
        var processShots = coordinatePlan.Shots
            .Where(shot => !shotMaskingPlan.EvaluateShot(shot).IsChessSkipped)
            .Select((shot, index) => shot with { SequenceNo = index + 1 })
            .ToArray();
        var defaultMarkSpeed = ReadDoubleAny(parameters, 900.0, "SCANNER_MARK_SPEED");
        var defaultJumpSpeed = ReadDoubleAny(parameters, 1500.0, "SCANNER_JUMP_SPEED");
        int SelectHeadNo(global::Drilling.Common.Recipe.ST_HEAD_SHOT_POINT shot)
        {
            return shot.HeadNo;
        }

        int SelectKey(global::System.Linq.IGrouping<int, global::Drilling.Common.Recipe.ST_HEAD_SHOT_POINT> group)
        {
            return group.Key;
        }

        global::Drilling.Common.Recipe.ST_HEAD_SHOT_POINT[] SelectValue(global::System.Linq.IGrouping<int, global::Drilling.Common.Recipe.ST_HEAD_SHOT_POINT> group)
        {
            return group.ToArray();
        }

        var shotsByHead = processShots.GroupBy(SelectHeadNo).ToDictionary(SelectKey, SelectValue, EqualityComparer<int>.Default);
        var activeHeadNos = new List<int>(coordinatePlan.HeadCount);
        for (var headNo = 1; headNo <= coordinatePlan.HeadCount; headNo++)
        {
            if (ReadHeadUse(parameters, headNo))
            {
                activeHeadNos.Add(headNo);
            }
        }

        if (activeHeadNos.Count == 0)
        {
            throw new InvalidOperationException("At least one head must be enabled. Check Hxx_USE option settings.");
        }

        global::Drilling.Common.Station.ST_HEAD_PROCESS_PLAN BuildHead(int headNo)
        {
            var headShots = shotsByHead.TryGetValue(headNo, out var values) ? values : [];
            var scannerMarkSpeed = ReadDoubleAny(parameters, defaultMarkSpeed, CreateHeadKeys(headNo, "SCANNER_MARK_SPEED"));
            var scannerJumpSpeed = ReadDoubleAny(parameters, defaultJumpSpeed, CreateHeadKeys(headNo, "SCANNER_JUMP_SPEED"));
            var scannerXRampRate = ReadDoubleAny(parameters, 30000.0, CreateHeadKeys(headNo, "SCANNER_X_RAMP_RATE", "SCANNER_RAMP_RATE"));
            var scannerYRampRate = ReadDoubleAny(parameters, scannerXRampRate, CreateHeadKeys(headNo, "SCANNER_Y_RAMP_RATE", "SCANNER_RAMP_RATE"));
            var scannerZRampRate = ReadDoubleAny(parameters, scannerYRampRate, CreateHeadKeys(headNo, "SCANNER_Z_RAMP_RATE"));
            var scannerZSpeed = ReadDoubleAny(parameters, scannerJumpSpeed, CreateHeadKeys(headNo, "SCANNER_Z_SPEED"));
            var scannerAccLimit = ReadDoubleAny(parameters, 100000.0, "SCAN_ACC_LIMIT", "SCANNER_ACC_LIMIT");
            return new ST_HEAD_PROCESS_PLAN(headNo, ReadDoubleAny(parameters, 1.0, CreateHeadKeys(headNo, "LASER_POWER")), ReadDoubleAny(parameters, 20.0, CreateHeadKeys(headNo, "LASER_FREQUENCY")), ReadIntAny(parameters, 10, CreateHeadKeys(headNo, "SHOT_COUNT")), scannerMarkSpeed, scannerJumpSpeed, scannerXRampRate, scannerYRampRate, scannerZRampRate, scannerZSpeed, scannerAccLimit, ReadDoubleAny(parameters, 0.0, CreateHeadKeys(headNo, "DOE_Z_POSITION")), headShots)
            {
                AutomationNo = ReadHeadAutomationNo(parameters, headNo),
                TaskNo = ReadHeadAutomationTaskNo(parameters, headNo),
                ScriptFileName = $"PROCESS_H{headNo:00}.ascript"};
        }

        var headPlans = activeHeadNos.Select(BuildHead).ToArray();
        return new ST_PROCESS_MODEL(processId, recipeId, glassId, lotId, headPlans, parameters, DateTimeOffset.Now);
    }

    private static IReadOnlyList<ST_HEAD_PREVIEW_DATA> SetHeadStatus(IReadOnlyList<ST_HEAD_PREVIEW_DATA> preview, EN_PROCESS_STEP processStep)
    {
        global::Drilling.Common.Station.ST_HEAD_PREVIEW_DATA SelectItem(global::Drilling.Common.Station.ST_HEAD_PREVIEW_DATA head)
        {
            var status = processStep switch
            {
                EN_PROCESS_STEP.Process => head.ShotCount > 0 ? EN_HEAD_PROCESS_STATUS.Running : EN_HEAD_PROCESS_STATUS.Disabled,
                EN_PROCESS_STEP.Completed => head.ShotCount > 0 ? EN_HEAD_PROCESS_STATUS.Completed : EN_HEAD_PROCESS_STATUS.Disabled,
                EN_PROCESS_STEP.Stopped => EN_HEAD_PROCESS_STATUS.Ready,
                EN_PROCESS_STEP.Error => EN_HEAD_PROCESS_STATUS.Error,
                _ => head.Status
            };
            return head with
            {
                Status = status
            };
        }

        return preview.Select(SelectItem).ToArray();
    }

    private IReadOnlyList<ST_PROCESS_DISPLAY_ITEM> BuildProcessSequence(EN_SCRIPT_STATUS scriptStatus, EN_PROCESS_STEP processStep)
    {
        global::Drilling.Common.Station.ST_PROCESS_DISPLAY_ITEM BuildProcess(global::Drilling.Common.Station.ST_STATION_PROCESS_FLOW_ITEM step)
        {
            return new ST_PROCESS_DISPLAY_ITEM(step.Order.ToString(CultureInfo.InvariantCulture), step.StepName, ReadAutoStepState(step.StepKey, scriptStatus, processStep));
        }

        return ProcessFlowItems.Select(BuildProcess).ToArray();
    }

    private IReadOnlyList<ST_PROCESS_DISPLAY_ITEM> BuildCurrentStepDetails(ST_PROCESS_MODEL? processModel, EN_SCRIPT_STATUS scriptStatus, EN_PROCESS_STEP processStep)
    {
        global::Drilling.Common.Station.ST_PROCESS_DISPLAY_ITEM BuildProcess(global::Drilling.Common.Station.CStationProcess.ST_AUTO_STEP_INFO step)
        {
            return new ST_PROCESS_DISPLAY_ITEM(step.DisplayName, AutoStepWait);
        }

        if (processModel is null)
        {
            return AutoStepInfos.Select(BuildProcess).ToArray();
        }

        global::Drilling.Common.Station.ST_PROCESS_DISPLAY_ITEM BuildProcess2(global::Drilling.Common.Station.CStationProcess.ST_AUTO_STEP_INFO step)
        {
            return new ST_PROCESS_DISPLAY_ITEM(step.DisplayName, ReadAutoStepState(step.Key, scriptStatus, processStep));
        }

        return AutoStepInfos.Select(BuildProcess2).ToArray();
    }

    private static IReadOnlyList<ST_PROCESS_DISPLAY_ITEM> BuildProcessSummary(ST_PROCESS_MODEL? processModel, ST_PROCESS_STATISTICS statistics)
    {
        var glassId = processModel?.GlassId ?? "-";
        return[new("Product Glass ID", string.IsNullOrWhiteSpace(glassId) ? "-" : glassId), new("Tact Time", FormatDuration(statistics.EstimatedTime))];
    }

    private IReadOnlyList<ST_PROCESS_DISPLAY_ITEM> BuildScriptStatusItems(ST_PROCESS_MODEL? processModel, EN_SCRIPT_STATUS scriptStatus, ST_PROCESS_RESULT? result)
    {
        var hasScript = processModel is not null && _lastScript is not null;
        string SelectFileName(global::Drilling.Common.Station.ST_HEAD_SCRIPT_RESULT script)
        {
            return script.FileName;
        }

        var scriptFiles = hasScript && _lastScript!.HeadScripts.Count > 0 ? string.Join(", ", _lastScript.HeadScripts.Select(SelectFileName)) : hasScript ? _lastScript!.FileName : "-";
        string SelectItem(global::Drilling.Common.Station.ST_HEAD_SCRIPT_RESULT script)
        {
            return script.TaskNo.ToString(CultureInfo.InvariantCulture);
        }

        var taskNumbers = hasScript && _lastScript!.HeadScripts.Count > 0 ? string.Join(", ", _lastScript.HeadScripts.Select(SelectItem)) : hasScript ? "1" : "-";
        return[new("Script Build", FormatScriptStatus(scriptStatus)), new("Script File", scriptFiles, hasScript ? _lastScript!.FilePath : ""), new("Task No", taskNumbers), new("Execute State", FormatExecuteState(scriptStatus, result, hasScript)), new("Created Time", FormatDateTime(_scriptCreatedAt)), new("Started Time", FormatDateTime(_scriptStartedAt)), new("Completed Time", FormatDateTime(_scriptCompletedAt)), new("Result", FormatScriptResult(scriptStatus, result, hasScript)), new("Error Code", result is { IsSuccess: false } ? "1" : "0")];
    }

    private static IReadOnlyList<ST_PROCESS_DISPLAY_ITEM> BuildScriptLifecycleItems(EN_SCRIPT_STATUS scriptStatus, EN_PROCESS_STEP processStep)
    {
        return[new("Not Created", LifecycleState(scriptStatus, processStep, 0)), new("Created", LifecycleState(scriptStatus, processStep, 1)), new("Started", LifecycleState(scriptStatus, processStep, 2)), new("Running", LifecycleState(scriptStatus, processStep, 3)), new("Completed", LifecycleState(scriptStatus, processStep, 4))];
    }

    private static ST_PROCESS_STATISTICS BuildStatistics(ST_PROCESS_MODEL? processModel, double progressPercent, TimeSpan elapsedTime)
    {
        int SelectValue(global::Drilling.Common.Station.ST_HEAD_PROCESS_PLAN head)
        {
            return head.Shots.Count;
        }

        var totalShots = processModel?.HeadPlans.Sum(SelectValue) ?? 0;
        return new ST_PROCESS_STATISTICS(totalShots, (int)Math.Round(totalShots * 0.60), (int)Math.Round(totalShots * 0.40), totalShots == 0 ? TimeSpan.Zero : TimeSpan.FromSeconds(80), elapsedTime, Math.Clamp(progressPercent, 0.0, 100.0));
    }

    private static ST_PROCESS_STATISTICS EmptyStatistics()
    {
        return new ST_PROCESS_STATISTICS(0, 0, 0, TimeSpan.Zero, TimeSpan.Zero, 0.0);
    }

    private void RefreshSnapshot()
    {
        _snapshot = CreateSnapshot(_snapshot.ProcessModel, _snapshot.HeadPreviews, _snapshot.ScriptStatus, _snapshot.ProcessStep, _snapshot.Result);
    }

    private void ResetAutoStepStates() => ResetAutoStepStatesCore(false);

    private void ResetAutoStepStatesCore(bool preserveSequenceActions)
    {
        if (!preserveSequenceActions) _sequenceActions.Reset();
        _autoStepStates.Clear();
        foreach (var step in AutoStepInfos)
        {
            _autoStepStates[step.Key] = AutoStepWait;
        }
    }

    private void SetAutoStepState(string stepKey, string state)
    {
        _autoStepStates[stepKey] = state;
    }

    private void MarkRunningAutoSteps(string state)
    {
        foreach (var step in AutoStepInfos)
        {
            if (_autoStepStates.TryGetValue(step.Key, out var currentState) && currentState == AutoStepRunning)
            {
                _autoStepStates[step.Key] = state;
            }
        }
    }

    private string ReadAutoStepState(string stepKey, EN_SCRIPT_STATUS scriptStatus, EN_PROCESS_STEP processStep)
    {
        if (_autoStepStates.TryGetValue(stepKey, out var state))
        {
            return state;
        }

        return (stepKey, scriptStatus, processStep) switch
        {
            (AutoStepProcess, EN_SCRIPT_STATUS.Created or EN_SCRIPT_STATUS.Running or EN_SCRIPT_STATUS.Completed, EN_PROCESS_STEP.Process) => AutoStepRunning,
            (AutoStepInspection, EN_SCRIPT_STATUS.Running, EN_PROCESS_STEP.Inspection) => AutoStepRunning,
            (AutoStepComplete, EN_SCRIPT_STATUS.Completed, EN_PROCESS_STEP.Completed) => AutoStepDone,
            _ => AutoStepWait
        };
    }

    private EN_SCRIPT_STATUS ResolveStepScriptStatus(string stepKey, EN_SCRIPT_STATUS defaultStatus)
    {
        if (stepKey.Equals(AutoStepComplete, StringComparison.OrdinalIgnoreCase))
        {
            return GetCurrentScriptStatusForComplete();
        }

        if (stepKey.Equals(AutoStepInspection, StringComparison.OrdinalIgnoreCase) && _lastScript is null)
        {
            return EN_SCRIPT_STATUS.NotCreated;
        }

        return defaultStatus;
    }

    private EN_SCRIPT_STATUS GetCurrentScriptStatusForComplete()
    {
        if (_lastScript is null)
        {
            return EN_SCRIPT_STATUS.NotCreated;
        }

        return _scriptStartedAt is null ? EN_SCRIPT_STATUS.Created : EN_SCRIPT_STATUS.Completed;
    }

    private static ST_STATION_PROCESS_FLOW_ITEM GetProcessFlowItem(string stepKey)
    {
        bool MatchesItem(global::Drilling.Common.Station.ST_STATION_PROCESS_FLOW_ITEM step)
        {
            return step.StepKey.Equals(stepKey, StringComparison.OrdinalIgnoreCase);
        }

        return ProcessFlowItems.FirstOrDefault(MatchesItem) ?? throw new InvalidOperationException($"Auto step is not defined: {stepKey}");
    }

    private static string GetAutoStepName(string stepKey)
    {
        bool MatchesItem(global::Drilling.Common.Station.CStationProcess.ST_AUTO_STEP_INFO step)
        {
            return step.Key == stepKey;
        }

        return AutoStepInfos.FirstOrDefault(MatchesItem)?.DisplayName ?? stepKey;
    }

    private static Dictionary<string, string> CreateAutoStepStateMap()
    {
        string SelectKey(global::Drilling.Common.Station.CStationProcess.ST_AUTO_STEP_INFO step)
        {
            return step.Key;
        }

        string SelectAutoStepWait(global::Drilling.Common.Station.CStationProcess.ST_AUTO_STEP_INFO arg0)
        {
            return AutoStepWait;
        }

        return AutoStepInfos.ToDictionary(SelectKey, SelectAutoStepWait, StringComparer.OrdinalIgnoreCase);
    }

    private static string LifecycleState(EN_SCRIPT_STATUS scriptStatus, EN_PROCESS_STEP processStep, int stepNo)
    {
        return (scriptStatus, processStep, stepNo) switch
        {
            (EN_SCRIPT_STATUS.NotCreated, _, 0) => "ACTIVE",
            (EN_SCRIPT_STATUS.Created, _, 0) => "DONE",
            (EN_SCRIPT_STATUS.Created, _, 1) => "ACTIVE",
            (EN_SCRIPT_STATUS.Running, _, <= 2) => "DONE",
            (EN_SCRIPT_STATUS.Running, _, 3) => "ACTIVE",
            (EN_SCRIPT_STATUS.Completed, _, _) => stepNo < 4 ? "DONE" : "ACTIVE",
            (EN_SCRIPT_STATUS.Error, _, _) => stepNo == 3 ? "ERROR" : "-",
            _ => "-"
        };
    }

    private static string FormatAttenuatorStatus(ST_ATTENUATOR_STATUS status)
    {
        return $"Current={FormatDouble(status.CurrentPosition)}, Target={FormatDouble(status.TargetPosition)}, State={status.CommandState}, Error={status.LastError}";
    }

    private static string FormatBETStatus(ST_BET_STATUS status)
    {
        return $"MAG={FormatDouble(status.CurrentMagnification)}/{FormatDouble(status.TargetMagnification)}, DIV={FormatDouble(status.CurrentDivergence)}/{FormatDouble(status.TargetDivergence)}, Moving={status.IsMoving}, Alarm={status.AlarmOn}, Error={status.LastError}";
    }

    private static string FormatCommState(EN_COMM_STATE state)
    {
        return state switch
        {
            EN_COMM_STATE.Online => "ONLINE",
            EN_COMM_STATE.Simulation => "SIMULATION",
            _ => "OFFLINE"
        };
    }

    private static string FormatInterfaceName(ST_INTERFACE_DATA data)
    {
        return $"{data.Device}[{data.Number}]/{data.NickName}";
    }

    private static string FormatInterfaceName(ST_INTERFACE_COMM_STATUS status)
    {
        return $"{status.Module}[{status.Number}]/{status.NickName}";
    }

    private static string FormatDouble(double value)
    {
        return value.ToString("F3", CultureInfo.InvariantCulture);
    }

    private static double ReadDirectionAny(IReadOnlyDictionary<string, string> parameters, double defaultValue, params string[] keys)
    {
        bool ShouldIncludeItem(string key)
        {
            return !string.IsNullOrWhiteSpace(key);
        }

        foreach (var key in keys.Where(ShouldIncludeItem))
        {
            if (!parameters.TryGetValue(key, out var value) || string.IsNullOrWhiteSpace(value))
            {
                continue;
            }

            return NormalizeDirection(value.Trim(), key);
        }

        return NormalizeDirection(defaultValue, "DEFAULT_DIRECTION");
    }

    private static double NormalizeDirection(string value, string key)
    {
        var normalized = value.Trim().ToUpperInvariant();
        if (double.TryParse(normalized, NumberStyles.Any, CultureInfo.InvariantCulture, out var number))
        {
            return NormalizeDirection(number, key);
        }

        if (normalized is "-" or "-1" or "REVERSE" or "REV" or "NEGATIVE" or "MINUS")
        {
            return -1.0;
        }

        if (normalized is "+" or "+1" or "FORWARD" or "FWD" or "POSITIVE" or "PLUS")
        {
            return 1.0;
        }

        throw new InvalidOperationException($"Invalid direction value. {key}={value}");
    }

    private static double NormalizeDirection(double value, string key)
    {
        if (!double.IsFinite(value) || (value != -1.0 && value != 1.0))
        {
            throw new InvalidOperationException($"Direction setting {key} must be -1 or +1. Current value: {value}");
        }

        return value;
    }

    private static string FormatCommand(string command, IReadOnlyList<(string Key, string Value)> arguments)
    {
        string SelectItem((string Key, string Value) argument)
        {
            return $"{argument.Key}={argument.Value}";
        }

        return string.Join(";", new[] { command }.Concat(arguments.Select(SelectItem)));
    }

    private static bool IsProcessControlSuccessResponse(string response)
    {
        if (string.IsNullOrWhiteSpace(response))
        {
            return false;
        }

        var firstToken = response.Trim().ToUpperInvariant().Split([';', '|', ':', ',', ' ', '\t', '\r', '\n'], StringSplitOptions.RemoveEmptyEntries).FirstOrDefault();
        return firstToken is "OK" or "ACK" or "SUCCESS" or "ACCEPTED" or "DONE";
    }

    private static string FormatResponseForLog(string response)
    {
        return string.IsNullOrWhiteSpace(response) ? "<empty>" : response.Replace('\r', ' ').Replace('\n', ' ').Trim();
    }

    private static double? ReadNullableDoubleAny(IReadOnlyDictionary<string, string> parameters, params string[] keys)
    {
        bool ShouldIncludeItem(string key)
        {
            return !string.IsNullOrWhiteSpace(key);
        }

        foreach (var key in keys.Where(ShouldIncludeItem))
        {
            if (parameters.TryGetValue(key, out var value) && double.TryParse(value, NumberStyles.Any, CultureInfo.InvariantCulture, out var result))
            {
                return result;
            }
        }

        return null;
    }

    private static int? ReadNullableIntAny(IReadOnlyDictionary<string, string> parameters, params string[] keys)
    {
        bool ShouldIncludeItem(string key)
        {
            return !string.IsNullOrWhiteSpace(key);
        }

        foreach (var key in keys.Where(ShouldIncludeItem))
        {
            if (!parameters.TryGetValue(key, out var value))
            {
                continue;
            }

            if (int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var intResult))
            {
                return intResult;
            }

            if (double.TryParse(value, NumberStyles.Any, CultureInfo.InvariantCulture, out var doubleResult))
            {
                return (int)Math.Round(doubleResult);
            }
        }

        return null;
    }

    private static double ReadDouble(IReadOnlyDictionary<string, string> parameters, string key, double defaultValue)
    {
        return parameters.TryGetValue(key, out var value) && double.TryParse(value, NumberStyles.Any, CultureInfo.InvariantCulture, out var result) ? result : defaultValue;
    }

    private static int ReadInt(IReadOnlyDictionary<string, string> parameters, string key, int defaultValue)
    {
        return parameters.TryGetValue(key, out var value) && int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var result) ? result : defaultValue;
    }

    private static double ReadDoubleAny(IReadOnlyDictionary<string, string> parameters, double defaultValue, params string[] keys)
    {
        bool ShouldIncludeItem(string key)
        {
            return !string.IsNullOrWhiteSpace(key);
        }

        foreach (var key in keys.Where(ShouldIncludeItem))
        {
            if (parameters.TryGetValue(key, out var value) && double.TryParse(value, NumberStyles.Any, CultureInfo.InvariantCulture, out var result))
            {
                return result;
            }
        }

        return defaultValue;
    }

    private static int ReadIntAny(IReadOnlyDictionary<string, string> parameters, int defaultValue, params string[] keys)
    {
        bool ShouldIncludeItem(string key)
        {
            return !string.IsNullOrWhiteSpace(key);
        }

        foreach (var key in keys.Where(ShouldIncludeItem))
        {
            if (!parameters.TryGetValue(key, out var value))
            {
                continue;
            }

            if (int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var intResult))
            {
                return intResult;
            }

            if (double.TryParse(value, NumberStyles.Any, CultureInfo.InvariantCulture, out var doubleResult))
            {
                return (int)Math.Round(doubleResult);
            }
        }

        return defaultValue;
    }

    private static bool IsBufferedRunEnabled(IReadOnlyDictionary<string, string> parameters)
    {
        return ReadBoolAny(parameters, false, ScriptBufferedRunUseKey);
    }

    private static int ReadScriptRunTimeoutMs(IReadOnlyDictionary<string, string> parameters)
    {
        return Math.Max(0, ReadIntAny(parameters, ScriptRunDefaultTimeoutMs, ScriptRunTimeoutMsKey, ScriptBufferedRunTimeoutMsKey));
    }

    private static int ReadScriptRunPollIntervalMs(IReadOnlyDictionary<string, string> parameters)
    {
        return Math.Max(10, ReadIntAny(parameters, ScriptRunDefaultPollIntervalMs, ScriptRunPollIntervalMsKey));
    }

    private static int ReadBufferedRunLinesPerCommand(IReadOnlyDictionary<string, string> parameters)
    {
        return Math.Max(2, ReadIntAny(parameters, 1000, ScriptBufferedRunLinesPerCommandKey));
    }

    private static int ReadBufferedRunQueueSize(IReadOnlyDictionary<string, string> parameters)
    {
        return Math.Max(1, ReadIntAny(parameters, 100, ScriptBufferedRunQueueSizeKey));
    }

    private static int ReadBufferedRunTimeoutMs(IReadOnlyDictionary<string, string> parameters)
    {
        return Math.Max(0, ReadIntAny(parameters, 600000, ScriptBufferedRunTimeoutMsKey));
    }

    private static bool ReadBool(IReadOnlyDictionary<string, string> parameters, string key, bool defaultValue)
    {
        if (!parameters.TryGetValue(key, out var value) || string.IsNullOrWhiteSpace(value))
        {
            return defaultValue;
        }

        return value.Trim().ToUpperInvariant() switch
        {
            "1" or "Y" or "YES" or "TRUE" or "ON" or "USE" => true,
            "0" or "N" or "NO" or "FALSE" or "OFF" or "SKIP" => false,
            _ => defaultValue
        };
    }

    private static bool ReadBoolAny(IReadOnlyDictionary<string, string> parameters, bool defaultValue, params string[] keys)
    {
        bool ShouldIncludeItem(string key)
        {
            return !string.IsNullOrWhiteSpace(key);
        }

        foreach (var key in keys.Where(ShouldIncludeItem))
        {
            if (parameters.TryGetValue(key, out var value) && !string.IsNullOrWhiteSpace(value))
            {
                return value.Trim().ToUpperInvariant() switch
                {
                    "1" or "Y" or "YES" or "TRUE" or "ON" or "USE" => true,
                    "0" or "N" or "NO" or "FALSE" or "OFF" or "SKIP" => false,
                    _ => defaultValue
                };
            }
        }

        return defaultValue;
    }

    private static bool ReadBoolValue(string value, bool defaultValue)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return defaultValue;
        }

        return value.Trim().ToUpperInvariant() switch
        {
            "1" or "Y" or "YES" or "TRUE" or "ON" or "USE" => true,
            "0" or "N" or "NO" or "FALSE" or "OFF" or "SKIP" => false,
            _ => defaultValue
        };
    }

    private static string ReadText(IReadOnlyDictionary<string, string> parameters, string key, string defaultValue)
    {
        return parameters.TryGetValue(key, out var value) && !string.IsNullOrWhiteSpace(value) ? value.Trim() : defaultValue;
    }

    private static string ReadTextAny(IReadOnlyDictionary<string, string> parameters, string defaultValue, IEnumerable<string> keys)
    {
        bool ShouldIncludeItem(string key)
        {
            return !string.IsNullOrWhiteSpace(key);
        }

        foreach (var key in keys.Where(ShouldIncludeItem))
        {
            if (parameters.TryGetValue(key, out var value) && !string.IsNullOrWhiteSpace(value))
            {
                return value.Trim();
            }
        }

        return defaultValue;
    }

    private static string[] CreateHeadKeys(int headNo, params string[] names)
    {
        var paddedHeadNoText = headNo.ToString("00", CultureInfo.InvariantCulture);
        string SelectItem(string name)
        {
            return $"H{paddedHeadNoText}_{name}";
        }

        return names.Select(SelectItem).ToArray();
    }

    private static bool ReadHeadUse(IReadOnlyDictionary<string, string> parameters, int headNo)
    {
        return ReadBoolAny(parameters, true, CreateHeadKeys(headNo, "USE"));
    }

    private static int ReadHeadAutomationNo(IReadOnlyDictionary<string, string> parameters, int headNo)
    {
        return Math.Max(0, ReadIntAny(parameters, headNo <= 4 ? 0 : 1, CreateHeadKeys(headNo, "AUTOMATION_NO")));
    }

    private static int ReadHeadAutomationTaskNo(IReadOnlyDictionary<string, string> parameters, int headNo)
    {
        var defaultTaskNo = ((headNo - 1) % 4) + 1;
        return Math.Max(1, ReadIntAny(parameters, defaultTaskNo, CreateHeadKeys(headNo, "AUTOMATION_TASK_NO")));
    }

    private static string ReadAnyParameter(ST_PROCESS_MODEL processModel, string defaultValue, params string[] keys)
    {
        foreach (var key in keys)
        {
            if (processModel.Parameters.TryGetValue(key, out var value) && !string.IsNullOrWhiteSpace(value))
            {
                return value.Trim();
            }
        }

        return defaultValue;
    }

    private ST_PROCESS_MODEL GetProcessModel()
    {
        return _processModel ?? throw new InvalidOperationException("Process Model is not built.");
    }

    private ST_STATION_PROCESS_STATUS SetAlarm(string message, CancellationToken cancellationToken)
    {
        SetSequenceState(EN_STATION_SEQUENCE.Error);
        AddProcessLog("ERROR", "STATION", message);
        MarkRunningAutoSteps(AutoStepError);
        TrySetProductError(message, cancellationToken);
        var result = new ST_PROCESS_RESULT(false, message, DateTimeOffset.Now);
        TryReportProcessResult(result, "ALARM", cancellationToken, EN_STATION_STATE.Alarm);
        _snapshot = CreateSnapshot(_snapshot.ProcessModel, SetHeadStatus(_snapshot.HeadPreviews, EN_PROCESS_STEP.Error), EN_SCRIPT_STATUS.Error, EN_PROCESS_STEP.Error, result);
        SetStationState(EN_STATION_STATE.Alarm, EN_PROCESS_STEP.Error, EN_SCRIPT_STATUS.Error, message);
        return _snapshot;
    }

    private void SetSequenceState(EN_STATION_SEQUENCE sequenceState)
    {
        lock (_sequenceLock)
        {
            if (_sequenceState == sequenceState)
            {
                return;
            }

            _sequenceState = sequenceState;
            _stationStatus = (_stationStatus with
            {
                ChangedAt = DateTimeOffset.Now
            }

            ).WithSequenceState(sequenceState);
        }
    }

    private bool TryMoveSequenceState(EN_STATION_SEQUENCE expectedState, EN_STATION_SEQUENCE nextState)
    {
        lock (_sequenceLock)
        {
            if (_sequenceState != expectedState)
            {
                return false;
            }

            _sequenceState = nextState;
            _stationStatus = (_stationStatus with
            {
                ChangedAt = DateTimeOffset.Now
            }

            ).WithSequenceState(nextState);
            return true;
        }
    }

    private EN_STATION_SEQUENCE ReadSequenceState()
    {
        lock (_sequenceLock)
        {
            return _sequenceState;
        }
    }

    private ST_STATION_STATUS ReadStationStatus()
    {
        lock (_sequenceLock)
        {
            return _stationStatus;
        }
    }

    private void SetStationState(EN_STATION_STATE state, EN_PROCESS_STEP processStep, EN_SCRIPT_STATUS scriptStatus, string message)
    {
        ST_STATION_STATUS stationStatus;
        lock (_sequenceLock)
        {
            _stationStatus = (_stationStatus with
            {
                State = state,
                ProcessStep = processStep,
                ScriptStatus = scriptStatus,
                LastMessage = message,
                ChangedAt = DateTimeOffset.Now
            }

            ).WithSequenceState(_sequenceState);
            stationStatus = _stationStatus;
        }

        _logManager?.WriteStationState(stationStatus.StationName, state.ToString().ToUpperInvariant(), processStep.ToString().ToUpperInvariant(), message);
    }

    private void AddProcessLog(string level, string source, string message)
    {
        lock (_processLogLock)
        {
            _processLogs.Add(new ST_PROCESS_LOG_ITEM(DateTimeOffset.Now, level, source, message));
            var overflowCount = _processLogs.Count - MaximumProcessLogCount;
            if (overflowCount > 0)
            {
                _processLogs.RemoveRange(0, overflowCount);
            }
        }
    }

    private void ClearProcessLogs()
    {
        lock (_processLogLock)
        {
            _processLogs.Clear();
        }
    }

    private ST_PROCESS_LOG_ITEM[] GetProcessLogsSnapshot()
    {
        lock (_processLogLock)
        {
            return _processLogs.ToArray();
        }
    }

    private void AddSequenceLog(string level, string source, string message)
    {
        var stationStatus = ReadStationStatus();
        AddProcessLog(level, source, message);
        try
        {
            _logManager?.WriteStationState(stationStatus.StationName, stationStatus.State.ToString().ToUpperInvariant(), $"SEQ_{source}_{level}", message);
        }
        catch
        {
            // Sequence execution must not be retried because a diagnostic log write failed.
        }
    }

    private static string FormatInterLockBlockedMessage(ST_INTERLOCK_SUMMARY interLock)
    {
        bool MatchesItem(global::Drilling.Common.InterLock.ST_INTERLOCK_ITEM x)
        {
            return x.Level != EN_INTERLOCK_LEVEL.Ok;
        }

        var item = interLock.Items.FirstOrDefault(MatchesItem);
        return item is null ? "InterLock is not ready." : $"InterLock is not ready. {item.Signal}: {item.Detail}";
    }

    private static string FormatStartInterLockBlockedMessage(ST_INTERLOCK_SUMMARY interLock)
    {
        bool MatchesItem(global::Drilling.Common.InterLock.ST_INTERLOCK_ITEM item)
        {
            return item.Level != EN_INTERLOCK_LEVEL.Ok;
        }

        string FormatItem(global::Drilling.Common.InterLock.ST_INTERLOCK_ITEM item)
        {
            var detail = string.IsNullOrWhiteSpace(item.Detail) ? item.State : item.Detail;
            return $"- {item.Signal}: {detail}";
        }

        var blockedItems = interLock.Items.Where(MatchesItem).Select(FormatItem).ToArray();
        if (blockedItems.Length == 0)
        {
            return "공정 시작에 실패했습니다. 인터락을 확인하세요.";
        }

        return "공정 시작에 실패했습니다. 인터락을 확인하세요." + Environment.NewLine + string.Join(Environment.NewLine, blockedItems);
    }

    private static string FormatScriptStatus(EN_SCRIPT_STATUS status)
    {
        return status switch
        {
            EN_SCRIPT_STATUS.NotCreated => "Not Created",
            _ => status.ToString()};
    }

    private static string FormatExecuteState(EN_SCRIPT_STATUS scriptStatus, ST_PROCESS_RESULT? result, bool hasScript)
    {
        if (!hasScript)
        {
            return result is null ? "-" : "Not Executed";
        }

        if (result is not null)
        {
            return GetProcessResultCode(result) == "SKIPPED" ? "Skipped" : result.IsSuccess ? "Completed" : "Failed";
        }

        return scriptStatus switch
        {
            EN_SCRIPT_STATUS.Running => "Running",
            EN_SCRIPT_STATUS.Created => "Ready",
            EN_SCRIPT_STATUS.Error => "Error",
            _ => "-"
        };
    }

    private static string FormatScriptResult(EN_SCRIPT_STATUS scriptStatus, ST_PROCESS_RESULT? result, bool hasScript)
    {
        if (!hasScript)
        {
            return result is null ? "-" : "Not Executed";
        }

        if (result is not null)
        {
            return GetProcessResultCode(result);
        }

        return scriptStatus is EN_SCRIPT_STATUS.Created or EN_SCRIPT_STATUS.Running ? "In Progress" : "-";
    }

    private static string FormatDateTime(DateTimeOffset? value)
    {
        return value?.ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture) ?? "-";
    }

    private static string FormatProcessResultDetail(ST_PROCESS_RESULT result, string processId, string recipeId, string productId)
    {
        var state = GetProcessResultCode(result);
        return string.Join(", ", $"Process={processId}", $"Recipe={recipeId}", $"Product={productId}", $"Result={state}", $"Message={result.Message}", $"Time={result.CompletedAt.ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture)}");
    }

    private static string GetProcessResultCode(ST_PROCESS_RESULT result)
    {
        return string.IsNullOrWhiteSpace(result.ResultCode) ? result.IsSuccess ? "OK" : "NG" : result.ResultCode.Trim().ToUpperInvariant();
    }

    private static string FormatDuration(TimeSpan value)
    {
        return value == TimeSpan.Zero ? "00:00:00" : value.ToString(@"hh\:mm\:ss", CultureInfo.InvariantCulture);
    }

    private sealed record ST_BUFFERED_RUN_GROUP_RESULT(int AutomationNo, string HeadSummary, string Response);
    private sealed record ST_BUFFERED_RUN_STOP_RESULT(int AutomationNo, int TaskNo, string HeadSummary, bool IsSuccess, string Response, string ErrorMessage);
    private readonly record struct ST_AUTOMATION_TASK_KEY(int AutomationNo, int TaskNo);
    private sealed record ST_AUTOMATION_TASK_TARGET(int AutomationNo, int TaskNo, string HeadSummary);
    private sealed record ST_AUTOMATION_TASK_STATUS(int TaskNo, string State, string SourceFile, string ErrorMessage, string RawResponse);
    private sealed record ST_AUTOMATION_TASK_LINE_STATUS(int TaskNo, int CurrentLine, string RawResponse);
    private sealed record ST_SCANNER_STATUS_LOG_AXIS_TARGET(int HeadNo, int AutomationNo, int ControllerNo, int TaskNo, string AxisRole, string AxisName, int AioNo, bool ReadExtendedStatus, string FilePath);
    private sealed record ST_QUEUE_COUNT_LOG_TARGET(int AutomationNo, int ControllerNo, int TaskNo, string HeadNo, string ScriptFile, int TotalLine, string FilePath);
    private sealed record ST_AUTO_STEP_INFO(string Key, string DisplayName);
    private sealed class CScannerStatusLogger : IDisposable
    {
        private const int ScannerStatusReadTimeoutMs = 5000;
        private const string Header = "Timestamp,RecipeId,Head,ControllerNo,TaskNo,AxisName,AxisPosition,AxisCurrentFeedback,AxisEnableStatus,AxisHomeStatus,AxisFault,GalvoTemperature,GalvoLaserOutputRaw,PositionFbkAux,TaskStatus,ProcessorUsage";
        private readonly CStationProcess _owner;
        private readonly string _recipeId;
        private readonly IReadOnlyList<ST_SCANNER_STATUS_LOG_AXIS_TARGET> _targets;
        private readonly CancellationTokenSource _cancellation = new();
        private readonly object _writeLock = new();
        private readonly Thread _thread;
        private Guid _snapshotOwnerId = Guid.Empty;
        private string _lastError = "";
        private bool _started;
        private bool _stopped;

        private CScannerStatusLogger(CStationProcess owner, string recipeId, IReadOnlyList<ST_SCANNER_STATUS_LOG_AXIS_TARGET> targets)
        {
            _owner = owner;
            _recipeId = recipeId;
            _targets = targets;
            _thread = new Thread(Run)
            {
                IsBackground = true,
                Name = "ScannerStatusLogger"
            };
        }

        public static CScannerStatusLogger Create(CStationProcess owner, string recipeId, bool bufferedRun, IReadOnlyDictionary<string, string> parameters, IReadOnlyList<ST_HEAD_SCRIPT_RESULT> headScripts)
        {
            var targets = CreateTargets(bufferedRun, parameters, headScripts);
            return new CScannerStatusLogger(owner, recipeId, targets);
        }

        public void Start()
        {
            if (_started || _targets.Count == 0)
            {
                return;
            }

            _snapshotOwnerId = CScannerStatusLiveSnapshotStore.Begin();
            _started = true;
            _thread.Start();
        }

        public void StopAndWriteFinal()
        {
            if (_stopped)
            {
                return;
            }

            _stopped = true;
            _cancellation.Cancel();
            if (_started && !_thread.Join(QueueCountLogStopWaitMs))
            {
                _owner.AddProcessLog("WARN", "SCANNER_STATUS", "Scanner status logger did not stop before timeout.");
            }

            if (_started)
            {
                WriteSnapshotOnce();
            }

            if (_snapshotOwnerId != Guid.Empty)
            {
                CScannerStatusLiveSnapshotStore.End(_snapshotOwnerId);
                _snapshotOwnerId = Guid.Empty;
            }
        }

        public void Dispose()
        {
            StopAndWriteFinal();
            _cancellation.Dispose();
        }

        private static IReadOnlyList<ST_SCANNER_STATUS_LOG_AXIS_TARGET> CreateTargets(bool bufferedRun, IReadOnlyDictionary<string, string> parameters, IReadOnlyList<ST_HEAD_SCRIPT_RESULT> headScripts)
        {
            var targets = new List<ST_SCANNER_STATUS_LOG_AXIS_TARGET>();
            var rootDirectory = ResolveRootDirectory(headScripts);
            var dateDirectory = DateTime.Now.ToString("yyyyMMdd", CultureInfo.InvariantCulture);
            var modeDirectory = bufferedRun ? "Buffered" : "Standard";
            foreach (var script in headScripts)
            {
                if (script.TotalShots <= 0)
                {
                    continue;
                }

                var headNo = script.HeadNo;
                if (!ReadHeadUse(parameters, headNo))
                {
                    continue;
                }

                var controllerNo = script.AutomationNo + 1;
                var filePath = Path.Combine(rootDirectory, dateDirectory, modeDirectory, $"Controller {controllerNo.ToString(CultureInfo.InvariantCulture)}", $"Task {script.TaskNo.ToString(CultureInfo.InvariantCulture)}.txt");
                var aioNo = Math.Max(0, ReadIntAny(parameters, 0, CreateHeadKeys(headNo, "SCANNER_AIO_NO")));
                AddAxisTarget(targets, script, controllerNo, "X", ReadTextAny(parameters, "", CreateHeadKeys(headNo, "X_AXIS", "GX_AXIS")), aioNo, true, filePath);
                AddAxisTarget(targets, script, controllerNo, "Y", ReadTextAny(parameters, "", CreateHeadKeys(headNo, "Y_AXIS", "GY_AXIS")), aioNo, true, filePath);
                if (ReadBoolAny(parameters, false, CreateHeadKeys(headNo, "SCANNER_Z_USE", "Z_USE")))
                {
                    AddAxisTarget(targets, script, controllerNo, "Z", ReadTextAny(parameters, "", CreateHeadKeys(headNo, "SCANNER_Z_AXIS", "Z_AXIS")), aioNo, false, filePath);
                }
            }

            return targets;
        }

        private static void AddAxisTarget(List<ST_SCANNER_STATUS_LOG_AXIS_TARGET> targets, ST_HEAD_SCRIPT_RESULT script, int controllerNo, string axisRole, string axisName, int aioNo, bool readExtendedStatus, string filePath)
        {
            targets.Add(new ST_SCANNER_STATUS_LOG_AXIS_TARGET(script.HeadNo, script.AutomationNo, controllerNo, script.TaskNo, axisRole, axisName.Trim(), aioNo, readExtendedStatus, filePath));
        }

        private static string ResolveRootDirectory(IReadOnlyList<ST_HEAD_SCRIPT_RESULT> headScripts)
        {
            foreach (var script in headScripts)
            {
                if (string.IsNullOrWhiteSpace(script.FilePath))
                {
                    continue;
                }

                var directoryPath = Path.GetDirectoryName(Path.GetFullPath(script.FilePath));
                if (string.IsNullOrWhiteSpace(directoryPath))
                {
                    continue;
                }

                var directory = new DirectoryInfo(directoryPath);
                while (directory is not null)
                {
                    if (directory.Name.Equals("Data", StringComparison.OrdinalIgnoreCase) && directory.Parent is not null)
                    {
                        return Path.Combine(directory.Parent.FullName, "Log", ScannerStatusLogDirectoryName);
                    }

                    directory = directory.Parent;
                }
            }

            return Path.Combine(AppContext.BaseDirectory, "Log", ScannerStatusLogDirectoryName);
        }

        private void Run()
        {
            while (!_cancellation.Token.WaitHandle.WaitOne(ScannerStatusLogIntervalMs))
            {
                WriteSnapshotOnce();
            }
        }

        private void WriteSnapshotOnce()
        {
            if (_targets.Count == 0)
            {
                return;
            }

            var elapsed = Stopwatch.StartNew();
            lock (_writeLock)
            {
                var taskStatusCache = new Dictionary<ST_AUTOMATION_TASK_KEY, string>();
                var processorUsageCache = new Dictionary<int, string>();
                var snapshot = new List<ST_SCANNER_AXIS_LIVE_STATUS>(_targets.Count);
                foreach (var target in _targets)
                {
                    var liveStatus = ReadTargetSnapshot(target, taskStatusCache, processorUsageCache);
                    snapshot.Add(liveStatus);
                    if (!target.AxisRole.Equals("Z", StringComparison.OrdinalIgnoreCase))
                    {
                        WriteTargetSnapshot(target, liveStatus);
                    }
                }

                if (_snapshotOwnerId != Guid.Empty)
                {
                    CScannerStatusLiveSnapshotStore.Update(_snapshotOwnerId, snapshot);
                }
            }

            elapsed.Stop();
            if (elapsed.ElapsedMilliseconds >= ScannerStatusReadTimeoutMs)
            {
                RememberError($"Scanner status snapshot delayed. ElapsedMs={elapsed.ElapsedMilliseconds.ToString(CultureInfo.InvariantCulture)}, TargetCount={_targets.Count.ToString(CultureInfo.InvariantCulture)}");
            }
        }

        private ST_SCANNER_AXIS_LIVE_STATUS ReadTargetSnapshot(ST_SCANNER_STATUS_LOG_AXIS_TARGET target, Dictionary<ST_AUTOMATION_TASK_KEY, string> taskStatusCache, Dictionary<int, string> processorUsageCache)
        {
            var taskStatus = ReadTaskStatus(target, taskStatusCache);
            var processorUsage = ReadProcessorUsage(target, processorUsageCache);
            var headName = $"H{target.HeadNo:00}";
            var automationLabel = $"#{target.AutomationNo.ToString(CultureInfo.InvariantCulture)}";
            if (string.IsNullOrWhiteSpace(target.AxisName) || target.AxisName.Equals("-", StringComparison.Ordinal))
            {
                return new ST_SCANNER_AXIS_LIVE_STATUS(target.HeadNo, target.AutomationNo, target.ControllerNo, target.TaskNo, headName, automationLabel, target.AxisRole, "-", "-", "-", "NOT CONFIGURED", "NO", "-", "-", "-", "-", taskStatus, processorUsage, "NOT CONFIGURED", $"{headName} {target.AxisRole} axis name is not configured.");
            }

            if (!IsAutomationAxisName(target.AxisName))
            {
                return new ST_SCANNER_AXIS_LIVE_STATUS(target.HeadNo, target.AutomationNo, target.ControllerNo, target.TaskNo, headName, automationLabel, target.AxisRole, target.AxisName, "-", "-", "NOT CONFIGURED", "NO", "-", "-", "-", "-", taskStatus, processorUsage, "NOT CONFIGURED", $"{headName} {target.AxisRole} axis name is invalid: {target.AxisName}.");
            }

            try
            {
                if (!_owner._automationManager.IsSimul(target.AutomationNo) && !_owner._automationManager.IsConnect(target.AutomationNo))
                {
                    return new ST_SCANNER_AXIS_LIVE_STATUS(target.HeadNo, target.AutomationNo, target.ControllerNo, target.TaskNo, headName, automationLabel, target.AxisRole, target.AxisName, "-", "-", "OFFLINE", "-", "-", "-", "-", "-", taskStatus, processorUsage, "OFFLINE", "Automation not connected.");
                }

                var cached = _owner._automationManager.StatusSnapshots.GetAxis(target.AxisName, target.AutomationNo, target.AioNo, target.ReadExtendedStatus);
                if (cached.Value is not { } status)
                    return new ST_SCANNER_AXIS_LIVE_STATUS(target.HeadNo, target.AutomationNo, target.ControllerNo, target.TaskNo, headName, automationLabel, target.AxisRole, target.AxisName, "-", "-", cached.State, "-", "-", "-", "-", "-", taskStatus, processorUsage, cached.State, cached.Detail);
                return new ST_SCANNER_AXIS_LIVE_STATUS(target.HeadNo, target.AutomationNo, target.ControllerNo, target.TaskNo, headName, automationLabel, target.AxisRole, target.AxisName, FormatScannerPosition(status.PositionFeedback), FormatExtendedScannerValue(status.CurrentFeedback, target.ReadExtendedStatus), status.Able ? "ABLE" : "DISABLE", status.HomeDone ? "OK" : "NO", FormatStatusText(status.Fault), FormatExtendedScannerTemperature(status.MotorTemperature, target.ReadExtendedStatus), FormatExtendedScannerValue(status.GalvoLaserOutputRaw, target.ReadExtendedStatus), FormatExtendedScannerValue(status.AuxiliaryFeedback, target.ReadExtendedStatus), taskStatus, processorUsage, status.HasError ? "ERROR" : "OK", string.IsNullOrWhiteSpace(status.RawResponse) ? "-" : status.RawResponse);
            }
            catch (Exception ex)
            {
                RememberError($"Scanner status log skipped. Controller {target.ControllerNo}, Task {target.TaskNo}, H{target.HeadNo:00} {target.AxisRole}: {ex.Message}");
                return new ST_SCANNER_AXIS_LIVE_STATUS(target.HeadNo, target.AutomationNo, target.ControllerNo, target.TaskNo, headName, automationLabel, target.AxisRole, target.AxisName, "-", "-", "ERROR", "NO", "-", "-", "-", "-", taskStatus, processorUsage, "ERROR", ex.Message);
            }
        }

        private string ReadTaskStatus(ST_SCANNER_STATUS_LOG_AXIS_TARGET target, Dictionary<ST_AUTOMATION_TASK_KEY, string> cache)
        {
            var key = new ST_AUTOMATION_TASK_KEY(target.AutomationNo, target.TaskNo);
            if (cache.TryGetValue(key, out var cached))
            {
                return cached;
            }

            var status = "ERROR";
            try
            {
                if (_owner._automationManager.IsSimul(target.AutomationNo))
                {
                    status = "SIM";
                }
                else if (!_owner._automationManager.IsConnect(target.AutomationNo))
                {
                    status = "OFFLINE";
                }
                else
                {
                    var shared = _owner._automationManager.StatusSnapshots.GetTask(target.TaskNo, target.AutomationNo);
                    status = shared.Value is { } response ? ParseAutomationTaskStatus(response).State : shared.State;
                }
            }
            catch (Exception ex)
            {
                RememberError($"Scanner status task read skipped. Controller {target.ControllerNo}, Task {target.TaskNo}: {ex.Message}");
            }

            cache[key] = status;
            return status;
        }

        private string ReadProcessorUsage(ST_SCANNER_STATUS_LOG_AXIS_TARGET target, Dictionary<int, string> cache)
        {
            if (cache.TryGetValue(target.AutomationNo, out var cached))
            {
                return cached;
            }

            var processorUsage = "ERROR";
            try
            {
                if (_owner._automationManager.IsSimul(target.AutomationNo))
                {
                    processorUsage = "SIM";
                }
                else if (!_owner._automationManager.IsConnect(target.AutomationNo))
                {
                    processorUsage = "OFFLINE";
                }
                else
                {
                    var shared = _owner._automationManager.StatusSnapshots.GetProcessorUsage(target.AutomationNo);
                    processorUsage = shared.Value is { } response ? ParseProcessorUsage(response) : shared.State;
                }
            }
            catch (Exception ex)
            {
                RememberError($"Scanner status processor usage read skipped. Controller {target.ControllerNo}: {ex.Message}");
            }

            cache[target.AutomationNo] = processorUsage;
            return processorUsage;
        }

        private void WriteTargetSnapshot(ST_SCANNER_STATUS_LOG_AXIS_TARGET target, ST_SCANNER_AXIS_LIVE_STATUS status)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(target.FilePath) ?? "");
                if (!File.Exists(target.FilePath) || new FileInfo(target.FilePath).Length == 0)
                {
                    File.AppendAllText(target.FilePath, Header + Environment.NewLine, Encoding.UTF8);
                }

                File.AppendAllText(target.FilePath, FormatLine(status) + Environment.NewLine, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                RememberError($"Scanner status log write skipped. Controller {target.ControllerNo}, Task {target.TaskNo}: {ex.Message}");
            }
        }

        private void RememberError(string message)
        {
            if (message.Equals(_lastError, StringComparison.Ordinal))
            {
                return;
            }

            _lastError = message;
            _owner.AddProcessLog("WARN", "SCANNER_STATUS", message);
        }

        private string FormatLine(ST_SCANNER_AXIS_LIVE_STATUS status)
        {
            var fields = new[]
            {
                DateTimeOffset.Now.ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture),
                _recipeId,
                status.Head,
                status.ControllerNo.ToString(CultureInfo.InvariantCulture),
                status.TaskNo.ToString(CultureInfo.InvariantCulture),
                status.AxisNo,
                status.AxisPosition,
                status.AxisCurrentFeedback,
                status.AxisEnableStatus,
                status.AxisHomeStatus,
                status.AxisFault,
                status.GalvoTemperature,
                status.GalvoLaserOutputRaw,
                status.PositionFbkAux,
                status.TaskStatus,
                status.ProcessorUsage
            };

            return FormatCsv(fields);
        }

        private static string ParseProcessorUsage(string response)
        {
            var fields = response.Split(':');
            if (fields.Length >= 4 && fields[0].Equals("OK", StringComparison.OrdinalIgnoreCase) && fields[1].Equals("SYSTEM", StringComparison.OrdinalIgnoreCase) && fields[2].Equals("PROCESSOR_USAGE", StringComparison.OrdinalIgnoreCase) && double.TryParse(fields[3], NumberStyles.Float, CultureInfo.InvariantCulture, out var usage))
            {
                return Math.Clamp(usage, 0.0, 100.0).ToString("F1", CultureInfo.InvariantCulture);
            }

            return response.StartsWith("OK", StringComparison.OrdinalIgnoreCase) ? "0.0" : "ERROR";
        }

        private static string FormatScannerPosition(double value)
        {
            if (!double.IsFinite(value))
            {
                return "-";
            }

            return value.ToString("F3", CultureInfo.InvariantCulture);
        }

        private static string FormatExtendedScannerValue(double value, bool readExtendedStatus)
        {
            return readExtendedStatus ? FormatScannerPosition(value) : "-";
        }

        private static string FormatExtendedScannerTemperature(double value, bool readExtendedStatus)
        {
            if (!readExtendedStatus)
            {
                return "-";
            }

            return CGalvoTemperature.FormatCelsius(value);
        }

        private static string FormatStatusText(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? "-" : value.Trim();
        }

        private static bool IsAutomationAxisName(string value)
        {
            if (value.Length == 0 || !char.IsAsciiLetter(value[0]))
            {
                return false;
            }

            foreach (var character in value)
            {
                if (!char.IsAsciiLetter(character) && !char.IsAsciiDigit(character) && character != '_')
                {
                    return false;
                }
            }

            return true;
        }

        private static string FormatCsv(IReadOnlyList<string> fields)
        {
            var builder = new StringBuilder();
            for (var i = 0; i < fields.Count; i++)
            {
                if (i > 0)
                {
                    builder.Append(',');
                }

                builder.Append(FormatCsvField(fields[i]));
            }

            return builder.ToString();
        }

        private static string FormatCsvField(string value)
        {
            var text = value ?? "";
            if (!text.Contains(',', StringComparison.Ordinal) && !text.Contains('"', StringComparison.Ordinal) && !text.Contains('\r', StringComparison.Ordinal) && !text.Contains('\n', StringComparison.Ordinal))
            {
                return text;
            }

            return "\"" + text.Replace("\"", "\"\"", StringComparison.Ordinal) + "\"";
        }
    }

    private sealed class CQueueCountLogger : IDisposable
    {
        private const string Header = "Timestamp,RecipeId,ControllerNo,TaskNo,HeadNo,ScriptFile,CurrentLine,TotalLine";
        private readonly CStationProcess _owner;
        private readonly string _recipeId;
        private readonly IReadOnlyList<ST_QUEUE_COUNT_LOG_TARGET> _targets;
        private readonly CancellationTokenSource _cancellation = new();
        private readonly object _writeLock = new();
        private readonly Thread _thread;
        private string _lastError = "";
        private bool _started;
        private bool _stopped;

        private CQueueCountLogger(CStationProcess owner, string recipeId, IReadOnlyList<ST_QUEUE_COUNT_LOG_TARGET> targets)
        {
            _owner = owner;
            _recipeId = recipeId;
            _targets = targets;
            _thread = new Thread(Run)
            {
                IsBackground = true,
                Name = "QueueCountLogger"
            };
        }

        public static CQueueCountLogger Create(CStationProcess owner, string recipeId, bool bufferedRun, IReadOnlyList<ST_HEAD_SCRIPT_RESULT> headScripts)
        {
            var targets = CreateTargets(bufferedRun, headScripts);
            return new CQueueCountLogger(owner, recipeId, targets);
        }

        public void Start()
        {
            if (_started || _targets.Count == 0)
            {
                return;
            }

            _started = true;
            _thread.Start();
        }

        public void StopAndWriteFinal()
        {
            if (_stopped)
            {
                return;
            }

            _stopped = true;
            _cancellation.Cancel();
            if (!_started)
            {
                return;
            }

            if (_started && !_thread.Join(QueueCountLogStopWaitMs))
            {
                _owner.AddProcessLog("WARN", "QUEUE_COUNT", "Queue count logger did not stop before timeout.");
            }

            WriteSnapshotOnce();
        }

        public void Dispose()
        {
            StopAndWriteFinal();
            _cancellation.Dispose();
        }

        private static IReadOnlyList<ST_QUEUE_COUNT_LOG_TARGET> CreateTargets(bool bufferedRun, IReadOnlyList<ST_HEAD_SCRIPT_RESULT> headScripts)
        {
            var targets = new List<ST_QUEUE_COUNT_LOG_TARGET>();
            var rootDirectory = ResolveRootDirectory(headScripts);
            var dateDirectory = DateTime.Now.ToString("yyyyMMdd", CultureInfo.InvariantCulture);
            var modeDirectory = bufferedRun ? "Buffered" : "Standard";
            foreach (var script in headScripts)
            {
                if (script.TotalShots <= 0)
                {
                    continue;
                }

                var controllerNo = script.AutomationNo + 1;
                var filePath = Path.Combine(rootDirectory, dateDirectory, modeDirectory, $"Controller {controllerNo.ToString(CultureInfo.InvariantCulture)}", $"Task {script.TaskNo.ToString(CultureInfo.InvariantCulture)}.txt");
                targets.Add(new ST_QUEUE_COUNT_LOG_TARGET(script.AutomationNo, controllerNo, script.TaskNo, $"H{script.HeadNo:00}", script.FileName, Math.Max(0, script.TotalLines), filePath));
            }

            return targets;
        }

        private static string ResolveRootDirectory(IReadOnlyList<ST_HEAD_SCRIPT_RESULT> headScripts)
        {
            foreach (var script in headScripts)
            {
                if (string.IsNullOrWhiteSpace(script.FilePath))
                {
                    continue;
                }

                var directoryPath = Path.GetDirectoryName(Path.GetFullPath(script.FilePath));
                if (string.IsNullOrWhiteSpace(directoryPath))
                {
                    continue;
                }

                var directory = new DirectoryInfo(directoryPath);
                while (directory is not null)
                {
                    if (directory.Name.Equals("Data", StringComparison.OrdinalIgnoreCase) && directory.Parent is not null)
                    {
                        return Path.Combine(directory.Parent.FullName, "Log", QueueCountLogDirectoryName);
                    }

                    directory = directory.Parent;
                }
            }

            return Path.Combine(AppContext.BaseDirectory, "Log", QueueCountLogDirectoryName);
        }

        private void Run()
        {
            while (!_cancellation.Token.WaitHandle.WaitOne(QueueCountLogIntervalMs))
            {
                WriteSnapshotOnce();
            }
        }

        private void WriteSnapshotOnce()
        {
            if (_targets.Count == 0)
            {
                return;
            }

            lock (_writeLock)
            {
                foreach (var target in _targets)
                {
                    WriteTargetSnapshot(target);
                }
            }
        }

        private void WriteTargetSnapshot(ST_QUEUE_COUNT_LOG_TARGET target)
        {
            try
            {
                var lineStatus = _owner.ReadAutomationTaskLineStatus(target.AutomationNo, target.TaskNo, CancellationToken.None);
                Directory.CreateDirectory(Path.GetDirectoryName(target.FilePath) ?? "");
                if (!File.Exists(target.FilePath) || new FileInfo(target.FilePath).Length == 0)
                {
                    File.AppendAllText(target.FilePath, Header + Environment.NewLine, Encoding.UTF8);
                }

                File.AppendAllText(target.FilePath, FormatLine(target, lineStatus.CurrentLine) + Environment.NewLine, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                RememberError($"Queue count log skipped. Controller {target.ControllerNo}, Task {target.TaskNo}: {ex.Message}");
            }
        }

        private void RememberError(string message)
        {
            if (message.Equals(_lastError, StringComparison.Ordinal))
            {
                return;
            }

            _lastError = message;
            _owner.AddProcessLog("WARN", "QUEUE_COUNT", message);
        }

        private string FormatLine(ST_QUEUE_COUNT_LOG_TARGET target, int currentLine)
        {
            var fields = new[]
            {
                DateTimeOffset.Now.ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture),
                _recipeId,
                target.ControllerNo.ToString(CultureInfo.InvariantCulture),
                target.TaskNo.ToString(CultureInfo.InvariantCulture),
                target.HeadNo,
                target.ScriptFile,
                Math.Max(0, currentLine).ToString(CultureInfo.InvariantCulture),
                target.TotalLine.ToString(CultureInfo.InvariantCulture)
            };

            return FormatCsv(fields);
        }

        private static string FormatCsv(IReadOnlyList<string> fields)
        {
            var builder = new StringBuilder();
            for (var i = 0; i < fields.Count; i++)
            {
                if (i > 0)
                {
                    builder.Append(',');
                }

                builder.Append(FormatCsvField(fields[i]));
            }

            return builder.ToString();
        }

        private static string FormatCsvField(string value)
        {
            var text = value ?? "";
            if (!text.Contains(',', StringComparison.Ordinal) && !text.Contains('"', StringComparison.Ordinal) && !text.Contains('\r', StringComparison.Ordinal) && !text.Contains('\n', StringComparison.Ordinal))
            {
                return text;
            }

            return "\"" + text.Replace("\"", "\"\"", StringComparison.Ordinal) + "\"";
        }
    }

    private sealed class CBufferedRunWorker
    {
        private readonly CStationProcess _owner;
        private readonly int _automationNo;
        private readonly IReadOnlyList<ST_HEAD_SCRIPT_RESULT> _headScripts;
        private readonly int _queueSize;
        private readonly int _linesPerCommand;
        private readonly int _timeoutMs;
        private readonly CancellationToken _cancellationToken;
        private readonly Thread _thread;
        private volatile bool _isComplete;
        public CBufferedRunWorker(CStationProcess owner, int automationNo, IReadOnlyList<ST_HEAD_SCRIPT_RESULT> headScripts, int queueSize, int linesPerCommand, int timeoutMs, CancellationToken cancellationToken)
        {
            _owner = owner;
            _automationNo = automationNo;
            _headScripts = headScripts;
            _queueSize = queueSize;
            _linesPerCommand = linesPerCommand;
            _timeoutMs = timeoutMs;
            _cancellationToken = cancellationToken;
            _thread = new Thread(Run)
            {
                IsBackground = true,
                Name = "BufferedRunA1_" + automationNo.ToString(CultureInfo.InvariantCulture)
            };
        }

        public bool IsComplete
        {
            get
            {
                return _isComplete;
            }
        }

        public ST_BUFFERED_RUN_GROUP_RESULT? Result { get; private set; }
        public Exception? Error { get; private set; }
        public int AutomationNo
        {
            get
            {
                return _automationNo;
            }
        }

        public void Start()
        {
            _thread.Start();
        }

        public bool WaitForCompletion(int timeoutMs)
        {
            return _thread.Join(timeoutMs);
        }

        private void Run()
        {
            try
            {
                Result = _owner.RunBufferedHeadScriptGroup(_automationNo, _headScripts, _queueSize, _linesPerCommand, _timeoutMs, _cancellationToken);
            }
            catch (Exception exception)
            {
                Error = exception;
            }
            finally
            {
                _isComplete = true;
            }
        }
    }
}
