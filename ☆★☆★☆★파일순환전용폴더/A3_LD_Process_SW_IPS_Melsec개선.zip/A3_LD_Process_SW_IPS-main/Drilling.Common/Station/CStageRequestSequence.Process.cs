namespace Drilling.Common.Station;

public sealed partial class CStageRequestSequence
{
    public const string StgProcessStart = "HANDSHAKE_STG_PROCESS_START";
    public const string StgProcessComplete = "HANDSHAKE_STG_PROCESS_COMPLETE";
    public const string PrcProcessAble = "HANDSHAKE_PRC_PROCESS_ABLE";
    public const string PrcProcessStart = "HANDSHAKE_PRC_PROCESS_START";
    public const string PrcProcessComplete = "HANDSHAKE_PRC_PROCESS_COMPLETE";
    private static readonly string[] ProcessOutputs = [PrcProcessComplete, PrcProcessStart, PrcProcessAble];
    private static readonly string[] CompletedCycleActions =
    [
        CSequenceActionIds.PrepareData, CSequenceActionIds.BuildUploadScript,
        CSequenceActionIds.DoReadySignalsClear, CSequenceActionIds.ProcessMofZero, CSequenceActionIds.ProcessTaskRun,
        CSequenceActionIds.ProcessReadyPosition, CSequenceActionIds.ProcessMachining, CSequenceActionIds.ProcessResults
    ];
    private bool _processOutputsOwned;

    private async Task PrepareProcessTasks(Func<CancellationToken, Task> zero,
        Func<CancellationToken, Task> runTasks, CancellationToken token)
    {
        Set("PROCESS_READY_CHECK", "Checking Stage Y Ready position and Busy OFF before MOF initialization.");
        await Action(CSequenceActionIds.ProcessReadyPosition, verifyProcessReady ?? (_ => Task.CompletedTask), token).ConfigureAwait(false);
        Set("PROCESS_MOF_ZERO", "Checking auxiliary feedback and zeroing only nonzero axes.");
        await Action(CSequenceActionIds.ProcessMofZero, zero, token).ConfigureAwait(false);
        // Register ownership before issuing RUN: an accepted command can lose its acknowledgement.
        _tasksIssued = true;
        Set("PROCESS_TASK_RUN", "Initializing MOF and verifying every participating Task is waiting for encoder motion.");
        await Action(CSequenceActionIds.ProcessTaskRun, runTasks, token).ConfigureAwait(false);
    }

    private async Task RunProcess(Func<CancellationToken, Task> zero,
        Func<CancellationToken, Task> runTasks, CancellationToken token)
    {
        while (true)
        {
            token.ThrowIfCancellationRequested();
            var sample = EnsureConnectedSignals();
            checkActiveWork?.Invoke();
            if (TrySignal(sample, StgProcessAble, out var able) && able == 1 &&
                TrySignal(sample, StgProcessStart, out var start) && start == 0 &&
                TrySignal(sample, StgProcessComplete, out var complete) && complete == 0) break;
            await Task.Delay(100, token).ConfigureAwait(false);
        }
        await PrepareProcessTasks(zero, runTasks, token).ConfigureAwait(false);
        await WriteConfirmed(PrcProcessAble, 1, token).ConfigureAwait(false);
        Set("PROCESS_WAIT_START", "Process preparation complete and ABLE acknowledged; waiting for Stage START.", true);
        await WaitSignal(StgProcessStart, 1, token).ConfigureAwait(false);
        await WriteConfirmed(PrcProcessStart, 1, token).ConfigureAwait(false);
        Set("PROCESS_MACHINING", "Waiting for normal completion of every machining Task / queue.");
        // Task/queue execution has its configured run timeout, not the short handshake/action timeout.
        await Action(CSequenceActionIds.ProcessMachining, processMachining!, token, Timeout.InfiniteTimeSpan).ConfigureAwait(false);
        Set("PROCESS_RESULTS", "Validating and saving machining results.");
        await Action(CSequenceActionIds.ProcessResults, processResults ?? (_ => Task.CompletedTask), token).ConfigureAwait(false);
        await WriteConfirmed(PrcProcessComplete, 1, token).ConfigureAwait(false);
        Set("PROCESS_WAIT_COMPLETE", "Machining complete; waiting for Stage Process COMPLETE.");
        await WaitSignal(StgProcessComplete, 1, token).ConfigureAwait(false);
        Set("PROCESS_SIGNALS_CLEAR", "Clearing our Process / DoReady signals and action feedback; waiting for Stage signals OFF.");
        await Action(CSequenceActionIds.ProcessSignalsClear, async ct =>
        {
            foreach (var id in ProcessOutputs.Concat(new[] { PrcComplete, PrcStart, PrcAble }))
                await WriteConfirmed(id, 0, ct).ConfigureAwait(false);
            actions.ResetToWaiting(CompletedCycleActions);
            // This action remains RUNNING while waiting for the peer and releasing ownership.
            // On success it returns directly to WAIT; errors and cancellation remain visible.
            foreach (var id in new[] { StgProcessComplete, StgProcessStart, StgProcessAble })
                await WaitSignal(id, 0, ct).ConfigureAwait(false);
            if (releaseProcessTasks is not null) await releaseProcessTasks(ct).ConfigureAwait(false);
        }, token, resetToWaitingOnSuccess: true).ConfigureAwait(false);
        Set("PROCESS_COMPLETE", "Process handshake completed; waiting for the next DoReady request.");
    }
}
