namespace Drilling.Common.Automation;

public sealed record ST_SCANNER_AXIS_LIVE_STATUS(int HeadNo, int AutomationNo, int ControllerNo, int TaskNo, string Head, string Automation, string Axis, string AxisNo, string AxisPosition, string AxisCurrentFeedback, string AxisEnableStatus, string AxisHomeStatus, string AxisFault, string GalvoTemperature, string GalvoLaserOutputRaw, string PositionFbkAux, string TaskStatus, string ProcessorUsage, string Error, string Detail);

public static class CScannerStatusLiveSnapshotStore
{
    private static readonly object SnapshotLock = new();
    private static Guid _ownerId = Guid.Empty;
    private static IReadOnlyList<ST_SCANNER_AXIS_LIVE_STATUS> _snapshot = [];

    public static Guid Begin()
    {
        var ownerId = Guid.NewGuid();
        lock (SnapshotLock)
        {
            _ownerId = ownerId;
            _snapshot = [];
        }

        return ownerId;
    }

    public static void Update(Guid ownerId, IReadOnlyList<ST_SCANNER_AXIS_LIVE_STATUS> snapshot)
    {
        lock (SnapshotLock)
        {
            if (_ownerId != ownerId)
            {
                return;
            }

            _snapshot = snapshot;
        }
    }

    public static void End(Guid ownerId)
    {
        lock (SnapshotLock)
        {
            if (_ownerId != ownerId)
            {
                return;
            }

            _ownerId = Guid.Empty;
            _snapshot = [];
        }
    }

    public static bool TryGetHeadSnapshot(int headNo, out IReadOnlyList<ST_SCANNER_AXIS_LIVE_STATUS> snapshot)
    {
        lock (SnapshotLock)
        {
            if (_ownerId == Guid.Empty)
            {
                snapshot = [];
                return false;
            }

            var items = new List<ST_SCANNER_AXIS_LIVE_STATUS>();
            foreach (var item in _snapshot)
            {
                if (item.HeadNo == headNo)
                {
                    items.Add(item);
                }
            }

            snapshot = items;
            return true;
        }
    }

    public static bool TryGetTaskStatus(int automationNo, int taskNo, out string taskStatus)
    {
        lock (SnapshotLock)
        {
            taskStatus = "WAIT";
            if (_ownerId == Guid.Empty)
            {
                return false;
            }

            foreach (var item in _snapshot)
            {
                if (item.AutomationNo == automationNo && item.TaskNo == taskNo && !string.IsNullOrWhiteSpace(item.TaskStatus))
                {
                    taskStatus = item.TaskStatus;
                    return true;
                }
            }

            return true;
        }
    }

    public static bool TryGetProcessorUsage(int automationNo, out string processorUsage)
    {
        lock (SnapshotLock)
        {
            processorUsage = "WAIT";
            if (_ownerId == Guid.Empty)
            {
                return false;
            }

            foreach (var item in _snapshot)
            {
                if (item.AutomationNo == automationNo && !string.IsNullOrWhiteSpace(item.ProcessorUsage))
                {
                    processorUsage = item.ProcessorUsage;
                    return true;
                }
            }

            return true;
        }
    }
}
