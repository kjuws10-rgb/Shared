using System.Collections.ObjectModel;

namespace Drilling.Common.Automation;

/// <summary>Saved HomeSpeed values and their per-axis primary-unit velocity labels from the same configuration read.</summary>
public sealed class CConfiguredHomeSpeedValues : ReadOnlyDictionary<string, double>
{
    public IReadOnlyDictionary<string, string> Units { get; }

    public CConfiguredHomeSpeedValues(IEnumerable<KeyValuePair<string, double>> values,
        IEnumerable<KeyValuePair<string, string>>? units = null)
        : base(new Dictionary<string, double>(values, StringComparer.OrdinalIgnoreCase))
    {
        var copiedUnits = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        if (units is not null)
            foreach (var (axis, unit) in units)
                if (ContainsKey(axis) && !string.IsNullOrWhiteSpace(unit)) copiedUnits[axis] = unit.Trim();
        Units = new ReadOnlyDictionary<string, string>(copiedUnits);
    }
}
