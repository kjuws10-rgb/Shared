using System.Collections.Concurrent;
using System.Globalization;
using System.Text.Json;

namespace Drilling.Common.Automation;

public partial class CAutomationManager
{
    private readonly ConcurrentDictionary<string, double> _simulationConfiguredHomeSpeeds = new(StringComparer.OrdinalIgnoreCase);

    /// <summary>Reads saved HomeSpeed values, which may differ from the active values until controller reset.</summary>
    public virtual async Task<IReadOnlyDictionary<string, double>> ReadConfiguredHomeSpeeds(
        IReadOnlyList<string> axisNames, int number = 0, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(axisNames);
        ArgumentOutOfRangeException.ThrowIfNegative(number);
        cancellationToken.ThrowIfCancellationRequested();
        var axes = axisNames.Select(ValidateConfiguredHomeAxis).Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
        if (axes.Length == 0)
            return new CConfiguredHomeSpeedValues([]);

        if (IsSimul(number))
            return new CConfiguredHomeSpeedValues(axes.ToDictionary(axis => axis,
                    axis => _simulationConfiguredHomeSpeeds.GetOrAdd(CreateSimulationAxisKey(number, axis), 20.0),
                    StringComparer.OrdinalIgnoreCase),
                axes.ToDictionary(axis => axis, _ => "mm/sec", StringComparer.OrdinalIgnoreCase));

        var response = await ExecuteRaw($"AUTOMATION1:CONFIG:HOME_SPEEDS:{string.Join(',', axes)}", number, cancellationToken, suppressLog: true).ConfigureAwait(false);
        const string prefix = "OK:CONFIG_HOME_SPEEDS:";
        if (!response.StartsWith(prefix, StringComparison.Ordinal))
            throw new InvalidOperationException($"Saved HomeSpeed values could not be read: {response}");
        using var document = JsonDocument.Parse(response[prefix.Length..]);
        var root = document.RootElement;
        var hasMetadata = root.ValueKind == JsonValueKind.Object && root.TryGetProperty("Values", out _);
        var valuesElement = hasMetadata ? root.GetProperty("Values") : root;
        var values = valuesElement.Deserialize<Dictionary<string, double>>()
            ?? throw new InvalidOperationException("Saved HomeSpeed response was empty.");
        var units = hasMetadata && root.TryGetProperty("Units", out var unitsElement)
            ? unitsElement.Deserialize<Dictionary<string, string>>() : null;
        var result = new CConfiguredHomeSpeedValues(values, units);
        if (result.Count != axes.Length || axes.Any(axis => !result.TryGetValue(axis, out var value) || !double.IsFinite(value) || value < 0))
            throw new InvalidOperationException("Saved HomeSpeed response did not contain valid values for the requested axes.");
        return result;
    }

    /// <summary>Saves and verifies one HomeSpeed; does not change active parameters or reset the controller.</summary>
    public virtual async Task<double> SetConfiguredHomeSpeed(
        string axisName, double speed, int number = 0, CancellationToken cancellationToken = default)
    {
        var axis = ValidateConfiguredHomeAxis(axisName);
        ArgumentOutOfRangeException.ThrowIfNegative(number);
        if (!double.IsFinite(speed) || speed <= 0)
            throw new ArgumentOutOfRangeException(nameof(speed), "Home speed must be finite and greater than zero.");
        cancellationToken.ThrowIfCancellationRequested();
        try
        {
            if (IsSimul(number))
            {
                var key = CreateSimulationAxisKey(number, axis);
                _simulationConfiguredHomeSpeeds[key] = speed;
                return _simulationConfiguredHomeSpeeds[key];
            }

            var response = await ExecuteRaw($"AUTOMATION1:CONFIG:HOME_SPEED:{axis}:{speed.ToString("R", CultureInfo.InvariantCulture)}", number, cancellationToken).ConfigureAwait(false);
            const string prefix = "OK:CONFIG_HOME_SPEED:";
            if (!response.StartsWith(prefix, StringComparison.Ordinal)
                || !double.TryParse(response[prefix.Length..], NumberStyles.Float, CultureInfo.InvariantCulture, out var saved)
                || !double.IsFinite(saved) || saved != speed)
                throw new InvalidOperationException($"HomeSpeed save could not be verified. Axis={axis}, response={response}");
            return saved;
        }
        finally
        {
            // A failed readback can follow a successful save. Invalidate even when the write reports an error.
            StatusSnapshots.RequestConfiguredHomeSpeedsRefresh(number);
        }
    }

    internal static string ValidateConfiguredHomeAxis(string axisName)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(axisName);
        var axis = axisName.Trim();
        if (!IsAeroScriptAxisIdentifier(axis))
            throw new ArgumentException("Axis reference must be an axis name or a nonnegative axis number.", nameof(axisName));
        if (!axis.All(char.IsAsciiDigit)) return axis;
        if (!int.TryParse(axis, NumberStyles.None, CultureInfo.InvariantCulture, out var axisNo))
            throw new ArgumentException("Axis number is out of range.", nameof(axisName));
        return axisNo.ToString(CultureInfo.InvariantCulture);
    }
}
