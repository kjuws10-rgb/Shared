namespace Drilling.Common.Automation;

public sealed partial class CAutomationStatusSnapshotService
{
    private const int ConfiguredHomeSpeedRefreshMs = 10000;
    private const int ConfiguredHomeSpeedStaleMs = 30000;
    private readonly Dictionary<int, ConfiguredHomeSpeedEntry> _configuredHomeSpeedEntries = [];

    /// <summary>Registers requested axes and immediately returns the centrally acquired saved settings.</summary>
    public ST_AUTOMATION_STATUS_SNAPSHOT<IReadOnlyDictionary<string, double>> GetConfiguredHomeSpeeds(
        IReadOnlyList<string> axes, int controller)
    {
        ArgumentNullException.ThrowIfNull(axes);
        ArgumentOutOfRangeException.ThrowIfNegative(controller);
        var normalizedAxes = axes.Select(CAutomationManager.ValidateConfiguredHomeAxis)
            .Select(axis => axis.ToUpperInvariant()).Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
        lock (_sync)
        {
            if (_disposed) return new(null, "STOPPED", "Automation status acquisition stopped.", default);
            if (normalizedAxes.Length == 0)
                return new(ReadOnlyValues(new Dictionary<string, double>()), "OK", "No configured axes requested.", DateTimeOffset.Now);
            if (!_configuredHomeSpeedEntries.TryGetValue(controller, out var entry))
                _configuredHomeSpeedEntries.Add(controller, entry = new ConfiguredHomeSpeedEntry(controller));
            var now = Environment.TickCount64;
            var addedAxis = false;
            foreach (var axis in normalizedAxes)
            {
                addedAxis |= !entry.RequestedAxes.ContainsKey(axis);
                entry.RequestedAxes[axis] = now;
            }
            if (addedAxis) InvalidateConfiguredHomeSpeedEntry(entry);
            if (_autoStart) _worker ??= Task.Run(Collect);
            if (entry.UpdatedAt == default)
                return new(null, "LOADING", "Waiting for shared saved HomeSpeed snapshot.", default);
            if (now - entry.CollectedAt > ConfiguredHomeSpeedStaleMs)
                return new(null, "STALE", "Saved HomeSpeed snapshot is older than 30 seconds.", entry.UpdatedAt);
            return new(entry.Value, entry.State, entry.Detail, entry.UpdatedAt);
        }
    }

    /// <summary>Requests a new central read; never performs controller I/O on the caller.</summary>
    public void RequestConfiguredHomeSpeedsRefresh(int controller)
    {
        ArgumentOutOfRangeException.ThrowIfNegative(controller);
        lock (_sync)
        {
            if (!_disposed && _configuredHomeSpeedEntries.TryGetValue(controller, out var entry))
                InvalidateConfiguredHomeSpeedEntry(entry);
        }
    }

    // Caller holds _sync. Each axis has its own demand lease so one consumer cannot retain unused axes.
    private ConfiguredHomeSpeedRead[] PrepareConfiguredHomeSpeedReads(long now)
    {
        var reads = new List<ConfiguredHomeSpeedRead>();
        foreach (var pair in _configuredHomeSpeedEntries.ToArray())
        {
            var entry = pair.Value;
            var expired = entry.RequestedAxes.Where(axis => now - axis.Value > LeaseMs).Select(axis => axis.Key).ToArray();
            foreach (var axis in expired) entry.RequestedAxes.Remove(axis);
            if (entry.RequestedAxes.Count == 0)
            {
                _configuredHomeSpeedEntries.Remove(pair.Key);
                continue;
            }
            if (expired.Length > 0) InvalidateConfiguredHomeSpeedEntry(entry);
            if (entry.InFlight || entry.UpdatedAt != default && now - entry.LastAttemptAt < ConfiguredHomeSpeedRefreshMs) continue;
            entry.InFlight = true;
            entry.LastAttemptAt = now;
            reads.Add(new(entry.Controller, entry, entry.RequestedAxes.Keys.ToArray(), entry.Version));
        }
        return reads.ToArray();
    }

    private void CollectConfiguredHomeSpeeds(ConfiguredHomeSpeedRead read, CancellationToken token)
    {
        IReadOnlyDictionary<string, double>? values = null;
        var state = "OK";
        var detail = "Shared saved HomeSpeed snapshot";
        try
        {
            token.ThrowIfCancellationRequested();
            if (!_automation.IsSimul(read.Controller) && !_automation.IsConnect(read.Controller))
                (state, detail) = ("OFFLINE", "Automation not connected.");
            else
            {
                using var timeout = CancellationTokenSource.CreateLinkedTokenSource(token);
                timeout.CancelAfter(2000);
                var result = _automation.ReadConfiguredHomeSpeeds(read.Axes, read.Controller, timeout.Token).GetAwaiter().GetResult();
                timeout.Token.ThrowIfCancellationRequested();
                if (read.Axes.Any(axis => !result.TryGetValue(axis, out var value) || !double.IsFinite(value) || value < 0))
                    throw new InvalidOperationException("Saved HomeSpeed snapshot did not contain valid values for all requested axes.");
                values = ReadOnlyValues(result);
            }
        }
        catch (OperationCanceledException) when (token.IsCancellationRequested)
        {
            lock (_sync) read.Entry.InFlight = false;
            throw;
        }
        catch (Exception exception) { (state, detail) = ("ERROR", exception.Message); }
        lock (_sync)
        {
            read.Entry.InFlight = false;
            // SET/REFRESH or a new axis may invalidate an already-running read. Never republish it.
            if (_disposed || !_configuredHomeSpeedEntries.TryGetValue(read.Controller, out var current) ||
                !ReferenceEquals(current, read.Entry) || current.Version != read.Version) return;
            current.Value = values;
            current.State = state;
            current.Detail = detail;
            current.UpdatedAt = DateTimeOffset.Now;
            current.CollectedAt = Environment.TickCount64;
        }
    }

    private static IReadOnlyDictionary<string, double> ReadOnlyValues(IEnumerable<KeyValuePair<string, double>> values)
        => new CConfiguredHomeSpeedValues(values, (values as CConfiguredHomeSpeedValues)?.Units);

    private static void InvalidateConfiguredHomeSpeedEntry(ConfiguredHomeSpeedEntry entry)
    {
        entry.Version++;
        entry.Value = null;
        entry.State = "LOADING";
        entry.Detail = "Waiting for shared saved HomeSpeed snapshot.";
        entry.UpdatedAt = default;
        entry.CollectedAt = 0;
        entry.LastAttemptAt = 0;
    }

    private sealed class ConfiguredHomeSpeedEntry(int controller)
    {
        public int Controller { get; } = controller;
        public Dictionary<string, long> RequestedAxes { get; } = new(StringComparer.OrdinalIgnoreCase);
        public IReadOnlyDictionary<string, double>? Value;
        public string State = "LOADING";
        public string Detail = "";
        public DateTimeOffset UpdatedAt;
        public long CollectedAt;
        public long LastAttemptAt;
        public long Version;
        public bool InFlight;
    }

    private sealed record ConfiguredHomeSpeedRead(int Controller, ConfiguredHomeSpeedEntry Entry, string[] Axes, long Version);
}
