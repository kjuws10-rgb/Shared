namespace Drilling.Common.Automation;

public sealed partial class CAutomationStatusSnapshotService
{
    public ST_AUTOMATION_STATUS_SNAPSHOT<ST_MOF_READINESS> GetMofReadiness(int task, int controller)
        => Get<ST_MOF_READINESS>($"MOF_READY|{controller}|{task}", controller,
            token => _automation.ReadMofReadiness(task, controller, token).GetAwaiter().GetResult());

    public void InvalidateMofReadiness(int task, int controller)
    {
        GetMofReadiness(task, controller);
        InvalidateEntry($"MOF_READY|{controller}|{task}");
    }
}
