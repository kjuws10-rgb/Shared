using System.Diagnostics;

namespace Drilling.Common.Automation;

public sealed record ST_AUTOMATION_STATUS_SNAPSHOT<T>(T? Value, string State, string Detail, DateTimeOffset UpdatedAt) where T : class
{
    public long Version { get; init; }
    public long CollectedTimestamp { get; init; }
}

/// <summary>One acquisition owner per Automation manager. Consumers only register/read cached values.</summary>
public sealed partial class CAutomationStatusSnapshotService : IDisposable
{
    private readonly CAutomationManager _automation;
    private readonly object _sync = new();
    private readonly Dictionary<string, Entry> _entries = new(StringComparer.Ordinal);
    private readonly CancellationTokenSource _stop = new();
    private readonly bool _autoStart;
    private Task? _worker;
    private bool _disposed;
    private const int LeaseMs = 10000;
    private const int StaleMs = 5000;

    internal CAutomationStatusSnapshotService(CAutomationManager automation, bool autoStart = true)
    {
        _automation = automation;
        _autoStart = autoStart;
    }

    public ST_AUTOMATION_STATUS_SNAPSHOT<ST_AUTOMATION_AXIS_STATUS> GetAxis(string axis, int controller, int aio, bool extended)
        => Get<ST_AUTOMATION_AXIS_STATUS>($"AXIS|{controller}|{axis.Trim().ToUpperInvariant()}|{aio}|{extended}", controller,
            token => _automation.ReadAxisStatusByNameNoLog(axis, controller, aio, extended, token));

    /// <summary>Invalidate after a command acknowledgement so an earlier in-flight read cannot complete that command.</summary>
    public void InvalidateAxis(string axis, int controller, int aio = 0, bool extended = false)
    {
        GetAxis(axis, controller, aio, extended);
        var key = $"AXIS|{controller}|{axis.Trim().ToUpperInvariant()}|{aio}|{extended}";
        lock (_sync)
        {
            if (_disposed || !_entries.TryGetValue(key, out var entry)) return;
            entry.Generation++;
            entry.Version++;
            entry.Value = null;
            entry.State = "LOADING";
            entry.Detail = "Waiting for an Automation snapshot collected after the command.";
            entry.UpdatedAt = default;
            entry.CollectedAt = 0;
            entry.CollectedTimestamp = 0;
        }
    }

    public ST_AUTOMATION_STATUS_SNAPSHOT<string> GetTask(int task, int controller)
        => Get<string>($"TASK|{controller}|{task}", controller,
            token => _automation.ReadTaskStatus(task, controller, token).GetAwaiter().GetResult());

    public ST_AUTOMATION_STATUS_SNAPSHOT<string> GetProcessorUsage(int controller)
        => Get<string>($"CPU|{controller}", controller,
            token => _automation.ReadProcessorUsage(controller, token).GetAwaiter().GetResult());

    internal ST_AUTOMATION_STATUS_SNAPSHOT<T> Get<T>(string key, int controller, Func<CancellationToken, object> read) where T : class
    {
        lock (_sync)
        {
            if (_disposed) return new(null, "STOPPED", "Automation status acquisition stopped.", default);
            var now = Environment.TickCount64;
            if (!_entries.TryGetValue(key, out var entry))
                _entries.Add(key, entry = new Entry(controller, read));
            entry.LastRequested = now;
            if (_autoStart) _worker ??= Task.Run(Collect);
            if (entry.UpdatedAt == default) return new(null, "LOADING", "Waiting for shared Automation snapshot.", default) { Version = entry.Version };
            if (now - entry.CollectedAt > StaleMs) return new(null, "STALE", "Automation snapshot is older than 5 seconds.", entry.UpdatedAt)
                { Version = entry.Version, CollectedTimestamp = entry.CollectedTimestamp };
            return new(entry.Value as T, entry.State, entry.Detail, entry.UpdatedAt)
                { Version = entry.Version, CollectedTimestamp = entry.CollectedTimestamp };
        }
    }

    private async Task Collect()
    {
        try
        {
            while (!_stop.IsCancellationRequested)
            {
                var elapsed = Stopwatch.StartNew();
                await CollectOnce(_stop.Token).ConfigureAwait(false);
                await Task.Delay(Math.Max(1, 1000 - (int)Math.Min(1000, elapsed.ElapsedMilliseconds)), _stop.Token).ConfigureAwait(false);
            }
        }
        catch (OperationCanceledException) when (_stop.IsCancellationRequested) { }
    }

    internal Task CollectOnce(CancellationToken token)
    {
        Entry[] entries;
        ConfiguredHomeSpeedRead[] configuredReads;
        lock (_sync)
        {
            var now = Environment.TickCount64;
            foreach (var key in _entries.Where(pair => now - pair.Value.LastRequested > LeaseMs).Select(pair => pair.Key).ToArray())
                _entries.Remove(key);
            entries = _entries.Values.ToArray();
            configuredReads = PrepareConfiguredHomeSpeedReads(now);
        }
        // Different controllers are independent; each controller has one sequential read queue.
        return Task.WhenAll(entries.Select(entry => entry.Controller).Concat(configuredReads.Select(read => read.Controller)).Distinct().Select(controller => Task.Run(() =>
        {
            foreach (var entry in entries.Where(entry => entry.Controller == controller))
            {
                token.ThrowIfCancellationRequested();
                long generation;
                long collectedTimestamp;
                lock (_sync)
                {
                    if (_disposed) return;
                    generation = entry.Generation;
                    collectedTimestamp = Stopwatch.GetTimestamp();
                }
                object? value = null;
                var state = "OK";
                var detail = "Shared Automation snapshot";
                try
                {
                    if (!_automation.IsSimul(entry.Controller) && !_automation.IsConnect(entry.Controller))
                        (state, detail) = ("OFFLINE", "Automation not connected.");
                    else
                    {
                        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(token);
                        timeout.CancelAfter(2000);
                        value = entry.Read(timeout.Token);
                        timeout.Token.ThrowIfCancellationRequested();
                    }
                }
                catch (OperationCanceledException) when (token.IsCancellationRequested) { throw; }
                catch (Exception exception) { (state, detail) = ("ERROR", exception.Message); }
                lock (_sync)
                {
                    if (_disposed) return;
                    if (entry.Generation != generation) continue;
                    entry.Value = value;
                    entry.State = state;
                    entry.Detail = detail;
                    entry.UpdatedAt = DateTimeOffset.Now;
                    entry.CollectedAt = Environment.TickCount64;
                    entry.CollectedTimestamp = collectedTimestamp;
                    entry.Version++;
                }
            }
            foreach (var read in configuredReads.Where(read => read.Controller == controller))
                CollectConfiguredHomeSpeeds(read, token);
        }, token)));
    }

    public void Dispose()
    {
        lock (_sync)
        {
            if (_disposed) return;
            _disposed = true;
            _entries.Clear();
            _configuredHomeSpeedEntries.Clear();
        }
        _stop.Cancel();
        // Do not dispose the token source while an SDK read may still be unwinding.
        if (_worker is { } worker)
            _ = worker.ContinueWith(_ => _stop.Dispose(), TaskScheduler.Default);
        else _stop.Dispose();
    }

    private sealed class Entry(int controller, Func<CancellationToken, object> read)
    {
        public int Controller { get; } = controller;
        public Func<CancellationToken, object> Read { get; } = read;
        public long LastRequested;
        public long CollectedAt;
        public object? Value;
        public string State = "LOADING";
        public string Detail = "";
        public DateTimeOffset UpdatedAt;
        public long Generation;
        public long Version;
        public long CollectedTimestamp;
    }
}
