using System.Globalization;

namespace Drilling.Common.Automation;

public sealed record ST_AUXILIARY_FEEDBACK(double Position);
public sealed record ST_MOF_ZERO_TARGET(int Controller, int Task, string Axis);

public partial class CAutomationManager
{
    public async Task RunStagePreparedScript(string file, int task, int controller, CancellationToken token)
    {
        var response = await RunScriptIfIdle(file, task, controller, token).ConfigureAwait(false);
        EnsureAutomationResponseSucceeded(response, $"Stage script RUN failed: {file}.");
        if (IsSimul(controller)) RegisterStageSimulationTask(controller, task, file, buffered: false);
        StatusSnapshots.InvalidateTask(task, controller);
    }

    public async Task StopStagePreparedTask(int task, int controller, CancellationToken token)
    {
        var response = await StopTask(task, controller, token).ConfigureAwait(false);
        EnsureAutomationResponseSucceeded(response, $"Stage Task stop failed: {task}.");
        StatusSnapshots.InvalidateTask(task, controller);
        using var limit = CancellationTokenSource.CreateLinkedTokenSource(token);
        limit.CancelAfter(TimeSpan.FromSeconds(5));
        while (true)
        {
            limit.Token.ThrowIfCancellationRequested();
            var sample = StatusSnapshots.GetTask(task, controller);
            if (sample.State is "ERROR" or "OFFLINE" or "STOPPED")
                throw new InvalidOperationException($"Cannot confirm Task STOP: {task}. {sample.Detail}");
            var fields = sample.State == "OK" ? sample.Value?.Split(':') : null;
            if (fields is { Length: >= 4 } && fields[0] == "OK" && fields[1] == "TASK" &&
                int.TryParse(fields[2], out var taskNo) && taskNo == task && fields[3] is "Idle" or "ProgramComplete" or "QueueComplete" or "Stopped") return;
            await Task.Delay(50, limit.Token).ConfigureAwait(false);
        }
    }
    internal async Task<ST_AUXILIARY_FEEDBACK> ReadAuxiliaryFeedback(string axis, int controller, CancellationToken token)
    {
        ValidateAxisNameOnly(axis);
        if (IsSimul(controller)) return new(0);
        var response = await ExecuteRaw($"AUTOMATION1:FEEDBACK|READ_AUX|{axis}", controller, token, suppressLog: true).ConfigureAwait(false);
        const string prefix = "OK:AUX:";
        if (!response.StartsWith(prefix, StringComparison.Ordinal) ||
            !double.TryParse(response[prefix.Length..], NumberStyles.Float, CultureInfo.InvariantCulture, out var value) || !double.IsFinite(value))
            throw new InvalidOperationException($"Auxiliary feedback read failed: {axis}. {response}");
        return new(value);
    }

    public async Task SetAuxiliaryFeedbackZero(string axis, int task, int controller, CancellationToken token = default)
    {
        ValidateAxisNameOnly(axis);
        if (task < 1) throw new ArgumentOutOfRangeException(nameof(task));
        if (!IsSimul(controller))
        {
            var response = await ExecuteRaw($"AUTOMATION1:FEEDBACK|ZERO_AUX|{axis}|{task}", controller, token).ConfigureAwait(false);
            EnsureAutomationResponseSucceeded(response, $"Auxiliary encoder zero failed: {axis}.");
        }
        StatusSnapshots.InvalidateAuxiliaryFeedback(axis, controller);
    }

    public Task ZeroMofFeedbackIfNeeded(IEnumerable<ST_MOF_ZERO_TARGET> targets, CancellationToken token = default)
        => new CMofZeroOperation(
            target => StatusSnapshots.GetAuxiliaryFeedback(target.Axis, target.Controller),
            (target, ct) => SetAuxiliaryFeedbackZero(target.Axis, target.Task, target.Controller, ct))
            .Execute(targets, token);
}

/// <summary>Uses the shared acquisition cache; zero axes are never sent a write command.</summary>
public sealed class CMofZeroOperation(
    Func<ST_MOF_ZERO_TARGET, ST_AUTOMATION_STATUS_SNAPSHOT<ST_AUXILIARY_FEEDBACK>> read,
    Func<ST_MOF_ZERO_TARGET, CancellationToken, Task> zero)
{
    public async Task Execute(IEnumerable<ST_MOF_ZERO_TARGET> targets, CancellationToken token = default)
    {
        foreach (var target in targets.DistinctBy(t => (t.Controller, t.Axis.Trim().ToUpperInvariant())))
        {
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(token);
            timeout.CancelAfter(TimeSpan.FromSeconds(10));
            var before = await WaitForValue(target, timeout.Token).ConfigureAwait(false);
            if (before.Value!.Position == 0) continue;
            await zero(target, timeout.Token).ConfigureAwait(false);
            // The command invalidates the cache generation. Require a later collection,
            // never the pre-command sample or an in-flight read from the old generation.
            while (true)
            {
                var after = await WaitForValue(target, timeout.Token).ConfigureAwait(false);
                if (after.Version > before.Version && after.Value!.Position == 0) break;
                await Task.Delay(50, timeout.Token).ConfigureAwait(false);
            }
        }
    }

    private async Task<ST_AUTOMATION_STATUS_SNAPSHOT<ST_AUXILIARY_FEEDBACK>> WaitForValue(ST_MOF_ZERO_TARGET target, CancellationToken token)
    {
        while (true)
        {
            token.ThrowIfCancellationRequested();
            var sample = read(target);
            if (sample.State == "OK" && sample.Value is { } value && double.IsFinite(value.Position)) return sample;
            if (sample.State is "ERROR" or "OFFLINE" or "STOPPED")
                throw new InvalidOperationException($"MOF feedback unavailable: Controller {target.Controller}, {target.Axis}. {sample.State}: {sample.Detail}");
            await Task.Delay(50, token).ConfigureAwait(false);
        }
    }
}
