using System.Collections.Concurrent;
using System.Globalization;

namespace Drilling.Common.Automation;

public partial class CAutomationManager
{
    private readonly ConcurrentDictionary<(int Controller, int Task), CSimulatedMofReadiness> _simulatedMofReadiness = new();

    public virtual async Task PrepareMofReadiness(int task, int controller, long runId, CancellationToken token)
    {
        token.ThrowIfCancellationRequested();
        var index = CMofReadiness.VariableIndex(task);
        if (runId <= 0) throw new ArgumentOutOfRangeException(nameof(runId));
        if (IsSimul(controller))
            _simulatedMofReadiness[(controller, task)] = new(runId);
        else
        {
            var response = await ExecuteRaw($"AUTOMATION1:VARIABLE|SET_GLOBAL_INTEGER|{index}|0", controller, token).ConfigureAwait(false);
            EnsureAutomationResponseSucceeded(response, $"MOF readiness reset failed: A{controller}/T{task}.");
        }
        StatusSnapshots.InvalidateMofReadiness(task, controller);
    }

    public virtual async Task<ST_MOF_READINESS> ReadMofReadiness(int task, int controller, CancellationToken token)
    {
        token.ThrowIfCancellationRequested();
        var index = CMofReadiness.VariableIndex(task);
        if (IsSimul(controller))
            return new(_simulatedMofReadiness.TryGetValue((controller, task), out var ready) ? ready.Value : 0);
        var response = await ExecuteRaw($"AUTOMATION1:VARIABLE|GET_GLOBAL_INTEGER|{index}", controller, token, suppressLog: true).ConfigureAwait(false);
        var fields = response.Split(':');
        if (fields.Length != 4 || fields[0] != "OK" || fields[1] != "GLOBAL_INTEGER" ||
            !int.TryParse(fields[2], NumberStyles.Integer, CultureInfo.InvariantCulture, out var receivedIndex) || receivedIndex != index ||
            !long.TryParse(fields[3], NumberStyles.Integer, CultureInfo.InvariantCulture, out var value))
            throw new InvalidOperationException($"MOF readiness read failed: A{controller}/T{task}. {response}");
        return new(value);
    }

    private async Task PublishSimulatedMofReadiness(int controller, int task, CStageSimulatedTask session)
    {
        if (!_simulatedMofReadiness.TryGetValue((controller, task), out var ready)) return;
        await Task.Delay(200).ConfigureAwait(false);
        if (!session.IsActive || !_stageSimulationTasks.TryGetValue((controller, task), out var active) || !ReferenceEquals(active, session) ||
            !_simulatedMofReadiness.TryGetValue((controller, task), out var current) || !ReferenceEquals(current, ready)) return;
        ready.Publish();
        StatusSnapshots.InvalidateMofReadiness(task, controller);
    }

    private sealed class CSimulatedMofReadiness(long expected)
    {
        private long _value;
        public long Value => Interlocked.Read(ref _value);
        public void Publish() => Interlocked.Exchange(ref _value, expected);
    }
}
