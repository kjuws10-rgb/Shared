using System.Globalization;
using Aerotech.Automation1.DotNet;

namespace Drilling.Common.Automation;

public static class CAutomationAxisFault
{
    public static long? ParseMask(string value)
    {
        var text = value.Trim();
        if (text.Equals("None", StringComparison.OrdinalIgnoreCase)) return 0;
        if (text.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
            return long.TryParse(text[2..], NumberStyles.HexNumber, CultureInfo.InvariantCulture, out var hex) && hex >= 0 ? hex : null;
        return long.TryParse(text, NumberStyles.Integer, CultureInfo.InvariantCulture, out var mask) && mask >= 0 ? mask : null;
    }

    public static bool RequiresReset(long mask) => (mask & (long)AxisFault.InternalFault) != 0;
    public static bool HasLimitFault(long mask) => (mask & (long)(AxisFault.CwEndOfTravelLimitFault | AxisFault.CcwEndOfTravelLimitFault |
        AxisFault.CwSoftwareLimitFault | AxisFault.CcwSoftwareLimitFault)) != 0;

    public static string Describe(long mask)
    {
        if (mask == 0) return "활성 Fault 없음";
        var names = new List<string>();
        long known = 0;
        foreach (var name in Enum.GetNames<AxisFault>().Where(name => name.EndsWith("Fault", StringComparison.Ordinal)))
        {
            var fault = Enum.Parse<AxisFault>(name);
            var bit = (long)fault;
            if (bit == 0 || (known & bit) == bit || (mask & bit) != bit) continue;
            names.Add(name);
            known |= bit;
        }
        if ((mask & ~known) != 0) names.Add($"Unknown Fault: 0x{mask & ~known:X}");
        if (RequiresReset(mask)) names.Add("InternalFault는 컨트롤러 RESET이 필요합니다.");
        return $"FAULT: 0x{mask:X}\n{string.Join("\n", names)}";
    }
}
