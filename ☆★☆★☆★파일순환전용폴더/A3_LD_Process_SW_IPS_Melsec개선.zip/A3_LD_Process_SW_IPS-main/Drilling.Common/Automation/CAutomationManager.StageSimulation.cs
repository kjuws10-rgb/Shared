namespace Drilling.Common.Automation;

public sealed record ST_STAGE_TASK_SIMULATION_TARGET(int HeadNo, int Controller, int Task);

public partial class CAutomationManager
{
    private readonly System.Collections.Concurrent.ConcurrentDictionary<(int Controller, int Task), CStageSimulatedTask> _stageSimulationTasks = new();

    private CStageSimulatedTask RegisterStageSimulationTask(int controller, int task, string file, bool buffered)
    {
        var session = new CStageSimulatedTask(file, buffered, () => StatusSnapshots.InvalidateTask(task, controller));
        _stageSimulationTasks.AddOrUpdate((controller, task), session, (_, previous) =>
            previous.IsActive ? throw new InvalidOperationException($"Simulated Task is already running: A{controller}/T{task}.") : session);
        StatusSnapshots.InvalidateTask(task, controller);
        _ = PublishSimulatedMofReadiness(controller, task, session);
        return session;
    }

    /// <summary>Only the Automation interface's own simulation setting permits a virtual completion.</summary>
    public void StartStageMachiningSimulation(IReadOnlyList<ST_STAGE_TASK_SIMULATION_TARGET> targets, CancellationToken token)
    {
        var ordered = targets.OrderBy(target => target.HeadNo).ToArray();
        for (var index = 0; index < ordered.Length; index++)
        {
            token.ThrowIfCancellationRequested();
            var target = ordered[index];
            if (!IsSimul(target.Controller)) continue;
            if (!_stageSimulationTasks.TryGetValue((target.Controller, target.Task), out var session))
                throw new InvalidOperationException($"No simulated RUN for H{target.HeadNo:00}: A{target.Controller}/T{target.Task}.");
            session.Start(TimeSpan.FromSeconds(3 + index), token);
        }
    }

    private sealed class CStageSimulatedTask(string file, bool buffered, Action changed)
    {
        private readonly object _sync = new();
        private readonly TaskCompletionSource _completion = new(TaskCreationOptions.RunContinuationsAsynchronously);
        private readonly CancellationTokenSource _stop = new();
        private string _state = buffered ? "QueueRunning" : "ProgramRunning";
        private bool _started;
        public string File { get; } = file;
        public string State { get { lock (_sync) return _state; } }
        public bool IsActive => State is "QueueRunning" or "ProgramRunning";
        public Task Completion => _completion.Task;

        public void Start(TimeSpan duration, CancellationToken token)
        {
            lock (_sync)
            {
                if (_started) throw new InvalidOperationException("Simulated machining was already started.");
                if (!IsActive) throw new InvalidOperationException("Simulated Task is no longer running.");
                _started = true;
            }
            _ = CompleteAfter(duration, token);
        }

        private async Task CompleteAfter(TimeSpan duration, CancellationToken token)
        {
            using var limit = CancellationTokenSource.CreateLinkedTokenSource(token, _stop.Token);
            try
            {
                await Task.Delay(duration, limit.Token).ConfigureAwait(false);
                lock (_sync)
                {
                    limit.Token.ThrowIfCancellationRequested();
                    if (!IsActive) return;
                    _state = buffered ? "QueueComplete" : "ProgramComplete";
                    _completion.TrySetResult();
                }
                changed();
            }
            catch (OperationCanceledException) { Stop(); }
            finally { lock (_sync) _stop.Dispose(); }
        }

        public void Stop()
        {
            lock (_sync)
            {
                if (!IsActive) return;
                _state = "Stopped";
                _completion.TrySetCanceled();
                _stop.Cancel();
                if (!_started) _stop.Dispose();
            }
            changed();
        }
    }
}
