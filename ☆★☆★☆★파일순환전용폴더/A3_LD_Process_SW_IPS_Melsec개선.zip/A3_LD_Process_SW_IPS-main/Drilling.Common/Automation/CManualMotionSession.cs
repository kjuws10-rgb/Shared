namespace Drilling.Common.Automation;

/// <summary>Orders manual starts and stops, including a release while a start is still pending.</summary>
public sealed class CManualMotionSession
{
    private readonly SemaphoreSlim _gate = new(1, 1);
    private long _generation;
    private Func<Task>? _stopJog;
    public long Generation => Interlocked.Read(ref _generation);
    public void Invalidate() => Interlocked.Increment(ref _generation);

    public async Task Execute(long generation, Func<Task> action, Func<Task>? stopJog = null)
    {
        await _gate.WaitAsync();
        try
        {
            if (generation != Generation) return;
            if (_stopJog is not null) throw new InvalidOperationException("JOG를 먼저 정지해 주세요.");
            // Retain the stop callback even if the start reports an error after transmission.
            _stopJog = stopJog;
            await action();
        }
        finally { _gate.Release(); }
    }

    public async Task StopJog()
    {
        Invalidate();
        await _gate.WaitAsync();
        try
        {
            if (_stopJog is null) return;
            await _stopJog();
            _stopJog = null;
        }
        finally { _gate.Release(); }
    }

    public async Task StopAll(Func<Task> stopAll)
    {
        Invalidate();
        await _gate.WaitAsync();
        try
        {
            var errors = new List<Exception>();
            try { if (_stopJog is not null) { await _stopJog(); _stopJog = null; } }
            catch (Exception exception) { errors.Add(exception); }
            try { await stopAll(); }
            catch (Exception exception) { errors.Add(exception); }
            if (errors.Count > 0) throw new AggregateException(errors);
        }
        finally { _gate.Release(); }
    }
}
