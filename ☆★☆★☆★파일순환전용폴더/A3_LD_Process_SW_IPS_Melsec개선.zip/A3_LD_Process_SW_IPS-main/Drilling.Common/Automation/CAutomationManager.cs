using System.Collections.Concurrent;
using System.Globalization;
using Drilling.Common.Interface;
using Drilling.Common.Managers;

namespace Drilling.Common.Automation;
public sealed record ST_BUFFERED_SCRIPT_RUN_ITEM(string LocalScriptPath, string ScriptFileName, int TaskIndex);
// MotorTemperature is the converted Galvo temperature in °C (NaN when unavailable); RawResponse retains the original input.
public sealed record ST_AUTOMATION_AXIS_STATUS(int AutomationNo, string AxisName, int? AxisNo, double PositionFeedback, double PositionCommand, double AuxiliaryFeedback, double CurrentFeedback, double GalvoLaserOutputRaw, double MotorTemperature, bool Able, bool HomeDone, bool HasError, string DriveStatus, string HomeState, string Fault, string RawResponse, DateTimeOffset UpdatedAt)
{
    public bool? IsInPosition { get; init; }
    public bool? IsMotionDone { get; init; }
}
public partial class CAutomationManager
{
    private const string LocalScriptPathKey = "LocalScriptPath";
    private const string AutomationScriptPathKey = "AutomationScriptPath";
    private const long Automation1DriveStatusEnabledMask = 1L;
    private const long Automation1AxisStatusHomedMask = 1L;
    private static readonly IReadOnlyDictionary<string, int> AxisNoMap = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase)
    {
        ["GX"] = 0,
        ["GY"] = 1
    };
    private readonly CInterfaceManager _interfaceManager;
    private readonly CSettingManager? _settingManager;
    private readonly string _projectRoot;
    private readonly string _defaultLocalScriptDirectory;
    private readonly ConcurrentDictionary<string, bool> _simulationAxisAbleStates = new(StringComparer.OrdinalIgnoreCase);
    private readonly ConcurrentDictionary<string, double> _simulationAxisPositions = new(StringComparer.OrdinalIgnoreCase);
    public CAutomationStatusSnapshotService StatusSnapshots { get; }
    public CAutomationManager(CInterfaceManager interfaceManager, CSettingManager? settingManager = null, string projectRoot = "", string defaultLocalScriptDirectory = "")
    {
        _interfaceManager = interfaceManager;
        StatusSnapshots = new CAutomationStatusSnapshotService(this);
        _settingManager = settingManager;
        _projectRoot = string.IsNullOrWhiteSpace(projectRoot) ? AppContext.BaseDirectory : projectRoot;
        _defaultLocalScriptDirectory = string.IsNullOrWhiteSpace(defaultLocalScriptDirectory) ? Path.Combine(_projectRoot, "Data", "Script") : defaultLocalScriptDirectory;
    }

    public Task Connect(int number = 0, CancellationToken cancellationToken = default)
    {
        return _interfaceManager.Connect(EN_EQP_MODULE.Automation1, number, cancellationToken: cancellationToken);
    }

    public Task Disconnect(int number = 0, CancellationToken cancellationToken = default)
    {
        return _interfaceManager.Disconnect(EN_EQP_MODULE.Automation1, number, cancellationToken);
    }

    public bool IsConnect(int number = 0)
    {
        return _interfaceManager.IsConnect(EN_EQP_MODULE.Automation1, number);
    }

    public bool IsSimul(int number = 0)
    {
        return _interfaceManager.IsSimul(EN_EQP_MODULE.Automation1, number);
    }

    public Task<string> ReadStatus(int number = 0, CancellationToken cancellationToken = default)
    {
        return ExecuteRaw("AUTOMATION1:STATUS", number, cancellationToken);
    }

    public async Task<IReadOnlyList<string>> ReadControllerAxes(int number = 0, CancellationToken cancellationToken = default)
    {
        var response = await ExecuteRaw("AUTOMATION1:SYSTEM:AXES", number, cancellationToken, suppressLog: true);
        const string prefix = "OK:AXES:";
        if (!response.StartsWith(prefix, StringComparison.Ordinal))
            throw new InvalidOperationException($"Controller axis list could not be read: {response}");
        return response[prefix.Length..].Split(',', StringSplitOptions.RemoveEmptyEntries)
            .Select(Uri.UnescapeDataString).Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
    }

    public Task<string> ReadProcessorUsage(int number = 0, CancellationToken cancellationToken = default)
    {
        return ExecuteRaw("AUTOMATION1:SYSTEM:PROCESSOR_USAGE", number, cancellationToken);
    }

    public Task<string> ResetController(int number = 0, CancellationToken cancellationToken = default)
    {
        if (IsSimul(number))
        {
            return Task.FromResult($"OK:SYSTEM:RESET:{number.ToString(CultureInfo.InvariantCulture)}");
        }

        return ExecuteRaw("AUTOMATION1:SYSTEM:RESET", number, cancellationToken);
    }

    public Task<string> ReadIo(string address, int number = 0, CancellationToken cancellationToken = default)
    {
        var ioAddress = ValidateIoAddress(address, outputOnly: false);
        return ExecuteRaw($"AUTOMATION1:IO:{ioAddress}:READ", number, cancellationToken);
    }

    public Task<string> SetIo(string address, bool isOn, int number = 0, CancellationToken cancellationToken = default)
    {
        var ioAddress = ValidateIoAddress(address, outputOnly: true);
        return ExecuteRaw($"AUTOMATION1:IO:{ioAddress}:{(isOn ? "ON" : "OFF")}", number, cancellationToken);
    }

    private static string ValidateIoAddress(string address, bool outputOnly)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(address);
        var value = address.Trim();
        bool MatchesItem(char character)
        {
            return character is ':' or '|' or '\r' or '\n' || char.IsControl(character) || char.IsWhiteSpace(character);
        }

        if (value.Any(MatchesItem))
        {
            throw new InvalidOperationException($"Automation1 IO address contains an invalid command delimiter: {address}");
        }

        var normalized = value.ToUpperInvariant();
        var parts = normalized.Split(['.', '/', ','], StringSplitOptions.None);
        if (parts.Length != 2)
        {
            throw new InvalidOperationException($"Automation1 IO address is invalid: {address}. Use A0.DO1, A0.DI1, or 0.1.");
        }

        var axisText = TrimIoAxisPrefix(parts[0]);
        var bitText = parts[1];
        var isOutput = false;
        if (bitText.StartsWith("DO", StringComparison.Ordinal))
        {
            isOutput = true;
            bitText = bitText[2..];
        }
        else if (bitText.StartsWith("DI", StringComparison.Ordinal))
        {
            bitText = bitText[2..];
        }
        else if (bitText.StartsWith("Y", StringComparison.Ordinal))
        {
            isOutput = true;
            bitText = bitText[1..];
        }
        else if (bitText.StartsWith("X", StringComparison.Ordinal))
        {
            bitText = bitText[1..];
        }

        if (outputOnly && !isOutput)
        {
            throw new InvalidOperationException($"Automation1 IO output command can use DO/Y address only: {address}");
        }

        if (!IsUnsignedInteger(axisText) || !IsUnsignedInteger(bitText) || !int.TryParse(axisText, NumberStyles.None, CultureInfo.InvariantCulture, out var axisNo) || !int.TryParse(bitText, NumberStyles.None, CultureInfo.InvariantCulture, out var bitNo) || axisNo < 0 || bitNo < 0 || bitNo > 63)
        {
            throw new InvalidOperationException($"Automation1 IO address is invalid: {address}. Use A0.DO1, A0.DI1, or 0.1.");
        }

        return value;
    }

    private static string TrimIoAxisPrefix(string axisText)
    {
        if (axisText.StartsWith("AXIS", StringComparison.Ordinal))
        {
            return axisText[4..];
        }

        return axisText.StartsWith("A", StringComparison.Ordinal) ? axisText[1..] : axisText;
    }

    private static bool IsUnsignedInteger(string value)
    {
        return value.Length > 0 && value.All(char.IsAsciiDigit);
    }

    private Task<string> ExecuteRaw(string command, int number, CancellationToken cancellationToken, bool suppressLog = false)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(command);
        return suppressLog ? _interfaceManager.ExecuteFunctionNoLog(EN_EQP_MODULE.Automation1, number, command, cancellationToken) : _interfaceManager.ExecuteFunction(EN_EQP_MODULE.Automation1, number, command, cancellationToken);
    }

    public Task<string> Move(string axisName, double targetPosition, double velocity = 100.0, int number = 0, CancellationToken cancellationToken = default)
    {
        return ExecuteAxis(axisName, $"MOVE_ABS:{Format(targetPosition)}:{Format(velocity)}", number, cancellationToken);
    }

    public Task<string> MoveRel(string axisName, double distance, double velocity = 100.0, int number = 0, CancellationToken cancellationToken = default)
    {
        return ExecuteAxis(axisName, $"MOVE_REL:{Format(distance)}:{Format(velocity)}", number, cancellationToken);
    }

    public Task<string> Stop(string axisName, int number = 0, CancellationToken cancellationToken = default)
    {
        return ExecuteAxis(axisName, "STOP", number, cancellationToken);
    }

    public Task<string> ManualMove(string axisName, double value, double velocity, bool relative, int number, CancellationToken cancellationToken = default)
    {
        if (!double.IsFinite(value) || !double.IsFinite(velocity) || velocity <= 0)
            throw new ArgumentOutOfRangeException(nameof(velocity), "Position and speed must be finite; speed must be positive.");
        return ExecuteAxis(axisName, $"MANUAL_{(relative ? "REL" : "ABS")}:{Format(value)}:{Format(velocity)}", number, cancellationToken);
    }

    public Task<string> JogStart(string axisName, double velocity, int number)
    {
        if (!double.IsFinite(velocity) || velocity == 0) throw new ArgumentOutOfRangeException(nameof(velocity));
        return ExecuteAxis(axisName, $"JOG_START:{Format(velocity)}", number, default);
    }

    public Task<string> JogStop(string axisName, int number)
        => ExecuteAxis(axisName, "JOG_STOP", number, default);

    public Task<string> AbortMotion(string axisName, int number, CancellationToken cancellationToken = default)
        => ExecuteAxis(axisName, "ABORT_MOTION", number, cancellationToken);

    public Task<string> ServoOn(string axisName, int number = 0, CancellationToken cancellationToken = default)
    {
        return ExecuteAxis(axisName, "SERVO_ON", number, cancellationToken);
    }

    public Task<string> ServoOff(string axisName, int number = 0, CancellationToken cancellationToken = default)
    {
        return ExecuteAxis(axisName, "SERVO_OFF", number, cancellationToken);
    }

    public Task<string> Home(string axisName, int number = 0, CancellationToken cancellationToken = default)
    {
        return ExecuteAxis(axisName, "HOME", number, cancellationToken);
    }

    public Task<string> HomeAsync(string axisName, int number = 0, CancellationToken cancellationToken = default)
    {
        return ExecuteAxis(axisName, "HOME_ASYNC", number, cancellationToken);
    }

    public Task<string> ResetAlarm(string axisName, int number = 0, CancellationToken cancellationToken = default)
    {
        return ExecuteAxis(axisName, "RESET_ALARM", number, cancellationToken);
    }

    public Task<string> ReadAxis(string axisName, int number = 0, CancellationToken cancellationToken = default)
    {
        return ExecuteAxis(axisName, "READ", number, cancellationToken);
    }

    public ST_AUTOMATION_AXIS_STATUS ReadAxisStatus(string axisName, int number = 0, CancellationToken cancellationToken = default)
    {
        return ReadAxisStatus(axisName, number, 0, cancellationToken);
    }

    public ST_AUTOMATION_AXIS_STATUS ReadAxisStatus(string axisName, int number, int analogInputNo, CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(axisName);
        ValidateAnalogInputNo(analogInputNo);
        var normalizedAxis = axisName.Trim();
        if (IsSimul(number))
        {
            return CreateSimulationAxisStatus(number, normalizedAxis);
        }

        var response = ReadAxis(normalizedAxis, number, analogInputNo, cancellationToken).GetAwaiter().GetResult();
        return ParseAxisStatus(number, normalizedAxis, response);
    }

    public ST_AUTOMATION_AXIS_STATUS ReadAxisStatusByName(string axisName, int number = 0, CancellationToken cancellationToken = default)
    {
        return ReadAxisStatusByName(axisName, number, 0, cancellationToken);
    }

    public ST_AUTOMATION_AXIS_STATUS ReadAxisStatusByName(string axisName, int number, int analogInputNo, CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(axisName);
        ValidateAnalogInputNo(analogInputNo);
        var normalizedAxis = axisName.Trim();
        ValidateAxisNameOnly(normalizedAxis);
        if (IsSimul(number))
        {
            return CreateSimulationAxisStatus(number, normalizedAxis);
        }

        var response = ReadAxisByName(normalizedAxis, number, analogInputNo, cancellationToken).GetAwaiter().GetResult();
        return ParseAxisStatus(number, normalizedAxis, response);
    }

    public ST_AUTOMATION_AXIS_STATUS ReadAxisStatusByNameNoLog(string axisName, int number, int analogInputNo, bool readExtendedStatus, CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(axisName);
        ValidateAnalogInputNo(analogInputNo);
        var normalizedAxis = axisName.Trim();
        ValidateAxisNameOnly(normalizedAxis);
        if (IsSimul(number))
        {
            return CreateSimulationAxisStatus(number, normalizedAxis);
        }

        var response = ReadAxisByName(normalizedAxis, number, analogInputNo, readExtendedStatus, cancellationToken, suppressLog: true).GetAwaiter().GetResult();
        return ParseAxisStatus(number, normalizedAxis, response);
    }

    public async Task<string> RunLocalScript(string localScriptPath, string controllerFileName = "", int taskIndex = 1, int number = 0, CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(localScriptPath);
        ValidateTaskIndex(taskIndex);
        var resolvedLocalScriptPath = ResolveLocalScriptPath(localScriptPath, cancellationToken);
        var resolvedControllerFileName = string.IsNullOrWhiteSpace(controllerFileName) ? CreateControllerFileName(localScriptPath, cancellationToken) : CreateControllerFileName(controllerFileName, cancellationToken);
        if (IsSimul(number))
        {
            return CreateSimulationTaskStatus(taskIndex, "Idle", resolvedControllerFileName);
        }

        return await ExecuteRaw($"AUTOMATION1:SCRIPT|RUN_LOCAL|{taskIndex}|{resolvedLocalScriptPath}|{resolvedControllerFileName}", number, cancellationToken);
    }

    public virtual async Task<string> UploadScript(string localScriptPath, string scriptFileName = "", int number = 0, CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(localScriptPath);
        var resolvedLocalScriptPath = ResolveLocalScriptPath(localScriptPath, cancellationToken);
        var controllerFileName = string.IsNullOrWhiteSpace(scriptFileName) ? CreateControllerFileName(localScriptPath, cancellationToken) : CreateControllerFileName(scriptFileName, cancellationToken);
        return await ExecuteRaw($"AUTOMATION1:SCRIPT|UPLOAD|{resolvedLocalScriptPath}|{controllerFileName}", number, cancellationToken);
    }

    public virtual async Task<string> RunScript(string scriptFileName, int taskIndex = 1, int number = 0, CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(scriptFileName);
        ValidateTaskIndex(taskIndex);
        var controllerFileName = CreateControllerFileName(scriptFileName, cancellationToken);
        if (IsSimul(number))
        {
            return CreateSimulationTaskStatus(taskIndex, "Idle", controllerFileName);
        }

        return await ExecuteRaw($"AUTOMATION1:SCRIPT|RUN|{taskIndex}|{controllerFileName}", number, cancellationToken);
    }

    public async Task<string> RunScriptIfIdle(string scriptFileName, int taskIndex = 1, int number = 0, CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(scriptFileName);
        ValidateTaskIndex(taskIndex);
        var controllerFileName = CreateControllerFileName(scriptFileName, cancellationToken);
        if (IsSimul(number)) return CreateSimulationTaskStatus(taskIndex, "Idle", controllerFileName);
        return await ExecuteRaw($"AUTOMATION1:SCRIPT|RUN_IF_IDLE|{taskIndex}|{controllerFileName}", number, cancellationToken);
    }

    public async Task<string> RunBufferedScript(string localScriptPath, string scriptFileName = "", int taskIndex = 1, int number = 0, int queueSize = 100, int linesPerCommand = 1000, int timeoutMs = 600000, CancellationToken cancellationToken = default)
    {
        return await RunBufferedScripts([new ST_BUFFERED_SCRIPT_RUN_ITEM(localScriptPath, scriptFileName, taskIndex)], number, queueSize, linesPerCommand, timeoutMs, cancellationToken);
    }

    public async Task<string> RunBufferedScripts(IReadOnlyList<ST_BUFFERED_SCRIPT_RUN_ITEM> scripts, int number = 0, int queueSize = 100, int linesPerCommand = 1000, int timeoutMs = 600000, CancellationToken cancellationToken = default)
        => await RunBufferedScriptsCore(scripts, number, queueSize, linesPerCommand, timeoutMs, upload: true, stageSession: false, cancellationToken).ConfigureAwait(false);

    // DoReady already uploaded these exact files. This operation owns the queues
    // until completion/cancellation; the Station observes RUN through shared snapshots.
    public virtual Task<string> RunStagePreparedBufferedScripts(IReadOnlyList<ST_BUFFERED_SCRIPT_RUN_ITEM> scripts, int number, int queueSize, int linesPerCommand, int timeoutMs, CancellationToken cancellationToken)
        => RunBufferedScriptsCore(scripts, number, queueSize, linesPerCommand, timeoutMs, upload: false, stageSession: true, cancellationToken);

    private async Task<string> RunBufferedScriptsCore(IReadOnlyList<ST_BUFFERED_SCRIPT_RUN_ITEM> scripts, int number, int queueSize, int linesPerCommand, int timeoutMs, bool upload, bool stageSession, CancellationToken cancellationToken)
    {
        if (scripts.Count == 0)
        {
            return "OK:SCRIPT:BUFFERED_RUN:EMPTY";
        }

        var commandQueueSize = Math.Max(1, queueSize);
        var commandLinesPerCommand = Math.Max(2, linesPerCommand);
        var commandTimeoutMs = Math.Max(0, timeoutMs);
        var fields = new List<string>
        {
            "AUTOMATION1:SCRIPT",
            "BUFFERED_RUN_GROUP",
            commandQueueSize.ToString(CultureInfo.InvariantCulture),
            commandLinesPerCommand.ToString(CultureInfo.InvariantCulture),
            commandTimeoutMs.ToString(CultureInfo.InvariantCulture)
        };
        var controllerFileNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var script in scripts)
        {
            ValidateTaskIndex(script.TaskIndex);
            ArgumentException.ThrowIfNullOrWhiteSpace(script.LocalScriptPath);
            var resolvedLocalScriptPath = ResolveLocalScriptPath(script.LocalScriptPath, cancellationToken);
            ValidateBufferedRunScriptFile(resolvedLocalScriptPath);
            var controllerFileName = CreateBufferedRunControllerFileName(script, resolvedLocalScriptPath, cancellationToken);
            if (!controllerFileNames.Add(controllerFileName))
            {
                throw new InvalidOperationException($"Automation1 buffered run controller file is duplicated: {controllerFileName}");
            }

            if (upload)
            {
                var uploadResponse = await UploadScript(resolvedLocalScriptPath, controllerFileName, number, cancellationToken);
                EnsureAutomationResponseSucceeded(uploadResponse, $"Buffered script upload failed. ControllerFile={controllerFileName}");
            }
            fields.Add(script.TaskIndex.ToString(CultureInfo.InvariantCulture));
            fields.Add(controllerFileName);
        }

        if (stageSession && IsSimul(number))
        {
            var sessions = new List<CStageSimulatedTask>();
            try
            {
                foreach (var script in scripts)
                    sessions.Add(RegisterStageSimulationTask(number, script.TaskIndex, script.ScriptFileName, buffered: true));
                // DoReady starts RUN; only Process START releases virtual machining.
                using var limit = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
                if (commandTimeoutMs > 0) limit.CancelAfter(commandTimeoutMs);
                try { await Task.WhenAll(sessions.Select(session => session.Completion)).WaitAsync(limit.Token).ConfigureAwait(false); }
                catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested && limit.IsCancellationRequested)
                {
                    throw new TimeoutException($"Automation1 buffered run timeout: {commandTimeoutMs} ms.");
                }
            }
            catch
            {
                foreach (var session in sessions) session.Stop();
                throw;
            }
            return "OK:SCRIPT:BUFFERED_RUN:SIMULATION";
        }
        var response = await ExecuteRaw(string.Join("|", fields), number, cancellationToken).ConfigureAwait(false);
        EnsureAutomationResponseSucceeded(response, "Buffered script run failed.");
        return response;
    }

    private string CreateBufferedRunControllerFileName(ST_BUFFERED_SCRIPT_RUN_ITEM script, string resolvedLocalScriptPath, CancellationToken cancellationToken)
    {
        var fileName = string.IsNullOrWhiteSpace(script.ScriptFileName) ? CreateTaskScopedScriptFileName(script.TaskIndex, resolvedLocalScriptPath) : script.ScriptFileName;
        return CreateControllerFileName(fileName, cancellationToken);
    }

    private static string CreateTaskScopedScriptFileName(int taskIndex, string localScriptPath)
    {
        var fileName = Path.GetFileName(localScriptPath);
        if (string.IsNullOrWhiteSpace(fileName))
        {
            fileName = "PROCESS.ascript";
        }

        return $"T{taskIndex.ToString(CultureInfo.InvariantCulture)}_{fileName}";
    }

    public virtual Task<string> StopTask(int taskIndex = 1, int number = 0, CancellationToken cancellationToken = default)
    {
        ValidateTaskIndex(taskIndex);
        if (IsSimul(number))
        {
            if (_stageSimulationTasks.TryGetValue((number, taskIndex), out var session))
            {
                session.Stop();
                return Task.FromResult(CreateSimulationTaskStatus(taskIndex, session.State, session.File));
            }
            return Task.FromResult(CreateSimulationTaskStatus(taskIndex, "Idle"));
        }

        return ExecuteRaw($"AUTOMATION1:SCRIPT|STOP|{taskIndex}", number, cancellationToken);
    }

    public virtual Task<string> ReadTaskStatus(int taskIndex = 1, int number = 0, CancellationToken cancellationToken = default)
    {
        ValidateTaskIndex(taskIndex);
        if (IsSimul(number))
        {
            return Task.FromResult(_stageSimulationTasks.TryGetValue((number, taskIndex), out var session)
                ? CreateSimulationTaskStatus(taskIndex, session.State, session.File)
                : CreateSimulationTaskStatus(taskIndex, "Idle"));
        }

        return ExecuteRaw($"AUTOMATION1:SCRIPT|STATUS|{taskIndex}", number, cancellationToken, suppressLog: true);
    }

    public virtual Task<string> ReadTaskLineStatus(int taskIndex = 1, int number = 0, CancellationToken cancellationToken = default)
    {
        ValidateTaskIndex(taskIndex);
        if (IsSimul(number))
        {
            return Task.FromResult(string.Join(":", "OK", "TASK_LINE", taskIndex.ToString(CultureInfo.InvariantCulture), "0"));
        }

        return ExecuteRaw($"AUTOMATION1:TASK|LINE_STATUS|{taskIndex}", number, cancellationToken, suppressLog: true);
    }

    public virtual async Task<string> ReleaseEncoderScaleFactor(string galvoAxis, int taskIndex = 1, int number = 0, CancellationToken cancellationToken = default)
    {
        var axis = ResolveAeroScriptAxis(galvoAxis);
        ValidateTaskIndex(taskIndex);

        var response = await ExecuteRaw($"AUTOMATION1:COMMAND|{taskIndex.ToString(CultureInfo.InvariantCulture)}|GalvoEncoderScaleFactorSet({axis}, 0)", number, cancellationToken);
        EnsureAutomationResponseSucceeded(response, $"Automation1 encoder scale release failed. Axis={axis}, Task={taskIndex.ToString(CultureInfo.InvariantCulture)}.");
        return response;
    }

    public virtual async Task<string> SetGalvoLaserOutput(string galvoAxis, bool isOn, int taskIndex = 1, int number = 0, CancellationToken cancellationToken = default)
    {
        var axis = ResolveAeroScriptAxis(galvoAxis);
        ValidateTaskIndex(taskIndex);
        var output = isOn ? "On" : "Off";
        var response = await ExecuteRaw($"AUTOMATION1:COMMAND|{taskIndex.ToString(CultureInfo.InvariantCulture)}|GalvoLaserOutput({axis}, GalvoLaser.{output})", number, cancellationToken);
        EnsureAutomationResponseSucceeded(response, $"Automation1 laser output command failed. Axis={axis}, Output={output}, Task={taskIndex.ToString(CultureInfo.InvariantCulture)}.");
        return response;
    }

    private static void ValidateTaskIndex(int taskIndex)
    {
        if (taskIndex < 1)
        {
            throw new ArgumentOutOfRangeException(nameof(taskIndex), taskIndex, "Automation1 task index must be 1 or greater.");
        }
    }

    private static string CreateSimulationTaskStatus(int taskIndex, string state, string sourceFile = "", string errorMessage = "")
    {
        return string.Join(":", "OK", "TASK", taskIndex.ToString(CultureInfo.InvariantCulture), state, sourceFile, errorMessage);
    }

    private Task<string> ExecuteAxis(string axisName, string command, int number, CancellationToken cancellationToken)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(axisName);
        var automationAxis = ResolveAutomationAxis(axisName);
        if (IsSimul(number) && command is "SERVO_ON" or "SERVO_OFF")
        {
            cancellationToken.ThrowIfCancellationRequested();
            _simulationAxisAbleStates[CreateSimulationAxisKey(number, automationAxis)] = command == "SERVO_ON";
            return Task.FromResult($"OK:AXIS:{automationAxis}:{command}");
        }

        if (IsSimul(number))
        {
            cancellationToken.ThrowIfCancellationRequested();
            var parts = command.Split(':');
            var operation = parts[0];
            if (operation is "MANUAL_ABS" or "MANUAL_REL" or "MOVE_ABS" or "MOVE_REL")
            {
                if (parts.Length < 2 || !double.TryParse(parts[1], NumberStyles.Float, CultureInfo.InvariantCulture, out var value) || !double.IsFinite(value))
                    throw new InvalidOperationException("Simulated axis target is invalid.");
                var key = CreateSimulationAxisKey(number, automationAxis);
                _simulationAxisPositions.AddOrUpdate(key, value, (_, previous) => operation is "MANUAL_REL" or "MOVE_REL" ? previous + value : value);
                return Task.FromResult($"OK:AXIS:{automationAxis}:{operation}");
            }
            if (operation is "HOME" or "HOME_ASYNC")
            {
                _simulationAxisPositions[CreateSimulationAxisKey(number, automationAxis)] = 0;
                return Task.FromResult($"OK:AXIS:{automationAxis}:{operation}");
            }
            if (operation is "STOP" or "ABORT_MOTION" or "JOG_STOP")
                return Task.FromResult($"OK:AXIS:{automationAxis}:{operation}");
        }

        return ExecuteRaw($"AUTOMATION1:AXIS:{automationAxis}:{command}", number, cancellationToken);
    }

    private Task<string> ReadAxis(string axisName, int number, int analogInputNo, CancellationToken cancellationToken)
    {
        ValidateAnalogInputNo(analogInputNo);
        return ExecuteAxis(axisName, $"READ:{analogInputNo.ToString(CultureInfo.InvariantCulture)}", number, cancellationToken);
    }

    private Task<string> ReadAxisByName(string axisName, int number, int analogInputNo, CancellationToken cancellationToken)
    {
        return ReadAxisByName(axisName, number, analogInputNo, true, cancellationToken);
    }

    private Task<string> ReadAxisByName(string axisName, int number, int analogInputNo, bool readExtendedStatus, CancellationToken cancellationToken)
    {
        return ReadAxisByName(axisName, number, analogInputNo, readExtendedStatus, cancellationToken, suppressLog: false);
    }

    private Task<string> ReadAxisByName(string axisName, int number, int analogInputNo, bool readExtendedStatus, CancellationToken cancellationToken, bool suppressLog)
    {
        ValidateAnalogInputNo(analogInputNo);
        ValidateAxisNameOnly(axisName);
        var statusMode = readExtendedStatus ? "FULL" : "BASIC";
        return ExecuteRaw($"AUTOMATION1:AXIS:{axisName.Trim()}:READ:{analogInputNo.ToString(CultureInfo.InvariantCulture)}:{statusMode}", number, cancellationToken, suppressLog);
    }

    private static void ValidateAxisNameOnly(string axisName)
    {
        var normalized = axisName.Trim();
        if (!IsAxisNameOnlyIdentifier(normalized))
        {
            throw new InvalidOperationException($"Automation1 axis must be configured by axis name, not axis number: {axisName}");
        }
    }

    private static void ValidateAnalogInputNo(int analogInputNo)
    {
        if (analogInputNo < 0 || analogInputNo > 3)
        {
            throw new ArgumentOutOfRangeException(nameof(analogInputNo), analogInputNo, "Automation1 analog input number must be between 0 and 3.");
        }
    }

    private static void ValidateBufferedRunScriptFile(string localScriptPath)
    {
        if (!File.Exists(localScriptPath))
        {
            throw new FileNotFoundException("Buffered run script file was not found.", localScriptPath);
        }

        var lineNo = 0;
        foreach (var rawLine in File.ReadLines(localScriptPath))
        {
            lineNo++;
            var line = rawLine.Trim();
            if (string.IsNullOrWhiteSpace(line) || line.StartsWith("//", StringComparison.Ordinal))
            {
                continue;
            }

            var token = GetAeroScriptToken(line);
            if (IsBufferedRunBlockedToken(token) || (token.StartsWith('$') && !IsBufferedGlobalIntegerAssignment(line)))
            {
                throw new InvalidDataException($"Buffered run script validation failed. {Path.GetFileName(localScriptPath)} line {lineNo} cannot be queued: {line}");
            }
        }
    }

    private static string GetAeroScriptToken(string line)
    {
        var endIndex = line.IndexOfAny(['(', ' ', '\t']);
        return endIndex <= 0 ? line : line[..endIndex];
    }

    // Global arrays already exist on the controller; no declaration or local variable is queued.
    private static bool IsBufferedGlobalIntegerAssignment(string line)
    {
        const string prefix = "$iglobal[";
        if (!line.StartsWith(prefix, StringComparison.Ordinal)) return false;
        var close = line.IndexOf(']', prefix.Length);
        if (close < 0 || !int.TryParse(line.AsSpan(prefix.Length, close - prefix.Length), NumberStyles.None,
            CultureInfo.InvariantCulture, out var index) || index < 0) return false;
        var assignment = line[(close + 1)..].Trim();
        return assignment.StartsWith('=') && long.TryParse(assignment.AsSpan(1).Trim(), NumberStyles.None,
            CultureInfo.InvariantCulture, out var value) && value >= 0;
    }

    private static bool IsBufferedRunBlockedToken(string token)
    {
        return token.Equals("program", StringComparison.OrdinalIgnoreCase) || token.Equals("end", StringComparison.OrdinalIgnoreCase) || token.Equals("var", StringComparison.OrdinalIgnoreCase) || token.Equals("global", StringComparison.OrdinalIgnoreCase) || token.Equals("if", StringComparison.OrdinalIgnoreCase) || token.Equals("else", StringComparison.OrdinalIgnoreCase) || token.Equals("elseif", StringComparison.OrdinalIgnoreCase) || token.Equals("endif", StringComparison.OrdinalIgnoreCase) || token.Equals("while", StringComparison.OrdinalIgnoreCase) || token.Equals("endwhile", StringComparison.OrdinalIgnoreCase) || token.Equals("for", StringComparison.OrdinalIgnoreCase) || token.Equals("endfor", StringComparison.OrdinalIgnoreCase) || token.Equals("repeat", StringComparison.OrdinalIgnoreCase) || token.Equals("endrepeat", StringComparison.OrdinalIgnoreCase) || token.Equals("function", StringComparison.OrdinalIgnoreCase) || token.Equals("endfunction", StringComparison.OrdinalIgnoreCase) || token.Equals("return", StringComparison.OrdinalIgnoreCase) || token.Equals("break", StringComparison.OrdinalIgnoreCase) || token.Equals("continue", StringComparison.OrdinalIgnoreCase);
    }

    private static void EnsureAutomationResponseSucceeded(string response, string message)
    {
        if (IsAutomationSuccessResponse(response))
        {
            return;
        }

        throw new InvalidOperationException($"{message} Response={FormatAutomationResponse(response)}");
    }

    private static bool IsAutomationSuccessResponse(string response)
    {
        if (string.IsNullOrWhiteSpace(response))
        {
            return false;
        }

        var trimmed = response.Trim();
        if (trimmed.StartsWith("OK", StringComparison.OrdinalIgnoreCase) || trimmed.StartsWith("ACK", StringComparison.OrdinalIgnoreCase))
        {
            return true;
        }

        return trimmed.StartsWith("SIM:", StringComparison.OrdinalIgnoreCase) && trimmed.EndsWith(":OK", StringComparison.OrdinalIgnoreCase);
    }

    private static string FormatAutomationResponse(string response)
    {
        if (string.IsNullOrWhiteSpace(response))
        {
            return "<empty>";
        }

        var automationError = FormatAutomationErrorResponse(response);
        return string.IsNullOrWhiteSpace(automationError) ? response.Trim() : automationError;
    }

    private static string FormatAutomationErrorResponse(string response)
    {
        if (string.IsNullOrWhiteSpace(response))
        {
            return "";
        }

        var fields = response.Trim().Split(':', 4, StringSplitOptions.TrimEntries);
        if (fields.Length >= 4 && fields[0].Equals("ERROR", StringComparison.OrdinalIgnoreCase) && fields[1].Equals("AUTOMATION1", StringComparison.OrdinalIgnoreCase))
        {
            return $"{fields[2]}: {fields[3]}";
        }

        return "";
    }

    private static string ResolveAutomationAxis(string axisName)
    {
        var normalized = axisName.Trim();
        return AxisNoMap.TryGetValue(normalized, out var axisNo) ? axisNo.ToString(CultureInfo.InvariantCulture) : normalized;
    }

    private static string ResolveAeroScriptAxis(string axisName)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(axisName);
        var normalized = axisName.Trim();
        if (!IsAeroScriptAxisIdentifier(normalized))
        {
            throw new InvalidOperationException($"Automation1 axis name must be a numeric axis number or start with a letter and use letters, numbers, and underscores only: {axisName}");
        }

        return AxisNoMap.TryGetValue(normalized, out var axisNo) ? axisNo.ToString(CultureInfo.InvariantCulture) : normalized;
    }

    private static bool IsAeroScriptAxisIdentifier(string value)
    {
        if (value.Length == 0)
        {
            return false;
        }

        if (value.All(char.IsAsciiDigit))
        {
            return true;
        }

        bool MatchesItem(char character)
        {
            return char.IsAsciiLetter(character) || char.IsAsciiDigit(character) || character == '_';
        }

        return char.IsAsciiLetter(value[0]) && value.All(MatchesItem);
    }

    private static bool IsAxisNameOnlyIdentifier(string value)
    {
        if (value.Length == 0 || char.IsAsciiDigit(value[0]))
        {
            return false;
        }

        if (!char.IsAsciiLetter(value[0]))
        {
            return false;
        }

        foreach (var character in value)
        {
            if (!char.IsAsciiLetter(character) && !char.IsAsciiDigit(character) && character != '_')
            {
                return false;
            }
        }

        return true;
    }

    private ST_AUTOMATION_AXIS_STATUS CreateSimulationAxisStatus(int automationNo, string axisName)
    {
        var able = _simulationAxisAbleStates.GetOrAdd(CreateSimulationAxisKey(automationNo, ResolveAutomationAxis(axisName)), true);
        var position = _simulationAxisPositions.GetValueOrDefault(CreateSimulationAxisKey(automationNo, ResolveAutomationAxis(axisName)));
        return new ST_AUTOMATION_AXIS_STATUS(automationNo, axisName, TryGetAxisNo(axisName), position, position, 0.0, 0.0, 0.0, 20.0, able, true, false, able ? "Enabled" : "Disabled", "Homed", "0", $"SIM:AUTOMATION1:AXIS:{axisName}:READ:OK", DateTimeOffset.Now)
        { IsInPosition = true, IsMotionDone = true };
    }

    private static string CreateSimulationAxisKey(int automationNo, string axisName)
    {
        return $"{automationNo.ToString(CultureInfo.InvariantCulture)}:{axisName.Trim()}";
    }

    private static ST_AUTOMATION_AXIS_STATUS ParseAxisStatus(int automationNo, string requestedAxis, string response)
    {
        if (string.IsNullOrWhiteSpace(response))
        {
            return CreateErrorAxisStatus(automationNo, requestedAxis, "No Response", response);
        }

        var automationError = FormatAutomationErrorResponse(response);
        if (!string.IsNullOrWhiteSpace(automationError))
        {
            return CreateErrorAxisStatus(automationNo, requestedAxis, automationError, response);
        }

        var tokens = response.Split(':', StringSplitOptions.TrimEntries | StringSplitOptions.None);
        if (tokens.Length < 3 || !tokens[0].Equals("OK", StringComparison.OrdinalIgnoreCase) || !tokens[1].Equals("AXIS", StringComparison.OrdinalIgnoreCase))
        {
            return CreateErrorAxisStatus(automationNo, requestedAxis, "Invalid Response", response);
        }

        var axisName = string.IsNullOrWhiteSpace(tokens[2]) ? requestedAxis : tokens[2];
        var values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        for (var index = 3; index + 1 < tokens.Length; index += 2)
        {
            values[tokens[index]] = tokens[index + 1];
        }

        var driveStatus = GetValue(values, "DRIVE");
        var fault = GetValue(values, "FAULT");
        var homeState = GetValue(values, "HOME");
        var hasMotionPositions = values.TryGetValue("FPOS", out var feedbackText) &&
            double.TryParse(feedbackText, NumberStyles.Float, CultureInfo.InvariantCulture, out var feedback) && double.IsFinite(feedback) &&
            values.TryGetValue("CPOS", out var commandText) &&
            double.TryParse(commandText, NumberStyles.Float, CultureInfo.InvariantCulture, out var command) && double.IsFinite(command);
        return new ST_AUTOMATION_AXIS_STATUS(automationNo, axisName, TryGetAxisNo(axisName), ReadDouble(values, "FPOS"), ReadDouble(values, "CPOS"), ReadDouble(values, "AUX"), ReadDouble(values, "CURRENT"), ReadDouble(values, "LASER_RAW"), ReadGalvoTemperatureCelsius(values), IsDriveAble(driveStatus), IsHomeDone(homeState), IsFaultActive(fault), driveStatus, homeState, fault, response, DateTimeOffset.Now)
        {
            IsInPosition = hasMotionPositions ? ReadMotionStatusFlag(values, "IN_POSITION") : null,
            IsMotionDone = hasMotionPositions ? ReadMotionStatusFlag(values, "MOTION_DONE") : null
        };
    }

    private static bool? ReadMotionStatusFlag(IReadOnlyDictionary<string, string> values, string key)
    {
        if (!values.TryGetValue(key, out var text)) return null;
        return text.Trim() switch { "1" => true, "0" => false, _ => null };
    }

    private static double ReadGalvoTemperatureCelsius(IReadOnlyDictionary<string, string> values)
    {
        return values.TryGetValue("MOTOR_TEMP", out var text)
            && double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out var value)
            ? CGalvoTemperature.FromAnalogInput(value)
            : double.NaN;
    }

    private static ST_AUTOMATION_AXIS_STATUS CreateErrorAxisStatus(int automationNo, string axisName, string fault, string response)
    {
        return new ST_AUTOMATION_AXIS_STATUS(automationNo, axisName, TryGetAxisNo(axisName), 0.0, 0.0, 0.0, 0.0, 0.0, double.NaN, false, false, true, "", "", fault, response, DateTimeOffset.Now);
    }

    private static int? TryGetAxisNo(string axisName)
    {
        var normalized = axisName.Trim();
        if (int.TryParse(normalized, NumberStyles.Integer, CultureInfo.InvariantCulture, out var axisNo))
        {
            return axisNo;
        }

        return AxisNoMap.TryGetValue(normalized, out axisNo) ? axisNo : null;
    }

    private static string GetValue(IReadOnlyDictionary<string, string> values, string key)
    {
        return values.TryGetValue(key, out var value) ? value : "";
    }

    private static double ReadDouble(IReadOnlyDictionary<string, string> values, string key)
    {
        return values.TryGetValue(key, out var value) && double.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out var parsed) ? parsed : 0.0;
    }

    private static bool IsDriveAble(string driveStatus)
    {
        if (TryReadStatusWord(driveStatus, out var statusWord))
        {
            return (statusWord & Automation1DriveStatusEnabledMask) == Automation1DriveStatusEnabledMask;
        }

        return driveStatus.Contains("Enabled", StringComparison.OrdinalIgnoreCase) || driveStatus.Contains("ServoControl", StringComparison.OrdinalIgnoreCase);
    }

    private static bool IsHomeDone(string homeState)
    {
        var normalized = homeState.Trim();
        if (TryReadStatusWord(normalized, out var statusWord))
        {
            return (statusWord & Automation1AxisStatusHomedMask) == Automation1AxisStatusHomedMask;
        }

        return normalized.Equals("1", StringComparison.OrdinalIgnoreCase) || normalized.Equals("TRUE", StringComparison.OrdinalIgnoreCase) || normalized.Contains("Homed", StringComparison.OrdinalIgnoreCase) || normalized.Contains("Done", StringComparison.OrdinalIgnoreCase) || normalized.Contains("Complete", StringComparison.OrdinalIgnoreCase);
    }

    private static bool TryReadStatusWord(string value, out long statusWord)
    {
        var normalized = value.Trim();
        if (long.TryParse(normalized, NumberStyles.Integer, CultureInfo.InvariantCulture, out statusWord))
        {
            return true;
        }

        if (normalized.StartsWith("0x", StringComparison.OrdinalIgnoreCase) && long.TryParse(normalized[2..], NumberStyles.HexNumber, CultureInfo.InvariantCulture, out statusWord))
        {
            return true;
        }

        if (double.TryParse(normalized, NumberStyles.Float, CultureInfo.InvariantCulture, out var doubleValue) && double.IsFinite(doubleValue))
        {
            statusWord = Convert.ToInt64(doubleValue);
            return Math.Abs(doubleValue - statusWord) <= 0.000001;
        }

        statusWord = 0;
        return false;
    }

    private static bool IsFaultActive(string fault)
    {
        var normalized = fault.Trim();
        return !string.IsNullOrWhiteSpace(normalized) && !normalized.Equals("0", StringComparison.OrdinalIgnoreCase) && !normalized.Equals("None", StringComparison.OrdinalIgnoreCase);
    }

    private string ResolveLocalScriptPath(string fileNameOrPath, CancellationToken cancellationToken)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(fileNameOrPath);
        var trimmed = fileNameOrPath.Trim();
        if (Path.IsPathRooted(trimmed))
        {
            return Path.GetFullPath(trimmed);
        }

        var fileNameOnly = Path.GetFileName(trimmed);
        if (trimmed.Equals(fileNameOnly, StringComparison.OrdinalIgnoreCase))
        {
            var scriptDirectory = GetLocalScriptDirectory(cancellationToken);
            return Path.GetFullPath(Path.Combine(scriptDirectory, trimmed));
        }

        return Path.GetFullPath(Path.Combine(_projectRoot, trimmed));
    }

    private string GetLocalScriptDirectory(CancellationToken cancellationToken)
    {
        var settingValue = _settingManager is null ? "" : _settingManager.GetValue(EN_SETTING_TAB.Option, LocalScriptPathKey, "", cancellationToken);
        return ResolveLocalDirectory(settingValue, _defaultLocalScriptDirectory);
    }

    private string ResolveLocalDirectory(string settingValue, string defaultDirectory)
    {
        var value = string.IsNullOrWhiteSpace(settingValue) ? defaultDirectory : settingValue.Trim();
        return Path.IsPathRooted(value) ? Path.GetFullPath(value) : Path.GetFullPath(Path.Combine(_projectRoot, value));
    }

    private string CreateControllerFileName(string fileNameOrPath, CancellationToken cancellationToken)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(fileNameOrPath);
        var trimmed = fileNameOrPath.Trim().Replace('\\', '/');
        if (trimmed.StartsWith('/'))
        {
            return trimmed;
        }

        var controllerDirectory = GetControllerScriptDirectory(cancellationToken);
        var fileName = Path.GetFileName(trimmed);
        return CombineControllerPath(controllerDirectory, fileName);
    }

    private string GetControllerScriptDirectory(CancellationToken cancellationToken)
    {
        var settingValue = _settingManager is null ? "" : _settingManager.GetValue(EN_SETTING_TAB.Option, AutomationScriptPathKey, "/", cancellationToken);
        if (string.IsNullOrWhiteSpace(settingValue))
        {
            return "/";
        }

        var normalized = settingValue.Trim().Replace('\\', '/');
        return normalized.StartsWith('/') ? normalized : "/" + normalized;
    }

    private static string CombineControllerPath(string directory, string fileName)
    {
        var normalizedDirectory = string.IsNullOrWhiteSpace(directory) ? "/" : directory.Trim().Replace('\\', '/');
        if (!normalizedDirectory.StartsWith('/'))
        {
            normalizedDirectory = "/" + normalizedDirectory;
        }

        normalizedDirectory = normalizedDirectory.TrimEnd('/');
        return normalizedDirectory.Length == 0 ? "/" + fileName : $"{normalizedDirectory}/{fileName}";
    }

    private static string Format(double value)
    {
        return value.ToString("0.######", CultureInfo.InvariantCulture);
    }
}
