namespace Drilling.Common.Automation;

public sealed partial class CAutomationStatusSnapshotService
{
    // Encoder axes need only AuxiliaryFeedback; do not query galvo-only status on them.
    public ST_AUTOMATION_STATUS_SNAPSHOT<ST_AUXILIARY_FEEDBACK> GetAuxiliaryFeedback(string axis, int controller)
        => Get<ST_AUXILIARY_FEEDBACK>(AuxiliaryKey(axis, controller), controller,
            token => _automation.ReadAuxiliaryFeedback(axis, controller, token).GetAwaiter().GetResult());

    internal void InvalidateAuxiliaryFeedback(string axis, int controller)
    {
        GetAuxiliaryFeedback(axis, controller);
        InvalidateEntry(AuxiliaryKey(axis, controller));
    }

    public void InvalidateTask(int task, int controller)
    {
        GetTask(task, controller);
        InvalidateEntry($"TASK|{controller}|{task}");
    }

    private void InvalidateEntry(string key)
    {
        lock (_sync)
        {
            if (!_entries.TryGetValue(key, out var entry)) return;
            entry.Generation++;
            entry.Version++;
            entry.Value = null;
            entry.State = "LOADING";
            entry.UpdatedAt = default;
            entry.CollectedAt = 0;
            entry.CollectedTimestamp = 0;
        }
    }

    private static string AuxiliaryKey(string axis, int controller) => $"AUX|{controller}|{axis.Trim().ToUpperInvariant()}";
}
