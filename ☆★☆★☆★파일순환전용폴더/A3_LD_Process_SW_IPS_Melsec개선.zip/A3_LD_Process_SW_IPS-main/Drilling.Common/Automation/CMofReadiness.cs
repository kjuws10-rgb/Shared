namespace Drilling.Common.Automation;

public sealed record ST_MOF_READINESS(long RunId);

/// <summary>Controller-local global integers [TaskNo - 1] are reserved for MOF readiness.</summary>
public static class CMofReadiness
{
    // Exact even in diagnostics that represent integer status values as doubles (< 2^53).
    private static long _lastRunId = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() * 1000;
    public static long CreateRunId() => Interlocked.Increment(ref _lastRunId);
    public static int VariableIndex(int task)
    {
        if (task < 1) throw new ArgumentOutOfRangeException(nameof(task));
        return task - 1;
    }
}
