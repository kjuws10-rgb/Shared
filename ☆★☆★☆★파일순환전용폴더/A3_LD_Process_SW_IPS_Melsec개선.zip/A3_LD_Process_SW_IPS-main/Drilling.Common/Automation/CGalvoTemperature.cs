using System.Globalization;

namespace Drilling.Common.Automation;

public static class CGalvoTemperature
{
    public static double FromAnalogInput(double value)
    {
        // Apply the equipment's calibration directly to the value read from the analog input.
        return double.IsFinite(value) ? (2637.0 - value) / 13.6 : double.NaN;
    }

    public static string FormatCelsius(double value)
    {
        return double.IsFinite(value) ? $"{value.ToString("F3", CultureInfo.InvariantCulture)} °C" : "-";
    }
}
