using System.Diagnostics;

namespace Drilling.Common.Automation;

public sealed record ST_AUTOMATION_ABSOLUTE_MOVE_TARGET(string Label, int AutomationNo, string AxisReference,
    int AioNo, bool ReadExtendedStatus, double Position, double Speed);

/// <summary>Absolute moves with completion verified exclusively through the shared acquisition cache.</summary>
public sealed class CAutomationPositioningService(CAutomationManager automation)
{
    public async Task MoveAndWait(IReadOnlyList<ST_AUTOMATION_ABSOLUTE_MOVE_TARGET> targets,
        CancellationToken cancellationToken = default)
    {
        var routes = new HashSet<(int, string)>();
        foreach (var target in targets)
        {
            if (!double.IsFinite(target.Position) || !double.IsFinite(target.Speed) || target.Speed <= 0 ||
                string.IsNullOrWhiteSpace(target.AxisReference) || !char.IsAsciiLetter(target.AxisReference[0]) ||
                target.AxisReference.Any(c => !char.IsAsciiLetterOrDigit(c) && c != '_') ||
                !routes.Add((target.AutomationNo, target.AxisReference.ToUpperInvariant())))
                throw new InvalidOperationException($"{target.Label}: invalid or duplicate absolute move target.");
            EnsureConnected(target);
            Read(target); // Register every axis with the shared worker before sending commands.
        }
        if (targets.Count == 0) return;
        var attempted = new List<ST_AUTOMATION_ABSOLUTE_MOVE_TARGET>();
        var fences = new Dictionary<ST_AUTOMATION_ABSOLUTE_MOVE_TARGET, long>();
        try
        {
            await WaitUntil(targets, target => ReadReady(target) is not null, cancellationToken);
            foreach (var target in targets)
            {
                cancellationToken.ThrowIfCancellationRequested();
                EnsureConnected(target);
                attempted.Add(target);
                using var commandTimeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
                commandTimeout.CancelAfter(TimeSpan.FromSeconds(5));
                EnsureResponse(await automation.ManualMove(target.AxisReference, target.Position, target.Speed,
                    false, target.AutomationNo, commandTimeout.Token).WaitAsync(commandTimeout.Token), target.Label);
                automation.StatusSnapshots.InvalidateAxis(target.AxisReference, target.AutomationNo, target.AioNo, target.ReadExtendedStatus);
                fences[target] = Stopwatch.GetTimestamp();
            }
            await WaitUntil(targets, target =>
            {
                var snapshot = Read(target);
                if (snapshot.CollectedTimestamp <= fences[target]) return false;
                var status = ReadReady(target, snapshot);
                return status is { IsInPosition: true, IsMotionDone: true } &&
                    double.IsFinite(status.PositionFeedback) && double.IsFinite(status.PositionCommand) &&
                    Math.Abs(status.PositionFeedback - target.Position) <= 0.001 &&
                    Math.Abs(status.PositionCommand - target.Position) <= 0.001;
            }, cancellationToken);
        }
        catch (Exception failure)
        {
            var stopErrors = new List<string>();
            foreach (var target in attempted)
            {
                try
                {
                    using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(5));
                    EnsureResponse(await automation.AbortMotion(target.AxisReference, target.AutomationNo, timeout.Token)
                        .WaitAsync(timeout.Token), $"{target.Label} STOP");
                }
                catch (Exception stopFailure) { stopErrors.Add($"{target.Label}: {stopFailure.Message}"); }
            }
            if (stopErrors.Count > 0)
                throw new InvalidOperationException($"{failure.Message}\n축 정지 확인 실패:\n{string.Join("\n", stopErrors)}", failure);
            if (failure is OperationCanceledException && !cancellationToken.IsCancellationRequested)
                throw new TimeoutException("DOE Z 이동 명령 응답 시간이 초과되었습니다.", failure);
            throw;
        }
    }

    private void EnsureConnected(ST_AUTOMATION_ABSOLUTE_MOVE_TARGET target)
    {
        if (!automation.IsSimul(target.AutomationNo) && !automation.IsConnect(target.AutomationNo))
            throw new InvalidOperationException($"{target.Label}: controller is offline.");
    }
    private ST_AUTOMATION_STATUS_SNAPSHOT<ST_AUTOMATION_AXIS_STATUS> Read(ST_AUTOMATION_ABSOLUTE_MOVE_TARGET target)
        => automation.StatusSnapshots.GetAxis(target.AxisReference, target.AutomationNo, target.AioNo, target.ReadExtendedStatus);

    private ST_AUTOMATION_AXIS_STATUS? ReadReady(ST_AUTOMATION_ABSOLUTE_MOVE_TARGET target,
        ST_AUTOMATION_STATUS_SNAPSHOT<ST_AUTOMATION_AXIS_STATUS>? snapshot = null)
    {
        EnsureConnected(target);
        snapshot ??= Read(target);
        if (snapshot.State is "ERROR" or "OFFLINE" or "STOPPED")
            throw new InvalidOperationException($"{target.Label}: {snapshot.State} {snapshot.Detail}");
        if (snapshot.State != "OK" || snapshot.Value is not { } status) return null;
        if (status.HasError || !status.Able || !status.HomeDone)
            throw new InvalidOperationException($"{target.Label}: Enable/Home/Fault 상태를 확인해 주세요. Fault={status.Fault}");
        return status;
    }

    private static async Task WaitUntil(IReadOnlyList<ST_AUTOMATION_ABSOLUTE_MOVE_TARGET> targets,
        Func<ST_AUTOMATION_ABSOLUTE_MOVE_TARGET, bool> ready, CancellationToken cancellationToken)
    {
        var elapsed = Stopwatch.StartNew();
        while (true)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var pending = targets.Where(target => !ready(target)).ToArray();
            if (pending.Length == 0) return;
            if (elapsed.Elapsed >= TimeSpan.FromSeconds(60))
                throw new TimeoutException($"DOE Z 이동 완료 확인 시간 초과: {string.Join(", ", pending.Select(t => t.Label))}");
            await Task.Delay(200, cancellationToken);
        }
    }

    private static void EnsureResponse(string response, string label)
    {
        if (!response.StartsWith("OK:", StringComparison.OrdinalIgnoreCase) && !response.StartsWith("SIM:", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException($"{label}: {response}");
    }
}
