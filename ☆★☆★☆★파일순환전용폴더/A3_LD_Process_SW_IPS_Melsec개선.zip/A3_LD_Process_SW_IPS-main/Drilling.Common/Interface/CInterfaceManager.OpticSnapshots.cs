namespace Drilling.Common.Interface;

public partial class CInterfaceManager
{
    private COpticStatusSnapshotService CreateOpticSnapshots() => new(
        () => GetInterfaceList().Where(data => data.Device is EN_EQP_MODULE.TalonLaser or EN_EQP_MODULE.Bet)
            .Select(data => (data.Device, data.Number)).ToArray(),
        (module, number) => IsSimul(module, number) || IsConnect(module, number),
        ReadOpticLaserStatus, ReadOpticBetStatus);

    private async Task<ST_LASER_STATUS> ReadOpticLaserStatus(int number, CancellationToken token)
    {
        token.ThrowIfCancellationRequested();
        if (!IsSimul(EN_EQP_MODULE.TalonLaser, number) && !IsConnect(EN_EQP_MODULE.TalonLaser, number))
            throw new IOException("LASER가 연결되어 있지 않습니다.");
        var value = await RefreshTalonLaserStatusAsync(number, token, suppressCommandLog: true).ConfigureAwait(false);
        if (value.LastError != EN_TALON_ERROR.Ok) throw new IOException($"LASER 상태 수집 실패: {value.LastError}");
        return new(value.LaserOn, value.ShutterOpen, value.GateOpen, value.OutputPower);
    }

    private async Task<ST_BET_STATUS> ReadOpticBetStatus(int number, CancellationToken token)
    {
        token.ThrowIfCancellationRequested();
        if (!IsSimul(EN_EQP_MODULE.Bet, number) && !IsConnect(EN_EQP_MODULE.Bet, number))
            throw new IOException("BET가 연결되어 있지 않습니다.");
        var value = await RefreshBETStatusAsync(number, token, suppressCommandLog: true).ConfigureAwait(false);
        if (!value.CommOk || value.LastError != EN_BET_ERROR.Ok) throw new IOException($"BET 상태 수집 실패: {value.LastError}");
        return value;
    }

    public ST_LASER_STATUS GetCachedLaserStatus(int number)
    {
        var value = GetTalonStatus(number);
        return new(value.LaserOn, value.ShutterOpen, value.GateOpen, value.OutputPower);
    }
    public ST_BET_STATUS GetCachedBetStatus(int number) => GetBETStatusValue(number);
}
