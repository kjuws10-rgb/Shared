using System.Collections.Concurrent;
using System.Globalization;
using Drilling.Common.Managers;

namespace Drilling.Common.Interface;

public partial class CInterfaceManager
{
    public const string AttenuatorSoftwareLimitMessagePrefix = "ATT SW LIMIT: ";
    private readonly ConcurrentDictionary<int, SemaphoreSlim> _attenuatorMoveLocks = new();
    private Func<IReadOnlyList<ST_SYSTEM_PARAMETER>>? _attenuatorLimitSettings;

    public void ConfigureAttenuatorSoftwareLimits(Func<IReadOnlyList<ST_SYSTEM_PARAMETER>> settingsProvider)
    {
        _attenuatorLimitSettings = settingsProvider ?? throw new ArgumentNullException(nameof(settingsProvider));
    }

    private async Task<ST_DEVICE_COMMAND_RESULT> ExecuteAttenuatorMoveWithinLimits(
        int number, EN_ATTENUATOR_COMMAND command, double parameter, CancellationToken cancellationToken, bool suppressCommandLog)
    {
        var gate = _attenuatorMoveLocks.GetOrAdd(number, _ => new SemaphoreSlim(1, 1));
        await gate.WaitAsync(cancellationToken);
        try
        {
            var settings = _attenuatorLimitSettings?.Invoke();
            double ReadLimit(string key)
            {
                var text = settings?.FirstOrDefault(item => item.Key.Equals(key, StringComparison.OrdinalIgnoreCase))?.Value;
                return double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out var value) ? value : double.NaN;
            }

            var minimum = ReadLimit("ATTENUATOR_DEGREE_MIN_SW_LIMIT");
            var maximum = ReadLimit("ATTENUATOR_DEGREE_MAX_SW_LIMIT");
            if (!double.IsFinite(minimum) || !double.IsFinite(maximum) || minimum > maximum)
            {
                return Block("Attenuator Degree Min/Max SW Limit 설정을 확인하세요. 유효한 숫자와 Min ≤ Max가 필요합니다.");
            }
            if (!double.IsFinite(parameter))
            {
                return Block("이동 각도는 유효한 숫자여야 합니다.");
            }

            var origin = 0.0;
            if (command == EN_ATTENUATOR_COMMAND.MoveRel)
            {
                var device = GetAttenuatorInterfaceData(number);
                if (device is null) return Block("Attenuator 연결 설정을 확인할 수 없어 REL 이동을 차단했습니다.");
                if (IsInterfaceSimulation(device))
                {
                    origin = GetAttenuatorStatusValue(number).CurrentPosition;
                }
                else
                {
                    // CONEX PR increments the controller target (TH), which may differ from TP while moving.
                    var read = await ExecuteAttenuatorCommandCore(number, EN_ATTENUATOR_COMMAND.PollTargetPosition, 0, cancellationToken, true);
                    origin = read.IsSuccess
                        ? CConex_AGP.Apply(EN_ATTENUATOR_COMMAND.PollTargetPosition, 0, read.Message,
                            GetAttenuatorStatusValue(number) with { TargetPosition = double.NaN }, false).TargetPosition
                        : double.NaN;
                    if (!double.IsFinite(origin)) return Block("장치의 목표 각도를 읽을 수 없어 REL 이동을 차단했습니다.");
                }
            }

            // Validate both requested and transmitted (three-decimal) targets.
            var transmittedParameter = double.Parse(parameter.ToString("F3", CultureInfo.InvariantCulture), CultureInfo.InvariantCulture);
            foreach (var offset in new[] { parameter, transmittedParameter })
            {
                // Decimal addition keeps exact degree boundaries such as 0.1 + 0.2 == 0.3.
                var target = (double)((decimal)origin + (decimal)offset);
                if (!double.IsFinite(target) || target < minimum || target > maximum)
                {
                    return Block($"목표 각도 {target.ToString("G17", CultureInfo.InvariantCulture)} deg가 허용 범위 " +
                        $"[{minimum.ToString(CultureInfo.InvariantCulture)}, {maximum.ToString(CultureInfo.InvariantCulture)}] deg를 벗어나 이동을 차단했습니다.");
                }
            }

            return await ExecuteAttenuatorCommandCore(number, command, transmittedParameter, cancellationToken, suppressCommandLog);
        }
        catch (Exception exception) when (exception is not OperationCanceledException)
        {
            return Block($"Attenuator 이동 처리에 실패했습니다. {exception.Message}");
        }
        finally
        {
            gate.Release();
        }

        ST_DEVICE_COMMAND_RESULT Block(string message) => new(false, $"{AttenuatorSoftwareLimitMessagePrefix}H{number + 1:00} {message}");
    }
}
