using System.Globalization;
using Aerotech.Automation1.DotNet;

namespace Drilling.Common.Interface;

internal sealed partial class CAutomation1Comm
{
    private static bool IsMofReadinessReadRequest(string function)
    {
        if (!TryGetAutomationBody(function, out var body)) return false;
        var fields = SplitPipe(body);
        return fields.Length == 3 && fields[0].Equals("VARIABLE", StringComparison.OrdinalIgnoreCase) &&
            fields[1].Equals("GET_GLOBAL_INTEGER", StringComparison.OrdinalIgnoreCase);
    }

    private static string ExecuteVariableFunction(Controller controller, string[] fields)
    {
        if (fields.Length < 3 || !int.TryParse(fields[2], NumberStyles.Integer, CultureInfo.InvariantCulture, out var index) || index < 0)
            throw new InvalidOperationException("A non-negative controller global integer index is required.");
        if (fields.Length == 3 && fields[1] == "GET_GLOBAL_INTEGER")
        {
            var value = controller.Runtime.Variables.Global.GetInteger(index);
            return FormattableString.Invariant($"OK:GLOBAL_INTEGER:{index}:{value}");
        }
        if (fields.Length != 4 || fields[1] != "SET_GLOBAL_INTEGER" ||
            !long.TryParse(fields[3], NumberStyles.Integer, CultureInfo.InvariantCulture, out var written))
            throw new InvalidOperationException("Invalid controller global integer command.");
        controller.Runtime.Variables.Global.SetInteger(index, written);
        return "OK:GLOBAL_INTEGER_WRITE";
    }
}
