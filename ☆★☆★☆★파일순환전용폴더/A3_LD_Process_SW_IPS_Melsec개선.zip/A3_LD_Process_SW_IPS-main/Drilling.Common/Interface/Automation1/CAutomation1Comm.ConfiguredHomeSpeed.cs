using System.Globalization;
using System.Text.Json;
using Aerotech.Automation1.DotNet;

namespace Drilling.Common.Interface;

internal sealed partial class CAutomation1Comm
{
    // ExecuteAutomation1Function invokes this while holding _commLock. Configuration is not thread safe;
    // keep each fresh read / one-parameter update / save / readback in that same critical section.
    private static string ExecuteConfiguredHomeSpeedFunction(Controller controller, IReadOnlyList<string> tokens)
    {
        if (tokens.Count < 3)
            throw new InvalidOperationException("Automation1 saved HomeSpeed command is invalid.");

        var command = tokens[1].ToUpperInvariant();
        if (command == "HOME_SPEEDS" && tokens.Count == 3)
        {
            var axes = tokens[2].Split(',', StringSplitOptions.None).Select(ValidateConfiguredHomeSpeedAxis)
                .Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
            var configuration = controller.Configuration.Parameters.GetConfiguration();
            var values = axes.ToDictionary(axis => axis,
                axis => ConfiguredHomeSpeedAxis(configuration, axis).Homing.HomeSpeed.Value,
                StringComparer.OrdinalIgnoreCase);
            var units = axes.ToDictionary(axis => axis, axis =>
            {
                var primaryUnits = ConfiguredHomeSpeedAxis(configuration, axis).Units.UnitsName.Value?.Trim();
                return string.IsNullOrEmpty(primaryUnits) ? string.Empty : $"{primaryUnits}/sec";
            }, StringComparer.OrdinalIgnoreCase);
            return "OK:CONFIG_HOME_SPEEDS:" + JsonSerializer.Serialize(new { Values = values, Units = units });
        }

        if (command == "HOME_SPEED" && tokens.Count == 4)
        {
            var axis = ValidateConfiguredHomeSpeedAxis(tokens[2]);
            var speed = ReadDouble(tokens, 3, "HOME_SPEED");
            if (!double.IsFinite(speed) || speed <= 0)
                throw new ArgumentOutOfRangeException(nameof(speed), "Home speed must be finite and greater than zero.");

            // Never retain a full configuration between UI reads and writes: other saved parameters
            // may have changed in the meantime. Read it anew and replace only this axis' HomeSpeed.
            var configuration = controller.Configuration.Parameters.GetConfiguration();
            ConfiguredHomeSpeedAxis(configuration, axis).Homing.HomeSpeed.Value = speed;
            controller.Configuration.Parameters.SetConfiguration(configuration);
            var readback = controller.Configuration.Parameters.GetConfiguration();
            var saved = ConfiguredHomeSpeedAxis(readback, axis).Homing.HomeSpeed.Value;
            if (!double.IsFinite(saved) || saved != speed)
                throw new InvalidOperationException($"Saved HomeSpeed did not match the requested value. Axis={axis}");
            return "OK:CONFIG_HOME_SPEED:" + saved.ToString("R", CultureInfo.InvariantCulture);
        }

        throw new InvalidOperationException($"Automation1 saved HomeSpeed command is unknown: {command}");
    }

    private static AxisParameterCategory ConfiguredHomeSpeedAxis(ConfiguredParameters configuration, string axis)
        => int.TryParse(axis, NumberStyles.None, CultureInfo.InvariantCulture, out var number)
            ? configuration.Axes[number] : configuration.Axes[axis];

    private static string ValidateConfiguredHomeSpeedAxis(string value)
    {
        var axis = value.Trim();
        var isNumber = axis.Length > 0 && axis.All(char.IsAsciiDigit);
        var isName = axis.Length > 0 && char.IsAsciiLetter(axis[0])
            && axis.All(character => char.IsAsciiLetterOrDigit(character) || character == '_');
        if (!isNumber && !isName || isNumber && !int.TryParse(axis, NumberStyles.None, CultureInfo.InvariantCulture, out _))
            throw new InvalidOperationException($"Automation1 configured axis reference is invalid: {value}");
        return axis;
    }
}
