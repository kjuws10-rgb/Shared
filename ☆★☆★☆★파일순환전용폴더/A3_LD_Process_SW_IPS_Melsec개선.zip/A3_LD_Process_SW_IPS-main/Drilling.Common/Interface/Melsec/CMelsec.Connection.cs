using System.Globalization;

namespace Drilling.Common.Interface;

public sealed partial class CMelsec
{
    // Settings reload must not stop the shared worker or close another station's path.
    internal void CloseDevice(int deviceNo, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var ids = GetMapList().Where(row => row.DeviceNo == deviceNo).Select(row => NormalizeId(row.Id)).ToHashSet(StringComparer.OrdinalIgnoreCase);
        const string message = "MELSEC interface settings changed.";
        lock (_requestLock)
        {
            var count = _requestQueue.Count;
            for (var index = 0; index < count; index++)
            {
                var pending = _requestQueue.Dequeue();
                if (ids.Contains(pending.Id) || (pending.Command == EN_MELSEC_THREAD_COMMAND.Open && Equals(pending.Value, deviceNo)))
                {
                    pending.Error = new OperationCanceledException(message);
                    pending.Completed.Set();
                }
                else _requestQueue.Enqueue(pending);
            }
        }
        lock (_writeLock)
        {
            foreach (var pending in _writeQueue.Concat(_activeWriteCommand is null ? [] : new[] { _activeWriteCommand }))
            {
                if (!ids.Contains(pending.WriteId) && !ids.Contains(pending.ReadbackId)) continue;
                pending.CancelRequested = true;
                pending.Result = EN_MELSEC_WRITE_RESULT.Cancelled;
                pending.ErrorMessage = message;
            }
        }
        if (IsRunning)
            ExecuteThreadRequest(new CMelsecThreadRequest(EN_MELSEC_THREAD_COMMAND.Close,
                "MELSEC_" + deviceNo.ToString(CultureInfo.InvariantCulture), deviceNo, cancellationToken));
        else
            CloseDeviceCore(deviceNo);
    }

    private void CloseDeviceCore(int deviceNo)
    {
        var data = _interfaceManager.GetInterfaceData(EN_EQP_MODULE.Melsec, deviceNo);
        bool hasPath;
        lock (_ioLock) hasPath = _melsecNetPaths.ContainsKey(deviceNo);
        if (hasPath && data is not null) CloseMelsecNetChannelCore(deviceNo, data, ReadMelsecNetOption(data));
        lock (_pollLock)
        {
            _pollDeviceBackoff.Remove(deviceNo);
            foreach (var block in _pollBlocks.Where(block => block.DeviceNo == deviceNo))
            {
                block.NextReadAt = DateTimeOffset.MinValue;
                SetBlockState(block, EN_MELSEC_CACHE_STATE.Offline, "MELSEC interface settings changed.");
                lock (_readStateLock)
                    foreach (var item in block.Items) _readSnapshots.Remove(NormalizeId(item.Data.Id));
            }
        }
    }
}
