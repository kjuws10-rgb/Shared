using System.Diagnostics;
using System.Text;

namespace Drilling.Common.Interface;

public enum EN_MELSEC_CACHE_STATE { Pending, Valid, Stale, Error, Offline }

public sealed record ST_MELSEC_CACHED_VALUE(
    string Id, object? Value, EN_MELSEC_CACHE_STATE State,
    DateTimeOffset? UpdatedAt, long ReadCycleNo, string ErrorMessage)
{
    public bool IsValid => State == EN_MELSEC_CACHE_STATE.Valid;
}

// UTC times identify an attempt; durations and update intervals use Stopwatch
// (monotonic time), so a system-clock adjustment does not distort those metrics.
public sealed record ST_MELSEC_POLLING_DIAGNOSTIC(
    int DeviceNo, string Address, int WordCount, int PollMs, IReadOnlyList<string> Ids,
    EN_MELSEC_CACHE_STATE State, long AttemptNo, bool IsReading,
    DateTimeOffset? LastAttemptStartedAt, DateTimeOffset? LastAttemptCompletedAt,
    DateTimeOffset? LastSuccessfulUpdateAt, double? LastAttemptDurationMs, double? LastUpdateIntervalMs);

public sealed partial class CMelsec
{
    private const int DefaultPollingIntervalMs = 1000;
    private const int PollingFailureBackoffMs = 2000;
    private const int MaximumPollingBlocksPerRun = 4;
    private const int PollingBurstBudgetMs = 8;
    private readonly object _pollLock = new();
    private readonly Dictionary<string, ST_MELSEC_CACHED_VALUE> _cachedValues = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, PollBlock> _pollBlockById = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<int, DateTimeOffset> _pollDeviceBackoff = new();
    private List<PollBlock> _pollBlocks = [];
    private int _pollGeneration;
    private int _nextPollBlock;

    // Reading a snapshot never starts communication or enqueues a device read.
    // A complete block (including all bits of each word) is published under one lock.
    public IReadOnlyDictionary<string, ST_MELSEC_CACHED_VALUE> GetCachedSnapshot() => GetCachedSnapshot(out _);

    // Return matching map metadata as well, so a map reload cannot mix a new
    // scale/type with a sample decoded using the previous configuration.
    public IReadOnlyDictionary<string, ST_MELSEC_CACHED_VALUE> GetCachedSnapshot(out IReadOnlyList<ST_MELSEC_MAP_DATA> map)
    {
        var now = DateTimeOffset.UtcNow;
        lock (_pollLock)
        {
            map = Map;
            return _cachedValues.ToDictionary(pair => pair.Key,
                pair => WithCacheFreshness(pair.Key, pair.Value, now), StringComparer.OrdinalIgnoreCase);
        }
    }

    // Like GetCachedSnapshot, this is a local snapshot only: no I/O or request
    // queue work. Ids lets a UI associate a row with its shared native read block.
    public IReadOnlyList<ST_MELSEC_POLLING_DIAGNOSTIC> GetPollingDiagnostics()
    {
        var now = DateTimeOffset.UtcNow;
        lock (_pollLock)
        {
            return Array.AsReadOnly(_pollBlocks.Select(block =>
            {
                var ids = Array.AsReadOnly(block.Items.Select(item => NormalizeId(item.Data.Id)).ToArray());
                var state = _cachedValues.TryGetValue(ids[0], out var sample)
                    ? WithCacheFreshness(ids[0], sample, now).State : EN_MELSEC_CACHE_STATE.Pending;
                var address = block.Address.Device + block.Start.ToString(
                    IsHexDevice(block.Address.Device) ? "X" : "D", System.Globalization.CultureInfo.InvariantCulture);
                return new ST_MELSEC_POLLING_DIAGNOSTIC(block.DeviceNo, address, block.WordCount,
                    block.IntervalMs, ids, state, block.AttemptNo, block.IsReading,
                    block.LastAttemptStartedAt, block.LastAttemptCompletedAt, block.LastSuccessfulUpdateAt,
                    block.LastAttemptDurationMs, block.LastUpdateIntervalMs);
            }).ToArray());
        }
    }

    // Control operations such as REL target calculation can require a new sample.
    // Concurrent requests share the central block read instead of reading individually.
    public async Task<ST_MELSEC_CACHED_VALUE> RefreshCachedValueAsync(
        string id, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var key = NormalizeId(id);
        PollBlock block;
        long previousAttempt;
        int generation;
        lock (_pollLock)
        {
            if (!_pollBlockById.TryGetValue(key, out block!))
            {
                var reason = _cachedValues.TryGetValue(key, out var entry) ? entry.ErrorMessage : "No readable enabled map entry.";
                throw new InvalidOperationException($"MELSEC cache cannot refresh {id}: {reason}");
            }
            generation = _pollGeneration;
            previousAttempt = block.AttemptNo;
            if (!block.IsReading) block.NextReadAt = DateTimeOffset.MinValue;
            _pollDeviceBackoff.Remove(block.DeviceNo);
        }

        var elapsed = Stopwatch.StartNew();
        while (elapsed.ElapsedMilliseconds < DefaultWriteTimeoutMs)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (!_acceptRequests || !IsRunning)
                throw new InvalidOperationException("MELSEC communication is not running.");
            lock (_pollLock)
            {
                if (generation != _pollGeneration)
                    throw new InvalidOperationException("MELSEC map changed while waiting for feedback.");
                if (block.AttemptNo > previousAttempt && _cachedValues.TryGetValue(key, out var sample))
                {
                    sample = WithCacheFreshness(key, sample, DateTimeOffset.UtcNow);
                    if (sample.IsValid) return sample;
                    throw new IOException($"MELSEC feedback is unavailable: {id}. {sample.ErrorMessage}");
                }
            }
            await Task.Delay(10, cancellationToken).ConfigureAwait(false);
        }
        throw new TimeoutException($"MELSEC fresh feedback timed out: {id}.");
    }

    private ST_MELSEC_CACHED_VALUE WithCacheFreshness(string id, ST_MELSEC_CACHED_VALUE sample, DateTimeOffset now)
    {
        var interval = _pollBlockById.TryGetValue(id, out var block) ? block.IntervalMs : DefaultPollingIntervalMs;
        if (sample.IsValid && sample.UpdatedAt is { } updated &&
            now - updated > TimeSpan.FromMilliseconds(Math.Max(1000L, (long)interval * 3)))
            return sample with { Value = null, State = EN_MELSEC_CACHE_STATE.Stale, ErrorMessage = "MELSEC feedback has not been updated within its polling interval." };
        return sample;
    }

    private void RebuildPollingMap(Dictionary<string, ST_MELSEC_MAP_DATA> map)
    {
        var items = new List<PollItem>();
        var entries = new Dictionary<string, ST_MELSEC_CACHED_VALUE>(StringComparer.OrdinalIgnoreCase);
        foreach (var row in map.Values.Where(row => row.Use && row.Access != EN_MELSEC_ACCESS.Write))
        {
            var id = NormalizeId(row.Id);
            try
            {
                ValidateMapData(row);
                var count = row.DataType switch
                {
                    EN_MELSEC_DATA_TYPE.Bit or EN_MELSEC_DATA_TYPE.Word => 1,
                    EN_MELSEC_DATA_TYPE.String => row.Length,
                    _ => Math.Max(2, row.Length)
                };
                if (count < 1 || count > MelsecNetMaximumTransferBytes / sizeof(short))
                    throw new InvalidDataException($"MELSEC polling length is invalid: {row.Id}, {count} words.");
                var address = ParseAddress(row.Address);
                _ = checked(address.Number + count - 1);
                items.Add(new PollItem(row, address, count, row.PollMs > 0 ? row.PollMs : DefaultPollingIntervalMs));
                entries[id] = new(id, null, EN_MELSEC_CACHE_STATE.Pending, null, 0, "Waiting for MELSEC feedback.");
            }
            catch (Exception exception) when (exception is FormatException or InvalidDataException or InvalidOperationException or NotSupportedException or OverflowException)
            {
                entries[id] = new(id, null, EN_MELSEC_CACHE_STATE.Error, null, 0, exception.Message);
            }
        }

        var blocks = new List<PollBlock>();
        foreach (var group in items.GroupBy(item => (item.Data.DeviceNo, item.Address.Device)))
        {
            PollBlock? current = null;
            foreach (var item in group.OrderBy(item => item.Address.Number).ThenBy(item => item.WordCount))
            {
                var end = checked(item.Address.Number + item.WordCount - 1);
                // Word addresses advance by one word. Do not assume that address
                // arithmetic for native bit devices (B/X/Y etc.) has that meaning.
                var wordAddressed = item.Address.Device is "W" or "SW" or "D" or "SD" or "R" or "ZR";
                var overlaps = current != null && item.Address.Number <= current.End;
                var adjacent = current != null && (long)item.Address.Number == (long)current.End + 1 && item.IntervalMs == current.IntervalMs;
                var canMerge = current != null &&
                    (wordAddressed ? overlaps || adjacent : item.Address.Number == current.Start && item.WordCount == current.WordCount) &&
                    (long)Math.Max(end, current.End) - current.Start + 1 <= MelsecNetMaximumTransferBytes / sizeof(short);
                if (!canMerge)
                {
                    current = new PollBlock(item);
                    blocks.Add(current);
                }
                else
                {
                    current!.Items.Add(item);
                    current.End = Math.Max(current.End, end);
                    current.IntervalMs = Math.Min(current.IntervalMs, item.IntervalMs);
                }
            }
        }

        lock (_pollLock)
        {
            lock (_mapLock) _map = map;
            _pollGeneration++;
            _pollBlocks = blocks;
            _nextPollBlock = 0;
            _pollDeviceBackoff.Clear();
            _pollBlockById.Clear();
            _cachedValues.Clear();
            foreach (var pair in entries) _cachedValues[pair.Key] = pair.Value;
            foreach (var block in blocks)
                foreach (var item in block.Items) _pollBlockById[NormalizeId(item.Data.Id)] = block;
            lock (_readStateLock) _readSnapshots.Clear();
        }
    }

    private void RestartPollingSchedule()
    {
        lock (_pollLock)
        {
            _pollDeviceBackoff.Clear();
            foreach (var block in _pollBlocks)
            {
                block.NextReadAt = DateTimeOffset.MinValue;
                SetBlockState(block, EN_MELSEC_CACHE_STATE.Pending, "Waiting for MELSEC feedback.");
            }
        }
    }

    private void RestartPollingDevice(int deviceNo)
    {
        lock (_pollLock)
        {
            _pollDeviceBackoff.Remove(deviceNo);
            foreach (var block in _pollBlocks.Where(block => block.DeviceNo == deviceNo))
            {
                block.NextReadAt = DateTimeOffset.MinValue;
                SetBlockState(block, EN_MELSEC_CACHE_STATE.Pending, "Waiting for MELSEC feedback.");
            }
        }
    }

    private void InvalidatePollingCache(EN_MELSEC_CACHE_STATE state, string message)
    {
        lock (_pollLock)
        {
            foreach (var block in _pollBlocks) SetBlockState(block, state, message);
        }
    }

    private void InvalidateWrittenCache(int deviceNo, ST_MELSEC_ADDRESS address, int count)
    {
        lock (_pollLock)
        {
            foreach (var block in _pollBlocks.Where(block => block.DeviceNo == deviceNo &&
                block.Address.Device == address.Device && (long)block.Start < (long)address.Number + count && block.End >= address.Number))
            {
                block.NextReadAt = DateTimeOffset.MinValue;
                SetBlockState(block, EN_MELSEC_CACHE_STATE.Pending, "Waiting for feedback after write.");
            }
        }
    }

    private void SetBlockState(PollBlock block, EN_MELSEC_CACHE_STATE state, string message)
    {
        foreach (var item in block.Items)
        {
            var id = NormalizeId(item.Data.Id);
            if (_cachedValues.TryGetValue(id, out var previous))
                _cachedValues[id] = previous with { Value = null, State = state, ErrorMessage = message };
        }
    }

    private void PollDueCacheBlocks()
    {
        var elapsed = Stopwatch.StartNew();
        for (var count = 0; count < MaximumPollingBlocksPerRun; count++)
        {
            if (!_acceptRequests || IsStopRequested()) return;
            // Preserve one polling opportunity per Run, but never add a burst
            // ahead of pending control work or a due write/readback phase.
            if (count > 0 && (elapsed.ElapsedMilliseconds >= PollingBurstBudgetMs || ShouldYieldPollingToControl())) return;
            if (!PollNextCacheBlock()) return;
        }
        // The budget is soft: a synchronous native ReceiveEx cannot be aborted
        // here. Check time/Stop/control only between calls on this same worker.
    }

    private bool PollNextCacheBlock()
    {
        if (!_acceptRequests) return false;
        PollBlock? selected = null;
        int generation;
        long attemptStartedTimestamp = 0;
        var now = DateTimeOffset.UtcNow;
        lock (_pollLock)
        {
            generation = _pollGeneration;
            for (var scanned = 0; scanned < _pollBlocks.Count; scanned++)
            {
                var index = _nextPollBlock++ % _pollBlocks.Count;
                if (_nextPollBlock >= _pollBlocks.Count) _nextPollBlock = 0;
                var block = _pollBlocks[index];
                if (block.NextReadAt > now ||
                    (_pollDeviceBackoff.TryGetValue(block.DeviceNo, out var retryAt) && retryAt > now)) continue;
                selected = block;
                selected.IsReading = true;
                selected.LastAttemptStartedAt = DateTimeOffset.UtcNow;
                selected.LastAttemptCompletedAt = null;
                selected.LastAttemptDurationMs = null;
                attemptStartedTimestamp = Stopwatch.GetTimestamp();
                break;
            }
        }
        if (selected == null) return false;

        try
        {
            var first = selected.Items[0].Data;
            var connection = GetInterfaceData(first);
            if (!IsSimulation(connection))
            {
                bool open;
                lock (_ioLock) open = _melsecNetPaths.ContainsKey(selected.DeviceNo);
                if (!open)
                {
                    CompletePollingFailure(selected, generation, EN_MELSEC_CACHE_STATE.Offline, "MELSEC communication line is not open.");
                    return true;
                }
            }
            var words = ReadWords(first, selected.Address, selected.WordCount, CancellationToken.None, suppressLog: true);
            var updatedAt = DateTimeOffset.UtcNow;
            var updatedTimestamp = Stopwatch.GetTimestamp();
            var cycle = ReadCycleNo;
            var values = selected.Items.Select(item => (Item: item, Value: DecodePollingValue(item, words, selected.Start))).ToArray();
            lock (_pollLock)
            {
                if (generation != _pollGeneration || !_acceptRequests) return true;
                foreach (var pair in values)
                {
                    var id = NormalizeId(pair.Item.Data.Id);
                    _cachedValues[id] = new(id, pair.Value, EN_MELSEC_CACHE_STATE.Valid, updatedAt, cycle, "");
                    SaveReadSnapshot(id, pair.Value);
                }
                selected.AttemptNo++;
                selected.LastUpdateIntervalMs = selected.LastSuccessfulTimestamp is { } previousTimestamp
                    ? Stopwatch.GetElapsedTime(previousTimestamp, updatedTimestamp).TotalMilliseconds : null;
                selected.LastSuccessfulTimestamp = updatedTimestamp;
                selected.LastSuccessfulUpdateAt = updatedAt;
                selected.NextReadAt = updatedAt.AddMilliseconds(selected.IntervalMs);
                _pollDeviceBackoff.Remove(selected.DeviceNo);
            }
        }
        catch (Exception exception)
        {
            CompletePollingFailure(selected, generation, EN_MELSEC_CACHE_STATE.Error, exception.Message);
        }
        finally
        {
            lock (_pollLock)
            {
                selected.IsReading = false;
                selected.LastAttemptCompletedAt = DateTimeOffset.UtcNow;
                selected.LastAttemptDurationMs = Stopwatch.GetElapsedTime(attemptStartedTimestamp).TotalMilliseconds;
            }
        }
        return true;
    }

    private void CompletePollingFailure(PollBlock block, int generation, EN_MELSEC_CACHE_STATE state, string message)
    {
        lock (_pollLock)
        {
            if (generation != _pollGeneration || !_acceptRequests) return;
            block.AttemptNo++;
            var retryAt = DateTimeOffset.UtcNow.AddMilliseconds(PollingFailureBackoffMs);
            block.NextReadAt = retryAt;
            _pollDeviceBackoff[block.DeviceNo] = retryAt;
            foreach (var affected in _pollBlocks.Where(candidate => candidate.DeviceNo == block.DeviceNo))
                SetBlockState(affected, state, message);
        }
    }

    private static object DecodePollingValue(PollItem item, ushort[] blockWords, int start)
    {
        var words = blockWords.AsSpan(item.Address.Number - start, item.WordCount).ToArray();
        switch (item.Data.DataType)
        {
            case EN_MELSEC_DATA_TYPE.Bit: return (words[0] & (1 << item.Address.BitIndex!.Value)) != 0;
            case EN_MELSEC_DATA_TYPE.Word: return ScaleInteger(words[0], item.Data.ReadScale);
            case EN_MELSEC_DATA_TYPE.DWord: return ScaleInteger(WordsToInt32(words), item.Data.ReadScale);
            case EN_MELSEC_DATA_TYPE.Double: return WordsToInt32(words) * item.Data.ReadScale;
            case EN_MELSEC_DATA_TYPE.Float: return WordsToFloat(words) * item.Data.ReadScale;
            case EN_MELSEC_DATA_TYPE.String:
                var bytes = new byte[words.Length * 2];
                for (var index = 0; index < words.Length; index++)
                {
                    bytes[index * 2] = (byte)words[index];
                    bytes[index * 2 + 1] = (byte)(words[index] >> 8);
                }
                return Encoding.ASCII.GetString(bytes).TrimEnd('\0', ' ');
            default: throw new InvalidDataException($"Unsupported MELSEC cache type: {item.Data.DataType}.");
        }
    }

    private static object ScaleInteger(int rawValue, double readScale) =>
        readScale == 1 ? (object)rawValue : rawValue * readScale;

    private sealed record PollItem(ST_MELSEC_MAP_DATA Data, ST_MELSEC_ADDRESS Address, int WordCount, int IntervalMs);
    private sealed class PollBlock(PollItem first)
    {
        public List<PollItem> Items { get; } = [first];
        public int DeviceNo => Items[0].Data.DeviceNo;
        public ST_MELSEC_ADDRESS Address => first.Address with { BitIndex = null };
        public int Start => first.Address.Number;
        public int End { get; set; } = first.Address.Number + first.WordCount - 1;
        public int WordCount => End - Start + 1;
        public int IntervalMs { get; set; } = first.IntervalMs;
        public DateTimeOffset NextReadAt { get; set; } = DateTimeOffset.MinValue;
        public long AttemptNo { get; set; }
        public bool IsReading { get; set; }
        public DateTimeOffset? LastAttemptStartedAt { get; set; }
        public DateTimeOffset? LastAttemptCompletedAt { get; set; }
        public DateTimeOffset? LastSuccessfulUpdateAt { get; set; }
        public double? LastAttemptDurationMs { get; set; }
        public double? LastUpdateIntervalMs { get; set; }
        public long? LastSuccessfulTimestamp { get; set; }
    }
}
