namespace Drilling.Common.Interface;

public sealed partial class CMelsec
{
    // Called only by the normal simulation read path. Read-only motor feedback is
    // encoded into the same simulated PLC memory used by the common polling cache.
    private void UpdateStageMotionSimulationWords(int deviceNo, ST_MELSEC_ADDRESS start, int wordCount)
    {
        var feedback = _interfaceManager.GetStageMotionSimulationFeedback(deviceNo);
        var rows = Map.Where(row => row.DeviceNo == deviceNo && row.Access == EN_MELSEC_ACCESS.Read &&
            feedback.ContainsKey(row.Id)).ToArray();
        foreach (var row in rows)
        {
            var address = ParseAddress(row.Address);
            if (address.Device != start.Device || address.Number < start.Number ||
                (long)address.Number + row.Length > (long)start.Number + wordCount) continue;
            var value = feedback[row.Id];
            if (row.DataType is EN_MELSEC_DATA_TYPE.Word or EN_MELSEC_DATA_TYPE.DWord or EN_MELSEC_DATA_TYPE.Double or EN_MELSEC_DATA_TYPE.Float)
                WriteSimulationValue(row, value);
        }
    }
}
