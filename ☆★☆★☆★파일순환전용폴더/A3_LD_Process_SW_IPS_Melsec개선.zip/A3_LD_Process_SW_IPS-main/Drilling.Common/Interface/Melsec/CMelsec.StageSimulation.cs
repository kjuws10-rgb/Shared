namespace Drilling.Common.Interface;

public sealed partial class CMelsec
{
    public static bool IsStageSimulationSignal(ST_MELSEC_MAP_DATA data) =>
        data.Use && data.Id.StartsWith("HANDSHAKE_STG_", StringComparison.OrdinalIgnoreCase) &&
        data.Direction == EN_MELSEC_DIRECTION.In && data.Access != EN_MELSEC_ACCESS.Write &&
        data.DataType == EN_MELSEC_DATA_TYPE.DWord && data.Length == 2 &&
        double.IsFinite(data.ReadScale) && data.ReadScale > 0;

    public static bool IsStageAlignSimulationSignal(ST_MELSEC_MAP_DATA data) =>
        data.Use && (data.Id.Equals("SDC_DO_ALIGN_STATUS", StringComparison.OrdinalIgnoreCase) ||
                     data.Id.Equals("SDC_DO_ALIGN_COMPLETE", StringComparison.OrdinalIgnoreCase)) &&
        data.Direction == EN_MELSEC_DIRECTION.In && data.Access != EN_MELSEC_ACCESS.Write &&
        data.DataType == EN_MELSEC_DATA_TYPE.Word && data.Length == 1;

    /// <summary>Writes a Stage-owned Align raw Word into simulation memory, never to a PLC.</summary>
    public void SetStageAlignSimulationValue(string id, int rawValue)
    {
        if (rawValue is < 0 or > ushort.MaxValue)
            throw new ArgumentOutOfRangeException(nameof(rawValue), "1 WORD 원시값은 0~65535의 정수여야 합니다.");
        lock (_pollLock)
        {
            var data = GetMapData(id);
            if (!IsStageAlignSimulationSignal(data))
                throw new InvalidOperationException($"Stage 수신용 ALIGN 신호가 아닙니다: {id}");
            if (!IsSimulation(GetInterfaceData(data)))
                throw new InvalidOperationException($"MELSEC_{data.DeviceNo}가 SIMULATION 상태일 때만 변경할 수 있습니다.");

            WriteSimulationValue(data, rawValue * data.ReadScale);
            if (_pollBlockById.TryGetValue(NormalizeId(id), out var block))
                block.NextReadAt = DateTimeOffset.MinValue;
        }
    }

    /// <summary>
    /// Emulates the Stage PC's input in memory only. Does not use native writes,
    /// change map access, or publish UI/action flags. The common poller reads it normally.
    /// </summary>
    public void SetStageSimulationSignal(string id, bool on)
    {
        lock (_pollLock)
        {
            var data = GetMapData(id);
            if (!IsStageSimulationSignal(data))
                throw new InvalidOperationException($"Stage 수신용 핸드셰이크 신호가 아닙니다: {id}");
            if (!IsSimulation(GetInterfaceData(data)))
                throw new InvalidOperationException($"MELSEC_{data.DeviceNo}가 SIMULATION 상태일 때만 변경할 수 있습니다.");

            WriteSimulationValue(data, on ? 1 : 0);
            if (_pollBlockById.TryGetValue(NormalizeId(id), out var block))
                block.NextReadAt = DateTimeOffset.MinValue;
        }
    }
}
