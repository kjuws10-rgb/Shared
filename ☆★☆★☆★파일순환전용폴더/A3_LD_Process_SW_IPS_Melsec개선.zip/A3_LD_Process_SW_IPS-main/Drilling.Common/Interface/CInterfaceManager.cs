using Drilling.Common.Log;
using System.IO;
using System.Globalization;
using System.Collections.Concurrent;
using Drilling.Common.Managers;
using Drilling.Common.Alarm;
using Drilling.Common.Interface;
using Drilling.Common.Interface.Vision;
using Drilling.Common.InterLock;
using Drilling.Common.Motion;
using Drilling.Common.Station;

namespace Drilling.Common.Interface;
public enum EN_COMM_STATE
{
    Offline,
    Simulation,
    Online
}

public enum EN_EQP_MODULE
{
    WonikCtrl,
    Vision,
    Automation1,
    Motion,
    TalonLaser,
    Attenuator,
    Bet,
    PowerMeter,
    PicoMotor,
    Melsec
}

public enum EN_INTERFACE_TYPE
{
    OpcUa,
    ModbusSerial,
    ModbusTcp,
    Serial,
    SocketClient,
    SocketServer,
    SocketClientUdp,
    SocketServerUdp,
    AcsNet,
    XpsNet,
    Automation1Net,
    PicoMotor,
    MelsecNet
}

public sealed record ST_INTERFACE_HISTORY(DateTimeOffset OccurredAt, EN_EQP_MODULE Module, string NickName, string Action, string BeforeState, string AfterState, string Detail);
public sealed record ST_DEVICE_COMM_STATUS(EN_EQP_MODULE Module, EN_COMM_STATE ConnectionState);
public sealed record ST_INTERFACE_CONNECT_OPTION(string Endpoint, string LocalAddress, string RemoteAddress, int Port, int TimeoutMs, int RetryCount, string SerialPort, int BaudRate, string Parity, int DataBits, string StopBits, string Handshake, int MaxClientCount = 8);
public sealed record ST_INTERFACE_COMM_STATUS(EN_EQP_MODULE Module, string NickName, EN_INTERFACE_TYPE InterfaceType, int Number, bool AutoConnection, EN_COMM_STATE ConnectionState, bool IsSimulation, string Endpoint, string LastSent, string LastReceived, string LastError, DateTimeOffset? LastChangedAt)
{
    public string InstanceKey
    {
        get
        {
            return $"{Module}[{Number}]";
        }
    }
}

public sealed record ST_INTERFACE_RECEIVED_MESSAGE(DateTimeOffset ReceivedAt, EN_EQP_MODULE Module, int Number, string NickName, string RemoteEndPoint, string Message);
public sealed record ST_INTERFACE_PROTOCOL_TRACE(DateTimeOffset OccurredAt, EN_EQP_MODULE Module, int Number, string NickName, string Direction, string Message);
internal sealed record ST_COMM_PROTOCOL_TRACE(DateTimeOffset OccurredAt, string Direction, string Message);
public sealed record ST_INTERFACE_DATA(EN_INTERFACE_TYPE InterfaceType, EN_EQP_MODULE Device, int Number, string NickName, string SystemSection, bool AutoConnection, bool IsSimulation, IReadOnlyList<string> Arguments, IReadOnlyDictionary<string, string>? Extra = null)
{
    public string InstanceKey
    {
        get
        {
            return $"{Device}[{Number}]";
        }
    }
}

public sealed record ST_DEVICE_COMMAND_RESULT(bool IsSuccess, string Message);
public abstract class CBETFileBase
{
    public abstract Task<IReadOnlyList<ST_BET_TABLE_DATA>> Load(CancellationToken cancellationToken = default);
    public abstract Task Save(IReadOnlyList<ST_BET_TABLE_DATA> table, CancellationToken cancellationToken = default);
}

public partial class CInterfaceManager
{
    private readonly ConcurrentDictionary<string, CInterfaceDevice> _devices = new(StringComparer.OrdinalIgnoreCase);
    private readonly CLogManager? _logManager;
    private readonly CBETFileBase? _betFile;
    private readonly CMelsec _melsec;
    private readonly CPicoMotorService _picoMotorService = new();
    private bool? _simulationMode;
    public event Func<ST_INTERFACE_RECEIVED_MESSAGE, CancellationToken, Task<string>>? MessageReceived;
    public event Action<ST_INTERFACE_PROTOCOL_TRACE>? ProtocolTrace;
    public CInterfaceManager(bool? simulationMode = null, CLogManager? logManager = null, CBETFileBase? betFile = null, IReadOnlyList<ST_MELSEC_MAP_DATA>? melsecMap = null, CMelsecNetApi? melsecNetApi = null)
    {
        _simulationMode = simulationMode;
        _logManager = logManager;
        _betFile = betFile;
        _melsec = new CMelsec(this, _logManager, melsecMap, melsecNetApi);
        AttenuatorSnapshots = new CAttenuatorStatusSnapshotService(
            () => GetInterfaceList(EN_EQP_MODULE.Attenuator).Select(data => data.Number).ToArray(),
            number => IsConnect(EN_EQP_MODULE.Attenuator, number) || IsSimul(EN_EQP_MODULE.Attenuator, number),
            async (number, command, token) =>
            {
                if (!IsConnect(EN_EQP_MODULE.Attenuator, number) && !IsSimul(EN_EQP_MODULE.Attenuator, number))
                    throw new IOException("ATT가 연결되어 있지 않습니다.");
                var response = await ExecuteAttenuatorCommand(number, command, cancellationToken: token, suppressCommandLog: true).ConfigureAwait(false);
                if (!response.IsSuccess) throw new IOException(response.Message);
                if (!IsSimul(EN_EQP_MODULE.Attenuator, number)) return response.Message;
                var status = GetAttenuatorStatusValue(number);
                return command switch
                {
                    EN_ATTENUATOR_COMMAND.PollState => $"TS:0:{status.CommandState}",
                    EN_ATTENUATOR_COMMAND.PollCurrentPosition => $"TP:{status.CurrentPosition.ToString("R", CultureInfo.InvariantCulture)}",
                    EN_ATTENUATOR_COMMAND.PollTargetPosition => $"TH:{status.TargetPosition.ToString("R", CultureInfo.InvariantCulture)}",
                    _ => throw new InvalidOperationException("지원하지 않는 ATT 스냅샷 명령입니다.")
                };
            }, GetAttenuatorStatusValue);
        OpticSnapshots = CreateOpticSnapshots();
    }

    public CAttenuatorStatusSnapshotService AttenuatorSnapshots { get; }
    public COpticStatusSnapshotService OpticSnapshots { get; }

    public bool IsSimulation
    {
        get
        {
            bool IsIsSimulation(global::Drilling.Common.Interface.CInterfaceDevice device)
            {
                return device.IsSimulation;
            }

            return _devices.Count == 0 ? _simulationMode ?? true : _devices.Values.All(IsIsSimulation);
        }
    }

    public IReadOnlyList<CInterfaceDevice> Devices
    {
        get
        {
            return _devices.Values.ToArray();
        }
    }

    public CMelsec Melsec
    {
        get
        {
            return _melsec;
        }
    }

    public async Task SetSimulationMode(bool enabled, CancellationToken cancellationToken = default)
    {
        await AttenuatorSnapshots.StopAsync(cancellationToken);
        await OpticSnapshots.StopAsync();
        bool IsMelsecDevice(CInterfaceDevice device)
        {
            return device.Data.Device == EN_EQP_MODULE.Melsec;
        }

        var restartMelsec = _devices.Values.Any(IsMelsecDevice);
        if (restartMelsec)
        {
            _melsec.DeInitialize();
        }

        _simulationMode = enabled;
        foreach (var device in _devices.Values)
        {
            cancellationToken.ThrowIfCancellationRequested();
            await device.SetSimulationMode(enabled, cancellationToken);
        }

        if (restartMelsec)
        {
            _melsec.Initialize();
        }
        AttenuatorSnapshots.Start();
        OpticSnapshots.Start();
    }

    public void Register(ST_INTERFACE_DATA data)
    {
        var key = CreateDeviceKey(data.Device, data.Number);
        if (_devices.ContainsKey(key))
        {
            throw new InvalidOperationException($"Interface device was already registered: {FormatDeviceName(data)}");
        }

        _devices[key] = CreateDevice(data);
    }

    private CInterfaceDevice CreateDevice(ST_INTERFACE_DATA data)
    {
        var device = new CInterfaceDevice(data, _simulationMode ?? data.IsSimulation);
        if (data.Device == EN_EQP_MODULE.Melsec)
        {
            device.EnableExternalCommunication();
        }

        device.MessageReceived += OnDeviceMessageReceived;
        device.ProtocolTrace += OnDeviceProtocolTrace;
        return device;
    }

    public Task Initialize(CancellationToken cancellationToken = default)
    {
        return Connect(init: true, cancellationToken);
    }

    public async Task Destroy(CancellationToken cancellationToken = default)
    {
        await Disconnect(cancellationToken);
        await AttenuatorSnapshots.DisposeAsync();
        await OpticSnapshots.DisposeAsync();
        _picoMotorService.DisconnectAll();
        _devices.Clear();
        ClearDeviceStateMaps();
    }

    public async Task<int> Connect(bool init = false, CancellationToken cancellationToken = default)
    {
        var connectedCount = 0;
        foreach (var device in _devices.Values)
        {
            if (!device.Data.AutoConnection)
            {
                continue;
            }

            if (device.ConnectionState is EN_COMM_STATE.Online or EN_COMM_STATE.Simulation
                && (device.Data.Device != EN_EQP_MODULE.Melsec || _melsec.IsCommunicationAvailable))
            {
                connectedCount++;
                continue;
            }

            var beforeState = device.ConnectionState;
            device.ResetAutoReconnectPolicy();
            if (device.Data.Device == EN_EQP_MODULE.Melsec)
            {
                ConnectMelsecDevice(device, cancellationToken);
            }
            else
            {
                await device.Connect(cancellationToken);
            }

            WriteConnectionLog(init ? "INIT_CONNECT" : "CONNECT", device, beforeState);
            if (device.ConnectionState is EN_COMM_STATE.Online or EN_COMM_STATE.Simulation)
            {
                connectedCount++;
            }
        }

        AttenuatorSnapshots.Start();
        OpticSnapshots.Start();
        return connectedCount;
    }

    public async Task<int> Disconnect(CancellationToken cancellationToken = default)
    {
        await AttenuatorSnapshots.StopAsync(cancellationToken);
        await OpticSnapshots.StopAsync();
        foreach (var device in _devices.Values)
        {
            var beforeState = device.ConnectionState;
            device.SuppressAutoReconnect();
            if (device.Data.Device == EN_EQP_MODULE.Melsec)
            {
                DisconnectMelsecDevice(device, cancellationToken);
            }
            else
            {
                await device.Disconnect(cancellationToken);
            }

            WriteConnectionLog("DISCONNECT", device, beforeState);
        }

        _melsec.DeInitialize();
        _picoMotorService.DisconnectAll();
        return _devices.Count;
    }

    public async Task Connect(EN_EQP_MODULE module, int number, bool autoConnection = true, CancellationToken cancellationToken = default)
    {
        var device = GetDeviceOrThrow(module, number);
        device.ResetAutoReconnectPolicy();
        await ConnectDevice(device, autoConnection, cancellationToken);
        if (module == EN_EQP_MODULE.Attenuator)
        {
            AttenuatorSnapshots.Invalidate(number, "LOADING", "ATT 연결 후 새 상태를 기다리고 있습니다.");
            AttenuatorSnapshots.Start();
        }
        OpticSnapshots.Start();
    }

    public async Task Disconnect(EN_EQP_MODULE module, int number, CancellationToken cancellationToken = default)
    {
        if (!_devices.TryGetValue(CreateDeviceKey(module, number), out var device))
        {
            return;
        }

        OpticSnapshots.Invalidate(module, number);
        if (module == EN_EQP_MODULE.Attenuator) AttenuatorSnapshots.Invalidate(number);
        await DisconnectDevice(device, cancellationToken);
        OpticSnapshots.Invalidate(module, number);
        if (module == EN_EQP_MODULE.Attenuator) AttenuatorSnapshots.Invalidate(number);
    }

    public async Task Reconnect(EN_EQP_MODULE module, int number, CancellationToken cancellationToken = default)
    {
        var device = GetDeviceOrThrow(module, number);
        if (module == EN_EQP_MODULE.Attenuator) AttenuatorSnapshots.Invalidate(number, "LOADING", "ATT 재연결 후 상태를 기다리고 있습니다.");
        var beforeState = device.ConnectionState;
        if (device.Data.Device == EN_EQP_MODULE.Melsec)
        {
            DisconnectMelsecDevice(device, cancellationToken);
            ConnectMelsecDevice(device, cancellationToken);
        }
        else
        {
            await device.Disconnect(cancellationToken);
            device.ResetAutoReconnectPolicy();
            await device.Connect(cancellationToken);
        }

        WriteConnectionLog("RECONNECT", device, beforeState);
        if (module == EN_EQP_MODULE.Attenuator)
        {
            AttenuatorSnapshots.Invalidate(number, "LOADING", "ATT 재연결 후 새 상태를 기다리고 있습니다.");
            AttenuatorSnapshots.Start();
        }
        OpticSnapshots.Start();
    }

    public virtual async Task<string> ExecuteFunction(EN_EQP_MODULE module, int number, string function, CancellationToken cancellationToken = default)
    {
        var device = GetDeviceOrThrow(module, number);
        return await ExecuteDeviceFunction(device, function, cancellationToken);
    }

    public virtual async Task<string> ExecuteFunctionNoLog(EN_EQP_MODULE module, int number, string function, CancellationToken cancellationToken = default)
    {
        var device = GetDeviceOrThrow(module, number);
        return await ExecuteDeviceFunction(device, function, cancellationToken, suppressLog: true);
    }

    public async Task<string> ExecuteFunctionWithLogText(EN_EQP_MODULE module, int number, string function, string logText, CancellationToken cancellationToken = default)
    {
        var device = GetDeviceOrThrow(module, number);
        return await ExecuteDeviceFunction(device, function, cancellationToken, logText);
    }

    public bool IsConnect(EN_EQP_MODULE module, int number)
    {
        return _devices.TryGetValue(CreateDeviceKey(module, number), out var device) && device.ConnectionState is EN_COMM_STATE.Online or EN_COMM_STATE.Simulation;
    }

    public bool IsSimul(EN_EQP_MODULE module, int number)
    {
        return _devices.TryGetValue(CreateDeviceKey(module, number), out var device) && device.ConnectionState == EN_COMM_STATE.Simulation;
    }

    public ST_INTERFACE_DATA? GetInterfaceData(EN_EQP_MODULE module, int number)
    {
        return _devices.TryGetValue(CreateDeviceKey(module, number), out var device) ? device.Data : null;
    }

    internal void UpdateMelsecCommunicationState(int number, bool online, string lastSent, string lastReceived, string lastError)
    {
        if (!_devices.TryGetValue(CreateDeviceKey(EN_EQP_MODULE.Melsec, number), out var device) || device.IsSimulation)
        {
            return;
        }

        device.SetExternalCommunicationState(online ? EN_COMM_STATE.Online : EN_COMM_STATE.Offline, lastSent, lastReceived, lastError);
    }

    public async Task Connect(string nickName, bool autoConnection = true, CancellationToken cancellationToken = default)
    {
        var device = GetDeviceByNickNameOrThrow(nickName);
        device.ResetAutoReconnectPolicy();
        await ConnectDevice(device, autoConnection, cancellationToken);
        if (device.Data.Device == EN_EQP_MODULE.Attenuator)
        {
            AttenuatorSnapshots.Invalidate(device.Data.Number, "LOADING", "ATT 연결 후 새 상태를 기다리고 있습니다.");
            AttenuatorSnapshots.Start();
        }
        OpticSnapshots.Start();
    }

    public async Task Disconnect(string nickName, CancellationToken cancellationToken = default)
    {
        if (!TryGetDeviceByNickName(nickName, out var device, throwIfAmbiguous: true) || device is null)
        {
            return;
        }

        OpticSnapshots.Invalidate(device.Data.Device, device.Data.Number);
        if (device.Data.Device == EN_EQP_MODULE.Attenuator) AttenuatorSnapshots.Invalidate(device.Data.Number);
        await DisconnectDevice(device, cancellationToken);
        OpticSnapshots.Invalidate(device.Data.Device, device.Data.Number);
        if (device.Data.Device == EN_EQP_MODULE.Attenuator) AttenuatorSnapshots.Invalidate(device.Data.Number);
    }

    public async Task Reconnect(string nickName, CancellationToken cancellationToken = default)
    {
        var device = GetDeviceByNickNameOrThrow(nickName);
        if (device.Data.Device == EN_EQP_MODULE.Attenuator) AttenuatorSnapshots.Invalidate(device.Data.Number, "LOADING", "ATT 재연결 후 상태를 기다리고 있습니다.");
        var beforeState = device.ConnectionState;
        if (device.Data.Device == EN_EQP_MODULE.Melsec)
        {
            DisconnectMelsecDevice(device, cancellationToken);
            ConnectMelsecDevice(device, cancellationToken);
        }
        else
        {
            await device.Disconnect(cancellationToken);
            device.ResetAutoReconnectPolicy();
            await device.Connect(cancellationToken);
        }

        WriteConnectionLog("RECONNECT", device, beforeState);
        if (device.Data.Device == EN_EQP_MODULE.Attenuator)
        {
            AttenuatorSnapshots.Invalidate(device.Data.Number, "LOADING", "ATT 재연결 후 새 상태를 기다리고 있습니다.");
            AttenuatorSnapshots.Start();
        }
        OpticSnapshots.Start();
    }

    public async Task<string> ExecuteFunction(string nickName, string function, CancellationToken cancellationToken = default)
    {
        var device = GetDeviceByNickNameOrThrow(nickName);
        return await ExecuteDeviceFunction(device, function, cancellationToken);
    }

    public bool IsConnect(string nickName)
    {
        return TryGetDeviceByNickName(nickName, out var device, throwIfAmbiguous: true) && device is not null && device.ConnectionState is EN_COMM_STATE.Online or EN_COMM_STATE.Simulation;
    }

    public bool IsSimul(string nickName)
    {
        return TryGetDeviceByNickName(nickName, out var device, throwIfAmbiguous: true) && device is not null && device.ConnectionState == EN_COMM_STATE.Simulation;
    }

    public ST_INTERFACE_DATA? GetInterfaceData(string nickName)
    {
        return TryGetDeviceByNickName(nickName, out var device, throwIfAmbiguous: true) && device is not null ? device.Data : null;
    }

    public IReadOnlyList<ST_INTERFACE_DATA> GetInterfaceList(EN_EQP_MODULE? module = null)
    {
        bool MatchesCinterfacedevice(global::Drilling.Common.Interface.CInterfaceDevice device)
        {
            return module is null || device.Data.Device == module;
        }

        global::Drilling.Common.Interface.ST_INTERFACE_DATA SelectData(global::Drilling.Common.Interface.CInterfaceDevice device)
        {
            return device.Data;
        }

        global::Drilling.Common.Interface.EN_EQP_MODULE SelectDevice(global::Drilling.Common.Interface.ST_INTERFACE_DATA data)
        {
            return data.Device;
        }

        int SelectNumber(global::Drilling.Common.Interface.ST_INTERFACE_DATA data)
        {
            return data.Number;
        }

        string SelectNickName(global::Drilling.Common.Interface.ST_INTERFACE_DATA data)
        {
            return data.NickName;
        }

        return _devices.Values.Where(MatchesCinterfacedevice).Select(SelectData).OrderBy(SelectDevice).ThenBy(SelectNumber).ThenBy(SelectNickName, StringComparer.OrdinalIgnoreCase).ToArray();
    }

    public IReadOnlyList<ST_INTERFACE_COMM_STATUS> GetInterfaceCommunicationList(EN_EQP_MODULE? module = null)
    {
        bool MatchesCinterfacedevice(global::Drilling.Common.Interface.CInterfaceDevice device)
        {
            return module is null || device.Data.Device == module;
        }

        global::Drilling.Common.Interface.ST_INTERFACE_COMM_STATUS SelectValue(global::Drilling.Common.Interface.CInterfaceDevice device)
        {
            return device.GetCommunicationStatus();
        }

        global::Drilling.Common.Interface.EN_EQP_MODULE SelectModule(global::Drilling.Common.Interface.ST_INTERFACE_COMM_STATUS status)
        {
            return status.Module;
        }

        int SelectNumber(global::Drilling.Common.Interface.ST_INTERFACE_COMM_STATUS status)
        {
            return status.Number;
        }

        string SelectNickName(global::Drilling.Common.Interface.ST_INTERFACE_COMM_STATUS status)
        {
            return status.NickName;
        }

        return _devices.Values.Where(MatchesCinterfacedevice).Select(SelectValue).OrderBy(SelectModule).ThenBy(SelectNumber).ThenBy(SelectNickName, StringComparer.OrdinalIgnoreCase).ToArray();
    }

    public Task<IReadOnlyList<ST_INTERFACE_HISTORY>> ReadInterfaceHistory(EN_EQP_MODULE? module = null, string nickName = "", int maxRows = 100, Func<ST_INTERFACE_HISTORY, bool>? filter = null, CancellationToken cancellationToken = default, TimeSpan? lookback = null)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (_logManager is null) return Task.FromResult<IReadOnlyList<ST_INTERFACE_HISTORY>>([]);
        var through = DateTimeOffset.Now;
        return Task.Run(() => lookback is { } period
            ? _logManager.ReadInterfaceWindow(module, nickName, maxRows, through - period, through, filter, cancellationToken)
            : _logManager.ReadInterfaceRecent(module, nickName, maxRows, filter: filter), cancellationToken);
    }

    public IReadOnlyList<ST_DEVICE_COMM_STATUS> GetCommunicationStatus(CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        global::Drilling.Common.Interface.EN_EQP_MODULE SelectValue(global::Drilling.Common.Interface.CInterfaceDevice device)
        {
            return device.Data.Device;
        }

        global::Drilling.Common.Interface.EN_COMM_STATE SelectConnectionState(global::Drilling.Common.Interface.CInterfaceDevice device)
        {
            return device.ConnectionState;
        }

        global::Drilling.Common.Interface.ST_DEVICE_COMM_STATUS BuildDevice(global::System.Linq.IGrouping<global::Drilling.Common.Interface.EN_EQP_MODULE, global::Drilling.Common.Interface.CInterfaceDevice> group)
        {
            return new ST_DEVICE_COMM_STATUS(group.Key, CollapseConnectionState(group.Select(SelectConnectionState)));
        }

        global::Drilling.Common.Interface.EN_EQP_MODULE SelectModule(global::Drilling.Common.Interface.ST_DEVICE_COMM_STATUS status)
        {
            return status.Module;
        }

        return _devices.Values.GroupBy(SelectValue).Select(BuildDevice).OrderBy(SelectModule).ToArray();
    }

    private static EN_COMM_STATE CollapseConnectionState(IEnumerable<EN_COMM_STATE> states)
    {
        var stateArray = states.ToArray();
        bool MatchesItem(global::Drilling.Common.Interface.EN_COMM_STATE state)
        {
            return state == EN_COMM_STATE.Offline;
        }

        if (stateArray.Any(MatchesItem))
        {
            return EN_COMM_STATE.Offline;
        }

        bool MatchesItem2(global::Drilling.Common.Interface.EN_COMM_STATE state)
        {
            return state == EN_COMM_STATE.Simulation;
        }

        if (stateArray.All(MatchesItem2))
        {
            return EN_COMM_STATE.Simulation;
        }

        return EN_COMM_STATE.Online;
    }

    private async Task ConnectDevice(CInterfaceDevice device, bool autoConnection, CancellationToken cancellationToken)
    {
        if (!autoConnection && device.Data.AutoConnection)
        {
            return;
        }

        var beforeState = device.ConnectionState;
        if (device.Data.Device == EN_EQP_MODULE.Melsec)
        {
            ConnectMelsecDevice(device, cancellationToken);
        }
        else
        {
            await device.Connect(cancellationToken);
        }

        WriteConnectionLog("CONNECT", device, beforeState);
    }

    private async Task AutoReconnectDevice(EN_EQP_MODULE module, int number, CancellationToken cancellationToken)
    {
        var device = GetDeviceOrThrow(module, number);
        var beforeState = device.ConnectionState;
        await device.Connect(cancellationToken);
        if (device.ConnectionState != beforeState || device.ConnectionState is EN_COMM_STATE.Online or EN_COMM_STATE.Simulation)
        {
            WriteConnectionLog("AUTO_RECONNECT", device, beforeState);
        }
    }

    private async Task DisconnectDevice(CInterfaceDevice device, CancellationToken cancellationToken)
    {
        var beforeState = device.ConnectionState;
        device.SuppressAutoReconnect();
        if (device.Data.Device == EN_EQP_MODULE.Melsec)
        {
            DisconnectMelsecDevice(device, cancellationToken);
        }
        else
        {
            await device.Disconnect(cancellationToken);
        }

        WriteConnectionLog("DISCONNECT", device, beforeState);
    }

    private void ConnectMelsecDevice(CInterfaceDevice device, CancellationToken cancellationToken)
    {
        _melsec.Initialize();
        if (device.IsSimulation)
        {
            _melsec.Open(device.Data.Number, cancellationToken);
            device.SetExternalCommunicationState(EN_COMM_STATE.Simulation, "[SIMULATION] OPEN", "[SIMULATION] READY", "");
            return;
        }

        try
        {
            _melsec.Open(device.Data.Number, cancellationToken);
            device.SetExternalCommunicationState(EN_COMM_STATE.Online, "OPEN", "CONNECTED", "");
        }
        catch (Exception exception) when (exception is not OperationCanceledException)
        {
            device.SetExternalCommunicationState(EN_COMM_STATE.Offline, "OPEN", "", exception.Message);
        }
    }

    private void DisconnectMelsecDevice(CInterfaceDevice device, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        _melsec.DeInitialize();
        var closedState = device.IsSimulation ? EN_COMM_STATE.Simulation : EN_COMM_STATE.Offline;
        device.SetExternalCommunicationState(closedState, device.IsSimulation ? "[SIMULATION] CLOSE" : "CLOSE", device.IsSimulation ? "[SIMULATION] CLOSED" : "CLOSED", "");
    }

    private async Task<string> ExecuteDeviceFunction(CInterfaceDevice device, string function, CancellationToken cancellationToken, string? logText = null, bool suppressLog = false)
    {
        try
        {
            var response = await device.ExecuteFunction(function, cancellationToken);
            if (!suppressLog)
            {
                WriteCommandLog(device, function, response, logText);
            }

            return response;
        }
        catch (Exception ex)when (ex is InvalidOperationException or IOException or TimeoutException)
        {
            if (!suppressLog)
            {
                WriteErrorLog(device, function, ex.Message, logText);
            }

            throw;
        }
    }

    private CInterfaceDevice GetDeviceOrThrow(EN_EQP_MODULE module, int number)
    {
        return _devices.TryGetValue(CreateDeviceKey(module, number), out var device) ? device : throw new KeyNotFoundException($"Interface device was not registered: {FormatDeviceName(module, number)}");
    }

    private CInterfaceDevice GetDeviceByNickNameOrThrow(string nickName)
    {
        return TryGetDeviceByNickName(nickName, out var device, throwIfAmbiguous: true) && device is not null ? device : throw new KeyNotFoundException($"Interface device was not registered: {nickName}");
    }

    private bool TryGetDeviceByNickName(string nickName, out CInterfaceDevice? device, bool throwIfAmbiguous = false)
    {
        var normalized = NormalizeNickName(nickName);
        bool ShouldIncludeItem(global::Drilling.Common.Interface.CInterfaceDevice item)
        {
            return NormalizeNickName(item.Data.NickName).Equals(normalized, StringComparison.OrdinalIgnoreCase);
        }

        var matches = _devices.Values.Where(ShouldIncludeItem).ToArray();
        if (matches.Length == 0)
        {
            device = null;
            return false;
        }

        string SelectItem(global::Drilling.Common.Interface.CInterfaceDevice item)
        {
            return FormatDeviceName(item.Data);
        }

        if (matches.Length > 1 && throwIfAmbiguous)
        {
            var candidates = string.Join(", ", matches.Select(SelectItem));
            throw new InvalidOperationException($"Interface NICKNAME is duplicated: {nickName}. Use DEVICE + NUMBER instead. Candidates: {candidates}");
        }

        device = matches[0];
        return true;
    }

    private void WriteConnectionLog(string action, CInterfaceDevice device, EN_COMM_STATE beforeState)
    {
        if (_logManager is null)
        {
            return;
        }

        var status = device.GetCommunicationStatus();
        var afterState = FormatConnectionState(status.ConnectionState);
        if (!string.IsNullOrWhiteSpace(status.LastError))
        {
            afterState = $"{afterState} / {status.LastError}";
        }

        _logManager.WriteInterfaceConnection(device.Data.Device, action, device.Data.NickName, FormatConnectionState(beforeState), afterState);
    }

    private void WriteCommandLog(CInterfaceDevice device, string command, string response, string? logText = null)
    {
        if (_logManager is null)
        {
            return;
        }

        var status = device.GetCommunicationStatus();
        var sentCommand = !string.IsNullOrWhiteSpace(logText) ? logText : string.IsNullOrWhiteSpace(status.LastSent) ? command : status.LastSent;
        var loggedResponse = !string.IsNullOrWhiteSpace(logText) ? response.Replace(command, logText, StringComparison.Ordinal) : response;
        if (!string.IsNullOrWhiteSpace(status.LastError))
        {
            _logManager.WriteInterfaceError(device.Data.Device, device.Data.NickName, sentCommand, status.LastError);
            return;
        }

        _logManager.WriteInterfaceCommand(device.Data.Device, device.Data.NickName, sentCommand, loggedResponse, FormatConnectionState(status.ConnectionState));
    }

    private void WriteErrorLog(CInterfaceDevice device, string command, string detail, string? logText = null)
    {
        var status = device.GetCommunicationStatus();
        var sentCommand = !string.IsNullOrWhiteSpace(logText) ? logText : string.IsNullOrWhiteSpace(status.LastSent) ? command : status.LastSent;
        _logManager?.WriteInterfaceError(device.Data.Device, device.Data.NickName, sentCommand, detail);
    }

    private async Task<string> OnDeviceMessageReceived(CInterfaceDevice device, ST_COMM_RECEIVED_MESSAGE message, CancellationToken cancellationToken)
    {
        var receivedMessage = new ST_INTERFACE_RECEIVED_MESSAGE(message.ReceivedAt, device.Data.Device, device.Data.Number, device.Data.NickName, message.RemoteEndPoint, message.Message);
        _logManager?.WriteInterfaceCommand(device.Data.Device, device.Data.NickName, $"RECV:{message.RemoteEndPoint}", message.Message, "SOCKET_SERVER");
        var handler = MessageReceived;
        if (handler is null)
        {
            return "ACK";
        }

        var response = "ACK";
        foreach (var callback in handler.GetInvocationList().Cast<Func<ST_INTERFACE_RECEIVED_MESSAGE, CancellationToken, Task<string>>>())
        {
            var callbackResponse = await callback(receivedMessage, cancellationToken);
            if (!string.IsNullOrWhiteSpace(callbackResponse))
            {
                response = callbackResponse;
            }
        }

        return string.IsNullOrWhiteSpace(response) ? "ACK" : response;
    }

    private void OnDeviceProtocolTrace(CInterfaceDevice device, ST_COMM_PROTOCOL_TRACE trace)
    {
        if (trace.Direction.Equals("PACKET", StringComparison.OrdinalIgnoreCase))
        {
            _logManager?.WriteInterfaceProtocolTrace(
                device.Data.Device,
                trace.OccurredAt,
                trace.Message);
        }

        ProtocolTrace?.Invoke(new ST_INTERFACE_PROTOCOL_TRACE(
            trace.OccurredAt,
            device.Data.Device,
            device.Data.Number,
            device.Data.NickName,
            trace.Direction,
            trace.Message));
    }

    private void WriteTalonCommandLog(ST_INTERFACE_DATA data, string command, string response)
    {
        WriteInterfaceCommandLog(data, command, response);
    }

    private void WriteTalonErrorLog(ST_INTERFACE_DATA data, string command, string detail)
    {
        WriteInterfaceErrorLog(data, command, detail);
    }

    private void WriteInterfaceCommandLog(ST_INTERFACE_DATA data, string command, string response)
    {
        _logManager?.WriteInterfaceCommand(data.Device, data.NickName, command, response, data.IsSimulation ? "SIMULATION" : "");
    }

    private void WriteInterfaceErrorLog(ST_INTERFACE_DATA data, string command, string detail)
    {
        _logManager?.WriteInterfaceError(data.Device, data.NickName, command, detail);
    }

    private static string FormatConnectionState(EN_COMM_STATE state)
    {
        return state switch
        {
            EN_COMM_STATE.Online => "ONLINE",
            EN_COMM_STATE.Simulation => "SIMULATION",
            _ => "OFFLINE"
        };
    }

    private static string NormalizeNickName(string nickName)
    {
        return nickName.Trim().ToUpperInvariant();
    }

    private static string CreateDeviceKey(EN_EQP_MODULE module, int number)
    {
        return $"{module}:{number}";
    }

    private static string FormatDeviceName(ST_INTERFACE_DATA data)
    {
        return $"{data.Device}[{data.Number}]/{data.NickName}";
    }

    private static string FormatDeviceName(EN_EQP_MODULE module, int number)
    {
        return $"{module}[{number}]";
    }

    private readonly Dictionary<int, HashSet<int>> _laserOnHeads = [];
    private readonly ConcurrentDictionary<int, ST_TALON_STATUS> _talonStatuses = new();
    private readonly Dictionary<int, ST_ATTENUATOR_STATUS> _attenuatorStatuses = [];
    private readonly object _attenuatorStatusLock = new();
    private readonly ConcurrentDictionary<int, ST_BET_STATUS> _betStatuses = new();
    private readonly ConcurrentDictionary<int, ST_POWER_METER_STATUS> _powerMeterStatuses = new();
    private readonly Dictionary<int, int> _powerMeterSimulationAttenuators = [];
    public ST_LASER_STATUS GetLaserStatus(CancellationToken cancellationToken = default)
    {
        var interfaceData = GetTalonInterfaceData();
        return GetLaserStatus(interfaceData?.Number ?? 0, cancellationToken);
    }

    public ST_LASER_STATUS GetLaserStatus(int number, CancellationToken cancellationToken = default)
    {
        var interfaceData = GetTalonInterfaceData(number);
        if (!IsInterfaceSimulation(interfaceData))
        {
            var liveStatus = RefreshTalonLaserStatus(number, cancellationToken);
            return new ST_LASER_STATUS(liveStatus.LaserOn, liveStatus.ShutterOpen, liveStatus.GateOpen, liveStatus.OutputPower);
        }

        var simulationStatus = GetTalonStatus(number);
        var outputPower = simulationStatus.OutputPower > 0.0 ? simulationStatus.OutputPower : simulationStatus.LaserOn ? 8.5 : 0.0;
        return new ST_LASER_STATUS(simulationStatus.LaserOn, simulationStatus.ShutterOpen, simulationStatus.GateOpen, outputPower);
    }

    public async Task SetLaser(int headNo, bool enabled, CancellationToken cancellationToken = default)
    {
        var interfaceData = GetTalonInterfaceData();
        await SetLaser(interfaceData?.Number ?? 0, headNo, enabled, cancellationToken);
    }

    public async Task SetLaser(int number, int headNo, bool enabled, CancellationToken cancellationToken = default)
    {
        var interfaceData = GetTalonInterfaceData(number);
        if (interfaceData is not null && IsInterfaceSimulation(interfaceData))
        {
            SetSimulLaserHead(number, headNo, enabled);
            var status = CTalonLaser.Apply(EN_TALON_COMMAND.SetLaserOnOff, enabled ? 1.0 : 0.0, "", GetTalonStatus(number), simulation: true);
            SetTalonStatus(number, status);
            return;
        }

        var result = await ExecuteTalonLaserCommand(number, EN_TALON_COMMAND.SetLaserOnOff, enabled ? 1.0 : 0.0, cancellationToken);
        if (result.IsSuccess)
        {
            SetSimulLaserHead(number, headNo, enabled);
        }
    }

    public async Task<ST_DEVICE_COMMAND_RESULT> ExecuteTalonLaserCommand(EN_TALON_COMMAND command, double parameter = 0.0, CancellationToken cancellationToken = default)
    {
        var interfaceData = GetTalonInterfaceData();
        return interfaceData is null ? new ST_DEVICE_COMMAND_RESULT(false, "Talon interface is not registered.") : await ExecuteTalonLaserCommand(interfaceData.Number, command, parameter, cancellationToken);
    }

    public async Task<ST_DEVICE_COMMAND_RESULT> ExecuteTalonLaserCommand(int number, EN_TALON_COMMAND command, double parameter = 0.0, CancellationToken cancellationToken = default, bool suppressCommandLog = false)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var commandText = CTalonLaser.Build(command, parameter);
        if (string.IsNullOrWhiteSpace(commandText))
        {
            return new ST_DEVICE_COMMAND_RESULT(false, $"Talon command is not defined: {command}");
        }

        var interfaceData = GetTalonInterfaceData(number);
        if (interfaceData is null)
        {
            return new ST_DEVICE_COMMAND_RESULT(false, $"Talon interface is not registered: {FormatDeviceName(EN_EQP_MODULE.TalonLaser, number)}");
        }

        if (IsInterfaceSimulation(interfaceData))
        {
            var status = CTalonLaser.Apply(command, parameter, "", GetTalonStatus(number), simulation: true);
            SetTalonStatus(number, status);
            if (!suppressCommandLog)
            {
                WriteTalonCommandLog(interfaceData, commandText, "SIMULATION OK");
            }

            return new ST_DEVICE_COMMAND_RESULT(true, $"SIM:TALON:{number}:{command}:OK");
        }

        if (!IsConnect(interfaceData.Device, interfaceData.Number))
        {
            await AutoReconnectDevice(interfaceData.Device, interfaceData.Number, cancellationToken);
        }

        if (!IsConnect(interfaceData.Device, interfaceData.Number))
        {
            SetTalonStatus(number, GetTalonStatus(number)with { LastError = EN_TALON_ERROR.Timeout });
            if (!suppressCommandLog)
            {
                WriteTalonErrorLog(interfaceData, commandText, "OFFLINE");
            }

            return new ST_DEVICE_COMMAND_RESULT(false, $"Talon interface is offline: {FormatDeviceName(interfaceData)}");
        }

        var response = suppressCommandLog ? await ExecuteFunctionNoLog(interfaceData.Device, interfaceData.Number, commandText, cancellationToken) : await ExecuteFunction(interfaceData.Device, interfaceData.Number, commandText, cancellationToken);
        var expectsResponse = CTalonLaser.ExpectsResponse(command);
        cancellationToken.ThrowIfCancellationRequested();
        if (expectsResponse && !CTalonLaser.IsValidResponse(response))
        {
            SetTalonStatus(number, GetTalonStatus(number)with { LastError = EN_TALON_ERROR.InvalidResponse });
            if (!suppressCommandLog)
            {
                WriteTalonErrorLog(interfaceData, commandText, $"INVALID RESPONSE / {response}");
            }

            return new ST_DEVICE_COMMAND_RESULT(false, $"Talon invalid response. Command={commandText}, Response={response}");
        }

        var updatedStatus = CTalonLaser.Apply(command, parameter, response, GetTalonStatus(number), simulation: false);
        SetTalonStatus(number, updatedStatus);
        return new ST_DEVICE_COMMAND_RESULT(true, expectsResponse ? response : $"Talon command sent: {commandText}");
    }

    public ST_TALON_STATUS RefreshTalonLaserStatus(CancellationToken cancellationToken = default)
    {
        var interfaceData = GetTalonInterfaceData();
        return interfaceData is null ? ST_TALON_STATUS.Empty : RefreshTalonLaserStatus(interfaceData.Number, cancellationToken);
    }

    public ST_TALON_STATUS RefreshTalonLaserStatus(int number, CancellationToken cancellationToken = default)
    {
        return RefreshTalonLaserStatus(number, cancellationToken, suppressCommandLog: false);
    }

    public ST_TALON_STATUS RefreshTalonLaserStatus(int number, CancellationToken cancellationToken, bool suppressCommandLog)
        => RefreshTalonLaserStatusAsync(number, cancellationToken, suppressCommandLog).GetAwaiter().GetResult();

    public async Task<ST_TALON_STATUS> RefreshTalonLaserStatusAsync(int number, CancellationToken cancellationToken, bool suppressCommandLog)
    {
        var interfaceData = GetTalonInterfaceData(number);
        if (IsInterfaceSimulation(interfaceData))
        {
            return GetTalonStatus(number);
        }

        EN_TALON_COMMAND[] commands = [EN_TALON_COMMAND.GetDiodeCurrent, EN_TALON_COMMAND.GetDiodeTemp, EN_TALON_COMMAND.GetGateOpenClose, EN_TALON_COMMAND.GetShutterOpenClose, EN_TALON_COMMAND.GetExtGateEnableDisable, EN_TALON_COMMAND.GetOutputPower, EN_TALON_COMMAND.GetTowerTemp, EN_TALON_COMMAND.GetQsw, EN_TALON_COMMAND.GetThgSpot, EN_TALON_COMMAND.GetThgHour, EN_TALON_COMMAND.RequestStatusString, EN_TALON_COMMAND.GetQMode];
        foreach (var command in commands)
        {
            var result = await ExecuteTalonLaserCommand(number, command, cancellationToken: cancellationToken, suppressCommandLog: suppressCommandLog).ConfigureAwait(false);
            if (!result.IsSuccess)
            {
                return GetTalonStatus(number);
            }
        }

        return GetTalonStatus(number);
    }

    public ST_ATTENUATOR_STATUS GetAttenuatorStatus(CancellationToken cancellationToken = default)
    {
        var interfaceData = GetAttenuatorInterfaceData();
        return GetAttenuatorStatus(interfaceData?.Number ?? 0, cancellationToken);
    }

    public ST_ATTENUATOR_STATUS GetAttenuatorStatus(int number, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var snapshot = AttenuatorSnapshots.GetSnapshot(number);
        if (snapshot.IsValid && snapshot.IsFresh(TimeSpan.FromSeconds(2))) return snapshot.Value!;
        return new ST_ATTENUATOR_STATUS(double.NaN, double.NaN, snapshot.State, CommOk: false,
            LastError: EN_CONEX_AGP_ERROR.Timeout, UpdatedAt: snapshot.UpdatedAt == DateTimeOffset.MinValue ? null : snapshot.UpdatedAt);
    }

    public ST_ATTENUATOR_STATUS GetCachedAttenuatorStatus(int number)
    {
        return GetAttenuatorStatusValue(number);
    }

    public async Task<ST_DEVICE_COMMAND_RESULT> ExecuteAttenuatorCommand(EN_ATTENUATOR_COMMAND command, double parameter = 0.0, CancellationToken cancellationToken = default)
    {
        var interfaceData = GetAttenuatorInterfaceData();
        return interfaceData is null ? new ST_DEVICE_COMMAND_RESULT(false, "CONEX_AGP interface is not registered.") : await ExecuteAttenuatorCommand(interfaceData.Number, command, parameter, cancellationToken);
    }

    public async Task<ST_DEVICE_COMMAND_RESULT> ExecuteAttenuatorCommand(int number, EN_ATTENUATOR_COMMAND command, double parameter = 0.0, CancellationToken cancellationToken = default, bool suppressCommandLog = false)
    {
        var changesMotion = command is EN_ATTENUATOR_COMMAND.MoveAbs or EN_ATTENUATOR_COMMAND.MoveRel or
            EN_ATTENUATOR_COMMAND.Home or EN_ATTENUATOR_COMMAND.Stop or EN_ATTENUATOR_COMMAND.ResetController;
        if (changesMotion) AttenuatorSnapshots.Invalidate(number, "LOADING", "ATT 명령 후 새 상태 수집을 기다리고 있습니다.");
        try
        {
            if (command is EN_ATTENUATOR_COMMAND.MoveAbs or EN_ATTENUATOR_COMMAND.MoveRel)
            {
                return await ExecuteAttenuatorMoveWithinLimits(number, command, parameter, cancellationToken, suppressCommandLog);
            }

            return await ExecuteAttenuatorCommandCore(number, command, parameter, cancellationToken, suppressCommandLog);
        }
        finally
        {
            // Discard an older READY sample, including a frame that started while the command was in flight.
            if (changesMotion) AttenuatorSnapshots.Invalidate(number, "LOADING", "ATT 명령 후 새 상태 수집을 기다리고 있습니다.");
        }
    }

    private async Task<ST_DEVICE_COMMAND_RESULT> ExecuteAttenuatorCommandCore(int number, EN_ATTENUATOR_COMMAND command, double parameter, CancellationToken cancellationToken, bool suppressCommandLog)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (command == EN_ATTENUATOR_COMMAND.Refresh)
        {
            var status = RefreshAttenuatorStatus(number, cancellationToken, suppressCommandLog);
            return new ST_DEVICE_COMMAND_RESULT(true, $"CONEX_AGP refreshed. Position {status.CurrentPosition:F3} DEG.");
        }

        string commandText;
        try
        {
            commandText = CConex_AGP.Build(command, parameter);
        }
        catch (ArgumentOutOfRangeException ex)
        {
            return new ST_DEVICE_COMMAND_RESULT(false, $"CONEX_AGP command parameter is invalid. Command={command}, Parameter={parameter.ToString(CultureInfo.InvariantCulture)}, Reason={ex.Message}");
        }

        if (string.IsNullOrWhiteSpace(commandText))
        {
            return new ST_DEVICE_COMMAND_RESULT(false, $"CONEX_AGP command is not defined: {command}");
        }

        var interfaceData = GetAttenuatorInterfaceData(number);
        if (interfaceData is null)
        {
            return new ST_DEVICE_COMMAND_RESULT(false, $"CONEX_AGP interface is not registered: {FormatDeviceName(EN_EQP_MODULE.Attenuator, number)}");
        }

        if (IsInterfaceSimulation(interfaceData))
        {
            var status = CConex_AGP.Apply(command, parameter, "", GetAttenuatorStatusValue(number), simulation: true);
            SetAttenuatorStatus(number, status);
            if (!suppressCommandLog)
            {
                WriteInterfaceCommandLog(interfaceData, commandText, "SIMULATION OK");
            }

            return new ST_DEVICE_COMMAND_RESULT(true, $"SIM:CONEX_AGP:{number}:{command}:OK");
        }

        if (!IsConnect(interfaceData.Device, interfaceData.Number) && command is not (EN_ATTENUATOR_COMMAND.PollState or EN_ATTENUATOR_COMMAND.PollCurrentPosition or EN_ATTENUATOR_COMMAND.PollTargetPosition))
        {
            await AutoReconnectDevice(interfaceData.Device, interfaceData.Number, cancellationToken);
        }

        if (!IsConnect(interfaceData.Device, interfaceData.Number))
        {
            SetAttenuatorStatus(number, GetAttenuatorStatusValue(number)with { CommOk = false, LastError = EN_CONEX_AGP_ERROR.Timeout, UpdatedAt = DateTimeOffset.Now });
            if (!suppressCommandLog)
            {
                WriteInterfaceErrorLog(interfaceData, commandText, "OFFLINE");
            }

            return new ST_DEVICE_COMMAND_RESULT(false, $"CONEX_AGP interface is offline: {FormatDeviceName(interfaceData)}");
        }

        if (IsAttenuatorSelectingCommand(command))
        {
            //var currentStatus = GetAttenuatorStatusValue(number);
            //var validationError = ValidateAttenuatorCommand(command, parameter, currentStatus);
            //if (!string.IsNullOrWhiteSpace(validationError))
            //{
            //    WriteInterfaceErrorLog(interfaceData, commandText, validationError);
            //    return new ST_DEVICE_COMMAND_RESULT(false, $"CONEX_AGP command blocked. Command={commandText}, Reason={validationError}");
            //}
        }

        var response = suppressCommandLog ? await ExecuteFunctionNoLog(interfaceData.Device, interfaceData.Number, commandText, cancellationToken) : await ExecuteFunction(interfaceData.Device, interfaceData.Number, commandText, cancellationToken);
        var updatedStatus = CConex_AGP.Apply(command, parameter, response, GetAttenuatorStatusValue(number), simulation: false);
        SetAttenuatorStatus(number, updatedStatus);
        return CConex_AGP.IsSuccessResponse(response) ? new ST_DEVICE_COMMAND_RESULT(true, response) : new ST_DEVICE_COMMAND_RESULT(false, $"CONEX_AGP command failed. Command={commandText}, Response={response}");
    }

    public ST_ATTENUATOR_STATUS RefreshAttenuatorStatus(CancellationToken cancellationToken = default)
    {
        var interfaceData = GetAttenuatorInterfaceData();
        return interfaceData is null ? CreateDefaultAttenuatorStatus() : RefreshAttenuatorStatus(interfaceData.Number, cancellationToken);
    }

    public ST_ATTENUATOR_STATUS RefreshAttenuatorStatus(int number, CancellationToken cancellationToken = default)
    {
        return RefreshAttenuatorStatus(number, cancellationToken, suppressCommandLog: false);
    }

    public ST_ATTENUATOR_STATUS RefreshAttenuatorStatus(int number, CancellationToken cancellationToken, bool suppressCommandLog)
    {
        var interfaceData = GetAttenuatorInterfaceData(number);
        if (IsInterfaceSimulation(interfaceData))
        {
            return GetAttenuatorStatusValue(number);
        }

        EN_ATTENUATOR_COMMAND[] requiredCommands = [EN_ATTENUATOR_COMMAND.PollState, EN_ATTENUATOR_COMMAND.PollCurrentPosition];
        foreach (var command in requiredCommands)
        {
            var result = ExecuteAttenuatorCommand(number, command, cancellationToken: cancellationToken, suppressCommandLog: suppressCommandLog).GetAwaiter().GetResult();
            if (!result.IsSuccess)
            {
                return GetAttenuatorStatusValue(number);
            }
        }

        var status = GetAttenuatorStatusValue(number);
        if (status.CommandState is "DISABLE" or "READY" or "HOMING" or "MOVING")
        {
            var targetResult = ExecuteAttenuatorCommand(number, EN_ATTENUATOR_COMMAND.PollTargetPosition, cancellationToken: cancellationToken, suppressCommandLog: suppressCommandLog).GetAwaiter().GetResult();
            if (!targetResult.IsSuccess)
            {
                return GetAttenuatorStatusValue(number);
            }
        }

        return GetAttenuatorStatusValue(number);
    }

    private static bool IsAttenuatorSelectingCommand(EN_ATTENUATOR_COMMAND command)
    {
        return command is EN_ATTENUATOR_COMMAND.MoveAbs or EN_ATTENUATOR_COMMAND.MoveRel or
            EN_ATTENUATOR_COMMAND.Home or EN_ATTENUATOR_COMMAND.Stop or EN_ATTENUATOR_COMMAND.ResetController or
            EN_ATTENUATOR_COMMAND.SetHomeType or EN_ATTENUATOR_COMMAND.SetNegativeSoftwareLimit or
            EN_ATTENUATOR_COMMAND.SetPositiveSoftwareLimit or EN_ATTENUATOR_COMMAND.SetIGain or
            EN_ATTENUATOR_COMMAND.SetPGain or EN_ATTENUATOR_COMMAND.SetInterpolationFactor;
    }

    private static string ValidateAttenuatorCommand(EN_ATTENUATOR_COMMAND command, double parameter, ST_ATTENUATOR_STATUS status)
    {
        var state = status.CommandState.Trim().ToUpperInvariant();
        if (!status.CommOk || !status.UpdatedAt.HasValue || string.IsNullOrWhiteSpace(state) || state.StartsWith("STATE_", StringComparison.Ordinal))
        {
            return $"Controller state is unavailable: {status.CommandState}";
        }

        //if (command == EN_ATTENUATOR_COMMAND.Home && state != "NOT_REFERENCED")
        //{
        //    return $"OR is allowed only in NOT_REFERENCED state. Current={state}";
        //}

        if (command is EN_ATTENUATOR_COMMAND.MoveAbs or EN_ATTENUATOR_COMMAND.MoveRel)
        {
            if (state != "READY")
            {
                return $"PA/PR is allowed only in READY state. Current={state}";
            }

            var target = command == EN_ATTENUATOR_COMMAND.MoveAbs ? parameter : status.TargetPosition + parameter;
            if (status.NegativeSoftwareLimit.HasValue && target < status.NegativeSoftwareLimit.Value)
            {
                return $"Target {target.ToString(CultureInfo.InvariantCulture)} is below SL {status.NegativeSoftwareLimit.Value.ToString(CultureInfo.InvariantCulture)}.";
            }

            if (status.PositiveSoftwareLimit.HasValue && target > status.PositiveSoftwareLimit.Value)
            {
                return $"Target {target.ToString(CultureInfo.InvariantCulture)} is above SR {status.PositiveSoftwareLimit.Value.ToString(CultureInfo.InvariantCulture)}.";
            }
        }

        if (command is EN_ATTENUATOR_COMMAND.SetHomeType or EN_ATTENUATOR_COMMAND.SetIGain or EN_ATTENUATOR_COMMAND.SetPGain or EN_ATTENUATOR_COMMAND.SetInterpolationFactor &&
            state is not ("NOT_REFERENCED" or "CONFIGURATION" or "DISABLE"))
        {
            return $"HT/KI/KP/IF cannot be set in {state} state.";
        }

        if (command == EN_ATTENUATOR_COMMAND.SetNegativeSoftwareLimit)
        {
            if (state is not ("CONFIGURATION" or "DISABLE" or "READY"))
            {
                return $"SL cannot be set in {state} state.";
            }

            if (parameter > status.TargetPosition || status.PositiveSoftwareLimit.HasValue && parameter > status.PositiveSoftwareLimit.Value)
            {
                return "SL must be less than or equal to the current target and SR.";
            }
        }

        if (command == EN_ATTENUATOR_COMMAND.SetPositiveSoftwareLimit)
        {
            if (state is not ("CONFIGURATION" or "DISABLE" or "READY"))
            {
                return $"SR cannot be set in {state} state.";
            }

            if (parameter < status.TargetPosition || status.NegativeSoftwareLimit.HasValue && parameter < status.NegativeSoftwareLimit.Value)
            {
                return "SR must be greater than or equal to the current target and SL.";
            }
        }

        if (command == EN_ATTENUATOR_COMMAND.Stop && state is not ("HOMING" or "MOVING"))
        {
            return $"ST is allowed only while HOMING or MOVING. Current={state}";
        }

        return "";
    }

    public ST_BET_STATUS GetBETStatus(CancellationToken cancellationToken = default)
    {
        var interfaceData = GetBETInterfaceData();
        return GetBETStatus(interfaceData?.Number ?? 0, cancellationToken);
    }

    public ST_BET_STATUS GetBETStatus(int number, CancellationToken cancellationToken = default)
    {
        if (!IsInterfaceSimulation(GetBETInterfaceData(number)))
        {
            RefreshBETStatus(number, cancellationToken);
        }

        return GetBETStatusValue(number);
    }

    public async Task<ST_DEVICE_COMMAND_RESULT> ExecuteBETCommand(EN_BET_COMMAND command, double parameter1 = 0.0, double parameter2 = 0.0, CancellationToken cancellationToken = default)
    {
        var interfaceData = GetBETInterfaceData();
        return interfaceData is null ? new ST_DEVICE_COMMAND_RESULT(false, "BeamExpander interface is not registered.") : await ExecuteBETCommand(interfaceData.Number, command, parameter1, parameter2, cancellationToken);
    }

    public async Task<ST_DEVICE_COMMAND_RESULT> ExecuteBETCommand(int number, EN_BET_COMMAND command, double parameter1 = 0.0, double parameter2 = 0.0, CancellationToken cancellationToken = default, bool suppressCommandLog = false)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (command == EN_BET_COMMAND.Refresh)
        {
            var status = RefreshBETStatus(number, cancellationToken, suppressCommandLog);
            return new ST_DEVICE_COMMAND_RESULT(true, $"BET refreshed. MAG {status.CurrentMagnification:F3}, DIV {status.CurrentDivergence:F3}.");
        }

        if (command == EN_BET_COMMAND.MoveTable)
        {
            var table = await LoadBETData(cancellationToken);
            var index = (int)Math.Round(parameter1);
            bool MatchesItem(global::Drilling.Common.Interface.ST_BET_TABLE_DATA item)
            {
                return item.Index == index;
            }

            var row = table.FirstOrDefault(MatchesItem);
            if (row is null)
            {
                return new ST_DEVICE_COMMAND_RESULT(false, $"BET table row was not found: {index}");
            }

            return await ExecuteBETCommand(number, EN_BET_COMMAND.MoveManual, row.Magnification, row.Divergence, cancellationToken);
        }

        var commandText = CBeamExpander.Build(command, parameter1, parameter2);
        var logCommandText = CBeamExpander.BuildLogText(command, parameter1, parameter2);
        if (string.IsNullOrWhiteSpace(commandText))
        {
            return new ST_DEVICE_COMMAND_RESULT(false, $"BeamExpander command is not defined: {command}");
        }

        var interfaceData = GetBETInterfaceData(number);
        if (interfaceData is null)
        {
            return new ST_DEVICE_COMMAND_RESULT(false, $"BeamExpander interface is not registered: {FormatDeviceName(EN_EQP_MODULE.Bet, number)}");
        }

        if (IsInterfaceSimulation(interfaceData))
        {
            var status = CBeamExpander.Apply(command, parameter1, parameter2, "", GetBETStatusValue(number), simulation: true);
            SetBETStatus(number, status);
            if (!suppressCommandLog)
            {
                WriteInterfaceCommandLog(interfaceData, logCommandText, "SIMULATION OK");
            }

            return new ST_DEVICE_COMMAND_RESULT(true, $"SIM:BEAM_EXPENDER:{number}:{command}:OK");
        }

        if (!IsConnect(interfaceData.Device, interfaceData.Number))
        {
            await AutoReconnectDevice(interfaceData.Device, interfaceData.Number, cancellationToken);
        }

        if (!IsConnect(interfaceData.Device, interfaceData.Number))
        {
            SetBETStatus(number, GetBETStatusValue(number)with { CommOk = false, LastError = EN_BET_ERROR.Timeout, UpdatedAt = DateTimeOffset.Now });
            if (!suppressCommandLog)
            {
                WriteInterfaceErrorLog(interfaceData, logCommandText, "OFFLINE");
            }

            return new ST_DEVICE_COMMAND_RESULT(false, $"BeamExpander interface is offline: {FormatDeviceName(interfaceData)}");
        }

        var response = suppressCommandLog ? await ExecuteFunctionNoLog(interfaceData.Device, interfaceData.Number, commandText, cancellationToken) : await ExecuteFunction(interfaceData.Device, interfaceData.Number, commandText, cancellationToken);
        var updatedStatus = CBeamExpander.Apply(command, parameter1, parameter2, response, GetBETStatusValue(number), simulation: false);
        cancellationToken.ThrowIfCancellationRequested();
        SetBETStatus(number, updatedStatus);
        return CBeamExpander.IsSuccessResponse(response) ? new ST_DEVICE_COMMAND_RESULT(true, response) : new ST_DEVICE_COMMAND_RESULT(false, $"BeamExpander command failed. Command={logCommandText}, Response={response}");
    }

    public ST_BET_STATUS RefreshBETStatus(CancellationToken cancellationToken = default)
    {
        var interfaceData = GetBETInterfaceData();
        return interfaceData is null ? CreateDefaultBETStatus() : RefreshBETStatus(interfaceData.Number, cancellationToken);
    }

    public ST_BET_STATUS RefreshBETStatus(int number, CancellationToken cancellationToken = default)
    {
        return RefreshBETStatus(number, cancellationToken, suppressCommandLog: false);
    }

    public ST_BET_STATUS RefreshBETStatus(int number, CancellationToken cancellationToken, bool suppressCommandLog)
        => RefreshBETStatusAsync(number, cancellationToken, suppressCommandLog).GetAwaiter().GetResult();

    public async Task<ST_BET_STATUS> RefreshBETStatusAsync(int number, CancellationToken cancellationToken, bool suppressCommandLog)
    {
        var interfaceData = GetBETInterfaceData(number);
        if (IsInterfaceSimulation(interfaceData))
        {
            return GetBETStatusValue(number);
        }

        EN_BET_COMMAND[] commands = [EN_BET_COMMAND.PollMagnificationPosition, EN_BET_COMMAND.PollDivergencePosition];
        foreach (var command in commands)
        {
            var result = await ExecuteBETCommand(number, command, cancellationToken: cancellationToken, suppressCommandLog: suppressCommandLog).ConfigureAwait(false);
            if (!result.IsSuccess)
            {
                return GetBETStatusValue(number);
            }
        }

        return GetBETStatusValue(number);
    }

    public Task<IReadOnlyList<ST_BET_TABLE_DATA>> LoadBETData(CancellationToken cancellationToken = default)
    {
        return _betFile is null ? Task.FromResult<IReadOnlyList<ST_BET_TABLE_DATA>>(CreateDefaultBETData()) : _betFile.Load(cancellationToken);
    }

    public Task SaveBETData(IReadOnlyList<ST_BET_TABLE_DATA> table, CancellationToken cancellationToken = default)
    {
        return _betFile is null ? Task.CompletedTask : _betFile.Save(table, cancellationToken);
    }

    public ST_POWER_METER_STATUS GetPowerMeterStatus(CancellationToken cancellationToken = default)
    {
        var interfaceData = GetPowerMeterInterfaceData();
        return GetPowerMeterStatus(interfaceData?.Number ?? 0, cancellationToken);
    }

    public ST_POWER_METER_STATUS GetPowerMeterStatus(int number, CancellationToken cancellationToken = default)
    {
        return GetPowerMeterStatusValue(number);
    }

    public void SetPowerMeterSimulationAttenuator(int powerMeterNumber, int attenuatorNumber)
    {
        if (powerMeterNumber < 0 || attenuatorNumber < 0)
        {
            return;
        }

        _powerMeterSimulationAttenuators[powerMeterNumber] = attenuatorNumber;
    }

    public async Task<ST_DEVICE_COMMAND_RESULT> ExecutePowerMeterCommand(EN_POWER_METER_COMMAND command, double parameter = 0.0, CancellationToken cancellationToken = default)
    {
        var interfaceData = GetPowerMeterInterfaceData();
        return interfaceData is null ? new ST_DEVICE_COMMAND_RESULT(false, "PowerMeter interface is not registered.") : await ExecutePowerMeterCommand(interfaceData.Number, command, parameter, cancellationToken);
    }

    public async Task<ST_DEVICE_COMMAND_RESULT> ExecutePowerMeterCommand(int number, EN_POWER_METER_COMMAND command, double parameter = 0.0, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (command == EN_POWER_METER_COMMAND.Refresh)
        {
            var status = GetPowerMeterStatus(number, cancellationToken);
            return new ST_DEVICE_COMMAND_RESULT(true, $"PowerMeter refreshed. Power {status.MeasuredPower.ToString("F4", CultureInfo.InvariantCulture)} {status.Unit}.");
        }

        var commandText = CPowerMeter.Build(command, parameter);
        if (string.IsNullOrWhiteSpace(commandText))
        {
            return new ST_DEVICE_COMMAND_RESULT(false, $"PowerMeter command is not defined: {command}");
        }

        var interfaceData = GetPowerMeterInterfaceData(number);
        if (interfaceData is null)
        {
            return new ST_DEVICE_COMMAND_RESULT(false, $"PowerMeter interface is not registered: {FormatDeviceName(EN_EQP_MODULE.PowerMeter, number)}");
        }

        if (IsInterfaceSimulation(interfaceData))
        {
            var simulationPower = command == EN_POWER_METER_COMMAND.ReadPower ? CreatePowerMeterSimulationPower(number) : null;
            var status = CPowerMeter.Apply(command, parameter, "", GetPowerMeterStatusValue(number), simulation: true, simulationPower: simulationPower);
            SetPowerMeterStatus(number, status);
            WriteInterfaceCommandLog(interfaceData, commandText, "SIMULATION OK");
            return new ST_DEVICE_COMMAND_RESULT(true, $"SIM:POWER_METER:{number}:{command}:OK");
        }

        if (!IsConnect(interfaceData.Device, interfaceData.Number))
        {
            await AutoReconnectDevice(interfaceData.Device, interfaceData.Number, cancellationToken);
        }

        if (!IsConnect(interfaceData.Device, interfaceData.Number))
        {
            SetPowerMeterStatus(number, GetPowerMeterStatusValue(number)with { LastError = EN_POWER_METER_ERROR.Timeout, MeasuredAt = DateTimeOffset.Now });
            WriteInterfaceErrorLog(interfaceData, commandText, "OFFLINE");
            return new ST_DEVICE_COMMAND_RESULT(false, $"PowerMeter interface is offline: {FormatDeviceName(interfaceData)}");
        }

        var response = await ExecuteFunction(interfaceData.Device, interfaceData.Number, commandText, cancellationToken);
        var updatedStatus = CPowerMeter.Apply(command, parameter, response, GetPowerMeterStatusValue(number), simulation: false);
        SetPowerMeterStatus(number, updatedStatus);
        return CPowerMeter.IsSuccessResponse(response) ? new ST_DEVICE_COMMAND_RESULT(true, response) : new ST_DEVICE_COMMAND_RESULT(false, $"PowerMeter command failed. Command={commandText}, Response={response}");
    }

    public ST_POWER_METER_STATUS RefreshPowerMeterStatus(CancellationToken cancellationToken = default)
    {
        var interfaceData = GetPowerMeterInterfaceData();
        return interfaceData is null ? ST_POWER_METER_STATUS.Empty : RefreshPowerMeterStatus(interfaceData.Number, cancellationToken);
    }

    public ST_POWER_METER_STATUS RefreshPowerMeterStatus(int number, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return GetPowerMeterStatusValue(number);
    }

    public ST_PICO_MOTOR_STATUS GetPicoMotorStatus(CancellationToken cancellationToken = default)
    {
        int SelectNumber(global::Drilling.Common.Interface.ST_INTERFACE_DATA item)
        {
            return item.Number;
        }

        var data = GetInterfaceList(EN_EQP_MODULE.PicoMotor).OrderBy(SelectNumber).FirstOrDefault();
        if (data is null)
        {
            return ST_PICO_MOTOR_STATUS.Empty with
            {
                CommOk = false,
                LastError = EN_PICO_MOTOR_ERROR.NotSupported,
                UpdatedAt = DateTimeOffset.Now
            };
        }

        return GetPicoMotorStatus(data.Number, cancellationToken);
    }

    public ST_PICO_MOTOR_STATUS GetPicoMotorStatus(int number, CancellationToken cancellationToken = default)
    {
        bool MatchesItem(global::Drilling.Common.Interface.ST_INTERFACE_DATA item)
        {
            return item.Number == number;
        }

        var data = GetInterfaceList(EN_EQP_MODULE.PicoMotor).FirstOrDefault(MatchesItem);
        if (data is null)
        {
            return ST_PICO_MOTOR_STATUS.Empty with
            {
                CommOk = false,
                LastError = EN_PICO_MOTOR_ERROR.NotSupported,
                UpdatedAt = DateTimeOffset.Now
            };
        }

        try
        {
            return _picoMotorService.Refresh(data.Number, IsInterfaceSimulation(data), cancellationToken).GetAwaiter().GetResult();
        }
        catch
        {
            return _picoMotorService.GetStatus(data.Number)with
            {
                CommOk = false,
                LastError = EN_PICO_MOTOR_ERROR.Timeout,
                UpdatedAt = DateTimeOffset.Now
            };
        }
    }

    public ST_PICO_MOTOR_STATUS RefreshPicoMotorStatus(CancellationToken cancellationToken = default)
    {
        return GetPicoMotorStatus(cancellationToken);
    }

    public ST_PICO_MOTOR_STATUS RefreshPicoMotorStatus(int number, CancellationToken cancellationToken = default)
    {
        return GetPicoMotorStatus(number, cancellationToken);
    }

    public async Task<ST_DEVICE_COMMAND_RESULT> ExecutePicoMotorCommand(EN_PICO_MOTOR_COMMAND command, int motorNo = 1, double parameter = 0.0, CancellationToken cancellationToken = default)
    {
        int SelectNumber(global::Drilling.Common.Interface.ST_INTERFACE_DATA item)
        {
            return item.Number;
        }

        var data = GetInterfaceList(EN_EQP_MODULE.PicoMotor).OrderBy(SelectNumber).FirstOrDefault();
        if (data is null)
        {
            return new ST_DEVICE_COMMAND_RESULT(false, "PicoMotor interface is not registered.");
        }

        return await ExecutePicoMotorCommand(data.Number, command, motorNo, parameter, cancellationToken);
    }

    public async Task<ST_DEVICE_COMMAND_RESULT> ExecutePicoMotorCommand(int number, EN_PICO_MOTOR_COMMAND command, int motorNo = 1, double parameter = 0.0, CancellationToken cancellationToken = default)
    {
        bool MatchesItem(global::Drilling.Common.Interface.ST_INTERFACE_DATA item)
        {
            return item.Number == number;
        }

        var data = GetInterfaceList(EN_EQP_MODULE.PicoMotor).FirstOrDefault(MatchesItem);
        if (data is null)
        {
            return new ST_DEVICE_COMMAND_RESULT(false, $"PicoMotor interface {number} is not registered.");
        }

        var result = await _picoMotorService.Execute(data.Number, IsInterfaceSimulation(data), command, motorNo, parameter, cancellationToken);
        var commandText = $"{command}:MOTOR={motorNo}:VALUE={parameter.ToString("0.######", CultureInfo.InvariantCulture)}";
        if (result.IsSuccess)
        {
            WriteInterfaceCommandLog(data, commandText, result.Message);
        }
        else
        {
            WriteInterfaceErrorLog(data, commandText, result.Message);
        }

        return result;
    }

    public async Task<ST_DEVICE_COMMAND_RESULT> ExecutePicoMotorAllMove(IReadOnlyCollection<int> motorNos, double positionMm, int count, CancellationToken cancellationToken = default)
    {
        int SelectNumber(global::Drilling.Common.Interface.ST_INTERFACE_DATA item)
        {
            return item.Number;
        }

        var data = GetInterfaceList(EN_EQP_MODULE.PicoMotor).OrderBy(SelectNumber).FirstOrDefault();
        if (data is null)
        {
            return new ST_DEVICE_COMMAND_RESULT(false, "PicoMotor interface is not registered.");
        }

        return await ExecutePicoMotorAllMove(data.Number, motorNos, positionMm, count, cancellationToken);
    }

    public async Task<ST_DEVICE_COMMAND_RESULT> ExecutePicoMotorAllMove(int number, IReadOnlyCollection<int> motorNos, double positionMm, int count, CancellationToken cancellationToken = default)
    {
        bool MatchesItem(global::Drilling.Common.Interface.ST_INTERFACE_DATA item)
        {
            return item.Number == number;
        }

        var data = GetInterfaceList(EN_EQP_MODULE.PicoMotor).FirstOrDefault(MatchesItem);
        if (data is null)
        {
            return new ST_DEVICE_COMMAND_RESULT(false, $"PicoMotor interface {number} is not registered.");
        }

        var result = await _picoMotorService.ExecuteAllMove(data.Number, IsInterfaceSimulation(data), motorNos, positionMm, count, cancellationToken);
        var commandText = $"ALL_MOVE:MOTOR={string.Join(",", motorNos)}:DIST={positionMm.ToString("0.######", CultureInfo.InvariantCulture)}:COUNT={count}";
        if (result.IsSuccess)
        {
            WriteInterfaceCommandLog(data, commandText, result.Message);
        }
        else
        {
            WriteInterfaceErrorLog(data, commandText, result.Message);
        }

        return result;
    }

    private void SetSimulLaserHead(int number, int headNo, bool enabled)
    {
        var laserOnHeads = GetLaserOnHeads(number);
        if (enabled)
        {
            laserOnHeads.Add(headNo);
        }
        else
        {
            laserOnHeads.Remove(headNo);
        }
    }

    private HashSet<int> GetLaserOnHeads(int number)
    {
        if (!_laserOnHeads.TryGetValue(number, out var heads))
        {
            heads = [];
            _laserOnHeads[number] = heads;
        }

        return heads;
    }

    private ST_TALON_STATUS GetTalonStatus(int number)
    {
        return _talonStatuses.GetOrAdd(number, _ => ST_TALON_STATUS.Empty);
    }

    private void SetTalonStatus(int number, ST_TALON_STATUS status)
    {
        _talonStatuses[number] = status;
    }

    private ST_ATTENUATOR_STATUS GetAttenuatorStatusValue(int number)
    {
        lock (_attenuatorStatusLock)
        {
            if (!_attenuatorStatuses.TryGetValue(number, out var status))
            {
                status = CreateDefaultAttenuatorStatus();
                _attenuatorStatuses[number] = status;
            }
            return status;
        }
    }

    private void SetAttenuatorStatus(int number, ST_ATTENUATOR_STATUS status)
    {
        lock (_attenuatorStatusLock) _attenuatorStatuses[number] = status;
    }

    private ST_BET_STATUS GetBETStatusValue(int number)
    {
        return _betStatuses.GetOrAdd(number, _ => CreateDefaultBETStatus());
    }

    private void SetBETStatus(int number, ST_BET_STATUS status)
    {
        _betStatuses[number] = status;
    }

    private ST_POWER_METER_STATUS GetPowerMeterStatusValue(int number)
    {
        return _powerMeterStatuses.GetOrAdd(number, _ => ST_POWER_METER_STATUS.Empty);
    }

    private void SetPowerMeterStatus(int number, ST_POWER_METER_STATUS status)
    {
        _powerMeterStatuses[number] = status;
    }

    private double? CreatePowerMeterSimulationPower(int powerMeterNumber)
    {
        if (!_powerMeterSimulationAttenuators.TryGetValue(powerMeterNumber, out var attenuatorNumber))
        {
            var attenuatorData = GetAttenuatorInterfaceData();
            if (attenuatorData is null)
            {
                return null;
            }

            attenuatorNumber = attenuatorData.Number;
        }

        if (GetAttenuatorInterfaceData(attenuatorNumber) is null)
        {
            return null;
        }

        var attenuatorStatus = GetAttenuatorStatusValue(attenuatorNumber);
        var normalizedAttenuator = NormalizePowerMeterSimulationAttenuator(attenuatorStatus.CurrentPosition) / 360.0;
        const double minimumPower = 0.05;
        const double maximumPower = 2.25;
        return Math.Round(minimumPower + ((maximumPower - minimumPower) * normalizedAttenuator), 4);
    }

    private static double NormalizePowerMeterSimulationAttenuator(double position)
    {
        if (!double.IsFinite(position))
        {
            return 0.0;
        }

        return Math.Clamp(position, 0.0, 360.0);
    }

    private void PruneDeviceStateMaps()
    {
        PruneDeviceStateMap(_laserOnHeads, EN_EQP_MODULE.TalonLaser);
        PruneDeviceStateMap(_talonStatuses, EN_EQP_MODULE.TalonLaser);
        lock (_attenuatorStatusLock) PruneDeviceStateMap(_attenuatorStatuses, EN_EQP_MODULE.Attenuator);
        PruneDeviceStateMap(_betStatuses, EN_EQP_MODULE.Bet);
        PruneDeviceStateMap(_powerMeterStatuses, EN_EQP_MODULE.PowerMeter);
        PruneDeviceStateMap(_powerMeterSimulationAttenuators, EN_EQP_MODULE.PowerMeter);
    }

    private void ClearDeviceStateMaps()
    {
        _laserOnHeads.Clear();
        _talonStatuses.Clear();
        lock (_attenuatorStatusLock) _attenuatorStatuses.Clear();
        _betStatuses.Clear();
        _powerMeterStatuses.Clear();
        _powerMeterSimulationAttenuators.Clear();
    }

    private void PruneDeviceStateMap<T>(IDictionary<int, T> statusMap, EN_EQP_MODULE module)
    {
        int SelectNumber(global::Drilling.Common.Interface.ST_INTERFACE_DATA data)
        {
            return data.Number;
        }

        var validNumbers = GetInterfaceList(module).Select(SelectNumber).ToHashSet();
        bool ShouldIncludeItem(int number)
        {
            return !validNumbers.Contains(number);
        }

        foreach (var number in statusMap.Keys.Where(ShouldIncludeItem).ToArray())
        {
            statusMap.Remove(number);
        }
    }

    private ST_INTERFACE_DATA? GetTalonInterfaceData()
    {
        int SelectNumber(global::Drilling.Common.Interface.ST_INTERFACE_DATA data)
        {
            return data.Number;
        }

        string SelectNickName(global::Drilling.Common.Interface.ST_INTERFACE_DATA data)
        {
            return data.NickName;
        }

        return GetInterfaceList(EN_EQP_MODULE.TalonLaser).OrderBy(SelectNumber).ThenBy(SelectNickName, StringComparer.OrdinalIgnoreCase).FirstOrDefault();
    }

    private ST_INTERFACE_DATA? GetTalonInterfaceData(int number)
    {
        return GetInterfaceData(EN_EQP_MODULE.TalonLaser, number);
    }

    private ST_INTERFACE_DATA? GetAttenuatorInterfaceData()
    {
        int SelectNumber(global::Drilling.Common.Interface.ST_INTERFACE_DATA data)
        {
            return data.Number;
        }

        string SelectNickName(global::Drilling.Common.Interface.ST_INTERFACE_DATA data)
        {
            return data.NickName;
        }

        return GetInterfaceList(EN_EQP_MODULE.Attenuator).OrderBy(SelectNumber).ThenBy(SelectNickName, StringComparer.OrdinalIgnoreCase).FirstOrDefault();
    }

    private ST_INTERFACE_DATA? GetAttenuatorInterfaceData(int number)
    {
        return GetInterfaceData(EN_EQP_MODULE.Attenuator, number);
    }

    private ST_INTERFACE_DATA? GetBETInterfaceData()
    {
        int SelectNumber(global::Drilling.Common.Interface.ST_INTERFACE_DATA data)
        {
            return data.Number;
        }

        string SelectNickName(global::Drilling.Common.Interface.ST_INTERFACE_DATA data)
        {
            return data.NickName;
        }

        return GetInterfaceList(EN_EQP_MODULE.Bet).OrderBy(SelectNumber).ThenBy(SelectNickName, StringComparer.OrdinalIgnoreCase).FirstOrDefault();
    }

    private ST_INTERFACE_DATA? GetBETInterfaceData(int number)
    {
        return GetInterfaceData(EN_EQP_MODULE.Bet, number);
    }

    private ST_INTERFACE_DATA? GetPowerMeterInterfaceData()
    {
        int SelectNumber(global::Drilling.Common.Interface.ST_INTERFACE_DATA data)
        {
            return data.Number;
        }

        string SelectNickName(global::Drilling.Common.Interface.ST_INTERFACE_DATA data)
        {
            return data.NickName;
        }

        return GetInterfaceList(EN_EQP_MODULE.PowerMeter)
            .OrderBy(IsInterfaceSimulation)
            .ThenBy(SelectNumber)
            .ThenBy(SelectNickName, StringComparer.OrdinalIgnoreCase)
            .FirstOrDefault();
    }

    private ST_INTERFACE_DATA? GetPowerMeterInterfaceData(int number)
    {
        return GetInterfaceData(EN_EQP_MODULE.PowerMeter, number);
    }

    private bool IsInterfaceSimulation(ST_INTERFACE_DATA? interfaceData)
    {
        return interfaceData is null || IsSimul(interfaceData.Device, interfaceData.Number);
    }

    private static ST_ATTENUATOR_STATUS CreateDefaultAttenuatorStatus()
    {
        return new ST_ATTENUATOR_STATUS(55.0, 55.0, "READY");
    }

    private static ST_BET_STATUS CreateDefaultBETStatus()
    {
        return new ST_BET_STATUS(1020.000, 1020.000, 1626.000, 1626.000, 1020.000, 1626.000, false, true, true, false);
    }

    private static IReadOnlyList<ST_BET_TABLE_DATA> CreateDefaultBETData()
    {
        return[new(0, 1020, 1626, "2times"), new(1, 2351, 1118, "3times"), new(2, 3014, 1278, "4times"), new(3, 3410, 1706, "5times"), new(4, 3673, 2267, "6times")];
    }

}

public sealed class CInterfaceDevice
{
    private bool _simulationMode;
    private readonly CCommBase _comm;
    private string _simulationLastSent = "";
    private string _simulationLastReceived = "";
    private string _simulationLastError = "";
    private DateTimeOffset? _simulationLastChangedAt;
    private bool _externalCommunication;
    private EN_COMM_STATE _externalConnectionState = EN_COMM_STATE.Offline;
    private string _externalLastSent = "";
    private string _externalLastReceived = "";
    private string _externalLastError = "";
    private DateTimeOffset? _externalLastChangedAt;
    internal event Func<CInterfaceDevice, ST_COMM_RECEIVED_MESSAGE, CancellationToken, Task<string>>? MessageReceived;
    internal event Action<CInterfaceDevice, ST_COMM_PROTOCOL_TRACE>? ProtocolTrace;
    public CInterfaceDevice(ST_INTERFACE_DATA data, bool simulationMode)
    {
        Data = data;
        ConnectOption = CInterfaceConnectOption.Parse(data);
        _simulationMode = simulationMode;
        _comm = CComm.Create(Data, ConnectOption);
        if (_comm is CSocketServerComm messageSource)
        {
            messageSource.MessageReceived += OnCommMessageReceived;
        }

        if (_comm is CVisionComm visionComm)
        {
            visionComm.ProtocolTrace += OnCommProtocolTrace;
        }

        if (_simulationMode)
        {
            TouchSimulationState();
        }
    }

    public ST_INTERFACE_DATA Data { get; }
    public ST_INTERFACE_CONNECT_OPTION ConnectOption { get; }

    public EN_COMM_STATE ConnectionState
    {
        get
        {
            return _externalCommunication ? _externalConnectionState : _simulationMode ? EN_COMM_STATE.Simulation : _comm.ConnectionState;
        }
    }

    public bool IsSimulation
    {
        get
        {
            return _simulationMode;
        }
    }

    public ST_INTERFACE_COMM_STATUS GetCommunicationStatus()
    {
        if (_externalCommunication)
        {
            return new ST_INTERFACE_COMM_STATUS(Data.Device, Data.NickName, Data.InterfaceType, Data.Number, Data.AutoConnection, _externalConnectionState, _simulationMode, ConnectOption.Endpoint, _externalLastSent, _externalLastReceived, _externalLastError, _externalLastChangedAt);
        }

        return new ST_INTERFACE_COMM_STATUS(Data.Device, Data.NickName, Data.InterfaceType, Data.Number, Data.AutoConnection, ConnectionState, _simulationMode, _comm.Endpoint, _simulationMode ? _simulationLastSent : _comm.LastSent, _simulationMode ? _simulationLastReceived : _comm.LastReceived, _simulationMode ? _simulationLastError : _comm.LastError, _simulationMode ? _simulationLastChangedAt : _comm.LastChangedAt);
    }

    public async Task SetSimulationMode(bool enabled, CancellationToken cancellationToken = default)
    {
        if (_simulationMode == enabled)
        {
            return;
        }

        _simulationMode = enabled;
        if (_externalCommunication)
        {
            _externalConnectionState = enabled ? EN_COMM_STATE.Simulation : EN_COMM_STATE.Offline;
            _externalLastError = "";
            _externalLastChangedAt = DateTimeOffset.Now;
            return;
        }

        if (_simulationMode)
        {
            await _comm.Disconnect(cancellationToken);
            TouchSimulationState();
        }
    }

    public Task Connect(CancellationToken cancellationToken = default)
    {
        if (_externalCommunication)
        {
            cancellationToken.ThrowIfCancellationRequested();
            _externalConnectionState = _simulationMode ? EN_COMM_STATE.Simulation : EN_COMM_STATE.Offline;
            _externalLastChangedAt = DateTimeOffset.Now;
            return Task.CompletedTask;
        }

        if (_simulationMode)
        {
            cancellationToken.ThrowIfCancellationRequested();
            _simulationLastError = "";
            TouchSimulationState();
            return Task.CompletedTask;
        }

        return _comm.Connect(cancellationToken);
    }

    public void ResetAutoReconnectPolicy()
    {
        _comm.ResetAutoReconnectPolicy();
    }

    public void SuppressAutoReconnect()
    {
        _comm.SuppressAutoReconnect();
    }

    public Task Disconnect(CancellationToken cancellationToken = default)
    {
        if (_externalCommunication)
        {
            cancellationToken.ThrowIfCancellationRequested();
            _externalConnectionState = EN_COMM_STATE.Offline;
            _externalLastChangedAt = DateTimeOffset.Now;
            return Task.CompletedTask;
        }

        if (_simulationMode)
        {
            cancellationToken.ThrowIfCancellationRequested();
            TouchSimulationState();
            return Task.CompletedTask;
        }

        return _comm.Disconnect(cancellationToken);
    }

    public Task<string> ExecuteFunction(string function, CancellationToken cancellationToken = default)
    {
        if (_externalCommunication)
        {
            throw new InvalidOperationException("MELSEC commands must use CMelsec typed read/write functions.");
        }

        if (_simulationMode)
        {
            cancellationToken.ThrowIfCancellationRequested();
            _simulationLastSent = function;
            _simulationLastReceived = $"SIM:{Data.NickName}:{function}:OK";
            _simulationLastError = "";
            TouchSimulationState();
            return Task.FromResult(_simulationLastReceived);
        }

        return _comm.Execute(function, cancellationToken);
    }

    internal void EnableExternalCommunication()
    {
        _externalCommunication = true;
        _externalConnectionState = _simulationMode ? EN_COMM_STATE.Simulation : EN_COMM_STATE.Offline;
        _externalLastChangedAt = DateTimeOffset.Now;
    }

    internal void SetExternalCommunicationState(EN_COMM_STATE state, string lastSent, string lastReceived, string lastError)
    {
        _externalConnectionState = state;
        _externalLastSent = lastSent;
        _externalLastReceived = lastReceived;
        _externalLastError = lastError;
        _externalLastChangedAt = DateTimeOffset.Now;
    }

    private void TouchSimulationState()
    {
        _simulationLastChangedAt = DateTimeOffset.Now;
    }

    private async Task<string> OnCommMessageReceived(ST_COMM_RECEIVED_MESSAGE message, CancellationToken cancellationToken)
    {
        var handler = MessageReceived;
        if (handler is null)
        {
            return "ACK";
        }

        var response = "ACK";
        foreach (var callback in handler.GetInvocationList().Cast<Func<CInterfaceDevice, ST_COMM_RECEIVED_MESSAGE, CancellationToken, Task<string>>>())
        {
            var callbackResponse = await callback(this, message, cancellationToken);
            if (!string.IsNullOrWhiteSpace(callbackResponse))
            {
                response = callbackResponse;
            }
        }

        return string.IsNullOrWhiteSpace(response) ? "ACK" : response;
    }

    private void OnCommProtocolTrace(ST_COMM_PROTOCOL_TRACE trace)
    {
        ProtocolTrace?.Invoke(this, trace);
    }
}

internal static class CInterfaceConnectOption
{
    public static ST_INTERFACE_CONNECT_OPTION Parse(ST_INTERFACE_DATA data)
    {
        string SelectItem(string argument)
        {
            return argument.Trim();
        }

        var args = data.Arguments.Select(SelectItem).Concat(Enumerable.Repeat("", 5)).Take(5).ToArray();
        return data.InterfaceType switch
        {
            EN_INTERFACE_TYPE.Serial or EN_INTERFACE_TYPE.ModbusSerial => CreateSerialOption(data, args),
            EN_INTERFACE_TYPE.SocketClient or EN_INTERFACE_TYPE.SocketServer or EN_INTERFACE_TYPE.SocketClientUdp or EN_INTERFACE_TYPE.SocketServerUdp or EN_INTERFACE_TYPE.ModbusTcp => CreateSocketOption(data, args),
            EN_INTERFACE_TYPE.AcsNet => CreateAcsOption(args),
            EN_INTERFACE_TYPE.XpsNet => CreateXpsOption(args),
            EN_INTERFACE_TYPE.Automation1Net => CreateAutomation1Option(args),
            EN_INTERFACE_TYPE.PicoMotor => CreatePicoMotorOption(),
            EN_INTERFACE_TYPE.MelsecNet => CreateMelsecNetOption(args),
            EN_INTERFACE_TYPE.OpcUa => CreateOpcUaOption(args),
            _ => CreateSocketOption(data, args)};
    }

    private static ST_INTERFACE_CONNECT_OPTION CreateSocketOption(ST_INTERFACE_DATA data, IReadOnlyList<string> args)
    {
        var isServer = data.InterfaceType is EN_INTERFACE_TYPE.SocketServer or EN_INTERFACE_TYPE.SocketServerUdp;
        var localAddress = DefaultIfBlank(args[0], "0.0.0.0");
        var remoteAddress = DefaultIfBlank(args[1], isServer ? "*" : "127.0.0.1");
        var port = ReadInt(args[2], 0);
        var timeoutMs = ReadInt(args[3], 3000);
        var retryCount = ReadInt(args[4], 1);
        var maxClientCount = Math.Max(1, ReadInt(ReadExtra(data, "MAX_CLIENT_COUNT"), 8));
        var endpointAddress = isServer ? localAddress : remoteAddress;
        var endpoint = port > 0 ? $"{endpointAddress}:{port}" : endpointAddress;
        return new ST_INTERFACE_CONNECT_OPTION(endpoint, localAddress, remoteAddress, port, timeoutMs, retryCount, "", 0, "", 0, "", "", maxClientCount);
    }

    private static ST_INTERFACE_CONNECT_OPTION CreateAcsOption(IReadOnlyList<string> args)
    {
        var localAddress = DefaultIfBlank(args[0], "0.0.0.0");
        var remoteAddress = DefaultIfBlank(args[1], "127.0.0.1");
        var port = ReadInt(args[2], 701);
        var timeoutMs = ReadInt(args[3], 3000);
        var retryCount = ReadInt(args[4], 1);
        return new ST_INTERFACE_CONNECT_OPTION($"{remoteAddress}:{port}", localAddress, remoteAddress, port, timeoutMs, retryCount, "", 0, "", 0, "", "");
    }

    private static ST_INTERFACE_CONNECT_OPTION CreateXpsOption(IReadOnlyList<string> args)
    {
        var localAddress = DefaultIfBlank(args[0], "0.0.0.0");
        var remoteAddress = DefaultIfBlank(args[1], "192.168.254.254");
        var port = ReadInt(args[2], 5001);
        var timeoutMs = ReadInt(args[3], 3000);
        var retryCount = ReadInt(args[4], 1);
        return new ST_INTERFACE_CONNECT_OPTION($"{remoteAddress}:{port}", localAddress, remoteAddress, port, timeoutMs, retryCount, "", 0, "", 0, "", "");
    }

    private static ST_INTERFACE_CONNECT_OPTION CreateAutomation1Option(IReadOnlyList<string> args)
    {
        var localAddress = DefaultIfBlank(args[0], "0.0.0.0");
        var remoteAddress = DefaultIfBlank(args[1], "127.0.0.1");
        var port = ReadInt(args[2], 12200);
        var timeoutMs = ReadInt(args[3], 3000);
        var retryCount = ReadInt(args[4], 1);
        return new ST_INTERFACE_CONNECT_OPTION($"{remoteAddress}:{port}", localAddress, remoteAddress, port, timeoutMs, retryCount, "", 0, "", 0, "", "");
    }

    private static ST_INTERFACE_CONNECT_OPTION CreatePicoMotorOption()
    {
        return new ST_INTERFACE_CONNECT_OPTION("CmdLib (USB/Ethernet)", "", "", 0, 3000, 1, "", 0, "", 0, "", "");
    }

    private static ST_INTERFACE_CONNECT_OPTION CreateMelsecNetOption(IReadOnlyList<string> args)
    {
        var channel = DefaultIfBlank(args[0], "NOT_CONFIGURED");
        var network = DefaultIfBlank(args[1], "NOT_CONFIGURED");
        var station = DefaultIfBlank(args[2], "NOT_CONFIGURED");
        var timeoutMs = ReadInt(args[3], 3000);
        var retryCount = ReadInt(args[4], 1);
        var endpoint = "MELSECNET:CHANNEL=" + channel + ":NETWORK=" + network + ":STATION=" + station;
        return new ST_INTERFACE_CONNECT_OPTION(endpoint, "", "", 0, timeoutMs, retryCount, "", 0, "", 0, "", "");
    }

    private static ST_INTERFACE_CONNECT_OPTION CreateSerialOption(ST_INTERFACE_DATA data, IReadOnlyList<string> args)
    {
        var port = DefaultIfBlank(args[0], "COM1");
        var baudRate = ReadInt(args[1], 9600);
        var parity = DefaultIfBlank(args[2], "NONE");
        var dataBits = ReadInt(args[3], 8);
        var stopBits = DefaultIfBlank(args[4], "ONE");
        var handshake = ReadExtra(data, "FLOW_CONTROL");
        return new ST_INTERFACE_CONNECT_OPTION($"{port}:{baudRate}", "", "", 0, 3000, 1, port, baudRate, parity, dataBits, stopBits, handshake);
    }

    private static ST_INTERFACE_CONNECT_OPTION CreateOpcUaOption(IReadOnlyList<string> args)
    {
        var endpoint = DefaultIfBlank(args[0], "opc.tcp://127.0.0.1:4840");
        var timeoutMs = ReadInt(args[3], 3000);
        var retryCount = ReadInt(args[4], 1);
        return new ST_INTERFACE_CONNECT_OPTION(endpoint, "", endpoint, 0, timeoutMs, retryCount, "", 0, "", 0, "", "");
    }

    private static string ReadExtra(ST_INTERFACE_DATA data, params string[] names)
    {
        if (data.Extra is null)
        {
            return "";
        }

        foreach (var name in names)
        {
            if (data.Extra.TryGetValue(name, out var value) && !string.IsNullOrWhiteSpace(value))
            {
                return value.Trim();
            }
        }

        return "";
    }

    private static string DefaultIfBlank(string value, string defaultValue)
    {
        return string.IsNullOrWhiteSpace(value) ? defaultValue : value.Trim();
    }

    private static int ReadInt(string value, int defaultValue)
    {
        return int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var result) ? result : defaultValue;
    }
}
