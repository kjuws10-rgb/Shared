namespace Drilling.Common.Interface;

public sealed record ST_POWER_MEASURE_START(double? Angle, string Detail);

/// <summary>Calibration data for a single Head. Simulations must use a separate writable store.</summary>
public interface IPowerMeasureTable
{
    ST_POWER_MEASURE_START FindStart(int headNo, double targetPower, CancellationToken token);
    void SaveMeasurement(int headNo, double angle, double measuredPower, CancellationToken token);
}
