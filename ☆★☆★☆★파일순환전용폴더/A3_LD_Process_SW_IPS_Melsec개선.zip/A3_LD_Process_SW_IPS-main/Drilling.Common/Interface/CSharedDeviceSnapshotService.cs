namespace Drilling.Common.Interface;

public sealed record ST_SHARED_DEVICE_SNAPSHOT<T>(T? Value, string State, string Detail, DateTimeOffset UpdatedAt)
    where T : class;

/// <summary>Owns a single sequential transport reader; GetSnapshot never performs device I/O.</summary>
public sealed class CSharedDeviceSnapshotService<T> where T : class
{
    private readonly Func<CancellationToken, Task<T>> _read;
    private readonly TimeSpan _period;
    private readonly TimeSpan _timeout;
    private readonly TimeSpan _maximumAge;
    private readonly object _sync = new();
    private CancellationTokenSource? _stop;
    private Task? _worker;
    private Task<T>? _inflight;
    private bool _stopping;
    private long _generation;
    private long _collectedAt;
    private ST_SHARED_DEVICE_SNAPSHOT<T> _snapshot = new(null, "LOADING", "상태 수집을 기다리고 있습니다.", default);

    public CSharedDeviceSnapshotService(Func<CancellationToken, Task<T>> read,
        TimeSpan? period = null, TimeSpan? readTimeout = null, TimeSpan? maximumAge = null)
    {
        _read = read ?? throw new ArgumentNullException(nameof(read));
        _period = period ?? TimeSpan.FromSeconds(1);
        _timeout = readTimeout ?? TimeSpan.FromSeconds(2);
        _maximumAge = maximumAge ?? TimeSpan.FromSeconds(5);
        if (_period <= TimeSpan.Zero || _timeout <= TimeSpan.Zero || _maximumAge <= TimeSpan.Zero)
            throw new ArgumentOutOfRangeException(nameof(period));
    }

    public ST_SHARED_DEVICE_SNAPSHOT<T> GetSnapshot()
    {
        lock (_sync)
        {
            if (_snapshot.State == "OK" && Environment.TickCount64 - _collectedAt > _maximumAge.TotalMilliseconds)
                return _snapshot with { Value = null, State = "STALE", Detail = "최근 장치 상태를 수집하지 못했습니다." };
            return _snapshot;
        }
    }

    public void Start()
    {
        lock (_sync)
        {
            if (_stop is not null || _stopping) return;
            _stop = new CancellationTokenSource();
            var generation = ++_generation;
            _snapshot = new(null, "LOADING", "상태 수집을 기다리고 있습니다.", default);
            var token = _stop.Token;
            _worker = Task.Run(() => Collect(generation, token));
        }
    }

    public async Task StopAsync()
    {
        Task? worker;
        CancellationTokenSource? stop;
        lock (_sync)
        {
            _stopping = true;
            ++_generation;
            stop = _stop;
            stop?.Cancel();
            worker = _worker;
            _snapshot = new(null, "STOPPED", "상태 수집이 중지되었습니다.", default);
        }
        if (worker is not null) await worker.ConfigureAwait(false);
        lock (_sync)
        {
            if (ReferenceEquals(stop, _stop))
            {
                _stop = null;
                _worker = null;
                stop?.Dispose();
                _stopping = false;
            }
        }
    }

    private async Task Collect(long generation, CancellationToken token)
    {
        try
        {
            do
            {
                token.ThrowIfCancellationRequested();
                Task<T>? readTask;
                CancellationTokenSource? readStop = null;
                lock (_sync)
                {
                    if (generation != _generation) return;
                    if (_inflight is { IsCompleted: false })
                    {
                        // A cancelled/timed-out driver call is quarantined across cycles and restarts.
                        // Never issue a replacement while that same transport call is still running.
                        _snapshot = new(null, "BLOCKED", "이전 장치 조회가 끝나지 않아 재조회를 보류합니다.", default);
                        readTask = null;
                    }
                    else
                    {
                        readStop = CancellationTokenSource.CreateLinkedTokenSource(token);
                        readStop.CancelAfter(_timeout);
                        var readToken = readStop.Token;
                        _inflight = readTask = Task.Run(() => _read(readToken), CancellationToken.None);
                        var lifetime = readStop;
                        _ = readTask.ContinueWith(task => { _ = task.Exception; lifetime.Dispose(); },
                            CancellationToken.None, TaskContinuationOptions.ExecuteSynchronously, TaskScheduler.Default);
                    }
                }
                if (readTask is not null && readStop is not null)
                {
                    // A timeout releases this worker, but _inflight remains owned until the driver actually returns.
                    try
                    {
                        var value = await readTask.WaitAsync(_timeout, token).ConfigureAwait(false);
                        lock (_sync)
                        {
                            if (generation != _generation || token.IsCancellationRequested) return;
                            _collectedAt = Environment.TickCount64;
                            _snapshot = new(value, "OK", "", DateTimeOffset.Now);
                        }
                    }
                    catch (OperationCanceledException) when (token.IsCancellationRequested) { throw; }
                    catch (Exception exception)
                    {
                        lock (_sync)
                        {
                            if (generation != _generation) return;
                            _snapshot = new(null, exception is TimeoutException or OperationCanceledException ? "TIMEOUT" : "ERROR",
                                exception.Message, default);
                        }
                    }
                }
                await Task.Delay(_period, token).ConfigureAwait(false);
            }
            while (!token.IsCancellationRequested);
        }
        catch (OperationCanceledException) when (token.IsCancellationRequested) { }
    }
}
