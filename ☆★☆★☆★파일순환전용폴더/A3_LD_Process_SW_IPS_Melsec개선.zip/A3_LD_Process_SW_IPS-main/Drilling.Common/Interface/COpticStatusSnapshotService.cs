namespace Drilling.Common.Interface;

/// <summary>Shared Laser/BET readers. Consumers only inspect snapshots; offline devices are never queried.</summary>
public sealed class COpticStatusSnapshotService : IAsyncDisposable
{
    private sealed record Versioned<T>(long Version, T Value) where T : class;
    private sealed class Entry<T> where T : class
    {
        public long Version;
        public CSharedDeviceSnapshotService<Versioned<T>> Reader = null!;
    }
    private readonly Func<IReadOnlyList<(EN_EQP_MODULE Module, int Number)>> _devices;
    private readonly Func<EN_EQP_MODULE, int, bool> _connected;
    private readonly Func<int, CancellationToken, Task<ST_LASER_STATUS>> _laserRead;
    private readonly Func<int, CancellationToken, Task<ST_BET_STATUS>> _betRead;
    private readonly Dictionary<int, Entry<ST_LASER_STATUS>> _lasers = [];
    private readonly Dictionary<int, Entry<ST_BET_STATUS>> _bets = [];
    private readonly object _sync = new();
    private bool _running = true;
    private bool _disposed;

    public COpticStatusSnapshotService(Func<IReadOnlyList<(EN_EQP_MODULE Module, int Number)>> devices,
        Func<EN_EQP_MODULE, int, bool> connected,
        Func<int, CancellationToken, Task<ST_LASER_STATUS>> laserRead,
        Func<int, CancellationToken, Task<ST_BET_STATUS>> betRead)
    {
        _devices = devices;
        _connected = connected;
        _laserRead = laserRead;
        _betRead = betRead;
    }

    public ST_SHARED_DEVICE_SNAPSHOT<ST_LASER_STATUS> GetLaser(int number)
        => Get(EN_EQP_MODULE.TalonLaser, number, _lasers, _laserRead);
    public ST_SHARED_DEVICE_SNAPSHOT<ST_BET_STATUS> GetBet(int number)
        => Get(EN_EQP_MODULE.Bet, number, _bets, _betRead);

    private ST_SHARED_DEVICE_SNAPSHOT<T> Get<T>(EN_EQP_MODULE module, int number,
        Dictionary<int, Entry<T>> entries, Func<int, CancellationToken, Task<T>> read) where T : class
    {
        lock (_sync)
        {
            if (!_devices().Contains((module, number))) return new(null, "N/C", "장치가 등록되지 않았습니다.", default);
            if (!_running || _disposed) return new(null, "STOPPED", "상태 수집이 중지되었습니다.", default);
            if (!_connected(module, number))
            {
                if (entries.TryGetValue(number, out var previous)) Interlocked.Increment(ref previous.Version);
                return new(null, "OFFLINE", "장치가 연결되지 않았습니다.", default);
            }
            if (!entries.TryGetValue(number, out var entry))
            {
                entry = new Entry<T>();
                var target = entry;
                entry.Reader = new(async token =>
                {
                    var version = Interlocked.Read(ref target.Version);
                    if (!_connected(module, number)) throw new IOException("장치가 연결되지 않아 조회를 보류합니다.");
                    return new Versioned<T>(version, await read(number, token).ConfigureAwait(false));
                }, readTimeout: TimeSpan.FromSeconds(5));
                entries.Add(number, entry);
            }
            entry.Reader.Start();
            var snapshot = entry.Reader.GetSnapshot();
            if (snapshot.Value is not { } current) return new(null, snapshot.State, snapshot.Detail, snapshot.UpdatedAt);
            if (current.Version != Interlocked.Read(ref entry.Version))
                return new(null, "LOADING", "연결 설정 변경 후 새 상태를 기다리고 있습니다.", default);
            return new(current.Value, snapshot.State, snapshot.Detail, snapshot.UpdatedAt);
        }
    }

    public void Invalidate(EN_EQP_MODULE module, int number)
    {
        lock (_sync)
        {
            if (module == EN_EQP_MODULE.TalonLaser && _lasers.TryGetValue(number, out var laser)) Interlocked.Increment(ref laser.Version);
            if (module == EN_EQP_MODULE.Bet && _bets.TryGetValue(number, out var bet)) Interlocked.Increment(ref bet.Version);
        }
    }

    public void Start()
    {
        lock (_sync) { if (_disposed) return; _running = true; }
        foreach (var device in _devices())
        {
            if (device.Module == EN_EQP_MODULE.TalonLaser) GetLaser(device.Number);
            if (device.Module == EN_EQP_MODULE.Bet) GetBet(device.Number);
        }
    }

    public async Task StopAsync()
    {
        Task[] stops;
        lock (_sync)
        {
            _running = false;
            stops = _lasers.Values.Select(entry => entry.Reader.StopAsync())
                .Concat(_bets.Values.Select(entry => entry.Reader.StopAsync())).ToArray();
        }
        await Task.WhenAll(stops).ConfigureAwait(false);
    }

    public async ValueTask DisposeAsync()
    {
        lock (_sync) _disposed = true;
        await StopAsync().ConfigureAwait(false);
    }
}
