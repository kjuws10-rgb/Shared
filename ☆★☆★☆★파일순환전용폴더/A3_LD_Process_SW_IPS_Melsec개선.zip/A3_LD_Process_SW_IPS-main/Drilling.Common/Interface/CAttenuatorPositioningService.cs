using System.Diagnostics;
using System.Globalization;
using System.IO;

namespace Drilling.Common.Interface;

public sealed record ST_ATTENUATOR_MOVE_TARGET(int HeadNo, double Angle);

/// <summary>Issues ATT moves and waits only on the continuously collected shared snapshots.</summary>
public sealed class CAttenuatorPositioningService
{
    private const double PositionTolerance = 0.01;
    private static readonly TimeSpan MaximumSnapshotAge = TimeSpan.FromSeconds(2);
    private readonly Func<int, bool> _isRegistered;
    private readonly Func<int, double, ST_DEVICE_COMMAND_RESULT> _validateTarget;
    private readonly Func<int, EN_ATTENUATOR_COMMAND, double, CancellationToken, Task<ST_DEVICE_COMMAND_RESULT>> _executeCommand;
    private readonly Func<int, ST_ATTENUATOR_STATUS_SNAPSHOT> _getSnapshot;
    private readonly TimeSpan _moveTimeout;
    private readonly TimeSpan _pollInterval;
    private readonly SemaphoreSlim _operationLock = new(1, 1);
    private readonly object _pendingLock = new();
    private IReadOnlyList<ST_ATTENUATOR_MOVE_TARGET> _pendingStops = [];

    public CAttenuatorPositioningService(CInterfaceManager interfaces)
        : this(number => interfaces.GetInterfaceData(EN_EQP_MODULE.Attenuator, number) is not null,
            interfaces.ValidateAttenuatorAbsoluteMoveTarget,
            (number, command, value, token) => interfaces.ExecuteAttenuatorCommand(number, command, value, token),
            number => interfaces.AttenuatorSnapshots.GetSnapshot(number))
    {
        ArgumentNullException.ThrowIfNull(interfaces);
    }

    // Explicit transport injection keeps command order, failure handling, and timeouts testable offline.
    public CAttenuatorPositioningService(Func<int, bool> isRegistered,
        Func<int, double, ST_DEVICE_COMMAND_RESULT> validateTarget,
        Func<int, EN_ATTENUATOR_COMMAND, double, CancellationToken, Task<ST_DEVICE_COMMAND_RESULT>> executeCommand,
        Func<int, ST_ATTENUATOR_STATUS_SNAPSHOT> getSnapshot,
        TimeSpan? moveTimeout = null, TimeSpan? pollInterval = null)
    {
        _isRegistered = isRegistered ?? throw new ArgumentNullException(nameof(isRegistered));
        _validateTarget = validateTarget ?? throw new ArgumentNullException(nameof(validateTarget));
        _executeCommand = executeCommand ?? throw new ArgumentNullException(nameof(executeCommand));
        _getSnapshot = getSnapshot ?? throw new ArgumentNullException(nameof(getSnapshot));
        _moveTimeout = moveTimeout ?? TimeSpan.FromSeconds(30);
        _pollInterval = pollInterval ?? TimeSpan.FromMilliseconds(200);
        if (_moveTimeout <= TimeSpan.Zero) throw new ArgumentOutOfRangeException(nameof(moveTimeout));
        if (_pollInterval < TimeSpan.Zero) throw new ArgumentOutOfRangeException(nameof(pollInterval));
    }

    public bool HasPendingStops
    {
        get { lock (_pendingLock) return _pendingStops.Count > 0; }
    }

    public async Task MoveAndWaitAsync(IReadOnlyList<ST_ATTENUATOR_MOVE_TARGET> targets, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(targets);
        await _operationLock.WaitAsync(cancellationToken).ConfigureAwait(false);
        var attempted = new List<ST_ATTENUATOR_MOVE_TARGET>();
        try
        {
            if (HasPendingStops) throw new InvalidOperationException("ATT 정지가 확인되지 않은 Head가 있습니다. STOP으로 정지를 확인한 후 다시 시도해 주세요.");
            var prepared = ValidateTargets(targets);
            var fences = new Dictionary<int, ST_ATTENUATOR_COMPLETION_FENCE>();
            // Reject every missing device, invalid limit, or unavailable initial state before the first move.
            foreach (var target in prepared)
            {
                RequireReady(target, await WaitForInitialSnapshot(target, cancellationToken).ConfigureAwait(false));
            }
            foreach (var target in prepared)
            {
                cancellationToken.ThrowIfCancellationRequested();
                attempted.Add(target); // A lost acknowledgement can still mean that PA was accepted.
                fences[target.HeadNo] = await MoveOneAndWait(target, cancellationToken).ConfigureAwait(false);
            }
            // A later move can take time; verify all previously completed devices again before allowing RUN.
            foreach (var target in prepared)
            {
                var status = await WaitForFreshSnapshot(target, fences[target.HeadNo], cancellationToken).ConfigureAwait(false);
                RequireAtTarget(target, status);
            }
            cancellationToken.ThrowIfCancellationRequested();
        }
        catch (Exception exception)
        {
            if (attempted.Count > 0)
            {
                var failures = await StopTargets(attempted, CancellationToken.None).ConfigureAwait(false);
                if (failures.Count > 0)
                    throw new IOException($"{exception.Message}\n일부 ATT의 정지를 확인하지 못했습니다. STOP으로 다시 정지해 주세요.\n{string.Join("\n", failures)}", exception);
            }
            throw;
        }
        finally { _operationLock.Release(); }
    }

    public async Task StopPendingAsync(CancellationToken cancellationToken = default)
    {
        await _operationLock.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            IReadOnlyList<ST_ATTENUATOR_MOVE_TARGET> pending;
            lock (_pendingLock) pending = _pendingStops.ToArray();
            var failures = await StopTargets(pending, cancellationToken).ConfigureAwait(false);
            if (failures.Count > 0) throw new IOException($"ATT 정지를 확인하지 못했습니다.\n{string.Join("\n", failures)}");
        }
        finally { _operationLock.Release(); }
    }

    private IReadOnlyList<ST_ATTENUATOR_MOVE_TARGET> ValidateTargets(IReadOnlyList<ST_ATTENUATOR_MOVE_TARGET> targets)
    {
        if (targets.Count == 0) throw new InvalidDataException("ATT를 이동할 Head가 없습니다.");
        var heads = new HashSet<int>();
        var result = new List<ST_ATTENUATOR_MOVE_TARGET>(targets.Count);
        foreach (var target in targets)
        {
            if (target.HeadNo is < 1 or > 8 || !heads.Add(target.HeadNo))
                throw new InvalidDataException($"HEAD {target.HeadNo:00} ATT 대상 설정이 잘못되었거나 중복되었습니다.");
            if (!_isRegistered(target.HeadNo - 1)) throw Failure(target, "ATT 연결 설정이 없습니다.");
            if (!double.IsFinite(target.Angle)) throw Failure(target, "목표 각도는 유효한 숫자여야 합니다.");
            var validation = _validateTarget(target.HeadNo - 1, target.Angle);
            if (!validation.IsSuccess) throw Failure(target, validation.Message);
            result.Add(target with { Angle = double.Parse(target.Angle.ToString("F3", CultureInfo.InvariantCulture), CultureInfo.InvariantCulture) });
        }
        return result;
    }

    private async Task<ST_ATTENUATOR_COMPLETION_FENCE> MoveOneAndWait(ST_ATTENUATOR_MOVE_TARGET target, CancellationToken cancellationToken)
    {
        using var deadline = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        deadline.CancelAfter(_moveTimeout);
        ST_ATTENUATOR_STATUS_SNAPSHOT? last = null;
        try
        {
            var baseline = GetSnapshot(target).Version;
            await Execute(target, EN_ATTENUATOR_COMMAND.MoveAbs, target.Angle, deadline.Token).ConfigureAwait(false);
            var fence = new ST_ATTENUATOR_COMPLETION_FENCE(baseline, Stopwatch.GetTimestamp());
            while (true)
            {
                last = await WaitForFreshSnapshot(target, fence, deadline.Token).ConfigureAwait(false);
                if (last.Value?.CommandState == "READY" && last.IsInPosition && IsAtTarget(target, last)) return fence;
                if (last.Value?.CommandState is not ("READY" or "MOVING"))
                    throw Failure(target, $"이동을 완료할 수 없는 상태입니다. {Describe(last)}");
                await Task.Delay(_pollInterval, deadline.Token).ConfigureAwait(false);
            }
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            throw new TimeoutException($"{Prefix(target)} ATT 이동 완료 제한 시간({_moveTimeout.TotalSeconds.ToString("0.###", CultureInfo.InvariantCulture)}초)을 초과했습니다. {Describe(last)}");
        }
    }

    private async Task<ST_ATTENUATOR_STATUS_SNAPSHOT> WaitForInitialSnapshot(ST_ATTENUATOR_MOVE_TARGET target, CancellationToken cancellationToken)
    {
        using var deadline = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        deadline.CancelAfter(_moveTimeout);
        try
        {
            while (true)
            {
                deadline.Token.ThrowIfCancellationRequested();
                var snapshot = GetSnapshot(target);
                if (snapshot.IsFresh(MaximumSnapshotAge) && snapshot.IsValid) return snapshot;
                if (snapshot.State is "OFFLINE" or "STOPPED" or "ERROR" ||
                    snapshot.IsFresh(MaximumSnapshotAge) && snapshot.State is not ("LOADING" or "STALE"))
                    throw Failure(target, $"ATT 상태를 확인할 수 없습니다. {Describe(snapshot)}");
                await Task.Delay(_pollInterval, deadline.Token).ConfigureAwait(false);
            }
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        { throw new TimeoutException($"{Prefix(target)} ATT 상태 확인 제한 시간을 초과했습니다."); }
    }

    private async Task<ST_ATTENUATOR_STATUS_SNAPSHOT> WaitForFreshSnapshot(ST_ATTENUATOR_MOVE_TARGET target,
        ST_ATTENUATOR_COMPLETION_FENCE fence, CancellationToken cancellationToken)
    {
        using var deadline = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        deadline.CancelAfter(_moveTimeout);
        try
        {
            while (true)
            {
                deadline.Token.ThrowIfCancellationRequested();
                var snapshot = GetSnapshot(target);
                if (snapshot.Version > fence.Version && snapshot.CollectedTimestamp > fence.AcknowledgedTimestamp && snapshot.IsFresh(MaximumSnapshotAge))
                {
                    if (!snapshot.IsValid || snapshot.Value is not { CommOk: true, LastError: EN_CONEX_AGP_ERROR.Ok } value || !double.IsFinite(value.CurrentPosition))
                        throw Failure(target, $"ATT 상태를 확인할 수 없습니다. {Describe(snapshot)}");
                    return snapshot;
                }
                if (snapshot.State is "OFFLINE" or "STOPPED" or "ERROR")
                    throw Failure(target, $"ATT 상태를 확인할 수 없습니다. {Describe(snapshot)}");
                await Task.Delay(_pollInterval, deadline.Token).ConfigureAwait(false);
            }
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        { throw new TimeoutException($"{Prefix(target)} ATT의 새 상태를 확인하지 못했습니다."); }
    }

    private ST_ATTENUATOR_STATUS_SNAPSHOT GetSnapshot(ST_ATTENUATOR_MOVE_TARGET target)
    {
        var snapshot = _getSnapshot(target.HeadNo - 1);
        if (snapshot.Number != target.HeadNo - 1) throw Failure(target, "다른 Head의 ATT 상태가 반환되었습니다.");
        return snapshot;
    }

    private async Task<ST_DEVICE_COMMAND_RESULT> Execute(ST_ATTENUATOR_MOVE_TARGET target, EN_ATTENUATOR_COMMAND command, double value, CancellationToken cancellationToken)
    {
        try
        {
            var result = await _executeCommand(target.HeadNo - 1, command, value, cancellationToken).WaitAsync(cancellationToken).ConfigureAwait(false);
            if (!result.IsSuccess) throw Failure(target, $"{command} 명령에 실패했습니다. {result.Message}");
            return result;
        }
        catch (Exception exception) when (exception is IOException or TimeoutException)
        {
            throw new InvalidOperationException($"{Prefix(target)} {command} 통신에 실패했습니다. {exception.Message}", exception);
        }
    }

    private async Task<IReadOnlyList<string>> StopTargets(IReadOnlyList<ST_ATTENUATOR_MOVE_TARGET> targets, CancellationToken cancellationToken)
    {
        var failures = new List<string>();
        var pending = new List<ST_ATTENUATOR_MOVE_TARGET>();
        foreach (var target in targets)
        {
            using var deadline = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            deadline.CancelAfter(TimeSpan.FromSeconds(5));
            try
            {
                var baseline = GetSnapshot(target).Version;
                await Execute(target, EN_ATTENUATOR_COMMAND.Stop, 0, deadline.Token).ConfigureAwait(false);
                var fence = new ST_ATTENUATOR_COMPLETION_FENCE(baseline, Stopwatch.GetTimestamp());
                while (true)
                {
                    var snapshot = await WaitForFreshSnapshot(target, fence, deadline.Token).ConfigureAwait(false);
                    var state = snapshot.Value?.CommandState;
                    if (state is "READY" or "DISABLE" or "NOT_REFERENCED" or "CONFIGURATION") break;
                    if (state is not ("MOVING" or "HOMING")) throw Failure(target, $"정지 후 상태를 확인할 수 없습니다. State={state}");
                    await Task.Delay(_pollInterval, deadline.Token).ConfigureAwait(false);
                }
            }
            catch (Exception exception)
            {
                pending.Add(target);
                failures.Add($"{Prefix(target)} {exception.Message}");
            }
        }
        lock (_pendingLock) _pendingStops = pending;
        return failures;
    }

    private static bool IsAtTarget(ST_ATTENUATOR_MOVE_TARGET target, ST_ATTENUATOR_STATUS_SNAPSHOT snapshot)
        => snapshot.Value is { } status && double.IsFinite(status.CurrentPosition) && Math.Abs(status.CurrentPosition - target.Angle) <= PositionTolerance;

    private static void RequireReady(ST_ATTENUATOR_MOVE_TARGET target, ST_ATTENUATOR_STATUS_SNAPSHOT snapshot)
    {
        if (!snapshot.IsValid || !snapshot.IsFresh(MaximumSnapshotAge) || snapshot.Value is not { CommOk: true, LastError: EN_CONEX_AGP_ERROR.Ok } status ||
            !double.IsFinite(status.CurrentPosition) || status.CommandState != "READY" || !snapshot.IsInPosition)
            throw Failure(target, $"ATT가 유효한 READY/INPOSITION 상태가 아닙니다. {Describe(snapshot)}");
    }

    private static void RequireAtTarget(ST_ATTENUATOR_MOVE_TARGET target, ST_ATTENUATOR_STATUS_SNAPSHOT status)
    {
        RequireReady(target, status);
        if (!IsAtTarget(target, status)) throw Failure(target, $"ATT가 목표 각도에 도착하지 않았습니다. {Describe(status)}");
    }

    private static string Describe(ST_ATTENUATOR_STATUS_SNAPSHOT? snapshot) => snapshot is null ? "수집된 상태가 없습니다." :
        $"State={snapshot.State}/{snapshot.Value?.CommandState}, Current={snapshot.Value?.CurrentPosition.ToString("0.###", CultureInfo.InvariantCulture)} deg, InPosition={snapshot.IsInPosition}, {snapshot.Detail}";
    private static string Prefix(ST_ATTENUATOR_MOVE_TARGET target) => $"HEAD {target.HeadNo:00} / ATT 목표 {target.Angle.ToString("0.###", CultureInfo.InvariantCulture)} deg:";
    private static InvalidOperationException Failure(ST_ATTENUATOR_MOVE_TARGET target, string message) => new($"{Prefix(target)} {message}");
    private sealed record ST_ATTENUATOR_COMPLETION_FENCE(long Version, long AcknowledgedTimestamp);
}

public partial class CInterfaceManager
{
    /// <summary>Read-only absolute-target preflight using the same configured software limits as PA.</summary>
    public ST_DEVICE_COMMAND_RESULT ValidateAttenuatorAbsoluteMoveTarget(int number, double angle)
    {
        var settings = _attenuatorLimitSettings?.Invoke();
        double ReadLimit(string key)
        {
            var text = settings?.FirstOrDefault(item => item.Key.Equals(key, StringComparison.OrdinalIgnoreCase))?.Value;
            return double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out var value) ? value : double.NaN;
        }
        var minimum = ReadLimit("ATTENUATOR_DEGREE_MIN_SW_LIMIT");
        var maximum = ReadLimit("ATTENUATOR_DEGREE_MAX_SW_LIMIT");
        if (!double.IsFinite(minimum) || !double.IsFinite(maximum) || minimum > maximum)
            return Block("Attenuator Degree Min/Max SW Limit 설정을 확인해 주세요.");
        if (!double.IsFinite(angle)) return Block("이동 각도는 유효한 숫자여야 합니다.");
        var transmitted = double.Parse(angle.ToString("F3", CultureInfo.InvariantCulture), CultureInfo.InvariantCulture);
        if (angle < minimum || angle > maximum || transmitted < minimum || transmitted > maximum)
            return Block($"목표 각도 {angle.ToString("G17", CultureInfo.InvariantCulture)} deg가 허용 범위 [{minimum.ToString(CultureInfo.InvariantCulture)}, {maximum.ToString(CultureInfo.InvariantCulture)}] deg를 벗어났습니다.");
        return new(true, "ATT target is within software limits.");
        ST_DEVICE_COMMAND_RESULT Block(string message) => new(false, $"{AttenuatorSoftwareLimitMessagePrefix}H{number + 1:00} {message}");
    }
}
