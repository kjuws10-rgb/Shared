using System.Collections.Concurrent;
using System.Diagnostics;
using System.Globalization;
using System.IO;

namespace Drilling.Common.Interface;

public sealed record ST_ATTENUATOR_STATUS_SNAPSHOT(int Number, ST_ATTENUATOR_STATUS? Value,
    bool IsInPosition, long Version, DateTimeOffset UpdatedAt, long CollectedTimestamp, string State, string Detail)
{
    public bool IsValid => Value is { CommOk: true, LastError: EN_CONEX_AGP_ERROR.Ok } && double.IsFinite(Value.CurrentPosition);

    public bool IsFresh(TimeSpan maximumAge)
    {
        if (CollectedTimestamp <= 0 || maximumAge < TimeSpan.Zero) return false;
        var elapsed = Stopwatch.GetElapsedTime(CollectedTimestamp);
        return elapsed >= TimeSpan.Zero && elapsed <= maximumAge;
    }
}

/// <summary>Owns the shared ATT pollers. Readers never send a device query.</summary>
public sealed class CAttenuatorStatusSnapshotService : IAsyncDisposable
{
    private readonly Func<IReadOnlyList<int>> _deviceNumbers;
    private readonly Func<int, bool> _isConnected;
    private readonly Func<int, EN_ATTENUATOR_COMMAND, CancellationToken, Task<string>> _read;
    private readonly Func<int, ST_ATTENUATOR_STATUS>? _cachedValue;
    private readonly TimeSpan _period;
    private readonly TimeSpan _readTimeout;
    private readonly bool _autoStartOnRead;
    private readonly object _lifecycle = new();
    private readonly object _publication = new();
    private readonly ConcurrentDictionary<int, ST_ATTENUATOR_STATUS_SNAPSHOT> _snapshots = new();
    private readonly ConcurrentDictionary<int, CDeviceRead> _reads = new();
    private readonly ConcurrentDictionary<int, long> _epochs = new();
    private readonly ConcurrentDictionary<int, Task> _workers = new();
    private CancellationTokenSource? _cancellation;
    private Task? _discovery;
    private long _version;
    private int _generation;
    private bool _allowAutoStart = true;
    private bool _disposed;
    private bool _stopping;

    // All transport calls belong to this service; the injectable overload also supports offline regression.
    public CAttenuatorStatusSnapshotService(Func<IReadOnlyList<int>> deviceNumbers, Func<int, bool> isConnected,
        Func<int, EN_ATTENUATOR_COMMAND, CancellationToken, Task<string>> read,
        Func<int, ST_ATTENUATOR_STATUS>? cachedValue = null, TimeSpan? pollPeriod = null,
        TimeSpan? readTimeout = null, bool autoStartOnRead = true)
    {
        _deviceNumbers = deviceNumbers ?? throw new ArgumentNullException(nameof(deviceNumbers));
        _isConnected = isConnected ?? throw new ArgumentNullException(nameof(isConnected));
        _read = read ?? throw new ArgumentNullException(nameof(read));
        _cachedValue = cachedValue;
        _period = pollPeriod ?? TimeSpan.FromMilliseconds(500);
        _readTimeout = readTimeout ?? TimeSpan.FromSeconds(2);
        _autoStartOnRead = autoStartOnRead;
        if (_period <= TimeSpan.Zero) throw new ArgumentOutOfRangeException(nameof(pollPeriod));
        if (_readTimeout <= TimeSpan.Zero) throw new ArgumentOutOfRangeException(nameof(readTimeout));
    }

    public ST_ATTENUATOR_STATUS_SNAPSHOT GetSnapshot(int number)
    {
        lock (_lifecycle)
        {
            if (_autoStartOnRead && _allowAutoStart) Start();
        }
        if (!_deviceNumbers().Contains(number)) return Unavailable(number, "UNREGISTERED", "ATT 연결 설정이 없습니다.");
        if (!_isConnected(number))
        {
            if (!_snapshots.TryGetValue(number, out var disconnected) || disconnected.State != "OFFLINE")
                Invalidate(number, "OFFLINE", "ATT가 연결되어 있지 않습니다.");
        }
        return _snapshots.TryGetValue(number, out var snapshot) ? snapshot : Unavailable(number, "LOADING", "ATT 상태 수집을 기다리고 있습니다.");
    }

    public void Start()
    {
        lock (_lifecycle)
        {
            if (_disposed || _stopping || _cancellation is not null) return;
            _allowAutoStart = true;
            var generation = ++_generation;
            foreach (var number in _snapshots.Keys.Concat(_deviceNumbers()).Distinct())
                Invalidate(number, "LOADING", "ATT 상태 수집을 다시 시작합니다.");
            _cancellation = new CancellationTokenSource();
            var token = _cancellation.Token;
            _discovery = Task.Run(() => Discover(generation, token), CancellationToken.None);
        }
    }

    public async Task StopAsync(CancellationToken cancellationToken = default)
    {
        Task? discovery;
        CancellationTokenSource? cancellation;
        lock (_lifecycle)
        {
            _allowAutoStart = false;
            _stopping = true;
            ++_generation;
            cancellation = _cancellation;
            _cancellation = null;
            discovery = _discovery;
            _discovery = null;
            cancellation?.Cancel();
            foreach (var number in _snapshots.Keys.Concat(_deviceNumbers()).Distinct())
                Invalidate(number, "STOPPED", "ATT 상태 수집이 중지되었습니다.");
        }
        try
        {
            if (discovery is not null) await IgnoreCancellation(discovery).WaitAsync(cancellationToken).ConfigureAwait(false);
            await IgnoreCancellation(Task.WhenAll(_workers.Values.ToArray())).WaitAsync(cancellationToken).ConfigureAwait(false);
            _workers.Clear();
        }
        finally
        {
            cancellation?.Dispose();
            lock (_lifecycle) _stopping = false;
        }
    }

    public async ValueTask DisposeAsync()
    {
        await StopAsync().ConfigureAwait(false);
        lock (_lifecycle) _disposed = true;
    }

    /// <summary>Invalidation is memory-only and immediately removes any completion indication.</summary>
    public void Invalidate(int number, string state = "OFFLINE", string detail = "ATT 상태를 다시 수집해야 합니다.")
    {
        lock (_publication)
        {
            _epochs.AddOrUpdate(number, 1, (_, previous) => previous + 1);
            _snapshots[number] = new(number, null, false, Interlocked.Increment(ref _version), DateTimeOffset.Now, 0, state, detail);
        }
    }

    /// <summary>Collects one shared sample; simultaneous collectors for the same ATT are serialized.</summary>
    public Task CollectOnceAsync(int number, CancellationToken cancellationToken = default)
        => Collect(number, Volatile.Read(ref _generation), cancellationToken);

    private async Task Discover(int generation, CancellationToken cancellationToken)
    {
        while (!cancellationToken.IsCancellationRequested)
        {
            foreach (var number in _deviceNumbers().Distinct())
            {
                cancellationToken.ThrowIfCancellationRequested();
                if (_workers.TryGetValue(number, out var previous) && !previous.IsCompleted) continue;
                if (previous is not null) Observe(previous);
                _workers[number] = Task.Run(() => PollDevice(number, generation, cancellationToken), CancellationToken.None);
            }
            await Task.Delay(_period, cancellationToken).ConfigureAwait(false);
        }
    }

    private async Task PollDevice(int number, int generation, CancellationToken cancellationToken)
    {
        while (!cancellationToken.IsCancellationRequested && _deviceNumbers().Contains(number))
        {
            var started = Stopwatch.GetTimestamp();
            await Collect(number, generation, cancellationToken).ConfigureAwait(false);
            var delay = _period - Stopwatch.GetElapsedTime(started);
            if (delay > TimeSpan.Zero) await Task.Delay(delay, cancellationToken).ConfigureAwait(false);
        }
    }

    private async Task Collect(int number, int generation, CancellationToken cancellationToken)
    {
        var device = _reads.GetOrAdd(number, _ => new CDeviceRead());
        await device.Gate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            if (generation != Volatile.Read(ref _generation)) return;
            if (!_deviceNumbers().Contains(number)) { Invalidate(number, "UNREGISTERED", "ATT 연결 설정이 없습니다."); return; }
            // An offline device is never queried or automatically reconnected by this worker.
            if (!_isConnected(number)) { Invalidate(number, "OFFLINE", "ATT가 연결되어 있지 않습니다."); return; }
            if (device.InFlight is { IsCompleted: false })
            {
                Invalidate(number, "TIMEOUT", "이전 ATT 응답이 끝나지 않아 새 상태 읽기를 보류했습니다.");
                return;
            }
            var deadline = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            deadline.CancelAfter(_readTimeout);
            var started = Stopwatch.GetTimestamp();
            var epoch = _epochs.GetOrAdd(number, 0);
            var read = ReadFrame(number, deadline.Token);
            device.InFlight = read;
            try
            {
                var frame = await read.WaitAsync(deadline.Token).ConfigureAwait(false);
                cancellationToken.ThrowIfCancellationRequested();
                if (generation != Volatile.Read(ref _generation)) return;
                var cached = _cachedValue?.Invoke(number);
                var value = new ST_ATTENUATOR_STATUS(frame.Position, frame.Target ?? cached?.TargetPosition ?? frame.Position,
                    frame.State, CommOk: true, LastError: EN_CONEX_AGP_ERROR.Ok, UpdatedAt: DateTimeOffset.Now,
                    HomeType: cached?.HomeType, NegativeSoftwareLimit: cached?.NegativeSoftwareLimit,
                    PositiveSoftwareLimit: cached?.PositiveSoftwareLimit, IGain: cached?.IGain, PGain: cached?.PGain,
                    InterpolationFactor: cached?.InterpolationFactor);
                lock (_publication)
                {
                    if (_epochs.GetOrAdd(number, 0) != epoch || generation != Volatile.Read(ref _generation)) return;
                    if (!_isConnected(number)) { Invalidate(number, "OFFLINE", "ATT 연결이 해제되었습니다."); return; }
                    _snapshots[number] = new(number, value, frame.InPosition, Interlocked.Increment(ref _version),
                        DateTimeOffset.Now, started, frame.State, "");
                }
            }
            catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
            { if (generation == Volatile.Read(ref _generation)) Invalidate(number, "TIMEOUT", "ATT 상태 응답 제한 시간을 초과했습니다."); }
            catch (Exception exception) when (exception is not OperationCanceledException)
            { if (generation == Volatile.Read(ref _generation)) Invalidate(number, _isConnected(number) ? "ERROR" : "OFFLINE", exception.Message); }
            finally
            {
                if (read.IsCompleted) { Observe(read); deadline.Dispose(); }
                else _ = read.ContinueWith(completed => { Observe(completed); deadline.Dispose(); }, CancellationToken.None,
                    TaskContinuationOptions.ExecuteSynchronously, TaskScheduler.Default);
            }
        }
        finally { device.Gate.Release(); }
    }

    private async Task<CFrame> ReadFrame(int number, CancellationToken cancellationToken)
    {
        // Both state samples must indicate READY. A transition during TP cannot report in-position.
        var before = ParseState(await Read(EN_ATTENUATOR_COMMAND.PollState).ConfigureAwait(false));
        var positionText = await Read(EN_ATTENUATOR_COMMAND.PollCurrentPosition).ConfigureAwait(false);
        var fields = positionText.Split(':', StringSplitOptions.TrimEntries);
        if (fields.Length != 2 || !fields[0].Equals("TP", StringComparison.OrdinalIgnoreCase) ||
            !double.TryParse(fields[1], NumberStyles.Float, CultureInfo.InvariantCulture, out var position) || !double.IsFinite(position))
            throw new InvalidDataException($"ATT TP 위치 응답이 잘못되었습니다. {positionText}");
        double? target = null;
        if (before is "READY" or "MOVING" or "HOMING" or "DISABLE")
        {
            var targetText = await Read(EN_ATTENUATOR_COMMAND.PollTargetPosition).ConfigureAwait(false);
            fields = targetText.Split(':', StringSplitOptions.TrimEntries);
            if (fields.Length != 2 || !fields[0].Equals("TH", StringComparison.OrdinalIgnoreCase) ||
                !double.TryParse(fields[1], NumberStyles.Float, CultureInfo.InvariantCulture, out var parsedTarget) || !double.IsFinite(parsedTarget))
                throw new InvalidDataException($"ATT TH 목표 위치 응답이 잘못되었습니다. {targetText}");
            target = parsedTarget;
        }
        var after = ParseState(await Read(EN_ATTENUATOR_COMMAND.PollState).ConfigureAwait(false));
        return new(position, target, after, before == "READY" && after == "READY");

        async Task<string> Read(EN_ATTENUATOR_COMMAND command)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (!_isConnected(number)) throw new IOException("ATT가 연결되어 있지 않습니다.");
            return await _read(number, command, cancellationToken).ConfigureAwait(false);
        }
    }

    private static string ParseState(string response)
    {
        var fields = response.Split(':', StringSplitOptions.TrimEntries);
        if (fields.Length != 3 || !fields[0].Equals("TS", StringComparison.OrdinalIgnoreCase) ||
            !uint.TryParse(fields[1], NumberStyles.HexNumber, CultureInfo.InvariantCulture, out var error))
            throw new InvalidDataException($"ATT TS 상태 응답이 잘못되었습니다. {response}");
        if (error != 0) throw new InvalidDataException($"ATT 컨트롤러 오류: {response}");
        var state = fields[2].ToUpperInvariant();
        if (int.TryParse(state, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out var code))
            state = code switch
            {
                >= 0x0A and <= 0x10 => "NOT_REFERENCED", 0x14 => "CONFIGURATION", 0x1E => "HOMING",
                0x28 => "MOVING", 0x32 or 0x33 or 0x34 => "READY", 0x3C or 0x3D => "DISABLE", _ => $"STATE_{code:X2}"
            };
        if (state is not ("READY" or "MOVING" or "HOMING" or "NOT_REFERENCED" or "CONFIGURATION" or "DISABLE"))
            throw new InvalidDataException($"ATT 상태를 확인할 수 없습니다. {response}");
        return state;
    }

    private static ST_ATTENUATOR_STATUS_SNAPSHOT Unavailable(int number, string state, string detail)
        => new(number, null, false, 0, DateTimeOffset.MinValue, 0, state, detail);
    private static void Observe(Task task) { if (task.IsFaulted) _ = task.Exception; }
    private static async Task IgnoreCancellation(Task task)
    { try { await task.ConfigureAwait(false); } catch (OperationCanceledException) { } }
    private sealed class CDeviceRead
    {
        public SemaphoreSlim Gate { get; } = new(1, 1);
        public Task<CFrame>? InFlight { get; set; }
    }
    private sealed record CFrame(double Position, double? Target, string State, bool InPosition);
}
