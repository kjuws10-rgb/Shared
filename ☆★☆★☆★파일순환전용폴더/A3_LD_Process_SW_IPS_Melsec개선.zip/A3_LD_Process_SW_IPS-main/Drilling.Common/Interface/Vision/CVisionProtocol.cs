using System.Buffers.Binary;
using System.Globalization;
using System.Text;

namespace Drilling.Common.Interface.Vision;

public enum EN_VISION_COMMAND
{
    MarkFindSingle = 1000,
    FlyingReady = 1001,
    FlyingMoveDone = 1002,
    MarkFindLine = 1003,
    MarkFindSettingSingle = 1010,
    MarkFindManual = 1020,
    KeepAliveRequest = 1900,
    KeepAlive = 1999
}

public readonly record struct ST_VISION_PACKET_HEADER(
    int Command,
    int DataLength,
    int UniqueId,
    int ErrorCode);

public readonly record struct ST_VISION_MARK_SEARCH(
    int Cell,
    int Doe,
    int Line,
    int IndexX,
    int IndexY,
    int Head);

public readonly record struct ST_VISION_MARK_FIND(
    int Result,
    double TargetMarkX,
    double TargetMarkY,
    double HoleX,
    double HoleY);

public sealed record ST_VISION_PACKET(
    ST_VISION_PACKET_HEADER Header,
    byte[] Body);

public sealed record ST_VISION_SINGLE_RESULT(
    int Resolution,
    ST_VISION_MARK_FIND Mark);

public sealed record ST_VISION_LINE_RESULT(
    int Resolution,
    int FindHoleCount,
    IReadOnlyList<ST_VISION_MARK_FIND> Marks);

public sealed record ST_VISION_FLYING_READY(
    int InspectionType,
    IReadOnlyList<ST_VISION_MARK_SEARCH> Searches);

public static class CVisionProtocol
{
    private const string PacketLogSeparator = "----------------------------------------------------------------------";
    private const string PacketLogBodyIndent = "       ";
    public const int HeaderSize = 16;
    public const int MarkSearchSize = 24;
    public const int MarkFindPackedSize = 36;
    public const int SingleResultBodySize = 40;
    public const int MaximumBodySize = 1024 * 1024;
    // Arrays use the actual transmitted count. Bound by the existing packet byte limit,
    // not an arbitrary 100/2048-Shot limit; the larger result record must also fit.
    public const int MaximumMarkCount = (MaximumBodySize - 8) / MarkFindPackedSize;

    public static ST_VISION_PACKET CreateEmpty(
        EN_VISION_COMMAND command,
        int uniqueId,
        int errorCode = 0) =>
        Create(command, uniqueId, [], errorCode);

    public static ST_VISION_PACKET CreateMarkFindSingle(
        int uniqueId,
        ST_VISION_MARK_SEARCH search) =>
        Create(
            EN_VISION_COMMAND.MarkFindSingle,
            uniqueId,
            EncodeMarkSearch(search));

    public static ST_VISION_PACKET CreateFlyingReady(
        int uniqueId,
        int inspectionType,
        IReadOnlyList<ST_VISION_MARK_SEARCH> searches)
    {
        ArgumentNullException.ThrowIfNull(searches);
        if (searches.Count > MaximumMarkCount)
        {
            throw new ArgumentOutOfRangeException(
                nameof(searches),
                $"Flying Ready supports up to {MaximumMarkCount} mark searches.");
        }

        var body = new byte[8 + (searches.Count * MarkSearchSize)];
        WriteInt32(body, 0, inspectionType);
        WriteInt32(body, 4, searches.Count);
        for (var index = 0; index < searches.Count; index++)
        {
            WriteMarkSearch(body, 8 + (index * MarkSearchSize), searches[index]);
        }

        return Create(EN_VISION_COMMAND.FlyingReady, uniqueId, body);
    }

    public static ST_VISION_PACKET CreateSingleResult(
        EN_VISION_COMMAND command,
        int uniqueId,
        int resolution,
        ST_VISION_MARK_FIND mark,
        int errorCode = 0)
    {
        if (command is not EN_VISION_COMMAND.MarkFindSingle and
            not EN_VISION_COMMAND.MarkFindSettingSingle and
            not EN_VISION_COMMAND.MarkFindManual)
        {
            throw new ArgumentOutOfRangeException(
                nameof(command),
                command,
                "Vision single result supports commands 1000, 1010 and 1020.");
        }

        var body = new byte[SingleResultBodySize];
        WriteInt32(body, 0, resolution);
        WriteMarkFind(body, 4, mark);
        return Create(command, uniqueId, body, errorCode);
    }

    public static ST_VISION_PACKET CreateLineResult(
        int uniqueId,
        int resolution,
        IReadOnlyList<ST_VISION_MARK_FIND> marks,
        int errorCode = 0)
    {
        ArgumentNullException.ThrowIfNull(marks);
        if (marks.Count > MaximumMarkCount)
        {
            throw new ArgumentOutOfRangeException(
                nameof(marks),
                $"Vision line result supports up to {MaximumMarkCount} marks.");
        }

        var body = new byte[8 + (marks.Count * MarkFindPackedSize)];
        WriteInt32(body, 0, resolution);
        WriteInt32(body, 4, marks.Count);
        for (var index = 0; index < marks.Count; index++)
        {
            WriteMarkFind(body, 8 + (index * MarkFindPackedSize), marks[index]);
        }

        return Create(EN_VISION_COMMAND.MarkFindLine, uniqueId, body, errorCode);
    }

    public static ST_VISION_PACKET Create(
        EN_VISION_COMMAND command,
        int uniqueId,
        byte[] body,
        int errorCode = 0)
    {
        ArgumentNullException.ThrowIfNull(body);
        ValidateBodyLength(body.Length);
        return new ST_VISION_PACKET(
            new ST_VISION_PACKET_HEADER((int)command, body.Length, uniqueId, errorCode),
            body);
    }

    public static byte[] Encode(ST_VISION_PACKET packet)
    {
        ArgumentNullException.ThrowIfNull(packet);
        ArgumentNullException.ThrowIfNull(packet.Body);
        if (packet.Header.DataLength != packet.Body.Length)
        {
            throw new InvalidDataException(
                $"Vision packet body length mismatch. Header={packet.Header.DataLength}, Body={packet.Body.Length}.");
        }

        ValidateBodyLength(packet.Body.Length);
        var bytes = new byte[HeaderSize + packet.Body.Length];
        WriteInt32(bytes, 0, packet.Header.Command);
        WriteInt32(bytes, 4, packet.Header.DataLength);
        WriteInt32(bytes, 8, packet.Header.UniqueId);
        WriteInt32(bytes, 12, packet.Header.ErrorCode);
        packet.Body.CopyTo(bytes, HeaderSize);
        return bytes;
    }

    public static ST_VISION_PACKET_HEADER DecodeHeader(ReadOnlySpan<byte> bytes)
    {
        if (bytes.Length < HeaderSize)
        {
            throw new InvalidDataException(
                $"Vision header requires {HeaderSize} bytes. Received={bytes.Length}.");
        }

        var header = new ST_VISION_PACKET_HEADER(
            ReadInt32(bytes, 0),
            ReadInt32(bytes, 4),
            ReadInt32(bytes, 8),
            ReadInt32(bytes, 12));
        ValidateBodyLength(header.DataLength);
        return header;
    }

    public static ST_VISION_PACKET Decode(ReadOnlySpan<byte> bytes)
    {
        var header = DecodeHeader(bytes);
        var packetLength = HeaderSize + header.DataLength;
        if (bytes.Length != packetLength)
        {
            throw new InvalidDataException(
                $"Vision packet length mismatch. Expected={packetLength}, Received={bytes.Length}.");
        }

        return new ST_VISION_PACKET(header, bytes.Slice(HeaderSize, header.DataLength).ToArray());
    }

    public static ST_VISION_MARK_SEARCH DecodeMarkSearchRequest(ST_VISION_PACKET packet)
    {
        ArgumentNullException.ThrowIfNull(packet);
        if (packet.Header.Command != (int)EN_VISION_COMMAND.MarkFindSingle)
        {
            throw new InvalidDataException(
                $"Command {packet.Header.Command} is not a Mark Find Single request.");
        }

        if (packet.Body.Length != MarkSearchSize)
        {
            throw new InvalidDataException(
                $"Mark Find Single request requires {MarkSearchSize} bytes. Received={packet.Body.Length}.");
        }

        return ReadMarkSearch(packet.Body, 0);
    }

    public static ST_VISION_FLYING_READY DecodeFlyingReadyRequest(ST_VISION_PACKET packet)
    {
        ArgumentNullException.ThrowIfNull(packet);
        if (packet.Header.Command != (int)EN_VISION_COMMAND.FlyingReady)
        {
            throw new InvalidDataException(
                $"Command {packet.Header.Command} is not a Flying Ready request.");
        }

        if (packet.Body.Length < 8)
        {
            throw new InvalidDataException(
                $"Flying Ready request requires at least 8 bytes. Received={packet.Body.Length}.");
        }

        var inspectionType = ReadInt32(packet.Body, 0);
        var count = ReadInt32(packet.Body, 4);
        if (count is < 0 or > MaximumMarkCount)
        {
            throw new InvalidDataException(
                $"Flying Ready mark count must be between 0 and {MaximumMarkCount}. Received={count}.");
        }

        var requiredLength = 8 + (count * MarkSearchSize);
        if (packet.Body.Length != requiredLength)
        {
            throw new InvalidDataException(
                $"Flying Ready request body length does not match its mark count. Expected={requiredLength}, Received={packet.Body.Length}.");
        }

        var searches = new ST_VISION_MARK_SEARCH[count];
        for (var index = 0; index < count; index++)
        {
            searches[index] = ReadMarkSearch(packet.Body, 8 + (index * MarkSearchSize));
        }

        return new ST_VISION_FLYING_READY(inspectionType, searches);
    }

    public static ST_VISION_SINGLE_RESULT DecodeSingleResult(ST_VISION_PACKET packet)
    {
        ArgumentNullException.ThrowIfNull(packet);
        if (packet.Header.Command is not ((int)EN_VISION_COMMAND.MarkFindSingle) and
            not ((int)EN_VISION_COMMAND.MarkFindSettingSingle) and
            not ((int)EN_VISION_COMMAND.MarkFindManual))
        {
            throw new InvalidDataException(
                $"Command {packet.Header.Command} is not a single mark result.");
        }

        if (packet.Body.Length < SingleResultBodySize)
        {
            throw new InvalidDataException(
                $"Single mark response requires {SingleResultBodySize} bytes. Received={packet.Body.Length}.");
        }

        return new ST_VISION_SINGLE_RESULT(
            ReadInt32(packet.Body, 0),
            ReadPackedMarkFind(packet.Body, 4));
    }

    public static ST_VISION_LINE_RESULT DecodeLineResult(ST_VISION_PACKET packet)
    {
        ArgumentNullException.ThrowIfNull(packet);
        if (packet.Header.Command != (int)EN_VISION_COMMAND.MarkFindLine)
        {
            throw new InvalidDataException(
                $"Command {packet.Header.Command} is not a line mark result.");
        }

        if (packet.Body.Length < 8)
        {
            throw new InvalidDataException("Line mark response requires at least 8 bytes.");
        }

        var resolution = ReadInt32(packet.Body, 0);
        var count = ReadInt32(packet.Body, 4);
        if (count is < 0 or > MaximumMarkCount)
        {
            throw new InvalidDataException(
                $"Line mark response count must be between 0 and {MaximumMarkCount}. Received={count}.");
        }

        var expectedLength = 8 + (count * MarkFindPackedSize);
        if (packet.Body.Length != expectedLength)
        {
            throw new InvalidDataException(
                $"Line mark response body length does not match its result count. Expected={expectedLength}, Received={packet.Body.Length}.");
        }

        var marks = new ST_VISION_MARK_FIND[count];
        for (var index = 0; index < count; index++)
        {
            marks[index] = ReadPackedMarkFind(
                packet.Body,
                8 + (index * MarkFindPackedSize));
        }

        return new ST_VISION_LINE_RESULT(resolution, count, marks);
    }

    public static byte[] EncodeMarkSearch(ST_VISION_MARK_SEARCH search)
    {
        var bytes = new byte[MarkSearchSize];
        WriteMarkSearch(bytes, 0, search);
        return bytes;
    }

    public static string FormatPacketLog(
        string direction,
        ST_VISION_PACKET packet,
        string source = "")
    {
        ArgumentNullException.ThrowIfNull(packet);

        var builder = new StringBuilder();
        builder.AppendLine(PacketLogSeparator);
        builder.Append('[').Append(direction.Trim().ToUpperInvariant()).Append("] ");
        if (!string.IsNullOrWhiteSpace(source))
        {
            builder.Append(source.Trim()).Append(' ');
        }

        builder.AppendLine(GetCommandName(packet.Header.Command));
        builder.Append("[HEAD] Code : ").Append(packet.Header.Command)
            .Append(" / UniqueID : ").Append(packet.Header.UniqueId)
            .Append(" / Length : ").Append(packet.Header.DataLength)
            .Append(" / Error : ").Append(packet.Header.ErrorCode);
        AppendPacketLogBody(builder, packet);
        return builder.ToString();
    }

    public static string GetCommandName(int command)
    {
        return command switch
        {
            (int)EN_VISION_COMMAND.MarkFindSingle => "Mark Find Single",
            (int)EN_VISION_COMMAND.FlyingReady => "Flying Ready",
            (int)EN_VISION_COMMAND.FlyingMoveDone => "Flying Move Done",
            (int)EN_VISION_COMMAND.MarkFindLine => "Mark Find Line",
            (int)EN_VISION_COMMAND.MarkFindSettingSingle => "Mark Find Setting Single",
            (int)EN_VISION_COMMAND.MarkFindManual => "Mark Find Manual",
            (int)EN_VISION_COMMAND.KeepAliveRequest => "Keep-Alive Request",
            (int)EN_VISION_COMMAND.KeepAlive => "Keep-Alive",
            _ => $"Unknown Command ({command})"
        };
    }

    private static void AppendPacketLogBody(StringBuilder builder, ST_VISION_PACKET packet)
    {
        builder.AppendLine();
        if (packet.Body.Length == 0)
        {
            builder.Append("[BODY] Empty");
            return;
        }

        try
        {
            switch (packet.Header.Command)
            {
                case (int)EN_VISION_COMMAND.MarkFindSingle:
                    AppendMarkFindSingleLogBody(builder, packet);
                    return;
                case (int)EN_VISION_COMMAND.FlyingReady:
                    AppendFlyingReadyLogBody(builder, packet);
                    return;
                case (int)EN_VISION_COMMAND.MarkFindLine:
                    AppendLineResultLogBody(builder, packet);
                    return;
                case (int)EN_VISION_COMMAND.MarkFindSettingSingle:
                case (int)EN_VISION_COMMAND.MarkFindManual:
                    AppendSingleResultLogBody(builder, packet);
                    return;
                default:
                    builder.Append("[BODY] Binary Data Length : ").Append(packet.Body.Length);
                    return;
            }
        }
        catch (Exception exception) when (exception is InvalidDataException or ArgumentException)
        {
            builder.Append("[BODY] Decode Error : ").Append(exception.Message);
        }
    }

    private static void AppendMarkFindSingleLogBody(StringBuilder builder, ST_VISION_PACKET packet)
    {
        if (packet.Body.Length == MarkSearchSize)
        {
            var search = DecodeMarkSearchRequest(packet);
            builder.Append("[BODY] Cell No : ").Append(search.Cell).AppendLine();
            builder.Append(PacketLogBodyIndent).Append("DOE / Beam : ").Append(search.Doe).AppendLine();
            builder.Append(PacketLogBodyIndent).Append("Line No : ").Append(search.Line).AppendLine();
            builder.Append(PacketLogBodyIndent).Append("Index X : ").Append(search.IndexX).AppendLine();
            builder.Append(PacketLogBodyIndent).Append("Index Y : ").Append(search.IndexY).AppendLine();
            builder.Append(PacketLogBodyIndent).Append("Head No : ").Append(search.Head);
            return;
        }

        AppendSingleResultLogBody(builder, packet);
    }

    private static void AppendFlyingReadyLogBody(StringBuilder builder, ST_VISION_PACKET packet)
    {
        var ready = DecodeFlyingReadyRequest(packet);
        builder.Append("[BODY] Inspection Type : ").Append(ready.InspectionType).AppendLine();
        builder.Append(PacketLogBodyIndent).Append("Mark Count : ").Append(ready.Searches.Count);
        for (var index = 0; index < ready.Searches.Count; index++)
        {
            var search = ready.Searches[index];
            builder.AppendLine();
            builder.Append(PacketLogBodyIndent)
                .Append("Mark[").Append(index).Append("] : Cell=").Append(search.Cell)
                .Append(" / DOE=").Append(search.Doe)
                .Append(" / Line=").Append(search.Line)
                .Append(" / IndexX=").Append(search.IndexX)
                .Append(" / IndexY=").Append(search.IndexY)
                .Append(" / Head=").Append(search.Head);
        }
    }

    private static void AppendSingleResultLogBody(StringBuilder builder, ST_VISION_PACKET packet)
    {
        var result = DecodeSingleResult(packet);
        builder.Append("[BODY] Resolution : ").Append(result.Resolution).AppendLine();
        AppendMarkResultLog(builder, result.Mark, null);
    }

    private static void AppendLineResultLogBody(StringBuilder builder, ST_VISION_PACKET packet)
    {
        var result = DecodeLineResult(packet);
        builder.Append("[BODY] Resolution : ").Append(result.Resolution).AppendLine();
        builder.Append(PacketLogBodyIndent).Append("Find Hole Count : ").Append(result.FindHoleCount);
        for (var index = 0; index < result.Marks.Count; index++)
        {
            builder.AppendLine();
            AppendMarkResultLog(builder, result.Marks[index], index);
        }
    }

    private static void AppendMarkResultLog(
        StringBuilder builder,
        ST_VISION_MARK_FIND mark,
        int? index)
    {
        builder.Append(PacketLogBodyIndent);
        if (index.HasValue)
        {
            builder.Append("Mark[").Append(index.Value).Append("] ");
        }
        else
        {
            builder.Append("Mark ");
        }

        builder.Append("Result : ").Append(mark.Result)
            .Append(" / Target X : ").Append(FormatLogNumber(mark.TargetMarkX))
            .Append(" / Target Y : ").Append(FormatLogNumber(mark.TargetMarkY))
            .Append(" / Hole X : ").Append(FormatLogNumber(mark.HoleX))
            .Append(" / Hole Y : ").Append(FormatLogNumber(mark.HoleY));
    }

    private static string FormatLogNumber(double value)
    {
        return value.ToString("0.################", CultureInfo.InvariantCulture);
    }

    private static void WriteMarkSearch(
        Span<byte> destination,
        int offset,
        ST_VISION_MARK_SEARCH search)
    {
        WriteInt32(destination, offset, search.Cell);
        WriteInt32(destination, offset + 4, search.Doe);
        WriteInt32(destination, offset + 8, search.Line);
        WriteInt32(destination, offset + 12, search.IndexX);
        WriteInt32(destination, offset + 16, search.IndexY);
        WriteInt32(destination, offset + 20, search.Head);
    }

    private static void WriteMarkFind(
        Span<byte> destination,
        int offset,
        ST_VISION_MARK_FIND mark)
    {
        WriteInt32(destination, offset, mark.Result);
        WriteDouble(destination, offset + 4, mark.TargetMarkX);
        WriteDouble(destination, offset + 12, mark.TargetMarkY);
        WriteDouble(destination, offset + 20, mark.HoleX);
        WriteDouble(destination, offset + 28, mark.HoleY);
    }

    private static ST_VISION_MARK_FIND ReadPackedMarkFind(
        ReadOnlySpan<byte> source,
        int offset) =>
        new(
            ReadInt32(source, offset),
            ReadDouble(source, offset + 4),
            ReadDouble(source, offset + 12),
            ReadDouble(source, offset + 20),
            ReadDouble(source, offset + 28));

    private static ST_VISION_MARK_SEARCH ReadMarkSearch(
        ReadOnlySpan<byte> source,
        int offset) =>
        new(
            ReadInt32(source, offset),
            ReadInt32(source, offset + 4),
            ReadInt32(source, offset + 8),
            ReadInt32(source, offset + 12),
            ReadInt32(source, offset + 16),
            ReadInt32(source, offset + 20));

    private static void ValidateBodyLength(int length)
    {
        if (length is < 0 or > MaximumBodySize)
        {
            throw new InvalidDataException(
                $"Vision body length must be between 0 and {MaximumBodySize}. Received={length}.");
        }
    }

    private static int ReadInt32(ReadOnlySpan<byte> source, int offset) =>
        BinaryPrimitives.ReadInt32LittleEndian(source.Slice(offset, sizeof(int)));

    private static double ReadDouble(ReadOnlySpan<byte> source, int offset)
    {
        var bits = BinaryPrimitives.ReadInt64LittleEndian(source.Slice(offset, sizeof(long)));
        return BitConverter.Int64BitsToDouble(bits);
    }

    private static void WriteInt32(Span<byte> destination, int offset, int value) =>
        BinaryPrimitives.WriteInt32LittleEndian(destination.Slice(offset, sizeof(int)), value);

    private static void WriteDouble(Span<byte> destination, int offset, double value) =>
        BinaryPrimitives.WriteInt64LittleEndian(
            destination.Slice(offset, sizeof(long)),
            BitConverter.DoubleToInt64Bits(value));
}
