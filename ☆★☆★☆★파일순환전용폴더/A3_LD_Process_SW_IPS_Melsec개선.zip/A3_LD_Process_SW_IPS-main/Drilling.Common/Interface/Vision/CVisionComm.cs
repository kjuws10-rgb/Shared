using System.Collections.Concurrent;
using System.Globalization;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace Drilling.Common.Interface.Vision;

[CCommType("SocketServer", "Vision")]
internal sealed class CVisionComm(
    ST_INTERFACE_DATA data,
    ST_INTERFACE_CONNECT_OPTION option) : CCommBase(data, option)
{
    private readonly ConcurrentDictionary<int, TaskCompletionSource<ST_VISION_PACKET>> _pending = new();
    private readonly SemaphoreSlim _lifecycleLock = new(1, 1);
    private readonly SemaphoreSlim _writeLock = new(1, 1);
    private readonly SemaphoreSlim _clientReady = new(0, 1);
    private TcpListener? _listener;
    private TcpClient? _client;
    private NetworkStream? _stream;
    private CancellationTokenSource? _serverCancellation;
    private Task? _acceptTask;
    private Task? _receiveTask;
    private int _uniqueId;

    internal event Action<ST_COMM_PROTOCOL_TRACE>? ProtocolTrace;

    public override async Task Connect(CancellationToken cancellationToken = default)
    {
        await _lifecycleLock.WaitAsync(cancellationToken);
        try
        {
            if (_listener is not null &&
                _serverCancellation is not null &&
                !_serverCancellation.IsCancellationRequested)
            {
                LastError = "";
                SetState(EN_COMM_STATE.Online);
                return;
            }

            await StopServer();
            if (Option.Port <= 0)
            {
                SetError("Vision server port is invalid.");
                return;
            }

            var listener = new TcpListener(ResolveBindAddress(Option.LocalAddress), Option.Port);
            listener.Start(1);
            _listener = listener;
            _serverCancellation = new CancellationTokenSource();
            Task AcceptLoopCallback()
            {
                return AcceptLoop(listener, _serverCancellation.Token);
            }

            _acceptTask = Task.Run(AcceptLoopCallback, CancellationToken.None);
            LastSent = "";
            LastReceived = "";
            LastError = "";
            SetState(EN_COMM_STATE.Online);
            RaiseProtocolTrace("INFO", $"SERVER_LISTENING:{Option.Endpoint}");
        }
        catch (Exception ex) when (ex is SocketException or ArgumentException or InvalidOperationException)
        {
            await StopServer();
            SetError(ex);
        }
        finally
        {
            _lifecycleLock.Release();
        }
    }

    public override async Task Disconnect(CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        await _lifecycleLock.WaitAsync(cancellationToken);
        try
        {
            await StopServer();
            SetState(EN_COMM_STATE.Offline);
        }
        finally
        {
            _lifecycleLock.Release();
        }
    }

    public override async Task<string> Execute(
        string function,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var commandText = function.Trim();
            if (commandText.Equals("STATUS", StringComparison.OrdinalIgnoreCase))
            {
                LastSent = commandText;
                LastReceived = _client is { Connected: true }
                    ? "OK:VISION:CLIENT_CONNECTED"
                    : "OK:VISION:WAITING_CLIENT";
                LastError = "";
                return LastReceived;
            }

            if (_listener is null)
            {
                await Connect(cancellationToken);
            }

            var stream = await WaitForClient(cancellationToken);
            var request = ParseRequest(commandText, NextUniqueId());
            var response = await SendRequest(stream, request, cancellationToken);
            LastReceived = DescribeResponse(response);
            LastError = "";
            SetState(EN_COMM_STATE.Online);

            return LastReceived;
        }
        catch (Exception ex) when (ex is
            SocketException or IOException or InvalidDataException or
            InvalidOperationException or FormatException or TimeoutException or
            OperationCanceledException)
        {
            if (ex is OperationCanceledException && cancellationToken.IsCancellationRequested)
            {
                throw;
            }

            SetCommandError(ex.Message);
            return "";
        }
    }

    private async Task AcceptLoop(
        TcpListener listener,
        CancellationToken cancellationToken)
    {
        while (!cancellationToken.IsCancellationRequested)
        {
            TcpClient? client = null;
            try
            {
                client = await listener.AcceptTcpClientAsync(cancellationToken);
                client.NoDelay = true;
                ReplaceClient(client, cancellationToken);
            }
            catch (Exception ex) when (
                cancellationToken.IsCancellationRequested ||
                ex is ObjectDisposedException or SocketException or OperationCanceledException)
            {
                client?.Dispose();
                if (!cancellationToken.IsCancellationRequested)
                {
                    LastError = ex.Message;
                    LastChangedAt = DateTimeOffset.Now;
                }
            }
        }
    }

    private void ReplaceClient(
        TcpClient client,
        CancellationToken cancellationToken)
    {
        _client?.Dispose();
        _client = client;
        _stream = client.GetStream();
        Task ReceiveLoopCallback()
        {
            return ReceiveLoop(client, _stream, cancellationToken);
        }

        _receiveTask = Task.Run(ReceiveLoopCallback, CancellationToken.None);
        if (_clientReady.CurrentCount == 0)
        {
            _clientReady.Release();
        }

        LastError = "";
        SetState(EN_COMM_STATE.Online);
        RaiseProtocolTrace(
            "INFO",
            $"CLIENT_CONNECTED:{client.Client.RemoteEndPoint?.ToString() ?? "UNKNOWN"}");
    }

    private async Task ReceiveLoop(
        TcpClient client,
        NetworkStream stream,
        CancellationToken cancellationToken)
    {
        try
        {
            while (!cancellationToken.IsCancellationRequested && client.Connected)
            {
                var packet = await ReadPacket(stream, cancellationToken);
                LastReceived = DescribePacket(packet);
                LastChangedAt = DateTimeOffset.Now;
                if (packet.Header.Command == (int)EN_VISION_COMMAND.KeepAlive)
                {
                    LastError = "";
                    SetState(EN_COMM_STATE.Online);
                }

                RaiseProtocolTrace(
                    "PACKET",
                    CVisionProtocol.FormatPacketLog(
                        "RECV",
                        packet,
                        $"{Data.NickName}[{Data.Number}]"));

                if (packet.Header.Command == (int)EN_VISION_COMMAND.KeepAlive)
                {
                    await SendPacket(
                        stream,
                        CVisionProtocol.CreateEmpty(
                            EN_VISION_COMMAND.KeepAlive,
                            packet.Header.UniqueId,
                            packet.Header.ErrorCode),
                        cancellationToken);
                    continue;
                }

                if (packet.Header.Command == (int)EN_VISION_COMMAND.MarkFindManual)
                {
                    await SendPacket(
                        stream,
                        CVisionProtocol.CreateEmpty(
                            EN_VISION_COMMAND.MarkFindManual,
                            packet.Header.UniqueId),
                        cancellationToken);
                    continue;
                }

                if (_pending.TryRemove(packet.Header.UniqueId, out var completion))
                {
                    completion.TrySetResult(packet);
                }
            }
        }
        catch (Exception ex) when (ex is
            SocketException or IOException or InvalidDataException or
            ObjectDisposedException or OperationCanceledException)
        {
            if (!cancellationToken.IsCancellationRequested)
            {
                LastError = ex.Message;
                LastChangedAt = DateTimeOffset.Now;
            }
        }
        finally
        {
            if (ReferenceEquals(_client, client))
            {
                _stream = null;
                _client = null;
                while (_clientReady.CurrentCount > 0)
                {
                    _clientReady.Wait(0);
                }

                FailPending(new IOException("Vision client disconnected."));
                LastError = "Vision client disconnected.";
                SetState(IsServerListening()
                    ? EN_COMM_STATE.Online
                    : EN_COMM_STATE.Offline);
                RaiseProtocolTrace("INFO", "CLIENT_DISCONNECTED");
            }

            client.Dispose();
        }
    }

    private async Task<NetworkStream> WaitForClient(
        CancellationToken cancellationToken)
    {
        if (_stream is not null && _client is { Connected: true })
        {
            return _stream;
        }

        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeout.CancelAfter(Math.Max(100, Option.TimeoutMs));
        try
        {
            await _clientReady.WaitAsync(timeout.Token);
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            throw new TimeoutException("Vision client connection timeout.");
        }

        return _stream ?? throw new IOException("Vision client disconnected before command transmission.");
    }

    private async Task<ST_VISION_PACKET> SendRequest(
        NetworkStream stream,
        ST_VISION_PACKET request,
        CancellationToken cancellationToken)
    {
        var completion = new TaskCompletionSource<ST_VISION_PACKET>(
            TaskCreationOptions.RunContinuationsAsynchronously);
        if (!_pending.TryAdd(request.Header.UniqueId, completion))
        {
            throw new InvalidOperationException(
                $"Vision Unique ID is already pending: {request.Header.UniqueId}.");
        }

        try
        {
            await SendPacket(stream, request, cancellationToken);
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            timeout.CancelAfter(Math.Max(100, Option.TimeoutMs));
            try
            {
                var response = await completion.Task.WaitAsync(timeout.Token);
                if (response.Header.Command != request.Header.Command)
                {
                    throw new InvalidDataException(
                        $"Vision response command mismatch. Request={request.Header.Command}, Response={response.Header.Command}.");
                }

                if (response.Header.ErrorCode != 0 && response.Header.Command != (int)EN_VISION_COMMAND.FlyingMoveDone)
                {
                    throw new InvalidDataException(
                        $"Vision returned error code {response.Header.ErrorCode} for command {response.Header.Command}.");
                }

                return response;
            }
            catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
            {
                throw new TimeoutException(
                    $"Vision command {request.Header.Command} response timeout.");
            }
        }
        finally
        {
            _pending.TryRemove(request.Header.UniqueId, out _);
        }
    }

    private async Task SendPacket(
        NetworkStream stream,
        ST_VISION_PACKET packet,
        CancellationToken cancellationToken)
    {
        var bytes = CVisionProtocol.Encode(packet);
        await _writeLock.WaitAsync(cancellationToken);
        try
        {
            await stream.WriteAsync(bytes, cancellationToken);
            await stream.FlushAsync(cancellationToken);
            LastSent = DescribePacket(packet);
            LastChangedAt = DateTimeOffset.Now;
            RaiseProtocolTrace(
                "PACKET",
                CVisionProtocol.FormatPacketLog(
                    "SEND",
                    packet,
                    $"{Data.NickName}[{Data.Number}]"));
        }
        finally
        {
            _writeLock.Release();
        }
    }

    private static async Task<ST_VISION_PACKET> ReadPacket(
        NetworkStream stream,
        CancellationToken cancellationToken)
    {
        var headerBytes = new byte[CVisionProtocol.HeaderSize];
        await stream.ReadExactlyAsync(headerBytes, cancellationToken);
        var header = CVisionProtocol.DecodeHeader(headerBytes);
        var body = new byte[header.DataLength];
        if (body.Length > 0)
        {
            await stream.ReadExactlyAsync(body, cancellationToken);
        }

        return new ST_VISION_PACKET(header, body);
    }

    private static ST_VISION_PACKET ParseRequest(
        string function,
        int uniqueId)
    {
        var fields = function.Split(':', 2, StringSplitOptions.TrimEntries);
        var command = NormalizeCommand(fields[0]);
        var body = fields.Length > 1 ? fields[1] : "";
        return command switch
        {
            EN_VISION_COMMAND.MarkFindSingle => CVisionProtocol.CreateMarkFindSingle(uniqueId, ParseMarkSearch(body)),
            EN_VISION_COMMAND.FlyingReady => ParseFlyingReady(uniqueId, body),
            EN_VISION_COMMAND.FlyingMoveDone => CVisionProtocol.CreateEmpty(command, uniqueId),
            EN_VISION_COMMAND.MarkFindLine => CVisionProtocol.CreateEmpty(command, uniqueId),
            EN_VISION_COMMAND.MarkFindSettingSingle => CVisionProtocol.CreateEmpty(command, uniqueId),
            EN_VISION_COMMAND.KeepAliveRequest => CVisionProtocol.CreateEmpty(command, 0),
            _ => throw new InvalidOperationException(
                $"Vision command cannot be sent by Process: {(int)command}.")
        };
    }

    private static ST_VISION_PACKET ParseFlyingReady(
        int uniqueId,
        string body)
    {
        var parts = body.Split(':', 2, StringSplitOptions.TrimEntries);
        if (parts.Length == 0 ||
            !int.TryParse(parts[0], NumberStyles.Integer, CultureInfo.InvariantCulture, out var inspectionType))
        {
            throw new FormatException(
                "FLYING_READY format: FLYING_READY:type:cell,doe,line,indexX,indexY,head;...");
        }

        var searches = new List<ST_VISION_MARK_SEARCH>();
        if (parts.Length > 1 && !string.IsNullOrWhiteSpace(parts[1]))
        {
            var values = parts[1].Split(
                ';',
                StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            foreach (var value in values)
            {
                searches.Add(ParseMarkSearch(value));
            }
        }

        return CVisionProtocol.CreateFlyingReady(uniqueId, inspectionType, searches);
    }

    private static ST_VISION_MARK_SEARCH ParseMarkSearch(string value)
    {
        var fields = value.Split(',', StringSplitOptions.TrimEntries);
        if (fields.Length != 6)
        {
            throw new FormatException(
                "Mark Search format: cell,doe,line,indexX,indexY,head");
        }

        return new ST_VISION_MARK_SEARCH(
            ParseInt(fields[0], "cell"),
            ParseInt(fields[1], "doe"),
            ParseInt(fields[2], "line"),
            ParseInt(fields[3], "indexX"),
            ParseInt(fields[4], "indexY"),
            ParseInt(fields[5], "head"));
    }

    private static EN_VISION_COMMAND NormalizeCommand(string value)
    {
        var normalized = value.Trim().Replace("-", "_", StringComparison.Ordinal).ToUpperInvariant();
        return normalized switch
        {
            "1000" or "MARK_FIND_SINGLE" => EN_VISION_COMMAND.MarkFindSingle,
            "1001" or "FLYING_READY" => EN_VISION_COMMAND.FlyingReady,
            "1002" or "FLYING_MOVE_DONE" => EN_VISION_COMMAND.FlyingMoveDone,
            "1003" or "MARK_FIND_LINE" => EN_VISION_COMMAND.MarkFindLine,
            "1010" or "MARK_FIND_SETTING_SINGLE" => EN_VISION_COMMAND.MarkFindSettingSingle,
            "1900" or "KEEP_ALIVE_REQUEST" => EN_VISION_COMMAND.KeepAliveRequest,
            _ => throw new InvalidOperationException($"Unsupported Vision command: {value}.")
        };
    }

    private static int ParseInt(string value, string name) =>
        int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var result)
            ? result
            : throw new FormatException($"Vision {name} must be an integer. Value={value}.");

    private static string DescribeResponse(ST_VISION_PACKET packet)
    {
        // 1002 NCK is a valid protocol reply (Count mismatch), not a disconnected socket.
        // The sequence decides whether to retry; do not turn it into an empty response.
        if (packet.Header.Command == (int)EN_VISION_COMMAND.FlyingMoveDone && packet.Header.ErrorCode != 0)
            return $"NCK:1002:UID={packet.Header.UniqueId}:ERROR={packet.Header.ErrorCode}";
        if (packet.Header.Command is
            (int)EN_VISION_COMMAND.MarkFindSingle or
            (int)EN_VISION_COMMAND.MarkFindSettingSingle or
            (int)EN_VISION_COMMAND.MarkFindManual)
        {
            var result = CVisionProtocol.DecodeSingleResult(packet);
            return string.Create(
                CultureInfo.InvariantCulture,
                $"OK:{packet.Header.Command}:UID={packet.Header.UniqueId}:RESOLUTION={result.Resolution}:RESULT={result.Mark.Result}:TARGET_X={result.Mark.TargetMarkX:R}:TARGET_Y={result.Mark.TargetMarkY:R}:HOLE_X={result.Mark.HoleX:R}:HOLE_Y={result.Mark.HoleY:R}");
        }

        if (packet.Header.Command == (int)EN_VISION_COMMAND.MarkFindLine)
        {
            var result = CVisionProtocol.DecodeLineResult(packet);
            var builder = new StringBuilder();
            builder.Append("OK:")
                .Append(packet.Header.Command)
                .Append(":UID=")
                .Append(packet.Header.UniqueId)
                .Append(":RESOLUTION=")
                .Append(result.Resolution)
                .Append(":COUNT=")
                .Append(result.FindHoleCount)
                .Append(":MARKS=");

            for (var index = 0; index < result.Marks.Count; index++)
            {
                if (index > 0)
                {
                    builder.Append(';');
                }

                var mark = result.Marks[index];
                builder.Append(mark.Result)
                    .Append(',')
                    .Append(mark.TargetMarkX.ToString("R", CultureInfo.InvariantCulture))
                    .Append(',')
                    .Append(mark.TargetMarkY.ToString("R", CultureInfo.InvariantCulture))
                    .Append(',')
                    .Append(mark.HoleX.ToString("R", CultureInfo.InvariantCulture))
                    .Append(',')
                    .Append(mark.HoleY.ToString("R", CultureInfo.InvariantCulture));
            }

            return builder.ToString();
        }

        return $"OK:{packet.Header.Command}:UID={packet.Header.UniqueId}";
    }

    private static string DescribePacket(ST_VISION_PACKET packet) =>
        $"CMD={packet.Header.Command},LEN={packet.Header.DataLength},UID={packet.Header.UniqueId},ERR={packet.Header.ErrorCode}";

    private int NextUniqueId()
    {
        var value = Interlocked.Increment(ref _uniqueId);
        if (value > 0)
        {
            return value;
        }

        Interlocked.Exchange(ref _uniqueId, 1);
        return 1;
    }

    private void RaiseProtocolTrace(string direction, string message)
    {
        ProtocolTrace?.Invoke(new ST_COMM_PROTOCOL_TRACE(
            DateTimeOffset.Now,
            direction,
            message));
    }

    private bool IsServerListening()
    {
        return _listener is not null &&
               _serverCancellation is not null &&
               !_serverCancellation.IsCancellationRequested;
    }

    private async Task StopServer()
    {
        _serverCancellation?.Cancel();
        _listener?.Stop();
        _client?.Dispose();
        if (_acceptTask is not null)
        {
            await IgnoreCancellation(_acceptTask);
        }

        if (_receiveTask is not null)
        {
            await IgnoreCancellation(_receiveTask);
        }

        _serverCancellation?.Dispose();
        _serverCancellation = null;
        _listener = null;
        _client = null;
        _stream = null;
        _acceptTask = null;
        _receiveTask = null;
        while (_clientReady.CurrentCount > 0)
        {
            _clientReady.Wait(0);
        }

        FailPending(new IOException("Vision server stopped."));
    }

    private void FailPending(Exception exception)
    {
        foreach (var item in _pending.ToArray())
        {
            if (_pending.TryRemove(item.Key, out var completion))
            {
                completion.TrySetException(exception);
            }
        }
    }

    private static async Task IgnoreCancellation(Task task)
    {
        try
        {
            await task;
        }
        catch (Exception ex) when (ex is OperationCanceledException or ObjectDisposedException or SocketException or IOException)
        {
        }
    }

    private static IPAddress ResolveBindAddress(string value)
    {
        if (string.IsNullOrWhiteSpace(value) || value == "*")
        {
            return IPAddress.Any;
        }

        return IPAddress.TryParse(value, out var address)
            ? address
            : throw new ArgumentException($"Vision server local address is invalid: {value}");
    }
}
