using System.Collections.Concurrent;
using Drilling.Common.Motion;

namespace Drilling.Common.Interface;

public partial class CInterfaceManager
{
    private readonly ConcurrentDictionary<int, CManualStageMotionSimulation> _stageMotionSimulations = new();

    /// <summary>One shared motion model per MELSEC device, independent of the selected menu.</summary>
    public CManualStageMotionSimulation GetStageMotionSimulation(int? deviceNo = null)
    {
        var number = deviceNo ?? Melsec.Map.FirstOrDefault(row =>
            row.Id.Equals("MOTOR_STAGE_Y_CUR_POS", StringComparison.OrdinalIgnoreCase))?.DeviceNo
            ?? GetInterfaceList(EN_EQP_MODULE.Melsec).FirstOrDefault()?.Number ?? 0;
        return _stageMotionSimulations.GetOrAdd(number, _ => new());
    }

    public IReadOnlyDictionary<string, double> GetStageMotionSimulationFeedback(int? deviceNo = null)
    {
        var axes = GetStageMotionSimulation(deviceNo).GetSnapshot();
        var stage = axes.Single(row => row.Axis == EN_MANUAL_STAGE_AXIS.StageY);
        var review = axes.Single(row => row.Axis == EN_MANUAL_STAGE_AXIS.ReviewX);
        return new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase)
        {
            ["MOTOR_STAGE_Y_CUR_POS"] = stage.Position,
            ["MOTOR_STAGE_Y_CUR_SPEED"] = stage.Speed,
            ["MOTOR_STAGE_Y_BUSY"] = stage.IsMoving ? 1 : 0,
            ["MOTOR_CAMERA_X_CUR_POS"] = review.Position,
            ["MOTOR_CAMERA_X_CUR_SPEED"] = review.Speed,
            ["MOTOR_CAMERA_X_BUSY"] = review.IsMoving ? 1 : 0,
            ["MOTOR_WINDOW_Y_CUR_POS"] = 0,
            ["MOTOR_WINDOW_Y_CUR_SPEED"] = 0
        };
    }
}
