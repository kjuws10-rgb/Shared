using Drilling.Common.Managers;

namespace Drilling.Common.Interface;

public partial class CInterfaceManager
{
    public Task<ST_LASER_STATUS> ReadLaserStatusAsync(CancellationToken token)
    {
        token.ThrowIfCancellationRequested();
        var data = GetTalonInterfaceData();
        if (data is null) return Task.FromResult(new ST_LASER_STATUS(false, false, false, 0));
        if (!IsSimul(data.Device, data.Number) && !IsConnect(data.Device, data.Number))
            throw new IOException("LASER가 연결되어 있지 않아 상태 수집을 보류합니다.");
        var snapshot = OpticSnapshots.GetLaser(data.Number);
        return Task.FromResult(snapshot.Value ?? throw new IOException($"LASER {snapshot.State}: {snapshot.Detail}"));
    }

    public Task<ST_BET_STATUS> ReadBetStatusAsync(CancellationToken token)
    {
        token.ThrowIfCancellationRequested();
        var data = GetBETInterfaceData();
        if (data is null) return Task.FromResult(CreateDefaultBETStatus());
        if (!IsSimul(data.Device, data.Number) && !IsConnect(data.Device, data.Number))
            throw new IOException("BET가 연결되어 있지 않아 상태 수집을 보류합니다.");
        var snapshot = OpticSnapshots.GetBet(data.Number);
        return Task.FromResult(snapshot.Value ?? throw new IOException($"BET {snapshot.State}: {snapshot.Detail}"));
    }
}
