using System.IO;

namespace Drilling.Common.Interface;

public partial class CInterfaceManager
{
    private readonly SemaphoreSlim _reloadLock = new(1, 1);

    /// <summary>Applies changed rows only. Unchanged devices retain their live connection and status.</summary>
    public async Task Reload(IReadOnlyList<ST_INTERFACE_DATA> interfaces, bool reconnect = true, CancellationToken cancellationToken = default)
    {
        await _reloadLock.WaitAsync(cancellationToken);
        try
        {
            var requested = new Dictionary<string, ST_INTERFACE_DATA>(StringComparer.OrdinalIgnoreCase);
            foreach (var data in interfaces)
            {
                cancellationToken.ThrowIfCancellationRequested();
                if (!requested.TryAdd(CreateDeviceKey(data.Device, data.Number), data))
                    throw new InvalidDataException($"Duplicated interface DEVICE/NUMBER: {FormatDeviceName(data)}");
            }

            // Compare collection contents, since Setting creates new argument arrays on every Save.
            var replacements = requested.Where(pair => !_devices.TryGetValue(pair.Key, out var current) ||
                !SameInterfaceSettings(current.Data, pair.Value)).ToDictionary(pair => pair.Key,
                    pair => CreateDevice(pair.Value), StringComparer.OrdinalIgnoreCase);
            var retired = _devices.Where(pair => !requested.ContainsKey(pair.Key) || replacements.ContainsKey(pair.Key)).ToArray();
            if (retired.Length == 0 && replacements.Count == 0) return;

            // Prepare replacements before touching any connection, then retire only affected devices.
            foreach (var pair in retired)
            {
                cancellationToken.ThrowIfCancellationRequested();
                var device = pair.Value;
                if (device.Data.Device == EN_EQP_MODULE.Attenuator) AttenuatorSnapshots.Invalidate(device.Data.Number);
                if (device.Data.Device == EN_EQP_MODULE.Melsec)
                {
                    var before = device.ConnectionState;
                    _melsec.CloseDevice(device.Data.Number, cancellationToken);
                    device.SetExternalCommunicationState(EN_COMM_STATE.Offline, "CLOSE", "CLOSED", "");
                    WriteConnectionLog("DISCONNECT", device, before);
                }
                else
                {
                    await DisconnectDevice(device, cancellationToken);
                }
                if (device.Data.Device == EN_EQP_MODULE.PicoMotor) _picoMotorService.Disconnect(device.Data.Number);
                device.MessageReceived -= OnDeviceMessageReceived;
                device.ProtocolTrace -= OnDeviceProtocolTrace;
                _devices.TryRemove(pair.Key, out _);
                ClearDeviceState(device.Data);
            }

            foreach (var pair in replacements) _devices[pair.Key] = pair.Value;
            OpticSnapshots.Start();
            PruneDeviceStateMaps();

            foreach (var device in replacements.Values)
            {
                if (reconnect && device.Data.AutoConnection)
                    await ConnectDevice(device, autoConnection: true, cancellationToken);
                if (device.Data.Device == EN_EQP_MODULE.Attenuator)
                {
                    AttenuatorSnapshots.Invalidate(device.Data.Number, "LOADING", "ATT 연결 설정 변경 후 새 상태를 기다리고 있습니다.");
                    AttenuatorSnapshots.Start();
                }
            }
        }
        finally
        {
            _reloadLock.Release();
        }
    }

    private static bool SameInterfaceSettings(ST_INTERFACE_DATA left, ST_INTERFACE_DATA right)
    {
        if (left.InterfaceType != right.InterfaceType || left.Device != right.Device || left.Number != right.Number ||
            left.NickName.Trim() != right.NickName.Trim() || left.SystemSection.Trim() != right.SystemSection.Trim() ||
            left.AutoConnection != right.AutoConnection || left.IsSimulation != right.IsSimulation) return false;
        if (!left.Arguments.Concat(Enumerable.Repeat("", 5)).Take(5).Select(value => value.Trim()).SequenceEqual(
            right.Arguments.Concat(Enumerable.Repeat("", 5)).Take(5).Select(value => value.Trim()))) return false;
        var leftExtra = NormalizeExtra(left.Extra);
        var rightExtra = NormalizeExtra(right.Extra);
        return leftExtra.Count == rightExtra.Count && leftExtra.All(pair =>
            rightExtra.TryGetValue(pair.Key, out var value) && value == pair.Value);
    }

    private static Dictionary<string, string> NormalizeExtra(IReadOnlyDictionary<string, string>? extra)
        => (extra ?? new Dictionary<string, string>()).Where(pair => !string.IsNullOrWhiteSpace(pair.Value))
            .ToDictionary(pair => pair.Key.Trim(), pair => pair.Value.Trim(), StringComparer.OrdinalIgnoreCase);

    private void ClearDeviceState(ST_INTERFACE_DATA data)
    {
        OpticSnapshots.Invalidate(data.Device, data.Number);
        switch (data.Device)
        {
            case EN_EQP_MODULE.TalonLaser:
                _laserOnHeads.Remove(data.Number);
                _talonStatuses.TryRemove(data.Number, out _);
                break;
            case EN_EQP_MODULE.Attenuator:
                lock (_attenuatorStatusLock) _attenuatorStatuses.Remove(data.Number);
                AttenuatorSnapshots.Invalidate(data.Number);
                break;
            case EN_EQP_MODULE.Bet:
                _betStatuses.TryRemove(data.Number, out _);
                break;
            case EN_EQP_MODULE.PowerMeter:
                _powerMeterStatuses.TryRemove(data.Number, out _);
                _powerMeterSimulationAttenuators.Remove(data.Number);
                break;
        }
    }
}
