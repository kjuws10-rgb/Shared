using System.Diagnostics;
using System.Globalization;
using Drilling.Common.Automation;

namespace Drilling.Common.InterLock;

public static class CDoeZInterlock
{
    public static IReadOnlyList<ST_INTERLOCK_ITEM> Evaluate(IReadOnlyDictionary<string, string> parameters,
        Func<ST_SCANNER_AXIS_SETTING, ST_AUTOMATION_STATUS_SNAPSHOT<ST_AUTOMATION_AXIS_STATUS>> readSnapshot)
    {
        var items = new List<ST_INTERLOCK_ITEM>();
        for (var head = 1; head <= 8; head++)
        {
            var axis = CScannerAxisConfiguration.BuildAxisDefinitions(parameters, head)
                .FirstOrDefault(axis => axis.AxisName == "Z" && axis.IsUsed);
            if (axis.HeadNo == 0) continue;

            void Add(bool ready, string state, string detail) => items.Add(new("DOE Z Position",
                ready ? EN_INTERLOCK_LEVEL.Ok : EN_INTERLOCK_LEVEL.Error, state, detail)
                { Group = "HEAD", HeadNo = head, BlocksAutoRun = !ready });

            if (!string.IsNullOrEmpty(axis.ConfigurationError))
            {
                Add(false, "AXIS NG", axis.ConfigurationError);
                continue;
            }
            if (!ReadNumber(parameters, $"H{head:00}_DOE_Z_POSITION", out var target))
            {
                Add(false, "TARGET NG", "Recipe의 DOE Z 목표 위치를 확인해 주세요.");
                continue;
            }
            if (!ReadNumber(parameters, "DOE_Z_TOLERANCE", out var tolerance) || tolerance < 0)
            {
                Add(false, "SETTING NG", "Setting의 DOE Z Tolerance는 0 이상의 유한한 값이어야 합니다.");
                continue;
            }

            var snapshot = readSnapshot(axis);
            var age = snapshot.CollectedTimestamp > 0
                ? Stopwatch.GetElapsedTime(snapshot.CollectedTimestamp)
                : DateTimeOffset.UtcNow - snapshot.UpdatedAt;
            var fresh = snapshot.UpdatedAt != default && age >= TimeSpan.Zero && age <= TimeSpan.FromSeconds(5);
            if (snapshot.State != "OK" || snapshot.Value is not { } status || !fresh)
            {
                Add(false, snapshot.State == "OK" ? "STALE" : snapshot.State,
                    $"{axis.AxisReference}: 유효한 현재 위치 스냅샷이 필요합니다. {snapshot.Detail}");
                continue;
            }
            var position = status.PositionFeedback;
            var ready = double.IsFinite(position) && Math.Abs(position - target) <= tolerance + 1e-9;
            Add(ready, ready ? "OK" : "POSITION NG", FormattableString.Invariant(
                $"{axis.AxisReference}: Current {position:0.######} mm / Recipe {target:0.######} mm; Tolerance ±{tolerance:0.######} mm"));
        }
        return items;
    }

    private static bool ReadNumber(IReadOnlyDictionary<string, string> parameters, string key, out double value)
    {
        value = 0;
        return parameters.TryGetValue(key, out var text) &&
            double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out value) && double.IsFinite(value);
    }
}
