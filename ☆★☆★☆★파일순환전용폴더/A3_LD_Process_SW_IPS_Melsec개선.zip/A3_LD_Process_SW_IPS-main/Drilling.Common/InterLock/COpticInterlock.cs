using System.Globalization;
using Drilling.Common.Interface;

namespace Drilling.Common.InterLock;

/// <summary>Read-only recipe readiness checks. This class cannot issue a device command.</summary>
public static class COpticInterlock
{
    public const double PositionTolerance = 0.01;

    public static IReadOnlyList<ST_INTERLOCK_ITEM> Evaluate(IReadOnlyDictionary<string, string> parameters,
        IReadOnlyList<ST_INTERFACE_DATA> devices,
        Func<int, ST_SHARED_DEVICE_SNAPSHOT<ST_LASER_STATUS>> laser,
        Func<int, ST_SHARED_DEVICE_SNAPSHOT<ST_BET_STATUS>> bet,
        Func<int, ST_ATTENUATOR_STATUS_SNAPSHOT> attenuator)
    {
        var items = new List<ST_INTERLOCK_ITEM>();
        for (var head = 1; head <= 8; head++)
        {
            if (parameters.TryGetValue($"H{head:00}_USE", out var use) &&
                use.Trim().ToUpperInvariant() is "OFF" or "FALSE" or "0" or "NO") continue;
            var name = $"H{head:00}";
            void Add(string signal, bool ready, string detail, string state = "NOT READY") => items.Add(
                new($"{name} {signal}", ready ? EN_INTERLOCK_LEVEL.Ok : EN_INTERLOCK_LEVEL.Error,
                    ready ? "READY" : state, detail) { HeadNo = head, BlocksAutoRun = !ready });
            bool Registered(EN_EQP_MODULE module) => devices.Any(device => device.Device == module && device.Number == head - 1);

            if (Registered(EN_EQP_MODULE.TalonLaser))
            {
                var laserStatus = laser(head - 1);
                var laserValid = laserStatus is { State: "OK", Value: not null };
                var value = laserStatus.Value;
                Add("Laser ON", laserValid && value!.PowerOn, laserValid ? $"Laser={(value!.PowerOn ? "ON" : "OFF")}" : laserStatus.Detail, laserValid ? "OFF" : laserStatus.State);
                Add("Laser Gate", laserValid && value!.GateOn, laserValid ? $"Gate={(value!.GateOn ? "OPEN" : "CLOSE")}" : laserStatus.Detail, laserValid ? "CLOSE" : laserStatus.State);
                Add("Laser Shutter", laserValid && value!.ShutterOpen, laserValid ? $"Shutter={(value!.ShutterOpen ? "OPEN" : "CLOSE")}" : laserStatus.Detail, laserValid ? "CLOSE" : laserStatus.State);
            }

            if (Registered(EN_EQP_MODULE.Bet))
            {
                if (!ReadNumber(parameters, $"{name}_BET_MAGNIFICATION", out var targetMag) ||
                    !ReadNumber(parameters, $"{name}_BET_DIVERGENCE", out var targetDiv))
                    Add("BET Position", false, "레시피의 BET MAG/DIV 목표값을 확인해 주세요.", "TARGET NG");
                else
                {
                    var status = bet(head - 1);
                    var current = status.Value;
                    var ready = status.State == "OK" && current is { CommOk: true, AlarmOn: false, IsMoving: false, LastError: EN_BET_ERROR.Ok } &&
                        Near(current.CurrentMagnification, targetMag) && Near(current.CurrentDivergence, targetDiv);
                    Add("BET Position", ready, current is null ? status.Detail : FormattableString.Invariant(
                        $"MAG {current.CurrentMagnification:0.###} / Recipe {targetMag:0.###}, DIV {current.CurrentDivergence:0.###} / Recipe {targetDiv:0.###}; Tolerance ±{PositionTolerance}; Moving={current.IsMoving}, Alarm={current.AlarmOn}, Error={current.LastError}"),
                        status.State == "OK" ? "POS NG" : status.State);
                }
            }

            if (Registered(EN_EQP_MODULE.Attenuator))
            {
                if (!ReadNumber(parameters, $"{name}_ATTENUATOR_POSITION", out var targetAtt))
                    Add("ATT Position", false, "레시피의 ATT 목표각도를 확인해 주세요.", "TARGET NG");
                else
                {
                    var status = attenuator(head - 1);
                    var current = status?.Value;
                    var ready = status is { IsValid: true, IsInPosition: true } && status.IsFresh(TimeSpan.FromSeconds(2)) &&
                        current is not null && current.CommandState.Trim().ToUpperInvariant() is not ("MOVING" or "HOMING" or "BUSY") &&
                        Near(current.CurrentPosition, targetAtt);
                    Add("ATT Position", ready, current is null ? status?.Detail ?? "ATT가 등록되지 않았습니다." : FormattableString.Invariant(
                        $"Current {current.CurrentPosition:0.###}° / Recipe {targetAtt:0.###}°; Tolerance ±{PositionTolerance}°; InPosition={status!.IsInPosition}, State={current.CommandState}"),
                        status is { IsValid: true } && !status.IsFresh(TimeSpan.FromSeconds(2)) ? "STALE" : status is { IsValid: true } ? "POS NG" : status?.State ?? "N/C");
                }
            }
        }
        return items;
    }

    private static bool ReadNumber(IReadOnlyDictionary<string, string> parameters, string key, out double value)
    {
        value = 0;
        return parameters.TryGetValue(key, out var text) && double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out value) && double.IsFinite(value);
    }
    private static bool Near(double current, double target) => double.IsFinite(current) && Math.Abs(current - target) <= PositionTolerance + 1e-9;
}
