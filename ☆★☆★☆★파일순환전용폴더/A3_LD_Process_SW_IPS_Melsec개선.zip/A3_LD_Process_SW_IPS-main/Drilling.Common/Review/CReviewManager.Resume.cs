using Drilling.Common.Product;

namespace Drilling.Common.Review;

public sealed partial class CReviewManager
{
    private ST_REVIEW_PLAN? _interruptedReviewPlan;
    private string? _interruptedReviewProductId;

    private void RememberInterruptedReview(string? productId)
    {
        lock (_stateLock)
        {
            _interruptedReviewPlan = SequenceState is EN_REVIEW_SEQUENCE_STATE.Stopped or EN_REVIEW_SEQUENCE_STATE.Failed
                ? _currentPlan : null;
            _interruptedReviewProductId = productId;
        }
    }

    private ST_PRODUCT_REVIEW_DATA? FindInterruptedReviewCheckpoint(ST_REVIEW_PLAN plan, string? productId)
    {
        ST_REVIEW_PLAN? previous;
        lock (_stateLock)
        {
            if (!string.Equals(_interruptedReviewProductId ?? "", productId ?? "", StringComparison.OrdinalIgnoreCase)) return null;
            previous = _interruptedReviewPlan;
        }
        // Include a stop before the first result. A different recipe, Beam, target or method must never resume old results.
        if (previous is null || !previous.RecipeId.Equals(plan.RecipeId, StringComparison.OrdinalIgnoreCase) ||
            !previous.InspectionMethod.Equals(plan.InspectionMethod, StringComparison.OrdinalIgnoreCase) ||
            previous.VisionFlipType != plan.VisionFlipType || previous.ToleranceX != plan.ToleranceX || previous.ToleranceY != plan.ToleranceY ||
            previous.Points.Count != plan.Points.Count ||
            !previous.ReviewPoints.Any(point => point.State is EN_REVIEW_POINT_STATE.Ready or EN_REVIEW_POINT_STATE.Current)) return null;
        var points = previous.Points.ToDictionary(point => point.ShotKey, StringComparer.OrdinalIgnoreCase);
        foreach (var point in plan.Points)
            if (!points.TryGetValue(point.ShotKey, out var old) || old.Use != point.Use || old.HeadNo != point.HeadNo || old.BeamNo != point.BeamNo ||
                old.DesignX != point.DesignX || old.DesignY != point.DesignY || old.ReviewTargetX != point.ReviewTargetX || old.ReviewTargetY != point.ReviewTargetY)
                return null;
        return CreateProductReviewData(previous, DateTimeOffset.Now) with { State = EN_PRODUCT_PROCESS_STATE.Stopped };
    }

    private static IReadOnlyList<ST_REVIEW_PLAN_POINT> OrderLineFromCurrentPosition(
        IReadOnlyList<ST_REVIEW_PLAN_POINT> line, double currentReviewX)
    {
        var sorted = line.OrderBy(point => point.ReviewTargetX).ThenBy(point => point.CellNo).ThenBy(point => point.ShotNo).ToArray();
        return Math.Abs(currentReviewX - sorted[0].ReviewTargetX) <= Math.Abs(currentReviewX - sorted[^1].ReviewTargetX)
            ? sorted : sorted.Reverse().ToArray();
    }

    private IEnumerable<ST_REVIEW_PLAN_POINT> OrderPtoPFromCurrentPosition(IEnumerable<ST_REVIEW_PLAN_POINT> points, bool resume)
    {
        var rows = CreateIofLines(points.ToArray());
        for (var index = 0; index < rows.Count; index++)
        {
            // This iterator advances only after the previous row physically finishes.
            // A partial row may contain one remaining Shot; its old parity cannot determine the next direction.
            var row = resume || index > 0
                ? OrderLineFromCurrentPosition(rows[index], _reviewStageMotion!.ReviewXPosition)
                : rows[index];
            foreach (var point in row) yield return point;
        }
    }
}
