namespace Drilling.Common.Review;
public static class CReviewSampleRuleSelector
{
    public static IReadOnlyCollection<string> SelectEdgeShotKeys(ST_REVIEW_PLAN plan)
    {
        string SelectShotKey(global::Drilling.Common.Review.ST_REVIEW_PLAN_POINT point)
        {
            return point.ShotKey;
        }

        return plan.Points.Where(IsCellEdgeShot).Select(SelectShotKey).Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
    }

    public static IReadOnlyCollection<string> SelectCenterShotKeys(ST_REVIEW_PLAN plan)
    {
        string SelectShotKey(global::Drilling.Common.Review.ST_REVIEW_PLAN_POINT point)
        {
            return point.ShotKey;
        }

        return plan.Points.Where(IsCellCenterShot).Select(SelectShotKey).Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
    }

    private static bool IsCellEdgeShot(ST_REVIEW_PLAN_POINT point)
    {
        var columnCount = Math.Max(1, point.PixelCountX);
        var rowCount = Math.Max(1, point.PixelCountY);
        var zeroBasedShotNo = Math.Max(0, point.ShotNo - 1);
        var column = zeroBasedShotNo % columnCount;
        var row = zeroBasedShotNo / columnCount;
        return column == 0 || column == columnCount - 1 || row == 0 || row == rowCount - 1;
    }

    private static bool IsCellCenterShot(ST_REVIEW_PLAN_POINT point)
    {
        return !IsCellEdgeShot(point);
    }
}
