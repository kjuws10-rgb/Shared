using System.Collections.ObjectModel;

namespace Drilling.Common.Review;

/// <summary>Frozen run metadata. AUTO supplies its glass ID and Run Option choices when it starts FINE.</summary>
public sealed record ST_FINE_REVIEW_CONTEXT(string RecipeName, string GlassId, string Origin, int LinesPerCell,
    IReadOnlyDictionary<string, string> Parameters);

public sealed record ST_FINE_REVIEW_MONITOR(Guid RunId, long Revision, ST_FINE_REVIEW_REQUEST Request,
    ST_FINE_REVIEW_SNAPSHOT Progress, int StageDeviceNo, DateTimeOffset StartedAt,
    string OffsetFile = "");

/// <summary>Latest immutable FINE snapshot only. No device I/O, disk reads, UI callbacks or queued frames.</summary>
public sealed class CFineReviewMonitorStore
{
    private readonly object _gate = new();
    private ST_FINE_REVIEW_MONITOR? _latest;
    private long _revision;

    public ST_FINE_REVIEW_MONITOR? GetSnapshot() { lock (_gate) return _latest; }

    internal Guid Begin(ST_FINE_REVIEW_REQUEST request, int stageDeviceNo)
    {
        lock (_gate)
            if (_latest is { } staged && staged.RunId == request.PreparedMonitorRunId && staged.Progress.State == EN_REVIEW_SEQUENCE_STATE.Idle)
            {
                _latest = staged with { Revision = ++_revision, Progress = staged.Progress with
                    { State = EN_REVIEW_SEQUENCE_STATE.Running, Message = "FINE 검사 시작" } };
                return staged.RunId;
            }
        return Replace(request, stageDeviceNo, EN_REVIEW_SEQUENCE_STATE.Running, "검사 준비 중");
    }

    internal Guid Stage(ST_FINE_REVIEW_REQUEST request, int stageDeviceNo) =>
        Replace(request, stageDeviceNo, EN_REVIEW_SEQUENCE_STATE.Idle, "검사 계획 확정 · Stage Review START 대기");

    private Guid Replace(ST_FINE_REVIEW_REQUEST request, int stageDeviceNo, EN_REVIEW_SEQUENCE_STATE state, string message)
    {
        var context = request.Context;
        if (context is not null)
            request = request with { Context = context with { Parameters = new ReadOnlyDictionary<string, string>(
                new Dictionary<string, string>(context.Parameters, StringComparer.OrdinalIgnoreCase)) } };
        // Copy collection containers once. Published line/point records are immutable and reused between revisions.
        request = request with { Plan = request.Plan with { Points = Array.AsReadOnly(request.Plan.Points.ToArray()) },
            Lines = Array.AsReadOnly(request.Lines.Select(line => line with
            { Points = Array.AsReadOnly(line.Points.ToArray()) }).ToArray()) };
        var id = Guid.NewGuid();
        var initial = new ST_FINE_REVIEW_SNAPSHOT(request.Plan.RecipeId, request.Lines, state, message) { RunId = id };
        lock (_gate) _latest = new(id, ++_revision, request, initial, stageDeviceNo, DateTimeOffset.Now);
        return id;
    }

    internal void Publish(ST_FINE_REVIEW_SNAPSHOT snapshot)
    {
        lock (_gate)
            if (_latest is { } latest && latest.RunId == snapshot.RunId)
                _latest = latest with { Revision = ++_revision, Progress = snapshot };
    }

    public void MarkOffsetSaved(Guid runId, string file)
    {
        lock (_gate)
            if (_latest is { } latest && latest.RunId == runId && !string.IsNullOrWhiteSpace(file))
                _latest = latest with { Revision = ++_revision, OffsetFile = file };
    }
}
