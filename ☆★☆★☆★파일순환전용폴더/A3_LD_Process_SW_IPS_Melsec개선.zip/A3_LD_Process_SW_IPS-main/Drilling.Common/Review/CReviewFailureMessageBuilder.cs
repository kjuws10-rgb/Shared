using System.Text;

namespace Drilling.Common.Review;

public sealed record ST_REVIEW_FAILURE_MESSAGE(
    string Stage,
    string Cause,
    string Action,
    string AdditionalCause = "")
{
    public string ToDisplayText()
    {
        var builder = new StringBuilder();
        builder.AppendLine("검사를 완료하지 못했습니다.")
            .AppendLine()
            .Append("실패 단계: ")
            .AppendLine(Stage)
            .Append("원인: ")
            .AppendLine(Cause)
            .Append("확인 사항: ")
            .Append(Action);

        if (!string.IsNullOrWhiteSpace(AdditionalCause))
        {
            builder.AppendLine()
                .Append("추가 오류: ")
                .Append(AdditionalCause);
        }

        return builder.ToString();
    }
}

public static class CReviewFailureMessageBuilder
{
    private const string ProductUpdateFailureMarker = " Product Review state update failed: ";

    public static ST_REVIEW_FAILURE_MESSAGE Create(Exception exception)
    {
        ArgumentNullException.ThrowIfNull(exception);
        return Create(exception.Message);
    }

    public static ST_REVIEW_FAILURE_MESSAGE Create(string? message)
    {
        var normalizedMessage = string.IsNullOrWhiteSpace(message)
            ? "Review 검사 중 알 수 없는 오류가 발생했습니다."
            : message.Trim();
        var productStateFailure = normalizedMessage.Contains(
            ProductUpdateFailureMarker,
            StringComparison.OrdinalIgnoreCase);
        var primaryMessage = normalizedMessage;
        var additionalMessage = "";
        var markerIndex = normalizedMessage.IndexOf(
            ProductUpdateFailureMarker,
            StringComparison.OrdinalIgnoreCase);
        if (markerIndex >= 0)
        {
            primaryMessage = normalizedMessage[..markerIndex].Trim();
            additionalMessage = normalizedMessage[(markerIndex + ProductUpdateFailureMarker.Length)..].Trim();
        }

        var primary = Classify(primaryMessage, productStateFailure);
        var additionalCause = "";
        if (!string.IsNullOrWhiteSpace(additionalMessage))
        {
            var additional = Classify(additionalMessage, true);
            if (!additional.Cause.Equals(primary.Cause, StringComparison.Ordinal))
            {
                additionalCause = $"검사 실패 상태를 저장하지 못했습니다. {additional.Cause}";
            }
        }

        return new ST_REVIEW_FAILURE_MESSAGE(
            primary.Stage,
            primary.Cause,
            primary.Action,
            additionalCause);
    }

    private static ST_REVIEW_FAILURE_PART Classify(
        string message,
        bool productStateFailure)
    {
        if (Contains(message, "being used by another process") ||
            Contains(message, "다른 프로세스에서 사용 중"))
        {
            return new ST_REVIEW_FAILURE_PART(
                productStateFailure ? "검사 상태 저장" : "검사 파일 저장",
                productStateFailure
                    ? "검사 상태 파일이 다른 프로그램에서 사용 중입니다."
                    : "검사 관련 파일이 다른 프로그램에서 사용 중입니다.",
                "열려 있는 CSV 또는 중복 실행된 Drilling 프로그램을 닫고 다시 시도해 주세요.");
        }

        if (Contains(message, "access to the path") ||
            Contains(message, "access is denied") ||
            Contains(message, "UnauthorizedAccessException"))
        {
            return new ST_REVIEW_FAILURE_PART(
                productStateFailure ? "검사 상태 저장" : "검사 파일 저장",
                "검사 관련 파일에 쓸 수 있는 권한이 없습니다.",
                "파일의 읽기 전용 상태와 폴더 쓰기 권한을 확인해 주세요.");
        }

        if (Contains(message, "Vision Mark Find Line count mismatch"))
        {
            var requested = ReadValue(message, "Requested=");
            var received = ReadValue(message, "Received=");
            var countText = string.IsNullOrWhiteSpace(requested) || string.IsNullOrWhiteSpace(received)
                ? ""
                : $" (요청 {requested}, 수신 {received})";
            return new ST_REVIEW_FAILURE_PART(
                "Vision 결과 검증",
                $"IOF 결과 개수가 요청 개수와 다릅니다.{countText}",
                "테스트 클라이언트의 응답 개수와 해당 Line의 검사 대상 수를 확인해 주세요.");
        }

        if (Contains(message, "Vision Mark Find Line result array mismatch"))
        {
            var header = ReadValue(message, "Header=");
            var body = ReadValue(message, "Body=");
            var countText = string.IsNullOrWhiteSpace(header) || string.IsNullOrWhiteSpace(body)
                ? ""
                : $" (헤더 {header}, 결과 {body})";
            return new ST_REVIEW_FAILURE_PART(
                "Vision 결과 검증",
                $"IOF 응답의 결과 배열 개수가 올바르지 않습니다.{countText}",
                "Vision 응답의 COUNT와 실제 결과 배열 개수를 확인해 주세요.");
        }

        if (Contains(message, "Vision Mark Find Single response is empty"))
        {
            return new ST_REVIEW_FAILURE_PART(
                "Vision 응답 확인",
                AppendShot("P2P 검사 응답이 없습니다.", message),
                "Vision 또는 테스트 클라이언트가 명령 1000에 응답하는지 확인해 주세요.");
        }

        if (Contains(message, "Vision Flying Ready response is empty"))
        {
            return new ST_REVIEW_FAILURE_PART(
                "Vision 응답 확인",
                "IOF 검사 준비 응답이 없습니다.",
                "Vision 또는 테스트 클라이언트가 명령 1001에 응답하는지 확인해 주세요.");
        }

        if (Contains(message, "Vision Flying Move Done response is empty"))
        {
            return new ST_REVIEW_FAILURE_PART(
                "Vision 응답 확인",
                "IOF 이동 완료 응답이 없습니다.",
                "Vision 또는 테스트 클라이언트가 명령 1002에 응답하는지 확인해 주세요.");
        }

        if (Contains(message, "Vision Mark Find Line response is empty"))
        {
            return new ST_REVIEW_FAILURE_PART(
                "Vision 응답 확인",
                "IOF 검사 결과 응답이 없습니다.",
                "Vision 또는 테스트 클라이언트가 명령 1003에 응답하는지 확인해 주세요.");
        }

        if (Contains(message, "Vision client connection timeout") ||
            Contains(message, "Vision client disconnected") ||
            Contains(message, "Vision client is not connected"))
        {
            return new ST_REVIEW_FAILURE_PART(
                "Vision 연결 확인",
                "Vision 클라이언트가 연결되어 있지 않거나 연결이 끊어졌습니다.",
                "상단 Vision 상태와 Vision 또는 테스트 클라이언트의 연결을 확인해 주세요.");
        }

        if (Contains(message, "timeout") && Contains(message, "Vision"))
        {
            return new ST_REVIEW_FAILURE_PART(
                "Vision 응답 확인",
                "정해진 시간 안에 Vision 응답을 받지 못했습니다.",
                "Vision 연결 상태와 해당 명령의 처리 시간을 확인해 주세요.");
        }

        if (Contains(message, "Vision") &&
            (Contains(message, "response is invalid") ||
             Contains(message, "header is invalid") ||
             Contains(message, "has no result array") ||
             Contains(message, "result is invalid")))
        {
            return new ST_REVIEW_FAILURE_PART(
                "Vision 결과 해석",
                AppendShot("Vision 응답 형식이 올바르지 않습니다.", message),
                "Vision 프로토콜의 Body, COUNT, 배열 형식을 확인해 주세요.");
        }

        if (Contains(message, "Review Glass ID mismatch") ||
            Contains(message, "Product changed"))
        {
            return new ST_REVIEW_FAILURE_PART(
                "Glass 연결 확인",
                "검사 대상 Glass가 현재 활성 Glass와 일치하지 않습니다.",
                "Monitor의 Glass ID와 Review 화면의 Glass ID를 확인해 주세요.");
        }

        if (Contains(message, "Review Recipe mismatch"))
        {
            return new ST_REVIEW_FAILURE_PART(
                "Recipe 연결 확인",
                "Glass에 연결된 Recipe와 Review Recipe가 일치하지 않습니다.",
                "현재 Glass의 Recipe와 상단 선택 Recipe를 확인해 주세요.");
        }

        if (Contains(message, "not assigned to a processing Head"))
        {
            return new ST_REVIEW_FAILURE_PART(
                "검사 계획 생성",
                "선택한 Shot에 처리 Head가 배정되지 않았습니다.",
                "Recipe의 Cell 및 Head 배정을 확인해 주세요.");
        }

        if (Contains(message, "Executable review point is empty") ||
            Contains(message, "Ready review point is empty") ||
            Contains(message, "Review plan is empty") ||
            Contains(message, "Vision IOF line is empty"))
        {
            return new ST_REVIEW_FAILURE_PART(
                "검사 계획 생성",
                "실행할 수 있는 Review Shot이 없습니다.",
                "Shot 선택, Rule 조건, Head 배정 및 제외 조건을 확인해 주세요.");
        }

        if (Contains(message, "MAX_CELL_NUMBER") ||
            Contains(message, "PIXEL_SIZE") ||
            Contains(message, "SPLITED_BEAM_COUNT") ||
            Contains(message, "Review coordinate setting") ||
            Contains(message, "DOE pitch") ||
            Contains(message, "non-finite review target"))
        {
            return new ST_REVIEW_FAILURE_PART(
                "Recipe 값 검증",
                "Review 계산에 필요한 Recipe 값이 올바르지 않습니다.",
                "팝업 발생 전 선택한 Recipe의 Cell, Pitch, Beam 및 좌표 설정을 확인해 주세요.");
        }

        if (Contains(message, "could not find file") ||
            Contains(message, "FileNotFoundException"))
        {
            return new ST_REVIEW_FAILURE_PART(
                "검사 파일 확인",
                "검사에 필요한 파일을 찾을 수 없습니다.",
                "Recipe, Review 설정 및 결과 파일 경로를 확인해 주세요.");
        }

        return new ST_REVIEW_FAILURE_PART(
            productStateFailure ? "검사 상태 저장" : "Review 검사",
            FirstLine(message),
            "상세 로그를 확인한 뒤 동일 조건으로 다시 시도해 주세요.");
    }

    private static string AppendShot(string cause, string message)
    {
        var shot = ReadValue(message, "Shot=");
        return string.IsNullOrWhiteSpace(shot)
            ? cause
            : $"{cause} (Shot {shot})";
    }

    private static string ReadValue(string message, string key)
    {
        var start = message.IndexOf(key, StringComparison.OrdinalIgnoreCase);
        if (start < 0)
        {
            return "";
        }

        start += key.Length;
        var end = start;
        while (end < message.Length &&
               message[end] != ',' &&
               message[end] != '.' &&
               message[end] != ':' &&
               message[end] != '\r' &&
               message[end] != '\n' &&
               !char.IsWhiteSpace(message[end]))
        {
            end++;
        }

        return message[start..end].Trim();
    }

    private static string FirstLine(string message)
    {
        var end = message.Length;
        var lineEnd = message.IndexOfAny(['\r', '\n']);
        if (lineEnd >= 0)
        {
            end = Math.Min(end, lineEnd);
        }

        var stackStart = message.IndexOf("   at ", StringComparison.Ordinal);
        if (stackStart >= 0)
        {
            end = Math.Min(end, stackStart);
        }

        var firstLine = message[..end].Trim();
        const int maximumLength = 240;
        return firstLine.Length <= maximumLength
            ? firstLine
            : $"{firstLine[..maximumLength]}...";
    }

    private static bool Contains(string source, string value)
    {
        return source.Contains(value, StringComparison.OrdinalIgnoreCase);
    }

    private sealed record ST_REVIEW_FAILURE_PART(
        string Stage,
        string Cause,
        string Action);
}
