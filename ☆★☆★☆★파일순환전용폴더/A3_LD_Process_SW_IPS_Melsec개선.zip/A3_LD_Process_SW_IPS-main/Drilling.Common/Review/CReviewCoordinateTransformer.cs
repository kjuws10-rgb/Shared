using Drilling.Common.Recipe;

namespace Drilling.Common.Review;
[Flags]
public enum EN_VISION_FLIP_TYPE
{
    Normal = 0,
    XFlip = 1,
    YFlip = 2,
    XyFlip = 4
}

public readonly record struct ST_REVIEW_COORDINATE_OFFSET(double X, double Y);
public readonly record struct ST_REVIEW_COORDINATE_FORMULA(string Gx, string Gy);
public static class CReviewCoordinateTransformer
{
    public static ST_REVIEW_COORDINATE_OFFSET VisionErrorToStageOffset(
        double visionErrorX,
        double visionErrorY,
        EN_VISION_FLIP_TYPE flipType)
    {
        var transformedX = visionErrorX;
        var transformedY = visionErrorY;
        if (flipType.HasFlag(EN_VISION_FLIP_TYPE.XyFlip))
        {
            (transformedX, transformedY) = (transformedY, transformedX);
        }

        if (flipType.HasFlag(EN_VISION_FLIP_TYPE.XFlip))
        {
            transformedX = -transformedX;
        }

        if (flipType.HasFlag(EN_VISION_FLIP_TYPE.YFlip))
        {
            transformedY = -transformedY;
        }

        return new ST_REVIEW_COORDINATE_OFFSET(transformedX, transformedY);
    }

    public static ST_REVIEW_COORDINATE_OFFSET VisionErrorToScannerOffset(
        double visionErrorX,
        double visionErrorY,
        EN_VISION_FLIP_TYPE visionFlipType,
        ST_SCANNER_AXIS_TRANSFORM scannerAxisTransform)
    {
        var stageOffset = VisionErrorToStageOffset(visionErrorX, visionErrorY, visionFlipType);
        var scannerOffset = scannerAxisTransform.Apply(stageOffset.X, stageOffset.Y);
        return new ST_REVIEW_COORDINATE_OFFSET(scannerOffset.X, scannerOffset.Y);
    }

    public static ST_REVIEW_COORDINATE_FORMULA VisionErrorToScannerFormula(
        EN_VISION_FLIP_TYPE visionFlipType,
        ST_SCANNER_AXIS_TRANSFORM scannerAxisTransform)
    {
        var errorXBasis = VisionErrorToScannerOffset(1.0, 0.0, visionFlipType, scannerAxisTransform);
        var errorYBasis = VisionErrorToScannerOffset(0.0, 1.0, visionFlipType, scannerAxisTransform);
        return new ST_REVIEW_COORDINATE_FORMULA(FormatFormula(errorXBasis.X, errorYBasis.X), FormatFormula(errorXBasis.Y, errorYBasis.Y));
    }

    public static EN_VISION_FLIP_TYPE CreateVisionFlipType(bool xFlip, bool yFlip, bool xyFlip)
    {
        var flipType = EN_VISION_FLIP_TYPE.Normal;
        if (xFlip)
        {
            flipType |= EN_VISION_FLIP_TYPE.XFlip;
        }

        if (yFlip)
        {
            flipType |= EN_VISION_FLIP_TYPE.YFlip;
        }

        if (xyFlip)
        {
            flipType |= EN_VISION_FLIP_TYPE.XyFlip;
        }

        return flipType;
    }

    public static EN_VISION_FLIP_TYPE ParseVisionFlipType(string? xFlipValue, string? yFlipValue, string? xyFlipValue)
    {
        return CreateVisionFlipType(ParseOnOff(xFlipValue), ParseOnOff(yFlipValue), ParseOnOff(xyFlipValue));
    }

    public static string FormatVisionFlipType(EN_VISION_FLIP_TYPE flipType)
    {
        return $"X {FormatOnOff(flipType.HasFlag(EN_VISION_FLIP_TYPE.XFlip))} / " + $"Y {FormatOnOff(flipType.HasFlag(EN_VISION_FLIP_TYPE.YFlip))} / " + $"XY {FormatOnOff(flipType.HasFlag(EN_VISION_FLIP_TYPE.XyFlip))}";
    }

    private static bool ParseOnOff(string? value)
    {
        return (value ?? "").Trim().ToUpperInvariant()is "ON" or "TRUE" or "1" or "YES";
    }

    private static string FormatOnOff(bool value)
    {
        return value ? "ON" : "OFF";
    }

    private static string FormatFormula(double errorXCoefficient, double errorYCoefficient)
    {
        if (Math.Abs(errorXCoefficient) > 0.5)
        {
            return errorXCoefficient > 0.0 ? "+Error X" : "-Error X";
        }

        return errorYCoefficient > 0.0 ? "+Error Y" : "-Error Y";
    }
}
