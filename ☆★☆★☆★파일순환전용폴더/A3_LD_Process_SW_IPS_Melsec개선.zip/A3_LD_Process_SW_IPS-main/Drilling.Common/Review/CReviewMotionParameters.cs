using System.Globalization;
using Drilling.Common.Managers;

namespace Drilling.Common.Review;

public sealed record ST_REVIEW_MOTION_PARAMETERS(double Speed, double Acceleration)
{
    public static ST_REVIEW_MOTION_PARAMETERS Read(CSettingManager settings) => Read(settings.LoadSection(EN_SETTING_TAB.Motor));
    public static ST_REVIEW_MOTION_PARAMETERS Read(IEnumerable<ST_SYSTEM_PARAMETER> settings)
    {
        var values = settings.Where(p => !string.IsNullOrEmpty(p.Key)).GroupBy(p => p.Key, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.Last().Value, StringComparer.OrdinalIgnoreCase);
        double Get(string key, double fallback)
        {
            if (!values.TryGetValue(key, out var text)) return fallback;
            if (!double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out var value) || !double.IsFinite(value) || value <= 0)
                throw new InvalidOperationException($"Setting Motor의 {key}는 0보다 큰 유한한 숫자여야 합니다.");
            return value;
        }
        return new(Get("REVIEW_X_SPEED", 200), Get("REVIEW_X_ACC", 150));
    }
}
