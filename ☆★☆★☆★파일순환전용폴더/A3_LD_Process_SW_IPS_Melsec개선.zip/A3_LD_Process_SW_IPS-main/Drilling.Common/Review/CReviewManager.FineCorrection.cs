using Drilling.Common.Interface;
using Drilling.Common.Interface.Vision;
using Drilling.Common.Motion;

namespace Drilling.Common.Review;

public enum EN_FINE_INSPECTION_METHOD { Flying, PtoP }
public enum EN_FINE_REVIEW_LINE_STATE { Wait, Running, Complete, Ng, Error }
public sealed record ST_FINE_REVIEW_LINE(string Key, int Number, int ModelNo,
    IReadOnlyList<ST_REVIEW_PLAN_POINT> Points, EN_FINE_REVIEW_LINE_STATE State = EN_FINE_REVIEW_LINE_STATE.Wait);
public sealed record ST_FINE_REVIEW_REQUEST(ST_REVIEW_PLAN Plan, IReadOnlyList<ST_FINE_REVIEW_LINE> Lines,
    EN_FINE_INSPECTION_METHOD Method, int StartLineNo = 1, bool IsResume = false)
{
    public ST_FINE_REVIEW_CONTEXT? Context { get; init; }
    public bool StopOnNgLine { get; init; } = true;
    public Guid PreparedMonitorRunId { get; init; }
    public int CountMismatchRetries { get; init; }
    // The selected retry limit is shared by Count NCK and optional all-NG immediate retries.
    public bool ImmediateRetry { get; init; }
}
public sealed record ST_FINE_REVIEW_SNAPSHOT(string RecipeId, IReadOnlyList<ST_FINE_REVIEW_LINE> Lines,
    EN_REVIEW_SEQUENCE_STATE State, string Message, bool IsNgPause = false)
{
    public Guid RunId { get; init; }
    public string ResultFilePath { get; init; } = "";
    public string ResultSaveError { get; init; } = "";
}
public sealed record ST_FINE_REVIEW_RESULT_DATA(ST_FINE_REVIEW_REQUEST Request, ST_FINE_REVIEW_SNAPSHOT Snapshot,
    DateTimeOffset SavedAt, IReadOnlySet<string> AttemptedShotKeys, bool IsVisionSimulation)
{
    public IReadOnlyDictionary<string, int> CaptureAttempts { get; init; } = new Dictionary<string, int>();
}

public sealed partial class CReviewManager
{
    public CFineReviewMonitorStore FineMonitor { get; } = new();
    internal void RecordAutoFineLog(string action, string message) => WriteReviewLog(action, message);
    public void ValidateFinePreparation(ST_FINE_REVIEW_REQUEST request)
    {
        ValidateFineRequest(request);
        if (!IsReviewDeviceSimulation(EN_EQP_MODULE.Melsec, GetReviewStageDeviceNo()))
            throw new NotSupportedException("FINE의 실제 Stage 이동/IOF 배열 계약은 아직 미연결입니다. 현재는 MELSEC 시뮬레이션 이동으로 검사할 수 있습니다. Vision은 독립적으로 실제 통신할 수 있습니다.");
        _ = ST_REVIEW_MOTION_PARAMETERS.Read(settingManager);
    }

    public ST_AUTO_FINE_PLAN CreateAutoFinePlan(ST_AUTO_REVIEW_INPUT input, CancellationToken token = default)
    {
        token.ThrowIfCancellationRequested();
        var settings = settingManager.LoadSection(Drilling.Common.Managers.EN_SETTING_TAB.Option, token)
            .Concat(settingManager.LoadSection(Drilling.Common.Managers.EN_SETTING_TAB.Motor, token)).ToArray();
        var plan = CAutoFineReviewPlan.Build(input, settings);
        ValidateFinePreparation(plan.Request);
        var id = FineMonitor.Stage(plan.Request, GetReviewStageDeviceNo());
        return plan with { Request = plan.Request with { PreparedMonitorRunId = id } };
    }
    /// <summary>Fine sequence. Stage motion/trigger buffer currently require MELSEC simulation;
    /// Vision independently follows Vision 0's simulation setting. No real Stage command addresses are guessed.</summary>
    public async Task<ST_FINE_REVIEW_SNAPSHOT> StartFineCorrection(ST_FINE_REVIEW_REQUEST request,
        Action<ST_FINE_REVIEW_SNAPSHOT> progress, CancellationToken cancellationToken = default,
        Func<IReadOnlyList<ST_REVIEW_PLAN_POINT>, CancellationToken, Task<IReadOnlyList<ST_VISION_MARK_FIND>>>? simulationMeasurement = null)
    {
        ValidateFineRequest(request);
        var deviceNo = GetReviewStageDeviceNo();
        if (!IsReviewDeviceSimulation(EN_EQP_MODULE.Melsec, deviceNo))
            throw new InvalidOperationException("Stage Y / Review X 이동 명령·트리거 좌표 배열 주소·Buffer Ready 신호가 미정입니다. FINE은 현재 MELSEC 시뮬레이션에서 실행할 수 있습니다. Vision 통신은 Vision 장치 설정을 따릅니다.");
        var visionSimulation = IsReviewSimulation();
        if (simulationMeasurement is not null && !visionSimulation)
            throw new InvalidOperationException("실제 Vision 모드에서는 시뮬레이션 측정값을 사용할 수 없습니다.");
        var reviewMotion = ST_REVIEW_MOTION_PARAMETERS.Read(settingManager);
        if (!await _sequenceLock.WaitAsync(0, cancellationToken)) throw new InvalidOperationException("다른 Review 검사가 진행 중입니다.");
        var simulation = interfaceManager.GetStageMotionSimulation(deviceNo);
        CManualStageMotionSimulation.MotionLease? lease = null;
        var lines = request.Lines.ToArray();
        var attempted = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var captureAttempts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        var activeLine = -1;
        var started = false;
        var ngPause = false;
        var runId = Guid.Empty;
        var prefetchedIndex = -1;
        var prefetchedShotKey = "";
        ST_FINE_REVIEW_SNAPSHOT Publish(string message)
        {
            var snapshot = new ST_FINE_REVIEW_SNAPSHOT(request.Plan.RecipeId, Array.AsReadOnly(lines.ToArray()), SequenceState, message, ngPause) { RunId = runId };
            FineMonitor.Publish(snapshot);
            progress(snapshot);
            return snapshot;
        }
        try
        {
            lease = simulation.AcquireExclusiveMotion(); started = true;
            runId = FineMonitor.Begin(request, deviceNo);
            LastSavedResultPath = null; Interlocked.Exchange(ref _stopRequested, 0);
            SequenceState = EN_REVIEW_SEQUENCE_STATE.Running;
            var firstIndex = Array.FindIndex(lines, line => line.Number == request.StartLineNo);
            for (var i = 0; i < lines.Length; i++)
                if (!request.IsResume || i >= firstIndex)
                {
                    var line = lines[i];
                    var clean = line.Points.All(point => point.State == EN_REVIEW_POINT_STATE.Ready && point.Judge == "WAIT" && point.ErrorX == 0 && point.ErrorY == 0);
                    if (!clean || line.State != EN_FINE_REVIEW_LINE_STATE.Wait)
                        lines[i] = line with { State = EN_FINE_REVIEW_LINE_STATE.Wait,
                            Points = clean ? line.Points : Array.AsReadOnly(line.Points.Select(ClearFinePoint).ToArray()) };
                }
            Publish("FINE 검사 시작");
            var ptpKeepAliveSent = false;
            for (var index = firstIndex; index < lines.Length; index++)
            {
                CheckStop(); activeLine = index;
                var original = lines[index];
                var sorted = original.Points.OrderBy(point => point.ReviewTargetX).ThenBy(point => point.CellNo).ToArray();
                var ordered = original.Points[0].DesignX <= original.Points[^1].DesignX ? sorted : sorted.Reverse().ToArray();
                // Resume at the nearest endpoint. After each line the actual current endpoint
                // determines the next direction, including a reversed NG retry.
                if (request.Context?.Origin == "AUTO" || request.IsResume || index > firstIndex)
                {
                    var x = simulation.GetSnapshot().Single(axis => axis.Axis == EN_MANUAL_STAGE_AXIS.ReviewX).Position;
                    ordered = Math.Abs(x - sorted[0].ReviewTargetX) <= Math.Abs(x - sorted[^1].ReviewTargetX) ? sorted : sorted.Reverse().ToArray();
                }
                lines[index] = original with { Points = Array.AsReadOnly(ordered), State = EN_FINE_REVIEW_LINE_STATE.Running };
                if (request.Method == EN_FINE_INSPECTION_METHOD.PtoP)
                {
                    for (var pointIndex = 0; pointIndex < ordered.Length; pointIndex++)
                    {
                        var point = ordered[pointIndex];
                        var pointRetry = 0;
                        while (true)
                        {
                            CheckStop();
                            ordered[pointIndex] = point with { State = EN_REVIEW_POINT_STATE.Current };
                            ReplaceLine(index, ordered, EN_FINE_REVIEW_LINE_STATE.Running); Publish($"Line #{original.Number} / {pointIndex + 1} / {ordered.Length} · " +
                                (pointRetry == 0 ? "위치 이동" : $"Shot 즉시 재시도 {pointRetry} / {request.CountMismatchRetries}"));
                            await MoveAndWait(point, alreadyPositioned: pointRetry > 0);
                            await Task.Delay(250, cancellationToken); CheckStop();
                            if (request.Context?.Origin == "AUTO" && !visionSimulation && !ptpKeepAliveSent)
                            {
                                await ExecuteVisionCommand("KEEP_ALIVE_REQUEST", "Vision Keep Alive 응답이 없습니다.", cancellationToken);
                                ptpKeepAliveSent = true;
                            }
                            attempted.Add(point.ShotKey); captureAttempts[point.ShotKey] = pointRetry + 1;
                            ST_VISION_MARK_FIND mark;
                            if (visionSimulation) mark = (await SimulatedMarks([point]))[0];
                            else mark = (await MeasureVision(point, cancellationToken)).MarkFind
                                ?? throw new InvalidDataException("Vision 응답에 Target/Hole 좌표가 없습니다.");
                            point = ApplyFineMark(request.Plan, point, mark); ordered[pointIndex] = point;
                            ReplaceLine(index, ordered, EN_FINE_REVIEW_LINE_STATE.Running); Publish($"Line #{original.Number} · Shot 측정 완료");
                            if (!request.ImmediateRetry || point.State != EN_REVIEW_POINT_STATE.Ng) break;
                            LogNgAttempt(original.Number, pointRetry + 1, [point]);
                            if (pointRetry >= request.CountMismatchRetries)
                                throw new InvalidDataException($"Line #{original.Number} / {point.ShotKey} NG 즉시 재시도 한도 {request.CountMismatchRetries}회 초과");
                            pointRetry++;
                        }
                    }
                }
                else
                {
                    var countRetry = 0; // Shared total retry budget: NCK and all-NG attempts cannot reset each other.
                    while (true)
                    {
                        ordered = ordered.Select(point => point with { State = EN_REVIEW_POINT_STATE.Current }).ToArray();
                        ReplaceLine(index, ordered, EN_FINE_REVIEW_LINE_STATE.Running); Publish($"Line #{original.Number} · 시작 위치 이동");
                        await MoveAndWait(ordered[0], alreadyPositioned: countRetry > 0 ||
                            prefetchedIndex == index && prefetchedShotKey == ordered[0].ShotKey);
                        prefetchedIndex = -1; CheckStop();
                        if (!visionSimulation)
                        {
                            if (request.Context?.Origin == "AUTO")
                                await ExecuteVisionCommand("KEEP_ALIVE_REQUEST", "Vision Keep Alive 응답이 없습니다.", cancellationToken);
                            await ExecuteVisionCommand(CreateFlyingReadyCommand(ordered), "Flying Ready 응답이 없습니다.", cancellationToken);
                        }
                        CheckStop();
                        // The complete line is frozen before motion. This is a simulated ACS trigger
                        // buffer only; real MELSEC upload/Buffer Ready must be implemented after the map is agreed.
                        var triggerBuffer = Array.AsReadOnly(ordered.ToArray());
                        Publish($"Line #{original.Number} · 트리거 버퍼 {triggerBuffer.Count}개 준비 (Stage Simulation)");
                        await MoveAndWait(triggerBuffer[^1]); CheckStop();
                        foreach (var point in triggerBuffer) { attempted.Add(point.ShotKey); captureAttempts[point.ShotKey] = countRetry + 1; }
                        if (!visionSimulation)
                        {
                            try { await ExecuteVisionCommand("FLYING_MOVE_DONE", "Flying Move Done 응답이 없습니다.", cancellationToken); }
                            catch (CFlyingCountMismatchException) when (countRetry < request.CountMismatchRetries)
                            {
                                countRetry++;
                                // The completed end move has placed the camera at the opposite endpoint.
                                // Keep design IDs; reverse only the transmitted target order, never ask 1003 for an NCK attempt.
                                ordered = ordered.Reverse().ToArray();
                                Publish($"Line #{original.Number} Count NCK · 반대 방향 재시도 {countRetry} / {request.CountMismatchRetries}");
                                continue;
                            }
                            catch (CFlyingCountMismatchException error)
                            {
                                throw new InvalidDataException($"Line #{original.Number} Count NCK 재시도 한도 {request.CountMismatchRetries}회 초과", error);
                            }
                            CheckStop();
                        }
                        async Task ReceiveLine(CancellationToken token)
                        {
                            IReadOnlyList<ST_VISION_MARK_FIND> marks;
                            if (visionSimulation) marks = await SimulatedMarks(triggerBuffer, token);
                            else
                            {
                                var response = await ExecuteVisionCommand("MARK_FIND_LINE", "Mark Find Line 응답이 없습니다.", token);
                                marks = ParseVisionLineResponse(response, triggerBuffer).Select(measurement => measurement.MarkFind
                                    ?? throw new InvalidDataException("라인 응답에 Target/Hole 좌표가 없습니다.")).ToArray();
                            }
                            CheckStop(); token.ThrowIfCancellationRequested();
                            if (marks.Count != triggerBuffer.Count) throw new InvalidDataException($"라인 결과 수가 일치하지 않습니다. 요청={triggerBuffer.Count}, 수신={marks.Count}");
                            // Bind to this frozen line/attempt even while the camera moves to the next line.
                            ordered = triggerBuffer.Select((point, i) => ApplyFineMark(request.Plan, point, marks[i])).ToArray();
                            ReplaceLine(index, ordered, ordered.Any(point => point.State == EN_REVIEW_POINT_STATE.Ng)
                                ? EN_FINE_REVIEW_LINE_STATE.Ng : EN_FINE_REVIEW_LINE_STATE.Complete);
                            Publish($"Line #{original.Number} · 검사 결과 수신");
                        }
                        if (request.Context?.Origin == "AUTO" && !request.ImmediateRetry && index + 1 < lines.Length)
                        {
                            // OFF overlaps only the next start move with one outstanding 1003 reply.
                            // Do not start the next capture or release the lease before both operations settle.
                            var nextIndex = index + 1;
                            var next = lines[nextIndex].Points.OrderBy(point => point.ReviewTargetX).ThenBy(point => point.CellNo).ToArray();
                            var x = simulation.GetSnapshot().Single(axis => axis.Axis == EN_MANUAL_STAGE_AXIS.ReviewX).Position;
                            var nextStart = Math.Abs(x - next[0].ReviewTargetX) <= Math.Abs(x - next[^1].ReviewTargetX) ? next[0] : next[^1];
                            using var overlap = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
                            async Task Prefetch()
                            {
                                try { await MoveAndWait(nextStart, overlap.Token); }
                                catch (Exception error) when (error is not OperationCanceledException) { activeLine = nextIndex; throw; }
                            }
                            var receive = ReceiveLine(overlap.Token);
                            var move = Prefetch();
                            var first = await Task.WhenAny(receive, move);
                            if (first.IsFaulted || first.IsCanceled) overlap.Cancel();
                            try { await Task.WhenAll(receive, move); }
                            catch { overlap.Cancel(); throw; }
                            prefetchedIndex = nextIndex; prefetchedShotKey = nextStart.ShotKey;
                        }
                        else await ReceiveLine(cancellationToken);
                        if (request.ImmediateRetry && ordered.Any(point => point.State == EN_REVIEW_POINT_STATE.Ng))
                        {
                            LogNgAttempt(original.Number, countRetry + 1, ordered);
                            if (countRetry >= request.CountMismatchRetries)
                                throw new InvalidDataException($"Line #{original.Number} NG 즉시 재시도 한도 {request.CountMismatchRetries}회 초과");
                            countRetry++;
                            ordered = ordered.Reverse().ToArray();
                            Publish($"Line #{original.Number} NG · 반대 방향 즉시 재시도 {countRetry} / {request.CountMismatchRetries}");
                            continue;
                        }
                        break;
                    }
                }
                var state = ordered.Any(point => point.State == EN_REVIEW_POINT_STATE.Ng) ? EN_FINE_REVIEW_LINE_STATE.Ng : EN_FINE_REVIEW_LINE_STATE.Complete;
                ReplaceLine(index, ordered, state); activeLine = -1;
                if (request.StopOnNgLine && request.Method == EN_FINE_INSPECTION_METHOD.Flying && state == EN_FINE_REVIEW_LINE_STATE.Ng)
                {
                    ngPause = true; SequenceState = EN_REVIEW_SEQUENCE_STATE.Stopped;
                    return await Finish($"Line #{original.Number} NG · 라인 끝 위치에서 대기합니다. NG RETRY를 선택해 주세요.");
                }
                Publish($"Line #{original.Number} 검사 완료");
            }
            SequenceState = EN_REVIEW_SEQUENCE_STATE.Completed;
            return await Finish("FINE 검사 완료");
        }
        catch (OperationCanceledException)
        {
            SequenceState = EN_REVIEW_SEQUENCE_STATE.Stopped;
            return await Finish("FINE 검사 중지");
        }
        catch (Exception error)
        {
            SequenceState = EN_REVIEW_SEQUENCE_STATE.Failed;
            if (activeLine >= 0)
            {
                var line = lines[activeLine];
                lines[activeLine] = line with { State = EN_FINE_REVIEW_LINE_STATE.Error, Points = Array.AsReadOnly(line.Points.Select(point =>
                    point.State == EN_REVIEW_POINT_STATE.Current ? ClearFinePoint(point) with { Judge = "ERROR" } : point).ToArray()) };
            }
            return await Finish(error.Message);
        }
        finally { ReleaseMotion(); _sequenceLock.Release(); }

        void CheckStop() { cancellationToken.ThrowIfCancellationRequested(); if (IsStopRequested) throw new OperationCanceledException("Review Stop"); }
        void ReplaceLine(int index, IReadOnlyList<ST_REVIEW_PLAN_POINT> points, EN_FINE_REVIEW_LINE_STATE state)
            => lines[index] = lines[index] with { Points = Array.AsReadOnly(points.ToArray()), State = state };
        void LogNgAttempt(int lineNo, int attemptNo, IReadOnlyList<ST_REVIEW_PLAN_POINT> points)
        {
            var ng = points.Where(point => point.State == EN_REVIEW_POINT_STATE.Ng).Select(point =>
                FormattableString.Invariant($"{point.ShotKey}/B{point.BeamNo}:RecvX={point.ErrorX:R},RecvY={point.ErrorY:R}"));
            WriteReviewLog("FINE_NG_ATTEMPT", $"Run={runId},Recipe={request.Plan.RecipeId},Glass={request.Context?.GlassId},Line={lineNo},Attempt={attemptNo},NG={string.Join(";", ng)}");
        }
        async Task MoveAndWait(ST_REVIEW_PLAN_POINT target, CancellationToken? movementToken = null, bool alreadyPositioned = false)
        {
            var token = movementToken ?? cancellationToken;
            CheckStop();
            token.ThrowIfCancellationRequested();
            if (!alreadyPositioned)
            {
                lease!.Move(EN_MANUAL_STAGE_AXIS.StageY, target.ReviewTargetY, 1000);
                lease.Move(EN_MANUAL_STAGE_AXIS.ReviewX, target.ReviewTargetX, reviewMotion.Speed, reviewMotion.Acceleration);
            }
            var deadline = DateTimeOffset.UtcNow.AddSeconds(30);
            while (true)
            {
                CheckStop();
                token.ThrowIfCancellationRequested();
                // A fresh common simulation snapshot, read after issuing both commands.
                var feedback = interfaceManager.GetStageMotionSimulationFeedback(deviceNo);
                if (feedback["MOTOR_STAGE_Y_BUSY"] == 0 && feedback["MOTOR_CAMERA_X_BUSY"] == 0)
                {
                    if (Math.Abs(feedback["MOTOR_STAGE_Y_CUR_POS"] - target.ReviewTargetY) > .0005 ||
                        Math.Abs(feedback["MOTOR_CAMERA_X_CUR_POS"] - target.ReviewTargetX) > .0005)
                        throw new InvalidOperationException("Stage Y / Review X가 목표 위치에 도착하기 전에 정지했습니다.");
                    return;
                }
                if (DateTimeOffset.UtcNow >= deadline) throw new TimeoutException("Stage Y / Review X 이동 완료 대기 시간 초과 (30초)");
                await Task.Delay(20, token);
            }
        }
        async Task<IReadOnlyList<ST_VISION_MARK_FIND>> SimulatedMarks(IReadOnlyList<ST_REVIEW_PLAN_POINT> targets, CancellationToken? measurementToken = null)
        {
            var token = measurementToken ?? cancellationToken;
            await Task.Delay(80, token); CheckStop(); token.ThrowIfCancellationRequested();
            var marks = simulationMeasurement is not null ? await simulationMeasurement(targets, token)
                : targets.Select(point => CreateTemporaryVisionMeasurement(point).MarkFind!.Value).ToArray();
            if (marks.Count != targets.Count) throw new InvalidDataException("시뮬레이션 결과 수가 요청과 일치하지 않습니다.");
            return marks;
        }
        void ReleaseMotion() { if (lease is null) return; simulation.Stop(); lease.Dispose(); lease = null; }
        async Task<ST_FINE_REVIEW_SNAPSHOT> Finish(string message)
        {
            for (var i = 0; i < lines.Length; i++)
            {
                var line = lines[i];
                if (line.State == EN_FINE_REVIEW_LINE_STATE.Running || line.Points.Any(point => point.State == EN_REVIEW_POINT_STATE.Current))
                    ReplaceLine(i, line.Points.Select(point => point.State == EN_REVIEW_POINT_STATE.Current ? ClearFinePoint(point) : point).ToArray(),
                        line.Points.Any(point => point.State == EN_REVIEW_POINT_STATE.Ng) ? EN_FINE_REVIEW_LINE_STATE.Ng :
                        line.Points.All(point => point.State == EN_REVIEW_POINT_STATE.Ok) ? EN_FINE_REVIEW_LINE_STATE.Complete : EN_FINE_REVIEW_LINE_STATE.Wait);
            }
            ReleaseMotion();
            var snapshot = Publish(message);
            if (!started) return snapshot;
            try
            {
                var data = new ST_FINE_REVIEW_RESULT_DATA(request, snapshot, DateTimeOffset.Now, attempted, visionSimulation)
                    { CaptureAttempts = new System.Collections.ObjectModel.ReadOnlyDictionary<string, int>(captureAttempts) };
                var path = await Task.Run(() => reviewResultFile.SaveFineCorrection(data, CancellationToken.None));
                LastSavedResultPath = path; snapshot = snapshot with { ResultFilePath = path };
                WriteReviewLog("FINE_RESULT_SAVED", path);
            }
            catch (Exception error)
            {
                snapshot = snapshot with { ResultSaveError = error.Message, Message = message + " / 검사 결과 저장 실패: " + error.Message };
                WriteReviewLog("FINE_RESULT_SAVE_ERROR", error.ToString());
            }
            FineMonitor.Publish(snapshot);
            progress(snapshot); return snapshot;
        }
    }

    private static ST_REVIEW_PLAN_POINT ClearFinePoint(ST_REVIEW_PLAN_POINT point)
        => point with { State = EN_REVIEW_POINT_STATE.Ready, Judge = "WAIT", ErrorX = 0, ErrorY = 0 };
    private static ST_REVIEW_PLAN_POINT ApplyFineMark(ST_REVIEW_PLAN plan, ST_REVIEW_PLAN_POINT point, ST_VISION_MARK_FIND mark)
        => ApplyRoughMeasurement(plan, point, new ST_REVIEW_MEASURE_RESULT(0, 0, mark.Result > 0 ? "" : "NG", "FINE") { MarkFind = mark });
    private static void ValidateFineRequest(ST_FINE_REVIEW_REQUEST request)
    {
        if (request.CountMismatchRetries is < 0 or > 10)
            throw new InvalidOperationException("Count NCK 재시도 횟수는 0~10이어야 합니다.");
        if (request.ImmediateRetry && request.CountMismatchRetries < 1)
            throw new InvalidOperationException("즉시 재시도 ON일 때는 재시도 횟수가 1회 이상이어야 합니다.");
        if (request.Method is not (EN_FINE_INSPECTION_METHOD.Flying or EN_FINE_INSPECTION_METHOD.PtoP) || request.Lines.Count == 0 ||
            !request.Lines.Any(line => line.Number == request.StartLineNo) || !request.IsResume && request.StartLineNo != 1 || request.Lines.Any(line => line.Points.Count == 0) ||
            request.Lines.Select(line => line.Key).Distinct().Count() != request.Lines.Count ||
            !request.Lines.Select(line => line.Number).SequenceEqual(Enumerable.Range(1, request.Lines.Count)))
            throw new InvalidOperationException("FINE 검사 대상 또는 시작 라인이 올바르지 않습니다.");
        var points = request.Lines.SelectMany(line => line.Points).ToArray();
        if (points.Select(point => point.ShotKey).Distinct(StringComparer.OrdinalIgnoreCase).Count() != points.Length ||
            !points.Select(point => point.ShotKey).ToHashSet(StringComparer.OrdinalIgnoreCase).SetEquals(request.Plan.Points.Select(point => point.ShotKey)) ||
            points.Any(point => !point.Use || point.HeadNo <= 0 || !double.IsFinite(point.ReviewTargetX) || !double.IsFinite(point.ReviewTargetY)) ||
            !double.IsFinite(request.Plan.ToleranceX) || request.Plan.ToleranceX < 0 || !double.IsFinite(request.Plan.ToleranceY) || request.Plan.ToleranceY < 0)
            throw new InvalidOperationException("FINE Shot 좌표·중복·사용 여부·공차를 확인해 주세요.");
        if (request.Method == EN_FINE_INSPECTION_METHOD.Flying)
            foreach (var line in request.Lines)
            {
                if (line.Points.Count > CVisionProtocol.MaximumMarkCount) throw new InvalidOperationException($"Line #{line.Number} 결과가 Vision 패킷 크기 한도를 초과합니다.");
                if (line.Points.Max(point => point.ReviewTargetY) - line.Points.Min(point => point.ReviewTargetY) > .0005)
                    throw new InvalidOperationException($"Line #{line.Number}에 서로 다른 Stage Y 목표 위치가 포함되어 Flying할 수 없습니다. PtoP를 사용하거나 라인 구성을 확인해 주세요.");
            }
    }
}
