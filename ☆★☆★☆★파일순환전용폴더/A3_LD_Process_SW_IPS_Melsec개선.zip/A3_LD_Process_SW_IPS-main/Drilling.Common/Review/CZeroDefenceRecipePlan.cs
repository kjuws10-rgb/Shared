using System.Globalization;
using Drilling.Common.Managers;
using Drilling.Common.Recipe;

namespace Drilling.Common.Review;

/// <summary>A recipe/settings snapshot. Creating and validating it never moves a device.</summary>
public sealed class CZeroDefenceRecipePlan
{
    public const string CountKey = "ZERO_DEFENCE_POINT_COUNT";
    public static string Key(int head, string field) => $"ZD_H{head:00}_{field}";
    private readonly CRecipeShotMaskingPlan _mask;
    private readonly Dictionary<(int Cell, int Shot), ST_HEAD_SHOT_POINT> _shots;
    private readonly Func<ST_REVIEW_PLAN_POINT, int, ST_REVIEW_BEAM_POSITION> _beamPosition;
    public CZeroDefenceRecipePlan(ST_RECIPE_DEFINITION recipe, IReadOnlyList<ST_SYSTEM_PARAMETER> settings)
    {
        Recipe = recipe;
        var parameters = recipe.Parameters.Where(p => p.Key.Length > 0).GroupBy(p => p.Key, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.Last().Value, StringComparer.OrdinalIgnoreCase);
        foreach (var setting in settings.Where(s => s.Key.Length > 0)) parameters[setting.Key] = setting.Value;
        parameters["HEAD_COUNT"] = "8";
        Parameters = parameters;
        Plan = CShotCoordinatePlanBuilder.Build(parameters);
        _shots = Plan.Shots.ToDictionary(p => (p.CellNo, p.CellShotNo));
        _mask = CRecipeShotMaskingPlan.Build(parameters);
        var motion = ST_REVIEW_MOTION_PARAMETERS.Read(settings);
        Profile = new(Read("STAGE_START_POS_Y", 3960), Read("STAGE_SCAN_DIRECTION_Y", -1),
            Read("STAGE_SPEED", 80), motion.Speed, motion.Acceleration);
        var geometryRecipe = recipe with { Parameters = parameters.Select(p => new ST_RECIPE_PARAMETER(p.Key, p.Value, "", "", "", Key: p.Key)).ToArray() };
        _beamPosition = CReviewManager.CreateShotBeamPositionCalculator(geometryRecipe, Profile.StageDirection);
    }
    public ST_RECIPE_DEFINITION Recipe { get; }
    public IReadOnlyDictionary<string, string> Parameters { get; }
    public ST_SHOT_COORDINATE_PLAN Plan { get; }
    public ST_ZERO_DEFENCE_TIMING_PROFILE Profile { get; }
    public int Count => Int(CountKey, 2);
    public bool HasSelections => Enumerable.Range(1, 8).Any(h => new[] { "CELL", "SHOT", "BEAM" }.Any(f => Int(Key(h, f)) != 0));
    public int Int(string key, int fallback = 0)
    {
        if (!Parameters.TryGetValue(key, out var value)) return fallback;
        if (!int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var number))
            throw new InvalidOperationException($"{key}: 정수 값이 아닙니다.");
        return number;
    }
    private double Read(string key, double fallback)
    {
        if (!Parameters.TryGetValue(key, out var text)) return fallback;
        if (!double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out var value) || !double.IsFinite(value))
            throw new InvalidOperationException($"{key}: 유한한 숫자가 아닙니다.");
        return value;
    }
    public bool CanProcess(ST_HEAD_SHOT_POINT point) => !_mask.EvaluateShot(point).ShouldSkipLaser;
    public ST_RECIPE_SHOT_MASKING_RESULT Mask(ST_HEAD_SHOT_POINT point) => _mask.EvaluateShot(point);
    public ST_ZERO_DEFENCE_POINT GetPoint(int head, int cell, int shot, int beam)
    {
        if (!_shots.TryGetValue((cell, shot), out var point) || point.HeadNo != head)
            throw new InvalidOperationException($"H{head:00}: 해당 Head가 담당하는 Shot이 아닙니다.");
        if (!CanProcess(point)) throw new InvalidOperationException($"H{head:00}: Masking 또는 Chess로 제외된 Shot입니다.");
        var target = _beamPosition(new(point.SequenceNo, point.ShotKey, head, cell, shot, 0, 0, true,
            point.DesignX, point.DesignY, 0, 0, 0, 0, EN_REVIEW_POINT_STATE.Ready, "WAIT"), beam);
        var beamDesignX = target.ReviewX - Read("REVIEW_CAMERA_ALIGN_KEY_POS_X", 0) + Read("AK_MARGIN_X", 55);
        var beamDesignY = (target.StageY - Read("REVIEW_CAMERA_ALIGN_KEY_POS_Y", 0)) / Profile.StageDirection + Read("AK_MARGIN_Y", 45);
        if (!double.IsFinite(beamDesignX) || !double.IsFinite(beamDesignY) ||
            beamDesignX < -1e-8 || beamDesignX > Plan.GlassSizeX + 1e-8 ||
            beamDesignY < -1e-8 || beamDesignY > Plan.GlassSizeY + 1e-8)
            throw new InvalidOperationException($"H{head:00}: 선택한 Beam이 Glass 영역 밖입니다.");
        var scale = Math.Abs(Read($"H{head:00}_ENCODER_SCALE", Read("SCAN_ENCODER_SCALE", 16000)));
        if (scale <= 0) throw new InvalidOperationException($"H{head:00}: Encoder Scale을 확인해 주세요.");
        var frequency = Read($"H{head:00}_LASER_FREQUENCY", 100) * 1000;
        var shotCount = Read($"H{head:00}_SHOT_COUNT", 1);
        if (frequency <= 0 || shotCount < 0) throw new InvalidOperationException($"H{head:00}: 주파수·Shot Count를 확인해 주세요.");
        var machiningSeconds = shotCount / frequency +
            (Math.Max(0, Read($"H{head:00}_LASER_ON_DELAY", 0)) + Math.Max(0, Read($"H{head:00}_LASER_OFF_DELAY", 0))) / 1000;
        return new(head, cell, shot, beam, point.ShotKey,
            CReviewShotNameFormatter.ToMatrixName(shot, point.GroupCountX), target.ReviewX, target.StageY,
            point.EncoderWaitPosition / (scale * Profile.StageDirection), machiningSeconds);
    }
    public IReadOnlyList<ST_ZERO_DEFENCE_POINT> ReadSelections(bool requireComplete)
    {
        var result = new List<ST_ZERO_DEFENCE_POINT>();
        for (var head = 1; head <= 8; head++)
        {
            var cell = Int(Key(head, "CELL")); var shot = Int(Key(head, "SHOT")); var beam = Int(Key(head, "BEAM"));
            if (cell == 0 && shot == 0 && beam == 0 && !requireComplete) continue;
            if (cell <= 0 || shot <= 0 || beam <= 0) throw new InvalidOperationException($"H{head:00}: Cell·Shot·Beam을 모두 지정해 주세요.");
            result.Add(GetPoint(head, cell, shot, beam));
        }
        return result;
    }
    public string ValidateForSave()
    {
        try
        {
            if (Count is not (2 or 4)) return "0선방어 검사 개수는 2 또는 4만 가능합니다.";
            if (!HasSelections) return ""; // Recipes without a 0-line plan remain usable for other operations.
            return CZeroDefenceTiming.Validate(Count, ReadSelections(requireComplete: true), Profile).Message;
        }
        catch (Exception error) when (error is InvalidOperationException or ArgumentException) { return error.Message; }
    }
}
