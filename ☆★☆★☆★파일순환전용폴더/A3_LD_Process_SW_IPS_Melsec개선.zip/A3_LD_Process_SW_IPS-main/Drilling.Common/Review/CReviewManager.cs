using System.Globalization;
using System.Runtime.CompilerServices;
using System.Text;
using Drilling.Common.Interface;
using Drilling.Common.Interface.Vision;
using Drilling.Common.Log;
using Drilling.Common.Managers;
using Drilling.Common.Recipe;
using Drilling.Common.Product;

namespace Drilling.Common.Review;

internal interface IReviewPointListInfo
{
    bool AreAllPointsSelected { get; }
}

/// <summary>
/// Supplies the actual Recipe Cell shot-group grid to Review rule builders.
/// Review must use this layout instead of reconstructing a grid from a
/// flattened point count: the grid is defined by the current Recipe > Cell
/// calculation (Process PITCH / DOE), not by the legacy pixel dimensions.
/// </summary>
internal readonly record struct ST_REVIEW_CELL_POINT_RANGE(
    int StartIndex,
    int PointCount,
    int ColumnCount,
    int RowCount);

internal interface IReviewCellPointSource
{
    int PatternCellCount { get; }

    ST_REVIEW_CELL_POINT_RANGE GetCellRange(int zeroBasedCellIndex);
}

public enum EN_REVIEW_POINT_STATE
{
    Ready,
    Current,
    Ok,
    Ng,
    Skip
}

public enum EN_REVIEW_SEQUENCE_STATE
{
    Idle,
    Running,
    Stopping,
    Stopped,
    Completed,
    Failed
}

public enum EN_REVIEW_RULE_TYPE
{
    AllPoint,
    SamplePoint,
    Edge,
    Center,
    HeadPoint,
    CellPoint,
    ZeroLine
}

public sealed record ST_REVIEW_SEQUENCE_STATUS(
    EN_REVIEW_SEQUENCE_STATE State,
    int TotalCount,
    int CompletedCount,
    int NgCount,
    string Message);

public sealed record ST_REVIEW_PLAN_POINT(
    int PointNo,
    string ShotKey,
    int HeadNo,
    int CellNo,
    int ShotNo,
    int PixelCountX,
    int PixelCountY,
    bool Use,
    double DesignX,
    double DesignY,
    double ReviewTargetX,
    double ReviewTargetY,
    double ErrorX,
    double ErrorY,
    EN_REVIEW_POINT_STATE State,
    string Judge)
{
    public int BeamNo { get; init; } = 1;

    public double BeamOffsetGx { get; init; }

    public double BeamOffsetGy { get; init; }

    public string ExclusionReason { get; init; } = "";

}

public sealed record ST_REVIEW_BEAM_POSITION(int BeamNo, double StageY, double ReviewX);

/// <summary>
/// Physical scanner field used for both Main head assignment and Review
/// correction-scope presentation.  The value is intentionally expressed in
/// glass coordinates so callers do not need to recreate a Cell-grid estimate
/// of a Head range.
/// </summary>
public sealed record ST_REVIEW_HEAD_SCOPE(
    int HeadNo,
    double PositionX,
    double ScanFieldWidthX);

public static class CReviewShotNameFormatter
{
    public static string ToMatrixName(
        int shotNo,
        int columnCount)
    {
        var safeColumnCount = Math.Max(1, columnCount);
        var zeroBasedShotNo = Math.Max(0, shotNo - 1);
        var column = (zeroBasedShotNo % safeColumnCount) + 1;
        var row = (zeroBasedShotNo / safeColumnCount) + 1;

        return $"{ToColumnLetters(column)}{row}";
    }

    private static string ToColumnLetters(int oneBasedColumn)
    {
        var value = Math.Max(1, oneBasedColumn);
        var text = "";

        while (value > 0)
        {
            value--;
            text = (char)('A' + (value % 26)) + text;
            value /= 26;
        }

        return text;
    }
}

public sealed record ST_REVIEW_PLAN(
    string RecipeId,
    int CellCount,
    double ToleranceX,
    double ToleranceY,
    EN_VISION_FLIP_TYPE VisionFlipType,
    DateTimeOffset CreatedAt,
    IReadOnlyList<ST_REVIEW_PLAN_POINT> Points)
{
    public IReadOnlyList<ST_REVIEW_PLAN_POINT> GetCellPoints(int cellNo)
    {
        if (Points is CReviewRuntimePoints runtime) return runtime.Cell(cellNo);
        if (Points is IReviewCellPointSource cellSource &&
            cellNo >= 1 &&
            cellNo <= cellSource.PatternCellCount)
        {
            var range = cellSource.GetCellRange(cellNo - 1);
            var cellPoints = new List<ST_REVIEW_PLAN_POINT>(range.PointCount);
            for (var index = 0; index < range.PointCount; index++)
            {
                cellPoints.Add(Points[range.StartIndex + index]);
            }

            return cellPoints;
        }

        var matchingPoints = new List<ST_REVIEW_PLAN_POINT>();
        foreach (var point in Points)
        {
            if (point.CellNo == cellNo)
            {
                matchingPoints.Add(point);
            }
        }

        return matchingPoints;
    }

    public ST_REVIEW_PLAN_POINT? FindPoint(int cellNo, int shotNo)
    {
        if (Points is CReviewRuntimePoints runtime) return runtime.Find(cellNo, shotNo);
        if (Points is IReviewCellPointSource cellSource &&
            cellNo >= 1 &&
            cellNo <= cellSource.PatternCellCount)
        {
            var range = cellSource.GetCellRange(cellNo - 1);
            return shotNo >= 1 && shotNo <= range.PointCount
                ? Points[range.StartIndex + shotNo - 1]
                : null;
        }

        foreach (var point in Points)
        {
            if (point.CellNo == cellNo && point.ShotNo == shotNo)
            {
                return point;
            }
        }

        return null;
    }

    public ST_REVIEW_CORRECTION_PLAN? CorrectionPlan { get; init; }

    public string InspectionMethod { get; init; } = "P2P";

    public double StageScanDirectionY { get; init; } = -1.0;

    private static readonly ConditionalWeakTable<
        IReadOnlyList<ST_REVIEW_PLAN_POINT>,
        CReviewPointCache> ReviewPointCaches = new();

    private CReviewPointCache ReviewPointCache =>
        ReviewPointCaches.GetValue(Points, static points => new CReviewPointCache(points));

    public IReadOnlyList<ST_REVIEW_PLAN_POINT> ReviewPoints => Points is CReviewRuntimePoints runtime
        ? runtime.SelectedPoints : ReviewPointCache.ReviewPoints;

    // A new run/retry supplies a full initial snapshot; later publications carry
    // only changed Shots. Consumers may coalesce these deltas without rescanning Points.
    public Guid RuntimeId { get; init; }
    public IReadOnlyList<ST_REVIEW_PLAN_POINT>? PointUpdates { get; init; }

    private sealed class CReviewPointCache(IReadOnlyList<ST_REVIEW_PLAN_POINT> points)
    {
        public IReadOnlyList<ST_REVIEW_PLAN_POINT> ReviewPoints { get; } =
            points.Count == 0 ||
            points is IReviewPointListInfo { AreAllPointsSelected: true } ||
            points.All(point => point.Use)
                ? points
                : points.Where(point => point.Use).ToArray();
    }
}

public sealed record ST_REVIEW_CORRECTION_PLAN(
    EN_REVIEW_CORRECTION_RULE Rule,
    EN_REVIEW_CORRECTION_SCOPE Scope,
    IReadOnlyList<ST_REVIEW_PLAN_POINT> SourcePoints,
    EN_REVIEW_REFERENCE_LINE RoughReference = EN_REVIEW_REFERENCE_LINE.First,
    int FineLineCount = 0);

public sealed record ST_REVIEW_RESULT_DATA(
    ST_REVIEW_PLAN Plan,
    IReadOnlyList<ST_REVIEW_PLAN_POINT> Results,
    DateTimeOffset SavedAt,
    string GlassId = "",
    string InspectionMethod = "P2P")
{
    public string ResultStatus { get; init; } = "COMPLETED";

    public int TotalCount { get; init; }

    public string? TargetFilePath { get; init; }
}

public sealed record ST_REVIEW_RESULT_FILE_ROW(
    DateTimeOffset SavedAt,
    string RecipeId,
    string ShotKey,
    string ShotName,
    int HeadNo,
    int CellNo,
    double ErrorX,
    double ErrorY,
    string Judge);

public sealed record ST_REVIEW_RESULT_FILE_DATA(
    string FilePath,
    string FileName,
    string RecipeId,
    DateTimeOffset SavedAt,
    IReadOnlyList<ST_REVIEW_RESULT_FILE_ROW> Rows)
{
    public string GlassId { get; init; } = "";

    public string InspectionMethod { get; init; } = "";

    public string Rule { get; init; } = "";

    public string RuleScope { get; init; } = "";

    public int BeamNo { get; init; } = 1;

    public int? ReferenceCellNo { get; init; }

    public string ReferenceShot { get; init; } = "";

    public string RoughReference { get; init; } = "";

    public int FineLineCount { get; init; }

    public string ResultStatus { get; init; } = "COMPLETED";

    public int TotalCount { get; init; }
}

public interface IReviewResultFile
{
    string RootPath { get; }

    Task<ST_REVIEW_RESULT_FILE_DATA> Load(
        string path,
        CancellationToken cancellationToken = default);

    Task Save(
        ST_REVIEW_RESULT_DATA result,
        CancellationToken cancellationToken = default);
}

// The surrounding application still exposes Review files through these base
// classes.  Keeping the compatibility layer here lets the new Review engine
// run without changing the existing manager/configuration wiring.
public abstract class CReviewResultFileBase : IReviewResultFile
{
    public virtual Task<string> SaveFineCorrection(ST_FINE_REVIEW_RESULT_DATA result, CancellationToken cancellationToken = default) =>
        throw new NotSupportedException("FINE 검사 결과 저장이 구현되지 않았습니다.");
    public virtual Task<string> SaveRoughCorrection(
        ST_ROUGH_REVIEW_RESULT_DATA result, CancellationToken cancellationToken = default) =>
        throw new NotSupportedException("ROUGH 검사 결과 저장이 구현되지 않았습니다.");

    public virtual Task<ST_BEAM_INSPECTION_RESULT_FILE_DATA?> LoadLastBeamInspection(
        CancellationToken cancellationToken = default) =>
        throw new NotSupportedException("Beam Inspection 결과 불러오기가 구현되지 않았습니다.");

    public virtual Task<string> SaveBeamInspection(
        ST_BEAM_INSPECTION_SNAPSHOT result, string glassId, DateTimeOffset savedAt,
        CancellationToken cancellationToken = default) =>
        throw new NotSupportedException("Beam Inspection 결과 저장이 구현되지 않았습니다.");

    public abstract string RootPath { get; }

    public virtual IReadOnlyList<string> SearchRootPaths => [RootPath];

    public virtual string? LastSavedPath => null;

    public abstract Task<ST_REVIEW_RESULT_FILE_DATA> Load(
        string path,
        CancellationToken cancellationToken = default);

    public abstract Task Save(
        ST_REVIEW_RESULT_DATA result,
        CancellationToken cancellationToken = default);
}

public sealed record ST_REVIEW_OFFSET_ROW(
    int CellId,
    string ShotId,
    double ReviewOffsetX,
    double ReviewOffsetY)
{
    // Files without coordinate metadata contain legacy scanner-coordinate offsets.
    public bool IsDesignCoordinate { get; init; }
}

public sealed record ST_REVIEW_OFFSET_FILE_DATA(
    string RecipeId,
    string FilePath,
    string FileName,
    DateTimeOffset SavedAt,
    IReadOnlyList<ST_REVIEW_OFFSET_ROW> Rows)
{
    public static ST_REVIEW_OFFSET_FILE_DATA Empty(string recipeId)
    {
        return new ST_REVIEW_OFFSET_FILE_DATA(recipeId, "", "", DateTimeOffset.MinValue, []);
    }
}

public abstract class CReviewOffsetFileBase
{
    public abstract string RootPath { get; }

    public abstract Task<ST_REVIEW_OFFSET_FILE_DATA> LoadLatest(
        string recipeId,
        CancellationToken cancellationToken = default);

    public abstract Task<ST_REVIEW_OFFSET_FILE_DATA> SaveNew(
        string recipeId,
        IReadOnlyList<ST_REVIEW_OFFSET_ROW> rows,
        CancellationToken cancellationToken = default);
}

public interface IReviewManager
{
    ST_REVIEW_PLAN? CurrentPlan { get; }

    ST_REVIEW_PLAN_POINT? CurrentPoint { get; }

    ST_REVIEW_PLAN_POINT? LastMeasuredPoint { get; }

    EN_REVIEW_SEQUENCE_STATE SequenceState { get; }

    ST_REVIEW_PLAN CreatePlan(
        ST_RECIPE_DEFINITION recipe,
        IReadOnlyCollection<string> selectedShotKeys);

    ST_REVIEW_PLAN CreatePlan(
        ST_RECIPE_DEFINITION recipe,
        IReadOnlyCollection<string> selectedShotKeys,
        int selectedBeamNo);

    ST_REVIEW_PLAN CreateAllPlan(
        ST_RECIPE_DEFINITION recipe,
        int selectedBeamNo);

    Task<ST_REVIEW_SEQUENCE_STATUS> Start(
        ST_REVIEW_PLAN plan,
        string? productId,
        Action<ST_REVIEW_PLAN>? progress = null,
        CancellationToken cancellationToken = default);

    void Stop();

    Task<ST_REVIEW_SEQUENCE_STATUS> RetryRemaining(
        Action<ST_REVIEW_PLAN>? progress = null,
        CancellationToken cancellationToken = default);

}

public sealed partial class CReviewManager(
    CReviewResultFileBase reviewResultFile,
    CInterfaceManager interfaceManager,
    CSettingManager settingManager,
    CProductManager? productManager = null,
    CLogManager? logManager = null) : IReviewManager
{
    private const int DefaultReviewBeamNo = 1;
    private const int MaxHeadCount = 8;
    private const int DefaultHeadCount = 8;
    private const int DefaultCellCount = 20;
    private const int IofInspectionType = 0;
    private const double ReviewSequenceRowTolerance = 0.001;
    private static readonly ConditionalWeakTable<
        ST_RECIPE_DEFINITION,
        Dictionary<string, string>> RecipeParameterIndexes = new();
    private readonly SemaphoreSlim _sequenceLock = new(1, 1);
    private readonly object _stateLock = new();
    private int _stopRequested;
    private int _sequenceState = (int)EN_REVIEW_SEQUENCE_STATE.Idle;
    private ST_REVIEW_PLAN? _currentPlan;
    private ST_REVIEW_PLAN_POINT? _currentPoint;
    private ST_REVIEW_PLAN_POINT? _lastMeasuredPoint;
    private string? _reviewProductId;

    public string? LastSavedResultPath { get; private set; }

    public ST_REVIEW_PLAN? CurrentPlan
    {
        get
        {
            lock (_stateLock)
            {
                return _currentPlan;
            }
        }
    }

    public EN_REVIEW_SEQUENCE_STATE SequenceState
    {
        get => (EN_REVIEW_SEQUENCE_STATE)Volatile.Read(ref _sequenceState);
        private set => Volatile.Write(ref _sequenceState, (int)value);
    }

    private bool IsStopRequested => Volatile.Read(ref _stopRequested) != 0;

    public ST_REVIEW_PLAN CreatePlan(
        ST_RECIPE_DEFINITION recipe,
        IReadOnlyCollection<string> selectedShotKeys)
    {
        return CreatePlan(recipe, selectedShotKeys, 1);
    }

    public ST_REVIEW_PLAN CreatePlan(
        ST_RECIPE_DEFINITION recipe,
        IReadOnlyCollection<string> selectedShotKeys,
        int selectedBeamNo)
    {
        ValidateBeamNo(
            selectedBeamNo,
            ReadInt(recipe, 0, "SPLITED_BEAM_COUNT"));

        var selectedSet = selectedShotKeys
            .Where(key => !string.IsNullOrWhiteSpace(key))
            .Select(NormalizeShotKey)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        var allPlan = CreateAllPlan(recipe, selectedBeamNo);
        if (selectedSet.Count == 0)
        {
            return allPlan with { Points = [] };
        }

        var selectedPoints = new List<ST_REVIEW_PLAN_POINT>(selectedSet.Count);
        foreach (var key in selectedSet)
        {
            if (!TryParseShotKey(key, out var cellNo, out var shotNo) ||
                cellNo > allPlan.CellCount)
            {
                continue;
            }

            var point = allPlan.FindPoint(cellNo, shotNo);
            if (point is null || !point.Use)
            {
                continue;
            }

            selectedPoints.Add(point with
            {
                Use = true,
                State = EN_REVIEW_POINT_STATE.Ready,
                Judge = "WAIT"
            });
        }

        return allPlan with
        {
            Points = selectedPoints
                .OrderBy(point => point.PointNo)
                .ToArray()
        };
    }

    public ST_REVIEW_PLAN_POINT? CurrentPoint
    {
        get
        {
            lock (_stateLock)
            {
                return _currentPoint;
            }
        }
    }

    public ST_REVIEW_PLAN_POINT? LastMeasuredPoint
    {
        get
        {
            lock (_stateLock)
            {
                return _lastMeasuredPoint;
            }
        }
    }

    public static IReadOnlyList<ST_REVIEW_BEAM_POSITION> GetShotBeamPositions(
        ST_RECIPE_DEFINITION recipe,
        ST_REVIEW_PLAN_POINT point,
        double stageScanDirectionY)
    {
        var calculate = CreateShotBeamPositionCalculator(recipe, stageScanDirectionY);
        var splitBeamCount = ReadInt(recipe, 0, "SPLITED_BEAM_COUNT");
        return Enumerable.Range(1, splitBeamCount * splitBeamCount).Select(beam => calculate(point, beam)).ToArray();
    }

    /// <summary>Build recipe lookup and Cell geometry once for a batch. No device access or live recipe mutation.</summary>
    public static Func<ST_REVIEW_PLAN_POINT, int, ST_REVIEW_BEAM_POSITION> CreateShotBeamPositionCalculator(
        ST_RECIPE_DEFINITION recipe, double stageScanDirectionY)
    {
        var splitBeamCount = ReadInt(recipe, 0, "SPLITED_BEAM_COUNT");
        ValidateBeamNo(1, splitBeamCount);
        var parameters = recipe.Parameters
            .GroupBy(parameter => parameter.Key, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(group => group.Key, group => group.Last().Value, StringComparer.OrdinalIgnoreCase);
        var pixelSize = ReadDouble(recipe, 0.0, "PIXEL_SIZE");
        var marginX = ReadDouble(recipe, 55.0, "AK_MARGIN_X", "ALIGN_MARGIN_X");
        var marginY = ReadDouble(recipe, 45.0, "AK_MARGIN_Y", "ALIGN_MARGIN_Y");
        var cameraAlignX = ReadDouble(recipe, 0.0, "REVIEW_CAMERA_ALIGN_KEY_POS_X");
        var cameraAlignY = ReadDouble(recipe, 0.0, "REVIEW_CAMERA_ALIGN_KEY_POS_Y");
        var cells = new System.Collections.Concurrent.ConcurrentDictionary<int, (double Rotation, double BeamPitch)>();
        return (point, beamNo) =>
        {
            ValidateBeamNo(beamNo, splitBeamCount);
            var cell = cells.GetOrAdd(point.CellNo, cellNo =>
            {
                var model = CRecipeModelPixelCountReader.ReadPatternForCell(parameters, cellNo);
                var rotation = ReadDouble(recipe, 0.0, $"CELL{cellNo}_ROTATION");
                var layout = CCellPatternCalculator.Calculate(new ST_CELL_PATTERN_DEFINITION(cellNo, 0, 0, rotation,
                    pixelSize, model.PixelCountX, model.PixelCountY, model.ProcessPitch, splitBeamCount), includeShotCenters: false);
                if (!layout.IsValid) throw new InvalidOperationException(layout.ValidationMessage);
                return (rotation, layout.BeamPitchMillimeters);
            });
            var offset = CalculateBeamOffset(beamNo, splitBeamCount, cell.BeamPitch);
            var target = CalculateReviewTarget(point.DesignX - marginX, point.DesignY - marginY,
                cameraAlignX, cameraAlignY, offset.X, offset.Y, cell.Rotation, stageScanDirectionY);
            if (!double.IsFinite(target.X) || !double.IsFinite(target.Y))
                throw new InvalidOperationException($"Beam {beamNo}의 목표 위치를 계산할 수 없습니다.");
            return new ST_REVIEW_BEAM_POSITION(beamNo, target.Y, target.X);
        };
    }

    public ST_REVIEW_PLAN CreateAllPlan(
        ST_RECIPE_DEFINITION recipe,
        int selectedBeamNo)
    {
        ValidateBeamNo(
            selectedBeamNo,
            ReadInt(recipe, 0, "SPLITED_BEAM_COUNT"));

        return CreatePlanCore(
            recipe,
            _ => true,
            selectedBeamNo,
            selectAllAssignedPoints: true);
    }

    /// <summary>
    /// Returns the same physical head scan fields used while assigning Review
    /// plan points.  Review UI uses these values to render a global Head scope
    /// exactly like Main, instead of inferring a range from Cell columns.
    /// </summary>
    public IReadOnlyList<ST_REVIEW_HEAD_SCOPE> GetHeadScopes(
        ST_RECIPE_DEFINITION recipe)
    {
        return LoadReviewCoordinateSettings(recipe)
            .HeadLayout
            .Fields
            .Select(field => new ST_REVIEW_HEAD_SCOPE(
                field.HeadNo,
                field.PositionX,
                field.ScanFieldWidthX))
            .ToArray();
    }

    public Task<ST_REVIEW_SEQUENCE_STATUS> Start(
        ST_REVIEW_PLAN plan,
        string? productId,
        Action<ST_REVIEW_PLAN>? progress = null,
        CancellationToken cancellationToken = default)
    {
        return Start(plan, productId, null, false, progress, cancellationToken);
    }

    public async Task<ST_REVIEW_SEQUENCE_STATUS> Start(
        ST_REVIEW_PLAN plan,
        string? productId,
        ST_PRODUCT_REVIEW_DATA? checkpoint,
        bool resumeCheckpoint,
        Action<ST_REVIEW_PLAN>? progress = null,
        CancellationToken cancellationToken = default)
    {
        if (!await _sequenceLock.WaitAsync(0, cancellationToken))
        {
            return CreateStatus(
                CurrentPlan ?? plan,
                EN_REVIEW_SEQUENCE_STATE.Running,
                "Review sequence is already running.");
        }

        string? reviewProductId = null;
        var runInitialized = false;

        try
        {
            LastSavedResultPath = null;
            reviewProductId = ResolveReviewProductId(plan, productId);
            SetReviewProductId(reviewProductId);
            Interlocked.Exchange(ref _stopRequested, 0);
            var unassignedPoint = plan.ReviewPoints.FirstOrDefault(point => point.HeadNo <= 0);
            if (unassignedPoint is not null)
            {
                SequenceState = EN_REVIEW_SEQUENCE_STATE.Failed;
                WriteReviewLog(
                    "START",
                    "Review could not start because a processing Head is not assigned.");
                return CreateStatus(
                    plan,
                    SequenceState,
                    $"Review point {unassignedPoint.ShotKey} is not assigned to a processing Head.");
            }

            if (plan.ReviewPoints.Count == 0)
            {
                SequenceState = EN_REVIEW_SEQUENCE_STATE.Failed;
                WriteReviewLog(
                    "START",
                    "Review could not start because there is no inspection target.");
                return CreateStatus(plan, SequenceState, "Executable review point is empty.");
            }

            SequenceState = EN_REVIEW_SEQUENCE_STATE.Running;
            SetActivePoints(null, null);
            var workingPlan = resumeCheckpoint && checkpoint is not null
                ? RestoreCheckpoint(plan, checkpoint)
                : ResetPlanForRun(plan);
            workingPlan = PrepareRuntimePlan(workingPlan);
            SetCurrentPlan(workingPlan, progress);
            runInitialized = true;
            _reviewStageMotion = OpenReviewStageMotion();
            WriteReviewLog(
                resumeCheckpoint && checkpoint is not null ? "RESUME" : "START",
                resumeCheckpoint && checkpoint is not null
                    ? "Review resumed."
                    : "Review started.");
            if (!string.IsNullOrWhiteSpace(reviewProductId) && productManager is not null)
            {
                await productManager.SetReviewRunning(
                    reviewProductId,
                    CreateProductReviewData(
                        workingPlan,
                        resumeCheckpoint ? checkpoint?.SavedAt : null),
                    cancellationToken);
            }

            if (!IsPointToPoint(workingPlan))
            {
                return await RunIofSequence(
                    workingPlan,
                    reviewProductId,
                    progress,
                    cancellationToken,
                    resumeFromCurrentPosition: resumeCheckpoint);
            }

            foreach (var point in OrderPtoPFromCurrentPosition(
                workingPlan.ReviewPoints.Where(point => point.State is not (EN_REVIEW_POINT_STATE.Ok or EN_REVIEW_POINT_STATE.Ng)),
                resumeCheckpoint))
            {
                cancellationToken.ThrowIfCancellationRequested();

                if (point.State is EN_REVIEW_POINT_STATE.Ok or EN_REVIEW_POINT_STATE.Ng)
                {
                    continue;
                }

                if (IsStopRequested)
                {
                    SequenceState = EN_REVIEW_SEQUENCE_STATE.Stopped;
                    workingPlan = SetWaitingPointsReady(workingPlan);
                    SetCurrentPlan(workingPlan, progress);
                    return await CreateStoppedStatus(workingPlan, reviewProductId, "Review sequence stopped.");
                }

                var currentPoint = point with
                {
                    State = EN_REVIEW_POINT_STATE.Current,
                    Judge = "WAIT"
                };
                SetActivePoints(currentPoint, LastMeasuredPoint);
                workingPlan = UpdatePoint(workingPlan, currentPoint);
                SetCurrentPlan(workingPlan, progress);

                await MoveStageY(currentPoint, cancellationToken);

                if (IsStopRequested)
                {
                    SequenceState = EN_REVIEW_SEQUENCE_STATE.Stopped;
                    workingPlan = UpdatePoint(workingPlan, currentPoint with { State = EN_REVIEW_POINT_STATE.Ready });
                    SetCurrentPlan(workingPlan, progress);
                    return await CreateStoppedStatus(workingPlan, reviewProductId, "Review sequence stopped.");
                }

                await MoveVisionX(
                    currentPoint,
                    waitForMoveCompletion: true,
                    cancellationToken);

                if (IsStopRequested)
                {
                    SequenceState = EN_REVIEW_SEQUENCE_STATE.Stopped;
                    workingPlan = UpdatePoint(workingPlan, currentPoint with { State = EN_REVIEW_POINT_STATE.Ready });
                    SetCurrentPlan(workingPlan, progress);
                    return await CreateStoppedStatus(workingPlan, reviewProductId, "Review sequence stopped.");
                }

                var measurement = await MeasureVision(currentPoint, cancellationToken);

                if (IsStopRequested)
                {
                    SequenceState = EN_REVIEW_SEQUENCE_STATE.Stopped;
                    workingPlan = UpdatePoint(workingPlan, currentPoint with { State = EN_REVIEW_POINT_STATE.Ready });
                    SetCurrentPlan(workingPlan, progress);
                    return await CreateStoppedStatus(workingPlan, reviewProductId, "Review sequence stopped.");
                }

                var measuredPoint = ApplyMeasurement(workingPlan, currentPoint, measurement);
                SetActivePoints(null, measuredPoint);
                workingPlan = UpdatePoint(workingPlan, measuredPoint);
                SetCurrentPlan(workingPlan, progress);
                await SaveProgressToProduct(
                    workingPlan,
                    reviewProductId,
                    cancellationToken);
            }

            SequenceState = EN_REVIEW_SEQUENCE_STATE.Completed;
            SetCurrentPlan(workingPlan, progress);
            await SaveResultForProduct(
                workingPlan,
                workingPlan.ReviewPoints,
                reviewProductId,
                cancellationToken);
            WriteReviewLog(
                "COMPLETE",
                "Review completed.");
            return CreateStatus(workingPlan, SequenceState, "Review sequence completed.");
        }
        catch (OperationCanceledException)
        {
            _reviewStageMotion?.Stop();
            SequenceState = EN_REVIEW_SEQUENCE_STATE.Stopped;
            var stoppedPlan = SetWaitingPointsReady(CurrentPlan ?? plan);
            SetCurrentPlan(stoppedPlan, progress);
            return await CreateStoppedStatus(stoppedPlan, reviewProductId, "Review sequence canceled.");
        }
        catch (Exception ex)
        {
            _reviewStageMotion?.Stop();
            SequenceState = EN_REVIEW_SEQUENCE_STATE.Failed;
            var failedPlan = SetWaitingPointsReady(CurrentPlan ?? plan);
            SetCurrentPlan(failedPlan, progress);
            WriteReviewError();
            var updateResult = await TrySetProductReviewError(reviewProductId, ex.Message);
            return CreateStatus(failedPlan, SequenceState, AppendUpdateResult(ex.Message, updateResult));
        }
        finally
        {
            if (runInitialized) RememberInterruptedReview(reviewProductId);
            _reviewStageMotion?.Dispose(); _reviewStageMotion = null;
            _sequenceLock.Release();
        }
    }

    public void Stop()
    {
        Interlocked.Exchange(ref _stopRequested, 1);
        _reviewStageMotion?.Stop();
        var plan = CurrentPlan;
        WriteReviewLog(
            "STOP_REQUEST",
            "Review stop requested.");
        if (SequenceState == EN_REVIEW_SEQUENCE_STATE.Running)
        {
            SequenceState = EN_REVIEW_SEQUENCE_STATE.Stopping;
        }
    }

    public Task<ST_PRODUCT_REVIEW_DATA?> FindIncompleteProductReview(
        ST_REVIEW_PLAN plan,
        string glassId,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (FindInterruptedReviewCheckpoint(plan, glassId) is { } interrupted)
            return Task.FromResult<ST_PRODUCT_REVIEW_DATA?>(interrupted);
        if (string.IsNullOrWhiteSpace(glassId) ||
            productManager?.Current is not { } product ||
            !product.GlassId.Equals(glassId, StringComparison.OrdinalIgnoreCase) ||
            !IsMatchingIncompleteReview(plan, product.RecipeId, product.Review))
        {
            return Task.FromResult<ST_PRODUCT_REVIEW_DATA?>(null);
        }

        return Task.FromResult<ST_PRODUCT_REVIEW_DATA?>(product.Review);
    }

    public ST_SCANNER_AXIS_TRANSFORM GetScannerAxisTransform(int headNo)
    {
        if (headNo is < 1 or > DefaultHeadCount)
        {
            throw new ArgumentOutOfRangeException(
                nameof(headNo),
                headNo,
                $"Head number must be between 1 and {DefaultHeadCount}.");
        }

        return CScannerAxisTransform.Read(
            settingManager.LoadSection(EN_SETTING_TAB.Option),
            headNo);
    }

    public async Task<ST_REVIEW_SEQUENCE_STATUS> RetryRemaining(
        Action<ST_REVIEW_PLAN>? progress = null,
        CancellationToken cancellationToken = default)
    {
        var plan = CurrentPlan;
        if (plan is null)
        {
            return new ST_REVIEW_SEQUENCE_STATUS(
                EN_REVIEW_SEQUENCE_STATE.Idle,
                0,
                0,
                0,
                "Review plan is empty.");
        }

        plan = SetWaitingPointsReady(plan);
        SetCurrentPlan(plan, progress);

        var points = plan.ReviewPoints
            .Where(point => point.State == EN_REVIEW_POINT_STATE.Ready);
        var orderedPoints = OrderByReviewSequence(points)
            .ToArray();

        if (orderedPoints.Length == 0)
        {
            return CreateStatus(plan, SequenceState, "Ready review point is empty.");
        }

        return await RunRetryPoints(orderedPoints, "Review ready point retry completed.", progress, cancellationToken);
    }

    private string? ResolveReviewProductId(ST_REVIEW_PLAN plan, string? productId)
    {
        if (string.IsNullOrWhiteSpace(productId) || productManager?.Current is not { } product)
        {
            return null;
        }

        if (!product.GlassId.Equals(productId, StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException(
                $"Review Glass ID mismatch. Current={product.GlassId}, Input={productId}");
        }

        if (!string.IsNullOrWhiteSpace(product.RecipeId) &&
            !product.RecipeId.Equals(plan.RecipeId, StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException(
                $"Review Recipe mismatch. Product={product.RecipeId}, Review={plan.RecipeId}");
        }

        return product.GlassId;
    }

    private async Task SaveResultForProduct(
        ST_REVIEW_PLAN plan,
        IReadOnlyList<ST_REVIEW_PLAN_POINT> results,
        string? reviewProductId,
        CancellationToken cancellationToken)
    {
        var savedAt = DateTimeOffset.Now;
        var resultFileRows = GetMeasuredResultRows(results);
        await reviewResultFile.Save(
            new ST_REVIEW_RESULT_DATA(
                plan,
                resultFileRows,
                savedAt,
                reviewProductId ?? "",
                plan.InspectionMethod)
            {
                ResultStatus = "COMPLETED",
                TotalCount = plan.ReviewPoints.Count,
                TargetFilePath = null
            },
            cancellationToken).ConfigureAwait(false);
        LastSavedResultPath = reviewResultFile.LastSavedPath;
        WriteReviewLog(
            "RESULT_FILE_SAVED",
            "Review result file saved.");

        if (string.IsNullOrWhiteSpace(reviewProductId) || productManager is null)
        {
            return;
        }

        var productResults = CreateProductReviewResults(results);
        await productManager.SetReviewCompleted(
            reviewProductId,
            savedAt,
            productResults,
            CancellationToken.None).ConfigureAwait(false);
    }

    private async Task SaveProgressToProduct(
        ST_REVIEW_PLAN plan,
        string? reviewProductId,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(reviewProductId) || productManager is null)
        {
            return;
        }

        await productManager.SetReviewProgress(
            reviewProductId,
            CreateProductReviewData(plan, DateTimeOffset.Now),
            cancellationToken).ConfigureAwait(false);
    }

    private static ST_PRODUCT_REVIEW_DATA CreateProductReviewData(
        ST_REVIEW_PLAN plan,
        DateTimeOffset? savedAt)
    {
        var projection = plan.CorrectionPlan;
        ST_REVIEW_PLAN_POINT? referencePoint = null;
        foreach (var point in plan.ReviewPoints)
        {
            referencePoint = point;
            break;
        }

        return new ST_PRODUCT_REVIEW_DATA(
            EN_PRODUCT_PROCESS_STATE.Running,
            savedAt,
            CreateProductReviewResults(plan.ReviewPoints))
        {
            InspectionMethod = plan.InspectionMethod,
            RecipeId = plan.RecipeId,
            Rule = projection?.Rule.ToString().ToUpperInvariant() ?? "ALL",
            RuleScope = projection is null
                ? ""
                : projection.Scope == EN_REVIEW_CORRECTION_SCOPE.HeadCell ? "HEAD_CELL" : "HEAD",
            BeamNo = referencePoint?.BeamNo ?? DefaultReviewBeamNo,
            ReferenceCellNo = projection?.Rule == EN_REVIEW_CORRECTION_RULE.Simple
                ? referencePoint?.CellNo
                : null,
            ReferenceShot = projection?.Rule == EN_REVIEW_CORRECTION_RULE.Simple
                ? FormatShotName(referencePoint)
                : "",
            RoughReference = projection?.Rule == EN_REVIEW_CORRECTION_RULE.Rough
                ? projection.RoughReference.ToString().ToUpperInvariant()
                : "",
            FineLineCount = projection?.Rule == EN_REVIEW_CORRECTION_RULE.Fine
                ? projection.FineLineCount
                : 0,
            TotalCount = plan.ReviewPoints.Count
        };
    }

    private static IReadOnlyList<ST_PRODUCT_REVIEW_RESULT> CreateProductReviewResults(
        IReadOnlyList<ST_REVIEW_PLAN_POINT> results)
    {
        var productResults = new List<ST_PRODUCT_REVIEW_RESULT>();
        foreach (var point in results)
        {
            if (!point.Use ||
                point.State is not (EN_REVIEW_POINT_STATE.Ok or EN_REVIEW_POINT_STATE.Ng))
            {
                continue;
            }

            productResults.Add(new ST_PRODUCT_REVIEW_RESULT(
                $"CELL{point.CellNo}_{FormatShotName(point)}",
                point.HeadNo,
                point.CellNo,
                point.BeamNo,
                point.ErrorX,
                point.ErrorY,
                point.Judge));
        }

        return productResults;
    }

    private static bool IsPointToPoint(ST_REVIEW_PLAN plan)
    {
        return plan.InspectionMethod.Equals("P2P", StringComparison.OrdinalIgnoreCase);
    }

    private static bool IsMatchingIncompleteReview(
        ST_REVIEW_PLAN plan,
        string productRecipeId,
        ST_PRODUCT_REVIEW_DATA review)
    {
        var checkpointRecipeId = string.IsNullOrWhiteSpace(review.RecipeId)
            ? productRecipeId
            : review.RecipeId;
        if (review.State is EN_PRODUCT_PROCESS_STATE.NotStarted or EN_PRODUCT_PROCESS_STATE.Completed ||
            review.Results.Count == 0 ||
            (!string.IsNullOrWhiteSpace(checkpointRecipeId) &&
             !checkpointRecipeId.Equals(plan.RecipeId, StringComparison.OrdinalIgnoreCase)) ||
            !review.InspectionMethod.Equals(plan.InspectionMethod, StringComparison.OrdinalIgnoreCase) ||
            review.TotalCount != plan.ReviewPoints.Count)
        {
            return false;
        }

        var projection = plan.CorrectionPlan;
        var expectedRule = projection?.Rule.ToString().ToUpperInvariant() ?? "ALL";
        var expectedScope = projection is null
            ? ""
            : projection.Scope == EN_REVIEW_CORRECTION_SCOPE.HeadCell ? "HEAD_CELL" : "HEAD";
        if (!review.Rule.Equals(expectedRule, StringComparison.OrdinalIgnoreCase) ||
            !review.RuleScope.Equals(expectedScope, StringComparison.OrdinalIgnoreCase))
        {
            return false;
        }

        ST_REVIEW_PLAN_POINT? referencePoint = null;
        foreach (var point in plan.ReviewPoints)
        {
            referencePoint = point;
            break;
        }

        var expectedBeamNo = referencePoint?.BeamNo ?? DefaultReviewBeamNo;
        if (review.BeamNo != expectedBeamNo)
        {
            return false;
        }

        if (projection?.Rule == EN_REVIEW_CORRECTION_RULE.Simple &&
            (review.ReferenceCellNo != referencePoint?.CellNo ||
             !review.ReferenceShot.Equals(FormatShotName(referencePoint), StringComparison.OrdinalIgnoreCase)))
        {
            return false;
        }

        if (projection?.Rule == EN_REVIEW_CORRECTION_RULE.Rough &&
            !review.RoughReference.Equals(projection.RoughReference.ToString(), StringComparison.OrdinalIgnoreCase))
        {
            return false;
        }

        if (projection?.Rule == EN_REVIEW_CORRECTION_RULE.Fine &&
            review.FineLineCount != projection.FineLineCount)
        {
            return false;
        }

        var planKeys = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var point in plan.ReviewPoints)
        {
            planKeys.Add(CreateCheckpointPointKey(point));
        }

        foreach (var result in review.Results)
        {
            if (!planKeys.Contains(CreateCheckpointPointKey(result)))
            {
                return false;
            }
        }

        return true;
    }

    private static ST_REVIEW_PLAN RestoreCheckpoint(
        ST_REVIEW_PLAN plan,
        ST_PRODUCT_REVIEW_DATA checkpoint)
    {
        var measuredRows = new Dictionary<string, ST_PRODUCT_REVIEW_RESULT>(StringComparer.OrdinalIgnoreCase);
        foreach (var result in checkpoint.Results)
        {
            measuredRows[CreateCheckpointPointKey(result)] = result;
        }

        var points = new ST_REVIEW_PLAN_POINT[plan.Points.Count];
        for (var index = 0; index < plan.Points.Count; index++)
        {
            var point = plan.Points[index];
            if (!point.Use || !measuredRows.TryGetValue(CreateCheckpointPointKey(point), out var measured))
            {
                points[index] = point with
                {
                    ErrorX = 0.0,
                    ErrorY = 0.0,
                    State = point.Use ? EN_REVIEW_POINT_STATE.Ready : EN_REVIEW_POINT_STATE.Skip,
                    Judge = point.Use ? "WAIT" : "SKIP"
                };
                continue;
            }

            var state = measured.Judge.Equals("NG", StringComparison.OrdinalIgnoreCase)
                ? EN_REVIEW_POINT_STATE.Ng
                : EN_REVIEW_POINT_STATE.Ok;
            points[index] = point with
            {
                ErrorX = measured.ErrorX,
                ErrorY = measured.ErrorY,
                State = state,
                Judge = state == EN_REVIEW_POINT_STATE.Ng ? "NG" : "OK"
            };
        }

        return plan with { Points = points };
    }

    private static string CreateCheckpointPointKey(ST_REVIEW_PLAN_POINT point)
    {
        return CreateCheckpointPointKey(point.HeadNo, point.CellNo, FormatShotName(point), point.ShotKey);
    }

    private static string FormatShotName(ST_REVIEW_PLAN_POINT? point)
    {
        return point is null
            ? ""
            : CReviewShotNameFormatter.ToMatrixName(point.ShotNo, point.PixelCountX);
    }

    private static string CreateCheckpointPointKey(ST_REVIEW_RESULT_FILE_ROW row)
    {
        return CreateCheckpointPointKey(row.HeadNo, row.CellNo, row.ShotName, row.ShotKey);
    }

    private static string CreateCheckpointPointKey(ST_PRODUCT_REVIEW_RESULT result)
    {
        return CreateCheckpointPointKey(
            result.HeadNo,
            result.CellNo,
            "",
            result.ShotKey);
    }

    private static string CreateCheckpointPointKey(
        int headNo,
        int cellNo,
        string shotName,
        string shotKey)
    {
        var normalizedShotName = shotName.Trim().ToUpperInvariant();
        if (string.IsNullOrWhiteSpace(normalizedShotName))
        {
            var separatorIndex = shotKey.LastIndexOf('_');
            if (separatorIndex >= 0 && separatorIndex + 1 < shotKey.Length)
            {
                normalizedShotName = shotKey[(separatorIndex + 1)..].Trim().ToUpperInvariant();
            }
        }

        return $"H{headNo:00}|CELL{cellNo:000}|{normalizedShotName}";
    }

    private async Task<ST_PRODUCT_REVIEW_UPDATE_RESULT> TrySetProductReviewError(
        string? reviewProductId,
        string message)
    {
        if (string.IsNullOrWhiteSpace(reviewProductId) || productManager is null)
        {
            return ST_PRODUCT_REVIEW_UPDATE_RESULT.NotApplicable;
        }

        try
        {
            await productManager.SetReviewError(reviewProductId, message, CancellationToken.None);
            return ST_PRODUCT_REVIEW_UPDATE_RESULT.Success;
        }
        catch (Exception ex)
        {
            return LogProductReviewUpdateFailure(reviewProductId, "REVIEW ERROR UPDATE", ex);
        }
    }

    private async Task<ST_PRODUCT_REVIEW_UPDATE_RESULT> TrySetProductReviewStopped(
        string? reviewProductId,
        string message)
    {
        if (string.IsNullOrWhiteSpace(reviewProductId) || productManager is null)
        {
            return ST_PRODUCT_REVIEW_UPDATE_RESULT.NotApplicable;
        }

        try
        {
            await productManager.SetReviewStopped(reviewProductId, message, CancellationToken.None);
            return ST_PRODUCT_REVIEW_UPDATE_RESULT.Success;
        }
        catch (Exception ex)
        {
            return LogProductReviewUpdateFailure(reviewProductId, "REVIEW STOP UPDATE", ex);
        }
    }

    private async Task<ST_REVIEW_SEQUENCE_STATUS> CreateStoppedStatus(
        ST_REVIEW_PLAN plan,
        string? reviewProductId,
        string message)
    {
        WriteReviewLog(
            "STOP",
            message);
        var updateResult = await TrySetProductReviewStopped(reviewProductId, message);
        if (updateResult.Outcome == EN_PRODUCT_REVIEW_UPDATE_OUTCOME.Failed)
        {
            SequenceState = EN_REVIEW_SEQUENCE_STATE.Failed;
        }

        return CreateStatus(plan, SequenceState, AppendUpdateResult(message, updateResult));
    }

    private ST_PRODUCT_REVIEW_UPDATE_RESULT LogProductReviewUpdateFailure(
        string reviewProductId,
        string action,
        Exception exception)
    {
        var productWasReplaced = productManager?.Current is not { } current
            || !string.Equals(current.GlassId, reviewProductId, StringComparison.Ordinal);
        var outcome = productWasReplaced
            ? EN_PRODUCT_REVIEW_UPDATE_OUTCOME.ProductReplaced
            : EN_PRODUCT_REVIEW_UPDATE_OUTCOME.Failed;
        var detail = productWasReplaced
            ? $"Product changed before Review state could be updated. Error={exception.Message}"
            : $"Failed to persist Product Review state. Error={exception}";

        try
        {
            if (logManager is null)
            {
                System.Diagnostics.Trace.TraceError(detail);
            }
            else
            {
                logManager.WriteProductEvent(
                    reviewProductId,
                    action,
                    "REVIEW",
                    outcome == EN_PRODUCT_REVIEW_UPDATE_OUTCOME.Failed ? "FAILED" : "SKIPPED",
                    detail);
            }
        }
        catch (Exception logException)
        {
            System.Diagnostics.Trace.TraceError(
                $"{detail} Product event logging also failed: {logException}");
        }

        return new ST_PRODUCT_REVIEW_UPDATE_RESULT(outcome, detail);
    }

    private static string AppendUpdateResult(
        string message,
        ST_PRODUCT_REVIEW_UPDATE_RESULT updateResult)
    {
        return updateResult.Outcome switch
        {
            EN_PRODUCT_REVIEW_UPDATE_OUTCOME.ProductReplaced =>
                $"{message} Product changed; Product Review state update was skipped.",
            EN_PRODUCT_REVIEW_UPDATE_OUTCOME.Failed =>
                $"{message} Product Review state update failed: {updateResult.Detail}",
            _ => message
        };
    }

    private ST_REVIEW_PLAN CreatePlanCore(
        ST_RECIPE_DEFINITION recipe,
        Func<ST_REVIEW_PLAN_POINT, bool> useSelector,
        int selectedBeamNo = 1,
        bool selectAllAssignedPoints = false)
    {
        const int headCount = DefaultHeadCount;
        var cellCount = ReadRequiredCellCount(recipe, "MAX_CELL_NUMBER");
        var toleranceX = ReadDouble(recipe, 0.030, "REVIEW_TOLERANCE_X");
        var toleranceY = ReadDouble(recipe, 0.030, "REVIEW_TOLERANCE_Y");
        var coordinateSettings = LoadReviewCoordinateSettings(recipe);
        var runtimeCoordinateParameters = BuildRuntimeCoordinateParameters(recipe);
        var stageScanDirectionY = CShotCoordinatePlanBuilder.ReadDirection(
            runtimeCoordinateParameters,
            -1.0,
            "STAGE_SCAN_DIRECTION_Y");
        var processCoordinatePlan = CShotCoordinatePlanBuilder.Build(
            runtimeCoordinateParameters);
        var excludedShots = BuildReviewExcludedShots(
            runtimeCoordinateParameters,
            processCoordinatePlan.Shots);
        var assignedHeadNos = processCoordinatePlan.Shots
            .GroupBy(shot => (shot.CellNo, shot.CellShotNo))
            .ToDictionary(group => group.Key, group => group.Last().HeadNo);
        IReadOnlyList<ST_REVIEW_PLAN_POINT> points = BuildShotPoints(
            recipe,
            headCount,
            cellCount,
            coordinateSettings,
            assignedHeadNos,
            stageScanDirectionY,
            selectedBeamNo,
            selectAllAssignedPoints,
            excludedShots);
        if (!selectAllAssignedPoints)
        {
            points = points
                .Select(point =>
                {
                    var use = point.HeadNo > 0 &&
                        !excludedShots.ContainsKey(point.ShotKey) &&
                        useSelector(point);

                    return point with
                    {
                        BeamNo = selectedBeamNo,
                        Use = use,
                        State = use ? EN_REVIEW_POINT_STATE.Ready : EN_REVIEW_POINT_STATE.Skip,
                        Judge = use ? "WAIT" : "-"
                    };
                })
                .ToArray();
        }

        return new ST_REVIEW_PLAN(
            recipe.Id,
            cellCount,
            toleranceX,
            toleranceY,
            coordinateSettings.VisionFlipType,
            DateTimeOffset.Now,
            points)
        {
            StageScanDirectionY = stageScanDirectionY
        };
    }

    private static IReadOnlyDictionary<string, string> BuildReviewExcludedShots(
        IReadOnlyDictionary<string, string> runtimeCoordinateParameters,
        IReadOnlyList<ST_HEAD_SHOT_POINT> processShots)
    {
        var maskingPlan = CRecipeShotMaskingPlan.Build(runtimeCoordinateParameters);
        var excludedShots = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var shot in processShots)
        {
            var exclusion = maskingPlan.EvaluateShot(shot);
            if (!exclusion.ShouldSkipLaser)
            {
                continue;
            }

            excludedShots[NormalizeShotKey(shot.ShotKey)] =
                exclusion.IsMasked && exclusion.IsChessSkipped
                    ? "MASKING + CHESS"
                    : exclusion.IsMasked ? "MASKING" : "CHESS";
        }

        return excludedShots;
    }

    private IReadOnlyDictionary<string, string> BuildRuntimeCoordinateParameters(
        ST_RECIPE_DEFINITION recipe)
    {
        var parameters = recipe.Parameters
            .Where(parameter => !string.IsNullOrWhiteSpace(parameter.Key))
            .GroupBy(parameter => parameter.Key, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(
                group => group.Key,
                group => group.Last().Value,
                StringComparer.OrdinalIgnoreCase);

        // Use the same effective parameter set as CStationProcess. Head use,
        // center and scan-field settings can be supplied by Option/Motor and
        // must override the recipe when assigning an actual processing head.
        foreach (var tab in new[] { EN_SETTING_TAB.Option, EN_SETTING_TAB.Motor })
        {
            foreach (var setting in settingManager.LoadSection(tab))
            {
                if (!string.IsNullOrWhiteSpace(setting.Key))
                {
                    parameters[setting.Key] = setting.Value;
                }
            }
        }

        return parameters;
    }

    private ST_REVIEW_COORDINATE_SETTINGS LoadReviewCoordinateSettings(
        ST_RECIPE_DEFINITION recipe)
    {
        var optionSettings = settingManager.LoadSection(EN_SETTING_TAB.Option);
        var visionFlipType = CReviewCoordinateTransformer.ParseVisionFlipType(
            ReadSettingText(optionSettings, "", "VisionXFlip"),
            ReadSettingText(optionSettings, "", "VisionYFlip"),
            ReadSettingText(optionSettings, "", "VisionXyFlip"));

        var headFields = Enumerable.Range(1, 8)
            .Select(headNo =>
            {
                var position = ReadHeadPositionX(optionSettings, headNo);
                const double fallbackWidthX = 110.0;
                var widthX = ReadSettingDouble(
                    optionSettings,
                    fallbackWidthX,
                    $"H{headNo:00}_SCAN_FIELD_WIDTH_X",
                    $"H{headNo:00}_HEAD_FIELD_WIDTH_X");
                return new ST_REVIEW_HEAD_FIELD(
                    headNo,
                    position,
                    widthX > 0.0 ? widthX : fallbackWidthX);
            })
            .ToArray();

        // Keep Review assignment aligned with Main/Process: an explicitly
        // disabled head must not receive a review point.
        var activeHeadNos = headFields
            .Where(field => ReadSettingBoolean(optionSettings, true, $"H{field.HeadNo:00}_USE"))
            .Select(field => field.HeadNo)
            .ToArray();

        return new ST_REVIEW_COORDINATE_SETTINGS(
            new ST_REVIEW_HEAD_LAYOUT(headFields),
            activeHeadNos,
            visionFlipType);
    }

    private static double ReadHeadPositionX(
        IReadOnlyList<ST_SYSTEM_PARAMETER> settings,
        int headNo)
    {
        const double fallbackHead1PositionX = -5.0;
        const double fallbackHeadGapX = 200.0;
        var head1PositionX = ReadSettingDouble(
            settings,
            fallbackHead1PositionX,
            "H01_AK_POSITION_X");
        var headGapX = ReadSettingDouble(
            settings,
            fallbackHeadGapX,
            "HeadGapX");
        return head1PositionX + ((headNo - 1) * headGapX);
    }

    private static double ReadSettingDouble(
        IReadOnlyList<ST_SYSTEM_PARAMETER> settings,
        double defaultValue,
        params string[] keys)
    {
        foreach (var setting in settings)
        {
            if (!keys.Any(key =>
                    key.Equals(setting.Key, StringComparison.OrdinalIgnoreCase) ||
                    key.Equals(setting.Name, StringComparison.OrdinalIgnoreCase)))
            {
                continue;
            }

            if (double.TryParse(setting.Value, NumberStyles.Float, CultureInfo.InvariantCulture, out var parsed))
            {
                return parsed;
            }
        }

        return defaultValue;
    }

    private static bool ReadSettingBoolean(
        IReadOnlyList<ST_SYSTEM_PARAMETER> settings,
        bool defaultValue,
        params string[] keys)
    {
        var text = ReadSettingText(settings, "", keys);
        if (string.IsNullOrWhiteSpace(text))
        {
            return defaultValue;
        }

        if (bool.TryParse(text, out var parsed))
        {
            return parsed;
        }

        return text.Trim().ToUpperInvariant() switch
        {
            "1" or "ON" or "YES" or "Y" => true,
            "0" or "OFF" or "NO" or "N" => false,
            _ => defaultValue
        };
    }

    private static string ReadSettingText(
        IReadOnlyList<ST_SYSTEM_PARAMETER> settings,
        string defaultValue,
        params string[] keys)
    {
        foreach (var setting in settings)
        {
            if (!keys.Any(key =>
                    key.Equals(setting.Key, StringComparison.OrdinalIgnoreCase) ||
                    key.Equals(setting.Name, StringComparison.OrdinalIgnoreCase)))
            {
                continue;
            }

            return string.IsNullOrWhiteSpace(setting.Value)
                ? defaultValue
                : setting.Value.Trim();
        }

        return defaultValue;
    }

    private static IReadOnlyList<ST_REVIEW_PLAN_POINT> BuildShotPoints(
        ST_RECIPE_DEFINITION recipe,
        int headCount,
        int cellCount,
        ST_REVIEW_COORDINATE_SETTINGS coordinateSettings,
        IReadOnlyDictionary<(int CellNo, int CellShotNo), int> assignedHeadNos,
        double stageScanDirectionY,
        int selectedBeamNo,
        bool selectAllAssignedPoints,
        IReadOnlyDictionary<string, string> excludedShots)
    {
        var headLayout = coordinateSettings.HeadLayout;
        var akMarginX = ReadDouble(recipe, 55.0, "AK_MARGIN_X", "ALIGN_MARGIN_X");
        var akMarginY = ReadDouble(recipe, 45.0, "AK_MARGIN_Y", "ALIGN_MARGIN_Y");
        var reviewCameraAlignKeyPosX = ReadDouble(recipe, 0.0, "REVIEW_CAMERA_ALIGN_KEY_POS_X");
        var reviewCameraAlignKeyPosY = ReadDouble(recipe, 0.0, "REVIEW_CAMERA_ALIGN_KEY_POS_Y");
        var pixelSize = ReadDouble(recipe, 0.0, "PIXEL_SIZE");
        var splitBeamCount = ReadInt(recipe, 0, "SPLITED_BEAM_COUNT");
        var recipeParameterMap = recipe.Parameters
            .GroupBy(parameter => parameter.Key, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(group => group.Key, group => group.Last().Value, StringComparer.OrdinalIgnoreCase);
        var modelTypeCount = CRecipeModelPixelCountReader.ReadModelTypeCount(recipeParameterMap);
        ValidateBeamNo(selectedBeamNo, splitBeamCount);
        var definitions = new List<ST_CELL_PATTERN_DEFINITION>(cellCount);

        for (var cellNo = 1; cellNo <= cellCount; cellNo++)
        {
            var firstTargetX = ReadDouble(recipe, 0.0, $"CELL{cellNo}_ALIGN_TO_1ST_PIXEL_X");
            var firstTargetY = ReadDouble(recipe, 0.0, $"CELL{cellNo}_ALIGN_TO_1ST_PIXEL_Y");
            var rotation = ReadDouble(recipe, 0.0, $"CELL{cellNo}_ROTATION");
            var modelType = CRecipeModelPixelCountReader.ReadCellModelType(recipeParameterMap, cellNo, modelTypeCount);
            var modelPattern = CRecipeModelPixelCountReader.ReadPatternForModel(recipeParameterMap, modelType);
            var patternDefinition = new ST_CELL_PATTERN_DEFINITION(
                cellNo,
                firstTargetX,
                firstTargetY,
                rotation,
                pixelSize,
                modelPattern.PixelCountX,
                modelPattern.PixelCountY,
                modelPattern.ProcessPitch,
                splitBeamCount,
                akMarginX,
                akMarginY);
            definitions.Add(patternDefinition);
        }

        var cellCatalog = CRecipeCellPatternCatalog.Create(definitions);
        var allPointsSelected = false;
        if (selectAllAssignedPoints && excludedShots.Count == 0)
        {
            // The no-filter fast path is valid only if every catalog Shot has an active processing Head.
            // Count unique, in-range assignment keys without materializing the lazy coordinate list.
            var shotCounts = cellCatalog.Cells.ToDictionary(cell => cell.Definition.CellNo, cell => cell.Count);
            allPointsSelected = assignedHeadNos.Count(pair => pair.Value > 0 &&
                shotCounts.TryGetValue(pair.Key.CellNo, out var count) && pair.Key.CellShotNo >= 1 && pair.Key.CellShotNo <= count) == cellCatalog.Count;
        }
        return new CLazyReviewPointList(
            cellCatalog,
            allPointsSelected,
            (cell, pointIndex) =>
        {
            var shotGroup = CRecipeCellPatternCatalog.GetShotCenter(cell, pointIndex);
            var beamOffset = CalculateBeamOffset(
                selectedBeamNo,
                splitBeamCount,
                cell.Layout.BeamPitchMillimeters);
            var cellNo = cell.Definition.CellNo;
            var shotName = CReviewShotNameFormatter.ToMatrixName(
                    shotGroup.CellShotNo,
                    cell.Layout.GroupCountX);
                var headNo = assignedHeadNos.TryGetValue(
                    (cellNo, shotGroup.CellShotNo),
                    out var processHeadNo)
                    ? processHeadNo
                    : 0;
                var reviewTarget = CalculateReviewTarget(
                    shotGroup.DesignX - akMarginX,
                    shotGroup.DesignY - akMarginY,
                    reviewCameraAlignKeyPosX,
                    reviewCameraAlignKeyPosY,
                    beamOffset.X,
                    beamOffset.Y,
                    cell.Definition.RotationDegrees,
                    stageScanDirectionY);
                // TODO: Review coordinate transformation will be redesigned in a separate work item.
                // This final command-boundary guard remains intentional until that pipeline owns validation end to end.
                if (!double.IsFinite(reviewTarget.X) || !double.IsFinite(reviewTarget.Y))
                {
                    throw new InvalidOperationException(
                        $"Cell{cellNo} Shot Group {shotGroup.CellShotNo} produced a non-finite review target. " +
                        $"X={reviewTarget.X:R}, Y={reviewTarget.Y:R}.");
                }

            var shotKey = ToShotKey(cellNo, shotGroup.CellShotNo);
            var isExcluded = excludedShots.TryGetValue(shotKey, out var exclusionReason);
            var use = selectAllAssignedPoints && headNo > 0 && !isExcluded;
            return new ST_REVIEW_PLAN_POINT(
                    cell.StartIndex + pointIndex + 1,
                    shotKey,
                    headNo,
                    cellNo,
                    shotGroup.CellShotNo,
                    cell.Layout.GroupCountX,
                    cell.Layout.GroupCountY,
                    use,
                    shotGroup.DesignX,
                    shotGroup.DesignY,
                    reviewTarget.X,
                    reviewTarget.Y,
                    0.0,
                    0.0,
                    use ? EN_REVIEW_POINT_STATE.Ready : EN_REVIEW_POINT_STATE.Skip,
                    use ? "WAIT" : "-")
                {
                    BeamNo = selectedBeamNo,
                    BeamOffsetGx = beamOffset.X,
                    BeamOffsetGy = beamOffset.Y,
                    ExclusionReason = exclusionReason ?? ""
                };
        });
    }

    private static IReadOnlyList<ST_REVIEW_PLAN_POINT> GetMeasuredResultRows(
        IReadOnlyList<ST_REVIEW_PLAN_POINT> results)
    {
        var measuredRows = new List<ST_REVIEW_PLAN_POINT>();
        foreach (var point in results)
        {
            if (point.Use &&
                point.State is EN_REVIEW_POINT_STATE.Ok or EN_REVIEW_POINT_STATE.Ng)
            {
                measuredRows.Add(point);
            }
        }

        return measuredRows;
    }

    public static IReadOnlyList<ST_REVIEW_PLAN_POINT> ProjectCorrectionRows(
        ST_REVIEW_PLAN plan,
        IReadOnlyList<ST_REVIEW_PLAN_POINT> measuredResults)
    {
        if (plan.CorrectionPlan is not { SourcePoints.Count: > 0 } projection)
        {
            return measuredResults;
        }

        var measuredPoints = measuredResults
            .Where(point => point.Use &&
                point.State is EN_REVIEW_POINT_STATE.Ok or EN_REVIEW_POINT_STATE.Ng)
            .ToArray();
        if (measuredPoints.Length == 0)
        {
            return measuredResults;
        }

        return projection.Rule switch
        {
            EN_REVIEW_CORRECTION_RULE.Simple => ProjectSimpleResultRows(
                projection,
                measuredPoints),
            EN_REVIEW_CORRECTION_RULE.Rough => ProjectRoughResultRows(
                projection,
                measuredPoints),
            EN_REVIEW_CORRECTION_RULE.Fine => ProjectFineResultRows(
                projection.SourcePoints,
                measuredPoints),
            EN_REVIEW_CORRECTION_RULE.Edge => measuredPoints,
            _ => measuredPoints
        };
    }

    private static IReadOnlyList<ST_REVIEW_PLAN_POINT> ProjectSimpleResultRows(
        ST_REVIEW_CORRECTION_PLAN projection,
        IReadOnlyList<ST_REVIEW_PLAN_POINT> measuredPoints)
    {
        if (measuredPoints.Count != 1)
        {
            return measuredPoints;
        }

        var measuredPoint = measuredPoints[0];
        return projection.SourcePoints
            .Where(point => point.HeadNo == measuredPoint.HeadNo &&
                (projection.Scope != EN_REVIEW_CORRECTION_SCOPE.HeadCell ||
                    point.CellNo == measuredPoint.CellNo))
            .Where(point => point.HeadNo > 0)
            .Select(point => CopyMeasurement(point, measuredPoint))
            .ToArray();
    }

    private static IReadOnlyList<ST_REVIEW_PLAN_POINT> ProjectRoughResultRows(
        ST_REVIEW_CORRECTION_PLAN projection,
        IReadOnlyList<ST_REVIEW_PLAN_POINT> measuredPoints)
    {
        var measurements = measuredPoints
            .GroupBy(point => projection.Scope == EN_REVIEW_CORRECTION_SCOPE.HeadCell
                ? (point.HeadNo, point.CellNo)
                : (point.HeadNo, 0))
            .ToDictionary(group => group.Key, group => group.First());

        return projection.SourcePoints
            .Where(point => point.HeadNo > 0)
            .Select(point => new
            {
                Point = point,
                Key = projection.Scope == EN_REVIEW_CORRECTION_SCOPE.HeadCell
                    ? (point.HeadNo, point.CellNo)
                    : (point.HeadNo, 0)
            })
            .Where(item => measurements.ContainsKey(item.Key))
            .Select(item => CopyMeasurement(item.Point, measurements[item.Key]))
            .ToArray();
    }

    private static IReadOnlyList<ST_REVIEW_PLAN_POINT> ProjectFineResultRows(
        IReadOnlyList<ST_REVIEW_PLAN_POINT> sourcePoints,
        IReadOnlyList<ST_REVIEW_PLAN_POINT> measuredPoints)
    {
        var anchorsByHeadAndX = measuredPoints
            .Where(point => point.HeadNo > 0 &&
                double.IsFinite(point.DesignX) &&
                double.IsFinite(point.DesignY))
            .GroupBy(point => (point.HeadNo, X: FineCoordinateKey(point.DesignX)))
            .ToDictionary(
                group => group.Key,
                group => group
                    .GroupBy(point => FineCoordinateKey(point.DesignY))
                    .Select(yGroup => yGroup.First())
                    .OrderBy(point => point.DesignY)
                    .ToArray());

        var rows = new List<ST_REVIEW_PLAN_POINT>(sourcePoints.Count);
        foreach (var point in sourcePoints.Where(point =>
                     point.HeadNo > 0 &&
                     double.IsFinite(point.DesignX) &&
                     double.IsFinite(point.DesignY)))
        {
            if (!anchorsByHeadAndX.TryGetValue(
                    (point.HeadNo, FineCoordinateKey(point.DesignX)),
                    out var anchors) ||
                anchors.Length == 0)
            {
                continue;
            }

            rows.Add(InterpolateFineMeasurementAcrossGlass(point, anchors));
        }

        return rows;
    }

    private static ST_REVIEW_PLAN_POINT InterpolateFineMeasurementAcrossGlass(
        ST_REVIEW_PLAN_POINT point,
        IReadOnlyList<ST_REVIEW_PLAN_POINT> anchors)
    {
        var projected = InterpolateFineMeasurement(point, anchors);
        var judge = anchors.Any(anchor =>
            anchor.Judge.Equals("NG", StringComparison.OrdinalIgnoreCase))
                ? "NG"
                : "OK";
        return projected with
        {
            State = judge == "NG" ? EN_REVIEW_POINT_STATE.Ng : EN_REVIEW_POINT_STATE.Ok,
            Judge = judge
        };
    }

    private static ST_REVIEW_PLAN_POINT InterpolateFineMeasurement(
        ST_REVIEW_PLAN_POINT point,
        IReadOnlyList<ST_REVIEW_PLAN_POINT> anchors)
    {
        if (anchors.Count == 1 || point.DesignY <= anchors[0].DesignY)
        {
            return CopyMeasurement(point, anchors[0]);
        }

        if (point.DesignY >= anchors[^1].DesignY)
        {
            return CopyMeasurement(point, anchors[^1]);
        }

        for (var index = 1; index < anchors.Count; index++)
        {
            var upper = anchors[index];
            if (point.DesignY > upper.DesignY)
            {
                continue;
            }

            var lower = anchors[index - 1];
            var distance = upper.DesignY - lower.DesignY;
            var ratio = Math.Abs(distance) <= double.Epsilon
                ? 0.0
                : Math.Clamp((point.DesignY - lower.DesignY) / distance, 0.0, 1.0);
            var judge = lower.Judge.Equals("NG", StringComparison.OrdinalIgnoreCase) ||
                upper.Judge.Equals("NG", StringComparison.OrdinalIgnoreCase)
                    ? "NG"
                    : "OK";
            return point with
            {
                Use = true,
                ErrorX = lower.ErrorX + ((upper.ErrorX - lower.ErrorX) * ratio),
                ErrorY = lower.ErrorY + ((upper.ErrorY - lower.ErrorY) * ratio),
                State = judge == "NG" ? EN_REVIEW_POINT_STATE.Ng : EN_REVIEW_POINT_STATE.Ok,
                Judge = judge
            };
        }

        return CopyMeasurement(point, anchors[^1]);
    }

    private static ST_REVIEW_PLAN_POINT CopyMeasurement(
        ST_REVIEW_PLAN_POINT target,
        ST_REVIEW_PLAN_POINT measurement) => target with
        {
            Use = true,
            ErrorX = measurement.ErrorX,
            ErrorY = measurement.ErrorY,
            State = measurement.State,
            Judge = measurement.Judge
        };

    private static double FineCoordinateKey(double value) => Math.Round(value, 6);

    private sealed class CLazyReviewPointList(
        CRecipeCellPatternCatalog catalog,
        bool areAllPointsSelected,
        Func<ST_RECIPE_CELL_PATTERN_ENTRY, int, ST_REVIEW_PLAN_POINT> pointFactory)
        : IReadOnlyList<ST_REVIEW_PLAN_POINT>, IReviewPointListInfo, IReviewCellPointSource
    {
        private readonly ST_REVIEW_PLAN_POINT?[] _pointCache =
            new ST_REVIEW_PLAN_POINT?[catalog.Count];

        public int Count => catalog.Count;

        public bool AreAllPointsSelected => areAllPointsSelected;

        public int PatternCellCount => catalog.CellCount;

        public ST_REVIEW_CELL_POINT_RANGE GetCellRange(int zeroBasedCellIndex)
        {
            if ((uint)zeroBasedCellIndex >= (uint)catalog.CellCount)
            {
                throw new ArgumentOutOfRangeException(nameof(zeroBasedCellIndex));
            }

            var cell = catalog.Cells[zeroBasedCellIndex];
            return new ST_REVIEW_CELL_POINT_RANGE(
                cell.StartIndex,
                cell.Count,
                cell.Layout.GroupCountX,
                cell.Layout.GroupCountY);
        }

        public ST_REVIEW_PLAN_POINT this[int index]
        {
            get
            {
                if ((uint)index >= (uint)Count)
                {
                    throw new ArgumentOutOfRangeException(nameof(index));
                }

                var cached = Volatile.Read(ref _pointCache[index]);
                if (cached is not null)
                {
                    return cached;
                }

                var (cell, pointIndex) = catalog.Resolve(index);
                var created = pointFactory(cell, pointIndex);
                return Interlocked.CompareExchange(ref _pointCache[index], created, null) ?? created;
            }
        }

        public IEnumerator<ST_REVIEW_PLAN_POINT> GetEnumerator()
        {
            for (var index = 0; index < Count; index++)
            {
                yield return this[index];
            }
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator() => GetEnumerator();
    }

    private static ST_REVIEW_COORDINATE_OFFSET CalculateBeamOffset(
        int beamNo,
        int splitBeamCount,
        double doePitch)
    {
        ValidateBeamNo(beamNo, splitBeamCount);
        if (!double.IsFinite(doePitch) || doePitch <= 0.0)
        {
            throw new InvalidOperationException(
                $"DOE pitch must be a finite value greater than 0. Current value: {doePitch}");
        }

        var normalizedBeamNo = beamNo - 1;
        var column = normalizedBeamNo % splitBeamCount;
        var row = normalizedBeamNo / splitBeamCount;
        var center = (splitBeamCount - 1) / 2.0;
        var offsetX = (column - center) * doePitch;
        var offsetY = (row - center) * doePitch;
        if (!double.IsFinite(offsetX) || !double.IsFinite(offsetY))
        {
            throw new InvalidOperationException("DOE beam offset calculation produced a non-finite value.");
        }

        return new ST_REVIEW_COORDINATE_OFFSET(offsetX, offsetY);
    }

    private static void ValidateBeamNo(int beamNo, int splitBeamCount = 4)
    {
        if (!CCellPatternCalculator.IsSupportedSplitBeamCount(splitBeamCount))
        {
            throw new InvalidOperationException(
                "SPLITED_BEAM_COUNT must be either 1 or 4 before a review beam can be selected.");
        }

        var maximumBeamNo = (long)splitBeamCount * splitBeamCount;
        if (beamNo < 1 || beamNo > maximumBeamNo)
        {
            throw new ArgumentOutOfRangeException(
                nameof(beamNo),
                beamNo,
                $"Review beam number must be between 1 and {maximumBeamNo}.");
        }
    }

    private static ST_REVIEW_COORDINATE_OFFSET CalculateReviewTarget(
        double shotFromAlignKeyX,
        double shotFromAlignKeyY,
        double reviewCameraAlignKeyPosX,
        double reviewCameraAlignKeyPosY,
        double beamOffsetLocalX,
        double beamOffsetLocalY,
        double cellRotationDegrees,
        double stageScanDirectionY)
    {
        var beamOffset = RotateLocalOffset(
            beamOffsetLocalX,
            beamOffsetLocalY,
            cellRotationDegrees);

        return new ST_REVIEW_COORDINATE_OFFSET(
            reviewCameraAlignKeyPosX + shotFromAlignKeyX + beamOffset.X,
            reviewCameraAlignKeyPosY +
            (stageScanDirectionY * (shotFromAlignKeyY + beamOffset.Y)));
    }

    private static ST_REVIEW_COORDINATE_OFFSET RotateLocalOffset(
        double localX,
        double localY,
        double rotationDegrees)
    {
        var radians = rotationDegrees * Math.PI / 180.0;
        var cos = Math.Cos(radians);
        var sin = Math.Sin(radians);
        return new ST_REVIEW_COORDINATE_OFFSET(
            (localX * cos) - (localY * sin),
            (localX * sin) + (localY * cos));
    }

    private Task MoveStageY(ST_REVIEW_PLAN_POINT point, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (IsStopRequested) throw new OperationCanceledException("Review Stop");
        (_reviewStageMotion ?? throw new InvalidOperationException("Review Stage 이동이 준비되지 않았습니다.")).MoveStageY(point.ReviewTargetY);
        return Task.CompletedTask;
    }

    private async Task MoveVisionX(ST_REVIEW_PLAN_POINT point, bool waitForMoveCompletion, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (IsStopRequested) throw new OperationCanceledException("Review Stop");
        var motion = _reviewStageMotion ?? throw new InvalidOperationException("Review Stage 이동이 준비되지 않았습니다.");
        motion.MoveReviewX(point.ReviewTargetX);
        WriteReviewLog("MOVE", $"Stage move. X={FormatDouble(point.ReviewTargetX)}, Y={FormatDouble(point.ReviewTargetY)}");
        if (waitForMoveCompletion) await motion.WaitForArrival(point, cancellationToken);
    }

    private async Task<ST_REVIEW_MEASURE_RESULT> MeasureVision(
        ST_REVIEW_PLAN_POINT point,
        CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var isSimulation = IsReviewSimulation();
        WriteReviewLog(
            "MEASURE_START",
            "Measurement started.");

        try
        {
            ST_REVIEW_MEASURE_RESULT measurement;
            if (isSimulation)
            {
                measurement = CreateTemporaryVisionMeasurement(point);
            }
            else
            {
                var command = CreateMarkFindSingleCommand(point);
                var response = await interfaceManager.ExecuteFunction(
                    EN_EQP_MODULE.Vision,
                    0,
                    command,
                    cancellationToken);

                if (string.IsNullOrWhiteSpace(response))
                {
                    throw new InvalidDataException(
                        $"Vision Mark Find Single response is empty. Shot={point.ShotKey}");
                }

                measurement = ParseVisionResponse(response, point);
            }

            WriteReviewLog(
                "RESULT_RECEIVED",
                "Inspection result received.");
            return measurement;
        }
        catch (Exception exception) when (exception is not OperationCanceledException)
        {
            WriteReviewLog(
                "MEASURE_ERROR",
                "Measurement failed.");
            throw;
        }
    }

    private async Task<ST_REVIEW_SEQUENCE_STATUS> RunIofSequence(
        ST_REVIEW_PLAN workingPlan,
        string? reviewProductId,
        Action<ST_REVIEW_PLAN>? progress,
        CancellationToken cancellationToken,
        IReadOnlyList<ST_REVIEW_PLAN_POINT>? runPoints = null,
        bool resumeFromCurrentPosition = false)
    {
        var pendingPoints = runPoints ?? workingPlan.ReviewPoints
            .Where(point => point.State is not (EN_REVIEW_POINT_STATE.Ok or EN_REVIEW_POINT_STATE.Ng))
            .ToArray();
        var lines = CreateIofLines(pendingPoints);
        for (var lineIndex = 0; lineIndex < lines.Count; lineIndex++)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (IsStopRequested)
            {
                return await StopIofSequence(
                    workingPlan,
                    reviewProductId,
                    progress,
                    "Review IOF sequence stopped.");
            }

            // A resumed line starts at the endpoint closest to the camera's current position.
            // Subsequent lines also follow the current endpoint, including after a reversed retry.
            var line = resumeFromCurrentPosition || runPoints is not null || lineIndex > 0
                ? OrderLineFromCurrentPosition(lines[lineIndex], _reviewStageMotion!.ReviewXPosition)
                : lines[lineIndex];
            workingPlan = SetIofLineCurrent(workingPlan, line);
            SetActivePoints(line[0], LastMeasuredPoint);
            SetCurrentPlan(workingPlan, progress);

            WriteReviewLog(
                "MEASURE_START",
                "Measurement started.");
            IReadOnlyList<ST_REVIEW_MEASURE_RESULT> measurements;
            try
            {
                measurements = await MeasureVisionLine(line, cancellationToken);
                if (IsStopRequested)
                {
                    WriteReviewLog(
                        "MEASURE_STOPPED",
                        "Measurement stopped.");
                }
                else
                {
                    WriteReviewLog(
                        "RESULT_RECEIVED",
                        "Inspection result received.");
                }
            }
            catch (Exception exception) when (exception is not OperationCanceledException)
            {
                WriteReviewLog(
                    "MEASURE_ERROR",
                    "Measurement failed.");
                throw;
            }

            if (IsStopRequested)
            {
                return await StopIofSequence(
                    workingPlan,
                    reviewProductId,
                    progress,
                    "Review IOF sequence stopped.");
            }

            var measuredLine = new ST_REVIEW_PLAN_POINT[line.Count];
            for (var index = 0; index < line.Count; index++)
            {
                var currentPoint = GetPlanPoint(workingPlan, line[index].ShotKey);
                var measuredPoint = ApplyMeasurement(
                    workingPlan,
                    currentPoint,
                    measurements[index]);
                measuredLine[index] = measuredPoint;
            }

            workingPlan = UpdatePoints(workingPlan, measuredLine);
            SetActivePoints(null, measuredLine[^1]);

            SetCurrentPlan(workingPlan, progress);
            await SaveProgressToProduct(
                workingPlan,
                reviewProductId,
                cancellationToken);
        }

        SequenceState = EN_REVIEW_SEQUENCE_STATE.Completed;
        SetCurrentPlan(workingPlan, progress);
        await SaveResultForProduct(
            workingPlan,
            workingPlan.ReviewPoints,
            reviewProductId,
            cancellationToken);
        WriteReviewLog(
            runPoints is null ? "COMPLETE" : "RETRY_COMPLETE",
            runPoints is null ? "Review completed." : "Review retry completed.");
        return CreateStatus(workingPlan, SequenceState, "Review IOF sequence completed.");
    }

    private async Task<ST_REVIEW_SEQUENCE_STATUS> StopIofSequence(
        ST_REVIEW_PLAN workingPlan,
        string? reviewProductId,
        Action<ST_REVIEW_PLAN>? progress,
        string message)
    {
        SequenceState = EN_REVIEW_SEQUENCE_STATE.Stopped;
        workingPlan = SetWaitingPointsReady(workingPlan);
        SetActivePoints(null, LastMeasuredPoint);
        SetCurrentPlan(workingPlan, progress);
        return await CreateStoppedStatus(workingPlan, reviewProductId, message);
    }

    private async Task<IReadOnlyList<ST_REVIEW_MEASURE_RESULT>> MeasureVisionLine(
        IReadOnlyList<ST_REVIEW_PLAN_POINT> line,
        CancellationToken cancellationToken)
    {
        if (line.Count == 0)
        {
            throw new InvalidOperationException("Vision IOF line is empty.");
        }

        await MoveIofLineStart(line[0], cancellationToken);
        cancellationToken.ThrowIfCancellationRequested();
        if (IsStopRequested)
        {
            return [];
        }

        if (IsReviewSimulation())
        {
            await MoveIofLineEnd(line[^1], cancellationToken);
            if (IsStopRequested)
            {
                return [];
            }

            var temporaryResults = new ST_REVIEW_MEASURE_RESULT[line.Count];
            for (var index = 0; index < line.Count; index++)
            {
                temporaryResults[index] = CreateTemporaryVisionMeasurement(line[index]);
            }

            return temporaryResults;
        }

        await ExecuteVisionCommand(
            CreateFlyingReadyCommand(line),
            "Vision Flying Ready response is empty.",
            cancellationToken);
        if (IsStopRequested) return [];

        await MoveIofLineEnd(line[^1], cancellationToken);
        cancellationToken.ThrowIfCancellationRequested();
        if (IsStopRequested)
        {
            return [];
        }

        await ExecuteVisionCommand(
            "FLYING_MOVE_DONE",
            "Vision Flying Move Done response is empty.",
            cancellationToken);
        if (IsStopRequested) return [];
        var response = await ExecuteVisionCommand(
            "MARK_FIND_LINE",
            "Vision Mark Find Line response is empty.",
            cancellationToken);
        return ParseVisionLineResponse(response, line);
    }

    private async Task<string> ExecuteVisionCommand(
        string command,
        string emptyResponseMessage,
        CancellationToken cancellationToken)
    {
        var response = await interfaceManager.ExecuteFunction(
            EN_EQP_MODULE.Vision,
            0,
            command,
            cancellationToken);
        if (string.IsNullOrWhiteSpace(response))
        {
            throw new InvalidDataException(emptyResponseMessage);
        }
        if (response.StartsWith("NCK:1002:", StringComparison.OrdinalIgnoreCase))
            throw new CFlyingCountMismatchException(response);

        return response;
    }

    private async Task MoveIofLineStart(
        ST_REVIEW_PLAN_POINT point,
        CancellationToken cancellationToken)
    {
        // Reach the start position in the shared Stage simulator before sending Flying Ready.
        await MoveStageY(point, cancellationToken);
        await MoveVisionX(
            point,
            waitForMoveCompletion: true,
            cancellationToken);
    }

    private async Task MoveIofLineEnd(
        ST_REVIEW_PLAN_POINT point,
        CancellationToken cancellationToken)
    {
        // The end move completes only when both shared simulated axes reach their targets.
        await MoveStageY(point, cancellationToken);
        await MoveVisionX(
            point,
            waitForMoveCompletion: true,
            cancellationToken);
    }

    private static string CreateFlyingReadyCommand(
        IReadOnlyList<ST_REVIEW_PLAN_POINT> line)
    {
        if (line.Count > CVisionProtocol.MaximumMarkCount)
        {
            throw new InvalidOperationException(
                $"Vision IOF line supports up to {CVisionProtocol.MaximumMarkCount} shots. Current={line.Count}");
        }

        var builder = new StringBuilder();
        builder.Append("FLYING_READY:")
            .Append(IofInspectionType)
            .Append(':');
        for (var index = 0; index < line.Count; index++)
        {
            if (index > 0)
            {
                builder.Append(';');
            }

            AppendVisionMarkSearch(builder, line[index]);
        }

        return builder.ToString();
    }

    private static void AppendVisionMarkSearch(
        StringBuilder builder,
        ST_REVIEW_PLAN_POINT point)
    {
        var columnCount = Math.Max(1, point.PixelCountX);
        var zeroBasedShotNo = Math.Max(0, point.ShotNo - 1);
        var indexX = (zeroBasedShotNo % columnCount) + 1;
        var indexY = (zeroBasedShotNo / columnCount) + 1;

        builder.Append(point.CellNo)
            .Append(',')
            .Append(point.BeamNo)
            .Append(',')
            .Append(indexY)
            .Append(',')
            .Append(indexX)
            .Append(',')
            .Append(indexY)
            .Append(',')
            .Append(point.HeadNo);
    }

    private static IReadOnlyList<ST_REVIEW_MEASURE_RESULT> ParseVisionLineResponse(
        string response,
        IReadOnlyList<ST_REVIEW_PLAN_POINT> line)
    {
        const string marksToken = ":MARKS=";
        var marksIndex = response.IndexOf(marksToken, StringComparison.OrdinalIgnoreCase);
        if (marksIndex < 0)
        {
            throw new InvalidDataException(
                $"Vision Mark Find Line response has no result array. Response={response}");
        }

        var headerValues = SplitResponse(response[..marksIndex]);
        if (!TryReadInt(headerValues, "RESOLUTION", out var resolution) || resolution <= 0 ||
            !TryReadInt(headerValues, "COUNT", out var resultCount))
        {
            throw new InvalidDataException(
                $"Vision Mark Find Line header is invalid. Response={response}");
        }

        if (resultCount != line.Count)
        {
            throw new InvalidDataException(
                $"Vision Mark Find Line count mismatch. Requested={line.Count}, Received={resultCount}.");
        }

        var marksText = response[(marksIndex + marksToken.Length)..];
        var markTexts = marksText.Split(
            ';',
            StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        if (markTexts.Length != resultCount)
        {
            throw new InvalidDataException(
                $"Vision Mark Find Line result array mismatch. Header={resultCount}, Body={markTexts.Length}.");
        }

        var measurements = new ST_REVIEW_MEASURE_RESULT[resultCount];
        for (var index = 0; index < resultCount; index++)
        {
            var fields = markTexts[index].Split(',', StringSplitOptions.TrimEntries);
            if (fields.Length != 5 ||
                !int.TryParse(fields[0], NumberStyles.Integer, CultureInfo.InvariantCulture, out var result) ||
                !double.TryParse(fields[1], NumberStyles.Float, CultureInfo.InvariantCulture, out var targetX) ||
                !double.TryParse(fields[2], NumberStyles.Float, CultureInfo.InvariantCulture, out var targetY) ||
                !double.TryParse(fields[3], NumberStyles.Float, CultureInfo.InvariantCulture, out var shotX) ||
                !double.TryParse(fields[4], NumberStyles.Float, CultureInfo.InvariantCulture, out var shotY))
            {
                throw new InvalidDataException(
                    $"Vision Mark Find Line result is invalid. Index={index}, Value={markTexts[index]}");
            }

            var point = line[index];
            var errorX = shotX - targetX;
            var errorY = shotY - targetY;
            measurements[index] = new ST_REVIEW_MEASURE_RESULT(
                point.ReviewTargetX + errorX,
                point.ReviewTargetY + errorY,
                result > 0 ? "" : "NG",
                markTexts[index]) { MarkFind = new ST_VISION_MARK_FIND(result, targetX, targetY, shotX, shotY) };
        }

        return measurements;
    }

    private static IReadOnlyList<IReadOnlyList<ST_REVIEW_PLAN_POINT>> CreateIofLines(
        IReadOnlyList<ST_REVIEW_PLAN_POINT> points)
    {
        var orderedPoints = OrderByReviewSequence(points);
        var lines = new List<IReadOnlyList<ST_REVIEW_PLAN_POINT>>();
        List<ST_REVIEW_PLAN_POINT>? currentLine = null;
        double currentDesignY = 0.0;
        foreach (var point in orderedPoints)
        {
            if (currentLine is null ||
                Math.Abs(point.DesignY - currentDesignY) > ReviewSequenceRowTolerance)
            {
                currentLine = [];
                lines.Add(currentLine);
                currentDesignY = point.DesignY;
            }

            currentLine.Add(point);
        }

        return lines;
    }

    private static ST_REVIEW_PLAN SetIofLineCurrent(
        ST_REVIEW_PLAN plan,
        IReadOnlyList<ST_REVIEW_PLAN_POINT> line)
    {
        return UpdatePoints(plan, line.Select(point => GetPlanPoint(plan, point.ShotKey) with
            { State = EN_REVIEW_POINT_STATE.Current, Judge = "WAIT" }).ToArray());
    }

    private static ST_REVIEW_PLAN_POINT GetPlanPoint(
        ST_REVIEW_PLAN plan,
        string shotKey)
    {
        if (plan.Points is CReviewRuntimePoints runtime)
            return runtime.Find(shotKey) ?? throw new InvalidOperationException($"Review point was not found. Shot={shotKey}");
        foreach (var point in plan.Points)
        {
            if (point.ShotKey.Equals(shotKey, StringComparison.OrdinalIgnoreCase))
            {
                return point;
            }
        }

        throw new InvalidOperationException($"Review point was not found. Shot={shotKey}");
    }

    private static string CreateMarkFindSingleCommand(ST_REVIEW_PLAN_POINT point)
    {
        var columnCount = Math.Max(1, point.PixelCountX);
        var zeroBasedShotNo = Math.Max(0, point.ShotNo - 1);
        var indexX = (zeroBasedShotNo % columnCount) + 1;
        var indexY = (zeroBasedShotNo / columnCount) + 1;

        var lineNo = indexY;
        return string.Create(
            CultureInfo.InvariantCulture,
            $"MARK_FIND_SINGLE:{point.CellNo},{point.BeamNo},{lineNo},{indexX},{indexY},{point.HeadNo}");
    }

    private static ST_REVIEW_MEASURE_RESULT CreateTemporaryVisionMeasurement(
        ST_REVIEW_PLAN_POINT point)
    {
        const double normalErrorLimit = 0.0200;
        const double ngErrorMinimum = 0.0350;
        const double ngErrorRange = 0.0200;

        var createNgSample = Random.Shared.Next(10) == 0;
        var errorX = CreateRandomSignedValue(normalErrorLimit);
        var errorY = CreateRandomSignedValue(normalErrorLimit);

        if (createNgSample)
        {
            if (Random.Shared.Next(2) == 0)
            {
                errorX = CreateRandomSignedValue(ngErrorMinimum, ngErrorRange);
            }
            else
            {
                errorY = CreateRandomSignedValue(ngErrorMinimum, ngErrorRange);
            }
        }

        errorX = Math.Round(errorX, 4, MidpointRounding.AwayFromZero);
        errorY = Math.Round(errorY, 4, MidpointRounding.AwayFromZero);
        var response = FormatCommand(
            "TEMPORARY_RANDOM_VISION_RESULT",
            ("X", FormatDouble(point.ReviewTargetX + errorX)),
            ("Y", FormatDouble(point.ReviewTargetY + errorY)));

        return new ST_REVIEW_MEASURE_RESULT(
            point.ReviewTargetX + errorX,
            point.ReviewTargetY + errorY,
            "",
            response)
        {
            MarkFind = new ST_VISION_MARK_FIND(1, point.ReviewTargetX, point.ReviewTargetY,
                point.ReviewTargetX + errorX, point.ReviewTargetY + errorY)
        };
    }

    private static double CreateRandomSignedValue(double maximum)
    {
        return ((Random.Shared.NextDouble() * 2.0) - 1.0) * maximum;
    }

    private static double CreateRandomSignedValue(double minimum, double range)
    {
        var sign = Random.Shared.Next(2) == 0 ? -1.0 : 1.0;
        return sign * (minimum + (Random.Shared.NextDouble() * range));
    }



    private bool IsReviewSimulation()
    {
        return IsReviewDeviceSimulation(EN_EQP_MODULE.Vision, 0);
    }

    private static ST_REVIEW_PLAN_POINT ApplyMeasurement(
        ST_REVIEW_PLAN plan,
        ST_REVIEW_PLAN_POINT point,
        ST_REVIEW_MEASURE_RESULT measurement)
    {
        return ApplyMeasurementError(plan, point, measurement.X - point.ReviewTargetX,
            measurement.Y - point.ReviewTargetY, measurement.Judge);
    }

    private static ST_REVIEW_PLAN_POINT ApplyMeasurementError(ST_REVIEW_PLAN plan, ST_REVIEW_PLAN_POINT point,
        double errorX, double errorY, string measurementJudge)
    {
        var judge = !string.IsNullOrWhiteSpace(measurementJudge) &&
            !measurementJudge.Equals("WAIT", StringComparison.OrdinalIgnoreCase)
            ? measurementJudge.ToUpperInvariant()
            : Math.Abs(errorX) <= plan.ToleranceX && Math.Abs(errorY) <= plan.ToleranceY
                ? "OK"
                : "NG";
        var state = judge.Equals("OK", StringComparison.OrdinalIgnoreCase)
            ? EN_REVIEW_POINT_STATE.Ok
            : EN_REVIEW_POINT_STATE.Ng;

        return point with
        {
            ErrorX = errorX,
            ErrorY = errorY,
            State = state,
            Judge = judge
        };
    }

    private static ST_REVIEW_MEASURE_RESULT ParseVisionResponse(
        string response,
        ST_REVIEW_PLAN_POINT point)
    {
        var values = SplitResponse(response);
        if (!TryReadInt(values, "RESULT", out var result) ||
            !TryReadDouble(values, "TARGET_X", out var targetX) ||
            !TryReadDouble(values, "TARGET_Y", out var targetY) ||
            !TryReadDouble(values, "HOLE_X", out var holeX) ||
            !TryReadDouble(values, "HOLE_Y", out var holeY))
        {
            throw new InvalidDataException(
                $"Vision Mark Find Single response is invalid. Shot={point.ShotKey}, Response={response}");
        }

        var errorX = holeX - targetX;
        var errorY = holeY - targetY;
        var judge = result > 0 ? "" : "NG";
        return new ST_REVIEW_MEASURE_RESULT(
            point.ReviewTargetX + errorX,
            point.ReviewTargetY + errorY,
            judge,
            response) { MarkFind = new ST_VISION_MARK_FIND(result, targetX, targetY, holeX, holeY) };
    }

    private static IReadOnlyDictionary<string, string> SplitResponse(string response)
    {
        var values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        var tokens = response
            .Split([':', ';', ',', '|', '\r', '\n', ' '], StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

        foreach (var token in tokens)
        {
            var separatorIndex = token.IndexOf('=');
            if (separatorIndex <= 0 || separatorIndex == token.Length - 1)
            {
                continue;
            }

            values[token[..separatorIndex].Trim()] = token[(separatorIndex + 1)..].Trim();
        }

        return values;
    }

    private static bool TryReadDouble(
        IReadOnlyDictionary<string, string> values,
        string key,
        out double value)
    {
        value = 0.0;

        return values.TryGetValue(key, out var text) &&
            double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out value);
    }

    private static bool TryReadInt(
        IReadOnlyDictionary<string, string> values,
        string key,
        out int value)
    {
        value = 0;

        return values.TryGetValue(key, out var text) &&
            int.TryParse(text, NumberStyles.Integer, CultureInfo.InvariantCulture, out value);
    }

    private static string FormatCommand(
        string command,
        params (string Key, string Value)[] arguments)
    {
        return string.Join(
            ";",
            new[] { command }.Concat(arguments.Select(argument => $"{argument.Key}={argument.Value}")));
    }

    private static string FormatDouble(double value)
    {
        return value.ToString("0.000000", CultureInfo.InvariantCulture);
    }

    private void WriteReviewLog(
        string action,
        string detail)
    {
        if (logManager is null)
        {
            return;
        }

        try
        {
            logManager.WriteStationState(
                "PROCESS",
                "INSPECTION",
                $"REVIEW_{action}",
                detail);
        }
        catch (Exception exception)
        {
            System.Diagnostics.Trace.TraceError(
                $"Review log write failed. Action={action}, Error={exception.Message}");
        }
    }

    private void WriteReviewError()
    {
        WriteReviewLog(
            "ERROR",
            "Review failed.");
    }

    private void SetCurrentPlan(
        ST_REVIEW_PLAN plan,
        Action<ST_REVIEW_PLAN>? progress)
    {
        lock (_stateLock)
        {
            _currentPlan = plan;
        }

        progress?.Invoke(plan);
    }

    private void SetActivePoints(
        ST_REVIEW_PLAN_POINT? currentPoint,
        ST_REVIEW_PLAN_POINT? lastMeasuredPoint)
    {
        lock (_stateLock)
        {
            _currentPoint = currentPoint;
            _lastMeasuredPoint = lastMeasuredPoint;
        }
    }

    private void SetReviewProductId(string? productId)
    {
        lock (_stateLock)
        {
            _reviewProductId = string.IsNullOrWhiteSpace(productId) ? null : productId;
        }
    }

    private string? GetReviewProductId()
    {
        lock (_stateLock)
        {
            return _reviewProductId;
        }
    }

    private static ST_REVIEW_PLAN ResetPlanForRun(ST_REVIEW_PLAN plan)
    {
        var firstShotKey = OrderByReviewSequence(plan.ReviewPoints)
            .Select(point => point.ShotKey)
            .FirstOrDefault();

        return plan with
        {
            Points = plan.Points.Select(point => point.Use
                ? point with
                {
                    ErrorX = 0.0,
                    ErrorY = 0.0,
                    State = point.ShotKey.Equals(firstShotKey, StringComparison.OrdinalIgnoreCase)
                        ? EN_REVIEW_POINT_STATE.Current
                        : EN_REVIEW_POINT_STATE.Ready,
                    Judge = "WAIT"
                }
                : point with
                {
                    State = EN_REVIEW_POINT_STATE.Skip,
                    Judge = "-"
                }).ToArray()
        };
    }

    private static ST_REVIEW_PLAN SetWaitingPointsReady(ST_REVIEW_PLAN plan)
    {
        return UpdatePoints(plan, plan.ReviewPoints.Where(point => point.State == EN_REVIEW_POINT_STATE.Current)
            .Select(point => point with { State = EN_REVIEW_POINT_STATE.Ready }).ToArray());
    }

    private static ST_REVIEW_PLAN PrepareRuntimePlan(ST_REVIEW_PLAN plan) => plan with
    {
        Points = plan.Points is CReviewRuntimePoints ? plan.Points : new CReviewRuntimePoints(plan.Points),
        RuntimeId = Guid.NewGuid(), PointUpdates = null
    };

    private static ST_REVIEW_PLAN UpdatePoints(ST_REVIEW_PLAN plan, IReadOnlyList<ST_REVIEW_PLAN_POINT> updates)
    {
        var points = plan.Points as CReviewRuntimePoints ?? new CReviewRuntimePoints(plan.Points);
        return plan with { Points = points.Update(updates), PointUpdates = updates };
    }

    private static ST_REVIEW_PLAN UpdatePoint(
        ST_REVIEW_PLAN plan,
        ST_REVIEW_PLAN_POINT point)
    {
        return UpdatePoints(plan, [point]);
    }

    private static ST_REVIEW_SEQUENCE_STATUS CreateStatus(
        ST_REVIEW_PLAN plan,
        EN_REVIEW_SEQUENCE_STATE state,
        string message)
    {
        var reviewPoints = plan.ReviewPoints;
        var completedCount = reviewPoints.Count(point => point.State is EN_REVIEW_POINT_STATE.Ok or EN_REVIEW_POINT_STATE.Ng);
        var ngCount = reviewPoints.Count(point => point.State == EN_REVIEW_POINT_STATE.Ng);

        return new ST_REVIEW_SEQUENCE_STATUS(
            state,
            reviewPoints.Count,
            completedCount,
            ngCount,
            message);
    }

    private async Task<ST_REVIEW_SEQUENCE_STATUS> RunRetryPoints(
        IReadOnlyList<ST_REVIEW_PLAN_POINT> retryPoints,
        string completedMessage,
        Action<ST_REVIEW_PLAN>? progress,
        CancellationToken cancellationToken)
    {
        if (!await _sequenceLock.WaitAsync(0, cancellationToken))
        {
            return CreateStatus(
                CurrentPlan!,
                EN_REVIEW_SEQUENCE_STATE.Running,
                "Review sequence is already running.");
        }

        var reviewProductId = GetReviewProductId();

        try
        {
            var workingPlan = PrepareRuntimePlan(CurrentPlan!);
            Interlocked.Exchange(ref _stopRequested, 0);
            _reviewStageMotion = OpenReviewStageMotion();
            SequenceState = EN_REVIEW_SEQUENCE_STATE.Running;
            SetCurrentPlan(workingPlan, progress);
            WriteReviewLog(
                "RETRY_START",
                "Review retry started.");
            if (!string.IsNullOrWhiteSpace(reviewProductId) && productManager is not null)
            {
                await productManager.SetReviewRunning(
                    reviewProductId,
                    CreateProductReviewData(workingPlan, DateTimeOffset.Now),
                    cancellationToken);
            }

            if (!IsPointToPoint(workingPlan))
            {
                return await RunIofSequence(
                    workingPlan,
                    reviewProductId,
                    progress,
                    cancellationToken,
                    retryPoints);
            }

            foreach (var point in OrderPtoPFromCurrentPosition(retryPoints, resume: true))
            {
                cancellationToken.ThrowIfCancellationRequested();
                if (IsStopRequested)
                {
                    SequenceState = EN_REVIEW_SEQUENCE_STATE.Stopped;
                    return await CreateStoppedStatus(workingPlan, reviewProductId, "Review retry stopped.");
                }

                var currentPoint = point with
                {
                    State = EN_REVIEW_POINT_STATE.Current,
                    Judge = "WAIT"
                };
                SetActivePoints(currentPoint, LastMeasuredPoint);
                workingPlan = UpdatePoint(workingPlan, currentPoint);
                SetCurrentPlan(workingPlan, progress);

                await MoveStageY(currentPoint, cancellationToken);
                if (IsStopRequested)
                {
                    SequenceState = EN_REVIEW_SEQUENCE_STATE.Stopped;
                    workingPlan = UpdatePoint(workingPlan, currentPoint with { State = EN_REVIEW_POINT_STATE.Ready });
                    SetCurrentPlan(workingPlan, progress);
                    return await CreateStoppedStatus(workingPlan, reviewProductId, "Review retry stopped.");
                }

                await MoveVisionX(
                    currentPoint,
                    waitForMoveCompletion: true,
                    cancellationToken);
                if (IsStopRequested)
                {
                    SequenceState = EN_REVIEW_SEQUENCE_STATE.Stopped;
                    workingPlan = UpdatePoint(workingPlan, currentPoint with { State = EN_REVIEW_POINT_STATE.Ready });
                    SetCurrentPlan(workingPlan, progress);
                    return await CreateStoppedStatus(workingPlan, reviewProductId, "Review retry stopped.");
                }

                var measurement = await MeasureVision(currentPoint, cancellationToken);

                if (IsStopRequested)
                {
                    SequenceState = EN_REVIEW_SEQUENCE_STATE.Stopped;
                    workingPlan = UpdatePoint(workingPlan, currentPoint with { State = EN_REVIEW_POINT_STATE.Ready });
                    SetCurrentPlan(workingPlan, progress);
                    return await CreateStoppedStatus(workingPlan, reviewProductId, "Review retry stopped.");
                }

                var measuredPoint = ApplyMeasurement(workingPlan, currentPoint, measurement);
                SetActivePoints(null, measuredPoint);
                workingPlan = UpdatePoint(workingPlan, measuredPoint);
                SetCurrentPlan(workingPlan, progress);
                await SaveProgressToProduct(
                    workingPlan,
                    reviewProductId,
                    cancellationToken);
            }

            SequenceState = EN_REVIEW_SEQUENCE_STATE.Completed;
            await SaveResultForProduct(
                workingPlan,
                workingPlan.ReviewPoints,
                reviewProductId,
                cancellationToken);
            WriteReviewLog(
                "RETRY_COMPLETE",
                "Review retry completed.");
            return CreateStatus(workingPlan, SequenceState, completedMessage);
        }
        catch (OperationCanceledException)
        {
            _reviewStageMotion?.Stop();
            SequenceState = EN_REVIEW_SEQUENCE_STATE.Stopped;
            var stoppedPlan = SetWaitingPointsReady(CurrentPlan!);
            SetCurrentPlan(stoppedPlan, progress);
            return await CreateStoppedStatus(stoppedPlan, reviewProductId, "Review retry canceled.");
        }
        catch (Exception ex)
        {
            _reviewStageMotion?.Stop();
            SequenceState = EN_REVIEW_SEQUENCE_STATE.Failed;
            var failedPlan = SetWaitingPointsReady(CurrentPlan!);
            SetCurrentPlan(failedPlan, progress);
            WriteReviewError();
            var updateResult = await TrySetProductReviewError(reviewProductId, ex.Message);
            return CreateStatus(failedPlan, SequenceState, AppendUpdateResult(ex.Message, updateResult));
        }
        finally
        {
            RememberInterruptedReview(reviewProductId);
            _reviewStageMotion?.Dispose(); _reviewStageMotion = null;
            _sequenceLock.Release();
        }
    }

    private sealed record ST_REVIEW_MEASURE_RESULT(
        double X,
        double Y,
        string Judge,
        string RawResponse)
    {
        public ST_VISION_MARK_FIND? MarkFind { get; init; }
    }

    private enum EN_PRODUCT_REVIEW_UPDATE_OUTCOME
    {
        Success,
        NotApplicable,
        ProductReplaced,
        Failed
    }

    private sealed record ST_PRODUCT_REVIEW_UPDATE_RESULT(
        EN_PRODUCT_REVIEW_UPDATE_OUTCOME Outcome,
        string Detail)
    {
        public static readonly ST_PRODUCT_REVIEW_UPDATE_RESULT Success =
            new(EN_PRODUCT_REVIEW_UPDATE_OUTCOME.Success, string.Empty);
        public static readonly ST_PRODUCT_REVIEW_UPDATE_RESULT NotApplicable =
            new(EN_PRODUCT_REVIEW_UPDATE_OUTCOME.NotApplicable, string.Empty);
    }

    private static IReadOnlyList<ST_REVIEW_PLAN_POINT> OrderByReviewSequence(
        IEnumerable<ST_REVIEW_PLAN_POINT> points)
    {
        static double GetDesignY(ST_REVIEW_PLAN_POINT point)
        {
            return point.DesignY;
        }

        static double GetDesignX(ST_REVIEW_PLAN_POINT point)
        {
            return point.DesignX;
        }

        static int GetCellNo(ST_REVIEW_PLAN_POINT point)
        {
            return point.CellNo;
        }

        static int GetShotNo(ST_REVIEW_PLAN_POINT point)
        {
            return point.ShotNo;
        }

        var source = points
            .OrderBy(GetDesignY)
            .ThenBy(GetDesignX)
            .ThenBy(GetCellNo)
            .ThenBy(GetShotNo)
            .ToArray();
        var rows = new List<List<ST_REVIEW_PLAN_POINT>>();

        foreach (var point in source)
        {
            if (rows.Count == 0 ||
                Math.Abs(point.DesignY - rows[^1][0].DesignY) > ReviewSequenceRowTolerance)
            {
                rows.Add(new List<ST_REVIEW_PLAN_POINT>());
            }

            rows[^1].Add(point);
        }

        var orderedPoints = new List<ST_REVIEW_PLAN_POINT>(source.Length);

        for (var rowIndex = 0; rowIndex < rows.Count; rowIndex++)
        {
            var row = rows[rowIndex];
            var orderedRow = rowIndex % 2 == 0
                ? row
                    .OrderBy(GetDesignX)
                    .ThenBy(GetCellNo)
                    .ThenBy(GetShotNo)
                : row
                    .OrderByDescending(GetDesignX)
                    .ThenBy(GetCellNo)
                    .ThenBy(GetShotNo);

            orderedPoints.AddRange(orderedRow);
        }

        return orderedPoints;
    }

    private sealed record ST_REVIEW_HEAD_LAYOUT(
        IReadOnlyList<ST_REVIEW_HEAD_FIELD> Fields)
    {
        public ST_REVIEW_HEAD_FIELD GetFieldOrUnassigned(int headNo)
        {
            return Fields.FirstOrDefault(field => field.HeadNo == headNo)
                ?? new ST_REVIEW_HEAD_FIELD(
                    0,
                    0.0,
                    0.0);
        }
    }

    private sealed record ST_REVIEW_HEAD_FIELD(
        int HeadNo,
        double PositionX,
        double ScanFieldWidthX);

    private sealed record ST_REVIEW_COORDINATE_SETTINGS(
        ST_REVIEW_HEAD_LAYOUT HeadLayout,
        IReadOnlyList<int> ActiveHeadNos,
        EN_VISION_FLIP_TYPE VisionFlipType);

    public static string ToShotKey(int cellNo, int shotNo)
    {
        return $"CELL{Math.Max(1, cellNo):000}_SHOT{Math.Max(1, shotNo):0000}";
    }

    public static string NormalizeShotKey(string value)
    {
        var text = value.Trim().ToUpperInvariant();
        if (string.IsNullOrWhiteSpace(text))
        {
            return "";
        }

        var shotIndex = text.IndexOf("_SHOT", StringComparison.OrdinalIgnoreCase);
        const int keyLength = 5;
        if (shotIndex < 0)
        {
            shotIndex = text.IndexOf("_HOLE", StringComparison.OrdinalIgnoreCase);
        }
        if (text.StartsWith("CELL", StringComparison.OrdinalIgnoreCase) && shotIndex > 4)
        {
            var cellDigits = new string(text[4..shotIndex].Where(char.IsDigit).ToArray());
            var shotDigits = new string(text[(shotIndex + keyLength)..].Where(char.IsDigit).ToArray());

            if (int.TryParse(cellDigits, NumberStyles.Integer, CultureInfo.InvariantCulture, out var cellNo) &&
                int.TryParse(shotDigits, NumberStyles.Integer, CultureInfo.InvariantCulture, out var shotNo) &&
                cellNo > 0 &&
                shotNo > 0)
            {
                return ToShotKey(cellNo, shotNo);
            }
        }

        return "";
    }

    private static bool TryParseShotKey(string value, out int cellNo, out int shotNo)
    {
        cellNo = 0;
        shotNo = 0;
        var normalized = NormalizeShotKey(value);
        var separator = normalized.IndexOf("_SHOT", StringComparison.Ordinal);
        return separator > 4 &&
            int.TryParse(normalized.AsSpan(4, separator - 4), NumberStyles.Integer, CultureInfo.InvariantCulture, out cellNo) &&
            int.TryParse(normalized.AsSpan(separator + 5), NumberStyles.Integer, CultureInfo.InvariantCulture, out shotNo) &&
            cellNo > 0 && shotNo > 0;
    }

    private static int ReadInt(
        ST_RECIPE_DEFINITION recipe,
        int defaultValue,
        params string[] keys)
    {
        var value = ReadText(recipe, keys);

        if (int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var intValue))
        {
            return intValue;
        }

        return double.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out var doubleValue)
            ? (int)Math.Round(doubleValue)
            : defaultValue;
    }

    private static int ReadRequiredCellCount(
        ST_RECIPE_DEFINITION recipe,
        string key)
    {
        var parameter = FindParameter(recipe, key);
        var value = parameter?.Value?.Trim() ?? "";
        var minimum = GetParameterMinimum(parameter);
        var maximum = GetParameterMaximum(parameter, minimum);

        if (CCellPatternCalculator.TryParseCellCount(
                value,
                minimum,
                maximum,
                out var cellCount,
                out var validationMessage))
        {
            return cellCount;
        }

        throw new InvalidOperationException(validationMessage);
    }

    private static ST_RECIPE_PARAMETER? FindParameter(
        ST_RECIPE_DEFINITION recipe,
        string key)
    {
        return recipe.Parameters.FirstOrDefault(item =>
            item.Key.Equals(key, StringComparison.OrdinalIgnoreCase) ||
            item.Name.Equals(key, StringComparison.OrdinalIgnoreCase));
    }

    private static int GetParameterMinimum(ST_RECIPE_PARAMETER? parameter)
    {
        return parameter is not null && parameter.Max > parameter.Min
            ? Math.Max(CCellPatternCalculator.MinCellCount, (int)Math.Ceiling(parameter.Min))
            : CCellPatternCalculator.MinCellCount;
    }

    private static int? GetParameterMaximum(ST_RECIPE_PARAMETER? parameter, int minimum)
    {
        return parameter is not null && parameter.Max >= minimum
            ? (int)Math.Floor(parameter.Max)
            : null;
    }

    private static double ReadDouble(
        ST_RECIPE_DEFINITION recipe,
        double defaultValue,
        params string[] keys)
    {
        var value = ReadText(recipe, keys);

        return double.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out var doubleValue)
            ? doubleValue
            : defaultValue;
    }

    private static string ReadText(
        ST_RECIPE_DEFINITION recipe,
        params string[] keys)
    {
        var parameters = RecipeParameterIndexes.GetValue(
            recipe,
            static definition => CreateRecipeParameterIndex(definition));
        foreach (var key in keys)
        {
            if (parameters.TryGetValue(key, out var value) &&
                !string.IsNullOrWhiteSpace(value))
            {
                return value;
            }
        }

        return "";
    }

    private static Dictionary<string, string> CreateRecipeParameterIndex(
        ST_RECIPE_DEFINITION recipe)
    {
        var parameters = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var parameter in recipe.Parameters)
        {
            var value = parameter.Value?.Trim() ?? "";
            if (!string.IsNullOrWhiteSpace(parameter.Key))
            {
                parameters.TryAdd(parameter.Key, value);
            }

            if (!string.IsNullOrWhiteSpace(parameter.Name))
            {
                parameters.TryAdd(parameter.Name, value);
            }
        }

        return parameters;
    }
}
