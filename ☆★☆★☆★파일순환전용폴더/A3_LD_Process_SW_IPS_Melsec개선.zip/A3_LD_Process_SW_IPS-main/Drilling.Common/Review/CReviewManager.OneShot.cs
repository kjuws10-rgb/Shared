using Drilling.Common.Interface;
using Drilling.Common.Interface.Vision;
using Drilling.Common.Motion;

namespace Drilling.Common.Review;

public enum EN_ONE_SHOT_ACTION { Move, Inspection, MoveAndInspection }
public enum EN_ONE_SHOT_METHOD { MarkFindSingle, MarkFindSettingSingle }
public sealed record ST_ONE_SHOT_RESULT(ST_REVIEW_PLAN_POINT Point, ST_VISION_MARK_FIND? Mark,
    bool IsStageSimulation, bool IsVisionSimulation);

public sealed partial class CReviewManager
{
    public async Task<ST_ONE_SHOT_RESULT> ExecuteOneShot(ST_REVIEW_PLAN plan, ST_REVIEW_PLAN_POINT point,
        EN_ONE_SHOT_ACTION action, EN_ONE_SHOT_METHOD method, Action<string> progress,
        CancellationToken cancellationToken = default)
    {
        if (!Enum.IsDefined(action) || !Enum.IsDefined(method)) throw new ArgumentException("지원하지 않는 One Shot 동작입니다.");
        if (!point.Use || point.HeadNo <= 0 || point.ExclusionReason.Length > 0 ||
            !plan.Points.Any(item => item.ShotKey == point.ShotKey && item.Use) ||
            !double.IsFinite(point.ReviewTargetX) || !double.IsFinite(point.ReviewTargetY))
            throw new InvalidOperationException("가공 가능한 Shot과 Beam을 선택해 주세요.");
        var deviceNo = GetReviewStageDeviceNo();
        var stageSimulation = IsReviewDeviceSimulation(EN_EQP_MODULE.Melsec, deviceNo);
        var move = action != EN_ONE_SHOT_ACTION.Inspection;
        if (move && !stageSimulation)
            throw new InvalidOperationException("Stage Y / Review X 실제 이동 주소는 아직 미정입니다. 이동은 MELSEC 시뮬레이션에서 실행할 수 있습니다.");
        var reviewMotion = ST_REVIEW_MOTION_PARAMETERS.Read(settingManager);
        if (!await _sequenceLock.WaitAsync(0, cancellationToken)) throw new InvalidOperationException("다른 Review 검사가 진행 중입니다.");
        CManualStageMotionSimulation? simulation = null;
        CManualStageMotionSimulation.MotionLease? lease = null;
        var started = false;
        try
        {
            if (stageSimulation)
            {
                simulation = interfaceManager.GetStageMotionSimulation(deviceNo);
                lease = simulation.AcquireExclusiveMotion();
            }
            Interlocked.Exchange(ref _stopRequested, 0);
            SequenceState = EN_REVIEW_SEQUENCE_STATE.Running; started = true;
            CheckStop();
            if (move)
            {
                progress("Stage Y / Review X 이동 중");
                CheckStop();
                lease!.Move(EN_MANUAL_STAGE_AXIS.StageY, point.ReviewTargetY, 1000);
                lease.Move(EN_MANUAL_STAGE_AXIS.ReviewX, point.ReviewTargetX, reviewMotion.Speed, reviewMotion.Acceleration);
                var deadline = DateTimeOffset.UtcNow.AddSeconds(30);
                while (true)
                {
                    CheckStop();
                    var feedback = interfaceManager.GetStageMotionSimulationFeedback(deviceNo);
                    if (feedback["MOTOR_STAGE_Y_BUSY"] == 0 && feedback["MOTOR_CAMERA_X_BUSY"] == 0)
                    {
                        if (Math.Abs(feedback["MOTOR_STAGE_Y_CUR_POS"] - point.ReviewTargetY) > .0005 ||
                            Math.Abs(feedback["MOTOR_CAMERA_X_CUR_POS"] - point.ReviewTargetX) > .0005)
                            throw new InvalidOperationException("목표 위치에 도착하기 전에 Stage 이동이 정지되었습니다.");
                        break;
                    }
                    if (DateTimeOffset.UtcNow >= deadline) throw new TimeoutException("이동 완료 대기 시간 초과 (30초)");
                    await Task.Delay(20, cancellationToken);
                }
                progress("이동 완료");
            }
            ST_VISION_MARK_FIND? mark = null;
            var result = point;
            var visionSimulation = IsReviewSimulation();
            if (action != EN_ONE_SHOT_ACTION.Move)
            {
                if (move) await Task.Delay(250, cancellationToken);
                CheckStop(); progress("Vision 응답 대기 중");
                ST_REVIEW_MEASURE_RESULT measurement;
                if (method == EN_ONE_SHOT_METHOD.MarkFindSingle)
                    measurement = await MeasureVision(point, cancellationToken);
                else if (visionSimulation)
                    measurement = CreateTemporaryVisionMeasurement(point);
                else
                    measurement = ParseVisionResponse(await ExecuteVisionCommand("MARK_FIND_SETTING_SINGLE",
                        "Mark Find Setting Single 응답이 없습니다.", cancellationToken), point);
                CheckStop();
                result = ApplyRoughMeasurement(plan, point, measurement);
                mark = measurement.MarkFind;
            }
            CheckStop(); SequenceState = EN_REVIEW_SEQUENCE_STATE.Completed;
            return new(result, mark, stageSimulation, visionSimulation);
        }
        catch (OperationCanceledException) { if (started) SequenceState = EN_REVIEW_SEQUENCE_STATE.Stopped; throw; }
        catch { if (started) SequenceState = EN_REVIEW_SEQUENCE_STATE.Failed; throw; }
        finally
        {
            if (lease is not null) { if (move) simulation!.Stop(); lease.Dispose(); }
            _sequenceLock.Release();
        }
        void CheckStop() { cancellationToken.ThrowIfCancellationRequested(); if (IsStopRequested) throw new OperationCanceledException("Review Stop"); }
    }
}
