namespace Drilling.Common.Review;

public sealed record ST_FINE_OFFSET_DELTA(ST_REVIEW_PLAN_POINT Shot, double X, double Y);

/// <summary>Design coordinates only. Never combine different Cells or columns, or apply Head transforms here.</summary>
public static class CFineReviewOffsetCalculator
{
    public static IReadOnlyList<ST_FINE_OFFSET_DELTA> Calculate(IReadOnlyList<ST_REVIEW_PLAN_POINT> targets,
        IReadOnlyList<ST_REVIEW_PLAN_POINT> measurements, EN_VISION_FLIP_TYPE flip)
    {
        if (measurements.Count == 0) throw new InvalidOperationException("검사 결과가 없습니다.");
        if (measurements.Any(point => point.State == EN_REVIEW_POINT_STATE.Ng || point.Judge.Trim().Equals("NG", StringComparison.OrdinalIgnoreCase)))
            throw new InvalidOperationException("NG가 있어 FINE Offset 전체를 적용할 수 없습니다. NG RETRY 후 다시 적용해 주세요.");
        if (measurements.Any(point => point.State != EN_REVIEW_POINT_STATE.Ok || point.Judge != "OK"))
            throw new InvalidOperationException("검사 대상이 모두 OK로 완료되어야 Offset을 적용할 수 있습니다.");
        if (measurements.Select(point => point.ShotKey).Distinct(StringComparer.OrdinalIgnoreCase).Count() != measurements.Count)
            throw new InvalidOperationException("중복된 검사 Shot이 있습니다.");
        if (measurements.Concat(targets).Any(point => !double.IsFinite(point.DesignX) || !double.IsFinite(point.DesignY)) ||
            measurements.Any(point => !double.IsFinite(point.ErrorX) || !double.IsFinite(point.ErrorY)))
            throw new InvalidOperationException("Shot 좌표 또는 검사 결과가 올바르지 않습니다.");
        var columns = measurements.GroupBy(ColumnKey).ToDictionary(group => group.Key, group => group.OrderBy(point => point.DesignY).ToArray());
        var result = new List<ST_FINE_OFFSET_DELTA>();
        foreach (var column in targets.GroupBy(ColumnKey))
        {
            // Masking/CHESS may leave a column without any inspected Shot. Preserve that column's saved values.
            if (!columns.TryGetValue(column.Key, out var anchors)) continue;
            if (anchors.Select(point => Math.Round(point.DesignY, 6)).Distinct().Count() != anchors.Length)
                throw new InvalidOperationException($"Cell{column.Key.Cell:00}의 같은 열/Y에 중복 검사 결과가 있습니다.");
            var values = anchors.Select(point => CReviewCoordinateTransformer.VisionErrorToStageOffset(point.ErrorX, point.ErrorY, flip)).ToArray();
            var xs = values.Select(value => value.X).ToArray();
            var ys = values.Select(value => value.Y).ToArray();
            foreach (var shot in column)
            {
                var x = Interpolate(anchors, xs, shot.DesignY);
                var y = Interpolate(anchors, ys, shot.DesignY);
                if (!double.IsFinite(x) || !double.IsFinite(y)) throw new InvalidOperationException("FINE 보간 결과가 올바르지 않습니다.");
                result.Add(new(shot, x, y));
            }
        }
        if (result.Count == 0) throw new InvalidOperationException("적용할 Shot이 없습니다.");
        return result;
    }

    private static (int Cell, double X) ColumnKey(ST_REVIEW_PLAN_POINT point) => (point.CellNo, Math.Round(point.DesignX, 6));

    private static double Interpolate(ST_REVIEW_PLAN_POINT[] anchors, double[] values, double y)
    {
        if (anchors.Length == 1) return values[0];
        var origin = anchors[0].DesignY;
        var range = anchors[^1].DesignY - origin;
        var at = (y - origin) / range;
        var sum = 0.0;
        // At most seven anchors. Normalize Y and retain full precision until the accumulated value is saved.
        for (var i = 0; i < anchors.Length; i++)
        {
            if (Math.Abs(y - anchors[i].DesignY) < 1e-9) return values[i];
            var node = (anchors[i].DesignY - origin) / range;
            var basis = 1.0;
            for (var j = 0; j < anchors.Length; j++)
                if (i != j) { var other = (anchors[j].DesignY - origin) / range; basis *= (at - other) / (node - other); }
            sum += basis * values[i];
        }
        return sum;
    }
}
