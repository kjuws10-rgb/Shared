using Drilling.Common.Motion;

namespace Drilling.Common.Review;

public sealed record ST_ZERO_DEFENCE_TIMING_PROFILE(double StageStartY, double StageDirection,
    double StageSpeed, double ReviewSpeed, double ReviewAcceleration)
{
    // MCC chart: 2420 mm process travel, 80 mm/s nominal, 147.1 mm/s² acceleration/deceleration.
    // Stage speed is the actual recipe value; Stage origin is the configured Ready position.
    public double StageStroke { get; init; } = 2420;
    public double StageAcceleration { get; init; } = 147.1;
    public double SettleSeconds { get; init; } = .050;
    public double ArrivalMarginSeconds { get; init; } = .020;
    public double FramesPerSecond { get; init; } = 20;
    public double ExposureSeconds { get; init; } = .000010;
}
public sealed record ST_ZERO_DEFENCE_POINT(int HeadNo, int CellNo, int ShotNo, int BeamNo,
    string ShotKey, string ShotName, double ReviewX, double StageY, double MachiningDistance, double MachiningSeconds);
public sealed record ST_ZERO_DEFENCE_TIMING_ISSUE(int GroupNo, int FromHead, int ToHead, string Reason,
    double AvailableSeconds = 0, double RequiredSeconds = 0);
public sealed record ST_ZERO_DEFENCE_TRANSITION(int GroupNo, int FromHead, int ToHead,
    double AvailableSeconds, double RequiredSeconds)
{
    public double MarginSeconds => AvailableSeconds - RequiredSeconds;
}
public sealed record ST_ZERO_DEFENCE_TIMING_RESULT(IReadOnlyList<ST_ZERO_DEFENCE_TIMING_ISSUE> Issues,
    IReadOnlyList<ST_ZERO_DEFENCE_TRANSITION> Transitions)
{
    public bool IsValid => Issues.Count == 0;
    public string Message => string.Join("\n", Issues.Select(i => i.Reason));
}

/// <summary>No I/O. Validates each glass group, including exposure, X rest-to-rest travel and camera cadence.</summary>
public static class CZeroDefenceTiming
{
    public static ST_ZERO_DEFENCE_TIMING_RESULT Validate(int count, IEnumerable<ST_ZERO_DEFENCE_POINT> selections,
        ST_ZERO_DEFENCE_TIMING_PROFILE profile)
    {
        var issues = new List<ST_ZERO_DEFENCE_TIMING_ISSUE>();
        var transitions = new List<ST_ZERO_DEFENCE_TRANSITION>();
        if (count is not (2 or 4)) return new([new(0, 0, 0, "검사 개수는 2 또는 4만 가능합니다.")], []);
        var points = selections.ToArray();
        if (points.Any(p => p.HeadNo is < 1 or > 8) || points.GroupBy(p => p.HeadNo).Any(g => g.Count() != 1))
            return new([new(0, 0, 0, "Head별로 검사점 하나만 지정할 수 있습니다.")], []);
        if (profile.StageDirection is not (-1 or 1) || !double.IsFinite(profile.StageStartY) ||
            !double.IsFinite(profile.SettleSeconds) || profile.SettleSeconds < 0 ||
            !double.IsFinite(profile.ArrivalMarginSeconds) || profile.ArrivalMarginSeconds < 0 ||
            !double.IsFinite(profile.FramesPerSecond) || profile.FramesPerSecond <= 0 ||
            !double.IsFinite(profile.ExposureSeconds) || profile.ExposureSeconds <= 0)
            return new([new(0, 0, 0, "0선방어 이동·카메라 조건이 올바르지 않습니다.")], []);
        var stage = new CTrapezoidalMotion(profile.StageStroke, profile.StageSpeed, profile.StageAcceleration);
        _ = new CTrapezoidalMotion(0, profile.ReviewSpeed, profile.ReviewAcceleration);
        var samples = new List<(ST_ZERO_DEFENCE_POINT Point, double Time)>();
        foreach (var p in points)
        {
            var group = (p.HeadNo - 1) / count + 1;
            var travel = (p.StageY - profile.StageStartY) * profile.StageDirection;
            if (!double.IsFinite(p.ReviewX) || !double.IsFinite(travel) ||
                travel < stage.AccelerationDistance - 1e-8 ||
                travel + profile.StageSpeed * profile.ExposureSeconds > profile.StageStroke - stage.DecelerationDistance + 1e-8)
            {
                issues.Add(new(group, p.HeadNo, p.HeadNo, $"H{p.HeadNo:00} {p.ShotName}: 촬영 위치가 MCC 등속 가공 구간 밖입니다. 카메라 AK Y 티칭·Stage 시작 위치를 확인해 주세요."));
                continue;
            }
            var time = stage.TimeAt(travel);
            if (!double.IsFinite(p.MachiningDistance) || p.MachiningDistance < 0 || p.MachiningDistance > profile.StageStroke ||
                !double.IsFinite(p.MachiningSeconds) || p.MachiningSeconds < 0 ||
                time + 1e-8 < stage.TimeAt(p.MachiningDistance) + p.MachiningSeconds)
            {
                issues.Add(new(group, p.HeadNo, p.HeadNo, $"H{p.HeadNo:00} {p.ShotName}: 해당 Shot의 가공이 끝나기 전에 카메라 위치를 통과합니다."));
                continue;
            }
            samples.Add((p, time));
        }
        foreach (var group in samples.GroupBy(s => (s.Point.HeadNo - 1) / count + 1))
        {
            var ordered = group.OrderBy(s => s.Time).ThenBy(s => s.Point.HeadNo).ToArray();
            for (var i = 1; i < ordered.Length; i++)
            {
                var previous = ordered[i - 1]; var next = ordered[i];
                var move = new CTrapezoidalMotion(Math.Abs(next.Point.ReviewX - previous.Point.ReviewX), profile.ReviewSpeed, profile.ReviewAcceleration);
                var available = next.Time - previous.Time;
                var required = Math.Max(1 / profile.FramesPerSecond,
                    profile.ExposureSeconds + move.Duration + profile.SettleSeconds + profile.ArrivalMarginSeconds);
                transitions.Add(new(group.Key, previous.Point.HeadNo, next.Point.HeadNo, available, required));
                if (available + 1e-8 < required)
                    issues.Add(new(group.Key, previous.Point.HeadNo, next.Point.HeadNo,
                        $"그룹 {group.Key} · H{previous.Point.HeadNo:00} → H{next.Point.HeadNo:00}: " +
                        $"검사 간격 {available * 1000:0.0} ms / 필요 {required * 1000:0.0} ms " +
                        $"(X 이동 {move.Duration * 1000:0.0} + 안정화 {profile.SettleSeconds * 1000:0.0} + 여유 {profile.ArrivalMarginSeconds * 1000:0.0} ms).",
                        available, required));
            }
        }
        return new(issues, transitions);
    }
}
