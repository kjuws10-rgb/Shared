namespace Drilling.Common.Review;

public sealed record ST_REVIEW_SETTING_PROFILE(
    string RecipeId,
    string Rule,
    string Scope,
    string RoughReference,
    int FineLineCount,
    int BeamNo,
    string InspectionMethod,
    string SimpleShot);

public abstract class CReviewSettingFileBase
{
    public abstract Task<IReadOnlyList<string>> List(
        string recipeId,
        CancellationToken cancellationToken = default);

    public abstract Task<ST_REVIEW_SETTING_PROFILE> Load(
        string recipeId,
        string settingName,
        CancellationToken cancellationToken = default);

    public abstract Task Save(
        string recipeId,
        string settingName,
        ST_REVIEW_SETTING_PROFILE profile,
        CancellationToken cancellationToken = default);

    public abstract Task Rename(
        string recipeId,
        string oldSettingName,
        string newSettingName,
        CancellationToken cancellationToken = default);

    public abstract Task Delete(
        string recipeId,
        string settingName,
        CancellationToken cancellationToken = default);

    public abstract Task RenameRecipe(
        string oldRecipeId,
        string newRecipeId,
        CancellationToken cancellationToken = default);

    public abstract string GetDisplayPath(string recipeId, string settingName);
}
