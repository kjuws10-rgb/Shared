namespace Drilling.Common.Review;

/// <summary>Saved measurements for display; these are not targets in the current Recipe.</summary>
public sealed record ST_BEAM_INSPECTION_RESULT_BEAM(int BeamNo, double? XMm, double? YMm, string Judge)
{
    public bool IsMeasured => Judge is "OK" or "NG";
}

public sealed record ST_BEAM_INSPECTION_RESULT_SHOT(string GlassName, string HeadName, int HeadNo,
    string CellName, int CellNo, string ShotName, IReadOnlyList<ST_BEAM_INSPECTION_RESULT_BEAM> Beams);

public sealed record ST_BEAM_INSPECTION_RESULT_FILE_DATA(string FilePath, string FileName,
    DateTimeOffset SavedAt, bool IsSimulation, string GlassName,
    IReadOnlyList<ST_BEAM_INSPECTION_RESULT_SHOT> Shots);

public sealed partial class CReviewManager
{
    public Task<ST_BEAM_INSPECTION_RESULT_FILE_DATA?> LoadLastBeamInspection(CancellationToken cancellationToken = default)
        => reviewResultFile.LoadLastBeamInspection(cancellationToken);
}
