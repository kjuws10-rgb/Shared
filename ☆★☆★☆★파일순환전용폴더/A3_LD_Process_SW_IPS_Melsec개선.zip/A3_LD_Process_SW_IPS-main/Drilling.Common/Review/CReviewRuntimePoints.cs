using System.Collections;
using System.Collections.Immutable;

namespace Drilling.Common.Review;

// Published plans remain immutable. Updates copy only the affected tree branches,
// while every snapshot shares the fixed Shot/Cell indexes for this run.
internal sealed class CReviewRuntimePoints : IReadOnlyList<ST_REVIEW_PLAN_POINT>
{
    private sealed class Index
    {
        public readonly Dictionary<string, int> Shots = new(StringComparer.OrdinalIgnoreCase);
        public readonly Dictionary<(int Cell, int Shot), int> Positions = new();
        public readonly Dictionary<int, List<int>> Cells = new();
        public readonly int[] Selected;

        public Index(IReadOnlyList<ST_REVIEW_PLAN_POINT> points)
        {
            var selected = new List<int>();
            for (var i = 0; i < points.Count; i++)
            {
                var point = points[i];
                Shots.Add(point.ShotKey, i);
                Positions.Add((point.CellNo, point.ShotNo), i);
                if (!Cells.TryGetValue(point.CellNo, out var cell)) Cells.Add(point.CellNo, cell = []);
                cell.Add(i);
                if (point.Use) selected.Add(i);
            }
            Selected = selected.ToArray();
        }
    }

    private readonly ImmutableList<ST_REVIEW_PLAN_POINT> _points;
    private readonly Index _index;
    public IReadOnlyList<ST_REVIEW_PLAN_POINT> SelectedPoints { get; }
    public int Count => _points.Count;
    public ST_REVIEW_PLAN_POINT this[int index] => _points[index];

    public CReviewRuntimePoints(IReadOnlyList<ST_REVIEW_PLAN_POINT> points)
        : this(points.ToImmutableList(), new Index(points)) { }

    private CReviewRuntimePoints(ImmutableList<ST_REVIEW_PLAN_POINT> points, Index index)
    {
        _points = points;
        _index = index;
        SelectedPoints = index.Selected.Length == points.Count ? this : new Selection(this);
    }

    public CReviewRuntimePoints Update(IReadOnlyList<ST_REVIEW_PLAN_POINT> updates)
    {
        var builder = _points.ToBuilder();
        foreach (var point in updates)
        {
            var index = _index.Shots[point.ShotKey];
            if (point.Use != _points[index].Use)
                throw new InvalidOperationException("The inspection selection cannot change during a run.");
            builder[index] = point;
        }
        return new CReviewRuntimePoints(builder.ToImmutable(), _index);
    }

    public ST_REVIEW_PLAN_POINT? Find(string key) => _index.Shots.TryGetValue(key, out var i) ? _points[i] : null;
    public ST_REVIEW_PLAN_POINT? Find(int cell, int shot) => _index.Positions.TryGetValue((cell, shot), out var i) ? _points[i] : null;
    public IReadOnlyList<ST_REVIEW_PLAN_POINT> Cell(int cell) => _index.Cells.TryGetValue(cell, out var indices)
        ? indices.Select(i => _points[i]).ToArray() : [];
    public IEnumerator<ST_REVIEW_PLAN_POINT> GetEnumerator() => _points.GetEnumerator();
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();

    private sealed class Selection(CReviewRuntimePoints owner) : IReadOnlyList<ST_REVIEW_PLAN_POINT>
    {
        public int Count => owner._index.Selected.Length;
        public ST_REVIEW_PLAN_POINT this[int index] => owner._points[owner._index.Selected[index]];
        public IEnumerator<ST_REVIEW_PLAN_POINT> GetEnumerator()
        {
            foreach (var index in owner._index.Selected) yield return owner._points[index];
        }
        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
    }
}
