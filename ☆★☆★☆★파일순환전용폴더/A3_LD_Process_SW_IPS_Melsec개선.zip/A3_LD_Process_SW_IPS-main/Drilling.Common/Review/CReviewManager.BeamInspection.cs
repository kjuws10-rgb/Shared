using Drilling.Common.Managers;
using Drilling.Common.Interface;

namespace Drilling.Common.Review;

public sealed record ST_BEAM_INSPECTION_SNAPSHOT(
    string RecipeId,
    IReadOnlyList<ST_REVIEW_PLAN_POINT> Points,
    EN_REVIEW_SEQUENCE_STATE State,
    int ActiveIndex,
    string Message,
    bool IsSimulation)
{
    public bool IsStageSimulation { get; init; } = IsSimulation;
    public bool IsVisionSimulation { get; init; } = IsSimulation;
    public string? SavedPath { get; init; }
    public string? SaveError { get; init; }
    public int CompletedCount => Points.Count(p => p.State is EN_REVIEW_POINT_STATE.Ok or EN_REVIEW_POINT_STATE.Ng);
    public int NgCount => Points.Count(p => p.State == EN_REVIEW_POINT_STATE.Ng);
}

public sealed partial class CReviewManager
{
    public static IReadOnlyList<ST_REVIEW_PLAN_POINT> BuildBeamInspectionTargets(
        ST_RECIPE_DEFINITION recipe, ST_REVIEW_PLAN allPlan,
        IReadOnlyCollection<string> shotKeys, IReadOnlyCollection<int> beamNos)
    {
        if (shotKeys.Count == 0 || beamNos.Count == 0)
            throw new InvalidOperationException("Shot과 Beam을 각각 하나 이상 선택해 주세요.");

        var beams = beamNos.Distinct().Order().ToArray();
        var splitCount = ReadInt(recipe, 0, "SPLITED_BEAM_COUNT");
        foreach (var beam in beams) ValidateBeamNo(beam, splitCount);
        var shots = shotKeys.Distinct(StringComparer.OrdinalIgnoreCase)
            .Select(key => TryParseShotKey(key, out var cell, out var shot)
                ? allPlan.FindPoint(cell, shot) : null).ToArray();
        if (shots.Any(point => point is null || point.HeadNo <= 0 || !string.IsNullOrWhiteSpace(point.ExclusionReason)))
            throw new InvalidOperationException("선택한 Shot에 미할당 또는 MASKING/CHESS 제외 항목이 있습니다. 선택을 확인해 주세요.");

        var targets = new List<ST_REVIEW_PLAN_POINT>();
        foreach (var shot in shots.OfType<ST_REVIEW_PLAN_POINT>().OrderBy(p => p.CellNo).ThenBy(p => p.ShotNo))
        {
            var positions = GetShotBeamPositions(recipe, shot, allPlan.StageScanDirectionY).ToDictionary(p => p.BeamNo);
            foreach (var beam in beams)
            {
                var position = positions[beam];
                targets.Add(shot with
                {
                    PointNo = targets.Count + 1, BeamNo = beam, Use = true,
                    ReviewTargetX = position.ReviewX, ReviewTargetY = position.StageY,
                    State = EN_REVIEW_POINT_STATE.Ready, Judge = "WAIT", ErrorX = 0, ErrorY = 0
                });
            }
        }
        return targets;
    }

    public async Task<ST_BEAM_INSPECTION_SNAPSHOT> StartBeamInspection(
        ST_RECIPE_DEFINITION recipe, ST_REVIEW_PLAN allPlan,
        IReadOnlyCollection<string> shotKeys, IReadOnlyCollection<int> beamNos,
        Action<ST_BEAM_INSPECTION_SNAPSHOT> progress,
        CancellationToken cancellationToken = default)
    {
        var targets = BuildBeamInspectionTargets(recipe, allPlan, shotKeys, beamNos).ToArray();
        // The existing motion methods do not yet transmit MELSEC commands or
        // await a hardware completion signal. Never measure real glass at an unverified position.
        var stageSimulation = IsReviewDeviceSimulation(EN_EQP_MODULE.Melsec, GetReviewStageDeviceNo());
        var visionSimulation = IsReviewSimulation();
        if (!stageSimulation)
            throw new InvalidOperationException("Stage Y / Review X 실제 MELSEC 이동 주소와 완료 확인은 아직 미연결입니다. MELSEC 시뮬레이션에서는 Vision 장치의 실제 통신/시뮬레이션 설정을 독립적으로 사용할 수 있습니다.");
        if (!await _sequenceLock.WaitAsync(0, cancellationToken))
            throw new InvalidOperationException("다른 Review 검사가 진행 중입니다.");

        var activeIndex = -1;
        CReviewStageMotion? motion = null;
        var glassId = productManager?.Current?.GlassId ?? "";
        ST_BEAM_INSPECTION_SNAPSHOT Publish(string message)
        {
            var snapshot = new ST_BEAM_INSPECTION_SNAPSHOT(recipe.Id, Array.AsReadOnly(targets.ToArray()),
                SequenceState, activeIndex, message, stageSimulation || visionSimulation)
                { IsStageSimulation = stageSimulation, IsVisionSimulation = visionSimulation };
            progress(snapshot);
            return snapshot;
        }
        async Task<ST_BEAM_INSPECTION_SNAPSHOT> Finish(string message)
        {
            motion?.Dispose(); motion = null;
            var snapshot = new ST_BEAM_INSPECTION_SNAPSHOT(recipe.Id, Array.AsReadOnly(targets.ToArray()),
                SequenceState, -1, message, stageSimulation || visionSimulation)
                { IsStageSimulation = stageSimulation, IsVisionSimulation = visionSimulation };
            try
            {
                // A user stop cancels motion, but must not discard measurements already taken.
                var path = await reviewResultFile.SaveBeamInspection(snapshot, glassId, DateTimeOffset.Now,
                    CancellationToken.None);
                snapshot = snapshot with { SavedPath = path };
            }
            catch (Exception exception)
            {
                snapshot = snapshot with { SaveError = exception.Message };
            }
            progress(snapshot);
            return snapshot;
        }
        try
        {
            Interlocked.Exchange(ref _stopRequested, 0);
            motion = OpenReviewStageMotion();
            SequenceState = EN_REVIEW_SEQUENCE_STATE.Running;
            Publish("Beam Inspection 시작");
            for (var index = 0; index < targets.Length; index++)
            {
                cancellationToken.ThrowIfCancellationRequested();
                if (IsStopRequested) break;
                activeIndex = index;
                targets[index] = targets[index] with { State = EN_REVIEW_POINT_STATE.Current };
                Publish("측정 중");
                await motion.MoveAndWait(targets[index], cancellationToken);
                await Task.Delay(250, cancellationToken);
                if (IsStopRequested) break;
                var measurement = await MeasureVision(targets[index], cancellationToken);
                targets[index] = ApplyMeasurement(allPlan, targets[index], measurement);
                Publish("측정 완료");
            }
            SequenceState = targets.All(p => p.State is EN_REVIEW_POINT_STATE.Ok or EN_REVIEW_POINT_STATE.Ng)
                ? EN_REVIEW_SEQUENCE_STATE.Completed : EN_REVIEW_SEQUENCE_STATE.Stopped;
            for (var i = 0; i < targets.Length; i++)
                if (targets[i].State == EN_REVIEW_POINT_STATE.Current)
                    targets[i] = targets[i] with { State = EN_REVIEW_POINT_STATE.Ready };
            activeIndex = -1;
            return await Finish(SequenceState == EN_REVIEW_SEQUENCE_STATE.Completed ? "검사 완료" : "검사 중지");
        }
        catch (OperationCanceledException)
        {
            SequenceState = EN_REVIEW_SEQUENCE_STATE.Stopped;
            if (activeIndex >= 0 && targets[activeIndex].State == EN_REVIEW_POINT_STATE.Current)
                targets[activeIndex] = targets[activeIndex] with { State = EN_REVIEW_POINT_STATE.Ready };
            activeIndex = -1;
            return await Finish("검사 취소");
        }
        catch (Exception exception)
        {
            SequenceState = EN_REVIEW_SEQUENCE_STATE.Failed;
            if (activeIndex >= 0 && targets[activeIndex].State == EN_REVIEW_POINT_STATE.Current)
                targets[activeIndex] = targets[activeIndex] with { State = EN_REVIEW_POINT_STATE.Ready, Judge = "ERROR" };
            activeIndex = -1;
            return await Finish(exception.Message);
        }
        finally
        {
            motion?.Dispose();
            _sequenceLock.Release();
        }
    }
}
