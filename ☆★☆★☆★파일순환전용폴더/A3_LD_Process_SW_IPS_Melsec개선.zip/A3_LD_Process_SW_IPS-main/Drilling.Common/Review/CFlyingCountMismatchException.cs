namespace Drilling.Common.Review;

internal sealed class CFlyingCountMismatchException(string response) : InvalidOperationException("Vision 촬영 개수 불일치 / " + response);
