using Drilling.Common.Interface;
using Drilling.Common.Motion;

namespace Drilling.Common.Review;

public sealed partial class CReviewManager
{
    private CReviewStageMotion? _reviewStageMotion;

    private int GetReviewStageDeviceNo() => interfaceManager.Melsec.Map.FirstOrDefault(row =>
        row.Id.Equals("MOTOR_STAGE_Y_CUR_POS", StringComparison.OrdinalIgnoreCase))?.DeviceNo
        ?? interfaceManager.GetInterfaceList(EN_EQP_MODULE.Melsec).FirstOrDefault()?.Number ?? 0;

    private bool IsReviewDeviceSimulation(EN_EQP_MODULE module, int number)
    {
        // Use this device's effective mode even before it connects. Other devices must not change it.
        var device = interfaceManager.GetInterfaceCommunicationList(module).FirstOrDefault(row => row.Number == number);
        return device?.IsSimulation ?? (interfaceManager.Devices.Count == 0 && interfaceManager.IsSimulation);
    }

    private CReviewStageMotion OpenReviewStageMotion()
    {
        var number = GetReviewStageDeviceNo();
        if (!IsReviewDeviceSimulation(EN_EQP_MODULE.Melsec, number))
            throw new InvalidOperationException("Stage Y / Review X 실제 MELSEC 이동 주소와 완료 확인은 아직 미연결입니다. MELSEC 이동 시뮬레이션과 Vision 통신 설정은 각각 독립적으로 적용됩니다.");
        return new(interfaceManager.GetStageMotionSimulation(number), () => IsStopRequested, ST_REVIEW_MOTION_PARAMETERS.Read(settingManager));
    }

    private sealed class CReviewStageMotion : IDisposable
    {
        private readonly CManualStageMotionSimulation _simulation;
        private readonly CManualStageMotionSimulation.MotionLease _lease;
        private readonly Func<bool> _stopRequested;
        private readonly ST_REVIEW_MOTION_PARAMETERS _motion;
        public CReviewStageMotion(CManualStageMotionSimulation simulation, Func<bool> stopRequested, ST_REVIEW_MOTION_PARAMETERS motion)
        { _simulation = simulation; _stopRequested = stopRequested; _motion = motion; _lease = simulation.AcquireExclusiveMotion(); }
        public void MoveStageY(double position) => _lease.Move(EN_MANUAL_STAGE_AXIS.StageY, position, 1000);
        public void MoveReviewX(double position) => _lease.Move(EN_MANUAL_STAGE_AXIS.ReviewX, position, _motion.Speed, _motion.Acceleration);
        public double ReviewXPosition => _simulation.GetSnapshot().Single(axis => axis.Axis == EN_MANUAL_STAGE_AXIS.ReviewX).Position;
        public async Task MoveAndWait(ST_REVIEW_PLAN_POINT point, CancellationToken token)
        { CheckStop(token); MoveStageY(point.ReviewTargetY); MoveReviewX(point.ReviewTargetX); await WaitForArrival(point, token); }
        public async Task WaitForArrival(ST_REVIEW_PLAN_POINT point, CancellationToken token)
        {
            var deadline = DateTimeOffset.UtcNow.AddSeconds(30);
            while (true)
            {
                CheckStop(token);
                var axes = _simulation.GetSnapshot();
                if (axes.All(axis => !axis.IsMoving))
                {
                    if (Math.Abs(axes.Single(axis => axis.Axis == EN_MANUAL_STAGE_AXIS.StageY).Position - point.ReviewTargetY) > .0005 ||
                        Math.Abs(axes.Single(axis => axis.Axis == EN_MANUAL_STAGE_AXIS.ReviewX).Position - point.ReviewTargetX) > .0005)
                        throw new InvalidOperationException("Stage Y / Review X가 목표 위치에 도착하기 전에 정지되었습니다.");
                    return;
                }
                if (DateTimeOffset.UtcNow >= deadline) throw new TimeoutException("Stage Y / Review X 이동 완료 대기 시간 초과 (30초)");
                await Task.Delay(20, token);
            }
        }
        private void CheckStop(CancellationToken token)
        { token.ThrowIfCancellationRequested(); if (_stopRequested()) throw new OperationCanceledException("Review Stop"); }
        public void Stop() => _simulation.Stop();
        public void Dispose() { Stop(); _lease.Dispose(); }
    }
}
