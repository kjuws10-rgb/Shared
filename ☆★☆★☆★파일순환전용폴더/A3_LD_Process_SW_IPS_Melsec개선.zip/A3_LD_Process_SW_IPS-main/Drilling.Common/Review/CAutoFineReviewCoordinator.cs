using Drilling.Common.Recipe;
using Drilling.Common.Interface.Vision;

namespace Drilling.Common.Review;

/// <summary>Stage-handshake actions. No UI dependencies; only the next recipe load consumes the new offset file.</summary>
public sealed class CAutoFineReviewCoordinator(CReviewManager review, CReviewOffsetFileBase offsets,
    Func<CancellationToken, Task<ST_AUTO_REVIEW_INPUT>> capture,
    Func<IReadOnlyList<ST_REVIEW_PLAN_POINT>, CancellationToken, Task<IReadOnlyList<ST_VISION_MARK_FIND>>>? simulationMeasurement = null)
{
    private ST_AUTO_FINE_PLAN? _prepared;
    private ST_FINE_REVIEW_SNAPSHOT? _result;
    private bool _saved;
    public string Outcome { get; private set; } = "검사 대기";

    public async Task Prepare(CancellationToken token)
    {
        _prepared = null; _result = null; _saved = false;
        var input = await capture(token).ConfigureAwait(false);
        token.ThrowIfCancellationRequested();
        _prepared = review.CreateAutoFinePlan(input, token);
        Outcome = $"{input.GlassId} / {input.Recipe.Name} / Beam 11 / {input.Options.Method} / {input.Options.LineCount} Line / " +
            $"즉시 재시도 {(input.Options.ImmediateRetry ? "ON" : "OFF")} / {input.Options.CountMismatchRetries}회 · 계획 확정";
        review.RecordAutoFineLog("AUTO_REVIEW_PLAN", Outcome);
    }

    public async Task Measure(CancellationToken token)
    {
        var plan = _prepared ?? throw new InvalidOperationException("AUTO Review 계획이 없습니다.");
        _result = null;
        _result = await review.StartFineCorrection(plan.Request, _ => { }, token, simulationMeasurement).ConfigureAwait(false);
        token.ThrowIfCancellationRequested();
        if (_result.State != EN_REVIEW_SEQUENCE_STATE.Completed)
            throw new InvalidOperationException($"AUTO Review가 정상 완료되지 않았습니다: {_result.Message}");
        if (_result.ResultSaveError.Length > 0 || string.IsNullOrWhiteSpace(_result.ResultFilePath))
            throw new IOException($"AUTO Review 결과 저장을 확인할 수 없습니다: {_result.ResultSaveError}");
        if (_result.Lines.SelectMany(line => line.Points).Any(point => point.State is not (EN_REVIEW_POINT_STATE.Ok or EN_REVIEW_POINT_STATE.Ng)))
            throw new InvalidOperationException("미검사 또는 유효하지 않은 결과가 있어 Review COMPLETE를 보낼 수 없습니다.");
    }

    public async Task Save(CancellationToken token)
    {
        if (_saved) return;
        var plan = _prepared ?? throw new InvalidOperationException("AUTO Review 계획이 없습니다.");
        var result = _result ?? throw new InvalidOperationException("AUTO Review 검사 결과가 없습니다.");
        token.ThrowIfCancellationRequested();
        if (result.State != EN_REVIEW_SEQUENCE_STATE.Completed || result.ResultSaveError.Length > 0 || string.IsNullOrWhiteSpace(result.ResultFilePath))
            throw new InvalidOperationException("정상 완료 및 결과 파일 저장이 확인된 검사만 보정에 사용할 수 있습니다.");
        var measured = result.Lines.SelectMany(line => line.Points).ToArray();
        var ng = measured.Count(point => point.State == EN_REVIEW_POINT_STATE.Ng);
        if (ng > 0)
        {
            // Inspection completion is different from a quality OK. Keep every old offset when any Shot is NG.
            Outcome = $"검사 {measured.Length:N0}개 완료 / NG {ng:N0}개 · 보정 전체 미적용 · 기존 Review Offset 유지";
            review.RecordAutoFineLog("AUTO_REVIEW_NG", Outcome); _saved = true; return;
        }
        var deltas = CFineReviewOffsetCalculator.Calculate(plan.OffsetTargets, measured, plan.Request.Plan.VisionFlipType);
        var latest = await offsets.LoadLatest(plan.Request.Plan.RecipeId, token).ConfigureAwait(false);
        if (!latest.RecipeId.Equals(plan.Request.Plan.RecipeId, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("기존 Review Offset의 Recipe ID가 일치하지 않습니다.");
        var rows = latest.Rows.ToDictionary(row => (row.CellId, Normalize(row.ShotId)));
        foreach (var delta in deltas)
        {
            token.ThrowIfCancellationRequested();
            var shot = delta.Shot;
            var key = (shot.CellNo, Normalize(CReviewShotNameFormatter.ToMatrixName(shot.ShotNo, shot.PixelCountX)));
            var previous = rows.GetValueOrDefault(key);
            var design = previous is null ? (X: 0d, Y: 0d) : CReviewOffsetData.ToDesign(plan.Parameters, shot.HeadNo,
                previous.ReviewOffsetX, previous.ReviewOffsetY, previous.IsDesignCoordinate);
            if (!double.IsFinite(design.X) || !double.IsFinite(design.Y)) throw new InvalidDataException("기존 Review Offset 값이 유효하지 않습니다.");
            rows[key] = new(shot.CellNo, key.Item2, CAlignShotOffsetData.RoundValue(design.X + delta.X),
                CAlignShotOffsetData.RoundValue(design.Y + delta.Y)) { IsDesignCoordinate = true };
        }
        var saved = await offsets.SaveNew(plan.Request.Plan.RecipeId,
            rows.Values.OrderBy(row => row.CellId).ThenBy(row => row.ShotId).ToArray(), token).ConfigureAwait(false);
        _saved = true;
        review.FineMonitor.MarkOffsetSaved(result.RunId, saved.FileName);
        Outcome = $"전체 OK · {deltas.Count:N0} Shots FINE 누적 보정 저장 · 다음 Glass에 적용 / {saved.FileName}";
        review.RecordAutoFineLog("AUTO_REVIEW_OFFSET_SAVED", Outcome);
    }

    private static string Normalize(string text) => text.Trim().Replace("-", "_", StringComparison.Ordinal)
        .Replace(".", "_", StringComparison.Ordinal).ToUpperInvariant();
}
