using System.Collections.ObjectModel;
using System.Globalization;
using Drilling.Common.Managers;
using Drilling.Common.Recipe;

namespace Drilling.Common.Review;

public sealed record ST_AUTO_REVIEW_OPTIONS(int LineCount = 1, EN_FINE_INSPECTION_METHOD Method = EN_FINE_INSPECTION_METHOD.Flying,
    int CountMismatchRetries = 1, bool ImmediateRetry = false)
{
    public const int BeamNo = 11;
}
public sealed record ST_AUTO_REVIEW_INPUT(ST_RECIPE_DEFINITION Recipe, string GlassId, ST_AUTO_REVIEW_OPTIONS Options);
public sealed record ST_AUTO_FINE_PLAN(ST_FINE_REVIEW_REQUEST Request, IReadOnlyList<ST_REVIEW_PLAN_POINT> OffsetTargets,
    IReadOnlyDictionary<string, string> Parameters);

/// <summary>Prepared once before Prc Review ABLE. All coordinates and options remain frozen for that request.</summary>
public static class CAutoFineReviewPlan
{
    public static ST_AUTO_FINE_PLAN Build(ST_AUTO_REVIEW_INPUT input, IReadOnlyList<ST_SYSTEM_PARAMETER> settings)
    {
        if (input.Options.LineCount is not (1 or 3 or 5 or 7) || input.Options.Method is not (EN_FINE_INSPECTION_METHOD.Flying or EN_FINE_INSPECTION_METHOD.PtoP) ||
            input.Options.CountMismatchRetries is < 1 or > 3)
            throw new InvalidOperationException("AUTO Review 검사 방식 또는 라인 수가 올바르지 않습니다.");
        var parameters = input.Recipe.Parameters.Where(item => item.Key.Length > 0)
            .GroupBy(item => item.Key, StringComparer.OrdinalIgnoreCase).ToDictionary(group => group.Key, group => group.Last().Value, StringComparer.OrdinalIgnoreCase);
        foreach (var setting in settings.Where(item => item.Key.Length > 0)) parameters[setting.Key] = setting.Value;
        var frozen = new ReadOnlyDictionary<string, string>(parameters);
        var effectiveRecipe = input.Recipe with { Parameters = parameters.Select(pair =>
            new ST_RECIPE_PARAMETER(pair.Key, pair.Value, "", "", pair.Value, Key: pair.Key)).ToArray() };
        var calculate = CReviewManager.CreateShotBeamPositionCalculator(effectiveRecipe, CScannerAxisTransform.ReadStageDirection(frozen));
        var masking = CRecipeShotMaskingPlan.Build(frozen);
        var shots = CShotCoordinatePlanBuilder.Build(frozen).Shots;
        var all = shots.Select(shot => new ST_REVIEW_PLAN_POINT(shot.SequenceNo, shot.ShotKey, shot.HeadNo, shot.CellNo, shot.CellShotNo,
                shot.GroupCountX, shot.GroupCountY, shot.HeadNo > 0 && !masking.EvaluateShot(shot).ShouldSkipLaser,
                shot.DesignX, shot.DesignY, 0, 0, 0, 0, EN_REVIEW_POINT_STATE.Ready, "WAIT")
                { BeamNo = ST_AUTO_REVIEW_OPTIONS.BeamNo }).ToArray();
        var targets = all.Where(point => point.Use).ToArray();
        if (targets.Length == 0) throw new InvalidOperationException("AUTO Review 검사 대상 Shot이 없습니다.");
        var source = new ST_REVIEW_PLAN(input.Recipe.Id, targets.Select(point => point.CellNo).Distinct().Count(),
            Tolerance("REVIEW_TOLERANCE_X"), Tolerance("REVIEW_TOLERANCE_Y"),
            CReviewCoordinateTransformer.ParseVisionFlipType(parameters.GetValueOrDefault("VisionXFlip"),
                parameters.GetValueOrDefault("VisionYFlip"), parameters.GetValueOrDefault("VisionXyFlip")), DateTimeOffset.Now, all);
        var selected = CReviewRulePlanBuilder.Build(source, new(EN_REVIEW_CORRECTION_RULE.Fine,
            EN_REVIEW_CORRECTION_SCOPE.HeadCell, ST_AUTO_REVIEW_OPTIONS.BeamNo, "", EN_REVIEW_REFERENCE_LINE.First, input.Options.LineCount))
            .ShotKeys.ToHashSet(StringComparer.OrdinalIgnoreCase);
        var models = all.Select(point => point.CellNo).Distinct().ToDictionary(cell => cell,
            cell => CRecipeModelPixelCountReader.ReadCellModelType(parameters, cell));
        var modelCounts = models.Values.GroupBy(model => model).ToDictionary(group => group.Key, group => group.Count());
        var lines = new List<ST_FINE_REVIEW_LINE>();
        foreach (var model in targets.Where(point => selected.Contains(point.ShotKey)).GroupBy(point => models[point.CellNo])
            .OrderByDescending(group => modelCounts[group.Key]).ThenBy(group => group.Key))
        {
            var row = 0;
            foreach (var line in model.GroupBy(point => Math.Round(point.DesignY, 6)).OrderBy(group => group.Key))
            {
                var leftToRight = row++ % 2 == 0;
                var points = (leftToRight ? line.OrderBy(point => point.DesignX) : line.OrderByDescending(point => point.DesignX))
                    .ThenBy(point => point.CellNo).ThenBy(point => point.ShotNo).Select(point =>
                    {
                        var position = calculate(point, ST_AUTO_REVIEW_OPTIONS.BeamNo);
                        return point with { ReviewTargetX = position.ReviewX, ReviewTargetY = position.StageY };
                    }).ToArray();
                lines.Add(new($"B11:{model.Key}:{line.Key.ToString("R", CultureInfo.InvariantCulture)}", lines.Count + 1, model.Key, Array.AsReadOnly(points)));
            }
        }
        if (lines.Count == 0) throw new InvalidOperationException("AUTO FINE 검사 라인을 만들 수 없습니다.");
        var plan = source with { Points = Array.AsReadOnly(lines.SelectMany(line => line.Points).ToArray()) };
        var request = new ST_FINE_REVIEW_REQUEST(plan, lines.AsReadOnly(), input.Options.Method)
        {
            StopOnNgLine = false,
            CountMismatchRetries = input.Options.CountMismatchRetries,
            ImmediateRetry = input.Options.ImmediateRetry,
            Context = new(input.Recipe.Name, input.GlassId, "AUTO", input.Options.LineCount, frozen)
        };
        return new(request, Array.AsReadOnly(targets), frozen);

        double Tolerance(string key) => double.TryParse(parameters.GetValueOrDefault(key, "0.03"), NumberStyles.Float,
            CultureInfo.InvariantCulture, out var value) && double.IsFinite(value) && value >= 0 ? value
            : throw new InvalidOperationException($"{key} 설정을 확인해 주세요.");
    }
}
