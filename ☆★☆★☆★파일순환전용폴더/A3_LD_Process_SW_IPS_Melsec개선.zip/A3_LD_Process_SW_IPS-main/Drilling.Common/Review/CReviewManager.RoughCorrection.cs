using Drilling.Common.Interface;
using Drilling.Common.Interface.Vision;
using Drilling.Common.Motion;

namespace Drilling.Common.Review;

public sealed record ST_ROUGH_REVIEW_SNAPSHOT(string RecipeId, IReadOnlyList<ST_REVIEW_PLAN_POINT> Points,
    EN_REVIEW_SEQUENCE_STATE State, string Message)
{
    public string ResultFilePath { get; init; } = "";
    public string ResultSaveError { get; init; } = "";
}
public sealed record ST_ROUGH_REVIEW_RESULT_DATA(ST_REVIEW_PLAN Plan, ST_ROUGH_REVIEW_SNAPSHOT Snapshot,
    DateTimeOffset SavedAt, bool IsNgRetry, IReadOnlySet<string> AttemptedShotKeys,
    bool IsStageSimulation, bool IsVisionSimulation);
public sealed record ST_ROUGH_REVIEW_MEASUREMENT(double TargetX, double TargetY, double HoleX, double HoleY, string Judge);

public sealed partial class CReviewManager
{
    public static IReadOnlyList<ST_REVIEW_PLAN_POINT> OrderRoughTargets(IEnumerable<ST_REVIEW_PLAN_POINT> points)
        => points.GroupBy(point => Math.Round(point.DesignY, 3)).OrderBy(group => group.Key)
            .SelectMany((group, row) => row % 2 == 0
                ? group.OrderBy(point => point.DesignX).ThenBy(point => point.CellNo)
                : group.OrderByDescending(point => point.DesignX).ThenBy(point => point.CellNo)).ToArray();

    public async Task<ST_ROUGH_REVIEW_SNAPSHOT> StartRoughCorrection(ST_REVIEW_PLAN plan, bool retryNg,
        Action<ST_ROUGH_REVIEW_SNAPSHOT> progress, CancellationToken cancellationToken = default,
        Func<ST_REVIEW_PLAN_POINT, CancellationToken, Task<ST_ROUGH_REVIEW_MEASUREMENT>>? simulationMeasurement = null)
    {
        var deviceNo = GetReviewStageDeviceNo();
        if (!IsReviewDeviceSimulation(EN_EQP_MODULE.Melsec, deviceNo))
            throw new InvalidOperationException("Stage Y / Review X 실제 이동·완료 확인은 아직 미연결입니다. 현재 ROUGH 검사는 MELSEC 시뮬레이션에서 실행할 수 있습니다. Vision 측정은 해당 장치의 시뮬레이션 설정에 따릅니다.");
        var reviewMotion = ST_REVIEW_MOTION_PARAMETERS.Read(settingManager);
        if (!await _sequenceLock.WaitAsync(0, cancellationToken)) throw new InvalidOperationException("다른 Review 검사가 진행 중입니다.");
        var points = plan.Points.ToDictionary(point => point.ShotKey, StringComparer.OrdinalIgnoreCase);
        var targets = OrderRoughTargets(plan.Points.Where(point => !retryNg || point.State == EN_REVIEW_POINT_STATE.Ng));
        var simulation = interfaceManager.GetStageMotionSimulation(deviceNo);
        CManualStageMotionSimulation.MotionLease? lease = null;
        ST_REVIEW_PLAN_POINT? active = null;
        var attempted = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var started = false;
        var visionSimulation = IsReviewSimulation();
        ST_ROUGH_REVIEW_SNAPSHOT Publish(string message)
        {
            var snapshot = new ST_ROUGH_REVIEW_SNAPSHOT(plan.RecipeId,
                Array.AsReadOnly(plan.Points.Select(point => points[point.ShotKey]).ToArray()), SequenceState, message);
            progress(snapshot);
            return snapshot;
        }
        try
        {
            if (targets.Count == 0) throw new InvalidOperationException(retryNg ? "재검사할 NG Shot이 없습니다." : "검사할 Shot이 없습니다.");
            lease = simulation.AcquireExclusiveMotion();
            started = true;
            LastSavedResultPath = null;
            Interlocked.Exchange(ref _stopRequested, 0);
            SequenceState = EN_REVIEW_SEQUENCE_STATE.Running;
            if (!retryNg)
                foreach (var key in points.Keys.ToArray()) points[key] = points[key] with { State = EN_REVIEW_POINT_STATE.Ready, Judge = "WAIT", ErrorX = 0, ErrorY = 0 };
            Publish(retryNg ? "NG 재검사 시작" : "ROUGH 검사 시작");
            foreach (var target in targets)
            {
                cancellationToken.ThrowIfCancellationRequested();
                if (IsStopRequested) break;
                active = target;
                attempted.Add(target.ShotKey);
                points[target.ShotKey] = target with { State = EN_REVIEW_POINT_STATE.Current, Judge = "WAIT", ErrorX = 0, ErrorY = 0 };
                Publish("이동 / 측정 중");
                lease.Move(EN_MANUAL_STAGE_AXIS.StageY, target.ReviewTargetY, 1000);
                lease.Move(EN_MANUAL_STAGE_AXIS.ReviewX, target.ReviewTargetX, reviewMotion.Speed, reviewMotion.Acceleration);
                var deadline = DateTimeOffset.UtcNow.AddSeconds(30);
                while (true)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    if (IsStopRequested) break;
                    var positions = simulation.GetSnapshot();
                    if (positions.All(axis => !axis.IsMoving))
                    {
                        if (Math.Abs(positions.Single(axis => axis.Axis == EN_MANUAL_STAGE_AXIS.StageY).Position - target.ReviewTargetY) > 0.0005 ||
                            Math.Abs(positions.Single(axis => axis.Axis == EN_MANUAL_STAGE_AXIS.ReviewX).Position - target.ReviewTargetX) > 0.0005)
                            throw new InvalidOperationException("목표 위치에 도착하기 전에 Stage 이동이 정지되었습니다.");
                        break;
                    }
                    if (DateTimeOffset.UtcNow >= deadline) throw new TimeoutException("ROUGH 시뮬레이션 이동 시간 초과");
                    await Task.Delay(20, cancellationToken);
                }
                if (IsStopRequested) break;
                await Task.Delay(250, cancellationToken);
                if (IsStopRequested) break;
                if (simulationMeasurement is null)
                    points[target.ShotKey] = ApplyRoughMeasurement(plan, target, await MeasureVision(target, cancellationToken));
                else
                {
                    var measured = await simulationMeasurement(target, cancellationToken);
                    points[target.ShotKey] = ApplyRoughMeasurement(plan, target, new ST_REVIEW_MEASURE_RESULT(
                        0, 0, measured.Judge, "ROUGH_SIMULATION")
                        { MarkFind = new ST_VISION_MARK_FIND(measured.Judge == "NG" ? 0 : 1,
                            measured.TargetX, measured.TargetY, measured.HoleX, measured.HoleY) });
                }
                active = null;
                Publish("측정 완료");
            }
            SequenceState = active is null && !IsStopRequested ? EN_REVIEW_SEQUENCE_STATE.Completed : EN_REVIEW_SEQUENCE_STATE.Stopped;
            return await Finish(SequenceState == EN_REVIEW_SEQUENCE_STATE.Completed ? "검사 완료" : "검사 중지");
        }
        catch (OperationCanceledException)
        {
            SequenceState = EN_REVIEW_SEQUENCE_STATE.Stopped;
            return await Finish("검사 중지");
        }
        catch (Exception error)
        {
            SequenceState = EN_REVIEW_SEQUENCE_STATE.Failed;
            if (active is not null) points[active.ShotKey] = active with { State = EN_REVIEW_POINT_STATE.Ready, Judge = "ERROR" };
            return await Finish(error.Message);
        }
        finally
        {
            ReleaseMotion();
            _sequenceLock.Release();
        }
        void ReleaseMotion()
        {
            if (lease is null) return;
            simulation.Stop(); lease.Dispose(); lease = null;
        }
        async Task<ST_ROUGH_REVIEW_SNAPSHOT> Finish(string message)
        {
            if (active is not null && points[active.ShotKey].State == EN_REVIEW_POINT_STATE.Current)
                points[active.ShotKey] = active with { State = EN_REVIEW_POINT_STATE.Ready, Judge = "WAIT", ErrorX = 0, ErrorY = 0 };
            ReleaseMotion();
            var snapshot = Publish(message);
            if (!started) return snapshot;
            try
            {
                var result = new ST_ROUGH_REVIEW_RESULT_DATA(plan, snapshot, DateTimeOffset.Now, retryNg,
                    attempted, true, visionSimulation);
                // A user Stop cancels motion/measurement, but must not cancel the final result save.
                var path = await Task.Run(() => reviewResultFile.SaveRoughCorrection(result, CancellationToken.None));
                LastSavedResultPath = path;
                snapshot = snapshot with { ResultFilePath = path };
                WriteReviewLog("ROUGH_RESULT_SAVED", path);
            }
            catch (Exception error)
            {
                snapshot = snapshot with { ResultSaveError = error.Message,
                    Message = message + " / 검사 결과 저장 실패: " + error.Message };
                WriteReviewLog("ROUGH_RESULT_SAVE_ERROR", error.ToString());
            }
            progress(snapshot);
            return snapshot;
        }
    }

    private static ST_REVIEW_PLAN_POINT ApplyRoughMeasurement(ST_REVIEW_PLAN plan, ST_REVIEW_PLAN_POINT point,
        ST_REVIEW_MEASURE_RESULT measurement)
    {
        var mark = measurement.MarkFind ?? throw new InvalidDataException("Mark Find Single 응답에 Target/Hole 좌표가 없습니다.");
        var x = mark.TargetMarkX - mark.HoleX;
        var y = mark.TargetMarkY - mark.HoleY;
        if (!double.IsFinite(mark.TargetMarkX) || !double.IsFinite(mark.TargetMarkY) ||
            !double.IsFinite(mark.HoleX) || !double.IsFinite(mark.HoleY) || !double.IsFinite(x) || !double.IsFinite(y))
            throw new InvalidDataException("Mark Find Single의 Target/Hole 좌표가 유효하지 않습니다.");
        // These are camera response coordinates, independent of Stage/Review movement targets and head direction.
        return ApplyMeasurementError(plan, point, x, y, measurement.Judge);
    }
}
