using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Net.WebSockets;
using System.Security.Cryptography;

var root = Path.GetFullPath(args.Length > 0 ? args[0] : Path.Combine(AppContext.BaseDirectory, "../../../../../"));
var relay = Path.Combine(root, "src", "MiniRemote.Relay", "bin", "Release", "net10.0", "MiniRemote.Relay.dll");
if (!File.Exists(relay)) throw new FileNotFoundException("Build the relay in Release first.", relay);
var checks = 0;
await using (var server = await Server.Start(root, relay))
{
    using var http = new HttpClient { BaseAddress = new Uri(server.Origin) };
    using (var health = await http.GetAsync("/health"))
    {
        Check(health.StatusCode == HttpStatusCode.OK && await health.Content.ReadAsStringAsync() == "ok", "health");
        Check(health.Headers.GetValues("Content-Security-Policy").Single().Contains("default-src 'none'", StringComparison.Ordinal), "CSP");
        Check(health.Headers.GetValues("Referrer-Policy").Single() == "no-referrer", "referrer header");
        Check(health.Headers.CacheControl?.NoStore == true, "cache header");
    }
    Check((await http.GetAsync("/ws/short/host")).StatusCode == HttpStatusCode.BadRequest, "malformed room");
    Check((await http.GetAsync($"/ws/{Room()}/host")).StatusCode == HttpStatusCode.BadRequest, "plain HTTP cannot create room");
    Check((await http.GetAsync("/ws/a/b/extra")).StatusCode == HttpStatusCode.NotFound, "extra path rejected");
    using (var page = await http.GetAsync("/"))
        Check(page.StatusCode == HttpStatusCode.OK && page.Content.Headers.ContentType?.MediaType == "text/html", "viewer page served");
    using (var script = await http.GetAsync("/app.mjs"))
        Check(script.StatusCode == HttpStatusCode.OK && script.Content.Headers.ContentType?.MediaType is "text/javascript" or "application/javascript", "viewer module served");
    using (var request = new HttpRequestMessage(HttpMethod.Get, "/health"))
    {
        request.Headers.Host = "attacker.example";
        Check((await http.SendAsync(request)).StatusCode == HttpStatusCode.BadRequest, "unapproved Host rejected");
    }
    await Rejected(server, Room(), "viewer", server.Origin, HttpStatusCode.NotFound, "viewer cannot create room");
    var room = Room();
    using var host = await Connect(server, room, "host");
    await Rejected(server, room, "host", null, HttpStatusCode.Conflict, "duplicate host rejected");
    await Rejected(server, room, "viewer", "https://attacker.example", HttpStatusCode.Forbidden, "foreign Origin rejected");
    await Rejected(server, room, "viewer", null, HttpStatusCode.Forbidden, "missing viewer Origin rejected");
    using var viewer = await Connect(server, room, "viewer", server.Origin);
    await Rejected(server, room, "viewer", server.Origin, HttpStatusCode.Conflict, "duplicate viewer rejected");
    var payload = RandomNumberGenerator.GetBytes(50000);
    await host.SendAsync(payload.AsMemory(0, 17000), WebSocketMessageType.Binary, false, CancellationToken.None);
    await host.SendAsync(payload.AsMemory(17000), WebSocketMessageType.Binary, true, CancellationToken.None);
    var receivedFrame = await Receive(viewer);
    Check(payload.SequenceEqual(receivedFrame), "fragmented opaque host packet");
    var input = RandomNumberGenerator.GetBytes(8192);
    await viewer.SendAsync(input, WebSocketMessageType.Binary, true, CancellationToken.None);
    var receivedInput = await Receive(host);
    Check(input.SequenceEqual(receivedInput), "opaque viewer packet at limit");
    await viewer.CloseOutputAsync(WebSocketCloseStatus.NormalClosure, "test", CancellationToken.None);
    await Closed(host);
    await Rejected(server, room, "viewer", server.Origin, HttpStatusCode.NotFound, "disconnected room removed");
    await Rejected(server, room, "host", null, HttpStatusCode.Conflict, "consumed room cannot be recreated");
    checks++;
    Console.WriteLine("PASS disconnect closes both peers and removes room");

    await InvalidMessage(server, WebSocketMessageType.Text, new byte[40], "text rejected");
    await InvalidMessage(server, WebSocketMessageType.Binary, new byte[8193], "oversize viewer rejected");

    var oversizedRoom = Room();
    using var oversizedHost = await Connect(server, oversizedRoom, "host");
    using var oversizedViewer = await Connect(server, oversizedRoom, "viewer", server.Origin);
    try { await oversizedHost.SendAsync(new byte[2 * 1024 * 1024 + 1], WebSocketMessageType.Binary, true, CancellationToken.None); }
    catch (WebSocketException) { }
    await Closed(oversizedViewer);
    checks++;
    Console.WriteLine("PASS oversize host rejected");

    using var waitingHost = await Connect(server, Room(), "host");
    await waitingHost.SendAsync(new byte[40], WebSocketMessageType.Binary, true, CancellationToken.None);
    await Closed(waitingHost);
    checks++;
    Console.WriteLine("PASS missing peer is never buffered");
}
// A fresh server keeps quota tests independent from earlier handshake attempts.
await using (var server = await Server.Start(root, relay))
{
    var sockets = new List<ClientWebSocket>();
    try
    {
        for (var i = 0; i < 12; i++) sockets.Add(await Connect(server, Room(), "host"));
        await Rejected(server, Room(), "host", null, HttpStatusCode.TooManyRequests, "IP connection cap");
    }
    finally { foreach (var socket in sockets) socket.Dispose(); }
}
await using (var server = await Server.Start(root, relay))
{
    var room = Room();
    using var host = await Connect(server, room, "host");
    using var viewer = await Connect(server, room, "viewer", server.Origin);
    var draining = DrainUntilClosed(host);
    for (var i = 0; i < 130 && viewer.State == WebSocketState.Open; i++)
    {
        try { await viewer.SendAsync(new byte[40], WebSocketMessageType.Binary, true, CancellationToken.None); }
        catch (WebSocketException) { break; }
    }
    await draining;
    checks++;
    Console.WriteLine("PASS viewer message rate cap");
}
await using (var server = await Server.Start(root, relay, defaults: true))
{
    using var host = await Connect(server, Room(), "host");
    // The alias origins are exact strings; changing a port or adding a slash is rejected.
    var aliasRoom = Room();
    using var aliasHost = await Connect(server, aliasRoom, "host");
    using var aliasViewer = await Connect(server, aliasRoom, "viewer", "http://localhost:8787");
    Check(aliasViewer.State == WebSocketState.Open, "default localhost Origin accepted");
    var numericRoom = Room();
    using var numericHost = await Connect(server, numericRoom, "host");
    using var numericViewer = await Connect(server, numericRoom, "viewer", "http://127.0.0.1:8787");
    Check(numericViewer.State == WebSocketState.Open, "default numeric loopback Origin accepted");
    await Rejected(server, numericRoom, "viewer", "http://localhost:8787/", HttpStatusCode.Forbidden, "Origin trailing slash rejected");
    await Rejected(server, numericRoom, "viewer", "http://localhost:8788", HttpStatusCode.Forbidden, "Origin wrong port rejected");
}
Console.WriteLine($"PASS {checks} relay checks; no screen capture or input injection used.");

void Check(bool condition, string description)
{
    if (!condition) throw new InvalidOperationException(description);
    checks++;
    Console.WriteLine($"PASS {description}");
}

async Task Rejected(Server server, string room, string role, string? origin, HttpStatusCode expected, string description)
{
    using var socket = new ClientWebSocket();
    socket.Options.CollectHttpResponseDetails = true;
    if (origin is not null) socket.Options.SetRequestHeader("Origin", origin);
    try
    {
        using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(5));
        await socket.ConnectAsync(new Uri($"{server.WebSocketOrigin}/ws/{room}/{role}"), timeout.Token);
        throw new InvalidOperationException($"Unexpected accepted connection: {description}");
    }
    catch (WebSocketException)
    {
        Check(socket.HttpStatusCode == expected, description);
    }
}

async Task InvalidMessage(Server server, WebSocketMessageType type, byte[] bytes, string description)
{
    var room = Room();
    using var host = await Connect(server, room, "host");
    using var viewer = await Connect(server, room, "viewer", server.Origin);
    await viewer.SendAsync(bytes, type, true, CancellationToken.None);
    await Closed(host);
    checks++;
    Console.WriteLine($"PASS {description}");
}

static string Room() => Convert.ToBase64String(RandomNumberGenerator.GetBytes(16)).TrimEnd('=').Replace('+', '-').Replace('/', '_');
static async Task<ClientWebSocket> Connect(Server server, string room, string role, string? origin = null)
{
    var socket = new ClientWebSocket();
    if (origin is not null) socket.Options.SetRequestHeader("Origin", origin);
    using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(5));
    await socket.ConnectAsync(new Uri($"{server.WebSocketOrigin}/ws/{room}/{role}"), timeout.Token);
    return socket;
}
static async Task<byte[]> Receive(ClientWebSocket socket)
{
    using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(5));
    using var bytes = new MemoryStream();
    var buffer = new byte[16384];
    ValueWebSocketReceiveResult result;
    do
    {
        result = await socket.ReceiveAsync(buffer.AsMemory(), timeout.Token);
        if (result.MessageType != WebSocketMessageType.Binary) throw new InvalidOperationException("Expected binary packet");
        bytes.Write(buffer, 0, result.Count);
    } while (!result.EndOfMessage);
    return bytes.ToArray();
}
static async Task Closed(ClientWebSocket socket)
{
    using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(5));
    try
    {
        var result = await socket.ReceiveAsync(new byte[16384].AsMemory(), timeout.Token);
        if (result.MessageType != WebSocketMessageType.Close) throw new InvalidOperationException("Expected peer close");
    }
    catch (WebSocketException) { }
}
static async Task DrainUntilClosed(ClientWebSocket socket)
{
    using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(5));
    try
    {
        while (true)
        {
            var result = await socket.ReceiveAsync(new byte[16384].AsMemory(), timeout.Token);
            if (result.MessageType == WebSocketMessageType.Close) return;
        }
    }
    catch (WebSocketException) { }
}

internal sealed class Server(Process process, string origin) : IAsyncDisposable
{
    public string Origin { get; } = origin;
    public string WebSocketOrigin => Origin.Replace("http:", "ws:", StringComparison.Ordinal);
    public static async Task<Server> Start(string root, string relay, bool defaults = false)
    {
        var listener = new TcpListener(IPAddress.Loopback, 0);
        listener.Start();
        var port = defaults ? 8787 : ((IPEndPoint)listener.LocalEndpoint).Port;
        listener.Stop();
        var origin = $"http://127.0.0.1:{port}";
        var start = new ProcessStartInfo("dotnet")
        {
            WorkingDirectory = Path.Combine(root, "src", "MiniRemote.Relay"),
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true
        };
        start.ArgumentList.Add(relay);
        if (defaults)
        {
            start.Environment.Remove("ASPNETCORE_URLS");
            start.Environment.Remove("MINIREMOTE_PUBLIC_ORIGIN");
        }
        else
        {
            start.Environment["ASPNETCORE_URLS"] = origin;
            start.Environment["MINIREMOTE_PUBLIC_ORIGIN"] = origin;
        }
        start.Environment["DOTNET_NOLOGO"] = "1";
        var process = Process.Start(start) ?? throw new InvalidOperationException("Cannot start relay");
        var result = new Server(process, origin);
        using var http = new HttpClient { Timeout = TimeSpan.FromMilliseconds(300) };
        for (var i = 0; i < 80; i++)
        {
            if (process.HasExited) throw new InvalidOperationException("Relay exited: " + await process.StandardError.ReadToEndAsync());
            try
            {
                if (await http.GetStringAsync(origin + "/health") == "ok") return result;
            }
            catch (HttpRequestException) { }
            catch (TaskCanceledException) { }
            await Task.Delay(100);
        }
        await result.DisposeAsync();
        throw new TimeoutException("Relay did not start");
    }
    public async ValueTask DisposeAsync()
    {
        if (!process.HasExited) process.Kill(entireProcessTree: true);
        await process.WaitForExitAsync();
        var output = await process.StandardOutput.ReadToEndAsync();
        var error = await process.StandardError.ReadToEndAsync();
        if (output.Contains("/ws/", StringComparison.Ordinal) || error.Contains("/ws/", StringComparison.Ordinal))
            throw new InvalidOperationException("Relay output leaked request paths");
        process.Dispose();
    }
}
