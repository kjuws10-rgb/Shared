using System.Collections.Concurrent;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Net.WebSockets;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using MiniRemote.Core;

var checks = new List<string>();
void Check(bool condition, string label) { if (!condition) throw new Exception("FAIL: " + label); checks.Add(label); }
void Reject(Action action, string label)
{
    bool failed = false;
    try { action(); } catch { failed = true; }
    Check(failed, label);
}

var master = Enumerable.Range(0, 32).Select(i => (byte)i).ToArray();
if (args.FirstOrDefault() == "--wire-vector")
{
    using var vector = new Wire(master, true);
    Console.WriteLine(JsonSerializer.Serialize(new { key = Convert.ToBase64String(master), packet = Convert.ToBase64String(vector.Encode(MessageKind.Decision, Encoding.UTF8.GetBytes("{\"accepted\":true}"))) }));
    return;
}
if (args.FirstOrDefault() == "--decode-viewer")
{
    using var vector = new Wire(master, true);
    var decoded = vector.Decode(Convert.FromBase64String(args[1]));
    Check(decoded.Kind == MessageKind.Hello && Encoding.UTF8.GetString(decoded.Payload) == "{\"name\":\"browser-test\"}", "JS->C# cross-runtime packet");
    Console.WriteLine("PASS JS->C# cross-runtime packet");
    return;
}
using (var hostWire = new Wire(master, true))
using (var viewerWire = new Wire(master, false))
{
    var hello = viewerWire.Encode(MessageKind.Hello, Encoding.UTF8.GetBytes("hello"));
    Check(Encoding.UTF8.GetString(hostWire.Decode(hello).Payload) == "hello", "directional crypto roundtrip");
    Reject(() => hostWire.Decode(hello), "replay rejected");
    var next = viewerWire.Encode(MessageKind.Heartbeat, []); next[^1] ^= 1;
    Reject(() => hostWire.Decode(next), "tampered tag rejected");
    var own = hostWire.Encode(MessageKind.Decision, [1]);
    Reject(() => hostWire.Decode(own), "reflected directional packet rejected");
    Reject(() => hostWire.Decode([1, 2]), "truncated packet rejected");
    using var wrong = new Wire(RandomNumberGenerator.GetBytes(32), true);
    Reject(() => wrong.Decode(hello), "wrong key rejected");
}
Check(RelayAddress.Parse("http://localhost:8787").IsLoopback, "loopback HTTP allowed");
Check(RelayAddress.Socket(RelayAddress.Parse("https://example.com"), "room").ToString() == "wss://example.com/ws/room/host", "HTTPS->WSS endpoint");
foreach (var bad in new[] { "http://example.com", "https://user:pw@example.com", "https://example.com/path", "https://example.com/?x=1", "https://example.com/#key=secret", "file:///tmp" })
    Reject(() => RelayAddress.Parse(bad), "bad relay URI: " + bad.Split('?')[0].Split('#')[0]);
Check(InputCommand.Parse(Encoding.UTF8.GetBytes("{\"kind\":\"key\",\"code\":\"KeyA\",\"down\":true}")).Down, "valid physical key");
Check(KeyCodes.TryGet("Lang1", out var hangul) && hangul == 0x15, "Hangul mode key");
foreach (var bad in new[] { "{\"kind\":\"move\",\"x\":2,\"y\":0}", "{\"kind\":\"button\",\"x\":0,\"y\":0,\"button\":8,\"down\":true}", "{\"kind\":\"key\",\"code\":\"ExecuteShell\",\"down\":true}", "{\"kind\":\"wheel\",\"x\":0,\"y\":0,\"delta\":99999}", "{\"kind\":\"shell\"}" })
    Reject(() => InputCommand.Parse(Encoding.UTF8.GetBytes(bad)), "malformed/unsupported input rejected");

if (args.Length == 0)
{
    Console.WriteLine(JsonSerializer.Serialize(new { ok = true, checks, note = "Pass relay DLL path for integration checks." }, new JsonSerializerOptions { WriteIndented = true }));
    return;
}
string relay = Path.GetFullPath(args[0]);
using var listener = new TcpListener(IPAddress.Loopback, 0); listener.Start();
int port = ((IPEndPoint)listener.LocalEndpoint).Port; listener.Stop();
var server = new Uri($"http://127.0.0.1:{port}");
var processInfo = new ProcessStartInfo("dotnet") { UseShellExecute = false, CreateNoWindow = true, RedirectStandardError = true, RedirectStandardOutput = true, WorkingDirectory = Path.GetDirectoryName(relay)! };
processInfo.ArgumentList.Add(relay); processInfo.ArgumentList.Add("--urls"); processInfo.ArgumentList.Add(server.ToString());
processInfo.Environment["ASPNETCORE_ENVIRONMENT"] = "Production";
processInfo.Environment["ASPNETCORE_URLS"] = server.GetLeftPart(UriPartial.Authority);
processInfo.Environment["MINIREMOTE_PUBLIC_ORIGIN"] = server.GetLeftPart(UriPartial.Authority);
using var process = Process.Start(processInfo) ?? throw new Exception("Relay could not start.");
var processOutput = process.StandardOutput.ReadToEndAsync();
var processError = process.StandardError.ReadToEndAsync();
try
{
    using var http = new HttpClient { Timeout = TimeSpan.FromMilliseconds(300) };
    bool ready = false;
    for (int i = 0; i < 80 && !process.HasExited; i++)
    {
        try { if ((await http.GetAsync(new Uri(server, "/health"))).IsSuccessStatusCode) { ready = true; break; } } catch (HttpRequestException) { } catch (TaskCanceledException) { }
        await Task.Delay(100);
    }
    Check(ready, "production relay ready");

    async Task<(HostSession Host, Task Running, ClientWebSocket Viewer, Wire Cipher, FakeInput Sink, Func<int> Captures)> Connect(TaskCompletionSource<bool> approval)
    {
        var sink = new FakeInput(); int captures = 0;
        var host = await HostSession.ConnectAsync(server, sink, () => { Interlocked.Increment(ref captures); return [255, 216, 255, 217]; }, (_, ct) => approval.Task.WaitAsync(ct), _ => { });
        var run = host.RunAsync();
        var fragment = host.Invite[(host.Invite.IndexOf('#') + 1)..];
        var fields = fragment.Split('&').Select(x => x.Split('=', 2)).ToDictionary(x => x[0], x => x[1]);
        var key = Convert.FromBase64String(fields["key"].Replace('-', '+').Replace('_', '/') + "=");
        var cipher = new Wire(key, false);
        var viewer = new ClientWebSocket(); viewer.Options.SetRequestHeader("Origin", server.GetLeftPart(UriPartial.Authority));
        using var timeout = new CancellationTokenSource(5000);
        await viewer.ConnectAsync(new UriBuilder(server) { Scheme = "ws", Path = $"/ws/{fields["room"]}/viewer" }.Uri, timeout.Token);
        return (host, run, viewer, cipher, sink, () => Volatile.Read(ref captures));
    }
    async Task Send(ClientWebSocket socket, Wire cipher, MessageKind kind, string json = "")
    {
        using var timeout = new CancellationTokenSource(5000);
        await socket.SendAsync(new ArraySegment<byte>(cipher.Encode(kind, Encoding.UTF8.GetBytes(json))), WebSocketMessageType.Binary, true, timeout.Token);
    }
    async Task<(MessageKind Kind, byte[] Payload)> Receive(ClientWebSocket socket, Wire cipher)
    {
        using var timeout = new CancellationTokenSource(5000);
        using var output = new MemoryStream(); var buffer = new byte[32768];
        WebSocketReceiveResult result;
        do
        {
            result = await socket.ReceiveAsync(new ArraySegment<byte>(buffer), timeout.Token);
            if (result.MessageType == WebSocketMessageType.Close) throw new IOException("Unexpected close.");
            output.Write(buffer, 0, result.Count);
        } while (!result.EndOfMessage);
        return cipher.Decode(output.ToArray());
    }
    async Task<(MessageKind Kind, byte[] Payload)> Until(ClientWebSocket socket, Wire cipher, MessageKind wanted)
    {
        for (int i = 0; i < 30; i++) { var next = await Receive(socket, cipher); if (next.Kind == wanted) return next; }
        throw new Exception("Missing expected packet.");
    }
    var acceptance = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
    var accepted = await Connect(acceptance);
    await Send(accepted.Viewer, accepted.Cipher, MessageKind.Hello, "{\"name\":\"synthetic-viewer\"}");
    await Task.Delay(150);
    Check(accepted.Captures() == 0 && accepted.Sink.Commands.IsEmpty, "NO screen or input before local approval");
    acceptance.SetResult(true);
    var decision = await Until(accepted.Viewer, accepted.Cipher, MessageKind.Decision);
    Check(JsonDocument.Parse(decision.Payload).RootElement.GetProperty("accepted").GetBoolean(), "approval decision encrypted and received");
    var frame = await Until(accepted.Viewer, accepted.Cipher, MessageKind.Frame);
    Check(frame.Payload.SequenceEqual(new byte[] { 255, 216, 255, 217 }) && accepted.Captures() > 0, "synthetic frame after approval");
    await Send(accepted.Viewer, accepted.Cipher, MessageKind.Input, "{\"kind\":\"key\",\"code\":\"KeyA\",\"down\":true}");
    await Send(accepted.Viewer, accepted.Cipher, MessageKind.Input, "{\"kind\":\"move\",\"x\":0.25,\"y\":0.75}");
    for (int i = 0; i < 50 && accepted.Sink.Commands.Count < 2; i++) await Task.Delay(20);
    Check(accepted.Sink.Commands.Count == 2, "keyboard and normalized mouse delivered to MOCK sink");
    await Send(accepted.Viewer, accepted.Cipher, MessageKind.Input, "{\"kind\":\"release\"}");
    for (int i = 0; i < 50 && accepted.Sink.Commands.Count < 3; i++) await Task.Delay(20);
    Check(accepted.Sink.Pressed == 0, "viewer blur release clears mock input");
    await Send(accepted.Viewer, accepted.Cipher, MessageKind.Input, "{\"kind\":\"key\",\"code\":\"ControlLeft\",\"down\":true}");
    for (int i = 0; i < 50 && accepted.Sink.Pressed == 0; i++) await Task.Delay(20);
    accepted.Host.Stop();
    await accepted.Running.WaitAsync(TimeSpan.FromSeconds(5));
    Check(accepted.Sink.Pressed == 0 && accepted.Sink.Releases > 0, "host stop releases mock held keys");
    accepted.Viewer.Dispose(); accepted.Cipher.Dispose(); await accepted.Host.DisposeAsync();

    var denied = await Connect(new TaskCompletionSource<bool>());
    await Send(denied.Viewer, denied.Cipher, MessageKind.Hello, "{\"name\":\"unapproved-test\"}");
    await Send(denied.Viewer, denied.Cipher, MessageKind.Input, "{\"kind\":\"key\",\"code\":\"KeyA\",\"down\":true}");
    await denied.Running.WaitAsync(TimeSpan.FromSeconds(5));
    Check(denied.Captures() == 0 && denied.Sink.Commands.IsEmpty, "early input rejected and entire session terminated");
    denied.Viewer.Dispose(); denied.Cipher.Dispose(); await denied.Host.DisposeAsync();

    var rejectApproval = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
    var rejected = await Connect(rejectApproval);
    await Send(rejected.Viewer, rejected.Cipher, MessageKind.Hello, "{\"name\":\"rejection-test\"}");
    rejectApproval.SetResult(false);
    await rejected.Running.WaitAsync(TimeSpan.FromSeconds(5));
    Check(rejected.Captures() == 0 && rejected.Sink.Commands.IsEmpty, "local rejection produces zero captures/inputs");
    rejected.Viewer.Dispose(); rejected.Cipher.Dispose(); await rejected.Host.DisposeAsync();

    var waiting = await Connect(new TaskCompletionSource<bool>());
    await Send(waiting.Viewer, waiting.Cipher, MessageKind.Hello, "{\"name\":\"disconnect-test\"}");
    waiting.Viewer.Abort();
    await waiting.Running.WaitAsync(TimeSpan.FromSeconds(5));
    Check(waiting.Captures() == 0 && waiting.Sink.Releases > 0, "disconnect during approval cancels and releases safely");
    waiting.Viewer.Dispose(); waiting.Cipher.Dispose(); await waiting.Host.DisposeAsync();

    var pendingDispose = await Connect(new TaskCompletionSource<bool>());
    await Send(pendingDispose.Viewer, pendingDispose.Cipher, MessageKind.Hello, "{\"name\":\"dispose-test\"}");
    await pendingDispose.Host.DisposeAsync().AsTask().WaitAsync(TimeSpan.FromSeconds(5));
    await pendingDispose.Host.DisposeAsync();
    pendingDispose.Host.Stop();
    Check(pendingDispose.Running.IsCompleted && pendingDispose.Sink.Pressed == 0, "dispose during pending approval drains workers; repeated dispose/stop safe");
    pendingDispose.Viewer.Dispose(); pendingDispose.Cipher.Dispose();
}
finally
{
    if (!process.HasExited) process.Kill(true);
    await process.WaitForExitAsync();
    await processOutput; await processError;
}
Console.WriteLine(JsonSerializer.Serialize(new { ok = true, checks, note = "Only synthetic frames and mock inputs used. No real desktop captured or controlled." }, new JsonSerializerOptions { WriteIndented = true }));

sealed class FakeInput : IInputSink
{
    public ConcurrentQueue<InputCommand> Commands { get; } = new();
    public int Releases;
    public int Pressed;
    public void Apply(InputCommand command)
    {
        Commands.Enqueue(command);
        if (command.Kind == "release") ReleaseAll();
        else if (command.Kind == "key") Interlocked.Exchange(ref Pressed, command.Down ? 1 : 0);
    }
    public void ReleaseAll() { Interlocked.Increment(ref Releases); Interlocked.Exchange(ref Pressed, 0); }
}
