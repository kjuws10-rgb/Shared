// A synthetic encrypted host + an isolated headless Chromium profile.
// This test never captures the user's desktop or injects native PC input.
import assert from 'node:assert/strict';
import http from 'node:http';
import { createHash, randomBytes } from 'node:crypto';
import { readFile, writeFile, mkdir, mkdtemp, rm, access } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { Types, deriveKeys, encryptPacket, decryptPacket, jsonBytes, readJson } from '../../src/MiniRemote.Relay/wwwroot/protocol.mjs';

const directory = path.dirname(fileURLToPath(import.meta.url));
const staticDirectory = path.resolve(directory, '../../src/MiniRemote.Relay/wwwroot');
const artifacts = path.join(directory, 'artifacts');
await mkdir(artifacts, { recursive: true });
const master = randomBytes(32);
const keys = await deriveKeys(master);
const peers = [];
const faults = [];
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
async function until(check, label, timeout = 10_000) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    const result = await check();
    if (result) return result;
    await sleep(25);
  }
  throw new Error(`Timed out: ${label}`);
}
function wsFrame(opcode, payload) {
  payload = Buffer.from(payload);
  const header = Buffer.alloc(payload.length < 126 ? 2 : payload.length < 65536 ? 4 : 10);
  header[0] = 0x80 | opcode;
  if (header.length === 2) header[1] = payload.length;
  else if (header.length === 4) { header[1] = 126; header.writeUInt16BE(payload.length, 2); }
  else { header[1] = 127; header.writeBigUInt64BE(BigInt(payload.length), 2); }
  return Buffer.concat([header, payload]);
}

class MockHost {
  constructor(socket) {
    this.socket = socket;
    this.buffer = Buffer.alloc(0);
    this.received = [];
    this.sendSequence = 0n;
    this.receiveSequence = 0n;
    this.tail = Promise.resolve();
    this.sendTail = Promise.resolve();
    this.closed = false;
    socket.on('error', error => faults.push(error.message));
    socket.on('close', () => { this.closed = true; });
    socket.on('data', chunk => this.data(chunk));
  }
  data(chunk) {
    this.buffer = Buffer.concat([this.buffer, chunk]);
    while (this.buffer.length >= 2) {
      const opcode = this.buffer[0] & 15;
      const masked = Boolean(this.buffer[1] & 128);
      let length = this.buffer[1] & 127;
      let offset = 2;
      if (length === 126) { if (this.buffer.length < 4) return; length = this.buffer.readUInt16BE(2); offset = 4; }
      else if (length === 127) { if (this.buffer.length < 10) return; length = Number(this.buffer.readBigUInt64BE(2)); offset = 10; }
      if (!masked || length > 8192) { this.socket.destroy(); throw new Error('Malformed mock client frame'); }
      if (this.buffer.length < offset + 4 + length) return;
      const mask = this.buffer.subarray(offset, offset + 4);
      offset += 4;
      const data = Buffer.from(this.buffer.subarray(offset, offset + length));
      for (let i = 0; i < data.length; i++) data[i] ^= mask[i % 4];
      this.buffer = this.buffer.subarray(offset + length);
      if (opcode === 8) { this.socket.end(wsFrame(8, data)); continue; }
      if (opcode === 9) { this.socket.write(wsFrame(10, data)); continue; }
      assert.equal(opcode, 2);
      this.tail = this.tail.then(async () => {
        const packet = await decryptPacket(keys.send, data, this.receiveSequence++);
        this.received.push({ type: packet.type, value: packet.type === Types.heartbeat ? null : readJson(packet.payload) });
      }).catch(error => { faults.push(error.message); this.socket.destroy(); });
    }
  }
  send(type, payload = new Uint8Array()) {
    this.sendTail = this.sendTail.then(async () => {
      const wire = await encryptPacket(keys.receive, this.sendSequence++, type, payload);
      this.socket.write(wsFrame(2, wire));
    });
    return this.sendTail;
  }
  inputs() { return this.received.filter(packet => packet.type === Types.input).map(packet => packet.value); }
}

const mime = { '.html': 'text/html', '.css': 'text/css', '.mjs': 'text/javascript' };
const server = http.createServer(async (request, response) => {
  const name = request.url === '/' ? 'index.html' : request.url.slice(1);
  if (!['index.html', 'style.css', 'app.mjs', 'protocol.mjs'].includes(name)) { response.writeHead(404).end(); return; }
  try { response.writeHead(200, { 'content-type': mime[path.extname(name)], 'cache-control': 'no-store' }).end(await readFile(path.join(staticDirectory, name))); }
  catch { response.writeHead(500).end(); }
});
server.on('upgrade', (request, socket, head) => {
  if (!/^\/ws\/[A-Za-z0-9_-]{22}\/viewer$/.test(request.url)) { socket.destroy(); return; }
  const accept = createHash('sha1').update(request.headers['sec-websocket-key'] + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
  socket.write(`HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ${accept}\r\n\r\n`);
  const peer = new MockHost(socket);
  peers.push(peer);
  if (head.length) peer.data(head);
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const origin = `http://127.0.0.1:${server.address().port}`;
const newInvite = () => `${origin}/#room=${randomBytes(16).toString('base64url')}&key=${master.toString('base64url')}`;
const candidates = [process.env.MINIREMOTE_TEST_CHROME, 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe'].filter(Boolean);
let executable;
for (const candidate of candidates) { try { await access(candidate); executable = candidate; break; } catch {} }
if (!executable) throw new Error('Set MINIREMOTE_TEST_CHROME to a Chromium executable.');
const profile = await mkdtemp(path.join(artifacts, 'profile-'));
const browser = spawn(executable, ['--headless=new', '--remote-debugging-port=0', `--user-data-dir=${profile}`, '--no-first-run', '--no-default-browser-check', '--disable-background-networking', '--disable-sync', '--no-proxy-server', '--window-size=1280,1000', 'about:blank'], { windowsHide: true, stdio: 'ignore' });
let cdp;
const report = [];
try {
  const activePort = await until(async () => { try { return (await readFile(path.join(profile, 'DevToolsActivePort'), 'utf8')).split('\n')[0]; } catch { return null; } }, 'headless browser port');
  const targets = await (await fetch(`http://127.0.0.1:${activePort}/json/list`)).json();
  cdp = new WebSocket(targets.find(target => target.type === 'page').webSocketDebuggerUrl);
  await new Promise((resolve, reject) => { cdp.addEventListener('open', resolve, { once: true }); cdp.addEventListener('error', reject, { once: true }); });
  let messageId = 0;
  const calls = new Map();
  cdp.addEventListener('message', event => {
    const data = JSON.parse(event.data);
    if (data.id) {
      const pending = calls.get(data.id);
      calls.delete(data.id);
      if (data.error) pending.reject(new Error(JSON.stringify(data.error))); else pending.resolve(data.result);
    } else if (data.method === 'Runtime.exceptionThrown') faults.push(data.params.exceptionDetails.text);
  });
  const command = (method, params = {}) => new Promise((resolve, reject) => {
    const id = ++messageId;
    calls.set(id, { resolve, reject });
    cdp.send(JSON.stringify({ id, method, params }));
  });
  const evaluate = async expression => {
    const result = await command('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
    if (result.exceptionDetails) throw new Error(result.exceptionDetails.text);
    return result.result.value;
  };
  await command('Page.enable');
  await command('Runtime.enable');
  await command('Page.navigate', { url: newInvite() });
  await until(() => evaluate('Boolean(document.getElementById("connect") && !document.getElementById("connect").disabled)'), 'invitation loaded');
  assert.equal(await evaluate('location.hash'), '');
  assert.equal(await evaluate('document.getElementById("invite").value'), '');
  report.push('초대 fragment 및 입력칸에서 암호키 제거');

  const jpeg = Buffer.from(await evaluate('(()=>{ const c=document.createElement("canvas"); c.width=320;c.height=180; const x=c.getContext("2d"); x.fillStyle="#2468ac";x.fillRect(0,0,320,180);return c.toDataURL("image/jpeg",0.8).split(",")[1]; })()'), 'base64');
  await evaluate('document.getElementById("connect").click()');
  const first = await until(() => peers[0]?.received[0] && peers[0], 'encrypted hello');
  assert.deepEqual(first.received[0], { type: Types.hello, value: { name: '원격 사용자' } });
  await evaluate('document.getElementById("screen").focus();document.dispatchEvent(new KeyboardEvent("keydown",{code:"KeyA",bubbles:true,cancelable:true}))');
  await sleep(75);
  assert.equal(first.inputs().length, 0);
  assert.equal(await evaluate('document.getElementById("screen").dataset.ready'), 'false');
  await first.send(Types.heartbeat);
  await first.send(Types.decision, jsonBytes({ accepted: true, message: 'approved by synthetic host' }));
  await first.send(Types.frame, jpeg);
  await until(() => evaluate('document.getElementById("screen").dataset.ready === "true"'), 'approved JPEG render');
  const pixel = await evaluate('Array.from(document.getElementById("screen").getContext("2d").getImageData(160,90,1,1).data)');
  assert.ok(Math.abs(pixel[0] - 36) <= 3 && Math.abs(pixel[1] - 104) <= 3 && Math.abs(pixel[2] - 172) <= 3);
  report.push('승인 전 입력 차단, 암호화 Hello/Decision/Heartbeat 및 합성 JPEG 렌더링');

  const center = await evaluate('(()=>{const r=document.getElementById("screen").getBoundingClientRect();return {x:r.left+r.width/2,y:r.top+r.height/2};})()');
  async function clickScreen() {
    await command('Input.dispatchMouseEvent', { type: 'mousePressed', ...center, button: 'left', clickCount: 1 });
    await command('Input.dispatchMouseEvent', { type: 'mouseReleased', ...center, button: 'left', clickCount: 1 });
  }
  async function key(type, code, keyName = code) {
    await command('Input.dispatchKeyEvent', { type, code, key: keyName });
  }
  await clickScreen();
  await key('keyDown', 'ControlLeft', 'Control');
  await clickScreen();
  await clickScreen();
  await key('keyDown', 'KeyA', 'a');
  await key('keyUp', 'KeyA', 'a');
  await evaluate('document.dispatchEvent(new KeyboardEvent("keydown",{code:"Lang1",bubbles:true,cancelable:true}));document.dispatchEvent(new KeyboardEvent("keyup",{code:"Lang1",bubbles:true,cancelable:true}));');
  await key('keyUp', 'ControlLeft', 'Control');
  await command('Input.dispatchMouseEvent', { type: 'mouseWheel', ...center, deltaY: 100, deltaX: 0 });
  await until(() => first.inputs().some(value => value.kind === 'wheel'), 'encrypted browser inputs');
  const input = first.inputs();
  for (const code of ['KeyA', 'Lang1']) {
    assert.ok(input.some(value => value.kind === 'key' && value.code === code && value.down));
    assert.ok(input.some(value => value.kind === 'key' && value.code === code && !value.down));
  }
  const buttonDown = input.find(value => value.kind === 'button' && value.down);
  assert.ok(Math.abs(buttonDown.x - 0.5) < 0.01 && Math.abs(buttonDown.y - 0.5) < 0.01);
  assert.ok(input.some(value => value.kind === 'button' && !value.down));
  assert.ok(!input.some(value => value.kind === 'release'), 'normal pointerup must preserve held modifiers');
  let controlHeld = false;
  let modifierClicks = 0;
  for (const value of input) {
    if (value.kind === 'key' && value.code === 'ControlLeft') controlHeld = value.down;
    if (value.kind === 'button' && value.down && controlHeld) modifierClicks++;
  }
  assert.equal(modifierClicks, 2, 'Control remains held across two separate clicks');
  assert.equal(controlHeld, false, 'explicit Control key-up releases it');
  assert.equal(input.find(value => value.kind === 'wheel').delta, -120);
  report.push('포인터 실제 브라우저 이벤트, 중앙 좌표, 버튼 순서, KeyA/Lang1 키 및 휠');
  report.push('Ctrl 누른 채 연속 두 번 클릭: 정상 pointerup에서 modifier 유지, 명시적 keyup만 해제');
  const image = await command('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false });
  await writeFile(path.join(artifacts, 'viewer-approved.png'), Buffer.from(image.data, 'base64'));

  let releases = first.inputs().filter(value => value.kind === 'release').length;
  await evaluate('document.getElementById("screen").addEventListener("pointerdown",e=>{window.testPointerId=e.pointerId},{once:true})');
  await command('Input.dispatchMouseEvent', { type: 'mousePressed', ...center, button: 'left', clickCount: 1 });
  await evaluate('document.getElementById("screen").releasePointerCapture(window.testPointerId)');
  await command('Input.dispatchMouseEvent', { type: 'mouseMoved', x: center.x + 2, y: center.y });
  await until(() => first.inputs().filter(value => value.kind === 'release').length > releases, 'unexpected capture loss release');
  await command('Input.dispatchMouseEvent', { type: 'mouseReleased', ...center, button: 'left', clickCount: 1 });
  report.push('버튼이 눌린 상태의 예기치 않은 capture 손실은 모든 입력 release');

  releases = first.inputs().filter(value => value.kind === 'release').length;
  await key('keyDown', 'ShiftLeft', 'Shift');
  await key('keyDown', 'Escape', 'Escape');
  await until(() => first.inputs().filter(value => value.kind === 'release').length > releases, 'Escape release');
  assert.equal(await evaluate('document.getElementById("control-state").dataset.active'), 'false');
  assert.ok(!first.inputs().some(value => value.code === 'Escape'));
  const countPaused = first.inputs().length;
  await key('keyDown', 'KeyB', 'b');
  await key('keyUp', 'KeyB', 'b');
  await sleep(75);
  assert.equal(first.inputs().length, countPaused);
  await clickScreen();
  releases = first.inputs().filter(value => value.kind === 'release').length;
  await evaluate('window.dispatchEvent(new Event("blur"))');
  await until(() => first.inputs().filter(value => value.kind === 'release').length > releases, 'window blur release');
  await clickScreen();
  releases = first.inputs().filter(value => value.kind === 'release').length;
  await evaluate('Object.defineProperty(document,"hidden",{configurable:true,value:true});document.dispatchEvent(new Event("visibilitychange"));delete document.hidden;');
  await until(() => first.inputs().filter(value => value.kind === 'release').length > releases, 'hidden release');
  report.push('Esc 로컬 유지 및 일시정지, blur/hidden release, 일시정지 중 키 입력 차단');
  await evaluate('document.getElementById("stop").click()');
  await until(() => first.closed, 'stop closes session');
  await first.tail;
  assert.equal(first.received.at(-1).type, Types.end);
  assert.deepEqual(first.received.at(-2), { type: Types.input, value: { kind: 'release' } });
  report.push('중단 시 release → End 순서 및 소켓 종료');

  async function reconnect() {
    const index = peers.length;
    await evaluate(`document.getElementById("invite").value=${JSON.stringify(newInvite())};document.getElementById("import").click();document.getElementById("connect").click();`);
    return until(() => peers[index]?.received[0] && peers[index], 'fresh single-use invite');
  }
  const rejected = await reconnect();
  await rejected.send(Types.decision, jsonBytes({ accepted: false, message: '합성 호스트 거절' }));
  await until(() => rejected.closed, 'rejected connection closes');
  assert.equal(await evaluate('document.getElementById("message").textContent'), '합성 호스트 거절');
  assert.equal(rejected.inputs().length, 0);
  report.push('수동 초대 읽기 및 승인 거절 종료');

  const invalidSequence = await reconnect();
  invalidSequence.sendSequence = 1n;
  await invalidSequence.send(Types.decision, jsonBytes({ accepted: true }));
  await until(() => invalidSequence.closed, 'invalid sequence closes');
  assert.ok((await evaluate('document.getElementById("message").textContent')).includes('순서 검증'));
  const invalidTag = await reconnect();
  const corrupt = await encryptPacket(keys.receive, 0n, Types.decision, jsonBytes({ accepted: true }));
  corrupt[corrupt.length - 1] ^= 1;
  invalidTag.socket.write(wsFrame(2, corrupt));
  await until(() => invalidTag.closed, 'invalid authentication closes');
  report.push('수신 순서 불일치 및 AES-GCM tag 변조 즉시 종료');

  const silent = await reconnect();
  await until(() => silent.closed, '12-second authenticated-message timeout', 15_000);
  assert.ok((await evaluate('document.getElementById("message").textContent')).includes('12초'));
  assert.ok(silent.received.some(packet => packet.type === Types.heartbeat));
  report.push('2초 송신 heartbeat, 12초 인증 응답 timeout');
  assert.deepEqual(faults, []);
  await writeFile(path.join(artifacts, 'browser-report.json'), JSON.stringify({ passed: report, mockOnly: true, nativeInputInjection: false, userDesktopCapture: false }, null, 2));
  console.log(report.map(value => `PASS ${value}`).join('\n'));
  await command('Browser.close').catch(() => {});
} finally {
  cdp?.close();
  for (const peer of peers) peer.socket.destroy();
  server.closeAllConnections();
  await new Promise(resolve => server.close(resolve));
  browser.kill();
  await until(() => browser.exitCode !== null || browser.signalCode !== null, 'headless browser exit', 5_000).catch(() => {});
  // Only delete this test's verified direct-child temporary browser profile.
  if (path.dirname(path.resolve(profile)) === path.resolve(artifacts) && path.basename(profile).startsWith('profile-')) {
    await rm(profile, { recursive: true, force: true, maxRetries: 10, retryDelay: 200 });
  }
  master.fill(0);
}
