import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash, createDecipheriv, randomBytes, webcrypto } from 'node:crypto';
import { Types, MAX_HOST_PACKET, PacketSender, deriveKeys, encryptPacket, decryptPacket, jsonBytes, readJson, parseInvite, normalizedPoint, jpegDimensions, SUPPORTED_CODES } from '../../src/MiniRemote.Relay/wwwroot/protocol.mjs';

const master = Uint8Array.from({ length: 32 }, (_, i) => i);
const keys = await deriveKeys(master);
const invite = `https://relay.example/#room=${Buffer.alloc(16, 1).toString('base64url')}&key=${Buffer.from(master).toString('base64url')}`;

test('invite has an origin-bound, canonical 32-byte secret', () => {
  const parsed = parseInvite(invite, 'https://relay.example');
  assert.deepEqual(parsed.master, master);
  assert.equal(parsed.room.length, 22);
});
for (const [label, value] of [
  ['other origin', invite.replace('relay.example', 'other.example')],
  ['username', invite.replace('https://', 'https://user@')],
  ['path', invite.replace('/#', '/path#')],
  ['query', invite.replace('/#', '/?x=1#')],
  ['extra field', invite + '&extra=1'],
  ['duplicate key', invite + '&key=bad'],
  ['bad room', invite.replace('room=', 'room=+')],
  ['short secret', invite.slice(0, -1)],
  ['noncanonical secret', invite.slice(0, -1) + '9'],
]) test(`invite rejects ${label}`, () => assert.throws(() => parseInvite(value, 'https://relay.example')));

test('viewer directional key and AES-GCM wire match independent Node crypto', async () => {
  const sequence = 0x0102030405060708n;
  const payload = jsonBytes({ kind: 'key', code: 'Lang1', down: true });
  const wire = await encryptPacket(keys.send, sequence, Types.input, payload);
  const key = createHash('sha256').update(master).update('MiniRemote/viewer/v1').digest();
  const decipher = createDecipheriv('aes-256-gcm', key, wire.subarray(0, 12));
  decipher.setAuthTag(wire.subarray(-16));
  const plain = Buffer.concat([decipher.update(wire.subarray(12, -16)), decipher.final()]);
  assert.equal(plain[0], Types.input);
  assert.equal(plain.readBigUInt64BE(1), sequence);
  assert.deepEqual(new Uint8Array(plain.subarray(9)), payload);
});

test('host key decrypts only the correct direction and exact next sequence', async () => {
  const wire = await encryptPacket(keys.receive, 0n, Types.decision, jsonBytes({ accepted: true }));
  const result = await decryptPacket(keys.receive, wire, 0n);
  assert.equal(result.type, Types.decision);
  assert.deepEqual(readJson(result.payload), { accepted: true });
  await assert.rejects(decryptPacket(keys.send, wire, 0n));
  await assert.rejects(decryptPacket(keys.receive, wire, 1n));
});

test('tampered nonce, ciphertext and tag all fail authentication', async () => {
  const original = await encryptPacket(keys.receive, 0n, Types.heartbeat);
  for (const offset of [0, 12, original.length - 1]) {
    const wire = original.slice();
    wire[offset] ^= 1;
    await assert.rejects(decryptPacket(keys.receive, wire, 0n));
  }
});

test('each packet has a fresh nonce', async () => {
  const nonces = new Set();
  for (let i = 0; i < 50; i++) nonces.add(Buffer.from((await encryptPacket(keys.send, BigInt(i), Types.heartbeat)).subarray(0, 12)).toString('hex'));
  assert.equal(nonces.size, 50);
});

test('packet lengths and sequence overflow are bounded', async () => {
  await assert.rejects(decryptPacket(keys.receive, new Uint8Array(36), 0n));
  await assert.rejects(decryptPacket(keys.receive, new Uint8Array(MAX_HOST_PACKET + 1), 0n));
  await assert.rejects(encryptPacket(keys.send, 1n << 64n, Types.heartbeat));
});

test('sender serializes encryption and preserves key-down/up/release sequence', async () => {
  let active = 0;
  let maximumActive = 0;
  const cryptoApi = {
    getRandomValues: bytes => webcrypto.getRandomValues(bytes),
    subtle: {
      encrypt: async (...args) => {
        active++;
        maximumActive = Math.max(maximumActive, active);
        await new Promise(resolve => setTimeout(resolve, 3));
        const value = await webcrypto.subtle.encrypt(...args);
        active--;
        return value;
      },
    },
  };
  const wires = [];
  const transport = { readyState: 1, bufferedAmount: 0, send: wire => wires.push(wire) };
  const sender = new PacketSender(keys.send, transport, { cryptoApi });
  const commands = [ { kind: 'key', code: 'KeyA', down: true }, { kind: 'key', code: 'KeyA', down: false }, { kind: 'release' } ];
  await Promise.all(commands.map(command => sender.enqueue(Types.input, jsonBytes(command))));
  assert.equal(maximumActive, 1);
  for (let i = 0; i < wires.length; i++) assert.deepEqual(readJson((await decryptPacket(keys.send, wires[i], BigInt(i))).payload), commands[i]);
  assert.equal(sender.count, 0);
  assert.equal(sender.bytes, 0);
});

test('queue overflow terminates the session rather than silently losing release', async () => {
  let fatalCount = 0;
  const wires = [];
  const sender = new PacketSender(keys.send, { readyState: 1, bufferedAmount: 0, send: wire => wires.push(wire) }, { limitCount: 1, onFatal: () => fatalCount++ });
  const first = sender.enqueue(Types.input, jsonBytes({ kind: 'key', code: 'KeyA', down: true }));
  const release = sender.enqueue(Types.input, jsonBytes({ kind: 'release' }));
  await assert.rejects(release);
  await assert.rejects(first);
  assert.equal(fatalCount, 1);
  assert.equal(sender.closed, true);
  assert.equal(wires.length, 0);
});

test('browser transport backpressure terminates before sending', async () => {
  let fatalCount = 0;
  const sender = new PacketSender(keys.send, { readyState: 1, bufferedAmount: 32769, send: () => assert.fail('must not send') }, { onFatal: () => fatalCount++ });
  await assert.rejects(sender.enqueue(Types.heartbeat));
  assert.equal(fatalCount, 1);
});

test('viewer packet limit applies before encryption', async () => {
  const sender = new PacketSender(keys.send, { readyState: 1, bufferedAmount: 0, send() {} });
  await assert.rejects(sender.enqueue(Types.input, randomBytes(8192)));
  assert.equal(sender.closed, true);
});

test('letterboxed coordinates ignore bars and clamp captured drags', () => {
  const rect = { left: 10, top: 20, width: 1000, height: 1000 };
  assert.deepEqual(normalizedPoint(510, 520, rect, 1280, 720), { x: 0.5, y: 0.5 });
  assert.equal(normalizedPoint(510, 40, rect, 1280, 720), null);
  assert.deepEqual(normalizedPoint(510, 40, rect, 1280, 720, true), { x: 0.5, y: 0 });
  assert.deepEqual(normalizedPoint(-100, 520, rect, 1280, 720, true), { x: 0, y: 0.5 });
  assert.equal(normalizedPoint(1, 1, { left: 0, top: 0, width: 0, height: 0 }, 1280, 720), null);
});

test('portrait letterboxing normalizes against the image, not its element', () => {
  const rect = { left: 0, top: 0, width: 1000, height: 500 };
  assert.equal(normalizedPoint(10, 250, rect, 400, 800), null);
  assert.deepEqual(normalizedPoint(500, 250, rect, 400, 800), { x: 0.5, y: 0.5 });
});

function jpegHeader(width, height) {
  return Uint8Array.of(0xff, 0xd8, 0xff, 0xe0, 0, 2, 0xff, 0xc0, 0, 8, 8, height >> 8, height & 255, width >> 8, width & 255, 1, 0xff, 0xd9);
}
test('JPEG dimensions are checked before image decoding', () => {
  assert.deepEqual(jpegDimensions(jpegHeader(1280, 720)), { width: 1280, height: 720 });
  assert.throws(() => jpegDimensions(jpegHeader(1281, 720)));
  assert.throws(() => jpegDimensions(jpegHeader(1280, 901)));
  assert.throws(() => jpegDimensions(jpegHeader(0, 720)));
  assert.throws(() => jpegDimensions(Uint8Array.of(1, 2, 3, 4)));
  assert.throws(() => jpegDimensions(jpegHeader(1280, 720).subarray(0, 10)));
});

test('JSON rejects non-object and malformed UTF-8', () => {
  assert.throws(() => readJson(jsonBytes(null)));
  assert.throws(() => readJson(jsonBytes([])));
  assert.throws(() => readJson(Uint8Array.of(0xff)));
});

test('Korean physical language keys are supported and Escape/Windows stay local', () => {
  for (const key of ['Lang1', 'Lang2', 'KanaMode', 'KeyA', 'NumpadEnter']) assert.equal(SUPPORTED_CODES.has(key), true);
  for (const key of ['Escape', 'MetaLeft', 'MetaRight', 'Unidentified']) assert.equal(SUPPORTED_CODES.has(key), false);
});
