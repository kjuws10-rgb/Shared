// Synthetic fixed master only; never writes keys, ciphertext, or invite URLs.
import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { mkdir, writeFile } from 'node:fs/promises';
import { Types, deriveKeys, decryptPacket, encryptPacket, jsonBytes, readJson } from '../../src/MiniRemote.Relay/wwwroot/protocol.mjs';

const run = promisify(execFile);
const directory = path.dirname(fileURLToPath(import.meta.url));
const core = path.resolve(directory, '../CoreSmoke/bin/Release/net10.0/CoreSmoke.dll');
const { stdout } = await run('dotnet', [core, '--wire-vector'], { windowsHide: true });
const vector = JSON.parse(stdout.trim());
const master = new Uint8Array(Buffer.from(vector.key, 'base64'));
assert.deepEqual(master, Uint8Array.from({ length: 32 }, (_, index) => index));
const keys = await deriveKeys(master);
master.fill(0);
const packet = await decryptPacket(keys.receive, Buffer.from(vector.packet, 'base64'), 0n);
assert.equal(packet.type, Types.decision);
assert.deepEqual(readJson(packet.payload), { accepted: true });

const wire = await encryptPacket(keys.send, 0n, Types.hello, jsonBytes({ name: 'browser-test' }));
const result = await run('dotnet', [core, '--decode-viewer', Buffer.from(wire).toString('base64')], { windowsHide: true });
assert.match(result.stdout, /PASS JS->C# cross-runtime packet/);
const checks = [
  '.NET host Decision seq0 → JavaScript viewer authenticated decrypt',
  'JavaScript viewer Hello seq0 → .NET host authenticated decrypt',
];
const artifacts = path.join(directory, 'artifacts');
await mkdir(artifacts, { recursive: true });
await writeFile(path.join(artifacts, 'cross-runtime-report.json'), JSON.stringify({ passed: checks, fixedSyntheticMaster: true, keysOrPacketsPersisted: false }, null, 2));
console.log(checks.map(check => `PASS ${check}`).join('\n'));
