using System.Reflection;
using System.Runtime.InteropServices;
using System.Text.Json;

static class Program
{
    [STAThread]
    static int Main(string[] args)
    {
        ApplicationConfiguration.Initialize();
        var assembly = Assembly.Load("MiniRemote");
        var mainType = assembly.GetType("MiniRemote.Host.MainForm", true)!;
        using var main = (Form)Activator.CreateInstance(mainType, ["https://approved-relay.example"])!;
        // Render our own controls without showing a window or capturing the desktop.
        using var layout = main.Controls[0];
        main.Controls.Remove(layout);
        layout.Dock = DockStyle.None;
        layout.Size = main.ClientSize;
        layout.Location = Point.Empty;
        layout.Visible = true;
        layout.CreateControl(); layout.PerformLayout();
        using var bitmap = new Bitmap(layout.Width, layout.Height);
        layout.DrawToBitmap(bitmap, new Rectangle(Point.Empty, layout.Size));
        string output = Path.GetFullPath(args.FirstOrDefault() ?? "artifacts/host-preview.png");
        Directory.CreateDirectory(Path.GetDirectoryName(output)!);
        bitmap.Save(output);
        var inputType = assembly.GetType("MiniRemote.Host.WindowsInput+INPUT", true)!;
        int size = Marshal.SizeOf(inputType);
        if (size != (IntPtr.Size == 8 ? 40 : 28)) throw new Exception("Invalid native INPUT layout.");
        var stop = (Button)mainType.GetField("stop", BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(main)!;
        var copy = (Button)mainType.GetField("copy", BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(main)!;
        if (stop.Enabled || copy.Enabled) throw new Exception("Invalid initial controls.");
        Console.WriteLine(JsonSerializer.Serialize(new { ok = true, nativeInputSize = size, preview = output, actualDesktopCapture = false, actualInputInjection = false, connectionStarted = false }));
        return 0;
    }
}
