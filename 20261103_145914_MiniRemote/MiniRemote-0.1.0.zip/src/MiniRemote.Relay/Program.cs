using System.Diagnostics;
using System.Net;
using System.Net.WebSockets;
using System.Text.RegularExpressions;

var builder = WebApplication.CreateBuilder(args);
// Framework request logs can include the secret room in the request path.
builder.Logging.ClearProviders();
if (string.IsNullOrWhiteSpace(builder.Configuration["urls"]))
    builder.WebHost.UseUrls("http://127.0.0.1:8787");
builder.WebHost.ConfigureKestrel(options =>
{
    options.AddServerHeader = false;
    options.Limits.MaxRequestBodySize = 0;
    options.Limits.MaxConcurrentConnections = 256;
    options.Limits.MaxConcurrentUpgradedConnections = 128;
    options.Limits.RequestHeadersTimeout = TimeSpan.FromSeconds(10);
});
var policy = OriginPolicy.FromEnvironment();
builder.Services.AddSingleton(policy);
builder.Services.AddSingleton<RoomRegistry>();
builder.Services.AddHostedService<RoomExpiry>();
var app = builder.Build();

app.Use(async (context, next) =>
{
    context.Response.Headers["Content-Security-Policy"] = "default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' blob:; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'";
    context.Response.Headers["X-Content-Type-Options"] = "nosniff";
    context.Response.Headers["Referrer-Policy"] = "no-referrer";
    context.Response.Headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=(), clipboard-read=(), clipboard-write=()";
    context.Response.Headers["Cache-Control"] = "no-store";
    context.Response.Headers["Cross-Origin-Opener-Policy"] = "same-origin";
    context.Response.Headers["Cross-Origin-Resource-Policy"] = "same-origin";
    if (policy.IsPublicHttps) context.Response.Headers["Strict-Transport-Security"] = "max-age=31536000";
    if (!policy.AcceptsHost(context.Request.Host))
    {
        context.Response.StatusCode = StatusCodes.Status400BadRequest;
        return;
    }
    try { await next(context); }
    catch (OperationCanceledException) when (context.RequestAborted.IsCancellationRequested) { }
    catch
    {
        // Never log paths, room IDs, keys, ciphertext or exception/request details.
        if (!context.Response.HasStarted) context.Response.StatusCode = StatusCodes.Status500InternalServerError;
        else context.Abort();
    }
});
app.UseWebSockets(new WebSocketOptions
{
    KeepAliveInterval = TimeSpan.FromSeconds(15),
    KeepAliveTimeout = TimeSpan.FromSeconds(15)
});
app.UseDefaultFiles();
app.UseStaticFiles();
app.MapGet("/health", () => Results.Text("ok", "text/plain"));
app.Map("/ws/{room}/{role}", async (HttpContext context, string room, string role, RoomRegistry registry) =>
{
    if (!Regex.IsMatch(room, "\\A[A-Za-z0-9_-]{22}\\z", RegexOptions.CultureInvariant) || role is not ("host" or "viewer") || context.Request.QueryString.HasValue)
    {
        context.Response.StatusCode = StatusCodes.Status400BadRequest;
        return;
    }
    if (context.Request.Method != "GET" || !context.WebSockets.IsWebSocketRequest)
    {
        context.Response.StatusCode = StatusCodes.Status400BadRequest;
        return;
    }
    var origins = context.Request.Headers.Origin;
    if (role == "viewer" ? origins.Count != 1 || !policy.AcceptsOrigin(origins[0]) : origins.Count != 0)
    {
        context.Response.StatusCode = StatusCodes.Status403Forbidden;
        return;
    }
    var ip = context.Connection.RemoteIpAddress?.MapToIPv6().ToString() ?? "unknown";
    var reservation = registry.Reserve(room, role, ip);
    if (reservation.Room is null || reservation.Peer is null)
    {
        context.Response.StatusCode = reservation.Status;
        return;
    }
    var session = reservation.Room;
    var peer = reservation.Peer;
    try
    {
        using var socket = await context.WebSockets.AcceptWebSocketAsync();
        if (!registry.Attach(session, peer, socket)) return;
        using var linked = CancellationTokenSource.CreateLinkedTokenSource(session.Closed.Token, context.RequestAborted);
        await Forward(session, peer, linked.Token);
    }
    catch (OperationCanceledException) { }
    catch (WebSocketException) { }
    catch (IOException) { }
    finally { await registry.End(session); }
});
await app.RunAsync();

static async Task Forward(Room room, Peer source, CancellationToken cancellation)
{
    var socket = source.Socket!;
    var buffer = new byte[16 * 1024];
    var maximum = source.Role == "host" ? 2 * 1024 * 1024 : 8192;
    var rateMaximum = source.Role == "host" ? 15 : 120;
    var rateStart = Stopwatch.GetTimestamp();
    var count = 0;
    while (!cancellation.IsCancellationRequested && socket.State == WebSocketState.Open)
    {
        using var message = new MemoryStream();
        ValueWebSocketReceiveResult result;
        do
        {
            result = await socket.ReceiveAsync(buffer.AsMemory(), cancellation);
            if (result.MessageType == WebSocketMessageType.Close) return;
            if (result.MessageType != WebSocketMessageType.Binary || message.Length + result.Count > maximum)
            {
                await source.Close(result.MessageType == WebSocketMessageType.Binary ? WebSocketCloseStatus.MessageTooBig : WebSocketCloseStatus.InvalidMessageType);
                return;
            }
            message.Write(buffer, 0, result.Count);
        } while (!result.EndOfMessage);
        if (Stopwatch.GetElapsedTime(rateStart) >= TimeSpan.FromSeconds(1))
        {
            count = 0;
            rateStart = Stopwatch.GetTimestamp();
        }
        if (++count > rateMaximum)
        {
            await source.Close(WebSocketCloseStatus.PolicyViolation);
            return;
        }
        // There is no queue or pre-join buffering. Each sender waits for TCP backpressure.
        var target = source.Role == "host" ? room.Viewer : room.Host;
        if (target?.Socket is not { State: WebSocketState.Open }) return;
        await target.Send(message.GetBuffer().AsMemory(0, checked((int)message.Length)), cancellation);
    }
}

internal sealed class OriginPolicy
{
    private readonly HashSet<string> origins;
    private readonly HashSet<string> hosts;
    public bool IsPublicHttps { get; }
    private OriginPolicy(IEnumerable<Uri> allowed)
    {
        var values = allowed.ToArray();
        origins = values.Select(uri => uri.GetLeftPart(UriPartial.Authority)).ToHashSet(StringComparer.Ordinal);
        hosts = values.Select(uri => uri.Authority).ToHashSet(StringComparer.OrdinalIgnoreCase);
        IsPublicHttps = values.Any(uri => uri.Scheme == "https");
    }
    public bool AcceptsOrigin(string? origin) => origin is not null && origins.Contains(origin);
    public bool AcceptsHost(HostString host) => host.Value is { } value && hosts.Contains(value);
    public static OriginPolicy FromEnvironment()
    {
        var configured = Environment.GetEnvironmentVariable("MINIREMOTE_PUBLIC_ORIGIN");
        if (string.IsNullOrWhiteSpace(configured))
            return new OriginPolicy([new Uri("http://127.0.0.1:8787"), new Uri("http://localhost:8787")]);
        if (!Uri.TryCreate(configured, UriKind.Absolute, out var uri) || uri.UserInfo.Length != 0 || uri.AbsolutePath != "/" || uri.Query.Length != 0 || uri.Fragment.Length != 0 || (uri.Scheme != "https" && !(uri.Scheme == "http" && uri.IsLoopback)))
            throw new InvalidOperationException("MINIREMOTE_PUBLIC_ORIGIN must be an HTTPS origin (HTTP loopback is allowed for tests).");
        return new OriginPolicy([uri]);
    }
}

internal sealed class Peer(string role, string ip)
{
    public string Role { get; } = role;
    public string Ip { get; } = ip;
    public WebSocket? Socket { get; set; }
    private readonly SemaphoreSlim sendLock = new(1, 1);
    public async Task Send(ReadOnlyMemory<byte> data, CancellationToken cancellation)
    {
        await sendLock.WaitAsync(cancellation);
        try
        {
            if (Socket is not { State: WebSocketState.Open } socket) throw new OperationCanceledException();
            await socket.SendAsync(data, WebSocketMessageType.Binary, true, cancellation);
        }
        finally { sendLock.Release(); }
    }
    public async Task Close(WebSocketCloseStatus status = WebSocketCloseStatus.NormalClosure)
    {
        var socket = Socket;
        if (socket is null) return;
        using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(1));
        var held = false;
        try
        {
            await sendLock.WaitAsync(timeout.Token);
            held = true;
            if (socket.State is WebSocketState.Open or WebSocketState.CloseReceived)
                await socket.CloseOutputAsync(status, "Session ended", timeout.Token);
        }
        catch (Exception error) when (error is OperationCanceledException or WebSocketException or ObjectDisposedException) { }
        finally
        {
            socket.Abort();
            if (held) sendLock.Release();
        }
    }
}

internal sealed class Room(string id, Peer host)
{
    public string Id { get; } = id;
    public Peer Host { get; } = host;
    public Peer? Viewer { get; set; }
    public long Created { get; } = Stopwatch.GetTimestamp();
    public CancellationTokenSource Closed { get; } = new();
    public bool Ended { get; set; }
}

internal sealed class RoomRegistry
{
    private readonly object gate = new();
    private readonly Dictionary<string, Room> rooms = new(StringComparer.Ordinal);
    // A bounded tombstone set prevents deliberate reuse of a recently closed invite.
    private readonly Dictionary<string, long> consumed = new(StringComparer.Ordinal);
    private readonly Dictionary<string, int> connections = new(StringComparer.Ordinal);
    private readonly Dictionary<string, (long Started, int Count)> attempts = new(StringComparer.Ordinal);
    private int total;
    public (Room? Room, Peer? Peer, int Status) Reserve(string id, string role, string ip)
    {
        lock (gate)
        {
            foreach (var expired in attempts.Where(pair => Stopwatch.GetElapsedTime(pair.Value.Started) > TimeSpan.FromMinutes(1)).Select(pair => pair.Key).ToArray()) attempts.Remove(expired);
            if (!attempts.TryGetValue(ip, out var window))
            {
                if (attempts.Count >= 1024) return (null, null, 429);
                window = (Stopwatch.GetTimestamp(), 0);
            }
            attempts[ip] = (window.Started, window.Count + 1);
            if (window.Count >= 30 || total >= 128 || connections.GetValueOrDefault(ip) >= 12) return (null, null, 429);
            var peer = new Peer(role, ip);
            Room room;
            if (role == "host")
            {
                foreach (var expired in consumed.Where(pair => Stopwatch.GetElapsedTime(pair.Value) > TimeSpan.FromHours(1)).Select(pair => pair.Key).ToArray()) consumed.Remove(expired);
                if (rooms.ContainsKey(id) || consumed.ContainsKey(id)) return (null, null, 409);
                if (consumed.Count + rooms.Count >= 4096) return (null, null, 429);
                if (rooms.Count >= 64) return (null, null, 429);
                room = new Room(id, peer);
                rooms.Add(id, room);
            }
            else
            {
                if (!rooms.TryGetValue(id, out room!)) return (null, null, 404);
                if (room.Viewer is not null || room.Host.Socket is not { State: WebSocketState.Open }) return (null, null, 409);
                room.Viewer = peer;
            }
            total++;
            connections[ip] = connections.GetValueOrDefault(ip) + 1;
            return (room, peer, 101);
        }
    }
    public bool Attach(Room room, Peer peer, WebSocket socket)
    {
        lock (gate)
        {
            if (room.Ended) { socket.Abort(); return false; }
            peer.Socket = socket;
            return true;
        }
    }
    public async Task End(Room room)
    {
        Peer[] peers;
        lock (gate)
        {
            if (room.Ended) return;
            room.Ended = true;
            rooms.Remove(room.Id);
            consumed[room.Id] = Stopwatch.GetTimestamp();
            peers = room.Viewer is null ? [room.Host] : [room.Host, room.Viewer];
            foreach (var peer in peers)
            {
                total--;
                if (--connections[peer.Ip] == 0) connections.Remove(peer.Ip);
            }
            room.Closed.Cancel();
        }
        await Task.WhenAll(peers.Select(peer => peer.Close()));
    }
    public Room[] Expired()
    {
        lock (gate)
            return rooms.Values.Where(room => Stopwatch.GetElapsedTime(room.Created) >= (room.Viewer is null ? TimeSpan.FromMinutes(5) : TimeSpan.FromHours(1))).ToArray();
    }
    public Room[] All() { lock (gate) return rooms.Values.ToArray(); }
}

internal sealed class RoomExpiry(RoomRegistry registry) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        using var timer = new PeriodicTimer(TimeSpan.FromSeconds(5));
        try
        {
            while (await timer.WaitForNextTickAsync(stoppingToken))
                await Task.WhenAll(registry.Expired().Select(registry.End));
        }
        catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested) { }
    }
    public override async Task StopAsync(CancellationToken cancellationToken)
    {
        await Task.WhenAll(registry.All().Select(registry.End));
        await base.StopAsync(cancellationToken);
    }
}
