using System.Drawing.Drawing2D;
using System.Drawing.Imaging;

namespace MiniRemote.Host;

internal static class DesktopCapture
{
    private static readonly ImageCodecInfo Jpeg = ImageCodecInfo.GetImageEncoders().First(x => x.FormatID == ImageFormat.Jpeg.Guid);
    public static byte[] Frame()
    {
        var bounds = Screen.PrimaryScreen?.Bounds ?? throw new InvalidOperationException("화면을 찾을 수 없습니다.");
        using var full = new Bitmap(bounds.Width, bounds.Height, PixelFormat.Format24bppRgb);
        using (var graphics = Graphics.FromImage(full))
            graphics.CopyFromScreen(bounds.Left, bounds.Top, 0, 0, bounds.Size, CopyPixelOperation.SourceCopy);
        double ratio = Math.Min(1, Math.Min(1280d / bounds.Width, 900d / bounds.Height));
        using var small = new Bitmap(Math.Max(1, (int)(bounds.Width * ratio)), Math.Max(1, (int)(bounds.Height * ratio)), PixelFormat.Format24bppRgb);
        using (var graphics = Graphics.FromImage(small))
        {
            graphics.InterpolationMode = InterpolationMode.Bilinear;
            graphics.DrawImage(full, new Rectangle(0, 0, small.Width, small.Height));
        }
        using var parameters = new EncoderParameters(1);
        parameters.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, 55L);
        using var output = new MemoryStream();
        small.Save(output, Jpeg, parameters);
        return output.ToArray();
    }
}
