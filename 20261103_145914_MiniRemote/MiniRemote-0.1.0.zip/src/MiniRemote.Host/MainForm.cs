using System.Runtime.InteropServices;
using MiniRemote.Core;

namespace MiniRemote.Host;

internal sealed class MainForm : Form
{
    private readonly TextBox server = new() { Dock = DockStyle.Fill, PlaceholderText = "https://회사에서-허용한-서버" };
    private readonly TextBox invite = new() { Dock = DockStyle.Fill, Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical };
    private readonly Label status = new() { Dock = DockStyle.Fill, Text = "서버 주소를 입력하고 초대 링크를 만드세요.", ForeColor = Color.FromArgb(25, 65, 95), AutoSize = false };
    private readonly Button start = new() { Text = "초대 링크 만들기", AutoSize = true };
    private readonly Button stop = new() { Text = "즉시 중단", AutoSize = true, Enabled = false, BackColor = Color.FromArgb(255, 231, 231) };
    private readonly Button copy = new() { Text = "링크 복사", AutoSize = true, Enabled = false };
    private readonly WindowsInput input = new();
    private CancellationTokenSource? connecting;
    private HostSession? session;
    private ApprovalForm? approvalForm;
    private bool closing;
    private bool hotkey;

    public MainForm(string? initialServer)
    {
        Text = "MiniRemote · 화면 / 키보드 / 마우스";
        Font = new Font("맑은 고딕", 10F);
        ClientSize = new Size(640, 438);
        MinimumSize = new Size(590, 470);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Color.White;
        server.Text = initialServer ?? "http://localhost:8787";
        var layout = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(22), ColumnCount = 1, RowCount = 8 };
        foreach (int height in new[] { 40, 29, 34, 47, 72, 45, 48, 50 }) layout.RowStyles.Add(new RowStyle(SizeType.Absolute, height));
        layout.Controls.Add(new Label { Text = "내 PC에 잠시 접속 허용", Font = new Font(Font, FontStyle.Bold), Dock = DockStyle.Fill }, 0, 0);
        layout.Controls.Add(new Label { Text = "1. 승인된 중계 서버 주소", Dock = DockStyle.Fill }, 0, 1);
        layout.Controls.Add(server, 0, 2);
        var controls = new FlowLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(0, 7, 0, 0) };
        controls.Controls.AddRange([start, stop, copy]);
        layout.Controls.Add(controls, 0, 3);
        layout.Controls.Add(invite, 0, 4);
        layout.Controls.Add(status, 0, 5);
        layout.Controls.Add(new Label { Text = "2. 링크를 상대방에게 전달 → 3. 이 PC에서 접속 승인\n링크를 아는 사람은 접속을 요청할 수 있습니다. 필요한 상대에게만 전달하세요.", Dock = DockStyle.Fill, ForeColor = Color.DimGray, Font = new Font(Font.FontFamily, 9F) }, 0, 6);
        layout.Controls.Add(new Label { Text = "주 모니터만 공유 · 1회용 링크 · 최대 1시간\n중단: Ctrl+Alt+F12  |  회사에서 허용한 네트워크에서 사용", Dock = DockStyle.Fill, ForeColor = Color.DimGray, Font = new Font(Font.FontFamily, 9F) }, 0, 7);
        Controls.Add(layout);
        start.Click += async (_, _) => await StartAsync();
        stop.Click += (_, _) => Stop();
        copy.Click += (_, _) => { try { Clipboard.SetText(invite.Text); } catch (ExternalException) { SetStatus("클립보드가 사용 중입니다. 링크를 직접 선택해 복사하세요."); } };
        FormClosing += (_, _) => { closing = true; Stop(); };
    }
    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);
        hotkey = RegisterHotKey(Handle, 1, 0x4003, (uint)Keys.F12);
        if (!hotkey) SetStatus("중단 단축키가 이미 사용 중입니다. 즉시 중단 버튼을 사용하세요.");
    }
    protected override void OnHandleDestroyed(EventArgs e)
    {
        if (hotkey) UnregisterHotKey(Handle, 1);
        base.OnHandleDestroyed(e);
    }
    protected override void WndProc(ref Message m)
    {
        if (m.Msg == 0x0312 && m.WParam == 1) Stop();
        base.WndProc(ref m);
    }
    private async Task StartAsync()
    {
        Uri uri;
        try { uri = RelayAddress.Parse(server.Text); }
        catch (ArgumentException ex) { SetStatus(ex.Message); return; }
        start.Enabled = false; stop.Enabled = true; server.Enabled = false; copy.Enabled = false; invite.Clear();
        connecting = new CancellationTokenSource();
        SetStatus("중계 서버에 연결 중…");
        HostSession? current = null;
        try
        {
            current = await HostSession.ConnectAsync(uri, input, DesktopCapture.Frame, AskApprovalAsync, SetStatus, connecting.Token);
            session = current;
            if (connecting.IsCancellationRequested || closing) { current.Stop(); return; }
            invite.Text = current.Invite; copy.Enabled = true;
            SetStatus("초대 링크를 전달하세요. 접속 요청은 이 PC에서 승인해야 합니다. (5분 대기)");
            await Task.Run(current.RunAsync);
        }
        catch (OperationCanceledException) { SetStatus("연결을 중단했습니다."); }
        catch { SetStatus("서버에 연결할 수 없습니다. 주소·서버 실행·회사 네트워크 허용을 확인하세요."); }
        finally
        {
            if (current != null) await current.DisposeAsync();
            session = null;
            connecting.Dispose(); connecting = null;
            if (!closing && !IsDisposed)
            {
                start.Enabled = true; stop.Enabled = false; server.Enabled = true; copy.Enabled = false; invite.Clear();
                approvalForm?.Close(); approvalForm = null;
            }
        }
    }
    private Task<bool> AskApprovalAsync(string name, CancellationToken cancellation)
    {
        var answer = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
        Ui(() =>
        {
            if (cancellation.IsCancellationRequested || closing) { answer.TrySetResult(false); return; }
            approvalForm = new ApprovalForm(name);
            var dialog = approvalForm;
            dialog.FormClosed += (_, _) => answer.TrySetResult(dialog.Accepted);
            dialog.Show(this);
            if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
            dialog.Activate();
            var registration = cancellation.Register(() => Ui(() => { answer.TrySetResult(false); if (!dialog.IsDisposed) dialog.Close(); }));
            _ = answer.Task.ContinueWith(_ => registration.Dispose(), TaskScheduler.Default);
        });
        return answer.Task;
    }
    private void Stop()
    {
        connecting?.Cancel();
        session?.Stop("사용자가 연결을 중단했습니다.");
        input.ReleaseAll();
        approvalForm?.Close();
    }
    private void SetStatus(string value) => Ui(() =>
    {
        status.Text = value;
        status.ForeColor = value.StartsWith('●') ? Color.FromArgb(175, 25, 25) : Color.FromArgb(25, 65, 95);
    });
    private void Ui(Action action)
    {
        if (closing || IsDisposed || !IsHandleCreated) return;
        if (InvokeRequired) { try { BeginInvoke(action); } catch (InvalidOperationException) { } }
        else action();
    }
    [DllImport("user32.dll", SetLastError = true)] private static extern bool RegisterHotKey(IntPtr window, int id, uint modifiers, uint key);
    [DllImport("user32.dll")] private static extern bool UnregisterHotKey(IntPtr window, int id);
}

internal sealed class ApprovalForm : Form
{
    public bool Accepted { get; private set; }
    private readonly System.Windows.Forms.Timer timer = new() { Interval = 1000 };
    public ApprovalForm(string name)
    {
        Text = "원격 접속을 허용할까요?";
        Font = new Font("맑은 고딕", 10F);
        ClientSize = new Size(470, 215); FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false; MinimizeBox = false; StartPosition = FormStartPosition.CenterParent; TopMost = true;
        var message = new Label { Text = $"요청자 표시: {name}\n(상대가 입력한 이름이며 신원 인증 정보가 아닙니다.)\n\n허용하면 주 모니터 화면·키보드·마우스를 공유합니다.", Location = new Point(20, 15), Size = new Size(430, 110) };
        var countdown = new Label { Location = new Point(20, 132), Size = new Size(425, 25), Text = "30초 뒤 자동 거절" };
        var allow = new Button { Text = "지금 허용", Location = new Point(226, 166), Size = new Size(105, 32) };
        var deny = new Button { Text = "거절", Location = new Point(342, 166), Size = new Size(105, 32) };
        allow.Click += (_, _) => { Accepted = true; Close(); };
        deny.Click += (_, _) => Close();
        CancelButton = deny;
        Controls.AddRange([message, countdown, allow, deny]);
        int seconds = 30;
        timer.Tick += (_, _) => { countdown.Text = $"{--seconds}초 뒤 자동 거절"; if (seconds <= 0) Close(); };
        Shown += (_, _) => { deny.Focus(); timer.Start(); };
        FormClosed += (_, _) => timer.Dispose();
    }
}
