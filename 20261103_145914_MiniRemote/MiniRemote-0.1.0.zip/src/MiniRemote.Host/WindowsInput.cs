using System.ComponentModel;
using System.Runtime.InteropServices;
using MiniRemote.Core;

namespace MiniRemote.Host;

internal sealed class WindowsInput : IInputSink
{
    private readonly object gate = new();
    private readonly HashSet<string> keys = [];
    private readonly HashSet<int> buttons = [];
    public void Apply(InputCommand command)
    {
        lock (gate)
        {
            if (command.Kind == "release") { ReleaseAll(); return; }
            if (command.Kind == "key")
            {
                if (!command.Down && !keys.Contains(command.Code)) return;
                if (command.Down) keys.Add(command.Code);
                Key(command.Code, command.Down);
                if (!command.Down) keys.Remove(command.Code);
                return;
            }
            Move(command.X, command.Y);
            if (command.Kind == "button")
            {
                if (!command.Down && !buttons.Contains(command.Button)) return;
                if (command.Down) buttons.Add(command.Button);
                Button(command.Button, command.Down);
                if (!command.Down) buttons.Remove(command.Button);
            }
            else if (command.Kind == "wheel") Mouse(0x0800, data: unchecked((uint)command.Delta));
        }
    }
    public void ReleaseAll()
    {
        lock (gate)
        {
            foreach (var code in keys.ToArray()) { try { Key(code, false); } catch (Win32Exception) { } }
            foreach (var button in buttons.ToArray()) { try { Button(button, false); } catch (Win32Exception) { } }
            keys.Clear(); buttons.Clear();
        }
    }
    private static void Move(double x, double y)
    {
        var screen = Screen.PrimaryScreen?.Bounds ?? throw new InvalidOperationException("No screen.");
        var desktop = SystemInformation.VirtualScreen;
        int nativeX = screen.Left + (int)Math.Round(x * (screen.Width - 1));
        int nativeY = screen.Top + (int)Math.Round(y * (screen.Height - 1));
        int absoluteX = (int)Math.Round((nativeX - desktop.Left) * 65535d / Math.Max(1, desktop.Width - 1));
        int absoluteY = (int)Math.Round((nativeY - desktop.Top) * 65535d / Math.Max(1, desktop.Height - 1));
        Mouse(0x0001 | 0x8000 | 0x4000, absoluteX, absoluteY);
    }
    private static void Key(string code, bool down)
    {
        if (!KeyCodes.TryGet(code, out ushort key)) throw new InvalidDataException("Unsupported key.");
        Send(new INPUT { type = 1, data = new UNION { keyboard = new KEYBDINPUT { virtualKey = key, flags = (down ? 0u : 2u) | (KeyCodes.IsExtended(code) ? 1u : 0u) } } });
    }
    private static void Button(int button, bool down) => Mouse(button switch
    { 0 => down ? 0x0002u : 0x0004u, 1 => down ? 0x0020u : 0x0040u, 2 => down ? 0x0008u : 0x0010u, _ => throw new InvalidDataException("Unknown button.") });
    private static void Mouse(uint flags, int x = 0, int y = 0, uint data = 0) => Send(new INPUT { type = 0, data = new UNION { mouse = new MOUSEINPUT { x = x, y = y, flags = flags, mouseData = data } } });
    private static void Send(INPUT value)
    {
        if (SendInput(1, [value], Marshal.SizeOf<INPUT>()) != 1) throw new Win32Exception(Marshal.GetLastWin32Error(), "Windows가 입력을 허용하지 않았습니다.");
    }
    [StructLayout(LayoutKind.Sequential)] private struct INPUT { public uint type; public UNION data; }
    [StructLayout(LayoutKind.Explicit)] private struct UNION { [FieldOffset(0)] public MOUSEINPUT mouse; [FieldOffset(0)] public KEYBDINPUT keyboard; }
    [StructLayout(LayoutKind.Sequential)] private struct MOUSEINPUT { public int x, y; public uint mouseData, flags, time; public UIntPtr extra; }
    [StructLayout(LayoutKind.Sequential)] private struct KEYBDINPUT { public ushort virtualKey, scan; public uint flags, time; public UIntPtr extra; }
    [DllImport("user32.dll", SetLastError = true)] private static extern uint SendInput(uint count, INPUT[] inputs, int size);
}
