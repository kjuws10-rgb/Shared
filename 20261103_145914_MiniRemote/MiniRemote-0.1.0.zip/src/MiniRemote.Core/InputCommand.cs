using System.Text.Json;

namespace MiniRemote.Core;

public sealed record InputCommand(string Kind, double X = 0, double Y = 0, int Button = 0, bool Down = false, string Code = "", int Delta = 0)
{
    public static InputCommand Parse(byte[] payload)
    {
        if (payload.Length > 4096) throw new InvalidDataException("Input too large.");
        using var document = JsonDocument.Parse(payload, new JsonDocumentOptions { MaxDepth = 4 });
        var root = document.RootElement;
        string kind = root.GetProperty("kind").GetString() ?? "";
        if (kind == "release") return new(kind);
        if (kind == "key")
        {
            var code = root.GetProperty("code").GetString() ?? "";
            if (!KeyCodes.TryGet(code, out _)) throw new InvalidDataException("Unsupported key.");
            return new(kind, Down: root.GetProperty("down").GetBoolean(), Code: code);
        }
        if (kind is not ("move" or "button" or "wheel")) throw new InvalidDataException("Unknown input.");
        double x = root.GetProperty("x").GetDouble(), y = root.GetProperty("y").GetDouble();
        if (!double.IsFinite(x) || !double.IsFinite(y) || x < 0 || x > 1 || y < 0 || y > 1)
            throw new InvalidDataException("Coordinates out of bounds.");
        if (kind == "button")
        {
            int button = root.GetProperty("button").GetInt32();
            if (button is < 0 or > 2) throw new InvalidDataException("Unknown button.");
            return new(kind, x, y, button, root.GetProperty("down").GetBoolean());
        }
        if (kind == "wheel")
        {
            int delta = root.GetProperty("delta").GetInt32();
            if (delta is < -1200 or > 1200 || delta == 0) throw new InvalidDataException("Wheel out of bounds.");
            return new(kind, x, y, Delta: delta);
        }
        return new(kind, x, y);
    }
}

public static class KeyCodes
{
    private static readonly Dictionary<string, ushort> Codes = Build();
    private static Dictionary<string, ushort> Build()
    {
        var map = new Dictionary<string, ushort>(StringComparer.Ordinal)
        {
            ["Backspace"] = 0x08, ["Tab"] = 0x09, ["Enter"] = 0x0D, ["NumpadEnter"] = 0x0D,
            ["ShiftLeft"] = 0xA0, ["ShiftRight"] = 0xA1, ["ControlLeft"] = 0xA2, ["ControlRight"] = 0xA3,
            ["AltLeft"] = 0xA4, ["AltRight"] = 0xA5, ["Pause"] = 0x13, ["CapsLock"] = 0x14,
            ["Lang1"] = 0x15, ["Lang2"] = 0x19, ["KanaMode"] = 0x15, ["Escape"] = 0x1B,
            ["Space"] = 0x20, ["PageUp"] = 0x21, ["PageDown"] = 0x22, ["End"] = 0x23, ["Home"] = 0x24,
            ["ArrowLeft"] = 0x25, ["ArrowUp"] = 0x26, ["ArrowRight"] = 0x27, ["ArrowDown"] = 0x28,
            ["Insert"] = 0x2D, ["Delete"] = 0x2E, ["MetaLeft"] = 0x5B, ["MetaRight"] = 0x5C,
            ["ContextMenu"] = 0x5D, ["NumpadMultiply"] = 0x6A, ["NumpadAdd"] = 0x6B,
            ["NumpadSubtract"] = 0x6D, ["NumpadDecimal"] = 0x6E, ["NumpadDivide"] = 0x6F,
            ["NumLock"] = 0x90, ["ScrollLock"] = 0x91, ["Semicolon"] = 0xBA, ["Equal"] = 0xBB,
            ["Comma"] = 0xBC, ["Minus"] = 0xBD, ["Period"] = 0xBE, ["Slash"] = 0xBF,
            ["Backquote"] = 0xC0, ["BracketLeft"] = 0xDB, ["Backslash"] = 0xDC,
            ["BracketRight"] = 0xDD, ["Quote"] = 0xDE, ["IntlBackslash"] = 0xE2
        };
        for (int i = 0; i < 26; i++) map["Key" + (char)('A' + i)] = (ushort)('A' + i);
        for (int i = 0; i < 10; i++) { map["Digit" + i] = (ushort)('0' + i); map["Numpad" + i] = (ushort)(0x60 + i); }
        for (int i = 1; i <= 12; i++) map["F" + i] = (ushort)(0x6F + i);
        return map;
    }
    public static bool TryGet(string code, out ushort value) => Codes.TryGetValue(code, out value);
    public static bool IsExtended(string code) => code is "ControlRight" or "AltRight" or "NumpadEnter" or "NumpadDivide" or "NumLock" or "MetaLeft" or "MetaRight" or "ContextMenu" or "Insert" or "Delete" or "Home" or "End" or "PageUp" or "PageDown" || code.StartsWith("Arrow", StringComparison.Ordinal);
}

public interface IInputSink
{
    void Apply(InputCommand command);
    void ReleaseAll();
}
