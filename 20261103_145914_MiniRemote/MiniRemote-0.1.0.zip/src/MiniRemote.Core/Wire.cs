using System.Buffers.Binary;
using System.Security.Cryptography;
using System.Text;

namespace MiniRemote.Core;

public enum MessageKind : byte { Hello = 1, Decision = 2, Frame = 3, Input = 4, End = 5, Heartbeat = 6 }

public sealed class Wire : IDisposable
{
    private readonly AesGcm send, receive;
    private ulong sendSequence, receiveSequence;
    public Wire(byte[] master, bool host)
    {
        if (master.Length != 32) throw new ArgumentException("256-bit key required.");
        var hostKey = Derive(master, "MiniRemote/host/v1");
        var viewerKey = Derive(master, "MiniRemote/viewer/v1");
        send = new AesGcm(host ? hostKey : viewerKey, 16);
        receive = new AesGcm(host ? viewerKey : hostKey, 16);
        CryptographicOperations.ZeroMemory(hostKey);
        CryptographicOperations.ZeroMemory(viewerKey);
    }
    private static byte[] Derive(byte[] master, string label)
    {
        var material = master.Concat(Encoding.UTF8.GetBytes(label)).ToArray();
        try { return SHA256.HashData(material); }
        finally { CryptographicOperations.ZeroMemory(material); }
    }
    public byte[] Encode(MessageKind type, ReadOnlySpan<byte> payload)
    {
        if (sendSequence == ulong.MaxValue) throw new InvalidDataException("Sequence exhausted.");
        var clear = new byte[9 + payload.Length];
        clear[0] = (byte)type;
        BinaryPrimitives.WriteUInt64BigEndian(clear.AsSpan(1, 8), sendSequence++);
        payload.CopyTo(clear.AsSpan(9));
        var packet = new byte[12 + clear.Length + 16];
        RandomNumberGenerator.Fill(packet.AsSpan(0, 12));
        send.Encrypt(packet.AsSpan(0, 12), clear, packet.AsSpan(12, clear.Length), packet.AsSpan(12 + clear.Length, 16));
        CryptographicOperations.ZeroMemory(clear);
        return packet;
    }
    public (MessageKind Kind, byte[] Payload) Decode(ReadOnlySpan<byte> packet)
    {
        if (packet.Length < 37 || packet.Length > 2 * 1024 * 1024) throw new InvalidDataException("Invalid packet size.");
        var clear = new byte[packet.Length - 28];
        try
        {
            receive.Decrypt(packet[..12], packet.Slice(12, clear.Length), packet[^16..], clear);
            if (BinaryPrimitives.ReadUInt64BigEndian(clear.AsSpan(1, 8)) != receiveSequence || receiveSequence == ulong.MaxValue)
                throw new InvalidDataException("Unexpected sequence.");
            if (!Enum.IsDefined((MessageKind)clear[0])) throw new InvalidDataException("Unknown message.");
            receiveSequence++;
            return ((MessageKind)clear[0], clear.AsSpan(9).ToArray());
        }
        finally { CryptographicOperations.ZeroMemory(clear); }
    }
    public static string Base64Url(byte[] data) => Convert.ToBase64String(data).TrimEnd('=').Replace('+', '-').Replace('/', '_');
    public void Dispose() { send.Dispose(); receive.Dispose(); }
}

public static class RelayAddress
{
    public static Uri Parse(string value)
    {
        if (!Uri.TryCreate(value.Trim(), UriKind.Absolute, out var uri) ||
            (uri.Scheme != "https" && !(uri.Scheme == "http" && uri.IsLoopback)) ||
            uri.AbsolutePath != "/" || uri.Query.Length != 0 || uri.Fragment.Length != 0 || uri.UserInfo.Length != 0)
            throw new ArgumentException("서버 주소는 https://도메인 형식이어야 합니다. HTTP는 localhost 시험만 가능합니다.");
        return uri;
    }
    public static Uri Socket(Uri server, string room) => new UriBuilder(server)
    { Scheme = server.Scheme == "https" ? "wss" : "ws", Path = $"/ws/{room}/host" }.Uri;
}
