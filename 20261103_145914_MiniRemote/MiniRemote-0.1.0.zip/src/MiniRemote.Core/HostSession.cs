using System.Diagnostics;
using System.Net.WebSockets;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace MiniRemote.Core;

public sealed class HostSession : IAsyncDisposable
{
    private readonly ClientWebSocket socket = new();
    private readonly CancellationTokenSource lifetime = new();
    private readonly SemaphoreSlim sender = new(1, 1);
    private readonly List<Task> workers = [];
    private readonly object controlGate = new();
    private readonly object lifecycleGate = new();
    private Task? running, disposing;
    private bool disposed;
    private readonly Wire wire;
    private readonly IInputSink input;
    private readonly Func<byte[]> capture;
    private readonly Func<string, CancellationToken, Task<bool>> approve;
    private readonly Action<string> status;
    private volatile bool approved, hello;
    private long lastMessage = Stopwatch.GetTimestamp();
    private string endMessage = "연결이 종료되었습니다. 새 연결은 새 초대 링크를 만드세요.";
    public string Invite { get; }
    public bool IsApproved => approved;

    private HostSession(Uri server, IInputSink input, Func<byte[]> capture, Func<string, CancellationToken, Task<bool>> approve, Action<string> status)
    {
        this.input = input; this.capture = capture; this.approve = approve; this.status = status;
        var master = RandomNumberGenerator.GetBytes(32);
        Room = Wire.Base64Url(RandomNumberGenerator.GetBytes(16));
        Invite = server.AbsoluteUri + "#room=" + Room + "&key=" + Wire.Base64Url(master);
        wire = new Wire(master, true);
        CryptographicOperations.ZeroMemory(master);
        socket.Options.KeepAliveInterval = TimeSpan.FromSeconds(10);
        socket.Options.KeepAliveTimeout = TimeSpan.FromSeconds(10);
    }
    public string Room { get; }
    public static async Task<HostSession> ConnectAsync(Uri server, IInputSink input, Func<byte[]> capture, Func<string, CancellationToken, Task<bool>> approve, Action<string> status, CancellationToken cancellation = default)
    {
        var session = new HostSession(server, input, capture, approve, status);
        try
        {
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellation);
            timeout.CancelAfter(TimeSpan.FromSeconds(15));
            await session.socket.ConnectAsync(RelayAddress.Socket(server, session.Room), timeout.Token);
            return session;
        }
        catch { await session.DisposeAsync(); throw; }
    }
    public Task RunAsync()
    {
        lock (lifecycleGate)
        {
            ObjectDisposedException.ThrowIf(disposing != null, this);
            return running ??= RunCoreAsync();
        }
    }
    private async Task RunCoreAsync()
    {
        await using var expiry = new Timer(_ => Stop("연결 시간이 만료되었습니다. 새 초대 링크를 만드세요."), null, TimeSpan.FromMinutes(5), Timeout.InfiniteTimeSpan);
        try
        {
            var buffer = new byte[8192];
            int inputs = 0;
            long window = Stopwatch.GetTimestamp();
            while (!lifetime.IsCancellationRequested)
            {
                using var message = new MemoryStream();
                WebSocketReceiveResult part;
                do
                {
                    part = await socket.ReceiveAsync(new ArraySegment<byte>(buffer), lifetime.Token);
                    if (part.MessageType == WebSocketMessageType.Close) return;
                    if (part.MessageType != WebSocketMessageType.Binary || message.Length + part.Count > 8192)
                        throw new InvalidDataException("Invalid transport message.");
                    message.Write(buffer, 0, part.Count);
                } while (!part.EndOfMessage);
                var (kind, payload) = wire.Decode(message.ToArray());
                Interlocked.Exchange(ref lastMessage, Stopwatch.GetTimestamp());
                if (!hello)
                {
                    if (kind != MessageKind.Hello || payload.Length > 512) throw new InvalidDataException("Hello required.");
                    using var doc = JsonDocument.Parse(payload);
                    var name = doc.RootElement.GetProperty("name").GetString() ?? "방문자";
                    if (name.Length > 60) throw new InvalidDataException("Label too long.");
                    name = new string(name.Where(c => !char.IsControl(c) && char.GetUnicodeCategory(c) != System.Globalization.UnicodeCategory.Format).ToArray());
                    hello = true;
                    expiry.Change(TimeSpan.FromHours(1), Timeout.InfiniteTimeSpan);
                    Start(() => HeartbeatAsync());
                    Start(() => ApproveAsync(name));
                    continue;
                }
                switch (kind)
                {
                    case MessageKind.Heartbeat when payload.Length == 0: break;
                    case MessageKind.Input:
                        if (Stopwatch.GetElapsedTime(window).TotalSeconds >= 1) { inputs = 0; window = Stopwatch.GetTimestamp(); }
                        if (++inputs > 120) throw new InvalidDataException("Input rate exceeded.");
                        var command = InputCommand.Parse(payload);
                        lock (controlGate)
                        {
                            if (!approved || lifetime.IsCancellationRequested) throw new InvalidDataException("Input requires local approval.");
                            input.Apply(command);
                        }
                        break;
                    case MessageKind.End: return;
                    default: throw new InvalidDataException("Message not allowed in this state.");
                }
            }
        }
        catch (OperationCanceledException) when (lifetime.IsCancellationRequested) { }
        catch (Exception ex) when (ex is WebSocketException or IOException or InvalidDataException or CryptographicException or JsonException or InvalidOperationException or KeyNotFoundException or FormatException)
        { endMessage = "연결이 끊겼거나 올바르지 않은 데이터가 수신되어 종료했습니다."; }
        finally
        {
            lifetime.Cancel();
            socket.Abort();
            lock (controlGate) { approved = false; input.ReleaseAll(); }
            Task[] pending;
            lock (workers) pending = workers.ToArray();
            await Task.WhenAll(pending);
            status(endMessage);
        }
    }
    private void Start(Func<Task> action)
    {
        async Task Guard()
        {
            try { await action(); }
            catch (OperationCanceledException) when (lifetime.IsCancellationRequested) { }
            catch { Stop("연결 처리 중 문제가 생겨 중단했습니다. 서버 주소와 네트워크 상태를 확인하세요."); }
        }
        lock (workers) workers.Add(Guard());
    }
    private async Task ApproveAsync(string name)
    {
        status("접속 요청이 왔습니다. 이 PC에서 허용 여부를 선택하세요.");
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(lifetime.Token);
        timeout.CancelAfter(TimeSpan.FromSeconds(30));
        bool accepted;
        try { accepted = await approve(name, timeout.Token).WaitAsync(timeout.Token); }
        catch (OperationCanceledException) when (!lifetime.IsCancellationRequested) { accepted = false; }
        lifetime.Token.ThrowIfCancellationRequested();
        lock (controlGate)
        {
            lifetime.Token.ThrowIfCancellationRequested();
            approved = accepted;
        }
        await SendAsync(MessageKind.Decision, JsonSerializer.SerializeToUtf8Bytes(new { accepted, message = accepted ? "접속을 승인했습니다." : "접속이 거절되었거나 승인 시간이 만료되었습니다." }));
        if (!accepted) { Stop("접속을 거절했습니다. 새 초대 링크를 만들 수 있습니다."); return; }
        status("● 원격 제어 중 — 중단 버튼 또는 Ctrl+Alt+F12로 즉시 종료");
        Start(() => FramesAsync());
    }
    private async Task FramesAsync()
    {
        while (!lifetime.IsCancellationRequested)
        {
            var frame = capture();
            if (frame.Length > 2 * 1024 * 1024 - 37) throw new InvalidDataException("Frame too large.");
            await SendAsync(MessageKind.Frame, frame);
            await Task.Delay(200, lifetime.Token);
        }
    }
    private async Task HeartbeatAsync()
    {
        while (!lifetime.IsCancellationRequested)
        {
            await Task.Delay(2000, lifetime.Token);
            if (Stopwatch.GetElapsedTime(Interlocked.Read(ref lastMessage)).TotalSeconds > 12)
            { Stop("상대 기기의 응답이 없어 종료했습니다."); return; }
            await SendAsync(MessageKind.Heartbeat, []);
        }
    }
    private async Task SendAsync(MessageKind kind, byte[] payload)
    {
        await sender.WaitAsync(lifetime.Token);
        try
        {
            var packet = wire.Encode(kind, payload);
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(lifetime.Token);
            timeout.CancelAfter(TimeSpan.FromSeconds(8));
            await socket.SendAsync(new ArraySegment<byte>(packet), WebSocketMessageType.Binary, true, timeout.Token);
        }
        finally { sender.Release(); }
    }
    public void Stop(string? message = null)
    {
        lock (controlGate)
        {
            if (disposed) return;
            if (message != null) endMessage = message;
            approved = false;
            lifetime.Cancel();
            input.ReleaseAll();
            socket.Abort();
        }
    }
    public ValueTask DisposeAsync()
    {
        lock (lifecycleGate) return new ValueTask(disposing ??= DisposeCoreAsync());
    }
    private async Task DisposeCoreAsync()
    {
        Stop();
        Task? current;
        lock (lifecycleGate) current = running;
        try { if (current != null) await current.ConfigureAwait(false); }
        finally
        {
            lock (controlGate)
            {
                disposed = true;
                socket.Dispose(); wire.Dispose(); sender.Dispose(); lifetime.Dispose();
            }
        }
    }
}
