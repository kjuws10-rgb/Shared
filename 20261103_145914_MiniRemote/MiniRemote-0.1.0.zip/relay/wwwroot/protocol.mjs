export const Types = Object.freeze({ hello: 1, decision: 2, frame: 3, input: 4, end: 5, heartbeat: 6 });
export const MAX_HOST_PACKET = 2 * 1024 * 1024;
export const MAX_VIEWER_PACKET = 8192;
export const MAX_SEQUENCE = (1n << 64n) - 1n;
const encoder = new TextEncoder();
const decoder = new TextDecoder('utf-8', { fatal: true });

export function jsonBytes(value) { return encoder.encode(JSON.stringify(value)); }
export function readJson(bytes) {
  const value = JSON.parse(decoder.decode(bytes));
  if (value === null || typeof value !== 'object' || Array.isArray(value)) throw new Error('잘못된 메시지 형식입니다.');
  return value;
}

export function parseInvite(text, origin) {
  const url = new URL(text);
  if (url.origin !== origin || !['https:', 'http:'].includes(url.protocol) || url.username || url.password || url.pathname !== '/' || url.search) {
    throw new Error('현재 서버에서 만든 초대 링크를 사용하세요.');
  }
  const params = new URLSearchParams(url.hash.slice(1));
  if (params.size !== 2 || params.getAll('room').length !== 1 || params.getAll('key').length !== 1) throw new Error('초대 링크의 형식이 올바르지 않습니다.');
  const room = params.get('room');
  const key = params.get('key');
  if (!/^[A-Za-z0-9_-]{22}$/.test(room ?? '') || !/^[A-Za-z0-9_-]{43}$/.test(key ?? '')) throw new Error('초대 링크의 방 번호 또는 암호키가 올바르지 않습니다.');
  const master = Uint8Array.from(atob(key.replace(/-/g, '+').replace(/_/g, '/') + '='), c => c.charCodeAt(0));
  // Reject noncanonical encodings so one 32-byte secret has one textual form.
  if (master.length !== 32 || btoa(String.fromCharCode(...master)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '') !== key) throw new Error('초대 암호키를 읽을 수 없습니다.');
  return { room, master };
}

export async function deriveKeys(master, cryptoApi = globalThis.crypto) {
  if (!(master instanceof Uint8Array) || master.length !== 32) throw new Error('암호키 길이가 올바르지 않습니다.');
  async function derive(label) {
    const suffix = encoder.encode(label);
    const material = new Uint8Array(master.length + suffix.length);
    material.set(master);
    material.set(suffix, master.length);
    const digest = await cryptoApi.subtle.digest('SHA-256', material);
    material.fill(0);
    return cryptoApi.subtle.importKey('raw', digest, 'AES-GCM', false, ['encrypt', 'decrypt']);
  }
  const [send, receive] = await Promise.all([derive('MiniRemote/viewer/v1'), derive('MiniRemote/host/v1')]);
  return { send, receive };
}

export async function encryptPacket(key, sequence, type, payload = new Uint8Array(), cryptoApi = globalThis.crypto) {
  if (sequence < 0n || sequence > MAX_SEQUENCE || !Number.isInteger(type) || type < 1 || type > 6) throw new Error('송신 순서가 올바르지 않습니다.');
  const plain = new Uint8Array(9 + payload.length);
  plain[0] = type;
  new DataView(plain.buffer).setBigUint64(1, sequence, false);
  plain.set(payload, 9);
  const nonce = cryptoApi.getRandomValues(new Uint8Array(12));
  const encrypted = new Uint8Array(await cryptoApi.subtle.encrypt({ name: 'AES-GCM', iv: nonce, tagLength: 128 }, key, plain));
  const wire = new Uint8Array(12 + encrypted.length);
  wire.set(nonce);
  wire.set(encrypted, 12);
  return wire;
}

export async function decryptPacket(key, wire, expectedSequence, cryptoApi = globalThis.crypto) {
  const bytes = wire instanceof Uint8Array ? wire : new Uint8Array(wire);
  if (bytes.length < 37 || bytes.length > MAX_HOST_PACKET || expectedSequence > MAX_SEQUENCE) throw new Error('잘못된 수신 패킷입니다.');
  const plain = new Uint8Array(await cryptoApi.subtle.decrypt({ name: 'AES-GCM', iv: bytes.subarray(0, 12), tagLength: 128 }, key, bytes.subarray(12)));
  if (plain.length < 9 || new DataView(plain.buffer, plain.byteOffset, plain.byteLength).getBigUint64(1, false) !== expectedSequence) throw new Error('메시지 순서 검증에 실패했습니다.');
  return { type: plain[0], payload: plain.subarray(9) };
}

// This queue assigns sequence numbers in actual send order, even when WebCrypto
// resolves promises at different times. Exceeding a bound ends the session;
// key/button releases are never silently discarded.
export class PacketSender {
  constructor(key, transport, options = {}) {
    this.key = key;
    this.transport = transport;
    this.cryptoApi = options.cryptoApi ?? globalThis.crypto;
    this.onFatal = options.onFatal ?? (() => {});
    this.limitCount = options.limitCount ?? 64;
    this.limitBytes = options.limitBytes ?? 32 * 1024;
    this.limitBuffered = options.limitBuffered ?? 32 * 1024;
    this.count = 0;
    this.bytes = 0;
    this.sequence = 0n;
    this.closed = false;
    this.tail = Promise.resolve();
  }

  enqueue(type, payload = new Uint8Array()) {
    const packetSize = payload.length + 37;
    if (this.closed) return Promise.reject(new Error('접속이 종료되었습니다.'));
    if (packetSize > MAX_VIEWER_PACKET || this.count + 1 > this.limitCount || this.bytes + packetSize > this.limitBytes || this.transport.bufferedAmount > this.limitBuffered) {
      const error = new Error('전송이 지연되어 입력을 안전하게 중단했습니다. 새 초대 링크로 다시 연결하세요.');
      this.abort(error);
      return Promise.reject(error);
    }
    this.count++;
    this.bytes += packetSize;
    const task = this.tail.then(async () => {
      if (this.closed || this.transport.readyState !== 1) throw new Error('연결이 끊어졌습니다.');
      if (this.transport.bufferedAmount + packetSize > this.limitBuffered) throw new Error('전송 대기량이 한도를 넘었습니다.');
      const wire = await encryptPacket(this.key, this.sequence, type, payload, this.cryptoApi);
      if (this.closed || this.transport.readyState !== 1) throw new Error('연결이 끊어졌습니다.');
      this.transport.send(wire);
      this.sequence++;
    });
    this.tail = task.catch(error => this.abort(error)).finally(() => { this.count--; this.bytes -= packetSize; });
    return task;
  }

  abort(error) {
    if (this.closed) return;
    this.closed = true;
    this.onFatal(error);
  }
  dispose() { this.closed = true; this.key = null; }
}

export function normalizedPoint(clientX, clientY, rect, width, height, clamp = false) {
  if (!rect.width || !rect.height || !width || !height) return null;
  const scale = Math.min(rect.width / width, rect.height / height);
  const displayWidth = width * scale;
  const displayHeight = height * scale;
  const x = (clientX - rect.left - (rect.width - displayWidth) / 2) / displayWidth;
  const y = (clientY - rect.top - (rect.height - displayHeight) / 2) / displayHeight;
  if (!clamp && (x < 0 || x > 1 || y < 0 || y > 1)) return null;
  return { x: Math.min(1, Math.max(0, x)), y: Math.min(1, Math.max(0, y)) };
}

export function jpegDimensions(bytes) {
  if (!(bytes instanceof Uint8Array) || bytes.length < 4 || bytes[0] !== 0xff || bytes[1] !== 0xd8) throw new Error('JPEG 화면 형식이 올바르지 않습니다.');
  let offset = 2;
  const sof = new Set([0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf]);
  while (offset < bytes.length) {
    if (bytes[offset++] !== 0xff) break;
    while (offset < bytes.length && bytes[offset] === 0xff) offset++;
    const marker = bytes[offset++];
    if (marker === 0xda || marker === 0xd9 || marker === undefined) break;
    if (marker === 0x01 || marker >= 0xd0 && marker <= 0xd7) continue;
    if (offset + 2 > bytes.length) break;
    const length = bytes[offset] * 256 + bytes[offset + 1];
    if (length < 2 || offset + length > bytes.length) break;
    if (sof.has(marker)) {
      if (length < 8) break;
      const height = bytes[offset + 3] * 256 + bytes[offset + 4];
      const width = bytes[offset + 5] * 256 + bytes[offset + 6];
      if (width < 1 || width > 1280 || height < 1 || height > 900) throw new Error('화면 크기가 허용 범위를 넘었습니다.');
      return { width, height };
    }
    offset += length;
  }
  throw new Error('JPEG 화면의 크기를 확인할 수 없습니다.');
}

export const SUPPORTED_CODES = new Set([
  ...Array.from({ length: 26 }, (_, i) => `Key${String.fromCharCode(65 + i)}`),
  ...Array.from({ length: 10 }, (_, i) => `Digit${i}`),
  ...Array.from({ length: 10 }, (_, i) => `Numpad${i}`),
  ...Array.from({ length: 12 }, (_, i) => `F${i + 1}`),
  'Backspace', 'Tab', 'Enter', 'ShiftLeft', 'ShiftRight', 'ControlLeft', 'ControlRight', 'AltLeft', 'AltRight',
  'Space', 'CapsLock', 'Home', 'End', 'PageUp', 'PageDown', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown',
  'Insert', 'Delete', 'NumLock', 'ScrollLock', 'NumpadAdd', 'NumpadSubtract', 'NumpadMultiply', 'NumpadDivide',
  'NumpadDecimal', 'NumpadEnter', 'Backquote', 'Minus', 'Equal', 'BracketLeft', 'BracketRight', 'Backslash',
  'Semicolon', 'Quote', 'Comma', 'Period', 'Slash',
  'Lang1', 'Lang2', 'KanaMode', 'IntlBackslash', 'Pause', 'ContextMenu',
]);
