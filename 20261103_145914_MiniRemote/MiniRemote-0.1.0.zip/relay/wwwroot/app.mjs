import { Types, MAX_HOST_PACKET, PacketSender, deriveKeys, decryptPacket, jsonBytes, readJson, parseInvite, normalizedPoint, jpegDimensions, SUPPORTED_CODES } from './protocol.mjs';

const $ = id => document.getElementById(id);
const ui = Object.fromEntries(['status', 'invite', 'invite-state', 'import', 'viewer-name', 'connect-form', 'connect', 'pause', 'stop', 'message', 'screen', 'screen-wrap', 'screen-info', 'control-state', 'placeholder', 'placeholder-title', 'placeholder-description'].map(id => [id, $(id)]));
const canvas = ui.screen;
const context = canvas.getContext('2d', { alpha: false });
let invitation = null;
let current = null;

function status(phase, label, message) {
  ui.status.dataset.state = phase;
  ui.status.textContent = label;
  ui.message.textContent = message;
}
function placeholder(title, description) {
  ui.placeholder.hidden = false;
  ui['placeholder-title'].textContent = title;
  ui['placeholder-description'].textContent = description;
}
function setControl(active) {
  ui['control-state'].textContent = active ? '키보드 · 마우스 조작 중 — Esc로 일시정지' : '조작 일시정지 — 화면을 눌러 시작';
  ui['control-state'].dataset.active = String(active);
  ui['screen-wrap'].dataset.active = String(active);
  ui.pause.disabled = !active;
}
function setBusy(busy) {
  ui.invite.disabled = busy;
  ui.import.disabled = busy;
  ui['viewer-name'].disabled = busy;
  ui.connect.disabled = busy || !invitation;
  ui.stop.disabled = !busy;
}
function safeMessage(value, fallback) {
  return typeof value === 'string' && value.trim() ? value.replace(/[\u0000-\u001f\u007f-\u009f]/g, '').slice(0, 300) : fallback;
}
function loadInvite(text) {
  if (current && !current.ended) return;
  invitation?.master.fill(0);
  invitation = null;
  try {
    invitation = parseInvite(text.trim(), location.origin);
    ui['invite-state'].textContent = '초대장을 읽었습니다. 암호키는 이 창에만 보관됩니다.';
    status('ready', '연결 준비', '연결을 누르면 접속할 PC에 승인 요청을 보냅니다. 초대 링크는 한 번만 사용할 수 있습니다.');
  } catch (error) {
    ui['invite-state'].textContent = '현재 서버의 새 초대 링크가 필요합니다.';
    status('idle', '초대장 확인', error.message);
  }
  ui.invite.value = '';
  setBusy(false);
}

class Session {
  constructor(invite, name) {
    this.room = invite.room;
    this.master = invite.master;
    this.name = name;
    this.phase = 'connecting';
    this.ended = false;
    this.stopping = false;
    this.controlActive = false;
    this.socket = null;
    this.sender = null;
    this.receiveKey = null;
    this.readSequence = 0n;
    this.receiveTail = Promise.resolve();
    this.receiveCount = 0;
    this.receiveBytes = 0;
    this.lastAuthenticatedAt = 0;
    this.frameWidth = 0;
    this.frameHeight = 0;
    this.pressedButtons = new Set();
    this.pointerId = null;
    this.moveTimer = null;
    this.pendingMove = null;
    this.lastMoveAt = -Infinity;
    this.heartbeatTimer = null;
    this.connectionTimer = null;
    this.approvalTimer = null;
    this.stopTimer = null;
  }

  async start() {
    setBusy(true);
    setControl(false);
    canvas.dataset.ready = 'false';
    context.fillStyle = '#070b12';
    context.fillRect(0, 0, canvas.width, canvas.height);
    ui['screen-info'].textContent = '화면 대기';
    placeholder('서버에 연결하고 있습니다', '접속할 PC의 승인 전에는 화면과 입력을 주고받지 않습니다.');
    status('connecting', '연결 중', '승인 요청을 준비하고 있습니다.');
    try {
      const localHttp = location.protocol === 'http:' && ['localhost', '127.0.0.1', '[::1]'].includes(location.hostname);
      if (location.protocol !== 'https:' && !localHttp) throw new Error('외부 접속에는 회사에서 승인한 HTTPS 서버가 필요합니다.');
      if (!globalThis.isSecureContext || !globalThis.crypto?.subtle) throw new Error('이 브라우저에서 안전한 암호화를 사용할 수 없습니다. HTTPS로 접속하세요.');
      const keys = await deriveKeys(this.master);
      this.master.fill(0);
      this.master = null;
      if (this.ended) return;
      this.receiveKey = keys.receive;
      const scheme = location.protocol === 'https:' ? 'wss:' : 'ws:';
      const socket = new WebSocket(`${scheme}//${location.host}/ws/${this.room}/viewer`);
      this.socket = socket;
      this.room = null;
      socket.binaryType = 'arraybuffer';
      this.sender = new PacketSender(keys.send, socket, { onFatal: error => this.fail(error.message) });
      this.connectionTimer = setTimeout(() => this.fail('서버 연결 시간이 초과되었습니다. 새 초대 링크로 다시 연결하세요.'), 15_000);
      socket.addEventListener('open', () => this.opened());
      socket.addEventListener('message', event => this.received(event.data));
      socket.addEventListener('error', () => this.fail('서버에 연결할 수 없습니다. 승인된 서버 주소와 네트워크 허용 상태를 확인하세요.'));
      socket.addEventListener('close', () => this.finish('연결이 종료되었습니다. 접속할 PC에서 새 초대 링크를 받아 다시 연결하세요.'));
    } catch (error) {
      this.master?.fill(0);
      this.master = null;
      this.fail(error.message);
    }
  }

  async opened() {
    if (this.ended || this.stopping) return;
    clearTimeout(this.connectionTimer);
    this.phase = 'awaiting';
    this.lastAuthenticatedAt = performance.now();
    status('awaiting', 'PC 승인 대기', '접속할 PC의 사용자가 30초 안에 승인해야 합니다.');
    placeholder('PC 사용자의 승인을 기다립니다', '접속 이름은 직접 입력한 표시 이름이며 신원이 인증된 것은 아닙니다.');
    this.approvalTimer = setTimeout(() => this.fail('PC 승인 시간이 초과되었습니다. 새 초대 링크로 다시 연결하세요.'), 32_000);
    try {
      await this.sender.enqueue(Types.hello, jsonBytes({ name: this.name }));
      if (this.ended || this.stopping) return;
      this.heartbeatTimer = setInterval(() => {
        if (performance.now() - this.lastAuthenticatedAt >= 12_000) {
          this.fail('12초 동안 응답이 없어 연결을 종료했습니다.');
          return;
        }
        this.send(Types.heartbeat);
      }, 2_000);
    } catch { /* PacketSender already ends the session. */ }
  }

  send(type, payload) {
    if (this.ended || this.stopping || !this.sender) return;
    this.sender.enqueue(type, payload).catch(() => {});
  }

  received(data) {
    if (this.ended || this.stopping) return;
    if (!(data instanceof ArrayBuffer) || data.byteLength < 37 || data.byteLength > MAX_HOST_PACKET) {
      this.fail('잘못된 서버 메시지를 받아 연결을 종료했습니다.');
      return;
    }
    if (this.receiveCount >= 8 || this.receiveBytes + data.byteLength > 6 * 1024 * 1024) {
      this.fail('화면 수신이 지연되어 연결을 종료했습니다.');
      return;
    }
    this.receiveCount++;
    this.receiveBytes += data.byteLength;
    this.receiveTail = this.receiveTail.then(async () => {
      if (this.ended || this.stopping) return;
      let packet;
      try { packet = await decryptPacket(this.receiveKey, data, this.readSequence); }
      catch { throw new Error('암호화 또는 메시지 순서 검증에 실패했습니다. 새 초대 링크로 다시 연결하세요.'); }
      if (this.ended || this.stopping) return;
      this.readSequence++;
      this.lastAuthenticatedAt = performance.now();
      await this.handlePacket(packet);
    }).catch(error => this.fail(error.message)).finally(() => {
      this.receiveCount--;
      this.receiveBytes -= data.byteLength;
    });
  }

  async handlePacket({ type, payload }) {
    if (type === Types.heartbeat) {
      if (payload.length !== 0) throw new Error('응답 메시지 형식이 올바르지 않습니다.');
      return;
    }
    if (type === Types.end) {
      const value = readJson(payload);
      this.finish(safeMessage(value.message, 'PC에서 연결을 종료했습니다.'));
      return;
    }
    if (type === Types.decision) {
      if (this.phase !== 'awaiting') throw new Error('중복되거나 순서가 잘못된 승인 메시지입니다.');
      const value = readJson(payload);
      if (typeof value.accepted !== 'boolean') throw new Error('승인 메시지 형식이 올바르지 않습니다.');
      clearTimeout(this.approvalTimer);
      if (!value.accepted) {
        this.finish(safeMessage(value.message, 'PC 사용자가 연결을 거절했습니다.'));
        return;
      }
      this.phase = 'approved';
      status('approved', '연결됨 · 조작 대기', '승인되었습니다. 화면이 표시되면 화면을 눌러 키보드와 마우스 조작을 시작하세요.');
      placeholder('승인되었습니다', '첫 화면을 기다리고 있습니다.');
      return;
    }
    if (type !== Types.frame || this.phase !== 'approved') throw new Error('승인 전 화면 또는 허용되지 않은 메시지를 받았습니다.');
    const dimensions = jpegDimensions(payload);
    const blob = new Blob([payload], { type: 'image/jpeg' });
    let frame;
    let objectUrl;
    try {
      if (globalThis.createImageBitmap) frame = await createImageBitmap(blob);
      else {
        objectUrl = URL.createObjectURL(blob);
        frame = new Image();
        frame.src = objectUrl;
        await frame.decode();
      }
      if (this.ended || this.stopping) return;
      const width = frame.width || frame.naturalWidth;
      const height = frame.height || frame.naturalHeight;
      if (width !== dimensions.width || height !== dimensions.height) throw new Error('화면 크기 검증에 실패했습니다.');
      if (canvas.width !== width || canvas.height !== height) {
        canvas.width = width;
        canvas.height = height;
      }
      context.drawImage(frame, 0, 0, width, height);
      this.frameWidth = width;
      this.frameHeight = height;
      canvas.dataset.ready = 'true';
      ui.placeholder.hidden = true;
      ui['screen-info'].textContent = `${width} × ${height} · 기본 모니터`;
    } finally {
      frame?.close?.();
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    }
  }

  point(event, clamp = false) {
    return normalizedPoint(event.clientX, event.clientY, canvas.getBoundingClientRect(), this.frameWidth, this.frameHeight, clamp);
  }

  activate() {
    if (this.phase !== 'approved' || this.ended || this.stopping || !this.frameWidth) return false;
    canvas.focus({ preventScroll: true });
    this.controlActive = true;
    setControl(true);
    status('approved', '연결됨 · 조작 중', '키보드와 마우스를 원격 PC로 전달합니다. Esc를 누르면 조작을 일시정지합니다.');
    return true;
  }

  input(value) {
    if (this.phase === 'approved' && this.controlActive && !this.ended && !this.stopping) this.send(Types.input, jsonBytes(value));
  }

  move(point) {
    this.pendingMove = point;
    if (this.moveTimer !== null) return;
    const delay = Math.max(0, 34 - (performance.now() - this.lastMoveAt));
    this.moveTimer = setTimeout(() => {
      this.moveTimer = null;
      const latest = this.pendingMove;
      this.pendingMove = null;
      if (latest && this.controlActive && document.activeElement === canvas) {
        this.lastMoveAt = performance.now();
        this.input({ kind: 'move', ...latest });
      }
    }, delay);
  }

  clearMove() {
    clearTimeout(this.moveTimer);
    this.moveTimer = null;
    this.pendingMove = null;
  }

  release() {
    this.clearMove();
    this.pressedButtons.clear();
    if (this.phase === 'approved' && !this.ended && !this.stopping) this.send(Types.input, jsonBytes({ kind: 'release' }));
  }

  pause() {
    if (!this.controlActive || this.ended || this.stopping) return;
    this.controlActive = false;
    this.release();
    setControl(false);
    status('approved', '연결됨 · 일시정지', '조작을 일시정지했습니다. 다시 조작하려면 원격 화면을 누르세요.');
  }

  stop() {
    if (this.ended || this.stopping) return;
    if (!this.sender || this.socket?.readyState !== WebSocket.OPEN) {
      this.finish('접속을 중단했습니다. 새 초대 링크가 있어야 다시 연결할 수 있습니다.');
      return;
    }
    this.clearMove();
    this.pressedButtons.clear();
    this.controlActive = false;
    this.stopping = true;
    setControl(false);
    ui.stop.disabled = true;
    status('ending', '종료 중', '키보드와 마우스 입력을 해제하고 연결을 종료합니다.');
    const finish = () => this.finish('접속을 중단했습니다. 새 초대 링크가 있어야 다시 연결할 수 있습니다.');
    this.stopTimer = setTimeout(finish, 500);
    const sendRelease = this.phase === 'approved' ? this.sender.enqueue(Types.input, jsonBytes({ kind: 'release' })) : Promise.resolve();
    sendRelease.then(() => this.sender.enqueue(Types.end, jsonBytes({ message: '원격 사용자가 연결을 종료했습니다.' }))).then(finish, finish);
  }

  fail(message) { this.finish(safeMessage(message, '연결 오류로 접속을 중단했습니다.')); }

  finish(message) {
    if (this.ended) return;
    this.ended = true;
    this.controlActive = false;
    this.clearMove();
    this.pressedButtons.clear();
    clearTimeout(this.connectionTimer);
    clearTimeout(this.approvalTimer);
    clearTimeout(this.stopTimer);
    clearInterval(this.heartbeatTimer);
    this.master?.fill(0);
    this.master = null;
    this.receiveKey = null;
    this.sender?.dispose();
    if (this.socket && this.socket.readyState < WebSocket.CLOSING) this.socket.close(1000, 'Session ended');
    if (current !== this) return;
    setControl(false);
    ui['control-state'].textContent = '조작 꺼짐';
    canvas.dataset.ready = 'false';
    context.fillStyle = '#070b12';
    context.fillRect(0, 0, canvas.width, canvas.height);
    placeholder('연결이 종료되었습니다', '새 초대 링크를 받아 다시 연결할 수 있습니다.');
    ui['screen-info'].textContent = '화면 전송 종료';
    ui['invite-state'].textContent = '사용한 초대장은 폐기되었습니다. 새 초대 링크를 넣으세요.';
    status('ended', '연결 종료', message);
    setBusy(false);
  }
}

ui.import.addEventListener('click', () => loadInvite(ui.invite.value));
ui['connect-form'].addEventListener('submit', event => {
  event.preventDefault();
  if (current && !current.ended) return;
  if (ui.invite.value.trim()) loadInvite(ui.invite.value);
  if (!invitation) return;
  const name = ui['viewer-name'].value.replace(/[\u0000-\u001f\u007f-\u009f]/g, '').trim().slice(0, 60).replace(/[\uD800-\uDBFF]$/, '') || '원격 사용자';
  const invite = invitation;
  invitation = null;
  ui['invite-state'].textContent = '일회용 초대장 사용 중';
  current = new Session(invite, name);
  current.start();
});
ui.pause.addEventListener('click', () => current?.pause());
ui.stop.addEventListener('click', () => current?.stop());

canvas.addEventListener('pointerdown', event => {
  const session = current;
  if (!session || !event.isPrimary || ![0, 1, 2].includes(event.button)) return;
  const point = session.point(event);
  if (!point || !session.activate()) return;
  event.preventDefault();
  session.clearMove();
  session.pointerId = event.pointerId;
  session.pressedButtons.add(event.button);
  try { canvas.setPointerCapture(event.pointerId); } catch { session.pause(); return; }
  session.input({ kind: 'button', ...point, button: event.button, down: true });
});
canvas.addEventListener('pointermove', event => {
  const session = current;
  if (!session?.controlActive || !event.isPrimary || document.activeElement !== canvas) return;
  const point = session.point(event, canvas.hasPointerCapture(event.pointerId));
  if (point) { event.preventDefault(); session.move(point); }
});
canvas.addEventListener('pointerup', event => {
  const session = current;
  if (!session?.controlActive || !event.isPrimary || !session.pressedButtons.has(event.button)) return;
  const point = session.point(event, true);
  event.preventDefault();
  session.clearMove();
  session.pressedButtons.delete(event.button);
  if (point) session.input({ kind: 'button', ...point, button: event.button, down: false });
  else session.release();
});
canvas.addEventListener('pointercancel', () => current?.pause());
canvas.addEventListener('lostpointercapture', () => {
  // Browsers also release capture after an ordinary final pointerup. Its
  // button-up is already queued, so keep any deliberately held modifier keys.
  // Unexpected loss while a button is still down must release every input.
  if (current?.pressedButtons.size) current.release();
});
canvas.addEventListener('contextmenu', event => { if (current?.controlActive) event.preventDefault(); });
canvas.addEventListener('wheel', event => {
  const session = current;
  if (!session?.controlActive || document.activeElement !== canvas) return;
  const point = session.point(event);
  if (!point || !Number.isFinite(event.deltaY) || event.deltaY === 0) return;
  event.preventDefault();
  session.input({ kind: 'wheel', ...point, delta: -Math.sign(event.deltaY) * 120 });
}, { passive: false });

for (const [eventName, down] of [['keydown', true], ['keyup', false]]) {
  document.addEventListener(eventName, event => {
    const session = current;
    if (!session?.controlActive) return;
    if (event.code === 'Escape') {
      event.preventDefault();
      if (down) session.pause();
      return;
    }
    if (document.activeElement !== canvas || !SUPPORTED_CODES.has(event.code)) return;
    event.preventDefault();
    session.input({ kind: 'key', code: event.code, down });
  }, { capture: true });
}
canvas.addEventListener('blur', () => current?.pause());
window.addEventListener('blur', () => current?.pause());
document.addEventListener('visibilitychange', () => { if (document.hidden) current?.pause(); });
window.addEventListener('pagehide', () => {
  // Closing the socket is the final input-release guarantee on page teardown;
  // browsers do not guarantee completion of asynchronous encryption here.
  current?.pause();
  current?.finish('페이지를 닫아 접속을 종료했습니다.');
  invitation?.master.fill(0);
  invitation = null;
});

// Remove the secret before parsing, rendering or connecting. Never persist it.
const initialFragment = location.hash;
if (initialFragment) {
  history.replaceState(null, '', location.pathname + location.search);
  loadInvite(`${location.origin}/${initialFragment}`);
}
