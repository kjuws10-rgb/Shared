param([switch]$Portable)
$ErrorActionPreference = 'Stop'
Push-Location $PSScriptRoot
try {
    & dotnet publish src/MiniRemote.Host -c Release -r win-x64 --self-contained false -p:PublishSingleFile=true -p:DebugType=None -p:DebugSymbols=false -o artifacts/host-light --nologo
    if ($LASTEXITCODE -ne 0) { throw 'Host publish failed' }
    & dotnet build src/MiniRemote.Relay -c Release --no-incremental -p:DebugType=None -p:DebugSymbols=false "-p:PathMap=$PSScriptRoot=/_/MiniRemote" --nologo
    if ($LASTEXITCODE -ne 0) { throw 'Relay rebuild failed' }
    & dotnet publish src/MiniRemote.Relay -c Release --no-build --no-restore -p:DebugType=None -p:DebugSymbols=false -o artifacts/relay --nologo
    if ($LASTEXITCODE -ne 0) { throw 'Relay publish failed' }
    if ($Portable) {
        & dotnet publish src/MiniRemote.Host -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:EnableCompressionInSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:DebugType=None -p:DebugSymbols=false -o artifacts/host-portable --nologo
        if ($LASTEXITCODE -ne 0) { throw 'Portable publish failed' }
    }
} finally { Pop-Location }
