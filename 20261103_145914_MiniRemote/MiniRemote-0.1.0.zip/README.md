# MiniRemote

Windows PC의 주 모니터를 보면서 키보드·마우스를 조작하는 최소 원격 프로그램입니다. 조작하는 기기는 브라우저만 있으면 됩니다.

**외부 접속에는 사용할 권한이 있는 HTTPS 중계 서버가 필요합니다.** PC용 실행 파일과 서버 파일을 만들었으며, 공용 서버는 설치하지 않았습니다. 회사에서 해당 서버와 WebSocket 연결을 허용해야 사용할 수 있습니다.

## 바로 사용할 파일

| 파일 | 용도 |
| --- | --- |
| `host-light/MiniRemote.exe` | 약 216 KiB. Windows x64 + .NET 10 Desktop Runtime이 있는 PC용 |
| `host-portable/MiniRemote.exe` | 약 49.3 MiB. .NET을 포함한 Windows x64 실행 파일 |
| `relay/` | .NET 10 ASP.NET Core 중계 서버와 브라우저 화면 |
| `MiniRemote-0.1.0.zip` | 실행 파일 2종·서버·한글 안내를 묶은 배포본 |
| `시작안내.html` | 연결 구조 그림과 사용 순서 |

두 PC 모두에 프로그램을 설치할 필요는 없습니다. **조작받을 Windows PC에서만 실행**하고, 조작하는 기기는 초대 링크를 브라우저로 엽니다.

## 사용 순서

1. 중계 서버 관리자가 [deploy/README.md](deploy/README.md)의 HTTPS 서버를 준비합니다. 설치에는 승인된 서버·도메인·유효한 인증서가 필요합니다.
2. 조작받을 PC에서 `MiniRemote.exe`를 실행하고 `https://승인된-서버-주소`를 입력합니다.
3. **초대 링크 만들기 → 링크 복사**를 누른 뒤 필요한 상대방에게 전달합니다.
4. 상대방이 링크를 열어 **연결**을 누르면, 조작받을 PC에 승인창이 나옵니다. **지금 허용**을 누르세요. 30초 안에 승인하지 않으면 거절합니다.
5. 상대방이 브라우저의 화면을 누르면 키보드·마우스 조작이 시작됩니다. 브라우저의 **Esc**는 조작을 일시정지합니다. **접속 중단** 또는 PC 앱의 **즉시 중단 / Ctrl+Alt+F12**로 종료합니다.

초대 링크는 접속 비밀키를 포함합니다. 필요한 상대에게만 전달하세요. 표시 이름은 상대가 적은 이름이며 본인 인증 정보가 아닙니다. 링크는 한 번 사용 후 폐기되고, 새 접속에는 새 링크가 필요합니다. 대기는 5분, 연결은 최대 1시간입니다.

## 이 PC에서만 먼저 시험

`로컬시험.cmd`를 실행하면 이 PC의 `127.0.0.1:8787`에서 중계 서버를 실행하고 PC 앱을 엽니다. 열리는 콘솔을 닫으면 서버가 종료됩니다. 앱에서 링크를 만들어 같은 PC의 브라우저에서 열 수 있습니다. 앱의 접속 승인은 직접 선택해야 합니다.

**localhost 링크는 다른 PC나 외부망에서 접근할 수 없습니다.** 두 창이 서로 보이므로 같은 PC에서는 화면이 반복돼 보일 수 있습니다. 외부 연결은 HTTPS 서버 주소로 시험해야 합니다.

## 범위와 제한

- 주 모니터 1개, 최대 1280×900 비율 유지 JPEG, 초당 최대 5장입니다. 음성·파일 전송·원격 명령·클립보드 동기화는 제공하지 않습니다.
- 키보드·마우스 입력을 전달합니다. 브라우저/OS가 가로채는 단축키, Ctrl+Alt+Del, 로그인·UAC 보안 화면, 관리자 권한 앱은 조작이 제한될 수 있습니다. 한/영 전환은 물리 키 코드 Lang1을 지원하지만 실제 한글 IME 조합과 모든 키보드 배열은 실기 검증하지 않았습니다.
- 기본은 사람이 PC 앞에서 승인하는 방식입니다. 숨김 실행·자동 시작·서비스 설치·보안 차단 우회 기능은 없습니다.
- TLS 인증서 검증과 AES-256-GCM 메시지 암호화, 방향별 키, 순서 검증을 사용합니다. 브라우저 코드를 제공하는 중계 서버와 서버 관리자를 신뢰해야 합니다. 관리자 승인이나 보안 심사를 대신하지 않습니다.
- 프로토콜은 허용된 통신을 위한 일반 HTTPS/WSS입니다. 회사 프록시·방화벽·보안 프로그램이 차단하면 사용할 수 없습니다. 차단 해제는 해당 회사의 승인 절차로 처리해야 합니다.
- 직접 작성한 서명 없는 실행 파일입니다. 회사에서 배포를 승인한 위치·방식으로 사용하세요.
- 휴대폰 브라우저는 터치 포인터로 일부 마우스 동작을 사용할 수 있으나 전체 모바일/가상 키보드 지원은 검증하지 않았습니다. 기본 사용 대상은 데스크톱 브라우저입니다.

## 개발·검증

.NET 10 SDK로 빌드합니다. 외부 NuGet 라이브러리나 브라우저 CDN은 사용하지 않습니다.

```powershell
dotnet build src/MiniRemote.Host -c Release
dotnet build src/MiniRemote.Relay -c Release
dotnet run --project tests/RelaySmoke -c Release
dotnet run --project tests/CoreSmoke -c Release -- src/MiniRemote.Relay/bin/Release/net10.0/MiniRemote.Relay.dll
node --test tests/Viewer/protocol.test.mjs
node tests/Viewer/cross-runtime.mjs
```

브라우저 smoke 시험은 테스트 도구 Playwright가 설치된 환경에서 `tests/Viewer/browser-smoke.mjs`로 수행합니다. 이 도구는 제품 런타임에 필요하지 않습니다.

확인한 범위: 로컬 실제 중계 서버, 암호화 패킷의 C#↔JS 호환, 합성 JPEG와 모의 입력, 브라우저 실제 이벤트, 승인 전 차단, 중단/연결 단절/변조/재전송 거부, Windows 입력 구조 및 PC 앱 정적 렌더링입니다. 시험 중 실제 사용자 화면을 캡처하거나 OS 입력을 주입하지 않았습니다. 실제 두 PC의 키·마우스 조작, 실제 회사망/외부망, HTTPS 배포, 잠금 화면, 한글 IME 조합은 확인 전입니다. Docker 실행 환경이 없어 Compose 구동도 미검증입니다.

원본 구조는 [PROTOCOL.md](PROTOCOL.md), 서버 설정은 [deploy/README.md](deploy/README.md)를 참조하세요. Microsoft 문서: [SendInput 제한](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-sendinput), [ASP.NET Core WebSockets](https://learn.microsoft.com/en-us/aspnet/core/fundamentals/websockets?view=aspnetcore-10.0).

