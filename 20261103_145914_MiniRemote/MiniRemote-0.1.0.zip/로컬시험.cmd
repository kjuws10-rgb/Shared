@echo off
setlocal
cd /d "%~dp0"
where dotnet >nul 2>nul
if errorlevel 1 (
  echo This local relay test needs the .NET 10 ASP.NET Core Runtime.
  echo See README.md for approved server deployment.
  pause
  exit /b 1
)
echo Local test only: http://localhost:8787
echo This window hosts the relay. Close it to stop the relay.
start "MiniRemote local test" "%~dp0host-light\MiniRemote.exe" "http://localhost:8787"
dotnet "%~dp0relay\MiniRemote.Relay.dll" --urls http://127.0.0.1:8787
pause
