# Approved relay deployment

Local development requires .NET 10. Run `dotnet run --project src/MiniRemote.Relay` from the project root, then open `http://127.0.0.1:8787`. The listener defaults to loopback. `http://localhost:8787` is also an allowed local browser origin.

For external access, obtain an approved server, DNS hostname and valid TLS certificate. Replace `relay.example.com` in both `Caddyfile` and `compose.yaml`, then run `docker compose -f deploy/compose.yaml up --build -d` from the project root. This deployment binds only Caddy's HTTPS/HTTP ports publicly; the relay's plain HTTP port stays inside the container network. Caddy obtains and renews the TLS certificate. Production approval, DNS, server and hosting costs are the operator's responsibility.

Both the Windows host and browser connect outward to the approved HTTPS origin. Corporate firewalls, proxies and endpoint policy must permit that destination and WebSocket traffic. The application does not circumvent those controls. Do not disable TLS validation or endpoint protection.

`MINIREMOTE_PUBLIC_ORIGIN` is the exact browser-facing origin, including a non-default port if used. External origins require HTTPS; HTTP is accepted only for loopback tests. The relay ignores forwarded headers and validates the Host header against this configured origin. Preserve the public Host header at the reverse proxy (Caddy does this by default).

The relay permits at most 64 rooms, 128 upgraded sessions and 12 connections per source IP. There are at most 30 route connection attempts per minute per IP; this also applies to shared corporate egress IPs and, behind a reverse proxy, its source IP. No forwarded address headers are trusted. Viewer messages are limited to 8 KiB and 120 messages/second; host messages to 2 MiB and 15 messages/second. No messages are buffered for a missing peer. Waiting rooms expire after 5 minutes; joined rooms after 1 hour. A peer disconnect ends both sides and removes the room. Up to 4096 recently consumed room codes are retained in memory for 1 hour to reject reuse; new rooms are refused if that bound is reached. Browser Origin must exactly match the configured origin; native hosts must omit Origin. These checks supplement the application's end-to-end session encryption.

Request logging is disabled because WebSocket paths contain room codes. Do not enable reverse-proxy access logging, analytics, request-body capture, or URL tracing for `/ws/`. Invitation encryption keys are URL fragments and must not be saved or logged. The relay forwards ciphertext and does not hold decryption keys, files, shell access, screen recordings or session histories.

The example is a deployment configuration, not evidence of a running public service. Validate from the real external and corporate networks before operational use. Local tests exercise protocol transport with synthetic bytes only.
