# MiniRemote v1

Authorized, attended screen + keyboard/mouse control only. No persistence, shell, file transfer, clipboard, bypass, or certificate-validation exceptions.

## Transport

- .NET 10 Windows WinForms host; browser viewer; ASP.NET Core relay.
- Relay static viewer at `/`; health at `/health`; WebSocket `/ws/{room}/{role}` (`host` or `viewer`).
- Room = base64url(random 16 bytes), exactly 22 ASCII `[A-Za-z0-9_-]` characters. One host creates room, one viewer joins existing room. No room listing. Single use: either peer disconnect closes both and removes room, including a disconnected viewer before approval.
- Host invite: `https://approved-relay.example/#room=ROOM&key=BASE64URL_32_RANDOM_BYTES`. Fragment never sent in HTTP. Host origin URL cannot have path, userinfo, query or fragment. Cleartext only loopback for local testing; external use requires HTTPS/WSS.
- Relay forwards opaque binary messages only; host->viewer max 2 MiB, viewer->host max 8192 bytes. No buffering until peers exist. Host sends nothing until encrypted viewer hello. Relay must permit normal TCP backpressure, bound connection count, room age (1 hour) and waiting time (5 minutes), validate browser Origin equals server origin, reject malformed routes/extra peers/text frames/oversize messages, redact route/room in logs.
- Loopback-only HTTP default at 127.0.0.1:8787; deploy behind approved HTTPS reverse proxy. Native host has no Origin. Viewer requires matching Origin. No arbitrary forwarded-header trust.

## End-to-end packet

Master = 32 random bytes. Host-to-viewer AES key = SHA256(master || UTF8("MiniRemote/host/v1")); viewer-to-host = SHA256(master || UTF8("MiniRemote/viewer/v1")). AES-256-GCM, tag 128 bits, fresh CSPRNG 12-byte nonce per packet, no AAD.

Wire: nonce[12] || ciphertext || tag[16]. Decrypted: type[1] || sequence[8 unsigned big endian] || payload. Per-direction sequence starts at 0; receiving any other next sequence or invalid tag closes the single-use session. Minimum wire length 37 bytes. Session keys never persisted/logged. Browser must serialize async encrypt/decrypt calls in send/receive order.

Types:

1. Hello viewer->host JSON `{ "name": "viewer label" }`. Exactly once, first packet. Name max 60 characters, strip control characters; self-reported label, not verified identity.
2. Decision host->viewer JSON `{ "accepted": true/false, "message": "..." }`. Host user explicitly approves within 30 seconds. Before approval NO frames and NO input. Rejection/timeout ends room.
3. Frame host->viewer JPEG bytes. Primary monitor only, max width1280 / height900, aspect preserved, max5fps, quality55. Input normalized coordinates relative to this monitor. No captured screen sent until approval.
4. Input viewer->host JSON: `{ "kind": "move|button|wheel|key|release", "x": 0..1, "y": 0..1, "button": 0/1/2, "down": true/false, "code": "KeyA", "delta": 120 }`. Mouse button numbering is browser MouseEvent.button (0 left, 1 middle, 2 right). For key, use physical KeyboardEvent.code. Reject invalid values/unknown kinds, only supported code whitelist. Release clears tracked remote keys/buttons. Input only while approved. Repeated key downs allowed for key repeat. Send move at most30fps, queue bounded (bufferedAmount) and disconnect on overload; never silently drop releases.
5. End either direction JSON `{ "message": "..." }`; then disconnect.
6. Heartbeat both directions empty, every2s after hello; session dead after12s without ANY authenticated message. Host also limits approval to30s and active session to1h. Browser background throttling can terminate session safely.

Viewer sends `release` on blur, document hidden, lost pointer capture, before stop. Explicit click on screen enables keyboard forwarding. Esc stays local and pauses control, Ctrl+Alt+Del and Windows/UAC secure desktop unavailable. Host releases all tracked inputs on stop, disconnect, protocol error, timeout. Native host stop button and Ctrl+Alt+F12 hotkey end session. Local approval dialog remains modeless with main stop accessible. Host server field can be prefilled from first CLI argument; no unattended-control CLI option.
